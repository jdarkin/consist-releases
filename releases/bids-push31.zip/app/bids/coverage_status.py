"""Agency coverage status: one row per agency in agency_coverage, rebuilt by the daily scan, for the site's coverage pages.
Keyword-free and Claude-free: it only counts what Bid Catcher already stored.

  status   live      read automatically and working (a page, feed, open data or API read in the last 3 days, or an alert
                     email from the agency's portal account in the last 30 days)
           email     covered by portal alert emails only
           limited   the agency's pages refuse automated reading (robots.txt / 403 / login) and no alerts arrive yet
           pending   a portal account is waiting for the agency's approval, nothing reads yet
           none      no working channel
  quiet    1 when an agency that normally posts (6+ notices in the past year) has posted nothing for
           max(45 days, 3 x its usual gap between postings)

  bidmon coverage-status          rebuild and print a summary
"""
import datetime as dt
import statistics

import bidcore as bc

SCHEMA = """
CREATE TABLE IF NOT EXISTS agency_coverage (
  agency_id TEXT PRIMARY KEY, agency TEXT, country TEXT, state_prov TEXT, rail_modes TEXT, fleet_operator_ids TEXT,
  status TEXT, channels TEXT, platform TEXT, account_status TEXT,
  pages INTEGER, pages_ok INTEGER, pages_blocked INTEGER, meeting_sources INTEGER,
  last_checked TEXT, last_email TEXT, last_posting TEXT, last_award TEXT, last_meeting TEXT,
  notices_30d INTEGER, notices_90d INTEGER, rail_notices_90d INTEGER, notices_365d INTEGER, awards_365d INTEGER,
  open_bids INTEGER, usual_gap_days REAL, days_since_posting INTEGER, quiet INTEGER, updated TEXT);
"""
OPEN_DATA = {"seao": "open data (SEAO)", "canadabuys": "open data (CanadaBuys)", "ny_open_data": "open data (NY)",
             "sam_gov": "SAM.gov", "usaspending": "open data (USAspending)"}
RANK = {"active": 5, "verified": 4, "verify_pending": 3, "submitted": 2, "todo": 1, "skipped": 0}


def ensure(c):
    c.executescript(SCHEMA)
    c.commit()


def _d(s):
    try:
        return dt.date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def refresh(c):
    """Rebuilds agency_coverage. Returns {status: count}."""
    import coverage
    import inbox
    ensure(c)
    today = dt.date.today()
    recent = (dt.datetime.utcnow() - dt.timedelta(days=3)).isoformat(timespec="seconds")
    since30 = (dt.datetime.utcnow() - dt.timedelta(days=30)).isoformat(timespec="seconds")
    reg = {r["account_key"]: r["status"] for r in c.execute("SELECT account_key, status FROM registration")}
    pages = {}
    for r in c.execute("SELECT agency_id, last_checked, last_error FROM page_watch WHERE agency_id IS NOT NULL"):
        pages.setdefault(r["agency_id"], []).append(r)
    try:
        meet = {r[0]: (r[1], r[2]) for r in c.execute("SELECT agency_id, count(*), max(last_checked) FROM meeting_source WHERE active=1 GROUP BY agency_id")}
        last_meet = {r[0]: r[1] for r in c.execute("SELECT agency_id, max(meeting_date) FROM meeting WHERE meeting_date <= date('now') GROUP BY agency_id")}
    except Exception:
        meet, last_meet = {}, {}
    try:
        cps = {r[0]: r[1] for r in c.execute("SELECT agency_id, max(last_checked) FROM doc_source GROUP BY agency_id")}
    except Exception:
        cps = {}
    out = {}
    rows = []
    for a in c.execute("SELECT * FROM agency").fetchall():
        aid = a["agency_id"]
        pw = pages.get(aid, [])
        ok = [p for p in pw if p["last_checked"] and not p["last_error"]]
        blocked = [p for p in pw if coverage._blocked(p["last_error"])]
        keys = [k for k in (a["account_key"] or "").split(";") if k]
        acct = max((reg.get(k) for k in keys if reg.get(k)), key=lambda s: RANK.get(s, 0), default=None)
        doms = []
        for k in keys:
            base = k.split(":")[0]
            doms += [d for d, (_, kk) in inbox.PLATFORM_DOMAINS.items() if kk == base] + coverage.EXTRA_DOMAINS.get(base, [])
        doms += coverage.AGENCY_DOMAINS.get(aid, [])
        last_email = max((d for d, _ in coverage._alerts(c, sorted(set(doms)))), default="") if doms else ""
        n = c.execute("SELECT max(coalesce(published, date(first_seen))) last, "
                      "sum(coalesce(published, date(first_seen)) >= date('now','-30 days')) n30, "
                      "sum(coalesce(published, date(first_seen)) >= date('now','-90 days')) n90, "
                      "sum(coalesce(published, date(first_seen)) >= date('now','-90 days') AND coalesce(relevance, kw_score, 0) >= 50) r90, "
                      "sum(coalesce(published, date(first_seen)) >= date('now','-365 days')) n365, "
                      "sum(coalesce(notice_type,'') NOT IN ('award','cancelled') AND closing >= date('now') AND coalesce(relevance, kw_score, 0) >= 50) open_ "
                      "FROM notice WHERE agency_id=? AND coalesce(notice_type,'') != 'award'", (aid,)).fetchone()
        aw = c.execute("SELECT max(award_date), sum(award_date >= date('now','-365 days')) FROM award WHERE agency_id=?", (aid,)).fetchone()
        srcs = {r[0] for r in c.execute("SELECT DISTINCT source FROM notice WHERE agency_id=? AND first_seen >= date('now','-365 days')", (aid,))}
        dates = sorted({d for (d,) in c.execute("SELECT DISTINCT coalesce(published, date(first_seen)) FROM notice WHERE agency_id=? "
                                                  "AND coalesce(notice_type,'') != 'award' AND coalesce(published, date(first_seen)) >= date('now','-365 days')", (aid,))
                        if _d(d)})
        gaps = [(_d(b) - _d(a_)).days for a_, b in zip(dates, dates[1:])]
        gap = statistics.median(gaps) if gaps else None
        last = _d(n["last"])
        since = (today - last).days if last else None
        quiet = int(bool((n["n365"] or 0) >= 6 and since is not None and since > max(45, 3 * (gap or 0))))
        channels = []
        if pw:
            channels.append("agency page")
        if meet.get(aid):
            channels.append("board meetings")
        if cps.get(aid):
            channels.append("documents")
        if acct in ("active", "verified"):
            channels.append("portal alerts")
        channels += sorted({v for s, v in OPEN_DATA.items() if s in srcs})
        live = any((p["last_checked"] or "") >= recent for p in ok) or (meet.get(aid) and (meet[aid][1] or "") >= recent) \
            or bool({"seao", "canadabuys", "ny_open_data", "sam_gov"} & srcs and (n["n90"] or 0)) or (last_email and last_email >= since30 and ok)
        if live:
            status = "live"
        elif last_email and last_email >= since30:
            status = "email"
        elif blocked and len(blocked) >= len(pw):
            status = "limited"
        elif acct in ("submitted", "verify_pending"):
            status = "pending"
        else:
            status = "none"
        out[status] = out.get(status, 0) + 1
        checked = max([p["last_checked"] or "" for p in pw] + [(meet.get(aid) or (0, ""))[1] or "", cps.get(aid) or ""], default="") or None
        rows.append((aid, a["agency"], a["country"], a["state_prov"], a["rail_modes"], a["fleet_operator_ids"], status, ";".join(channels),
                     a["platform"], acct, len(pw), len(ok), len(blocked), (meet.get(aid) or (0, None))[0],
                     checked, (last_email or "")[:19] or None, n["last"], aw[0], last_meet.get(aid),
                     n["n30"] or 0, n["n90"] or 0, n["r90"] or 0, n["n365"] or 0, aw[1] or 0, n["open_"] or 0,
                     gap, since, quiet, bc.now()))
    c.execute("DELETE FROM agency_coverage")
    c.executemany(f"INSERT INTO agency_coverage VALUES ({','.join('?' * 29)})", rows)
    c.commit()
    return out


def summary(c):
    ensure(c)
    lines = ["status: " + ", ".join(f"{s} {n}" for s, n in c.execute("SELECT status, count(*) FROM agency_coverage GROUP BY status ORDER BY 2 DESC"))]
    q = c.execute("SELECT agency_id, last_posting, days_since_posting, usual_gap_days FROM agency_coverage WHERE quiet=1 ORDER BY days_since_posting DESC").fetchall()
    lines.append(f"quiet (normally active, nothing new lately): {len(q)}")
    lines += [f"  {r['agency_id']:14} last posting {r['last_posting']} ({r['days_since_posting']} days; usual gap {r['usual_gap_days'] or '-'} days)" for r in q[:25]]
    return "\n".join(lines)


_BIDWORDS = __import__("re").compile(r"\b(rfp|rfq|ifb|itb|bid|bids|solicitation|tender|proposal|due date|closing|addend)", __import__("re").I)


def audit(c, limit=80):
    """Why do 'live' agencies show no postings? One block per live agency with no notices in 90 days: which channel made
    it live, what each watched page last returned, and how many notices that agency ever got from each source.
    Read-only; prints text."""
    import os
    ensure(c)
    out = []
    rows = c.execute("SELECT * FROM agency_coverage WHERE status='live' AND coalesce(notices_90d,0)=0 ORDER BY agency_id").fetchall()
    allive = c.execute("SELECT count(*) FROM agency_coverage WHERE status='live'").fetchone()[0]
    out.append(f"live agencies: {allive}; live with 0 notices in 90 days: {len(rows)}")
    # spend and extraction trouble in the last 30 days
    spend = c.execute("SELECT substr(started,1,10) d, round(sum(cost_usd),3) FROM run_log WHERE started >= date('now','-14 days') GROUP BY d ORDER BY d").fetchall()
    out.append("Claude spend per day (14 d): " + ", ".join(f"{d[5:]} ${s}" for d, s in spend))
    try:
        cap = float((bc.settings() or {}).get("max_usd_per_day", 2))
    except Exception:
        cap = None
    out.append(f"daily cap: ${cap}")
    counts = {"budget reached": 0, "extraction failed": 0, "scan pages failed": 0}
    if os.path.exists(bc.LOG):
        cutoff = (dt.date.today() - dt.timedelta(days=30)).isoformat()
        with open(bc.LOG, errors="replace") as f:
            for line in f:
                if line[:10] < cutoff:
                    continue
                if "page watch: daily budget reached" in line:
                    counts["budget reached"] += 1
                elif "page watch: extraction failed" in line:
                    counts["extraction failed"] += 1
                elif "scan pages failed" in line:
                    counts["scan pages failed"] += 1
    out.append("log, last 30 days: " + ", ".join(f"{k} {v}" for k, v in counts.items()))
    src_all = {}
    for r in c.execute("SELECT agency_id, source, count(*) n, max(coalesce(published, date(first_seen))) last FROM notice GROUP BY agency_id, source"):
        src_all.setdefault(r["agency_id"], []).append(f"{r['source']} {r['n']} (last {r['last']})")
    summary = {"no page text": 0, "page has no bid words": 0, "page has bid words but 0 page notices": 0, "live via meetings/email only": 0}
    for a in rows[:limit]:
        aid = a["agency_id"]
        pw = c.execute("SELECT url, kind, last_checked, last_changed, last_error, length(coalesce(last_text,'')) n, last_text FROM page_watch WHERE agency_id=?", (aid,)).fetchall()
        ok = [p for p in pw if p["last_checked"] and not p["last_error"]]
        why = "pages" if ok else ("meetings" if a["meeting_sources"] else "email/other")
        out.append(f"\n{aid} [{a['platform'] or '-'}] live via {why}; channels {a['channels'] or '-'}; notices ever: " + ("; ".join(src_all.get(aid, [])) or "none"))
        if not ok:
            summary["live via meetings/email only"] += 1
        for p in pw:
            txt = p["last_text"] or ""
            hits = len(_BIDWORDS.findall(txt))
            snippet = " ".join(txt.split())[:110]
            out.append(f"  {p['kind'][:5]} {p['url'][:90]}\n     checked {str(p['last_checked'])[:10]} changed {str(p['last_changed'])[:10]} "
                       f"text {p['n']} chars, bid words {hits}" + (f", ERROR {p['last_error'][:80]}" if p["last_error"] else "") + f"\n     \"{snippet}\"")
        if ok:
            t = " ".join(p["last_text"] or "" for p in ok)
            if len(t) < 200:
                summary["no page text"] += 1
            elif len(_BIDWORDS.findall(t)) < 3:
                summary["page has no bid words"] += 1
            else:
                summary["page has bid words but 0 page notices"] += 1
    out.insert(4, "breakdown: " + ", ".join(f"{k} {v}" for k, v in summary.items()))
    return "\n".join(out)
