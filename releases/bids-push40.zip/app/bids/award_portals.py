"""Where each agency posts its bids, awards and closed solicitations (Justin 11-18: "look on every procurement portal for
notice of award ... go back as far as the agency's portal will let you").

Table agency_link: one row per (agency, url) with kind bids | awards | closed | tabulations, where it came from
(portal = portals.csv, curated = award_pages.csv shipped with Bid Catcher, discovered = found by discover()), and
whether page watch reads it. The Consist site shows these links on operator and agency pages.

discover(): reads each agency's bidding page (and its other watched pages) with the normal robots.txt rules and keeps
the links whose words say award, notice of award, bid results, tabulation, closed / past / archived solicitations.
No Claude calls. Batches of agencies per daily run until every agency has been checked, then again every 60 days.

Award pages found this way are read by the daily page watch as kind 'awards' (sources.watch_urls). Their first read
is history (never alerted). backfill() then follows each award page's older pages (next-page links, earlier years,
yearly award PDFs) once, as far back as the portal shows, within its own daily dollar cap (config award_backfill_usd,
default 1.0), also as history.
"""
import csv
import datetime
import html
import os
import re
import time
import urllib.parse

import bidcore as bc
import sources

KINDS = ("awards", "closed", "tabulations")
HERE = os.path.dirname(os.path.abspath(__file__))

POS = re.compile(r"\b(notice of (intent to )?award|intent to award|(contract|bid|solicitation|procurement|rfp)s? awards?|awarded (contracts?|bids?|solicitations?)|"
                 r"awards?\b|bid results?|solicitation results?|bid tab(ulation)?s?|tabulations?|"
                 r"(closed|past|previous|expired|archived?|completed|historical|inactive) (bids?|solicitations?|opportunities|procurements?|rfps?|ifbs?|contracts?|projects?)|"
                 r"(bid|solicitation|procurement)s? archive|archived?\b)", re.I)
NEG = re.compile(r"employee|safety|ceremon|banquet|program award|grant|scholarship|recogni|honou?r|award[- ]winning|"
                 r"apta|media|press|news|dbe|small business|award fee|fta award|federal award|wins?\b|achievement|excellence|"
                 r"meeting|minutes|agenda|budget|annual report|careers?|jobs?|art\b|photo|video", re.I)
HREF_POS = re.compile(r"award|closed|archive|past[-_]?(bid|solicit|opportun)|bid[-_]?result|tabulat|expired|completed[-_]?(bid|solicit)", re.I)
NEXT = re.compile(r"^\s*(next|next page|older|older entries|more|›|»|>|>>)\s*$", re.I)
YEARISH = re.compile(r"\b(19|20)\d\d\b")


def ensure(c):
    c.execute("""CREATE TABLE IF NOT EXISTS agency_link (
        agency_id TEXT NOT NULL, url TEXT NOT NULL, kind TEXT NOT NULL, label TEXT, source TEXT, watch INTEGER DEFAULT 1,
        score INTEGER, found TEXT, last_checked TEXT, backfilled TEXT, backfill_pages INTEGER, note TEXT,
        PRIMARY KEY (agency_id, url))""")
    c.execute("""CREATE TABLE IF NOT EXISTS agency_link_scan (agency_id TEXT PRIMARY KEY, checked TEXT, pages INTEGER,
        found INTEGER, error TEXT)""")


def kind_of(text, href=""):
    s = f"{text} {href}"
    if re.search(r"tabul|bid[-_ ]?results?|solicitation results?", s, re.I):
        return "tabulations"
    if re.search(r"award", s, re.I):
        return "awards"
    return "closed"


def is_pdf(u):
    return urllib.parse.urlparse(u).path.lower().endswith(".pdf")


def seed(c):
    """portals.csv bidding pages (kind bids) and the curated award pages shipped as award_pages.csv."""
    ensure(c)
    for r in c.execute("SELECT agency_id, portal_url, platform FROM agency WHERE portal_url LIKE 'http%'").fetchall():
        c.execute("INSERT INTO agency_link (agency_id, url, kind, label, source, watch, found) VALUES (?,?,?,?,?,0,?) "
                  "ON CONFLICT(agency_id, url) DO UPDATE SET kind=CASE WHEN agency_link.source='portal' THEN 'bids' ELSE agency_link.kind END",
                  (r["agency_id"], r["portal_url"], "bids", r["platform"] or "Bidding page", "portal", bc.now()))
    path = os.path.join(HERE, "award_pages.csv")
    if os.path.exists(path):
        for r in csv.DictReader(open(path, newline="", encoding="utf-8-sig")):
            aid, url = (r.get("agency_id") or "").strip(), (r.get("url") or "").strip()
            if not aid or not url.startswith("http"):
                continue
            kind = (r.get("kind") or "awards").strip()
            watch = 0 if is_pdf(url) or (r.get("watch") or "1").strip() == "0" else 1
            c.execute("INSERT INTO agency_link (agency_id, url, kind, label, source, watch, found, note) VALUES (?,?,?,?,?,?,?,?) "
                      "ON CONFLICT(agency_id, url) DO UPDATE SET kind=excluded.kind, label=excluded.label, source='curated', "
                      "watch=excluded.watch, note=excluded.note",
                      (aid, url, kind, (r.get("label") or "").strip() or None, "curated", watch, bc.now(), (r.get("note") or "").strip() or None))
    c.commit()


_A = re.compile(r"<a\b([^>]*)>(.*?)</a>", re.I | re.S)
_HREF = re.compile(r"""href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))""", re.I)


def links(raw_html, base):
    """(absolute url, link text, rel) for every <a href> on a page."""
    out = []
    for attrs, inner in _A.findall(raw_html):
        m = _HREF.search(attrs)
        if not m:
            continue
        href = html.unescape(next(g for g in m.groups() if g is not None)).strip()
        if not href or href.startswith(("#", "mailto:", "javascript:", "tel:")):
            continue
        text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", inner))).strip()
        if not text:
            t = re.search(r"""(?:title|aria-label)\s*=\s*["']([^"']+)""", attrs, re.I)
            text = t.group(1) if t else ""
        rel = (re.search(r"""rel\s*=\s*["']?([\w ]+)""", attrs, re.I) or [None, ""])[1]
        out.append((urllib.parse.urljoin(base, href).split("#")[0], text[:200], rel.lower()))
    return out


def _site(u):
    h = urllib.parse.urlparse(u).netloc.lower().split(":")[0]
    p = h.split(".")
    return ".".join(p[-3:]) if len(p) > 2 and len(p[-1]) == 2 and p[-2] in ("co", "gc", "on", "qc", "bc", "ab") else ".".join(p[-2:])


def score(text, href):
    if NEG.search(text):
        return 0
    s = 0
    if POS.search(text):
        s += 2
    if HREF_POS.search(href):
        s += 1
    if re.fullmatch(r"\s*awards?\s*", text or "", re.I) and not re.search(r"procure|purchas|bid|solicit|contract|vendor|supplier|business", href, re.I):
        return 0  # a bare "Awards" menu item outside procurement is usually the agency's honours page
    if len(text or "") > 60 and not re.search(r"closed|past|archiv|tabulat|results", text, re.I):
        return 0  # one notice, not a list of them
    return s


def _get(url):
    """Raw HTML (robots.txt honoured; JavaScript portals through the render service when configured)."""
    host = urllib.parse.urlparse(url).netloc.lower()
    if any(host == h or host.endswith("." + h) for h in sources.JS_HOSTS):
        if not bc.RENDER_URL:
            raise RuntimeError("JavaScript portal and no render service")
        h, final = bc.render(url)
        return h, final
    raw, cs, final = bc.fetch(url, timeout=40)
    return raw.decode(cs, "replace"), final


def discover(c, agencies=None, limit=40, days=60, pause=1.0, verbose=False):
    """Checks up to `limit` agencies not checked in `days` (or the given ones). Returns (agencies checked, links found)."""
    ensure(c)
    seed(c)
    cut = (datetime.datetime.utcnow() - datetime.timedelta(days=days)).isoformat()
    if agencies:
        todo = list(agencies)
    else:
        todo = [r[0] for r in c.execute(
            "SELECT a.agency_id FROM agency a LEFT JOIN agency_link_scan s ON s.agency_id=a.agency_id "
            "WHERE a.portal_url LIKE 'http%' AND (s.checked IS NULL OR s.checked < ?) ORDER BY s.checked IS NOT NULL, s.checked, a.agency_id LIMIT ?",
            (cut, limit))]
    total = 0
    for aid in todo:
        starts = [r[0] for r in c.execute("SELECT portal_url FROM agency WHERE agency_id=? AND portal_url LIKE 'http%'", (aid,))]
        starts += [r[0] for r in c.execute("SELECT url FROM page_watch WHERE agency_id=? AND kind='solicitations'", (aid,)) if r[0] not in starts]
        starts += [u for u, a, k in sources.EXTRA_PAGES if a == aid and u not in starts]
        seen, found, pages, err = set(starts), {}, 0, None
        queue = [(u, 0) for u in starts[:6]]
        while queue and pages < 10:
            url, depth = queue.pop(0)
            try:
                page, final = _get(url)
            except Exception as e:
                err = f"{url}: {e}"[:300]
                continue
            pages += 1
            time.sleep(pause)
            more = []
            for u, text, rel in links(page, final):
                if is_pdf(u) and not YEARISH.search(text + u):
                    continue
                if _site(u) != _site(final) and not any(h in u for h in sources.JS_HOSTS):
                    continue
                s = score(text, u)
                if s >= 2 and u not in found:
                    found[u] = (kind_of(text, u), text, s)
                elif depth == 0 and u not in seen and re.search(r"\b(procurements?|purchasing|bids?( and| &amp;| &) (rfps?|proposals|contracts)|bid opportunities|solicitations|doing business|contracting|vendors?|suppliers?)\b", text, re.I) \
                        and not NEG.search(text):
                    more.append(u)
            if depth == 0 and not found:
                for u in more[:3]:
                    seen.add(u)
                    queue.append((u, 1))
        for u, (kind, text, s) in found.items():
            c.execute("INSERT INTO agency_link (agency_id, url, kind, label, source, watch, score, found) VALUES (?,?,?,?,?,?,?,?) "
                      "ON CONFLICT(agency_id, url) DO UPDATE SET score=excluded.score",
                      (aid, u, kind, text or None, "discovered", 0 if is_pdf(u) else 1, s, bc.now()))
        c.execute("INSERT INTO agency_link_scan (agency_id, checked, pages, found, error) VALUES (?,?,?,?,?) "
                  "ON CONFLICT(agency_id) DO UPDATE SET checked=excluded.checked, pages=excluded.pages, found=excluded.found, error=excluded.error",
                  (aid, bc.now(), pages, len(found), err if not pages else None))
        c.commit()
        total += len(found)
        if verbose:
            print(f"{aid}: {pages} pages read, {len(found)} award links" + (f" ({err})" if err and not pages else ""))
            for u, (kind, text, s) in found.items():
                print(f"   {kind:12} {text[:50]!r:52} {u}")
    return len(todo), total


def watched(c):
    """(url, agency_id, country) of award pages for the daily page watch."""
    ensure(c)
    return [(r[0], r[1], r[2] or "US") for r in c.execute(
        "SELECT l.url, l.agency_id, a.country FROM agency_link l LEFT JOIN agency a ON a.agency_id=l.agency_id "
        "WHERE l.kind IN ('awards','closed','tabulations') AND l.watch=1 AND l.url LIKE 'http%'")]


def _older_pages(page, final, limit):
    """Next-page links and earlier-year pages or PDFs linked from an award page, oldest last, at most `limit`."""
    out = []
    for u, text, rel in links(page, final):
        if u == final or _site(u) != _site(final):
            continue
        if "next" in rel or NEXT.match(text) or (re.fullmatch(r"\d{1,3}", text) and re.search(r"[?&/](page|p|paged|pg|start|offset)[=/]?\d", u, re.I)):
            out.append(u)
        elif YEARISH.search(text) and (POS.search(text) or HREF_POS.search(u)) and not NEG.search(text):
            out.append(u)
    seen, res = set(), []
    for u in out:
        if u not in seen:
            seen.add(u)
            res.append(u)
    return res[:limit]


def _text(url):
    """(text, final url, how) of a page or PDF, read locally: pypdf for PDFs (no OCR in the image: a scanned PDF
    comes back with almost no text and is queued as 'scanned')."""
    if is_pdf(url):
        raw, cs, final = bc.fetch(url, timeout=90)
        try:
            import io, pypdf
            return "\n".join((p.extract_text() or "") for p in pypdf.PdfReader(io.BytesIO(raw)).pages[:200])[:400000], final, "pdf"
        except Exception as e:
            raise RuntimeError(f"PDF not readable: {e}")
    text, final = sources.read_page(url)
    return text, final, "html"


# ---- free reading: rules first, everything else waits in award_doc for review (Justin 11-18: no API spend) ----

MONEY = re.compile(r"(?:US\s?|CA|C)?\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?|\d{4,}(?:\.\d{2})?)")
COMPANY = re.compile(r"\b([A-Z0-9][A-Za-z0-9&.,'’\-/ ]{1,70}?\s(?:Inc|Incorporated|LLC|L\.L\.C|Corp|Corporation|Company|Co|Ltd|Limited|LP|LLP|PLLC|PC|"
                     r"JV|Joint Venture|Group|Associates|Services|Systems|Technologies|Constructors|Construction|Contractors|Engineering|"
                     r"Ltée|Ltee|Inc\.?|Enterprises|Industries|Solutions|Partners|Builders|Electric|Mobility|Transit|Rail)\b\.?)")
DATE = re.compile(r"\b(\d{1,2}/\d{1,2}/(?:19|20)?\d\d|(?:19|20)\d\d-\d{2}-\d{2}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2},?\s+(?:19|20)\d\d)\b")
REF = re.compile(r"\b((?:RFP|IFB|ITB|RFQ|RFB|BID|CONTRACT|SOLICITATION|NO\.?)\s*#?\s*[A-Z0-9][A-Z0-9\-./]{2,20}|[A-Z]{1,6}-?\d{2,}[-A-Z0-9]*)\b", re.I)
NOT_VENDOR = re.compile(r"^(total|amount|award|contract|vendor|contractor|description|title|date|project|estimate|budget|engineer)", re.I)


_SUFFIX = re.compile(r"^(Inc|Incorporated|LLC|L\.L\.C|Corp|Corporation|Co|Ltd|Limited|LP|LLP|PLLC|PC|JV|Ltée|Ltee)\.?$", re.I)


def _vendor_tail(s):
    """The company name at the end of a matched run: 'Q24-118 Escalator parts supply, Kone Inc.' -> 'Kone Inc'."""
    parts = [p.strip(" ,.;|") for p in re.split(r"\s[-–|]\s|,\s|;\s|\t|\s{2,}", s) if p.strip(" ,.;|")]
    if not parts:
        return s.strip(" ,.;|")
    v = parts[-1]
    if _SUFFIX.match(v) and len(parts) > 1:
        v = parts[-2] + ", " + v
    return v


def _iso(d):
    try:
        return sources.iso(d)
    except Exception:
        return None


def parse_awards(text):
    """Award rows a plain list or table shows: a line (or a table row split over a few lines) with a company name and a
    dollar amount. Title = the longest other text nearby. Returns dicts in store_items shape (kind 'award'). Conservative:
    anything ambiguous is left for review."""
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    out, used = [], set()
    for i, line in enumerate(lines):
        if i in used or not MONEY.search(line):
            continue
        lo = i
        while lo > 0 and i - lo < 4 and lo - 1 not in used and not MONEY.search(lines[lo - 1]):
            lo -= 1
        window = lines[lo:i + 1]
        blob = " | ".join(window)
        vend = None
        for w in window:
            m = COMPANY.search(w)
            if m and not NOT_VENDOR.match(m.group(1)):
                vend = _vendor_tail(m.group(1))
                break
        if not vend:
            continue
        amt = float(MONEY.search(line).group(1).replace(",", ""))
        if amt < 1000:
            continue
        others = [w for w in window if vend not in w and not MONEY.fullmatch(w.strip()) and not DATE.fullmatch(w.strip()) and len(w) > 8]
        title = max(others, key=len) if others else ""
        if not title:  # one-line row: what is left of it once vendor, amount, date and reference are taken out
            title = line.replace(vend, " ")
            r0 = REF.search(blob)
            if r0:
                title = title.replace(r0.group(1), " ")
        title = re.sub(r"\s+", " ", MONEY.sub("", DATE.sub("", title)))
        title = re.sub(r"(\s*[,.;:|]\s*)+$", "", re.sub(r"\s*([,;])(\s*[,.;])+", r"\1", title)).strip(" -|,;:")
        if len(title) < 6:
            continue
        d = DATE.search(blob)
        r = REF.search(blob)
        out.append({"kind": "award", "ref_no": (r.group(1).strip() if r else ""), "title": title[:300], "description": "",
                    "closing": "", "url": "", "vendor": vend[:200], "amount": amt, "award_date": (_iso(d.group(1)) if d else "") or "",
                    "bidders": []})
        used.update(range(lo, i + 1))
    return out


def ensure_queue(c):
    c.execute("""CREATE TABLE IF NOT EXISTS award_doc (id INTEGER PRIMARY KEY, agency_id TEXT, url TEXT UNIQUE, how TEXT,
        text TEXT, chars INTEGER, parsed INTEGER, stored INTEGER, status TEXT, added TEXT, reviewed TEXT, note TEXT)""")


def read_free(c, aid, country, url, text, how="html", suppliers=None):
    """Rules over the text, rows stored as history (confidence C, source 'rules'); the text kept in award_doc for review.
    Returns (rows parsed, rows new)."""
    ensure_queue(c)
    items = parse_awards(text)
    old = sources.HISTORY
    sources.HISTORY = True
    try:
        new = sources.store_items(c, items, aid, country, url, "rules", suppliers) if items else 0
    finally:
        sources.HISTORY = old
    c.execute("UPDATE award SET confidence='C' WHERE source='rules' AND confidence='A' AND agency_id IS ?", (aid,))
    status = "scanned" if how == "pdf" and len(text.strip()) < 300 else "queued"
    c.execute("INSERT INTO award_doc (agency_id, url, how, text, chars, parsed, stored, status, added) VALUES (?,?,?,?,?,?,?,?,?) "
              "ON CONFLICT(url) DO UPDATE SET text=excluded.text, chars=excluded.chars, parsed=excluded.parsed, "
              "stored=award_doc.stored+excluded.stored, status=CASE WHEN award_doc.status='reviewed' THEN 'changed' ELSE excluded.status END, added=excluded.added",
              (aid, url, how, text, len(text), len(items), new, status, bc.now()))
    c.commit()
    if not items and status == "queued":
        try:
            did = c.execute("SELECT id FROM award_doc WHERE url=?", (url,)).fetchone()[0]
            pi_submit(c, did, text)
        except Exception as e:
            bc.log(f"pi reader: could not queue {url}: {e}")
    return len(items), new


# ---- the Pi reader (pi-reader thread, Justin 11-18): a local model on the Raspberry Pi reads documents the rules
# could not, for free. Jobs are files in /data/pi-jobs/inbox; results come back in /data/pi-jobs/outbox. Off until
# the folder exists (vps-pijobs-setup.sh makes it). Results are suggestions from a small model: stored as confidence D.

PIJOBS = os.environ.get("BIDS_PI_JOBS", os.path.join(getattr(bc, "DATA", "/data"), "pi-jobs"))
PI_CHUNK = 11000


def pi_on():
    return os.path.isdir(os.path.join(PIJOBS, "inbox"))


def pi_submit(c, doc_id, text, max_chunks=8):
    """Writes the document as Pi jobs (one per ~11k characters, at most max_chunks). Returns jobs written."""
    if not pi_on() or len(text.strip()) < 300:
        return 0
    lines, chunks, cur = text.split("\n"), [], ""
    for l in lines:
        if len(cur) + len(l) + 1 > PI_CHUNK and cur:
            chunks.append(cur)
            cur = ""
        cur += l + "\n"
    if cur.strip():
        chunks.append(cur)
    import json
    n = 0
    for i, ch in enumerate(chunks[:max_chunks]):
        jid = f"awdoc-{doc_id}-{i}"
        tmp = os.path.join(PIJOBS, "inbox", f".{jid}.tmp")
        with open(tmp, "w") as f:
            json.dump({"id": jid, "kind": "award", "text": ch}, f)
        os.chmod(tmp, 0o664)
        os.replace(tmp, os.path.join(PIJOBS, "inbox", f"{jid}.json"))
        n += 1
    c.execute("UPDATE award_doc SET status='pi', note=coalesce(note,'') || ? WHERE id=?", (f" pi jobs {n};", doc_id))
    c.commit()
    return n


def pi_consume(c, min_conf=0.6):
    """Reads Pi results: an awardee with an amount becomes an award (confidence D, source 'pi', history); everything is
    noted on the document. Returns (results read, awards added)."""
    import glob, json
    if not os.path.isdir(os.path.join(PIJOBS, "outbox")):
        return 0, 0
    ensure_queue(c)
    suppliers = sources.supplier_ids()
    read = added = 0
    old = sources.HISTORY
    sources.HISTORY = True
    try:
        for p in sorted(glob.glob(os.path.join(PIJOBS, "outbox", "*.json"))):
            try:
                res = json.load(open(p))
            except Exception:
                continue
            read += 1
            m = re.match(r"awdoc-(\d+)-(\d+)$", str(res.get("id") or ""))
            doc = c.execute("SELECT * FROM award_doc WHERE id=?", (int(m.group(1)),)).fetchone() if m else None
            f = res.get("fields") or {}
            note = (f" pi {m.group(2) if m else '?'}: " + (f"error {res.get('error')}" if not res.get("ok") else
                    f"{f.get('awardee')} {f.get('amount')} conf {f.get('confidence')}"))[:300] + ";"
            try:
                conf = float(f.get("confidence") or 0)
            except (TypeError, ValueError):
                conf = 0.0
            if doc and res.get("ok") and f.get("awardee") and f.get("amount") and conf >= min_conf:
                try:
                    amt = float(str(f["amount"]).replace(",", "").replace("$", ""))
                except ValueError:
                    amt = None
                item = {"kind": "award", "ref_no": str(f.get("solicitation") or "")[:60], "title": str(f.get("title") or f.get("solicitation") or "Award")[:300],
                        "description": "", "closing": "", "url": "", "vendor": str(f["awardee"])[:200], "amount": amt,
                        "award_date": _iso(str(f.get("award_date") or "")) or "",
                        "bidders": [{"name": str(b.get("name")), "amount": b.get("amount") or 0} for b in (f.get("bidders") or []) if isinstance(b, dict) and b.get("name")]}
                ctry = (c.execute("SELECT country FROM agency WHERE agency_id=?", (doc["agency_id"],)).fetchone() or ["US"])[0] or "US"
                n = sources.store_items(c, [item], doc["agency_id"], ctry, doc["url"], "pi", suppliers)
                c.execute("UPDATE award SET confidence='D' WHERE source='pi' AND confidence='A'")
                added += 1 if n else 0
            if doc:
                c.execute("UPDATE award_doc SET note=coalesce(note,'') || ? WHERE id=?", (note, doc["id"]))
            c.commit()
            os.remove(p)
    finally:
        sources.HISTORY = old
    return read, added


def backfill(c, max_usd=None, per_link=40, verbose=False, max_pages=None):
    """One pass over award links not yet backfilled: the page itself, its older pages, earlier years and award PDFs,
    read locally (rules + review queue). Claude is used only if config award_backfill_usd is set above 0 (default 0).
    Returns (pages read, items found, new rows, cost)."""
    ensure(c)
    ensure_queue(c)
    max_usd = float(bc.settings().get("award_backfill_usd", 0) or 0) if max_usd is None else max_usd
    use_ai = max_usd > 0 and bool(bc.api_key())
    max_pages = max_pages or int(bc.settings().get("award_backfill_pages", 150))  # per run, so the daemon is not held up
    suppliers = sources.supplier_ids()
    pages = found = new = 0
    cost = 0.0
    rows = c.execute("SELECT l.agency_id, l.url, a.country FROM agency_link l LEFT JOIN agency a ON a.agency_id=l.agency_id "
                     "WHERE l.kind IN ('awards','closed','tabulations') AND l.backfilled IS NULL ORDER BY l.source='curated' DESC, l.score DESC").fetchall()
    old_hist = sources.HISTORY
    sources.HISTORY = True
    try:
        for r in rows:
            if (use_ai and cost >= max_usd) or pages >= max_pages:
                break
            targets = [r["url"]]
            if not is_pdf(r["url"]):
                try:
                    page, final = _get(r["url"])
                    targets += [u for u in _older_pages(page, final, per_link) if u != r["url"]]
                except Exception as e:
                    c.execute("UPDATE agency_link SET backfilled=?, backfill_pages=0, note=? WHERE agency_id=? AND url=?",
                              (bc.now(), f"backfill: {e}"[:300], r["agency_id"], r["url"]))
                    c.commit()
                    continue
            done = errs = 0
            for u in targets:
                if pages >= max_pages:
                    break
                if c.execute("SELECT 1 FROM award_doc WHERE url=?", (u,)).fetchone():
                    continue
                try:
                    text, final, how = _text(u)
                except Exception as e:
                    bc.log(f"award backfill: {u}: {e}")
                    errs += 1
                    continue
                time.sleep(1.0)
                pages += 1
                done += 1
                if use_ai and cost < max_usd and len(text) >= 200:
                    try:
                        out, k = bc.claude_json(sources.EXTRACT_SYSTEM, f"Agency: {r['agency_id']}\nPage: {final}\nPage kind: awards (older page)\n"
                                                f"Page text:\n{text[:40000]}", sources.EXTRACT_SCHEMA)
                        cost += k
                        found += len(out["items"])
                        new += sources.store_items(c, out["items"], r["agency_id"], r["country"] or "US", final, "page", suppliers)
                        c.commit()
                        continue
                    except Exception as e:
                        bc.log(f"award backfill: extraction failed for {u}: {e}")
                f, n = read_free(c, r["agency_id"], r["country"] or "US", final, text, how, suppliers)
                found += f
                new += n
                if verbose:
                    print(f"{r['agency_id']}: {u} ({how}, {len(text)} chars) -> {f} rows by rules, {n} new")
            if pages >= max_pages and targets and u != targets[-1]:
                c.commit()  # page cap reached mid-link: finish this link on the next run (pages already read are skipped)
                break
            if errs and not done:  # unreachable today (robots.txt 5xx, timeout): try again on a later run
                c.execute("UPDATE agency_link SET note=? WHERE agency_id=? AND url=?", (f"backfill: {errs} pages unreadable {bc.now()[:10]}", r["agency_id"], r["url"]))
            else:
                c.execute("UPDATE agency_link SET backfilled=?, backfill_pages=coalesce(backfill_pages,0)+? WHERE agency_id=? AND url=?",
                          (bc.now(), done, r["agency_id"], r["url"]))
            c.commit()
    finally:
        sources.HISTORY = old_hist
    return pages, found, new, cost


def load_review(c, path):
    """Award rows read by hand (in a Claude thread, no API) from queued award_doc texts: same CSV as load-past-rfps
    plus optional doc_url; marks those documents reviewed."""
    import contract_pages
    res = contract_pages.load_past_rfps(c, path, tag="awdoc")
    ensure_queue(c)
    for r in csv.DictReader(open(path, newline="", encoding="utf-8-sig")):
        if (r.get("doc_url") or "").strip():
            c.execute("UPDATE award_doc SET status='reviewed', reviewed=? WHERE url=?", (bc.now(), r["doc_url"].strip()))
    c.commit()
    return res


def tick(c, limit=40):
    """Daily: discover links for the next batch of agencies, then spend the backfill allowance. Logged in run_log."""
    started = bc.now()
    pr, pa = pi_consume(c)
    checked, links_found = discover(c, limit=limit)
    p, f, n, k = backfill(c)
    n += pa
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (started, bc.now(), "award portals", "done", links_found + f, n, k,
               f"discover: {checked} agencies checked, {links_found} award links; backfill: {p} pages read free, {f} rows by rules, {n} new; pi: {pr} results, {pa} awards"))
    c.commit()
    return checked, links_found, p, n, k


def report(c):
    ensure(c)
    rows = c.execute("SELECT a.agency_id, a.agency, s.checked, s.pages, s.error, "
                     "(SELECT group_concat(kind || ' ' || url, ' | ') FROM agency_link l WHERE l.agency_id=a.agency_id AND l.kind!='bids') links "
                     "FROM agency a LEFT JOIN agency_link_scan s ON s.agency_id=a.agency_id ORDER BY a.agency_id").fetchall()
    have = sum(1 for r in rows if r["links"])
    print(f"{have} of {len(rows)} agencies have an award or closed-solicitations link; "
          f"{sum(1 for r in rows if r['checked'])} checked")
    for r in rows:
        print(f"{r['agency_id']:14} {(r['checked'] or 'not checked')[:10]} {r['links'] or ('-- ' + (r['error'] or 'none found'))}"[:400])
