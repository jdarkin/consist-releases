"""1.8.21 (Justin 11-24): Admin > Operating expenses. What running Consist costs each month: hosting, mail, domains,
payment fees, social tools, code hosting, API services. Recurring items (monthly or yearly) plus one-off charges, all
entered by hand; nothing is pulled from a vendor and no paid integration is used.

Tables live in app.db and are separate from user data: opex_item (recurring) and opex_charge (one-off or a month's
actual amount for a recurring item, which then replaces the planned amount for that month).
Money is stored in cents. Months are 'YYYY-MM'. Yearly items count in their renewal month (cash view) and as 1/12 a
month in the monthly-equivalent view."""
import datetime

from . import db

CATEGORIES = ["Hosting", "Email", "Domains", "Payments", "Marketing and social", "Software and code", "API services",
              "Security", "Other"]
CYCLES = {"monthly": "Monthly", "yearly": "Yearly"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS opex_item (
  id INTEGER PRIMARY KEY, vendor TEXT NOT NULL, name TEXT NOT NULL, category TEXT DEFAULT 'Other',
  amount_cents INTEGER DEFAULT 0, cycle TEXT DEFAULT 'monthly', start_month TEXT, end_month TEXT,
  notes TEXT, confirmed INTEGER DEFAULT 0, created TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS opex_charge (
  id INTEGER PRIMARY KEY, month TEXT NOT NULL, vendor TEXT NOT NULL, name TEXT, category TEXT DEFAULT 'Other',
  amount_cents INTEGER DEFAULT 0, item_id INTEGER, notes TEXT, created TEXT);
CREATE INDEX IF NOT EXISTS opex_charge_month ON opex_charge (month);
"""

# Starting list (Justin can edit or delete any of these). Amounts from the IONOS invoice list read 11-13; the others
# are not known yet and start at $0 marked "amount not confirmed".
SEED = [
    ("IONOS", "VPS Linux M+ (server 74.208.37.200)", "Hosting", 14100, "yearly", "2026-10",
     "Invoice of $141.00 on Oct 24, 2026. Billing cycle not confirmed: if IONOS bills it monthly, change the cycle.", 0),
    ("IONOS", "Web Hosting Plus", "Hosting", 1400, "monthly", "2026-11", "$14.00 a month from Nov 2, 2026.", 1),
    ("IONOS", "MyDefender Starter", "Security", 250, "monthly", "2026-11", "$2.50 a month from Nov 3, 2026.", 1),
    ("IONOS", "Domain Security Pack", "Domains", 20000, "yearly", "2026-10", "$200.00 on Oct 4, 2026; looks yearly.", 0),
    ("IONOS", "Instant Domain", "Domains", 1100, "yearly", "2026-10", "$11.00 on Oct 26, 2026 (plus $3.00 on Oct 27).", 0),
    ("IONOS", "Mail Basic (5 mailboxes)", "Email", 0, "monthly", "2026-10", "Enter the monthly price from the IONOS invoice.", 0),
    ("Stripe", "Card processing fees", "Payments", 0, "monthly", "2026-11",
     "Varies with sales. Add each month's total from the Stripe dashboard as a charge.", 0),
    ("Make", "Social posting (LinkedIn, Bluesky)", "Marketing and social", 0, "monthly", "2026-11",
     "Enter the plan price, or leave at $0 on the free plan.", 0),
    ("GitHub", "Code and release hosting", "Software and code", 0, "monthly", "2026-10",
     "Enter the plan price, or leave at $0 on the free plan.", 0),
    ("Anthropic", "Claude API (AI analyst, Bid Catcher review)", "API services", 0, "monthly", "2026-10",
     "No paid API spend at present. Enter a charge for any month that has some.", 1),
]


def ensure():
    c = db.connect()
    try:
        c.executescript(SCHEMA)
        c.commit()
    finally:
        c.close()
    if db.settings().get("opex_seeded") != "1":
        now = db.now()
        if not db.q("SELECT 1 FROM opex_item LIMIT 1"):
            for v, n, cat, amt, cyc, start, note, conf in SEED:
                db.x("INSERT INTO opex_item (vendor, name, category, amount_cents, cycle, start_month, notes, confirmed, created, updated)"
                     " VALUES (?,?,?,?,?,?,?,?,?,?)", (v, n, cat, amt, cyc, start, note, conf, now, now))
        db.set_setting("opex_seeded", "1")


def cents(s):
    """'$1,234.50' or '12' -> cents; None if it isn't a number."""
    s = (s or "").replace("$", "").replace(",", "").strip()
    try:
        v = round(float(s) * 100)
    except ValueError:
        return None
    return v if 0 <= v < 10 ** 10 else None


def month_ok(m):
    try:
        datetime.date.fromisoformat((m or "") + "-01")
        return len(m) == 7
    except ValueError:
        return False


def this_month():
    return datetime.date.today().strftime("%Y-%m")


def months_back(n, end=None):
    y, m = map(int, (end or this_month()).split("-"))
    out = []
    for _ in range(n):
        out.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    return out[::-1]


def _active(it, month):
    return (it["start_month"] or "0000-00") <= month and (not it["end_month"] or it["end_month"] >= month)


def month_lines(month, items=None, charges=None):
    """Everything that counts in one month: [{vendor, name, category, cash, equiv, kind, item_id, charge_id}] in cents.
    cash = what is billed that month; equiv = monthly equivalent (yearly items spread over 12 months)."""
    items = items if items is not None else db.q("SELECT * FROM opex_item")
    charges = charges if charges is not None else db.q("SELECT * FROM opex_charge WHERE month = ?", (month,))
    charges = [c for c in charges if c["month"] == month]
    actual = {c["item_id"]: c for c in charges if c["item_id"]}
    out = []
    for it in items:
        if not _active(it, month):
            continue
        yearly = it["cycle"] == "yearly"
        due = (not yearly) or month[5:] == (it["start_month"] or month)[5:]
        if it["id"] in actual:
            c = actual[it["id"]]
            out.append(dict(vendor=it["vendor"], name=it["name"], category=it["category"], cash=c["amount_cents"],
                            equiv=c["amount_cents"] if not yearly else it["amount_cents"] // 12, kind="actual",
                            item_id=it["id"], charge_id=c["id"]))
        else:
            out.append(dict(vendor=it["vendor"], name=it["name"], category=it["category"],
                            cash=it["amount_cents"] if due else 0, equiv=it["amount_cents"] // 12 if yearly else it["amount_cents"],
                            kind="planned", item_id=it["id"], charge_id=None))
    for c in charges:
        if not c["item_id"] or c["item_id"] not in {it["id"] for it in items}:
            out.append(dict(vendor=c["vendor"], name=c["name"] or "", category=c["category"], cash=c["amount_cents"],
                            equiv=c["amount_cents"], kind="one-off", item_id=None, charge_id=c["id"]))
    return out


def summary(n=12, end=None):
    items = db.q("SELECT * FROM opex_item ORDER BY vendor, name")
    months = months_back(n, end)
    charges = db.q("SELECT * FROM opex_charge WHERE month >= ? AND month <= ?", (months[0], months[-1]))
    trend, vendors, cats = [], {}, {}
    for m in months:
        lines = month_lines(m, items, charges)
        trend.append(dict(month=m, cash=sum(x["cash"] for x in lines), equiv=sum(x["equiv"] for x in lines)))
        for x in lines:
            vendors.setdefault(x["vendor"], [0] * n)[months.index(m)] += x["cash"]
            cats[x["category"]] = cats.get(x["category"], 0) + x["cash"]
    run_rate = sum((it["amount_cents"] // 12 if it["cycle"] == "yearly" else it["amount_cents"])
                   for it in items if _active(it, this_month()))
    vend = sorted(({"vendor": v, "months": a, "total": sum(a)} for v, a in vendors.items()), key=lambda r: -r["total"])
    return dict(months=months, trend=trend, vendors=vend, cats=sorted(cats.items(), key=lambda kv: -kv[1]),
                run_rate=run_rate, recurring=items, unconfirmed=sum(1 for it in items if not it["confirmed"]))


def month_label(m):
    return datetime.date.fromisoformat(m + "-01").strftime("%b %Y")
