"""Spam protection for the Contact and "Did we miss something?" forms (1.8.23, Justin 11-24: "a lot of spam on the lead mailbox").
No paid services. Suspected spam is never emailed to the leads inbox: it is held in Admin > Leads > Held as spam with the
reason, where "Not spam" releases it (and sends the email) and Delete removes it.

Layers:
  1. Hidden trap field ("website"), hidden from people.
  2. Signed form time stamp (same as sign-up, app/signupguard.py): missing, forged, over a day old, or sent sooner than
     lead_min_secs (default 4) after the page loaded.
  3. Per-network limits: 5 per ten minutes (dropped, not stored) and lead_daily_ip (default 5) per day (held).
  4. Content checks: links (more than lead_max_links, default 1), a web address in the name or company, common spam
     phrases (SEO, backlinks, loans, crypto, casino and the like), mostly non-Latin text, throwaway email domains, and the
     same email sending the same message again within a day.
  5. Cloudflare Turnstile, when switched on for sign-up (Admin > Settings > Sign-up protection), also guards these forms."""
import re
import time

from . import auth, db, signupguard

DEFAULTS = {"lead_min_secs": "4", "lead_daily_ip": "5", "lead_max_links": "1"}
REASONS = {"trap": "Hidden trap field filled", "stamp": "Missing or bad form stamp", "fast": "Form sent too fast",
           "daily": "Over the daily limit for one network", "links": "Too many links", "urlname": "Web address in the name or company",
           "phrase": "Spam phrase", "script": "Mostly non-Latin text", "disposable": "Throwaway email domain",
           "repeat": "Same message sent again", "turnstile": "Failed the Turnstile check"}
URL_RE = re.compile(r"https?://|www\.|\b[a-z0-9-]+\.(?:com|net|org|ru|xyz|top|info|biz|io|co|shop|site|online)\b/?", re.I)
PHRASES = re.compile(r"\b(seo|backlinks?|guest post|rank(?:ing)? (?:your|on) (?:website|google)|first page of google|web ?traffic|"
                     r"lead generation services?|digital marketing (?:agency|services)|web ?design(?:ing)? services?|app development services?|"
                     r"crypto|bitcoin|forex|casino|betting|(?:business|personal|quick) loans?|viagra|cialis|porn|dating|onlyfans|telegram|whatsapp|"
                     r"unsubscribe|opt[- ]out|i (?:noticed|found) your (?:website|site)|increase (?:your )?sales|virtual assistant|"
                     r"cheap|discount code|click here|limited time|investment opportunity)\b", re.I)


def setting(s, k):
    return s.get(k, DEFAULTS.get(k, ""))


def _int(s, k):
    try:
        return max(0, int(setting(s, k) or 0))
    except ValueError:
        return int(DEFAULTS[k])


def _non_latin(text):
    letters = [c for c in text if c.isalpha()]
    return len(letters) >= 20 and sum(1 for c in letters if ord(c) > 0x24F) / len(letters) > 0.3


def check(request, form_stamp, trap, email, name, company, message, turnstile_token=""):
    """The reason key this message is held as spam, or None."""
    s = db.settings()
    ip = auth.client_ip(request)
    if trap:
        return "trap"
    age = signupguard._stamp_age(form_stamp)
    if age is None or age > 86400:
        return "stamp"
    if age < _int(s, "lead_min_secs"):
        return "fast"
    cap = _int(s, "lead_daily_ip")
    since = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - 86400))
    if cap and (db.q("SELECT count(*) n FROM lead WHERE ip = ? AND ts >= ?", (ip, since), one=True) or {"n": 0})["n"] >= cap:
        return "daily"
    if len(URL_RE.findall(message or "")) > _int(s, "lead_max_links"):
        return "links"
    if URL_RE.search(name or "") or URL_RE.search(company or ""):
        return "urlname"
    if PHRASES.search(" ".join((name or "", company or "", message or ""))):
        return "phrase"
    if _non_latin(message or ""):
        return "script"
    if signupguard.disposable(email):
        return "disposable"
    if db.q("SELECT 1 FROM lead WHERE lower(email) = lower(?) AND message = ? AND ts >= ?", (email, message, since), one=True):
        return "repeat"
    if signupguard.turnstile_ready(s) and not signupguard.turnstile_ok(turnstile_token, ip):
        return "turnstile"
    return None


def why(reason):
    return REASONS.get(reason or "", reason or "")


def held_count(days=30):
    r = db.q("SELECT count(*) n FROM lead WHERE status = 'spam' AND ts >= ?",
             (time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - days * 86400)),), one=True)
    return r["n"] if r else 0
