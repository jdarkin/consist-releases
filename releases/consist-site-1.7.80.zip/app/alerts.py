"""Saved-search email alerts. A background thread checks every 10 minutes: instant searches send whenever new notices match,
daily ones once a day, weekly ones on Mondays. Each search remembers the highest notice id it has already sent.
The same loop compares fleet records once a day (intel.detect_changes) and emails each user the changes on fleets they follow."""
import datetime
import html
import json
import logging
import threading
import time

from . import auth, config, data, db, intel, mailer

log = logging.getLogger("consist.alerts")


def due(s, now):
    last = s["last_sent"] or ""
    if s["frequency"] == "instant":
        return True
    if s["frequency"] == "daily":
        return last[:10] < now.date().isoformat() and now.hour >= 11  # 11:00 UTC = early morning in North America
    if s["frequency"] == "weekly":
        return now.weekday() == 0 and now.hour >= 11 and last[:10] < now.date().isoformat()
    return False


def matches(s, test=False):
    """test=True (1.7.79 Send test): the newest 10 matches whatever was already sent, so a test always shows real bids."""
    f = json.loads(s["query"] or "{}")
    f = {k: v for k, v in f.items() if k in ("q", "category", "country", "agency", "operator", "subsystem", "min_rel")}
    f["status"] = "all"
    f["after_id"] = 0 if test else (s["last_notice_id"] or 0)
    tok = None
    if json.loads(s["query"] or "{}").get("territory") == "1":  # 1.7.47: "only my territory", using the member's saved territory
        from . import lens, territory
        t = territory.for_user({"id": s["user_id"]})
        if territory.is_set(t):
            ops, ags = territory.resolve(t)
            tok = lens.set_current(lens.Scope(territory=(ops, ags, territory.label(t))))
    try:
        rows, _ = data.notices(f, per=10 if test else 50)
    finally:
        if tok is not None:
            from . import lens
            lens.reset(tok)
    return rows


def render(site, s, rows, test=False):
    lines = [f"{len(rows)} new rail bid{'s' if len(rows) != 1 else ''} match your search \"{s['name']}\".", ""]
    if test:
        lines = [TEST_NOTE_BID.format(n=len(rows), name=s["name"]), ""]
    items = []
    srcs = sources(rows)
    for n in rows:
        close = f" | closes {n['closing']}" if n.get("closing") else ""
        src_label, src_url = srcs.get(n["notice_id"], (None, None))
        # 1.7.33: a French or Spanish notice leads with its English machine translation (bids-push22), original title below;
        # the original alone until the translation lands.
        main, orig = (n.get("title_en"), n["title"]) if n.get("title_en") else (n["title"], None)
        lines.append(f"- {main} ({n['agency']}{close})" + (f"\n  Original: {orig}" if orig else "") + f"\n  {config.SITE_URL}/app/bids/{n['notice_id']}"
                     + (f"\n  {src_label}: {src_url}" if src_url else ""))
        items.append(f"<li style='margin:0 0 12px'><a href='{config.SITE_URL}/app/bids/{n['notice_id']}' style='color:#0b6b5d;font-weight:600'>"
                     f"{html.escape(main or '')}</a>"
                     + (f"<br><span style='color:#5c6670;font-size:12px'>{html.escape(orig)} (original; English is a machine translation)</span>" if orig else "")
                     + f"<br><span style='color:#5c6670;font-size:13px'>{html.escape(n['agency'] or '')}{html.escape(close)}"
                     f"</span><br><span style='font-size:13px'>{html.escape(n.get('restricted_note') or n.get('summary') or '')}</span>"
                     + (f"<br><a href='{html.escape(src_url)}' style='color:#0b6b5d;font-size:13px'>{html.escape(src_label)} ↗</a>" if src_url else "")
                     + "</li>")
    lines += ["", f"Manage alerts: {config.SITE_URL}/app/alerts"]
    body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} bid alert: "
            f"{html.escape(s['name'])}</h2>{_test_banner(lines[0]) if test else ''}<ul style='padding-left:18px'>{''.join(items)}</ul><p style='font-size:12px;color:#5c6670'>"
            f"<a href='{config.SITE_URL}/app/alerts'>Manage alerts</a></p></div>")
    return "\n".join(lines), body


def sources(rows):
    """1.7.80 (Justin 11-19): {notice_id: (label, url)} linking each bid to its original source at the agency: the posting itself
    when we have its page, else the agency's bidding portal (agency_link / agency.portal_url). Only http(s) links."""
    import re
    ok = lambda u: (u or "").strip() if re.match(r"(?i)^https?://", (u or "").strip()) else ""  # noqa: E731
    out, need = {}, []
    for n in rows:
        u = ok(n.get("url"))
        if u:
            out[n["notice_id"]] = ("Original posting on the agency site", u)
        elif n.get("agency_id"):
            need.append(n)
    if need:
        try:
            links = data.agency_links([n["agency_id"] for n in need])
        except Exception as e:
            log.warning("agency links for alert failed: %s", e)
            links = {}
        for n in need:
            bids = [x for x in links.get(n["agency_id"], []) if x["kind"] == "bids" and ok(x["url"])]
            if bids:
                out[n["notice_id"]] = (f"{n.get('agency') or 'Agency'} bidding portal", ok(bids[0]["url"]))
    return out


def run_once():
    now = datetime.datetime.now(datetime.timezone.utc)
    site = db.settings().get("site_name", "Consist")
    sent = 0
    for s in db.q("SELECT s.*, u.email FROM saved_search s JOIN user u ON u.id = s.user_id WHERE s.frequency != 'off' AND u.status = 'active'"):
        u = auth.load_user(s["user_id"])
        if not u:
            continue
        if not u.bids:  # a fleet-only plan has no bid monitoring
            continue
        if s["frequency"] == "instant" and not u.can("alerts_instant"):
            continue
        if not due(s, now):
            continue
        rows = matches(s)
        top = max([n["notice_id"] for n in rows], default=s["last_notice_id"] or 0)
        if rows:
            text, body = render(site, s, rows)
            try:
                mailer.send(s["email"], f"{site}: {len(rows)} new rail bid{'s' if len(rows) != 1 else ''} for \"{s['name']}\"", text, body, alerts=True, optional=True)
                sent += 1
            except Exception as e:
                log.error("alert to %s failed: %s", s["email"], e)
                continue
        if rows or s["frequency"] != "instant":
            db.x("UPDATE saved_search SET last_sent = ?, last_notice_id = ? WHERE id = ?", (now.isoformat(), top, s["id"]))
    return sent


def fleet_due(freq, last, now):
    if freq == "daily":
        return last[:10] < now.date().isoformat() and now.hour >= 11
    if freq == "weekly":
        return now.weekday() == 0 and now.hour >= 11 and last[:10] < now.date().isoformat()
    return False


def render_fleet(site, events, test=False):
    lines = [f"{len(events)} change{'s' if len(events) != 1 else ''} to fleets you follow.", ""]
    if test:
        lines = [TEST_NOTE_FLEET.format(n=len(events)), ""]
    items = []
    for e in events:
        fl = e.get("fleet") or {}
        name = f"{fl.get('operator_name', e['operator_id'])}: {fl.get('manufacturer') or ''} {fl.get('model_name', '')}".strip()
        url = f"{config.SITE_URL}/app/fleets/{e['fleet_id']}"
        lines.append(f"- {name}\n  {e['detail']}\n  {url}")
        items.append(f"<li style='margin:0 0 12px'><a href='{url}' style='color:#0b6b5d;font-weight:600'>{html.escape(name)}</a><br>"
                     f"<span style='font-size:13px'>{html.escape(e['detail'] or '')}</span></li>")
    lines += ["", f"Change how often you get these: {config.SITE_URL}/app/updates"]
    body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} fleet updates</h2>"
            f"{_test_banner(lines[0]) if test else ''}<ul style='padding-left:18px'>{''.join(items)}</ul><p style='font-size:12px;color:#5c6670'>"
            f"<a href='{config.SITE_URL}/app/updates'>Fleet update settings</a></p></div>")
    return "\n".join(lines), body


def run_fleet_changes():
    """Once a day: record fleet changes, then send each user's digest when it is due."""
    now = datetime.datetime.now(datetime.timezone.utc)
    st = db.settings()
    if (st.get("fleet_detect_last") or "")[:10] < now.date().isoformat():
        n = intel.detect_changes()
        db.set_setting("fleet_detect_last", now.isoformat())
        log.info("fleet change scan: %s events", n)
    site = st.get("site_name", "Consist")
    sent = 0
    for r in db.q("SELECT id, email FROM user WHERE status = 'active'"):
        u = auth.load_user(r["id"])
        if not u or not u.can("fleet_alerts"):
            continue
        freq = intel.pref(u, "fleet_email", "weekly")
        last = intel.pref(u, "fleet_email_last")
        if last is None:  # start from now so the first digest is not every change on record
            intel.set_pref(u, "fleet_email_last", now.isoformat())
            continue
        if not fleet_due(freq, last, now):
            continue
        events = intel.events_for_user(u, since=last, limit=60)
        if events:
            text, body = render_fleet(site, events)
            try:
                mailer.send(r["email"], f"{site}: {len(events)} fleet update{'s' if len(events) != 1 else ''}", text, body, optional=True)
                sent += 1
            except Exception as e:
                log.error("fleet digest to %s failed: %s", r["email"], e)
                continue
        intel.set_pref(u, "fleet_email_last", now.isoformat())
    return sent


# ---------- 1.7.79: Send test (Justin 11-19) ----------
TEST_NOTE_BID = ("This is a test of your alert \"{name}\". It shows the {n} newest bids that match it today, including ones you "
                 "may have seen. Real alerts only include bids that are new since the last email.")
TEST_NOTE_FLEET = ("This is a test of your fleet updates. It shows the {n} most recent changes (last 30 days) that fit your settings. "
                   "Real emails only include changes since the last one.")
_last_test = {}


def _test_banner(note):
    return (f"<p style='background:#fff6dd;border:1px solid #e8d48a;padding:8px 10px;font-size:13px;color:#5c4a00'>"
            f"{html.escape(note)}</p>")


def test_wait(key):
    """Seconds before this member may send another test of this alert (one a minute, so the button can't flood an inbox)."""
    return max(0, int(60 - (time.time() - _last_test.get(key, 0))))


def _test_mark(key):
    _last_test[key] = time.time()


def send_test_bid(u, sid):
    """Emails the member what this saved search would send, right now. Returns (ok, message for the page)."""
    s = db.q("SELECT * FROM saved_search WHERE id = ? AND user_id = ?", (sid, u["id"]), one=True)
    if not s:
        return False, "That saved search wasn't found."
    if not mailer.configured():
        return False, "Email sending isn't configured on this server yet, so the test couldn't be sent."
    key = (u["id"], "bid", sid)
    if test_wait(key):
        return False, f"Please wait {test_wait(key)} seconds before sending another test of this alert."
    from . import unsub
    if unsub.is_out(u["email"]):
        return False, f"{u['email']} has unsubscribed from alert emails, so nothing can be sent. Use the unsubscribe link in any earlier alert email and press Resubscribe."
    site = db.settings().get("site_name", "Consist")
    rows = matches(s, test=True)
    _test_mark(key)
    if rows:
        text, body = render(site, s, rows, test=True)
        subj = f"[Test] {site}: {len(rows)} rail bid{'s' if len(rows) != 1 else ''} for \"{s['name']}\""
    else:
        text = (f"This is a test of your alert \"{s['name']}\". No bids on record match it right now, so a real alert would not "
                f"send anything yet. Widen the search if you expected matches.\n\nManage alerts: {config.SITE_URL}/app/alerts")
        body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} bid alert: "
                f"{html.escape(s['name'])}</h2>{_test_banner(text.split(chr(10))[0])}<p style='font-size:12px'>"
                f"<a href='{config.SITE_URL}/app/alerts'>Manage alerts</a></p></div>")
        subj = f"[Test] {site}: no current matches for \"{s['name']}\""
    try:
        ok = mailer.send(u["email"], subj, text, body, alerts=True, optional=True)
    except Exception as e:
        log.error("test alert to %s failed: %s", u["email"], e)
        return False, "The test email couldn't be sent. The mail server refused it; please try again later."
    if ok is False:
        return False, "The test email couldn't be sent."
    return True, (f"Test sent to {u['email']} with the {len(rows)} newest matching bid{'s' if len(rows) != 1 else ''}." if rows
                  else f"Test sent to {u['email']}. No bids match this search right now, so the email says so.")


def send_test_fleet(u):
    """Emails the member a fleet update digest built from their current settings, using the last 30 days of changes."""
    if not mailer.configured():
        return False, "Email sending isn't configured on this server yet, so the test couldn't be sent."
    key = (u["id"], "fleet")
    if test_wait(key):
        return False, f"Please wait {test_wait(key)} seconds before sending another test."
    from . import unsub
    if unsub.is_out(u["email"]):
        return False, f"{u['email']} has unsubscribed from alert emails, so nothing can be sent. Use the unsubscribe link in any earlier alert email and press Resubscribe."
    site = db.settings().get("site_name", "Consist")
    since = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=30)).isoformat()
    events = intel.events_for_user(u, since=since, limit=25)
    _test_mark(key)
    if events:
        text, body = render_fleet(site, events, test=True)
        subj = f"[Test] {site}: {len(events)} fleet update{'s' if len(events) != 1 else ''}"
    else:
        text = ("This is a test of your fleet updates. No fleet changes in the last 30 days fit your settings, so a real email "
                f"would not send anything yet. Follow more fleets or widen your settings.\n\nFleet update settings: {config.SITE_URL}/app/updates")
        body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} fleet updates</h2>"
                f"{_test_banner(text.split(chr(10))[0])}<p style='font-size:12px'><a href='{config.SITE_URL}/app/updates'>Fleet update settings</a></p></div>")
        subj = f"[Test] {site}: no recent fleet updates"
    try:
        ok = mailer.send(u["email"], subj, text, body, optional=True)
    except Exception as e:
        log.error("test fleet digest to %s failed: %s", u["email"], e)
        return False, "The test email couldn't be sent. The mail server refused it; please try again later."
    if ok is False:
        return False, "The test email couldn't be sent."
    return True, (f"Test sent to {u['email']} with {len(events)} recent fleet change{'s' if len(events) != 1 else ''}." if events
                  else f"Test sent to {u['email']}. No fleet changes in the last 30 days fit your settings, so the email says so.")


def start():
    if not config.ALERTS_ENABLED:
        return

    def loop():
        time.sleep(30)
        while True:
            try:
                run_once()
            except Exception as e:
                log.error("alert run failed: %s", e)
            try:
                run_fleet_changes()
            except Exception as e:
                log.error("fleet change run failed: %s", e)
            try:
                from . import ep724
                ep724.refresh()  # 1.7.63: STB EP 724 weekly freight service data, checked once a day
            except Exception as e:
                log.error("EP 724 refresh failed: %s", e)
            try:
                from . import supplierdir
                if supplierdir.monthly_due():
                    supplierdir.reconcile_rssi()  # monthly RSSI member-list reconciliation (Admin > Supplier directory)
            except Exception as e:
                log.error("supplier directory RSSI check failed: %s", e)
            time.sleep(600)
    threading.Thread(target=loop, daemon=True).start()


def baseline(search_id):
    """New searches start from the newest notice so the first email is not a flood of old bids."""
    r = db.bq("SELECT max(notice_id) m FROM notice", one=True)
    db.x("UPDATE saved_search SET last_notice_id = ? WHERE id = ?", ((r["m"] if r else 0) or 0, search_id))
