"""Builds and deploys (Admin > Builds and deploys, Justin 11-12): what is running on production and staging and when it went in.

consist-stage.sh, consist-promote.sh, bids-stage.sh and bids-promote.sh append one JSON line per run to deploys.jsonl next to
fleet.db on the server (/opt/fleet-db-docker/data, seen here as /fleetdata). Each line:
  {"t": "2026-11-12T14:30:00Z", "kind": "site" | "bids", "env": "staging" | "production" | "check", "name": "consist-site-1.7.37.zip",
   "version": "1.7.37", "sha": "<sha256 of the zip>", "image": "sha256:...", "image_created": "...", "ok": true, "note": "..."}
The page only reads the file; nothing here writes to it."""
import datetime
import json
import os

from . import config

LOG = os.environ.get("DEPLOY_LOG") or os.path.join(os.path.dirname(config.FLEET_DB), "deploys.jsonl")
KINDS = {"site": "Website (consist-site)", "bids": "Bid Catcher"}
ENVS = {"production": "Production", "staging": "Staging", "check": "Checked (bids-stage)"}


def read(limit=500):
    """Deploy records, newest first. Bad lines are skipped."""
    out = []
    try:
        with open(LOG, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if isinstance(r, dict) and r.get("kind") and r.get("t"):
                    out.append(r)
    except OSError:
        return []
    out.sort(key=lambda r: str(r.get("t")), reverse=True)
    return out[:limit]


def current(rows):
    """(kind, env) -> the latest successful record, i.e. what is in place there now."""
    cur = {}
    for r in rows:
        if r.get("ok") is False:
            continue
        cur.setdefault((r.get("kind"), r.get("env")), r)
    return cur


def last_try(rows):
    """(kind, env) -> the latest record whatever its result (to flag a failed promote after a good one)."""
    out = {}
    for r in rows:
        out.setdefault((r.get("kind"), r.get("env")), r)
    return out


def _mtime(path):
    try:
        return datetime.datetime.fromtimestamp(os.path.getmtime(path), datetime.timezone.utc).isoformat(timespec="seconds")
    except OSError:
        return None


def running():
    """Facts about the copy serving this page."""
    from . import syslog
    started = datetime.datetime.fromtimestamp(syslog.STARTED, datetime.timezone.utc).isoformat(timespec="seconds")
    return {"version": config.VERSION, "env": "staging" if os.environ.get("STAGING") == "1" else "production", "started": started,
            "fleet_db": _mtime(config.FLEET_DB), "bids_db": _mtime(config.BIDS_DB), "log": LOG, "log_found": os.path.exists(LOG)}


def view():
    rows = read()
    return {"rows": rows, "cur": current(rows), "last": last_try(rows), "run": running(), "KINDS": KINDS, "ENVS": ENVS}


def _et_offset(d):
    """US Eastern offset for a UTC time (EDT from 2 AM on the 2nd Sunday of March to 2 AM on the 1st Sunday of November);
    worked out here because the slim image has no time zone database."""
    y = d.year
    mar = datetime.datetime(y, 3, 8 + (6 - datetime.date(y, 3, 8).weekday()) % 7, 7, tzinfo=datetime.timezone.utc)
    nov = datetime.datetime(y, 11, 1 + (6 - datetime.date(y, 11, 1).weekday()) % 7, 6, tzinfo=datetime.timezone.utc)
    return -4 if mar <= d < nov else -5


def et(t):
    """'Nov 12, 2026 9:30 AM ET' from an ISO UTC time."""
    if not t:
        return "—"
    try:
        d = datetime.datetime.fromisoformat(str(t).replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=datetime.timezone.utc)
        d = d.astimezone(datetime.timezone.utc)
        return (d + datetime.timedelta(hours=_et_offset(d))).strftime("%b %-d, %Y %-I:%M %p ET")
    except Exception:
        return str(t)
