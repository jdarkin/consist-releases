"""Rail cost and fuel indexes: STB/AAR Rail Cost Adjustment Factor (quarterly), AAR monthly railroad fuel price index,
and the STB EP 661 quarterly fuel cost / surcharge reports of each Class I. Seeds in seed/ (built by tools/stb/fuel)."""
import contextvars, csv, gzip, os

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEED = os.path.join(HERE, "seed")
CREDIT = ("Rail Cost Adjustment Factor: STB Ex Parte 290 (Sub-No. 5) decisions, computed by the Association of American Railroads. "
          "Fuel price index: AAR Monthly Railroad Fuel Price Indexes. Fuel cost and surcharge revenue: Class I quarterly reports to the STB (EP 661).")
# STB fuel report filer -> R-1 railroad id. Soo Line and KCS filed separately until 2023, together from 2024, as CPKC from 2026.
FILER = {"BNSF": "BNSF", "UP": "UNION_PACIFIC", "CSX": "CSX", "NS": "NORFOLK_SOUTHERN", "GTC": "CN_RAIL",
         "SOO": "CPKC", "KCS": "CPKC", "SOO-KCSR": "CPKC", "CPKC": "CPKC"}
DEF = {
    "rcaf_unadj": ("RCAF (unadjusted)", "Rail Cost Adjustment Factor before productivity: the quarterly change in railroad input prices (labor, fuel, materials, equipment rents, depreciation, interest, other), 4Q2022 = 1.000. Set by the STB each quarter from the AAR All-Inclusive Index."),
    "rcaf_adj": ("RCAF (adjusted)", "RCAF divided by the productivity adjustment factor (5-year average railroad productivity gain). Used for rate escalation where productivity gains are passed through."),
    "rcaf5": ("RCAF-5", "RCAF adjusted with the STB's alternative productivity factor (PAF-5)."),
    "forecast_error": ("Forecast error adjustment", "Correction applied two quarters later for the difference between the forecast and actual All-Inclusive Index."),
    "fuel_idx": ("AAR fuel price index", "Average price railroads paid for diesel fuel, including taxes, transport and handling, as an index (July 15, 1990 = 100). AAR, monthly; quarterly and annual values are averages of the months."),
    "fuel_cost": ("Fuel cost", "Total cost of locomotive fuel for freight, yard and work trains in the quarter, as reported to the STB (EP 661), $ thousands as filed."),
    "gallons": ("Gallons consumed", "Total gallons of locomotive fuel consumed, thousands of gallons."),
    "per_gal": ("Fuel cost per gallon", "Fuel cost / gallons consumed: what the railroad actually paid per gallon."),
    "fsc_revenue": ("Fuel surcharge revenue", "Fuel surcharges billed on all traffic in the quarter, $ thousands as filed with the STB."),
    "fsc_regulated": ("Surcharge revenue, regulated traffic", "Fuel surcharge revenue on traffic subject to STB rate regulation (not under contract or exempt)."),
    "recovery": ("Surcharge recovery", "Fuel surcharge revenue / fuel cost. Above 100% means surcharges brought in more than fuel cost; railroads set surcharges to recover the change in fuel price above a strike price, so 100% is not the target."),
    "fsc_per_gal": ("Surcharge per gallon", "Fuel surcharge revenue / gallons consumed."),
    "fsc_share": ("Surcharge share of revenue", "Fuel surcharge revenue for the year / R-1 operating revenues (Sched. 210)."),
    "net_fuel": ("Net fuel cost", "Fuel cost minus fuel surcharge revenue: the fuel bill shippers did not pay through surcharges."),
    "cost_change": ("Change in fuel cost", "Increase or decrease in fuel cost versus the same quarter a year earlier, as reported to the STB."),
    "deflator": ("Rail cost deflator", "Factor that restates a year's dollars in the latest full year's railroad input prices: average RCAF (unadjusted) of 2025 / average of the year, so figures read as 2025 rail-cost dollars. Used by the 'Rail cost index' option."),
}

_basis = contextvars.ContextVar("consist_deflator", default="cpi")  # cpi | rcaf


def set_basis(b):
    return _basis.set(b if b in ("cpi", "rcaf") else "cpi")


def basis():
    return _basis.get()


def _read(name):
    p = os.path.join(SEED, name)
    if not os.path.exists(p):
        return []
    with gzip.open(p, "rt", newline="") as f:
        return list(csv.DictReader(f))


def _f(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return None if x != x else x


_cache = {}


def _c(k, fn):
    if k not in _cache:
        _cache[k] = fn()
    return _cache[k]


def rcaf():
    return _c("rcaf", lambda: [dict(year=int(r["year"]), quarter=int(r["quarter"]), **{k: _f(v) for k, v in r.items() if k not in ("year", "quarter")})
                               for r in _read("rcaf.csv.gz")])


def fuel_monthly():
    return _c("fm", lambda: [dict(year=int(r["year"]), month=int(r["month"]), idx=_f(r["idx_1990"])) for r in _read("aar_fuel_monthly.csv.gz")])


def fuel_quarterly():
    def f():
        g = {}
        for r in fuel_monthly():
            g.setdefault((r["year"], (r["month"] - 1) // 3 + 1), []).append(r["idx"])
        return {k: sum(v) / len(v) for k, v in g.items() if len(v) == 3}
    return _c("fq", f)


def fuel_annual():
    def f():
        g = {}
        for r in fuel_monthly():
            g.setdefault(r["year"], []).append(r["idx"])
        return {k: sum(v) / len(v) for k, v in g.items() if len(v) == 12}
    return _c("fa", f)


def rcaf_annual():
    def f():
        g = {}
        for r in rcaf():
            if r["rcaf_unadj"]:
                g.setdefault(r["year"], []).append(r["rcaf_unadj"])
        return {k: sum(v) / len(v) for k, v in g.items() if len(v) == 4}
    return _c("ra", f)


BASE_YEAR = 2025  # same base year as the CPI factors in the locomotive data (cpi_to_2025)


def deflator(y, to=BASE_YEAR):
    """Multiply year-y dollars by this to get them in year `to` railroad input prices (average RCAF, unadjusted)."""
    a = rcaf_annual()
    return a[to] / a[y] if y in a and to in a else None


def fsc():
    """Quarterly EP 661 rows by R-1 railroad id (Soo Line and KCS summed)."""
    def f():
        g = {}
        for r in _read("stb_fuel_surcharge.csv.gz"):
            op = FILER.get(r["rr"])
            if not op:
                continue
            k = (op, int(r["year"]), int(r["quarter"]))
            d = g.setdefault(k, dict(op=op, year=k[1], quarter=k[2], fuel_cost=0, gallons=0, cost_change=0, fsc_revenue=0, fsc_regulated=0))
            for c in ("fuel_cost", "gallons", "cost_change", "fsc_revenue", "fsc_regulated"):
                d[c] += _f(r[c]) or 0
        return [_derive(v) for _, v in sorted(g.items())]
    return _c("fsc", f)


def _derive(d):
    d = dict(d)
    fc, gl, rv = d["fuel_cost"], d["gallons"], d["fsc_revenue"]
    d["per_gal"] = fc / gl if gl else None
    d["fsc_per_gal"] = rv / gl if gl else None
    d["recovery"] = 100 * rv / fc if fc else None
    d["net_fuel"] = fc - rv
    return d


def fsc_annual():
    def f():
        g = {}
        for r in fsc():
            k = (r["op"], r["year"])
            d = g.setdefault(k, dict(op=r["op"], year=r["year"], n=0, fuel_cost=0, gallons=0, cost_change=0, fsc_revenue=0, fsc_regulated=0))
            d["n"] += 1
            for c in ("fuel_cost", "gallons", "cost_change", "fsc_revenue", "fsc_regulated"):
                d[c] += r[c]
        return {k: _derive(v) for k, v in g.items() if v["n"] == 4}
    return _c("fsca", f)


def lag_table(op=None):
    """Quarter-on-quarter change in fuel price index vs in surcharge per gallon, same quarter and one quarter later."""
    fq = fuel_quarterly()
    rows = [r for r in fsc() if op is None or r["op"] == op]
    by = {}
    for r in rows:
        by.setdefault((r["year"], r["quarter"]), []).append(r)
    ks = sorted(by)
    out = []
    for i, k in enumerate(ks):
        g = by[k]
        gl = sum(x["gallons"] for x in g)
        spg = sum(x["fsc_revenue"] for x in g) / gl if gl else None
        ppg = sum(x["fuel_cost"] for x in g) / gl if gl else None
        out.append(dict(year=k[0], quarter=k[1], fuel_idx=fq.get(k), per_gal=ppg, fsc_per_gal=spg))
    return out
