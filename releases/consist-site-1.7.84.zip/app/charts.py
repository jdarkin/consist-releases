"""Small server-rendered SVG charts (no JavaScript needed). Colors come from CSS variables so they follow light and dark themes."""
import html

SERIES = ["var(--c1)", "var(--c2)", "var(--c3)", "var(--c4)", "var(--c5)"]


def _fmt(v):
    if v is None:
        return ""
    if abs(v) >= 1e9:
        return f"{v / 1e9:.1f}B"
    if abs(v) >= 1e6:
        return f"{v / 1e6:.1f}M"
    if abs(v) >= 1e3:
        return f"{v / 1e3:.0f}k"
    return f"{v:.2f}".rstrip("0").rstrip(".") if isinstance(v, float) else str(v)


def autorange(lo, hi, n=4):
    """Y axis bounds that fit the data shown (Justin, 2026-11-02: line charts auto-range to the selected data, not from zero): the data's
    min and max with a little padding, widened to round gridline steps. Data that never goes below zero keeps a floor of zero."""
    import math
    if lo is None or hi is None:
        return 0, 1
    span = hi - lo
    pad = span * 0.06 if span else (abs(hi) * 0.05 or 1)
    a, b = lo - pad, hi + pad
    if lo >= 0 and a < 0:
        a = 0
    raw = (b - a) / n
    mag = 10 ** math.floor(math.log10(raw)) if raw > 0 else 1
    best = None
    for m in (1, 1.2, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10, 12, 15, 20):  # the tightest round grid that still covers the data
        step = m * mag
        y0 = round(math.floor(a / step) * step, 9)
        if lo >= 0 and y0 < 0:
            y0 = 0
        if y0 + n * step >= b and (best is None or n * step < best[1] - best[0]):
            best = (y0, round(y0 + n * step, 9))
    return best or (a, b)


def line(series, w=640, h=220, prefix="", title="", xtip=None, ymin=None, ymax=None, pick=True):
    """series: [(label, [(x, y) or (x, y, href), ...]), ...] with numeric x. A point with an href links to its drill-down;
    every point carries a hover card (data-tip) with its series, x and value. pick: a From/To year picker over the chart."""
    series = [(lab, [tuple(p) + (None,) * (3 - len(p)) for p in s]) for lab, s in series]
    rr = year_range([p[0] for _, s in series for p in s if p[1] is not None], pick and ymin is None and ymax is None)
    if rr:
        series = [(lab, [p for p in s if in_range(p[0], rr)]) for lab, s in series]
        return range_wrap(_line(series, w, h, prefix, title, xtip, ymin, ymax), rr)
    return _line(series, w, h, prefix, title, xtip, ymin, ymax)


def _line(series, w=640, h=220, prefix="", title="", xtip=None, ymin=None, ymax=None):
    pts = [(x, y) for _, s in series for x, y, _h in s if y is not None]
    if not pts:
        return ""
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    x0, x1 = min(xs), max(xs)
    y0, y1 = autorange(min(ys), max(ys))
    if ymin is not None:  # a typed axis (service metrics explorer) overrides the automatic range
        y0 = ymin
    if ymax is not None and ymax > y0:
        y1 = ymax
    if y1 <= y0:
        y1 = y0 + 1
    L, R, T, B = 46, 12, 12, 26

    def sx(x):
        return L + (x - x0) / ((x1 - x0) or 1) * (w - L - R)

    def sy(y):
        return T + (1 - (y - y0) / (y1 - y0)) * (h - T - B)
    out = [f'<svg viewBox="0 0 {w} {h}" class="chart" role="img" aria-label="{html.escape(title)}">']
    for i in range(5):
        v = y0 + (y1 - y0) * i / 4
        y = sy(v)
        out.append(f'<line x1="{L}" x2="{w - R}" y1="{y:.1f}" y2="{y:.1f}" class="grid"/>'
                   f'<text x="{L - 6}" y="{y + 4:.1f}" class="ax" text-anchor="end">{prefix}{_fmt(v)}</text>')
    step = max(1, round((x1 - x0) / 8))
    x = x0
    while x <= x1:
        out.append(f'<text x="{sx(x):.1f}" y="{h - 8}" class="ax" text-anchor="middle">{int(x)}</text>')
        x += step
    def xl(x):
        if xtip:
            return xtip(x)
        return f"{int(x)} Q{round((x - int(x)) * 4) + 1}" if abs(x - round(x)) > 1e-6 else str(int(x))
    for i, (label, s) in enumerate(series):
        s = [(x, y, hr) for x, y, hr in s if y is not None]
        if not s:
            continue
        d = " ".join(f"{'M' if j == 0 else 'L'}{sx(x):.1f},{sy(y):.1f}" for j, (x, y, _h) in enumerate(s))
        col = SERIES[i % len(SERIES)]
        out.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="2.25" stroke-linejoin="round"/>')
        for x, y, hr in s:
            tip = html.escape(f"{label}, {xl(x)}\n{prefix}{_fmt(y)}" + ("\nClick to drill in" if hr else ""))
            c = f'<circle cx="{sx(x):.1f}" cy="{sy(y):.1f}" r="{4 if hr else 3}" fill="{col}" data-tip="{tip}"/>'
            out.append(f'<a href="{html.escape(hr)}">{c}</a>' if hr else c)
    out.append("</svg>")
    legend = "".join(f'<span><i style="background:{SERIES[i % len(SERIES)]}"></i>{html.escape(l)}</span>' for i, (l, _) in enumerate(series))
    return "".join(out) + (f'<div class="legend">{legend}</div>' if len(series) > 1 else "")


def bars(items, prefix="", suffix="", max_items=12):
    """items: [(label, value, sublabel)] -> horizontal bar list (HTML, not SVG, so labels wrap on phones)."""
    items = [i for i in items if i[1]][:max_items]
    if not items:
        return ""
    top = max(i[1] for i in items) or 1
    rows = []
    for it in items:
        label, v, sub = it[:3]
        href = it[3] if len(it) > 3 else None  # optional 4th item: the row links to this drill-down
        tag, attr = ("a", f' href="{html.escape(str(href))}"') if href else ("div", "")
        rows.append(f'<{tag} class="hbar{" link" if href else ""}"{attr}><div class="hbar-l"><b>{html.escape(str(label))}</b>'
                    f'{f"<small>{html.escape(str(sub))}</small>" if sub else ""}</div>'
                    f'<div class="hbar-t"><span style="width:{max(2, 100 * v / top):.1f}%"></span></div>'
                    f'<div class="hbar-v">{prefix}{_fmt(v)}{suffix}</div></{tag}>')
    return '<div class="hbars">' + "".join(rows) + "</div>"


def stacked_hbars(items, keys, prefix="", max_items=14):
    """items: [{label, usd, sub, href, segs: [(key, value, href)]}] -> horizontal bars split into colored segments (the first
    len(keys) keys get the series colors, a trailing 'other' segment is grey), each with a hover card. HTML, so labels wrap."""
    items = [i for i in items if i["usd"]][:max_items]
    if not items:
        return ""
    top = max(i["usd"] for i in items) or 1
    rows = []
    for it in items:
        segs = []
        for j, (k, v, href) in enumerate(it["segs"]):
            if not v:
                continue
            color = SERIES[j % len(SERIES)] if j < len(keys) else "var(--muted);opacity:.45"
            tip = html.escape(f"{it['label']}\n{k}: {prefix}{_fmt(v)} ({100 * v / it['usd']:.0f}%)" + ("\nClick to drill in" if href else ""))
            tag, attr = ("a", f' href="{html.escape(href)}"') if href else ("span", ' tabindex="0"')
            segs.append(f'<{tag}{attr} style="width:{100 * v / it["usd"]:.2f}%;background:{color}" data-tip="{tip}" aria-label="{html.escape(str(k))}"></{tag}>')
        bar = "".join(segs) or f'<span style="width:100%;background:var(--brand)"></span>'
        lab = (f'<a href="{html.escape(it["href"])}"><b>{html.escape(str(it["label"]))}</b></a>' if it.get("href")
               else f'<b>{html.escape(str(it["label"]))}</b>')
        sub = f"<small>{html.escape(str(it['sub']))}</small>" if it.get("sub") else ""
        rows.append(f'<div class="hbar"><div class="hbar-l">{lab}{sub}</div>'
                    f'<div class="hbar-t stack"><div style="width:{max(2, 100 * it["usd"] / top):.1f}%">{bar}</div></div>'
                    f'<div class="hbar-v">{prefix}{_fmt(it["usd"])}</div></div>')
    return '<div class="hbars">' + "".join(rows) + "</div>"


def stacked(years, keys, labels, w=640, h=220, href=None, sel=None):
    """years: {year: {key: value}} -> stacked columns.
    href(year, key) gives a link for each segment (key None: the whole year, from its label); sel = (year, key) marks the
    current selection. Linked charts get data-y / data-k attributes so app.js can filter the list below in place."""
    if not years:
        return ""
    ys = sorted(years)
    # bars start at zero (a cut-off bar misstates its size); the top fits the tallest stack on a round grid (Justin, 2026-11-03)
    top = autorange(0, max(sum(years[y].get(k, 0) or 0 for k in keys) for y in ys) or 1)[1] or 1
    if all(isinstance(v, int) for y in ys for v in years[y].values() if v is not None) and top % 4:
        top = -(-int(top) // 4) * 4 if top >= 1 else 4  # whole-number data (counts, cars) gets whole-number gridlines
    L, R, T, B = 40, 8, 10, 26
    bw = (w - L - R) / len(ys)
    out = [f'<svg viewBox="0 0 {w} {h}" class="chart" role="img" aria-label="by year">']
    for i in range(5):
        v = top * i / 4
        y = T + (1 - v / top) * (h - T - B)
        out.append(f'<line x1="{L}" x2="{w - R}" y1="{y:.1f}" y2="{y:.1f}" class="grid"/><text x="{L - 6}" y="{y + 4:.1f}" class="ax" text-anchor="end">{_fmt(v)}</text>')
    for i, yr in enumerate(ys):
        x = L + i * bw + bw * 0.18
        base = h - B
        for j, k in enumerate(keys):
            v = years[yr].get(k, 0) or 0
            hh = v / top * (h - T - B)
            if hh > 0:
                rect = (f'<rect x="{x:.1f}" y="{base - hh:.1f}" width="{bw * 0.64:.1f}" height="{hh:.1f}" rx="2" fill="{SERIES[j % len(SERIES)]}">'
                        f'<title>{yr} {html.escape(labels.get(k, k))}: {_fmt(v)}{" · click to list them" if href else ""}</title></rect>')
                if href:
                    on = " on" if sel and str(sel[0]) == str(yr) and sel[1] in (k, None) else ""
                    rect = f'<a href="{html.escape(str(href(yr, k)))}" class="seg{on}" data-y="{yr}" data-k="{html.escape(str(k))}">{rect}</a>'
                out.append(rect)
                base -= hh
        label = f'<text x="{x + bw * 0.32:.1f}" y="{h - 8}" class="ax" text-anchor="middle">{yr}</text>'
        if href:
            on = " on" if sel and str(sel[0]) == str(yr) and sel[1] is None else ""
            label = f'<a href="{html.escape(str(href(yr, None)))}" class="seg yr{on}" data-y="{yr}" data-k="">{label}</a>'
        out.append(label)
    out.append("</svg>")
    if href:
        out[0] = out[0].replace('class="chart"', f'class="chart linked{" has-sel" if sel else ""}"')
    legend = "".join(f'<span><i style="background:{SERIES[j % len(SERIES)]}"></i>{html.escape(labels.get(k, k))}</span>' for j, k in enumerate(keys))
    return "".join(out) + f'<div class="legend">{legend}</div>'


# ---- period picker for time-series charts (Justin, 2026-11-03: the user picks the years on every time-series chart) ----
import contextvars as _cv
_req = _cv.ContextVar("consist_chart_req", default=None)  # {"q": query params, "n": charts drawn so far in this request}


def begin(query):
    """Called per request (main.py) so each chart on a page gets a stable id and reads its own ?rcN=YYYY-YYYY range."""
    _req.set({"q": dict(query), "n": 0})


def year_range(xs, pick=True):
    """For x values in years: (id, first year, last year, from, to), or None when the chart spans under 3 years or has no picker."""
    st = _req.get()
    if not pick or st is None or not xs:
        return None
    lo, hi = int(min(xs)), int(max(xs))
    if lo < 1900 or hi - lo < 3:
        return None
    st["n"] += 1
    cid = f"rc{st['n']}"
    a, b = lo, hi
    v = st["q"].get(cid, "")
    if "-" in v:
        try:
            a, b = (int(x) for x in v.split("-", 1))
        except ValueError:
            a, b = lo, hi
    a, b = max(lo, min(a, hi)), max(lo, min(b, hi))
    if b < a:
        a, b = b, a
    return (cid, lo, hi, a, b)


def in_range(x, rr):
    return rr is None or rr[3] <= x < rr[4] + 1


def range_wrap(body, rr):
    if rr is None:
        return body
    cid, lo, hi, a, b = rr
    return (f'<div class="chart-range" id="{cid}" data-cid="{cid}" data-min="{lo}" data-max="{hi}" data-a="{a}" data-b="{b}">'
            + body + "</div>")
