"""Cost benchmarks slicer (/app/costs): the whole passenger costing dataset, filterable on every dimension it carries and
grouped by any one or two of them.

Two levels:
  operator  operator x mode x year from the NTD (operator_cost_trend), 2015 onward, with the operator's peer-group dimensions
            from lcc_operator (size band, traction, service type, climate zone)
  fleet     fleet-level 2025 estimates (v_fleet_profile: NTD cost allocated to each fleet by car-miles and vehicle class)
Filters are repeated query params (?mode=HR&mode=LR&size=large). Each option shows how many rows it would leave given the
other filters, so the slicer never offers an empty choice without saying so."""
import statistics
from urllib.parse import urlencode

from . import data, lens
from .intel import _rows

LEVELS = {"operator": "Operator and mode (NTD, by year)", "fleet": "Fleet (2025 estimate)"}

METRICS = {
    "operator": [
        ("vm_per_car_rev_mile", "Vehicle maintenance per car revenue mile", "$"),
        ("opex_per_car_rev_mile", "Operating cost per car revenue mile", "$"),
        ("vo_per_car_rev_mile", "Vehicle operations per car revenue mile", "$"),
        ("opex_per_car_rev_hour", "Operating cost per car revenue hour", "$"),
        ("opex_per_passenger_mile", "Operating cost per passenger mile", "$"),
        ("opex_per_trip", "Operating cost per trip", "$"),
        ("vm_per_peak_car", "Vehicle maintenance per peak car", "$"),
        ("farebox_recovery", "Farebox recovery", "%x"),
        ("delta_vs_peer_pct", "Opex per car mile vs national mode median", "%"),
        ("yoy_change_pct", "Opex per car mile, change on prior year", "%"),
        ("change_vs_2019_pct", "Opex per car mile, change since 2019", "%"),
    ],
    "fleet": [
        ("maint_cost_per_car_mile", "Maintenance per car mile", "$"),
        ("maint_cost_per_car_year", "Maintenance per car per year", "$"),
        ("opex_per_car_mile", "Operating cost per car mile", "$"),
        ("opex_per_seat_mile", "Operating cost per seat mile", "$"),
        ("opex_per_passenger_mile", "Operating cost per passenger mile", "$"),
        ("delta_vs_benchmark_pct", "Maintenance vs class benchmark", "%"),
        ("est_annual_miles_per_car", "Miles per car per year", ""),
    ],
}

SIZE = {"small": "Small", "medium": "Medium", "large": "Large", "very_large": "Very large"}


def _title(v):
    return str(v).replace("_", " ").replace("-", " ").capitalize() if v else "Not classified"


def _mode(r):
    m = data.MODE_ALIASES.get(r["ntd_mode"], r["ntd_mode"])
    return m


def _states(r):
    return [s.strip() for s in (r.get("states") or "").replace(",", ";").split(";") if s.strip()] or ["Not recorded"]


def _propulsion(r):
    p = (r.get("propulsion") or "").lower()
    for key, label in (("dual", "Dual-mode"), ("battery", "Battery-electric"), ("diesel", "Diesel"), ("cable", "Cable-hauled"),
                       ("unpowered", "Unpowered"), ("electric", "Electric")):
        if key in p:
            return label
    return "Not recorded"


def _decade(r):
    y = r.get("build_year")
    return f"{int(y) // 10 * 10}s" if y else "Not recorded"


def _age(r):
    y = r.get("build_year")
    if not y:
        return "Not recorded"
    a = 2025 - int(y)
    return "Under 10 years" if a < 10 else "10 to 19 years" if a < 20 else "20 to 29 years" if a < 30 else "30 years or more"


def _rebuilt(r):
    return "Rebuilt or overhauled" if r.get("last_rebuild_year") else "Never rebuilt"


# (key, label, value function -> str or list of str, label function for a value)
_COMMON = [
    ("mode", "Mode", _mode, lambda v: data.MODES.get(v, v)),
    ("country", "Country", lambda r: r.get("country") or "US", lambda v: lens.REGIONS.get(v, v)),
    ("state", "State or province", _states, str),
    ("category", "Operator type", lambda r: r.get("category") or "", _title),
    ("size", "System size", lambda r: r.get("size_band") or "", lambda v: SIZE.get(v, _title(v))),
    ("traction", "Traction", lambda r: r.get("traction") or "", _title),
    ("service", "Service type", lambda r: r.get("service_type") or "", _title),
    ("climate", "Climate zone", lambda r: r.get("climate_zone") or "", _title),
    ("operator", "Operator", lambda r: r["operator_id"], None),
]
DIMS = {
    "operator": _COMMON,
    "fleet": _COMMON[:-1] + [
        ("vclass", "Vehicle class", lambda r: r.get("vehicle_class") or "", lambda v: data.CLASSES.get(v, _title(v))),
        ("propulsion", "Propulsion", _propulsion, str),
        ("builder", "Builder", lambda r: r.get("manufacturer") or "Not recorded", str),
        ("decade", "Build decade", _decade, str),
        ("age", "Fleet age", _age, str),
        ("rebuilt", "Rebuild history", _rebuilt, str),
        _COMMON[-1],
    ],
}


def _dataset(level):
    sc = lens.current()
    w, a = sc.sql("t.ntd_mode" if level == "operator" else "p.ntd_mode", "o.country", territory=False)  # 1.7.45: peer benchmarks stay national
    # an operator's peer-group dimensions from its latest LCC row
    dims = ("LEFT JOIN (SELECT l.operator_id, l.size_band, l.traction, l.service_type, l.climate_zone FROM lcc_operator l "
            "JOIN (SELECT operator_id, max(report_year) y FROM lcc_operator GROUP BY operator_id) m "
            "ON m.operator_id = l.operator_id AND m.y = l.report_year) d USING (operator_id)")
    if level == "fleet":
        return _rows("SELECT p.*, f.qty_active AS cars, o.operator_name, o.country, o.states, o.category, d.size_band, d.traction, "
                     f"d.service_type, d.climate_zone FROM v_fleet_profile p JOIN operator o USING (operator_id) JOIN fleet f USING (fleet_id) {dims} "
                     f"WHERE {w} AND coalesce(p.include_in_national_count, 1) = 1", a)
    return _rows("SELECT t.*, o.operator_name, o.country, o.states, o.category, d.size_band, d.traction, d.service_type, d.climate_zone "
                 f"FROM operator_cost_trend t JOIN operator o USING (operator_id) {dims} WHERE {w} "
                 "ORDER BY t.operator_id, t.ntd_mode, t.report_year", a)


def _vals(fn, r):
    v = fn(r)
    v = v if isinstance(v, list) else [v]
    return [x if x not in (None, "") else "" for x in v]


def _q(vals):
    vals = sorted(vals)
    if len(vals) < 4:
        return vals[0], vals[-1]
    q = statistics.quantiles(vals, n=4)
    return q[0], q[2]


def parse(request):
    qp = request.query_params
    level = qp.get("level") if qp.get("level") in LEVELS else "operator"
    keys = {d[0] for d in DIMS[level]}
    sel = {k: [v for v in qp.getlist(k) if v != ""] for k in keys}
    sel = {k: v for k, v in sel.items() if v}
    metrics = dict((m[0], m) for m in METRICS[level])
    metric = qp.get("metric") if qp.get("metric") in metrics else METRICS[level][0][0]
    by = qp.get("by") if qp.get("by") in keys else "mode"
    then = qp.get("then") if qp.get("then") in keys and qp.get("then") != by else ""
    year = qp.get("year") or "latest"
    return {"level": level, "sel": sel, "metric": metric, "by": by, "then": then, "year": year}


def view(p):
    level, sel, metric, by, then = p["level"], p["sel"], p["metric"], p["by"], p["then"]
    dims = DIMS[level]
    rows = [r for r in _dataset(level)]
    names = {r["operator_id"]: r["operator_name"] for r in rows}
    labels = {d[0]: (d[3] or (lambda v: names.get(v, v))) for d in dims}
    fns = {d[0]: d[2] for d in dims}
    for r in rows:
        r["_d"] = {k: _vals(fn, r) for k, fn in fns.items()}

    years = sorted({r["report_year"] for r in rows if r.get("report_year")}) if level == "operator" else []
    if level == "operator":
        if p["year"] != "latest" and p["year"].isdigit() and int(p["year"]) in years:
            snap = [r for r in rows if r["report_year"] == int(p["year"])]
        else:
            last = {}
            for r in rows:
                if r.get(metric) is not None:
                    last[(r["operator_id"], r["ntd_mode"])] = r
            snap = list(last.values())
    else:
        snap = rows

    def keep(r, skip=None):
        return all(any(v in want for v in r["_d"][k]) for k, want in sel.items() if k != skip)

    # slicer options with counts given the other filters
    facets = []
    for k, label, fn, _ in dims:
        counts = {}
        for r in snap:
            if r.get(metric) is None or not keep(r, k):
                continue
            for v in set(r["_d"][k]):
                counts[v] = counts.get(v, 0) + 1
        for v in sel.get(k, []):
            counts.setdefault(v, 0)
        opts = sorted(counts.items(), key=lambda kv: (kv[0] == "", -kv[1], str(labels[k](kv[0]) if kv[0] else "")))
        facets.append({"key": k, "label": label, "on": sel.get(k, []),
                       "opts": [(v, labels[k](v) if v != "" else "Not classified", n, v in sel.get(k, [])) for v, n in opts]})

    hits = [r for r in snap if r.get(metric) is not None and keep(r)]

    def seg_keys(r):
        a = r["_d"][by]
        b = r["_d"][then] if then else [None]
        return [(x, y) for x in set(a) for y in set(b)]

    def seg_label(key):
        x, y = key
        lx = labels[by](x) if x != "" else "Not classified"
        return lx if y is None else f"{lx} · {labels[then](y) if y != '' else 'Not classified'}"

    groups = {}
    for r in hits:
        for key in seg_keys(r):
            groups.setdefault(key, []).append(r)
    unit = dict((m[0], m[2]) for m in METRICS[level])[metric]
    segments = []
    base = {k: v for k, v in sel.items()}
    for key, rs in groups.items():
        vals = [r[metric] for r in rs]
        lo, hi = _q(vals)
        seg = {"key": key, "label": seg_label(key), "n": len(rs), "ops": len({r["operator_id"] for r in rs}),
               "median": statistics.median(vals), "p25": lo, "p75": hi, "min": min(vals), "max": max(vals),
               "mean": statistics.fmean(vals)}
        if level == "fleet":
            w = [(r[metric], r.get("cars") or 0) for r in rs]
            tot = sum(c for _, c in w)
            seg["cars"] = tot
            seg["wmean"] = sum(v * c for v, c in w) / tot if tot else None
        drill = {**base, by: [key[0]]}
        if then:
            drill[then] = [key[1]]
        seg["href"] = qs(p, sel=drill, by=then or by, then="")
        segments.append(seg)
    segments.sort(key=lambda s: -s["median"])

    # trend: median by year for the six biggest segments (operator level)
    trend = []
    if level == "operator":
        top = sorted(segments, key=lambda s: -s["n"])[:6]
        for s in top:
            ys = {}
            for r in rows:
                if r.get(metric) is None or not keep(r) or s["key"] not in seg_keys(r):
                    continue
                ys.setdefault(r["report_year"], []).append(r[metric])
            pts = [(y, round(statistics.median(v) * (100 if unit == "%x" else 1), 2)) for y, v in sorted(ys.items())]
            if len(pts) > 1:
                trend.append((s["label"][:40], pts))

    vals = [r[metric] for r in hits]
    overall = {"n": len(hits), "ops": len({r["operator_id"] for r in hits}),
               "median": statistics.median(vals) if vals else None, "p25": _q(vals)[0] if vals else None, "p75": _q(vals)[1] if vals else None}
    active = []
    for fc in facets:
        for v, lab, _, on in fc["opts"]:
            if on:
                rest = {k: [x for x in vs if not (k == fc["key"] and x == v)] for k, vs in sel.items()}
                active.append((fc["label"], lab, qs(p, sel={k: vs for k, vs in rest.items() if vs})))
    hits.sort(key=lambda r: -(r[metric] or 0))
    for r in hits:
        r.pop("_d", None)
    bars = [(s["label"], s["median"] * (100 if unit == "%x" else 1), f"{s['n']} row{'s' if s['n'] != 1 else ''}", "/app/costs?" + s["href"])
            for s in segments if s["median"] and s["median"] > 0]
    return {"bars": bars, "facets": facets, "active": active, "segments": segments, "trend": trend, "rows": hits, "overall": overall, "years": years,
            "unit": unit, "metric_label": dict((m[0], m[1]) for m in METRICS[level])[metric], "cdy": (rows[0].get("constant_dollar_year") if rows else None),
            "dims": [(d[0], d[1]) for d in dims], "metrics": METRICS[level]}


def qs(p, **over):
    """Query string for this view with some parts replaced (sel replaces all filters)."""
    q = {**p, **over}
    items = [("level", q["level"]), ("metric", q["metric"]), ("by", q["by"])]
    if q.get("then"):
        items.append(("then", q["then"]))
    if q["level"] == "operator" and q.get("year") and q["year"] != "latest":
        items.append(("year", q["year"]))
    for k, vs in q["sel"].items():
        items += [(k, v) for v in vs]
    return urlencode(items)


def export_rows(v, level):
    if level == "fleet":
        cols = ["fleet_id", "operator_id", "operator_name", "country", "states", "ntd_mode", "manufacturer", "model_name", "vehicle_class",
                "propulsion", "build_year", "last_rebuild_year", "cars", "size_band", "traction", "service_type", "climate_zone"] + \
               [m[0] for m in METRICS["fleet"]]
    else:
        cols = ["operator_id", "operator_name", "country", "states", "category", "ntd_mode", "report_year", "size_band", "traction",
                "service_type", "climate_zone"] + [m[0] for m in METRICS["operator"]] + ["peer_median_opex_per_car_rev_mile", "constant_dollar_year"]
    return cols, v["rows"]
