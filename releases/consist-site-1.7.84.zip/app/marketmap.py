"""1.7.76 market map (Justin 11-18): a Marimekko chart on Market share. Each column is a segment, as wide as its total; the stack
shows each supplier's share of it; a click on a block opens its details. Two views: installed base (active cars: car builders and
each mapped subsystem, from intel.market) and rail awards (USD, last five years, by award category, from bids.db)."""
import json
from urllib.parse import quote

from . import data, lens

TOP = 12  # suppliers sent per column (the chart names the top 6 in the overview, all 12 when zoomed); the rest pooled as Other


def _cols(items, top=TOP):
    out = []
    for key, label, total, sups, link in items:
        if not total:
            continue
        sups = sorted([s for s in sups if s[1] > 0], key=lambda s: -s[1])
        blocks = [{"n": n, "v": round(v), "x": x} for n, v, x in sups[:top]]
        rest = sum(v for _, v, _ in sups[top:])
        if rest > 0:
            blocks.append({"n": "Other", "v": round(rest), "x": {"count": len(sups) - top}, "o": 1})
        out.append({"k": key, "l": label, "t": round(total), "b": blocks, "link": link})
    return sorted(out, key=lambda c: -c["t"])


def builders(cls=None, mode=None):
    """Car builders by vehicle type: one column per vehicle class, stacks = builders' active cars."""
    from . import intel
    cols = {}
    for fl in intel.snapshot().values():
        if (cls and fl["vehicle_class"] != cls) or (mode and data.MODE_ALIASES.get(fl["ntd_mode"], fl["ntd_mode"]) != mode):
            continue
        c = cols.setdefault(fl["vehicle_class"] or "other", {})
        b = c.setdefault(fl["manufacturer"] or "Unknown", [0, 0, set()])
        b[0] += fl["qty_active"] or 0
        b[1] += 1
        b[2].add(fl["operator_id"])
    return _cols([(k, data.cls_label(k), sum(v[0] for v in c.values()),
                   [(n, v[0], {"fleets": v[1], "ops": len(v[2]), "href": f"/app/market/drill?by=builder&name={quote(str(n))}&cls={quote(k)}"})
                    for n, v in c.items()], f"/app/market?cls={quote(k)}") for k, c in cols.items()])


def installed(m, components, fq=""):
    items = []
    for k, sub in m["subs"].items():
        items.append((k, components.get(k, k), sub["cars"], [(n, v, {"href": f"/app/market/drill?by=supplier&comp={k}&name={quote(str(n))}{fq}"})
                      for n, v in sub["suppliers"]], f"/app/market?sub={k}"))
    return _cols(items)


def awards(years=5):
    sc = lens.current()
    w, a = "1=1", []
    if sc.territory:
        w, a = sc.ter_sql("operator_id", "agency_id")
    rows = data._bq_safe("SELECT coalesce(category, 'other') cat, vendor, vendor_norm, count(*) n, sum(amount_usd) usd FROM award "
                         f"WHERE relevance >= 50 AND coalesce(vendor, '') != '' AND amount_usd > 0 AND award_date >= date('now', ?) AND {w} "
                         "GROUP BY 1, 3", [f"-{int(years)} years"] + a)
    cats = {}
    for r in rows:
        cats.setdefault(r["cat"], []).append((r["vendor"], r["usd"] or 0, {"count": r["n"],
                                              "href": f"/app/awards?category={quote(r['cat'])}&vendor={quote(r['vendor_norm'] or '')}"}))
    return _cols([(c, data.CATEGORIES.get(c, c.replace("_", " ").capitalize()), sum(v for _, v, _ in s), s, f"/app/awards?category={quote(c)}")
                  for c, s in cats.items()])


SVC_KINDS = {"om": "Operations and maintenance", "operations": "Train operations", "maintenance": "Vehicle and systems maintenance",
             "mow": "Track, signal and way maintenance", "overhaul": "Fleet overhaul", "concession": "Concessions (P3)", "facility": "Facility maintenance"}


def services():
    """1.7.84 (Justin 11-19): service contracts by kind, sized by annual value (NTD contracted-service payments, or a researched
    contract's value spread over its term). Contracts with no published value are counted but not sized."""
    from . import db, om
    sc = lens.current()
    names = {o["operator_id"]: o for o in om._rows("SELECT operator_id, operator_name, country FROM operator")}
    cols = {}
    for r in db.q(f"SELECT * FROM fleet_contract WHERE kind IN ({','.join('?' * len(SVC_KINDS))})", list(SVC_KINDS)):
        c = dict(r)
        country = (names.get(c["operator_id"]) or {}).get("country") or "US"
        if (sc.regions and country not in sc.regions) or not sc.in_territory(c["operator_id"]):
            continue
        yrs = None
        s0, e0 = om._date(c.get("start_date")), om._date(c.get("end_date"))
        if s0 and e0 and e0 > s0:
            yrs = (e0 - s0).days / 365.25
        v = c.get("annual_usd") or ((c.get("value_usd") or 0) / yrs if yrs else (c.get("value_usd") or 0) / om.TERM_YEARS.get(c["kind"], 5))
        b = cols.setdefault(c["kind"], {}).setdefault(c.get("vendor") or "Unknown", [0, 0, set()])
        b[0] += v or 0
        b[1] += 1
        b[2].add((names.get(c["operator_id"]) or {}).get("operator_name") or c["operator_id"])
    return _cols([(k, SVC_KINDS[k], sum(v[0] for v in c.values()),
                   [(n, v[0], {"count": v[1], "ops": len(v[2]), "agencies": sorted(v[2])[:8], "href": "/app/work?view=om"}) for n, v in c.items()],
                   "/app/work?view=om") for k, c in cols.items()])


def blob(m, components, fq, with_awards, cls=None, mode=None):
    d = {"installed": installed(m, components, fq), "builders": builders(cls, mode)}
    try:
        d["services"] = services()
    except Exception:
        d["services"] = []
    if with_awards:
        d["awards"] = awards()
    return json.dumps(d).replace("</", "<\\/")
