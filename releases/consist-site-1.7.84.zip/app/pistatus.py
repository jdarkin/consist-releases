"""Pi reader status (1.7.68, Justin 11-18: "a status module of pi server activity on the admin dashboard"). The Raspberry Pi
reader (pi-reader thread) syncs job files with /opt/fleet-db-docker/data/pi-jobs on the VPS, which the site sees read-only at
/fleetdata/pi-jobs (env PI_JOBS_DIR overrides). Bid Catcher writes jobs to inbox/; the Pi writes results to outbox/ (Bid Catcher
reads and removes them), status.json after every run and, from the Pi side's history update, history.json with its last 7 days
of jobs: {"jobs": [{"id", "t", "ok", "secs"}]}. status.json may also carry "host": {"ram_pct", "load1", "temp_c", "disk_pct"}.
Everything here reads files only and copes with any of them missing."""
import datetime
import glob
import json
import os

from . import config

ONLINE_SECS = 3900  # runs every 15 min: an hour without a check-in is offline
CYCLE = 900  # Pi cron */15


def folder():
    return os.environ.get("PI_JOBS_DIR") or os.path.join(os.path.dirname(config.FLEET_DB), "pi-jobs")


def _load(p):
    try:
        with open(p) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _ts(v):
    try:
        t = datetime.datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return t if t.tzinfo else t.replace(tzinfo=datetime.timezone.utc)
    except (TypeError, ValueError):
        return None


def _ago(secs):
    if secs is None:
        return "never"
    if secs < 90:
        return "just now"
    if secs < 5400:
        return f"{round(secs / 60)} min ago"
    if secs < 172800:
        return f"{round(secs / 3600)} h ago"
    return f"{round(secs / 86400)} days ago"


def status():
    """{'state': 'not linked' | 'offline' | 'online', 'seen', 'ago', 'model', 'processed', 'waiting', 'results', 'today', 'week',
    'failed_today', 'failed_week', 'avg_secs', 'last_error', 'host', 'history'}."""
    d = folder()
    if not os.path.isdir(d):
        return {"state": "not linked", "folder": d}
    now = datetime.datetime.now(datetime.timezone.utc)
    out = {"state": "offline", "folder": d, "waiting": len(glob.glob(os.path.join(d, "inbox", "*.json"))),
           "results": len(glob.glob(os.path.join(d, "outbox", "*.json"))), "ago": "never"}
    st = _load(os.path.join(d, "status.json")) or {}
    t = _ts(st.get("t"))
    if t:
        age = (now - t).total_seconds()
        out.update(seen=t.isoformat(), ago=_ago(age), state="online" if age <= ONLINE_SECS else "offline")
        # 1.7.71 (Justin 11-18): the Pi runs on cron */15, so the next run is the next quarter hour; a check-in older than one
        # cycle plus 5 minutes of run time means a run was missed
        q = now.replace(second=0, microsecond=0)
        nxt = q + datetime.timedelta(minutes=15 - q.minute % 15)
        out.update(next_run=nxt.isoformat(), overdue=age > CYCLE + 300, due_since=(t + datetime.timedelta(seconds=CYCLE + 300)).isoformat())
    out.update(model=st.get("model"), processed=st.get("processed_this_run"), host=st.get("host") if isinstance(st.get("host"), dict) else None)
    hist = _load(os.path.join(d, "history.json"))
    jobs = hist.get("jobs") if isinstance(hist, dict) else hist if isinstance(hist, list) else None
    if isinstance(jobs, list):
        day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
        wk0 = now - datetime.timedelta(days=7)
        rows = [(j, _ts(j.get("t"))) for j in jobs if isinstance(j, dict)]
        today = [j for j, jt in rows if jt and jt >= day0]
        week = [j for j, jt in rows if jt and jt >= wk0]
        secs = [float(j["secs"]) for j in week if j.get("ok") and isinstance(j.get("secs"), (int, float))]
        bad = [(j, jt) for j, jt in rows if jt and jt >= wk0 and not j.get("ok")]
        out.update(history=True, today=len(today), week=len(week), failed_today=sum(1 for j in today if not j.get("ok")),
                   failed_week=len(bad), avg_secs=round(sum(secs) / len(secs)) if secs else None,
                   last_error=(max(bad, key=lambda x: x[1])[0].get("error") or "")[:200] if bad else None)
    return out
