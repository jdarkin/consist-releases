"""Freight Analytics Portal (admin only): STB R-1 for every Class I railroad, CY2020 onward, by major asset class. See r1assets.py.
Lives under /admin/freight and uses the admin shell, so visitors and members get a 404 (auth.require_admin)."""
from fastapi import APIRouter, Depends, HTTPException, Request

from . import auth, r1assets as R
from .main import render
from .routes_app import csv_response

router = APIRouter(prefix="/admin/freight")
A = Depends(auth.require_admin)
EXPORT_COLS = ["module", "metric", "label", "operator_id", "railroad", "year", "value", "unit", "definition"]


def _year(request):
    ys = R.years()
    try:
        y = int(request.query_params.get("y") or 0)
    except ValueError:
        y = 0
    return y if y in ys else (ys[-1] if ys else None)


@router.get("")
def home(request: Request, u=A):
    return module(request, "overview", u)


@router.get("/m/{mod}")
def module(request: Request, mod: str, u=A):
    if mod not in R.MODULES:
        raise HTTPException(404)
    if request.query_params.get("export"):
        return csv_response("consist-freight-r1", EXPORT_COLS, R.export_rows())
    y = _year(request)
    md = R.MODULES[mod]
    ch = request.query_params.get("m") or md["chart"]
    if ch not in R.M:
        ch = md["chart"]
    ctx = dict(user=u, R=R, mod=mod, md=md, y=y, ch=ch)
    if y:
        rows, tot = R.grid(md["table"], y)
        ctx.update(tiles=R.tiles(mod, y), rows=rows, tot=tot, chart=R.line_chart(ch),
                   mix=R.mix(md["mix"][1], y) if md.get("mix") else None, mix2=R.mix(md["mix2"][1], y) if md.get("mix2") else None,
                   chart_keys=[k for k in md["table"] + md["tiles"] if k in R.M],
                   statements=[(t, [dict(key=k, label=R.M[k]["label"], tot=R.fmt(k, R.class1(k, y)),
                                         cells=[dict(show=R.fmt(k, R.value(k, o, y)), href=R.link(k, o, y)) for o in R.ids()]) for k in ks])
                               for t, ks in md.get("statements", [])])
    return render(request, "admin/r1_module.html", **ctx)


@router.get("/metric/{key}")
def metric(request: Request, key: str, u=A):
    if key not in R.M:
        raise HTTPException(404)
    op = request.query_params.get("rr")
    op = op if op in R.RAILROADS else None
    y = _year(request)
    m = R.M[key]
    ys = R.years()
    grid = [dict(op=o, label=R.RAILROADS[o][0], cells=[dict(y=yy, show=R.fmt(key, R.value(key, o, yy)), href=R.link(key, o, yy)) for yy in ys],
                 cagr=R.cagr(key, o)) for o in R.ids()]
    tot = [dict(y=yy, show=R.fmt(key, R.class1(key, yy))) for yy in ys]
    sel = None
    if op and y:
        sel = dict(op=op, y=y, label=R.RAILROADS[op][0], show=R.fmt(key, R.value(key, op, y)), inputs=R.inputs(key, op, y), sources=R.sources(op, y))
    return render(request, "admin/r1_metric.html", user=u, R=R, key=key, m=m, ys=ys, grid=grid, tot=tot, sel=sel, op=op, y=y,
                  mod=m.get("module", "overview"), chart=R.line_chart(key, op, y))


@router.get("/about")
def about(request: Request, u=A):
    import collections
    cov = collections.defaultdict(dict)
    for (o, y), d in R._cells()["cells"].items():
        cov[o][y] = len(d)
    return render(request, "admin/r1_about.html", user=u, R=R, cov=cov, mod="about")
