"""Maintenance mode: when the admin switch is on, every visitor gets the maintenance page (503) and admins keep the whole site.
Must sit inside SessionMiddleware so it can see who is signed in."""
import time

from starlette.requests import Request

from . import auth, db

# Always reachable: admins sign in through /admin, Stripe keeps posting webhooks, and the health check keeps Docker happy.
OPEN = ("/static", "/healthz", "/admin", "/stripe/webhook", "/robots.txt", "/logout", "/login", "/unsubscribe")
_cache = {"t": 0.0, "on": False}


def on():
    if time.monotonic() - _cache["t"] > 5:  # read the switch at most every 5 seconds
        try:
            _cache["on"] = db.settings().get("maintenance_on") == "1"
        except Exception:
            _cache["on"] = False
        _cache["t"] = time.monotonic()
    return _cache["on"]


def reset():
    _cache["t"] = 0.0


class MaintenanceMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not on() or scope["path"].startswith(OPEN):
            return await self.app(scope, receive, send)
        uid = (scope.get("session") or {}).get("uid")
        u = auth.load_user(uid) if uid else None
        if u and u.is_admin:
            return await self.app(scope, receive, send)
        from .main import render
        resp = render(Request(scope, receive), "public/maintenance.html", status=503, user=None)
        resp.headers["Retry-After"] = "1800"
        resp.headers["Cache-Control"] = "no-store"
        await resp(scope, receive, send)
