"""The AI analyst: Claude answers questions about the fleet and bid data by running read-only SQL, then returns a structured answer.
Two entry points share one tool loop: ask() for free-form questions and brief() for a bid fit brief on one notice."""
import json
import sqlite3
import threading
import time
import uuid

import anthropic

from . import config, data, db, freightai

PRICE_IN, PRICE_OUT, PRICE_CACHE_READ, PRICE_CACHE_WRITE = 4.0, 20.0, 0.20, 5.0  # USD per million tokens (Opus 5.5)
MAX_TURNS = 10
MAX_ROWS = 80

FLEET_TABLES = ["operator", "v_fleet_profile", "v_fleet_national", "fleet_duty_cycle", "fleet_opex_estimate", "overhaul_projection",
                "operator_cost_trend", "seed_subsystem", "fleet_subsystem", "supplier", "seed_procurement", "v_fleet_electrification",
                "fleet_lcc", "vehicle_model"]
BIDS_TABLES = ["agency", "notice", "award", "bid_tab"]
AWARD_TABLES = {"award", "bid_tab", "v_award_by_vendor", "v_award_share_by_category", "v_award_by_agency", "v_award_price_trend", "v_competition"}

_schema_cache = {}


def schema_text(passenger=True, freight=False):
    key = (passenger, freight)
    if key in _schema_cache:
        return _schema_cache[key]
    out = []
    for name, tables, conn in ((("fleet", FLEET_TABLES, db.fleet()), ("bids", BIDS_TABLES, db.bids())) if passenger else ()):
        if conn is None:
            continue
        out.append(f"## database '{name}'")
        for t in tables:
            try:
                cols = [r[1] for r in conn.execute(f"PRAGMA table_info({t})")]
            except sqlite3.Error:
                continue
            if cols:
                out.append(f"- {t}({', '.join(cols)})")
        conn.close()
    if freight:
        out.append(freightai.schema_text())
    _schema_cache[key] = "\n".join(x for x in out if x)
    return _schema_cache[key]


PASSENGER_DBS = """- 'fleet': every US and Canadian passenger rail fleet. Built from the FTA National Transit Database (NTD, public domain) plus researched
  records. v_fleet_profile is the best starting point (one row per fleet: operator, model, builder, class, build year, active cars,
  estimated annual miles per car, midlife and useful-life years, maintenance cost per car-mile and its delta vs the peer benchmark).
  Per-fleet costs and miles are allocations of operator/mode NTD totals, so treat them as estimates. Where fleet_opex_estimate.allocation_method is 'peer_estimate' (no reported cost; modelled from comparable NTD fleets) or 'r1_freight' (STB R-1 locomotive rates), the cost is a model estimate: say so, give its range (est_low_total_usd to est_high_total_usd) and estimate_grade, and do not use it as a benchmark. ntd_mode codes: CR commuter rail,
  HR heavy rail/metro, LR light rail, SR streetcar, MG monorail/AGT, YR hybrid rail, CC cable car, IP inclined plane. Confidence grades:
  A agency-reported, B trade press, C secondary, D inferred.
- 'bids': procurement notices from rail agencies (notice) scored 0-100 for relevance to rail vehicle maintenance, and contract awards
  (award) with vendor, amount and bidders. agency.fleet_operator_ids links an agency to fleet operator_id values (';'-separated).
  Notices with agency_id 'AMTRAK' may not be reissued or redistributed: never read, quote or paraphrase their description, summary
  or raw_json; use only title, ref_no, dates, category and subsystems, and point to the notice url for details.
  {awards_note}"""
FREIGHT_DB = """- 'freight': US and Canadian freight rail. Class I STB R-1 annual reports cell by cell (r1_cell, by operator_id BNSF, UNION_PACIFIC,
  CSX, NORFOLK_SOUTHERN, CN_RAIL, CPKC; sched is text such as '210') and parent 10-K figures (r1_cell sched 'SEC', freight_kpi_year), weekly EP 724 service metrics,
  rail cost indexes and fuel surcharges, FAF freight flows and forecasts, Statistics Canada traffic, border crossings, network density,
  tank cars, FHWA Section 130 crossing funding, and FRA data for every railroad including Class II and III short lines (attached as fra.*).
  For R-1 questions, first look up the line labels (SELECT DISTINCT sched, line, col, label FROM r1_cell WHERE label LIKE ...)."""
NO_ACCESS = {"passenger": "This user's plan covers freight only: the fleet and bids databases are not available. If asked about passenger fleets or bids, say "
             "that needs a passenger plan.",
             "freight": "This user's plan does not include the freight database. If asked about freight railroads, say that needs a freight plan."}


SYSTEM = """You are the research analyst inside {site}, a rail fleet and procurement intelligence service for suppliers, consultants and agencies.
You answer questions using SQLite databases, which you query with the run_sql tool (read-only SELECT statements only):

{databases}

Schema (columns):
{schema}

How to work:
- Query before you answer; never invent numbers. Prefer a few well-aimed queries (aggregate in SQL, LIMIT large results).
- Use LIKE with % wildcards for names; operator names and model names vary in spelling.
- When you are done, call give_answer exactly once with your final answer. Lead with the direct answer in the headline. Put 2-6 key
  numbers in key_figures, and a compact table when a list helps. Note estimates and data gaps plainly in the answer.
- Write for a busy business-development or fleet-engineering reader: plain sentences, no hype."""

TOOLS = [
    {"name": "run_sql", "description": "Run one read-only SQLite SELECT against the 'fleet', 'bids' or 'freight' database (only those described "
                "in the system prompt are open to this user). Returns up to 80 rows as JSON.",
     "strict": True,
     "input_schema": {"type": "object", "properties": {
         "database": {"type": "string", "enum": ["fleet", "bids", "freight"]},
         "sql": {"type": "string", "description": "A single SELECT (or WITH ... SELECT) statement."}},
         "required": ["database", "sql"], "additionalProperties": False}},
    {"name": "give_answer", "description": "Deliver the final answer to the user. Call once, at the end.", "strict": True,
     "input_schema": {"type": "object", "properties": {
         "headline": {"type": "string", "description": "One-sentence direct answer."},
         "answer_markdown": {"type": "string", "description": "The explanation in Markdown (short paragraphs or bullets)."},
         "key_figures": {"type": "array", "items": {"type": "object", "properties": {
             "label": {"type": "string"}, "value": {"type": "string"}, "note": {"type": "string"}},
             "required": ["label", "value", "note"], "additionalProperties": False}},
         "table": {"type": "object", "properties": {
             "title": {"type": "string"},
             "columns": {"type": "array", "items": {"type": "string"}},
             "rows": {"type": "array", "items": {"type": "array", "items": {"type": "string"}}}},
             "required": ["title", "columns", "rows"], "additionalProperties": False},
         "verdict": {"type": "string", "enum": ["none", "strong_fit", "possible_fit", "weak_fit"],
                     "description": "For bid briefs only; 'none' for ordinary questions."},
         "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
         "caveats": {"type": "array", "items": {"type": "string"}}},
         "required": ["headline", "answer_markdown", "key_figures", "table", "verdict", "confidence", "caveats"],
         "additionalProperties": False}},
]


class QueryError(Exception):
    pass


def run_sql(database, sql, allow_awards, access=("fleet", "bids")):
    s = sql.strip().rstrip(";")
    if ";" in s:
        raise QueryError("Only one statement is allowed.")
    if not s.lower().startswith(("select", "with")):
        raise QueryError("Only SELECT statements are allowed.")
    if database not in access:
        raise QueryError(f"The {database} database is not part of this user's plan.")
    conn = db.fleet() if database == "fleet" else db.bids() if database == "bids" else freightai.connect()
    if conn is None:
        raise QueryError(f"The {database} database is not available right now.")

    def authorizer(action, arg1, arg2, dbname, source):
        if action in (sqlite3.SQLITE_SELECT, sqlite3.SQLITE_FUNCTION, sqlite3.SQLITE_RECURSIVE):
            return sqlite3.SQLITE_OK
        if action == sqlite3.SQLITE_READ:
            if not allow_awards and database == "bids" and arg1 in AWARD_TABLES:
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        return sqlite3.SQLITE_DENY

    conn.set_authorizer(authorizer)
    deadline = time.time() + 8
    conn.set_progress_handler(lambda: 1 if time.time() > deadline else 0, 10000)
    try:
        cur = conn.execute(s)
        cols = [d[0] for d in cur.description or []]
        rows = cur.fetchmany(MAX_ROWS + 1)
    except sqlite3.DatabaseError as e:
        msg = str(e)
        if ("not authorized" in msg or "prohibited" in msg) and not allow_awards:
            msg += " (award data needs a paid plan; answer without it and say so)"
        raise QueryError(msg)
    finally:
        conn.close()
    more = len(rows) > MAX_ROWS
    out = [{c: (v[:300] if isinstance(v, str) else v) for c, v in zip(cols, r)} for r in rows[:MAX_ROWS]]
    return json.dumps({"rows": out, "truncated": more}, default=str)


def _cost(u):
    return ((u.input_tokens or 0) * PRICE_IN + (u.output_tokens or 0) * PRICE_OUT
            + (getattr(u, "cache_read_input_tokens", 0) or 0) * PRICE_CACHE_READ
            + (getattr(u, "cache_creation_input_tokens", 0) or 0) * PRICE_CACHE_WRITE) / 1e6


def _step(job_id, text):
    r = db.q("SELECT steps FROM analyst_job WHERE id = ?", (job_id,), one=True)
    steps = json.loads(r["steps"]) if r else []
    steps.append(text)
    db.x("UPDATE analyst_job SET steps = ? WHERE id = ?", (json.dumps(steps), job_id))


def _describe(sql, database=""):
    s = " ".join(sql.split()).lower()
    if database == "freight":
        if "r1_cell" in s or "kpi" in s:
            return "Reading Class I R-1 and 10-K filings"
        if "ep724" in s:
            return "Checking weekly service metrics"
        if "fra." in s:
            return "Checking FRA railroad data"
        return "Querying the freight database"
    if " award" in s:
        return "Checking contract awards"
    if "notice" in s:
        return "Searching bid notices"
    if "overhaul" in s:
        return "Checking overhaul timing"
    if "cost_trend" in s or "opex" in s or "maint_cost" in s:
        return "Looking at operating costs"
    if "subsystem" in s or "supplier" in s:
        return "Looking up subsystem suppliers"
    if "procurement" in s:
        return "Checking vehicle orders"
    return "Querying the fleet database"


def _loop(job_id, user_msg, allow_awards, access=("fleet", "bids")):
    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY or None)
    site = db.settings().get("site_name", "Consist")
    pas, fr = "fleet" in access, "freight" in access
    dbs = []
    if pas:
        dbs.append(PASSENGER_DBS.format(awards_note="Award tables are available." if allow_awards else
                                        "This user's plan does not include award data (award, bid_tab and the v_award_* views are blocked)."))
    else:
        dbs.append(NO_ACCESS["passenger"])
    dbs.append(FREIGHT_DB if fr else NO_ACCESS["freight"])
    system = SYSTEM.format(site=site, schema=schema_text(pas, fr), databases="\n".join(dbs))
    messages = [{"role": "user", "content": user_msg}]
    cost = 0.0
    for turn in range(MAX_TURNS):
        if cost >= config.ANALYST_MAX_USD:
            messages.append({"role": "user", "content": [{"type": "text", "text": "Budget reached: call give_answer now with what you have."}]})
        resp = client.beta.messages.create(
            model=config.ANALYST_MODEL, max_tokens=16000, system=system, tools=TOOLS, messages=messages,
            output_config={"effort": config.ANALYST_EFFORT}, cache_control={"type": "ephemeral"},
            betas=["server-side-fallback-2026-07-01"], fallbacks="default")
        cost += _cost(resp.usage)
        db.x("UPDATE analyst_job SET cost_usd = ? WHERE id = ?", (round(cost, 4), job_id))
        if resp.stop_reason == "refusal":
            raise RuntimeError("The model declined this request. Try rephrasing the question.")
        messages.append({"role": "assistant", "content": resp.content})
        if resp.stop_reason == "max_tokens":
            messages.append({"role": "user", "content": [{"type": "text", "text": "Your reply was cut off. Call give_answer now, briefly."}]})
            continue
        calls = [b for b in resp.content if b.type == "tool_use"]
        if not calls:
            text = "".join(b.text for b in resp.content if b.type == "text").strip()
            return {"headline": text.split("\n")[0][:200], "answer_markdown": text, "key_figures": [], "table": None,
                    "verdict": "none", "confidence": "medium", "caveats": []}, cost
        results = []
        for b in calls:
            if b.name == "give_answer":
                return b.input, cost
            try:
                _step(job_id, _describe(b.input.get("sql", ""), b.input.get("database", "")))
                out, err = run_sql(b.input["database"], b.input["sql"], allow_awards, access), False
            except (QueryError, KeyError) as e:
                out, err = f"Error: {e}", True
            results.append({"type": "tool_result", "tool_use_id": b.id, "content": out, "is_error": err})
        messages.append({"role": "user", "content": results})
    raise RuntimeError("The analysis took too many steps. Try a narrower question.")


def _run(job_id, user_msg, allow_awards, access=("fleet", "bids")):
    try:
        result, cost = _loop(job_id, user_msg, allow_awards, access)
        if result.get("table") and not result["table"].get("rows"):
            result["table"] = None
        db.x("UPDATE analyst_job SET status = 'done', result = ?, cost_usd = ? WHERE id = ?", (json.dumps(result), round(cost, 4), job_id))
    except anthropic.AuthenticationError:
        db.x("UPDATE analyst_job SET status = 'error', error = ? WHERE id = ?", ("The AI service key is not valid. An admin needs to check it.", job_id))
    except anthropic.RateLimitError:
        db.x("UPDATE analyst_job SET status = 'error', error = ? WHERE id = ?", ("The AI service is busy. Try again in a minute.", job_id))
    except anthropic.APIStatusError as e:
        db.x("UPDATE analyst_job SET status = 'error', error = ? WHERE id = ?", (f"The AI service returned an error ({e.status_code}).", job_id))
    except anthropic.APIConnectionError:
        db.x("UPDATE analyst_job SET status = 'error', error = ? WHERE id = ?", ("Could not reach the AI service.", job_id))
    except Exception as e:  # report anything else to the user rather than leaving the job spinning
        db.x("UPDATE analyst_job SET status = 'error', error = ? WHERE id = ?", (str(e)[:500], job_id))


def access(user):
    """Databases this user's analyst may query: passenger plans get fleet and bids, freight plans the freight database, the all-rail
    plan and admins all three."""
    if user.is_admin:
        return ("fleet", "bids", "freight")
    out = () if db.plan_line(user.plan or {}) == "freight" else ("fleet", "bids")
    if user.can_plan("rail"):
        out += ("freight",)
    return out or ("fleet", "bids")


def available():
    return bool(config.ANTHROPIC_API_KEY)


def start(user, kind, question, ref=None, context=""):
    job_id = uuid.uuid4().hex[:16]
    db.x("INSERT INTO analyst_job (id, user_id, created, kind, question, status, ref) VALUES (?,?,?,?,?,?,?)",
         (job_id, user["id"], db.now(), kind, question, "running", ref))
    msg = question if not context else f"{context}\n\n{question}"
    threading.Thread(target=_run, args=(job_id, msg, user.can("awards"), access(user)), daemon=True).start()
    return job_id


def brief_context(n):
    """The notice plus the fleets its agency runs, so the brief starts from facts rather than a search."""
    ops = data.notice_operators(n)
    fl = []
    for oid in ops[:3]:
        rows, _, _ = data.fleets({"operator": oid, "sort": "cars", "_noscope": 1}, per=12)
        fl += rows
    keep = ["fleet_id", "operator_id", "manufacturer", "model_name", "vehicle_class", "build_year", "qty_active",
            "est_annual_miles_per_car", "midlife_due_year", "ulb_year", "maint_cost_per_car_mile", "delta_vs_benchmark_pct"]
    notice = {k: n.get(k) for k in ("notice_id", "agency", "title", "description", "category", "subsystems", "published", "closing",
                                    "value_est", "currency", "ref_no", "summary")}
    return ("Bid notice:\n" + json.dumps(notice, default=str) + "\n\nFleets run by the issuing agency (operator ids " + ", ".join(ops) + "):\n"
            + json.dumps([{k: f.get(k) for k in keep} for f in fl], default=str))


def fleet_context(d):
    """1.7.24: the fleet a member asked about from its page, so the analyst knows exactly which fleet the question means."""
    keep = ["fleet_id", "operator_id", "operator_name", "service_name", "country", "ntd_mode", "vehicle_class", "manufacturer", "model_name",
            "build_year", "last_rebuild_year", "qty_active", "qty_total_current", "propulsion", "useful_life_benchmark", "est_annual_miles_per_car",
            "est_cumulative_miles", "midlife_due_year", "ulb_year", "engine_overhaul_due_year", "benchmark_maint_per_car_mile", "opex_per_car_mile",
            "maint_cost_per_car_mile", "delta_vs_benchmark_pct", "opex_per_seat_mile"]
    fl = {k: d.get(k) for k in keep if d.get(k) not in (None, "")}
    extra = {"national_benchmark": d.get("national") or {}, "duty_cycle": d.get("duty") or {}, "opex_estimate": d.get("opex") or {},
             "overhaul_projection": (d.get("overhauls") or [])[:6],
             "subsystems_on_record": [{k: x.get(k) for k in ("subsystem", "supplier", "product", "confidence")} for x in (d.get("subsystems") or [])][:20],
             "other_fleets_at_operator": [{k: x.get(k) for k in ("fleet_id", "manufacturer", "model_name", "vehicle_class", "build_year", "qty_active")}
                                          for x in (d.get("siblings") or [])][:12]}
    return ("The member is asking about ONE specific fleet, opened from its fleet page. Answer about this fleet (fleet_id "
            f"{d.get('fleet_id')}) and use its record below; look up more about it with your tools as needed. Do not ask which fleet is meant.\n"
            "Fleet record:\n" + json.dumps(fl, default=str) + "\nMore on this fleet:\n" + json.dumps(extra, default=str)[:6000])


BRIEF_Q = ("Write a bid fit brief for this notice for a rail vehicle supplier or maintenance contractor. Identify which fleet(s) it most "
           "likely concerns and their age, size, utilization and overhaul timing; who supplies the relevant subsystems today "
           "(seed_subsystem / fleet_subsystem); related past awards at this agency and who won them, with amounts, if award data is "
           "available; and the main risks or open questions. Set verdict to strong_fit, possible_fit or weak_fit for a typical "
           "specialist supplier in this category and explain why in the answer.")
