"""Post Admin > Social posts drafts to the Consist LinkedIn company page.

Main route (no LinkedIn developer app needed): a Make.com (or Zapier) webhook. The site sends the draft as JSON
{"text" (little text format), "raw", "url", "month"} to LINKEDIN_WEBHOOK_URL and the scenario posts it to the company page with Make's LinkedIn module,
which already has LinkedIn's approval. When no webhook is saved, the direct API is used, in one of two modes:
- Personal profile (no page ID): the self-serve "Share on LinkedIn" and "Sign In with LinkedIn using OpenID Connect" products,
  scopes openid profile w_member_social. Posts go out as the signed-in member.
- Company page (page ID saved): the Community Management API (scope w_organization_social), which LinkedIn must approve first.
Setup is in Admin > Social posts: paste the app's client ID and secret (and the page ID for page mode), then Connect. Tokens live in DATA_DIR/integrations.json with the other keys (chmod 600).
Access tokens last 60 days; when LinkedIn also issues a refresh token the site renews on its own, otherwise Admin shows when to
reconnect. Nothing posts on its own: every post is a button press by an admin."""
import datetime
import json
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request

from . import config

log = logging.getLogger("linkedin")

USERINFO_URL = "https://api.linkedin.com/v2/userinfo"


def page_mode():
    return bool(config.LINKEDIN_ORG_ID)


def scope():
    return "w_organization_social" if page_mode() else "openid profile w_member_social"
AUTH_URL = "https://www.linkedin.com/oauth/v2/authorization"
TOKEN_URL = "https://www.linkedin.com/oauth/v2/accessToken"
POSTS_URL = "https://api.linkedin.com/rest/posts"


def redirect_uri():
    return config.SITE_URL + "/admin/social/linkedin/callback"


def webhook_mode():
    return bool(config.LINKEDIN_WEBHOOK_URL)


def configured():
    return webhook_mode() or bool(config.LINKEDIN_CLIENT_ID and config.LINKEDIN_CLIENT_SECRET)


def status():
    """Dict for the admin page: configured, connected, days_left, can_refresh."""
    exp = int(config.LINKEDIN_EXPIRES or 0)
    days = (exp - time.time()) / 86400 if exp else None
    return {"configured": configured(), "webhook": webhook_mode(), "webhook_masked": config.masked("LINKEDIN_WEBHOOK_URL"),
            "connected": webhook_mode() or (bool(config.LINKEDIN_TOKEN) and (days is None or days > 0)),
            "days_left": int(days) if days is not None else None, "can_refresh": bool(config.LINKEDIN_REFRESH),
            "org_id": config.LINKEDIN_ORG_ID, "page_mode": page_mode(), "client_id": config.LINKEDIN_CLIENT_ID, "redirect_uri": redirect_uri()}


def auth_url(state):
    q = {"response_type": "code", "client_id": config.LINKEDIN_CLIENT_ID, "redirect_uri": redirect_uri(), "state": state, "scope": scope()}
    return AUTH_URL + "?" + urllib.parse.urlencode(q)


def _token_call(fields):
    data = urllib.parse.urlencode({**fields, "client_id": config.LINKEDIN_CLIENT_ID, "client_secret": config.LINKEDIN_CLIENT_SECRET}).encode()
    req = urllib.request.Request(TOKEN_URL, data=data, method="POST", headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=20) as r:
        t = json.load(r)
    save = {"LINKEDIN_TOKEN": t["access_token"], "LINKEDIN_EXPIRES": str(int(time.time()) + int(t.get("expires_in", 0)))}
    if t.get("refresh_token"):
        save["LINKEDIN_REFRESH"] = t["refresh_token"]
    config.save_stored(save)


def exchange(code):
    _token_call({"grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri()})
    if not page_mode():  # personal posts need the member's id as the author
        req = urllib.request.Request(USERINFO_URL, headers={"Authorization": f"Bearer {config.LINKEDIN_TOKEN}"})
        with urllib.request.urlopen(req, timeout=20) as r:
            config.save_stored({"LINKEDIN_PERSON_ID": json.load(r)["sub"]})


def disconnect():
    config.save_stored({"LINKEDIN_TOKEN": None, "LINKEDIN_EXPIRES": None, "LINKEDIN_REFRESH": None, "LINKEDIN_PERSON_ID": None})


def _fresh_token():
    exp = int(config.LINKEDIN_EXPIRES or 0)
    if config.LINKEDIN_REFRESH and exp and exp - time.time() < 7 * 86400:
        try:
            _token_call({"grant_type": "refresh_token", "refresh_token": config.LINKEDIN_REFRESH})
        except Exception as e:  # keep the current token; it may still be valid
            log.warning("LinkedIn token refresh failed: %s", e)
    if not config.LINKEDIN_TOKEN or (exp and exp < time.time()):
        raise RuntimeError("LinkedIn isn't connected or the sign-in expired. Click Connect LinkedIn.")
    return config.LINKEDIN_TOKEN


_RESERVED = re.compile(r"([\\|{}@\[\]()<>*_~#])")


def little_text(text):
    """LinkedIn's post text format: reserved characters must be escaped, hashtags written as {hashtag|\\#|word}.
    URLs are left alone so they stay clickable."""
    out = []
    for part in re.split(r"(https?://\S+)", text):
        if part.startswith(("http://", "https://")):
            out.append(part)
            continue
        tags = []

        def keep(m):
            tags.append(m.group(1))
            return f"\x00{len(tags) - 1}\x00"
        part = re.sub(r"(?<![\w&])#(\w+)", keep, part)
        part = _RESERVED.sub(r"\\\1", part)
        part = re.sub(r"\x00(\d+)\x00", lambda m: "{hashtag|\\#|" + tags[int(m.group(1))] + "}", part)
        out.append(part)
    return "".join(out)


def short_text(text, url="", limit=250):
    """The post's headline (first line) for X and Bluesky, at most limit characters, with no link: Make's step adds
    " " + url after it, and Bluesky caps a post at 300 characters. Cut at a word with an ellipsis when needed."""
    paras = [p.strip() for p in (text or "").split("\n\n") if p.strip()]
    hook = re.sub(r"https?://\S+", "", paras[0] if paras else "").strip()
    if len(hook) > limit:
        hook = hook[:limit - 1].rsplit(" ", 1)[0].rstrip(",;:") + "…"
    return hook


def _versions():
    """LinkedIn-Version header values to try, newest first: LinkedIn retires each monthly version after about a year."""
    d = datetime.date.today().replace(day=1)
    for _ in range(8):
        d = (d - datetime.timedelta(days=1)).replace(day=1)
        yield d.strftime("%Y%m")


def _webhook(text, url="", month="", image_url="", platforms="linkedin,bluesky", bsky_url=""):
    # Make's "Create a Company Text Post" passes Content to LinkedIn as is, and LinkedIn reads it as little text format,
    # so "text" goes out escaped (hashtags kept as hashtags); "raw" is the plain draft for other uses.
    # image_url (chart posts only, else ""): a public PNG. In Make, a router sends posts with an image_url to
    # "Create a Company Image Post" (HTTP > Get a file first); the rest keep using the text post module.
    # short_text: the headline alone (250 characters at most, no link) for the X and Bluesky branches; Make appends " " + url.
    body = json.dumps({"text": little_text(text), "raw": text, "short_text": short_text(text, url), "url": url, "month": month,
                       "image_url": image_url,
                       # platforms: "linkedin,bluesky" (both) or "bluesky" (Bluesky-only short items, 1.7.58); Make's LinkedIn
                       # modules filter on "platforms contains linkedin". bsky_url: the same link tagged ?ref=bluesky-<kind>.
                       "platforms": platforms or "linkedin,bluesky", "bsky_url": bsky_url or url}).encode()
    req = urllib.request.Request(config.LINKEDIN_WEBHOOK_URL, data=body, method="POST", headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30):
            return ""
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"The posting webhook answered {e.code}. Check the scenario in Make (or Zapier).")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Couldn't reach the posting webhook: {e.reason}")


def post(text, url="", month="", image_url="", platforms="linkedin,bluesky", bsky_url=""):
    """Publish a draft: through the webhook when one is saved, otherwise on the company page or the member's profile
    via the API. Returns the post's URL when LinkedIn gives one, else ''."""
    if webhook_mode():
        return _webhook(text, url, month, image_url, platforms, bsky_url)
    if not configured():
        raise RuntimeError("Add the LinkedIn app's client ID and secret first.")
    token = _fresh_token()
    if page_mode():
        author = f"urn:li:organization:{config.LINKEDIN_ORG_ID}"
    elif config.LINKEDIN_PERSON_ID:
        author = f"urn:li:person:{config.LINKEDIN_PERSON_ID}"
    else:
        raise RuntimeError("Click Connect LinkedIn again so the site learns which profile to post as.")
    body = json.dumps({"author": author, "commentary": little_text(text), "visibility": "PUBLIC",
                       "distribution": {"feedDistribution": "MAIN_FEED", "targetEntities": [], "thirdPartyDistributionChannels": []},
                       "lifecycleState": "PUBLISHED", "isReshareDisabledByAuthor": False}).encode()
    last = ""
    for ver in _versions():
        req = urllib.request.Request(POSTS_URL, data=body, method="POST", headers={
            "Authorization": f"Bearer {token}", "Content-Type": "application/json", "LinkedIn-Version": ver,
            "X-Restli-Protocol-Version": "2.0.0"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                urn = r.headers.get("x-restli-id") or r.headers.get("x-linkedin-id") or ""
                return f"https://www.linkedin.com/feed/update/{urn}/" if urn else "https://www.linkedin.com/feed/"
        except urllib.error.HTTPError as e:
            last = e.read().decode("utf-8", "replace")[:400]
            if "VERSION" in last.upper() and e.code in (400, 426):
                continue  # that monthly version isn't live (yet or any more); try the one before
            if e.code == 401:
                raise RuntimeError("LinkedIn rejected the sign-in. Click Connect LinkedIn again.")
            if e.code == 403:
                raise RuntimeError("LinkedIn refused the post (403). " + ("The app may not have Community Management API approval yet, "
                                   "or the connected account isn't an admin of the page." if page_mode() else
                                   "Check that the app has the Share on LinkedIn product, then click Connect LinkedIn again."))
            raise RuntimeError(f"LinkedIn error {e.code}: {last}")
    raise RuntimeError(f"LinkedIn didn't accept any API version: {last}")
