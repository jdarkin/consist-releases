"""The freight database the AI analyst queries (Justin, 2026-11-02: the Freight Markets Analyst plan includes AI questions, so the
analyst must see the freight data). The portal's freight sources are CSV seeds read in memory by each module, plus fra.db; here the
seeds are loaded once into a SQLite cache in the temp folder (rebuilt at start-up and when any seed file changes) and fra.db is attached read-only as 'fra'."""
import csv
import gzip
import os
import sqlite3
import tempfile
import threading

from . import config

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEED = os.path.join(HERE, "seed")
PATH = os.environ.get("FREIGHT_AI_DB") or os.path.join(tempfile.gettempdir(), "consist_freight_ai.sqlite")  # a rebuildable cache: kept out of DATA_DIR so backups skip it

# table name, seed file, what it is (shown to the model), index columns
TABLES = [
    ("r1_cell", "r1_cells.csv.gz", "Every cell of the Class I STB Form R-1 annual reports, one row per (r1_entity, report_year, sched, line, col) "
     "with the line's label; money values are in USD thousands. operator_id is the railroad (BNSF, UNION_PACIFIC, CSX, NORFOLK_SOUTHERN, "
     "CN_RAIL, CPKC); r1_entity is the filer (CPKC filed as SOO and KCS before 2024). sched 'SEC' holds parent-company 10-K/6-K figures from "
     "SEC XBRL in thousands, with the currency in the label (CN and CP report CAD). See r1_schedule for schedule titles.", ("r1_entity", "report_year", "sched")),
    ("freight_kpi_year", "freight_kpi_year.csv", "Class I yearly KPIs and 10-K figures by operator_id and metric, with unit, currency and source.",
     ("operator_id", "metric")),
    ("ep724", "ep724.csv.gz", "STB EP 724 weekly Class I service data: rr, measure (speed = train speed mph by train type in variable; dwell = "
     "terminal dwell hours, sub = terminal; cars_online; stalled = cars not moved 48h+; carloads by commodity), week (YYYY-MM-DD), value.",
     ("rr", "measure", "week")),
    ("statcan_rail", "statcan_rail.csv.gz", "Statistics Canada rail tables: table, entity, item, sub, period (YYYY or YYYY-MM), value. "
     "Money in CAD.", ("table", "item", "period")),
    ("rcaf", "rcaf.csv.gz", "STB Rail Cost Adjustment Factor by year and quarter (rcaf_unadj, rcaf_adj = productivity-adjusted).", ()),
    ("aar_fuel_monthly", "aar_fuel_monthly.csv.gz", "AAR monthly railroad fuel price index (two base years).", ()),
    ("stb_fuel_surcharge", "stb_fuel_surcharge.csv.gz", "Class I quarterly fuel cost, gallons and fuel surcharge revenue (STB EP 661), "
     "USD thousands.", ("rr", "year")),
    ("faf_rail_commodity", "faf_rail_commodity.csv.gz", "Freight Analysis Framework 5.7.1 US rail tonnage (ktons), value (musd_2017) and "
     "ton-miles by commodity and year, with low/high forecast scenarios to 2050.", ("commodity", "year")),
    ("faf_rail_state", "faf_rail_state.csv.gz", "FAF rail tonnage by origin and destination state, 2024 and 2050 (ktons).", ()),
    ("ntad_owner", "ntad_owner.csv.gz", "BTS NTAD network by owning railroad: route miles, train-miles, bridges by size, yards.", ()),
    ("ntad_subdiv", "ntad_subdiv.csv.gz", "NTAD network by owner, state and subdivision: miles, train-miles, max trains per day, bridges.", ()),
    ("ntad_yards", "ntad_yards.csv.gz", "NTAD rail yards.", ()),
    ("ntad_tofc", "ntad_tofc.csv.gz", "NTAD intermodal (TOFC/COFC) terminals.", ()),
    ("bts_border_rail", "bts_border_rail.csv.gz", "BTS inbound rail border crossings by port and month: trains, loaded and empty containers, "
     "passengers.", ("port", "period")),
    ("bts_tank_car_series", "bts_tank_car_series.csv.gz", "Flammable liquid tank cars by year, liquid and specification (DOT-111, DOT-117...).", ()),
    ("fra_shortline", "fra_shortline.csv.gz", "FRA railroad list: fra_code, fra_class (1, 2 regional, 3 short line), holding company, state.", ()),
    ("s130_apportionment", "s130_apportionment.csv.gz", "FHWA Section 130 railway-highway crossing program apportionments by state and "
     "fiscal year (USD).", ()),
]
FRA_NOTES = ("Attached as 'fra' (query as fra.<table>): FRA safety and operations for every railroad, keyed by fra_code (see fra.fra_railroad_map "
             "and the fra_shortline table for names and classes): fra_ops_year (Form 55 train-miles and employee hours), fra_accident_year and "
             "fra_accident_cause (Form 54), fra_casualty_year, fra_crossing (Form 71 inventory), fra_crossing_incident and fra_crossing_inc_year "
             "(Form 57), fra_crossing_rr, fra_network_owner; and where loaded the STB waybill freight car tables wb_* and freight_lessor_fleet.")

# codes that look like numbers but are compared as text by the portal (R-1 schedule '210', FAF state '01', periods '2024-01')
TEXT_COLS = {"sched", "col", "sctg2", "orig", "dest", "period", "week", "fra_code", "sub", "variable", "owner", "port"}
_lock = threading.Lock()


def _sig():
    return ";".join(f"{f}:{int(os.path.getmtime(os.path.join(SEED, f)))}" for _t, f, _d, _i in TABLES if os.path.exists(os.path.join(SEED, f)))


def _num(v):
    if v == "":
        return None
    try:
        return int(v) if v.lstrip("-").isdigit() else float(v)
    except ValueError:
        return v


def ensure():
    """Build the cache when it is missing or a seed changed. Returns False when there is nothing to load."""
    sig = _sig()
    if not sig:
        return False
    with _lock:
        if os.path.exists(PATH):
            try:
                c = sqlite3.connect(f"file:{PATH}?mode=ro", uri=True)
                have = c.execute("SELECT v FROM _meta WHERE k = 'sig'").fetchone()
                c.close()
                if have and have[0] == sig:
                    return True
            except sqlite3.Error:
                pass
        tmp = f"{PATH}.{os.getpid()}.tmp"  # one per worker process; os.replace makes the swap atomic
        if os.path.exists(tmp):
            os.remove(tmp)
        c = sqlite3.connect(tmp)
        for name, fn, _desc, idx in TABLES:
            p = os.path.join(SEED, fn)
            if not os.path.exists(p):
                continue
            with (gzip.open(p, "rt", newline="") if fn.endswith(".gz") else open(p, newline="")) as f:
                rd = csv.reader(f)
                cols = [h.strip().replace(" ", "_").replace("-", "_") for h in next(rd)]
                c.execute(f"CREATE TABLE {name} ({', '.join(chr(34) + x + chr(34) for x in cols)})")
                keep = [x in TEXT_COLS for x in cols]
                c.executemany(f"INSERT INTO {name} VALUES ({', '.join('?' * len(cols))})",
                              ([v if k else _num(v) for v, k in zip(r, keep)] for r in rd if len(r) == len(cols)))
            if idx:
                c.execute(f"CREATE INDEX {name}_ix ON {name} ({', '.join(chr(34) + x + chr(34) for x in idx)})")
        from . import r1assets
        c.execute("CREATE TABLE r1_schedule (sched, title)")
        c.executemany("INSERT INTO r1_schedule VALUES (?,?)", list(r1assets.SCHED.items()))
        c.execute("CREATE TABLE _meta (k, v)")
        c.execute("INSERT INTO _meta VALUES ('sig', ?)", (sig,))
        c.commit()
        c.close()
        os.replace(tmp, PATH)
    return True


def connect():
    """Read-only connection with fra.db attached as 'fra', or None."""
    try:
        if not ensure():
            return None
    except (OSError, sqlite3.Error, csv.Error):
        import logging
        logging.getLogger("consist").exception("freight_ai build")
        return None
    c = sqlite3.connect(f"file:{PATH}?mode=ro", uri=True, timeout=15, check_same_thread=False)
    if os.path.exists(config.FRA_DB):
        c.execute("ATTACH DATABASE ? AS fra", (f"file:{config.FRA_DB}?mode=ro",))
    return c


def warm():
    c = connect()
    if c is not None:
        c.close()


def schema_text():
    c = connect()
    if c is None:
        return ""
    out = ["## database 'freight'"]
    desc = {t: d for t, _f, d, _i in TABLES}
    desc["r1_schedule"] = "R-1 schedule codes and titles."
    for (t,) in c.execute("SELECT name FROM main.sqlite_master WHERE type = 'table' AND name NOT LIKE '\\_%' ESCAPE '\\' ORDER BY name"):
        cols = [r[1] for r in c.execute(f"PRAGMA main.table_info({t})")]
        out.append(f"- {t}({', '.join(cols)}): {desc.get(t, '')}")
    try:
        out.append(FRA_NOTES)
        for (t,) in c.execute("SELECT name FROM fra.sqlite_master WHERE type IN ('table', 'view') ORDER BY name"):
            cols = [r[1] for r in c.execute(f"PRAGMA fra.table_info({t})")]
            out.append(f"- fra.{t}({', '.join(cols)})")
    except sqlite3.Error:
        out.pop()
    c.close()
    return "\n".join(out)
