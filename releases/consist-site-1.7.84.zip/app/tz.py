"""Viewer time zones (1.7.71, Justin 11-18: "show all times on the site in the users time zone, not UTC"). Stored times stay
UTC; everything shown converts to the viewer's zone. Zone, first match wins: the member's choice on Account (user_pref tz),
the browser's zone (cookie tz, set by base.html on every page and remembered as user_pref tz_seen so emails can use it),
then US Eastern. Standing rule: no UTC shown to users; format times with these helpers or the Jinja filters lt, ld, ltime,
nicetime and utcclock."""
import contextlib
import contextvars
import datetime
import time
import urllib.parse
import zoneinfo

DEFAULT = "America/New_York"
_cur = contextvars.ContextVar("viewer_tz", default=None)
_ucache = {}  # uid -> (monotonic, manual tz, seen tz)
CHOICES = ["America/St_Johns", "America/Halifax", "America/New_York", "America/Toronto", "America/Chicago", "America/Winnipeg",
           "America/Denver", "America/Edmonton", "America/Phoenix", "America/Los_Angeles", "America/Vancouver", "America/Anchorage",
           "Pacific/Honolulu", "America/Mexico_City", "Europe/London", "Europe/Paris", "Europe/Berlin", "Asia/Tokyo", "Australia/Sydney", "UTC"]




def valid(name):
    if not name or len(name) > 64:
        return False
    try:
        zoneinfo.ZoneInfo(name)
        return True
    except Exception:
        return False


def name():
    return _cur.get() or DEFAULT


def zone():
    try:
        return zoneinfo.ZoneInfo(name())
    except Exception:
        return zoneinfo.ZoneInfo(DEFAULT)


@contextlib.contextmanager
def using(tzname):
    """Render in a given zone (emails to a member, background jobs)."""
    tok = _cur.set(tzname if valid(tzname) else None)
    try:
        yield
    finally:
        _cur.reset(tok)


def for_user(u):
    """The zone a member sees: their choice, else the browser zone we last saw, else the default."""
    if not u:
        return DEFAULT
    from . import intel
    try:
        return next((z for z in (intel.pref(u, "tz"), intel.pref(u, "tz_seen")) if valid(z)), DEFAULT)
    except Exception:
        return DEFAULT


def parse(s):
    """An aware UTC datetime from an ISO timestamp (naive = UTC), or None for empty, date-only or unreadable values."""
    if s is None or s == "":
        return None
    if isinstance(s, datetime.datetime):
        d = s
    else:
        t = str(s).strip()
        if len(t) < 13 or not (t[10] in "T " and t[11:13].isdigit()):
            return None
        try:
            d = datetime.datetime.fromisoformat(t.replace("Z", "+00:00")[:32])
        except ValueError:
            try:
                d = datetime.datetime.fromisoformat(t[:19])
            except ValueError:
                return None
    return d if d.tzinfo else d.replace(tzinfo=datetime.timezone.utc)


def local(s):
    d = parse(s)
    return d.astimezone(zone()) if d else None


def lt(s, empty="—"):
    """'2026-11-18 11:09 AM EST': a timestamp in the viewer's zone, compact for tables. Dates pass through unchanged."""
    d = local(s)
    if not d:
        return (str(s)[:10] if s else empty)
    return d.strftime("%Y-%m-%d %-I:%M %p ") + (d.tzname() or "")


def nicetime(s):
    """'Nov 18, 2026 11:09 AM EST'."""
    d = local(s)
    if not d:
        if not s:
            return "—"
        try:
            return datetime.date.fromisoformat(str(s)[:10]).strftime("%b %-d, %Y")
        except ValueError:
            return s
    return d.strftime("%b %-d, %Y %-I:%M %p ") + (d.tzname() or "")


def ld(s, empty="—"):
    """The calendar date (YYYY-MM-DD) of a timestamp in the viewer's zone; a plain date passes through."""
    if not s:
        return empty
    d = local(s)
    return d.strftime("%Y-%m-%d") if d else str(s)[:10]


def ltime(s, empty="—"):
    """'11:09 AM EST' (time only)."""
    d = local(s)
    return d.strftime("%-I:%M %p ") + (d.tzname() or "") if d else empty


def utcclock(hhmm):
    """A fixed daily UTC clock time ('03:00') as the viewer's local time today: '10:00 PM EST'."""
    try:
        h, m = (int(x) for x in str(hhmm).split(":")[:2])
    except ValueError:
        return hhmm
    now = datetime.datetime.now(datetime.timezone.utc)
    d = now.replace(hour=h, minute=m, second=0, microsecond=0).astimezone(zone())
    return d.strftime("%-I:%M %p ") + (d.tzname() or "")


def zone_label(z=None):
    z = z or name()
    try:
        ab = datetime.datetime.now(zoneinfo.ZoneInfo(z)).tzname()
    except Exception:
        ab = ""
    return f"{z.replace('_', ' ')} ({ab})" if ab and ab not in z else z.replace("_", " ")


class TZMiddleware:
    """Sets the viewer's zone for the request. Must sit inside SessionMiddleware (reads the session for the member)."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("path", "").startswith("/static"):
            return await self.app(scope, receive, send)
        ck = dict(h for h in scope.get("headers", []) if h[0] == b"cookie").get(b"cookie", b"").decode("latin-1")
        browser = None
        for part in ck.split(";"):
            k, _, v = part.strip().partition("=")
            if k == "tz":
                browser = urllib.parse.unquote(v)
        browser = browser if valid(browser) else None
        uid = (scope.get("session") or {}).get("uid") if "session" in scope else None
        chosen = None
        if uid:
            hit = _ucache.get(uid)
            if not hit or time.monotonic() - hit[0] > 120:
                try:
                    from . import db
                    rows = {r["key"]: r["value"] for r in db.q("SELECT key, value FROM user_pref WHERE user_id = ? AND key IN ('tz', 'tz_seen')", (uid,))}
                except Exception:
                    rows = {}
                hit = (time.monotonic(), rows.get("tz"), rows.get("tz_seen"))
                if len(_ucache) > 5000:
                    _ucache.clear()
                _ucache[uid] = hit
            chosen = hit[1] if valid(hit[1]) else None
            if browser and browser != hit[2]:  # remember the browser zone for emails
                try:
                    from . import db
                    db.x("INSERT INTO user_pref (user_id, key, value) VALUES (?,?,?) ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value",
                         (uid, "tz_seen", browser))
                    _ucache[uid] = (hit[0], hit[1], browser)
                except Exception:
                    pass
        tok = _cur.set(chosen or browser)
        try:
            await self.app(scope, receive, send)
        finally:
            _cur.reset(tok)


def forget(uid):
    _ucache.pop(uid, None)


def info(u=None):
    """For Account > Time zone: the zone in use, the member's choice (or None), the browser zone we last saw, and the list."""
    manual = seen = None
    if u:
        from . import intel
        try:
            manual = intel.pref(u, "tz") if valid(intel.pref(u, "tz")) else None
            seen = intel.pref(u, "tz_seen")
        except Exception:
            pass
    ch = list(CHOICES)
    for z in (manual, seen):
        if z and z not in ch:
            ch.insert(0, z)
    return {"label": zone_label(), "manual": manual, "seen": seen, "choices": ch}
