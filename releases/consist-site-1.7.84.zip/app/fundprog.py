"""Federal (and two state) grant programs that pay for rail work: program catalog, past awards, funding notices, a freight view and
a locomotive demand signal. Seeds: seed/fund_awards.csv.gz (USAspending, by Assistance Listing; rail-related awards only for
multi-modal programs) and seed/fund_opps.csv.gz (Grants.gov notices), both built by tools/funding/build_programs.py."""
import csv, datetime, gzip, os, re
from functools import lru_cache

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed")
# id, name, agency, ALN (None = no federal award feed), market (freight / passenger / both), size, what it funds, link
PROGRAMS = [
    ("crisi", "Consolidated Rail Infrastructure and Safety Improvements (CRISI)", "FRA", "20.325", "both", "About $1B a year (FY22-26)",
     "Track, bridges, safety, locomotive replacement, workforce. The main capital program for short lines and Class II railroads; passenger projects too.",
     "https://railroads.dot.gov/grants-loans/competitive-discretionary-grant-programs/consolidated-rail-infrastructure-and-safety-2"),
    ("nrp", "National Railroad Partnership (formerly Fed-State Partnership, National)", "FRA", "20.326", "passenger", "About $1.5B+ a year",
     "Intercity passenger capital projects outside and on the Northeast Corridor: corridors, stations, bridges, fleet. Includes the NEC program.",
     "https://railroads.dot.gov/grants-loans/competitive-discretionary-grant-programs/federal-state-partnership-intercity-passenger"),
    ("rce", "Railroad Crossing Elimination", "FRA", "20.327", "both", "About $600M a year",
     "Grade separations, closures, track relocation and crossing safety. See also Crossing safety funding (Section 130).",
     "https://railroads.dot.gov/grants-loans/competitive-discretionary-grant-programs/railroad-crossing-elimination-grant-program"),
    ("rne", "Restoration and Enhancement", "FRA", "20.324", "passenger", "About $50M a year",
     "Operating support for new, restored or expanded intercity passenger routes (up to six years).",
     "https://railroads.dot.gov/grants-loans/competitive-discretionary-grant-programs/restoration-and-enhancement-grants"),
    ("cid", "Corridor Identification and Development", "FRA", "20.339", "passenger", "Planning funds; about 70 corridors selected",
     "Pipeline of future intercity corridors: service development plans, then design. An early read on future rolling stock demand.",
     "https://railroads.dot.gov/corridor-ID"),
    ("amtrak", "Grants to Amtrak (NEC and National Network)", "FRA", "20.315", "passenger", "About $2.4B+ a year (annual + IIJA advance)",
     "Amtrak operating and capital grants, including fleet (Airo, Acela, long-distance replacement).",
     "https://railroads.dot.gov/grants-loans/amtrak-grants"),
    ("rrd", "Railroad Development and earlier FRA grants", "FRA", "20.314", "both", "Legacy and earmarked grants",
     "Older FRA capital grants and congressionally directed rail projects.", "https://railroads.dot.gov/grants-loans"),
    ("hsipr", "High-Speed and Intercity Passenger Rail (ARRA era)", "FRA", "20.319", "passenger", "Legacy (2009-2012 awards, still drawing down)",
     "Corridor and fleet projects from the 2009 program, several still active.", "https://railroads.dot.gov/grants-loans"),
    ("ptc", "Railroad Safety Technology (PTC)", "FRA", "20.321", "both", "Legacy and periodic",
     "Positive train control and other safety technology, mostly commuter railroads and short lines.", "https://railroads.dot.gov/grants-loans"),
    ("irc", "Interstate Rail Compacts", "FRA", "20.328", "passenger", "About $5M a year",
     "Small grants to multi-state rail compacts; an early signal of new corridors.", "https://railroads.dot.gov/grants-loans"),
    ("rrif", "RRIF and RRIF Express loans", "Build America Bureau", None, "both", "Up to $35B lending authority",
     "Low-rate federal loans for track, fleet, stations and facilities; RRIF Express speeds up loans under $150M for short lines.",
     "https://www.transportation.gov/buildamerica/financing/rrif/railroad-rehabilitation-improvement-financing"),
    ("cig", "Capital Investment Grants (New Starts, Core Capacity)", "FTA", "20.500", "passenger", "About $3.8B a year",
     "New and expanded rail transit lines. Projects in the pipeline lead to vehicle orders years later.",
     "https://www.transit.dot.gov/CIG"),
    ("rvr", "Rail Vehicle Replacement", "FTA", "20.500", "passenger", "About $300M a year (FY22-26)",
     "Competitive grants to replace rail transit cars that are past their useful life. Awards listed under Capital Investment Grants.",
     "https://www.transit.dot.gov/funding/grants/rail-vehicle-replacement-grant-program"),
    ("lowno", "Low-No and Bus and Bus Facilities", "FTA", "20.526", "passenger", "About $1.7B a year",
     "Mostly buses; rail-related awards (shops, propulsion, streetcars) shown only.", "https://www.transit.dot.gov/lowno"),
    ("raise", "BUILD (formerly RAISE / TIGER)", "DOT", "20.933", "both", "About $1.5B a year",
     "Multi-modal capital grants; rail-related awards shown only (short line track, rail-served ports, stations).",
     "https://www.transportation.gov/BUILDgrants"),
    ("infra", "INFRA (Nationally Significant Freight and Highway Projects)", "DOT", "20.934", "freight", "About $1.5B a year",
     "Large freight projects; rail-related awards shown only (intermodal, grade separations, rail access to ports).",
     "https://www.transportation.gov/grants/infra-grant-program"),
    ("mega", "Mega and other surface transportation discretionary grants", "DOT", "20.932", "both", "About $1B a year",
     "National Infrastructure Project Assistance (Mega); rail-related awards shown only.", "https://www.transportation.gov/grants/mega-grant-program"),
    ("dera", "Diesel Emissions Reduction Act (DERA), national", "EPA", "66.039", "freight", "About $100M+ a year",
     "Repowers and replacements of diesel engines, including switcher and line-haul locomotives. Rail-related awards shown only.",
     "https://www.epa.gov/dera"),
    ("dera_state", "DERA state allocations", "EPA", "66.040", "freight", "About 30% of DERA funds",
     "States run their own diesel programs with DERA money; some fund locomotive projects. Rail-related awards shown only.",
     "https://www.epa.gov/dera/state-allocations"),
    ("cleanports", "Clean Ports Program", "EPA", "66.051", "freight", "About $3B awarded in 2024 (one-time IRA funding)",
     "Zero-emission port equipment, including some rail yard and switching equipment. Rail-related awards shown only.",
     "https://www.epa.gov/ports-initiative/cleanports"),
    ("cleanhd", "Clean Heavy-Duty Vehicles", "EPA", "66.049", "both", "About $1B (one-time IRA funding)",
     "Mostly trucks and buses; rail-related awards shown only.", "https://www.epa.gov/clean-heavy-duty-vehicles-program"),
    ("cmaq", "Congestion Mitigation and Air Quality (CMAQ)", "FHWA", None, "both", "About $2.6B a year to states",
     "Formula money states can spend on locomotive repowers, commuter service and intermodal projects in air quality areas.",
     "https://www.fhwa.dot.gov/environment/air_quality/cmaq/"),
    ("moyer", "Carl Moyer Program (California)", "CARB", None, "freight", "Tens of millions a year",
     "California grants for cleaner engines, a major funder of Tier 4 and zero-emission switcher and line-haul locomotives.",
     "https://ww2.arb.ca.gov/our-work/programs/carl-moyer-memorial-air-quality-standards-attainment-program"),
    ("terp", "Texas Emissions Reduction Plan (TERP)", "TCEQ", None, "freight", "Tens of millions a year",
     "Texas grants for replacing and repowering diesel equipment, including locomotives (Emissions Reduction Incentive Grants).",
     "https://www.tceq.texas.gov/airquality/terp"),
]
PROG = {p[0]: p for p in PROGRAMS}
ALN_PROG = {}
for p in PROGRAMS:
    if p[3] and p[3] not in ALN_PROG:
        ALN_PROG[p[3]] = p[0]
FREIGHT_ALNS = {"20.325", "20.327", "20.314", "20.321", "20.933", "20.934", "20.932", "66.039", "66.040", "66.051", "66.049"}
CLASS1 = re.compile(r"union pacific|bnsf|csx|norfolk southern|canadian national|canadian pacific|cpkc|kansas city southern|grand trunk|soo line", re.I)
RR = re.compile(r"rail|railroad|railway|r\.r\.|\brr\b|terminal|belt|southern|pacific|northern|central|western|eastern|line\b", re.I)
PUBLIC = re.compile(r"department|dept|state of|county|city of|town of|village|authority|port\b|port of|commission|district|university|council|agency|board|regional|metropolitan", re.I)
WORK = [("Locomotives", r"locomotive|switcher|repower|genset"), ("Crossings", r"crossing|grade separation|underpass|overpass"),
        ("Bridges", r"bridge|trestle|culvert"), ("Track", r"track|rail(?:s)? replac|tie[s ]|ballast|286|siding|yard|rehabilitat|upgrade"),
        ("Safety and signals", r"signal|ptc|positive train|safety|derail"), ("Planning", r"plan|study|design|environmental|engineering")]
DEF = {"awards": "Number of federal grant awards on record (USAspending.gov), fiscal 2019 to date, rail-related only for multi-modal programs.",
       "amount": "Federal obligation on the award (current amount in USAspending.gov), not total project cost.",
       "next": "Next open or forecast funding notice for the program (Grants.gov). Blank: no notice posted or forecast now.",
       "segment": "Recipient type from the recipient name: Class I railroad, other railroad (short line or regional), or public body (state, county, city, port, authority)."}


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _date(s):
    for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except (TypeError, ValueError):
            pass
    return None


def segment(name):
    if CLASS1.search(name or ""):
        return "Class I"
    if PUBLIC.search(name or ""):
        return "Public body"
    if RR.search(name or ""):
        return "Other railroad"
    return "Other"


def work_type(desc):
    for lab, rx in WORK:
        if re.search(rx, desc or "", re.I):
            return lab
    return "Other"


@lru_cache(maxsize=1)
def awards():
    p = os.path.join(SEED, "fund_awards.csv.gz")
    if not os.path.exists(p):
        return []
    out = []
    with gzip.open(p, "rt", newline="") as f:
        for r in csv.DictReader(f):
            r["amount_usd"] = _f(r.get("amount_usd"))
            if r["amount_usd"] <= 0 or (r.get("start_date") or "") < "2015":
                continue  # de-obligations and long-closed awards
            r["year"] = (r.get("start_date") or "")[:4]
            r["prog"] = ALN_PROG.get(r["aln"])
            d = re.sub(r"^DESCRIPTION:\s*", "", r.get("description") or "", flags=re.I)
            r["description"] = d[:1].upper() + d[1:].lower() if d.isupper() else d
            r["segment"] = segment(r.get("recipient"))
            r["work"] = work_type(d)
            r["loco"] = r.get("loco") == "1"
            out.append(r)
    out.sort(key=lambda r: r.get("start_date") or "", reverse=True)
    return out


@lru_cache(maxsize=1)
def opps():
    p = os.path.join(SEED, "fund_opps.csv.gz")
    if not os.path.exists(p):
        return []
    with gzip.open(p, "rt", newline="") as f:
        rows = list(csv.DictReader(f))
    seen, out = set(), []
    for r in rows:
        if r["opp_id"] in seen:
            continue
        seen.add(r["opp_id"])
        r["prog"] = ALN_PROG.get(r["aln"])
        r["close"] = _date(r.get("close_date"))
        r["open"] = _date(r.get("open_date"))
        r["title"] = (r.get("title") or "").replace("&amp;", "&").replace("&iquest;", "-")
        r["url"] = f"https://www.grants.gov/search-results-detail/{r['opp_id']}"
        out.append(r)
    return out


def calendar(today=None):
    today = today or datetime.date.today()
    up = [r for r in opps() if r["status"] in ("posted", "forecasted") and (not r["close"] or r["close"] >= today)]
    up.sort(key=lambda r: (r["close"] is None, r["close"] or today))
    recent = [r for r in opps() if r["close"] and today - datetime.timedelta(days=400) <= r["close"] < today]
    recent.sort(key=lambda r: r["close"], reverse=True)
    return up, recent


def catalog(market=None):
    by = {}
    for r in awards():
        d = by.setdefault(r["prog"], {"n": 0, "usd": 0.0})
        d["n"] += 1
        d["usd"] += r["amount_usd"]
    up, _ = calendar()
    nxt = {}
    for r in up:
        nxt.setdefault(r["prog"], r)
    rows = []
    for p in PROGRAMS:
        if market and p[4] not in (market, "both"):
            continue
        s = by.get(p[0], {"n": 0, "usd": 0.0}) if p[0] != "rvr" else {"n": 0, "usd": 0.0}
        rows.append(dict(id=p[0], name=p[1], agency=p[2], aln=p[3], market=p[4], size=p[5], what=p[6], url=p[7], n=s["n"], usd=s["usd"], next=nxt.get(p[0])))
    return rows


def program(pid):
    p = PROG.get(pid)
    if not p:
        return None
    rows = [r for r in awards() if r["prog"] == pid] if pid != "rvr" else []
    years, states = {}, {}
    for r in rows:
        years[r["year"]] = years.get(r["year"], 0) + r["amount_usd"]
        states[r["state"] or "?"] = states.get(r["state"] or "?", 0) + r["amount_usd"]
    ops = sorted([o for o in opps() if o["prog"] == pid], key=lambda o: o["close"] or datetime.date(1900, 1, 1), reverse=True)
    return dict(id=p[0], name=p[1], agency=p[2], aln=p[3], market=p[4], size=p[5], what=p[6], url=p[7], awards=rows,
                years=sorted(years.items()), states=sorted(states.items(), key=lambda kv: -kv[1])[:15], opps=ops[:25],
                total=sum(r["amount_usd"] for r in rows))


def freight_programs():
    return [p for p in PROGRAMS if p[3] in FREIGHT_ALNS]


def freight(seg=None, work=None, prog=None):
    rows = [r for r in awards() if r["aln"] in FREIGHT_ALNS and r["segment"] in ("Class I", "Other railroad", "Public body")]
    if prog:
        rows = [r for r in rows if r["prog"] == prog]
    if seg:
        rows = [r for r in rows if r["segment"] == seg]
    if work:
        rows = [r for r in rows if r["work"] == work]
    summ = {}
    for r in rows:
        d = summ.setdefault((r["prog"], r["segment"]), {"n": 0, "usd": 0.0})
        d["n"] += 1
        d["usd"] += r["amount_usd"]
    return rows, summ


def locomotives():
    rows = [r for r in awards() if r["loco"]]
    by_year = {}
    for r in rows:
        by_year[r["year"]] = by_year.get(r["year"], 0) + r["amount_usd"]
    return rows, sorted(by_year.items())
