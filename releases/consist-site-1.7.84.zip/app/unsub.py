"""Email opt-out for optional mail (bid and fleet alerts, invites, notes). Account mail (password resets, sign-in) is never blocked.
Each optional email carries List-Unsubscribe and List-Unsubscribe-Post (RFC 8058 one-click) pointing at /unsubscribe/<token>."""
from itsdangerous import BadSignature, URLSafeSerializer

from . import config, db

_S = URLSafeSerializer(config.SECRET_KEY, salt="unsubscribe")


def _norm(email):
    return (email or "").strip().lower()


def token(email):
    return _S.dumps(_norm(email))


def email_for(tok):
    try:
        e = _S.loads(tok)
    except BadSignature:
        return None
    return e if isinstance(e, str) and "@" in e else None


def url(email):
    return f"{config.SITE_URL}/unsubscribe/{token(email)}"


def is_out(email):
    return bool(db.q("SELECT 1 FROM email_optout WHERE email = ?", (_norm(email),), one=True))


def opt_out(email, how="link"):
    if not is_out(email):
        db.x("INSERT INTO email_optout (email, created, how) VALUES (?,?,?)", (_norm(email), db.now(), how))
        db.audit("email_optout", f"{_norm(email)} ({how})", None, None)


def opt_in(email):
    db.x("DELETE FROM email_optout WHERE email = ?", (_norm(email),))
    db.audit("email_optin", _norm(email), None, None)
