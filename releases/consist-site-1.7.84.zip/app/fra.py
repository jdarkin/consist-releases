"""FRA safety and grade crossing data for the /rail portal (routes_rail.py).

Reads fra.db, which the fleet-db stack builds monthly from FRA Office of Railroad Safety data and the BTS NTAD rail network
(fleet-db/tools fra-update, schema in fleet-db/fra/README.md). The site opens it read only and attaches fleet.db for operator
names; operator_id values match fleet.db's operator table. None of this is shown on the passenger pages.
"""
import os
import sqlite3
import time

from . import config

CREDIT = "Source: FRA Office of Railroad Safety and BTS NTAD; compiled by Consist."
CLASS1 = {"BNSF", "UP", "NS", "CSX", "CN_RAIL", "CPKC"}
# FRA reporting ids that differ from the Class I ids the R-1 and locomotive pages use (freight.RAILROADS)
LOCO = {"UP": "UNION_PACIFIC", "NS": "NORFOLK_SOUTHERN"}
FALLBACK_NAMES = {"BNSF": "BNSF Railway", "UP": "Union Pacific", "NS": "Norfolk Southern", "CSX": "CSX Transportation",
                  "CN_RAIL": "CN (US lines)", "CPKC": "CPKC (US lines)"}
WARNINGS = ["Four-quadrant gates", "Gates", "Flashing lights", "Signs only", "None", "Grade separated"]
GATED = ("Gates", "Four-quadrant gates")
WARN_COLORS = {"Four-quadrant gates": "#1f7a4d", "Gates": "#2e9e62", "Flashing lights": "#d99a1e", "Signs only": "#d0572c",
               "None": "#b3261e", "Grade separated": "#7a8290"}
WARN_COLOR_LIST = [WARN_COLORS[w] for w in WARNINGS]
CAUSE_GROUPS = ["Track", "Human factors", "Equipment", "Signal", "Misc", "Unknown"]
SORTS = {"collisions": "collisions_since_2010 DESC, exposure_index DESC", "exposure": "exposure_index DESC",
         "trains": "total_trains_per_day DESC", "passenger": "passenger_trains_per_day DESC", "aadt": "aadt DESC",
         "speed": "max_timetable_speed DESC", "place": "state, county, city, street"}
PER_PAGE = 50
MAP_MAX = 4000
EXPORT_MAX = 50000
CROSSING_COLS = ["crossing_id", "railroad_name", "fra_code", "operator_id", "state", "county", "city", "street", "latitude", "longitude",
                 "crossing_type", "position", "warning", "gate_arms", "flashing_light_pairs", "passenger_trains_per_day", "total_trains_per_day",
                 "max_timetable_speed", "main_tracks", "aadt", "pct_trucks", "school_bus_route", "quiet_zone", "exposure_index",
                 "collisions_since_2010", "killed_since_2010", "injured_since_2010", "last_collision", "inventory_updated"]


def available():
    return os.path.exists(config.FRA_DB)


def connect():
    if not available():
        return None
    c = sqlite3.connect(f"file:{config.FRA_DB}?mode=ro", uri=True, timeout=15, check_same_thread=False)
    c.row_factory = sqlite3.Row
    if os.path.exists(config.FLEET_DB):
        c.execute("ATTACH DATABASE ? AS fl", (f"file:{config.FLEET_DB}?mode=ro",))
    return c


def q(sql, args=(), one=False):
    c = connect()
    if c is None:
        return None if one else []
    try:
        rows = [dict(r) for r in c.execute(sql, args).fetchall()]
        return (rows[0] if rows else None) if one else rows
    finally:
        c.close()


_cache = {}


def cached(key, fn, ttl=900):
    """Small in-process cache keyed by the fra.db file time, so a monthly rebuild shows up at once."""
    stamp = os.path.getmtime(config.FRA_DB) if available() else 0
    hit = _cache.get(key)
    if hit and hit[0] == stamp and time.time() - hit[1] < ttl:
        return hit[2]
    v = fn()
    _cache[key] = (stamp, time.time(), v)
    return v


def names():
    def load():
        out = dict(FALLBACK_NAMES)
        try:
            for r in q("SELECT operator_id, operator_name, category FROM fl.operator"):
                out[r["operator_id"]] = r["operator_name"]
        except sqlite3.Error:
            pass
        return out
    return cached("names", load)


def categories():
    def load():
        try:
            return {r["operator_id"]: r["category"] for r in q("SELECT operator_id, category FROM fl.operator")}
        except sqlite3.Error:
            return {}
    return cached("cats", load)


def segment(op):
    """Passenger = an agency in the passenger fleet database (commuter, intercity, transit); everything else reporting to FRA is
    freight (2026-11-03: unknown short lines used to fall into Passenger)."""
    cat = categories().get(op) or ""
    return "Passenger" if cat and not cat.startswith("freight") and op not in CLASS1 else "Freight"


# Safety lens buttons, both portals (Justin, 2026-11-03). The freight portal opens on All freight, the passenger app on All passenger.
SAFETY_LENSES = [("all", "All railroads", "Every operator reporting FRA safety data."),
                 ("pax", "All passenger", "Amtrak, commuter railroads and other passenger agencies that report to FRA."),
                 ("freight", "All freight", "Every freight railroad: Class I, regional, short line and other."),
                 ("commuter", "Passenger / commuter", "Commuter railroads only."),
                 ("c1", "Class I", "The Class I freight railroads."),
                 ("c2", "Regional", "Regional (Class II) freight railroads."),
                 ("c3", "Short line", "Short line (Class III) freight railroads."),
                 ("other", "Other", "Freight-side operators with no FRA class on file, such as tourist, terminal and industrial railroads.")]


def lens_keys(op):
    """The safety lenses an FRA operator belongs to."""
    from . import shortline as _sl
    if segment(op) == "Passenger":
        return {"all", "pax"} | ({"commuter"} if categories().get(op) == "commuter" else set())
    c = "1" if op in CLASS1 else _sl.class_of(op)
    return {"all", "freight", {"1": "c1", "2": "c2", "3": "c3"}.get(c, "other")}


def by_lens(rows, lens):
    """Rows (from operators()) in one safety lens; only operators that actually report train-miles."""
    return [r for r in rows if (r.get("train_miles") or 0) > 0 and lens in lens_keys(r["operator_id"])]


def title(s):
    return " ".join(w.capitalize() for w in (s or "").split()) if s and s.isupper() else (s or "")


# ---------- headline numbers ----------

def headline():
    def load():
        base = "crossing_type = 'Public' AND position = 'At Grade' AND passenger_trains_per_day > 0"
        r = q(f"""SELECT (SELECT count(*) FROM fra_crossing) AS crossings,
                (SELECT count(*) FROM fra_crossing WHERE position = 'At Grade') AS at_grade,
                (SELECT count(*) FROM fra_crossing WHERE {base}) AS pax_public,
                (SELECT count(*) FROM fra_crossing WHERE {base} AND warning NOT IN ('Gates', 'Four-quadrant gates')) AS ungated,
                (SELECT count(*) FROM fra_crossing WHERE {base} AND warning NOT IN ('Gates', 'Four-quadrant gates') AND collisions_since_2010 > 0) AS ungated_hit,
                (SELECT sum(collisions_since_2010) FROM fra_crossing WHERE {base} AND warning NOT IN ('Gates', 'Four-quadrant gates')) AS ungated_collisions,
                (SELECT count(*) FROM fra_crossing_incident) AS incidents,
                (SELECT min(year) FROM fra_crossing_incident) AS inc_from, (SELECT max(year) FROM fra_crossing_incident) AS inc_to,
                (SELECT count(*) FROM v_fra_operator) AS operators,
                (SELECT max(inventory_updated) FROM fra_crossing) AS inventory_updated""", one=True) or {}
        return r
    return cached("headline", load) if available() else {}


# ---------- operator safety rates ----------

def operators(seg=""):
    def load():
        rows = q("""SELECT v.*, x.crossings, x.pax, x.pax_ungated FROM v_fra_operator v LEFT JOIN (
                      SELECT xo.operator_id, count(*) crossings, sum(c.passenger_trains_per_day > 0) pax,
                             sum(c.passenger_trains_per_day > 0 AND c.crossing_type = 'Public' AND c.warning NOT IN ('Gates', 'Four-quadrant gates', 'Grade separated')) pax_ungated
                      FROM fra_crossing_operator xo JOIN fra_crossing c USING (crossing_id) WHERE c.position = 'At Grade' GROUP BY xo.operator_id) x USING (operator_id)
                    ORDER BY v.train_miles DESC""")
        nm = names()
        for r in rows:
            r["name"] = nm.get(r["operator_id"], r["operator_id"])
            r["segment"] = segment(r["operator_id"])
            tm = (r["train_miles"] or 0) / 1e6
            r["fatal_per_m"] = round(r["crossing_fatalities"] / tm, 2) if tm else None
            r["damage_per_m"] = round(r["damage_usd"] / tm) if tm else None
        return rows
    rows = cached("operators", load)
    return [r for r in rows if not seg or r["segment"] == seg]


def medians(rows, keys):
    out = {}
    for k in keys:
        v = sorted(r[k] for r in rows if r.get(k) is not None)
        out[k] = (v[len(v) // 2] if len(v) % 2 else (v[len(v) // 2 - 1] + v[len(v) // 2]) / 2) if v else None
    return out


def operator(op):
    """Everything on one operator's safety page."""
    v = next((r for r in operators() if r["operator_id"] == op), None)
    yrs = q("""SELECT year, sum(total_train_miles) tm, sum(passenger_train_miles) ptm, sum(freight_train_miles) ftm, sum(passenger_miles) pm
               FROM fra_ops_year WHERE operator_id = ? GROUP BY year ORDER BY year""", (op,))
    acc = q("""SELECT year, kind, cause_group, sum(accidents) n, sum(damage_usd) dmg, sum(killed) killed, sum(injured) injured
               FROM fra_accident_year WHERE operator_id = ? GROUP BY year, kind, cause_group ORDER BY year""", (op,))
    xinc = q("SELECT year, sum(collisions) n, sum(killed) killed, sum(injured) injured FROM fra_crossing_inc_year WHERE operator_id = ? GROUP BY year ORDER BY year", (op,))
    cas = q("SELECT person_type, sum(fatal) fatal, sum(nonfatal) nonfatal FROM fra_casualty_year WHERE operator_id = ? GROUP BY person_type ORDER BY sum(fatal) DESC, sum(nonfatal) DESC", (op,))
    if not (v or yrs or acc):
        return None
    y1 = v["year_to"] if v else (max(r["year"] for r in yrs) if yrs else None)
    y0 = (y1 - 4) if y1 else None
    top = q("""SELECT cause_code, cause, cause_group, sum(accidents) n, sum(damage_usd) dmg FROM fra_accident_cause
               WHERE operator_id = ? AND year BETWEEN ? AND ? GROUP BY cause_code ORDER BY n DESC, dmg DESC LIMIT 15""", (op, y0, y1)) if y1 else []
    xs = q("""SELECT count(*) n, sum(c.position = 'At Grade') at_grade, sum(c.position = 'At Grade' AND c.passenger_trains_per_day > 0) pax,
                     sum(c.position = 'At Grade' AND c.warning IN ('Gates', 'Four-quadrant gates')) gated,
                     sum(c.position = 'At Grade' AND c.crossing_type = 'Public' AND c.passenger_trains_per_day > 0 AND c.warning NOT IN ('Gates', 'Four-quadrant gates')) pax_ungated,
                     sum(c.collisions_since_2010 > 0) hit, sum(c.quiet_zone NOT IN ('No', '') AND c.quiet_zone IS NOT NULL) quiet
              FROM fra_crossing_operator xo JOIN fra_crossing c USING (crossing_id) WHERE xo.operator_id = ?""", (op,), one=True) or {}
    warn = q("""SELECT c.warning, count(*) n FROM fra_crossing_operator xo JOIN fra_crossing c USING (crossing_id)
                WHERE xo.operator_id = ? AND c.position = 'At Grade' GROUP BY c.warning ORDER BY n DESC""", (op,))
    codes = q("SELECT fra_code, fra_name FROM fra_railroad_map WHERE operator_id = ? ORDER BY fra_code", (op,))
    years = sorted({r["year"] for r in yrs} | {r["year"] for r in acc} | {r["year"] for r in xinc})
    by = {y: dict(year=y, tm=None, pm=None, train=0, crossing=0, killed=0, injured=0, dmg=0, **{g: 0 for g in CAUSE_GROUPS}) for y in years}
    for r in yrs:
        by[r["year"]].update(tm=r["tm"], pm=r["pm"])
    for r in acc:
        d = by[r["year"]]
        if r["kind"] == "train":
            d["train"] += r["n"] or 0
            d[r["cause_group"] if r["cause_group"] in CAUSE_GROUPS else "Unknown"] += r["n"] or 0
            d["dmg"] += r["dmg"] or 0
    for r in xinc:
        by[r["year"]].update(crossing=r["n"] or 0, killed=r["killed"] or 0, injured=r["injured"] or 0)
    for d in by.values():
        tm = (d["tm"] or 0) / 1e6
        d["rate"] = round(d["train"] / tm, 2) if tm else None
        d["xrate"] = round(d["crossing"] / tm, 2) if tm else None
    return dict(op=op, name=names().get(op, op), segment=segment(op), v=v, years=[by[y] for y in years], top=top, cas=cas, xs=xs, warn=warn,
                codes=codes, y0=y0, y1=y1)


# ---------- accidents by cause ----------

def cause_years(op=None, seg=""):
    where, args = ["kind = 'train'"], []
    if op:
        where.append("operator_id = ?")
        args.append(op)
    elif seg:
        ids = [r["operator_id"] for r in operators(seg)]
        where.append(f"operator_id IN ({','.join('?' * len(ids))})" if ids else "0")
        args += ids
    rows = q(f"SELECT year, cause_group, sum(accidents) n, sum(damage_usd) dmg FROM fra_accident_year WHERE {' AND '.join(where)} GROUP BY year, cause_group ORDER BY year", args)
    years = sorted({r["year"] for r in rows})
    grid = {y: {g: 0 for g in CAUSE_GROUPS} for y in years}
    dmg = {y: 0 for y in years}
    for r in rows:
        grid[r["year"]][r["cause_group"] if r["cause_group"] in CAUSE_GROUPS else "Unknown"] += r["n"] or 0
        dmg[r["year"]] += r["dmg"] or 0
    return years, grid, dmg


def top_causes(y0, y1, op=None, seg="", group="", limit=40):
    where, args = ["year BETWEEN ? AND ?"], [y0, y1]
    if op:
        where.append("operator_id = ?")
        args.append(op)
    elif seg:
        ids = [r["operator_id"] for r in operators(seg)]
        where.append(f"operator_id IN ({','.join('?' * len(ids))})" if ids else "0")
        args += ids
    if group:
        where.append("cause_group = ?")
        args.append(group)
    return q(f"""SELECT cause_code, max(cause) cause, cause_group, sum(accidents) n, sum(damage_usd) dmg, count(DISTINCT operator_id) ops
                 FROM fra_accident_cause WHERE {' AND '.join(where)} GROUP BY cause_code ORDER BY n DESC, dmg DESC LIMIT ?""", args + [limit])


def cause_operators(code, y0, y1):
    rows = q("""SELECT a.operator_id, a.fra_code, max(m.fra_name) fra_name, sum(a.accidents) n, sum(a.damage_usd) dmg FROM fra_accident_cause a
                LEFT JOIN fra_railroad_map m ON m.fra_code = a.fra_code WHERE a.cause_code = ? AND a.year BETWEEN ? AND ?
                GROUP BY coalesce(a.operator_id, a.fra_code) ORDER BY n DESC LIMIT 30""", (code, y0, y1))
    nm = names()
    for r in rows:
        r["name"] = nm.get(r["operator_id"]) or r["fra_name"] or r["fra_code"]
    return rows


def accident_years():
    r = q("SELECT min(year) a, max(year) b FROM fra_accident_year", one=True) or {}
    return r.get("a"), r.get("b")


# ---------- crossings ----------

def crossing_filters(params, preset=None):
    """The crossings explorer's filters from the query string. preset='ungated' starts from public, at-grade passenger
    crossings without gates that have had a collision since 2010."""
    g = lambda k, d="": (params.get(k) or d).strip()
    f = dict(state=g("state").upper(), op=g("op"), warning=g("warning"), type=g("type"), position=g("position", "At Grade"),
             pax=g("pax"), hit=g("hit"), school=g("school"), quiet=g("quiet"), q=g("q"), sort=g("sort", "collisions"),
             rr=",".join(x for x in g("rr").upper().replace(" ", "").split(",") if x.isalnum())[:200], cls=g("cls") if g("cls") in ("1", "2", "3") else "")
    if preset == "ungated":
        f.update(type=f["type"] or "Public", position="At Grade", pax="1", warning=f["warning"] or "ungated",
                 hit=(params.get("hit") or "").strip() if "hit" in params else "1")
    if f["sort"] not in SORTS:
        f["sort"] = "collisions"
    if f["warning"] not in WARNINGS + ["ungated", "gated", ""]:
        f["warning"] = ""
    if f["type"] not in ("Public", "Private", ""):
        f["type"] = ""
    if f["position"] not in ("At Grade", "RR Over", "RR Under", "any"):
        f["position"] = "At Grade"
    return f


def _where(f):
    w, a = [], []
    if f["state"]:
        w.append("c.state = ?")
        a.append(f["state"])
    if f["op"]:
        w.append("c.crossing_id IN (SELECT crossing_id FROM fra_crossing_operator WHERE operator_id = ?)")
        a.append(f["op"])
    if f.get("rr"):  # operating railroad FRA code(s), e.g. from the freight railroad tables
        codes = f["rr"].split(",")
        w.append(f"c.fra_code IN ({','.join('?' * len(codes))})")
        a += codes
    if f.get("cls"):  # every crossing on track operated by railroads of one FRA class
        from . import shortline
        codes = [c for c, r in shortline._seed().items() if r["fra_class"] == f["cls"]] or ["-"]
        w.append(f"c.fra_code IN ({','.join('?' * len(codes))})")
        a += codes
    if f["warning"] == "ungated":
        w.append("c.warning NOT IN ('Gates', 'Four-quadrant gates', 'Grade separated')")
    elif f["warning"] == "gated":
        w.append("c.warning IN ('Gates', 'Four-quadrant gates')")
    elif f["warning"]:
        w.append("c.warning = ?")
        a.append(f["warning"])
    if f["type"]:
        w.append("c.crossing_type = ?")
        a.append(f["type"])
    if f["position"] and f["position"] != "any":
        w.append("c.position = ?")
        a.append(f["position"])
    if f["pax"]:
        w.append("c.passenger_trains_per_day > 0")
    if f["hit"]:
        w.append("c.collisions_since_2010 > 0")
    if f["school"]:
        w.append("c.school_bus_route = 'Yes'")
    if f["quiet"]:
        w.append("c.quiet_zone IS NOT NULL AND c.quiet_zone NOT IN ('No', '')")
    if f["q"]:
        w.append("(c.crossing_id = ? OR c.city LIKE ? OR c.street LIKE ? OR c.county LIKE ? OR c.railroad_name LIKE ?)")
        like = f"%{f['q']}%"
        a += [f["q"].upper(), like, like, like, like]
    return (" AND ".join(w) or "1=1"), a


def crossings(f, page=1):
    where, args = _where(f)
    order = SORTS[f["sort"]]
    stats = q(f"""SELECT count(*) n, sum(c.collisions_since_2010) collisions, sum(c.killed_since_2010) killed, sum(c.injured_since_2010) injured,
                         sum(c.collisions_since_2010 > 0) hit, sum(c.warning IN ('Gates', 'Four-quadrant gates')) gated,
                         sum(c.passenger_trains_per_day > 0) pax FROM fra_crossing c WHERE {where}""", args, one=True) or {}
    rows = q(f"SELECT c.* FROM fra_crossing c WHERE {where} ORDER BY {order}, c.crossing_id LIMIT ? OFFSET ?", args + [PER_PAGE, (page - 1) * PER_PAGE])
    return rows, stats


def crossing_points(f):
    """Up to MAP_MAX located crossings for the map, the most collision-prone first: [id, lat, lon, warning index, collisions]."""
    where, args = _where(f)
    rows = q(f"""SELECT c.crossing_id, c.latitude, c.longitude, c.warning, c.collisions_since_2010 FROM fra_crossing c
                 WHERE {where} AND c.latitude IS NOT NULL AND c.longitude IS NOT NULL AND c.latitude != 0
                 ORDER BY {SORTS[f['sort']]} LIMIT ?""", args + [MAP_MAX])
    wi = {w: i for i, w in enumerate(WARNINGS)}
    return [[r["crossing_id"], round(r["latitude"], 5), round(r["longitude"], 5), wi.get(r["warning"], 4), r["collisions_since_2010"] or 0] for r in rows]


def crossings_export(f):
    where, args = _where(f)
    return q(f"SELECT {', '.join('c.' + k for k in CROSSING_COLS)} FROM fra_crossing c WHERE {where} ORDER BY {SORTS[f['sort']]} LIMIT ?", args + [EXPORT_MAX])


def facets():
    def load():
        nm = names()
        ops = [(r["operator_id"], nm.get(r["operator_id"], r["operator_id"]), r["n"])
               for r in q("SELECT operator_id, count(*) n FROM fra_crossing_operator GROUP BY operator_id")]
        return dict(states=[r["state"] for r in q("SELECT state FROM fra_crossing_state ORDER BY state") if r["state"]],
                    ops=sorted(ops, key=lambda o: (o[0] not in CLASS1, o[1].lower())))
    return cached("facets", load)


def crossing(cid):
    c = q("SELECT * FROM fra_crossing WHERE crossing_id = ?", (cid,), one=True)
    if not c:
        return None
    c["incidents"] = q("SELECT * FROM fra_crossing_incident WHERE crossing_id = ? ORDER BY date DESC", (cid,))
    nm = names()
    c["operators"] = [dict(r, name=nm.get(r["operator_id"], r["operator_id"]))
                      for r in q("SELECT operator_id, source FROM fra_crossing_operator WHERE crossing_id = ? ORDER BY source = 'owner' DESC", (cid,))]
    return c


def state_rows():
    return q("""SELECT s.*, x.ungated, x.hit FROM fra_crossing_state s LEFT JOIN (
                  SELECT state, sum(warning NOT IN ('Gates', 'Four-quadrant gates')) ungated,
                         sum(warning NOT IN ('Gates', 'Four-quadrant gates') AND collisions_since_2010 > 0) hit
                  FROM fra_crossing WHERE crossing_type = 'Public' AND position = 'At Grade' AND passenger_trains_per_day > 0 GROUP BY state) x USING (state)
                ORDER BY s.crossings_passenger DESC""")
