"""BTS seeds for the Freight portal: FAF5 rail flows and forecasts, NTAD network (freight trains per day, bridges, yards,
intermodal terminals), border rail crossings, and the flammable-liquid tank car series. All US federal, public domain."""
import csv, gzip, os
SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed")
CREDIT_FAF = "Freight Analysis Framework 5.7.1 (BTS and FHWA, prepared by Oak Ridge National Laboratory). Forecasts are FAF's base, low and high scenarios."
CREDIT_NTAD = "BTS National Transportation Atlas Database: Freight Trains per Day (FRA), Railroad Bridges, Rail Yards, Intermodal Rail Terminals (TOFC/COFC)."
CREDIT_BORDER = "BTS Border Crossing Entry Data (US Customs and Border Protection inbound crossings)."
CREDIT_TANK = ("BTS, Progress Toward Safer Rail Tank Cars Transporting Flammable Liquids: 2025 Report, Table 2 (2013-2024, from Railinc Umler and TRAIN II), and the 2026 Report for 2025 totals.")
_c = {}


def _read(name):
    if name not in _c:
        p = os.path.join(SEED, name)
        _c[name] = list(csv.DictReader(gzip.open(p, "rt", newline=""))) if os.path.exists(p) else []
    return _c[name]


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


# ---- FAF ----
def faf_commodities(mode="rail"):
    rows = {}
    for r in _read("faf_rail_commodity.csv.gz"):
        if r["mode"] == mode:
            rows.setdefault(r["commodity"], {})[r["year"]] = r
    out = []
    for c, ys in rows.items():
        a, b = _f(ys.get("2024", {}).get("ktons")), _f(ys.get("2050", {}).get("ktons"))
        lo, hi = _f(ys.get("2050", {}).get("ktons_low")), _f(ys.get("2050", {}).get("ktons_high"))
        allm = next((x for x in _read("faf_rail_commodity.csv.gz") if x["mode"] == "all" and x["commodity"] == c and x["year"] == "2024"), None)
        out.append(dict(name=c, t2024=a, t2050=b, lo=lo, hi=hi, growth=100 * ((b / a) ** (1 / 26) - 1) if a and b else None,
                        tmiles=_f(ys.get("2024", {}).get("mton_miles")), value=_f(ys.get("2024", {}).get("musd_2017")),
                        share=100 * a / _f(allm["ktons"]) if allm and _f(allm["ktons"]) else None))
    return sorted([r for r in out if r["t2024"] > 0], key=lambda r: -r["t2024"])


def faf_total(mode="rail"):
    t = {}
    for r in _read("faf_rail_commodity.csv.gz"):
        if r["mode"] == mode:
            d = t.setdefault(int(r["year"]), [0, 0, 0])
            d[0] += _f(r["ktons"]); d[1] += _f(r["ktons_low"]); d[2] += _f(r["ktons_high"])
    return sorted(t.items())


def faf_states(n=25):
    o, d = {}, {}
    for r in _read("faf_rail_state.csv.gz"):
        for k, nm, m in ((r["orig"], r["orig_name"], o), (r["dest"], r["dest_name"], d)):
            x = m.setdefault(nm, [0, 0])
            x[0] += _f(r["ktons_2024"]); x[1] += _f(r["ktons_2050"])
    f = lambda m: sorted(([k, v[0], v[1], 100 * (v[1] / v[0] - 1) if v[0] else None] for k, v in m.items()), key=lambda x: -x[1])[:n]
    lanes = sorted(_read("faf_rail_state.csv.gz"), key=lambda r: -_f(r["ktons_2024"]))[:n]
    return f(o), f(d), lanes


# ---- NTAD ----
BANDS = ["under 1", "1-4", "5-9", "10-19", "20-39", "40+"]
NAMES = {"UP": "Union Pacific", "BNSF": "BNSF", "CSXT": "CSX", "NS": "Norfolk Southern", "CN": "CN (US)", "CPRS": "CPKC (Soo Line)",
         "KCS": "CPKC (KCS)", "AMTK": "Amtrak"}


def owners(min_miles=50):
    rows = []
    for r in _read("ntad_owner.csv.gz"):
        d = {k: (_f(v) if k != "owner" else v) for k, v in r.items()}
        if d["miles"] >= min_miles or d["bridges"] >= 100:
            d["name"] = NAMES.get(d["owner"], d["owner"])
            d["density"] = d["train_miles"] / d["miles"] if d["miles"] else None
            d["dense_share"] = 100 * (d["b_20-39"] + d["b_40+"]) / d["miles"] if d["miles"] else None
            d["bridges_per_100"] = 100 * d["bridges"] / d["miles"] if d["miles"] else None
            rows.append(d)
    return sorted(rows, key=lambda r: -r["miles"])


def subdivs(owner, n=40):
    rows = [dict(r, miles=_f(r["miles"]), train_miles=_f(r["train_miles"]), max_trains=_f(r["max_trains"]), pass_miles=_f(r["pass_miles"]), bridges=_f(r["bridges"]))
            for r in _read("ntad_subdiv.csv.gz") if r["owner"] == owner]
    for r in rows:
        r["density"] = r["train_miles"] / r["miles"] if r["miles"] else None
    return sorted(rows, key=lambda r: -r["train_miles"])[:n]


def tofc(owner=None):
    return [r for r in _read("ntad_tofc.csv.gz") if not owner or owner in (r["rail_co"] or "")]


def yards(owner):
    return [r for r in _read("ntad_yards.csv.gz") if r["owner"] == owner]


# ---- border ----
def border_ports(measure="Trains", year=None):
    rows = _read("bts_border_rail.csv.gz")
    if not rows:
        return [], None
    year = year or max(r["period"][:4] for r in rows if r["period"][5:] == "12")
    agg = {}
    for r in rows:
        if r["measure"] == measure and r["period"][:4] in (year, str(int(year) - 1)):
            k = (r["port"], r["state"], r["border"])
            agg.setdefault(k, [0, 0])[0 if r["period"][:4] == year else 1] += _f(r["value"])
    out = [dict(port=k[0], state=k[1], border=k[2], v=v[0], prev=v[1], chg=100 * (v[0] / v[1] - 1) if v[1] else None) for k, v in agg.items() if v[0] or v[1]]
    return sorted(out, key=lambda r: -r["v"]), year


def border_monthly(measure="Trains"):
    m = {}
    for r in _read("bts_border_rail.csv.gz"):
        if r["measure"] == measure:
            d = m.setdefault(r["period"], [0, 0])
            d[0 if "Canada" in r["border"] else 1] += _f(r["value"])
    return sorted(m.items())


# ---- tank cars ----
def tank_series():
    t = {}
    for r in _read("bts_tank_car_series.csv.gz"):
        t.setdefault(r["car"], {})[int(r["year"])] = t.get(r["car"], {}).get(int(r["year"]), 0) + _f(r["count"])
    return t


def tank_latest():
    """Summary years after the detailed BTS series ends (2021): BTS 'Progress Toward Safer Rail Tank Cars' reports, loaded in fra.db
    (bts_tank_car_fl). Returns {year: {total, dot117, cpc1232, other}}."""
    from . import fra
    try:
        rows = fra.q("SELECT CAST(year AS INT) y, metric, value FROM bts_tank_car_fl")
    except Exception:
        return {}
    m = {}
    for r in rows:
        m.setdefault(r["y"], {})[r["metric"]] = r["value"]
    out = {}
    for y, v in m.items():
        tot = v.get("tank_cars_class3_fl")
        d117 = v.get("dot117_in_fl_service")
        if d117 is None and v.get("dot117_non_crude") and v.get("dot117_crude_share") is not None:
            d117 = round(v["dot117_non_crude"] / (1 - v["dot117_crude_share"] / 100))   # derived: non-crude DOT-117s / non-crude share
        if tot:
            c = v.get("cpc1232_in_fl_service")
            out[y] = dict(total=tot, dot117=d117, cpc1232=c, other=tot - (d117 or 0) - (c or 0) if d117 else None, derived="dot117_in_fl_service" not in v)
    return dict(sorted(out.items()))
