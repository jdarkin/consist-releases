"""Award analyst: past awards like a given bid or scope, who won them and at what price, with the statistics that matter
when pricing a bid (median, spread between bids, number of bidders, how often the low bidder won). Also the funding
side that Bid Catcher's budgets collector fills in: capital plans, budgets, board actions and FTA grants.
All bids.db reads are read-only; tables the collector has not created yet read as empty."""
import re
import statistics

from . import data, db

STOP = {"rail", "transit", "contract", "services", "service", "agreement", "authority", "provide", "provision", "supply", "the", "and",
        "for", "with", "from", "year", "years", "option", "options", "request", "proposals", "proposal", "bid", "rfp", "ifb", "rfq", "invitation"}
STAGES = {"planned": "Capital plan", "budgeted": "Budgeted", "authorized": "Board authorized", "solicitation": "Out for bid",
          "intent_to_award": "Intent to award", "awarded": "Awarded", "amended": "Change order / option"}
STAGE_ORDER = list(STAGES)


def _q(sql, args=(), one=False):
    try:
        return db.bq(sql, args, one=one)
    except Exception:  # table not created yet on this bids.db
        return None if one else []


def _stem(w):
    return w[:-3] + "y" if w.endswith("ies") and len(w) > 4 else w[:-1] if w.endswith("s") and not w.endswith("ss") and len(w) > 4 else w


def tokens(s):
    """Scope words, singular: "trucks" and "truck" match."""
    return {_stem(w) for w in re.findall(r"[a-z0-9][a-z0-9\-]{2,}", (s or "").lower()) if w not in STOP and not w.isdigit()}


# ---------------- taxonomy: read from bids.db (Bid Catcher's taxonomy.py writes subsystem_def), so new subsystems need no code here

FALLBACK_WORK = {"new_vehicles": "New vehicles", "overhaul": "Overhaul / rebuild", "repair": "Repair", "parts": "Parts supply",
                 "maintenance": "Maintenance services", "construction": "Construction / installation", "engineering": "Engineering / design"}
GROUP_LABELS = {"vehicle": "Vehicle", "wayside": "Wayside and infrastructure", "facilities": "Facilities and shop", None: "Other"}
CATEGORY_WORK = {"overhaul_program": "overhaul", "component_repair": "repair", "parts_supply": "parts", "maintenance_services": "maintenance",
                 "vehicle_procurement": "new_vehicles", "rail_engineering": "engineering", "engineering_support": "engineering"}
_TAX = {"at": 0.0}


def taxonomy():
    """{'subsystems': {key: (label, group, regex)}, 'work': {key: (label, regex)}}, cached for 10 minutes. Also refreshes the
    labels in data.SUBSYSTEMS, which templates use everywhere."""
    import time
    if time.time() - _TAX["at"] < 600 and _TAX.get("subsystems"):
        return _TAX
    subs, work = {}, {}
    for r in _q("SELECT key, label, grp, pattern, kind FROM subsystem_def"):
        try:
            rx = re.compile(r["pattern"], re.I) if r["pattern"] else None
        except re.error:
            rx = None
        if r["kind"] == "work_type":
            work[r["key"]] = (r["label"], rx)
        else:
            subs[r["key"]] = (r["label"] or r["key"].replace("_", " ").capitalize(), r["grp"], rx)
    if not subs:  # bids.db from before taxonomy.py: labels only, no patterns
        subs = {k: (v, "vehicle", None) for k, v in data.SUBSYSTEMS.items()}
    if not work:
        work = {k: (v, None) for k, v in FALLBACK_WORK.items()}
    for k, (label, _, _) in subs.items():
        data.SUBSYSTEMS[k] = label
    _TAX.update(subsystems=subs, work=work, at=time.time())
    return _TAX


def subsystems_of(a):
    """Stored subsystems plus the ones the taxonomy patterns find in the title and notes."""
    have = {x for x in (a.get("subsystems") or "").split(";") if x}
    text = f"{a.get('title') or ''} {a.get('notes') or ''}"
    return have | {k for k, (_, _, rx) in taxonomy()["subsystems"].items() if rx and rx.search(text)}


def work_of(a):
    text = f"{a.get('title') or ''} {a.get('notes') or ''}"
    for k, (_, rx) in taxonomy()["work"].items():
        if rx and rx.search(text):
            return k
    return CATEGORY_WORK.get(a.get("category"))


UNIT_RX = re.compile(r"\b(\d{1,3}(?:,\d{3})+|\d{1,5})\s+(?:[A-Za-z0-9/\-]+\s+){0,3}(wheel ?sets?|wheels?|kits?|sets?|rail ?cars?|cars?|"
                     r"vehicles?|lrvs?|locomotives?|coaches|trucks?|bogies?|assembl(?:y|ies)|units?|motors?|sheaves?|doors?|compressors?|"
                     r"couplers?|pantographs?|seats?|crossings?|switch(?:es)?|turnouts?|ties|crossties)\b", re.I)
UNIT_NAMES = {"wheelset": "wheelset", "wheel": "wheel", "kit": "kit", "set": "kit", "railcar": "car", "car": "car", "vehicle": "car", "lrv": "car",
              "locomotive": "locomotive", "coache": "car", "coach": "car", "truck": "truck", "bogie": "truck", "assembly": "unit", "assemblie": "unit",
              "unit": "unit", "motor": "motor", "sheave": "sheave", "door": "door", "compressor": "compressor", "coupler": "coupler",
              "pantograph": "pantograph", "seat": "seat", "crossing": "crossing", "switche": "switch", "switch": "switch", "turnout": "switch",
              "tie": "tie", "crosstie": "tie"}


def units_of(a):
    """(quantity, unit) stated in the title or notes, e.g. (3000, 'wheel') or (57, 'kit'), else (None, None)."""
    for m in UNIT_RX.finditer(f"{a.get('title') or ''} {a.get('notes') or ''}"):
        q = int(m.group(1).replace(",", ""))
        if 2 <= q <= 200000 and not (1990 <= q <= 2040 and "," not in m.group(1)):
            u = m.group(2).lower().replace(" ", "")
            u = u[:-1] if u.endswith("s") and u[:-1] in UNIT_NAMES else u
            return q, UNIT_NAMES.get(u, u)
    return None, None


# US CPI-U annual averages (BLS; 2025 and 2026 estimated), to compare awards in today's dollars
CPI = {2005: 195.3, 2006: 201.6, 2007: 207.3, 2008: 215.3, 2009: 214.5, 2010: 218.1, 2011: 224.9, 2012: 229.6, 2013: 233.0, 2014: 236.7,
       2015: 237.0, 2016: 240.0, 2017: 245.1, 2018: 251.1, 2019: 255.7, 2020: 258.8, 2021: 271.0, 2022: 292.7, 2023: 304.7, 2024: 313.7,
       2025: 322.0, 2026: 330.0}


def today_usd(amount, date):
    try:
        y = min(max(int((date or "")[:4]), min(CPI)), max(CPI))
    except ValueError:
        return amount
    return amount * CPI[max(CPI)] / CPI[y] if amount else amount


def facets():
    """Filter options built from what the awards actually hold: categories, subsystems (grouped) and work types, each with
    how many priced, relevant awards carry it. Options with no awards are left out, so new values appear by themselves."""
    rows = [dict(r) for r in _q("SELECT category, subsystems, title, notes FROM award WHERE relevance >= 50 AND amount_usd > 0")]
    tax = taxonomy()
    cats, subs, work = {}, {}, {}
    for a in rows:
        if a["category"]:
            cats[a["category"]] = cats.get(a["category"], 0) + 1
        for k in subsystems_of(a):
            subs[k] = subs.get(k, 0) + 1
        w = work_of(a)
        if w:
            work[w] = work.get(w, 0) + 1
    groups = {}
    for k, n in sorted(subs.items(), key=lambda x: (-x[1], x[0])):
        label, grp, _ = tax["subsystems"].get(k, (k.replace("_", " ").capitalize(), None, None))
        groups.setdefault(grp, []).append((k, label, n))
    order = [g for g in GROUP_LABELS if g in groups] + [g for g in groups if g not in GROUP_LABELS]
    return {"categories": [(k, data.CATEGORIES.get(k, k.replace("_", " ").capitalize()), n) for k, n in sorted(cats.items(), key=lambda x: -x[1])],
            "subsystem_groups": [(GROUP_LABELS.get(g, (g or "Other").capitalize()), groups[g]) for g in order],
            "work": [(k, tax["work"].get(k, (k,))[0], n) for k, n in sorted(work.items(), key=lambda x: -x[1])]}


def ref_from(f, notice=None):
    """The scope to compare against: a tracked notice (its trade, subsystems and work type steer the ranking), or the form,
    where every field picked is a filter, so the comparison stays like for like."""
    if notice:
        r = {"title": notice["title"], "category": notice.get("category"), "subsystems": notice.get("subsystems") or "",
             "agency_id": notice.get("agency_id"), "country": notice.get("country"), "q": notice["title"], "notice_id": notice["notice_id"],
             "explicit": False}
        r["subsystems"] = ";".join(sorted(subsystems_of({"title": notice["title"], "notes": notice.get("description"),
                                                          "subsystems": r["subsystems"]})))
        r["work"] = work_of({"title": notice["title"], "notes": notice.get("description"), "category": notice.get("category")})
        r["qty"], r["unit"] = units_of({"title": notice["title"], "notes": notice.get("description")})
        return r
    q = f.get("q") or ""
    # what the keywords imply (e.g. "grade crossing" -> Grade crossings, "truck overhaul" -> Overhaul) steers the ranking without filtering
    return {"title": q, "category": f.get("category"), "subsystems": f.get("subsystem") or "", "work": f.get("work") or "",
            "agency_id": f.get("agency"), "country": f.get("country"), "q": q, "model": f.get("model") or "",
            "explicit": True, "qty": None, "unit": units_of({"title": q})[1],
            "hint_subsystems": "" if f.get("subsystem") else ";".join(sorted(subsystems_of({"title": q}))),
            "hint_work": "" if f.get("work") else (work_of({"title": q}) or "")}


def model_scope(model):
    """(operator ids running this vehicle model, tokens that name it) for the analyst's Model filter."""
    from . import intel
    m = (model or "").strip().lower()
    ops = {fl["operator_id"] for fl in intel.snapshot_all().values() if (fl["model_name"] or "").lower() == m}
    toks = {w for w in re.findall(r"[a-z0-9][a-z0-9\-]+", m) if len(w) >= 2 and w not in STOP}
    return ops, toks


def similar(ref, limit=40, since=None):
    """Past awards ranked by likeness to ref. Each row gets score (0-100), why (the reasons), its subsystems and work type,
    quantity and unit price where the award states a quantity, and the amount in today's dollars.
    Like for like: the work type (overhaul, repair, parts, new vehicles...) and the subsystems weigh most, scope words are
    weighted by how rare they are, and a picked trade, subsystem or work type is a filter, not a hint."""
    import math
    where, args = ["a.relevance >= 50", "a.amount_usd > 0"], []
    if since:
        where.append("a.award_date >= ?")
        args.append(since)
    if ref.get("notice_id"):
        where.append("coalesce(a.notice_id, 0) != ?")
        args.append(ref["notice_id"])
    if ref.get("explicit") and ref.get("category"):
        where.append("a.category = ?")
        args.append(ref["category"])
    rows = [dict(r) for r in _q("SELECT a.*, coalesce(g.agency, a.buyer) agency FROM award a LEFT JOIN agency g USING (agency_id) "
                                f"WHERE {' AND '.join(where)}", args)]
    labels = {k: v[0] for k, v in taxonomy()["subsystems"].items()}
    wlabels = {k: v[0] for k, v in taxonomy()["work"].items()}
    t = tokens(ref.get("q"))
    picked = {s for s in (ref.get("subsystems") or "").split(";") if s}
    subs = picked or {s for s in (ref.get("hint_subsystems") or "").split(";") if s}
    picked_work = ref.get("work") or None
    rwork = picked_work or ref.get("hint_work") or None
    # how rare each scope word is across the candidate awards: "pantograph" says more than "vehicle"
    df = {}
    for a in rows:
        a["_tok"] = tokens(a["title"]) | tokens(a.get("notes"))
        for w in a["_tok"] & t:
            df[w] = df.get(w, 0) + 1
    idf = {w: math.log((len(rows) + 1) / (df.get(w, 0) + 1)) + 1 for w in t}
    m_ops, m_toks = model_scope(ref.get("model")) if ref.get("model") else (set(), set())
    if ref.get("model"):
        ag_ops = {r["agency_id"]: {x for x in (r["fleet_operator_ids"] or "").split(";") if x}
                  for r in _q("SELECT agency_id, fleet_operator_ids FROM agency")}
    this_year = int(str(__import__("datetime").date.today())[:4])
    out = []
    for a in rows:
        a["subs"], a["work"] = subsystems_of(a), work_of(a)
        a["qty"], a["unit"] = units_of(a)
        s, why = 0.0, []
        if ref.get("explicit"):  # picked on the form: filters
            if picked and not (a["subs"] & picked):
                continue
            if picked_work and a["work"] != picked_work:
                continue
            if picked or picked_work or ref.get("category"):
                s += 15  # passed every filter picked on the form
        if ref.get("model"):  # a filter, not just a boost: the buyer runs that model, or the contract names it
            runs = a.get("operator_id") in m_ops or bool(ag_ops.get(a["agency_id"], set()) & m_ops)
            named = bool(m_toks) and m_toks <= (a["_tok"] | {w for w in re.findall(r"[a-z0-9][a-z0-9\-]+", (a["title"] or "").lower())})
            if not (runs or named):
                continue
            s += 15 if named else 8
            why.append(f"names the {ref['model']}" if named else f"buyer runs the {ref['model']}")
        if rwork and a["work"]:
            if a["work"] == rwork:
                s += 20
                why.append(wlabels.get(rwork, rwork).lower())
            else:
                s -= 15
        if subs:
            both = a["subs"] & subs
            if both:
                s += 10 + 25 * len(both) / len(a["subs"] | subs)
                why.append(", ".join(labels.get(x, x) for x in sorted(both)))
            elif a["subs"]:
                s -= 10
        if ref.get("category"):
            if a["category"] == ref["category"]:
                s += 15
                why.append("same trade")
            elif t or subs:
                s -= 5
        if t:
            common = t & a["_tok"]
            if common:
                s += 25 * sum(idf[w] for w in common) / sum(idf.values())
                why.append("scope: " + ", ".join(sorted(common, key=lambda w: -idf[w])[:4]))
        if ref.get("unit") and a["unit"] == ref["unit"]:
            s += 8
            why.append(f"priced per {a['unit']}")
        if ref.get("agency_id") and a["agency_id"] == ref["agency_id"]:
            s += 5
            why.append("same agency")
        elif ref.get("country") and a["country"] == ref["country"]:
            s += 2
        try:
            if this_year - int((a.get("award_date") or "0")[:4]) <= 3:
                s += 3
        except ValueError:
            pass
        if not (ref.get("category") or subs or t or rwork):
            s = max(s, 50)
        if s >= 30:
            a["score"], a["why"] = min(100, round(s)), why
            a["today_usd"] = today_usd(a["amount_usd"], a.get("award_date"))
            a["unit_usd"] = a["amount_usd"] / a["qty"] if a["qty"] else None
            a["subs_label"] = [labels.get(x, x) for x in sorted(a["subs"])]
            a["work_label"] = wlabels.get(a["work"], "") if a["work"] else ""
            a.pop("_tok", None)
            out.append(a)
    out.sort(key=lambda a: a["award_date"] or "", reverse=True)
    out.sort(key=lambda a: -a["score"])
    return out[:limit]


def pct(vals, p):
    if not vals:
        return None
    v = sorted(vals)
    k = (len(v) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(v) - 1)
    return v[lo] + (v[hi] - v[lo]) * (k - lo)


def bid_tabs(award_ids):
    if not award_ids:
        return {}
    ph = ",".join("?" * len(award_ids))
    out = {}
    for r in _q(f"SELECT award_id, bidder, bidder_norm, amount, rank, winner FROM bid_tab WHERE award_id IN ({ph}) ORDER BY award_id, rank", list(award_ids)):
        out.setdefault(r["award_id"], []).append(dict(r))
    return out


def stats(rows):
    """Descriptive statistics for a set of awards (amounts in USD)."""
    amt = [a["amount_usd"] for a in rows if a.get("amount_usd")]
    if not amt:
        return None
    tabs = bid_tabs([a["award_id"] for a in rows])
    spreads, ratios, bidders, low_won, annual = [], [], [], [], []
    for a in rows:
        tab = [b for b in tabs.get(a["award_id"], []) if b["amount"]]
        lo = a.get("low_bid") or (min(b["amount"] for b in tab) if tab else None)
        hi = a.get("high_bid") or (max(b["amount"] for b in tab) if tab else None)
        n = a.get("n_bidders") or (len(tab) or None)
        if n:
            bidders.append(n)
        if lo and hi and hi > lo:
            spreads.append(100 * (hi - lo) / lo)
        if lo and a.get("amount") and n and n > 1:
            ratios.append(100 * (a["amount"] - lo) / lo)  # award vs low bid, in the award's own currency
            low_won.append(a["amount"] <= lo * 1.001)
        if a.get("term_months"):
            annual.append(a["amount_usd"] * 12 / a["term_months"])
    q1, q3 = pct(amt, .25), pct(amt, .75)
    return {"n": len(amt), "total": sum(amt), "min": min(amt), "max": max(amt), "mean": statistics.fmean(amt),
            "median": statistics.median(amt), "p25": q1, "p75": q3, "iqr": q3 - q1,
            "cv": round(100 * statistics.pstdev(amt) / statistics.fmean(amt)) if len(amt) > 1 else None,
            "annual_median": statistics.median(annual) if annual else None, "n_annual": len(annual),
            "bidders_median": statistics.median(bidders) if bidders else None, "n_bidders": len(bidders),
            "single_bid_pct": round(100 * sum(1 for b in bidders if b == 1) / len(bidders)) if bidders else None,
            "spread_median": statistics.median(spreads) if spreads else None, "n_spread": len(spreads),
            "spread_p75": pct(spreads, .75) if spreads else None,
            "award_vs_low_median": statistics.median(ratios) if ratios else None,
            "low_won_pct": round(100 * sum(low_won) / len(low_won)) if low_won else None, "n_low": len(low_won),
            "tabs": tabs}


def winners(rows):
    by = {}
    for a in rows:
        v = a.get("vendor_norm") or a.get("vendor") or "Unknown"
        w = by.setdefault(v, {"vendor": v, "wins": 0, "usd": 0.0, "prices": [], "agencies": set(), "latest": ""})
        w["wins"] += 1
        w["usd"] += a["amount_usd"] or 0
        w["prices"].append(a["amount_usd"])
        w["agencies"].add(a.get("agency") or a.get("agency_id"))
        w["latest"] = max(w["latest"], a.get("award_date") or "")
    total = sum(w["usd"] for w in by.values()) or 1
    for w in by.values():
        w["median"] = statistics.median([p for p in w["prices"] if p]) if any(w["prices"]) else None
        w["share"] = round(100 * w["usd"] / total)
    return sorted(by.values(), key=lambda w: (-w["wins"], -w["usd"]))


def bidder_record(rows, tabs):
    """Every firm that bid on these awards (from bid tabulations): bids, wins, and how far above the low bid it usually was."""
    by = {}
    for a in rows:
        tab = tabs.get(a["award_id"], [])
        lo = min((b["amount"] for b in tab if b["amount"]), default=None)
        for b in tab:
            k = b["bidder_norm"] or b["bidder"]
            r = by.setdefault(k, {"bidder": k, "bids": 0, "wins": 0, "gaps": []})
            r["bids"] += 1
            r["wins"] += 1 if b["winner"] else 0
            if lo and b["amount"]:
                r["gaps"].append(100 * (b["amount"] - lo) / lo)
    for r in by.values():
        r["win_rate"] = round(100 * r["wins"] / r["bids"]) if r["bids"] else None
        r["gap_median"] = statistics.median(r["gaps"]) if r["gaps"] else None
    return sorted(by.values(), key=lambda r: (-r["bids"], -r["wins"]))


def by_year(rows):
    ys = {}
    for a in rows:
        if a.get("award_date") and a.get("amount_usd"):
            ys.setdefault(a["award_date"][:4], []).append(a["amount_usd"])
    return [{"year": y, "n": len(v), "median": statistics.median(v)} for y, v in sorted(ys.items())]


def strip_svg(rows, st, w=640, h=86):
    """One dot per award on a log price axis, with the interquartile box and the median."""
    import math
    amt = [a["amount_usd"] for a in rows if a.get("amount_usd")]
    if not amt or not st:
        return ""
    lo, hi = math.log10(min(amt)), math.log10(max(amt))
    if hi - lo < 0.3:
        lo, hi = lo - 0.15, hi + 0.15
    x = lambda v: 20 + (w - 40) * (math.log10(v) - lo) / (hi - lo)  # noqa: E731
    parts = [f'<svg class="strip" viewBox="0 0 {w} {h}" role="img" aria-label="Award prices">',
             f'<rect x="{x(st["p25"]):.1f}" y="18" width="{max(2, x(st["p75"]) - x(st["p25"])):.1f}" height="30" rx="4" class="box"/>',
             f'<line x1="{x(st["median"]):.1f}" x2="{x(st["median"]):.1f}" y1="12" y2="54" class="med"/>']
    for i, a in enumerate(r for r in rows if r.get("amount_usd")):
        tip = "\n".join(t for t in (a.get("title") or "Award", f'{a.get("vendor") or "Vendor not published"} · ${a["amount_usd"]:,.0f}',
                                         f'{a.get("agency") or a.get("buyer") or ""} · {a.get("award_date") or "date unknown"}',
                                         "Click for the award details") if t)
        parts.append(f'<a href="/app/awards/{a["award_id"]}" data-tip="{_esc(tip)}" aria-label="{_esc(a.get("title"))}">'
                     f'<circle cx="{x(a["amount_usd"]):.1f}" cy="{33 + ((i * 7) % 15) - 7}" r="4" class="dot"/></a>')
    for v in (min(amt), st["median"], max(amt)):
        parts.append(f'<text x="{x(v):.1f}" y="{h - 8}" text-anchor="middle">{_money(v)}</text>')
    parts.append("</svg>")
    return "".join(parts)


def _esc(s):
    return (str(s or "")).replace("&", "&amp;").replace("<", "&lt;").replace('"', "&quot;")


def _money(v):
    return f"${v / 1e6:.1f}M" if v >= 1e6 else f"${v / 1e3:.0f}k" if v >= 1e3 else f"${v:.0f}"


def unit_stats(rows):
    """Median price per unit for the most common stated unit among rows (at least 2 awards with that unit)."""
    by = {}
    for a in rows:
        if a.get("unit_usd"):
            by.setdefault(a["unit"], []).append(a["unit_usd"])
    best = max(by.items(), key=lambda x: len(x[1]), default=(None, []))
    if len(best[1]) < 2:
        return None
    return {"unit": best[0], "n": len(best[1]), "median": statistics.median(best[1]), "min": min(best[1]), "max": max(best[1])}


def analyze(ref, limit=40, since=None):
    rows = similar(ref, limit, since)
    close = [a for a in rows if a["score"] >= 60]
    basis = close if len(close) >= 5 else rows  # statistics on the close matches when there are enough of them
    st = stats(basis)
    if st:
        st["basis"] = "close" if basis is close else "all"
        st["n_close"] = len(close)
        st["today_median"] = statistics.median([a["today_usd"] for a in basis if a.get("today_usd")])
        st["units"] = unit_stats(basis)
    tabs = st["tabs"] if st else {}
    return {"rows": rows, "stats": st, "winners": winners(rows), "bidders": bidder_record(rows, tabs), "years": by_year(rows),
            "strip": strip_svg(rows, st), "tabs": tabs}


# ---------------- funding side (Bid Catcher budgets collector) ----------------

def _latest(rows):
    """Capital plans and budgets repeat the same project in every edition: keep the newest record per agency, stage and project
    (the stage history of a project is kept, only re-statements of the same stage collapse). Rows must be newest first."""
    seen, out = set(), []
    for r in rows:
        k = (r["agency_id"], r["stage"], " ".join(sorted(tokens(r["project"]))) or r["project"])
        if k not in seen:
            seen.add(k)
            out.append(r)
    return out


# Funding segments: agency rail modes (NTD-style codes in Bid Catcher's agency table) -> segment
SEGMENTS = {"transit": "Transit", "passenger": "Passenger and commuter rail", "freight": "Freight"}
SEGMENT_MODES = {"transit": {"HR", "LR", "SR", "SC", "AG", "MG", "APM", "CC", "IP", "TR"},
                 "passenger": {"CR", "YR", "IC", "ICR", "AR"}, "freight": {"FR"}}


def segments():
    """The segments this viewer can pick: no freight while it is parked (see lens.py)."""
    from . import lens
    return {k: v for k, v in SEGMENTS.items() if k != "freight" or lens.current().freight}


def segment_of(modes):
    """Segments a ';'-separated mode list falls in (an agency can be in more than one)."""
    ms = {m for m in (modes or "").split(";") if m}
    return {k for k, v in SEGMENT_MODES.items() if ms & v}


def segment_agencies(seg):
    """Bid Catcher agency ids in one segment; None when seg is not a segment (no filter)."""
    if seg not in SEGMENTS:
        return None
    return [r["agency_id"] for r in _q("SELECT agency_id, rail_modes FROM agency") if seg in segment_of(r["rail_modes"])] or ["-"]


def budget_items(agency_ids=None, notice_id=None, stage=None, limit=300, all_editions=False):
    where, args = ["1=1"], []
    if notice_id:
        where.append("b.notice_id = ?")
        args.append(notice_id)
    if agency_ids:
        where.append(f"b.agency_id IN ({','.join('?' * len(agency_ids))})")
        args += list(agency_ids)
    if stage:
        where.append("b.stage = ?")
        args.append(stage)
    rows = [dict(r) for r in _q("SELECT b.*, coalesce(g.agency, b.agency_id) agency FROM budget_item b LEFT JOIN agency g USING (agency_id) "
                                f"WHERE {' AND '.join(where)} ORDER BY coalesce(b.doc_date, substr(b.first_seen, 1, 10)) DESC, b.item_id DESC", args)]
    return (rows if all_editions else _latest(rows))[:int(limit)]


def budget_summary(agency_ids=None):
    """Per stage: distinct items (latest edition), their dollars and agencies."""
    by = {}
    for r in budget_items(agency_ids, limit=10 ** 9):
        d = by.setdefault(r["stage"], {"stage": r["stage"], "n": 0, "usd": 0.0, "agencies": set()})
        d["n"] += 1
        d["usd"] += r["amount_usd"] or 0
        d["agencies"].add(r["agency_id"])
    return [dict(d, agencies=len(d["agencies"])) for d in by.values()]


def grants(agency_ids=None, rail_only=True, limit=200):
    where, args = ["1=1"], []
    if rail_only:
        where.append("f.rail = 1")
    if agency_ids:
        where.append(f"f.agency_id IN ({','.join('?' * len(agency_ids))})")
        args += list(agency_ids)
    return [dict(r) for r in _q("SELECT f.*, coalesce(g.agency, f.recipient) agency FROM funding_grant f LEFT JOIN agency g USING (agency_id) "
                                f"WHERE {' AND '.join(where)} ORDER BY f.start_date DESC LIMIT {int(limit)}", args)]


def reconcile(notice):
    """For one bid: what the agency budgeted or authorized for it, any intent to award, the award, and the gap between them."""
    items = budget_items(notice_id=notice["notice_id"])
    if not items and notice.get("agency_id"):  # no direct link yet: same agency, overlapping scope
        t = tokens(notice["title"])
        for b in budget_items([notice["agency_id"]], limit=400):
            u = tokens(b["project"]) | tokens(b.get("description"))
            if t and u and len(t & u) / len(t | u) >= 0.25 and (not notice.get("category") or b["category"] == notice["category"]):
                b["guess"] = True
                items.append(b)
    items.sort(key=lambda b: (STAGE_ORDER.index(b["stage"]) if b["stage"] in STAGES else 9, b.get("doc_date") or ""))
    budget = next((b["amount_usd"] for b in items if b["stage"] in ("budgeted", "authorized", "planned") and b.get("amount_usd")), None)
    award = next((b["amount_usd"] for b in items if b["stage"] in ("awarded", "intent_to_award") and b.get("amount_usd")), None)
    return {"items": items, "budget": budget, "award": award,
            "gap_pct": round(100 * (award - budget) / budget) if budget and award else None}


# ---------------- funding mix (the chart at the top of the Funding tab) ----------------

CFDA = {"20.500": "FTA Capital Investment Grants", "20.507": "FTA Urbanized Area Formula", "20.525": "FTA State of Good Repair",
        "20.526": "FTA Bus and Bus Facilities", "20.509": "FTA Rural Area Formula", "20.513": "FTA Enhanced Mobility",
        "20.505": "FTA Metropolitan Planning", "20.519": "FTA Clean Fuels", "20.527": "FTA Public Transportation Emergency Relief",
        "20.528": "FTA Rail Fixed Guideway Safety", "20.522": "FTA Alternatives Analysis", "20.514": "FTA Research",
        "20.531": "FTA Integrated Mobility", "20.933": "DOT National Infrastructure Investments",
        "20.314": "FRA Railroad Development", "20.325": "FRA Consolidated Rail Infrastructure and Safety",
        "20.326": "FRA Federal-State Partnership for Intercity Passenger Rail", "20.327": "FRA Railroad Crossing Elimination"}
PURPOSES = [("New vehicles", r"new (rail ?)?(cars?|vehicles?)|replac|purchase|procure|acqui|order|rolling stock|(light rail|rail|multilevel|subway|railcar)s?\b.*vehicles?|\b\d+ .*cars\b"),
            ("Overhaul and rebuild", r"overhaul|rebuild|refurb|midlife|mid-life|remanufactur|life extension|rehab"),
            ("Vehicle systems and parts", r"hvac|door|brake|propulsion|traction|truck|bogie|wheel|coupler|cctv|\bpis\b|component|spare|parts"),
            ("Signals and train control", r"signal|cbtc|\bptc\b|train control|interlocking|communications|scada"),
            ("Track and structures", r"track|rail replacement|tie|switch|bridge|tunnel|right of way|guideway|catenary|traction power|substation|electrif"),
            ("Stations and facilities", r"station|platform|yard|shop|facility|facilities|maintenance (base|building)"),
            ("Operations and maintenance", r"operat|maintenance|o&m|service")]
CAT_PURPOSE = {"vehicle_procurement": "New vehicles", "overhaul_program": "Overhaul and rebuild", "component_repair": "Vehicle systems and parts",
               "parts_supply": "Vehicle systems and parts", "onboard_systems": "Vehicle systems and parts", "signals_communications": "Signals and train control",
               "track_infrastructure": "Track and structures", "traction_power": "Track and structures", "stations_facilities": "Stations and facilities",
               "shop_equipment": "Stations and facilities", "maintenance_services": "Operations and maintenance", "rail_operations": "Operations and maintenance",
               "cleaning_interior": "Operations and maintenance", "engineering_support": "Engineering and consulting",
               "rail_engineering": "Engineering and consulting"}


def purpose_of(text, category=None):
    if category in CAT_PURPOSE:
        return CAT_PURPOSE[category]
    t = (text or "").lower()
    return next((label for label, rx in PURPOSES if re.search(rx, t)), "Other rail projects")


FUNDING_DIMS = [("program", "Program"), ("purpose", "Purpose"), ("status", "Status"), ("source", "Source"), ("agency", "Agency"),
                ("year", "Year")]
NOT_STATED = "Funding source not stated"


def funding_records(rows, agency_ids=None):
    """Every funding dollar we hold as one flat record with all its dimensions, so the Funding chart can group by one and split by
    another. rows: funding_award rows (intel.funding_rows). Researched awards and FTA grants count as 'Awarded (grant)'; budget and
    board items carry their pipeline stage (latest edition of each) and their stated funding source as the program."""
    out = []
    for r in rows:
        out.append({"program": re.sub(r"\s*\(FY[^)]*\)", "", r.get("program") or "Unnamed program"),
                    "purpose": purpose_of(f"{r.get('purpose') or ''} {r.get('program') or ''}"), "status": "Awarded (grant)",
                    "source": "Researched awards", "agency": r.get("operator_name") or r.get("operator_id") or "Unknown",
                    "year": (r.get("award_date") or "")[:4] or "Unknown", "usd": r.get("amount_usd") or 0})
    for g in grants(agency_ids, limit=10 ** 9):
        out.append({"program": CFDA.get(g.get("cfda") or "", f"FTA program {g.get('cfda') or 'unknown'}"), "purpose": purpose_of(g.get("description")),
                    "status": "Awarded (grant)", "source": "FTA grants", "agency": g.get("agency") or "Unknown",
                    "year": (g.get("start_date") or "")[:4] or "Unknown", "usd": g.get("amount_usd") or 0})
    for b in budget_items(agency_ids, limit=10 ** 9):
        yr = (b.get("doc_date") or "")[:4] or re.sub(r"\D", "", str(b.get("fiscal_year") or ""))[:4] or "Unknown"
        out.append({"program": (b.get("funding_source") or "").strip()[:60] or NOT_STATED,
                    "purpose": purpose_of(f"{b.get('project') or ''} {b.get('description') or ''}", b.get("category")),
                    "status": STAGES.get(b["stage"], b["stage"]), "source": "Budgets and board items", "agency": b.get("agency") or "Unknown",
                    "year": yr, "usd": b.get("amount_usd") or 0})
    return [r for r in out if r["usd"]]


def _dim_order(dim, totals):
    if dim == "status":
        order = [STAGES[s] for s in STAGE_ORDER] + ["Awarded (grant)"]
        return [k for k in order if k in totals] + sorted(k for k in totals if k not in order)
    if dim == "year":
        return sorted((k for k in totals if k != "Unknown"), reverse=True) + (["Unknown"] if "Unknown" in totals else [])
    keys = sorted(totals, key=lambda k: -totals[k])
    return [k for k in keys if k != NOT_STATED] + ([NOT_STATED] if NOT_STATED in totals else [])


def funding_slice(records, by="program", split="", filters=None, max_split=5):
    """Group records by one dimension and, optionally, split each bar by a second, after applying filters {dim: value}.
    Returns the bars (each with its split segments), the split keys (top max_split, the rest as 'Other'), a pivot table, and the
    values each filter can take (counted under the other filters, so a pick never leads to an empty chart)."""
    dims = dict(FUNDING_DIMS)
    by = by if by in dims else "program"
    split = split if split in dims and split != by else ""
    filters = {k: v for k, v in (filters or {}).items() if k in dims and v}
    rows = [r for r in records if all(r[k] == v for k, v in filters.items())]
    options = {}
    for d in dims:
        t = {}
        for r in records:
            if all(r[k] == v for k, v in filters.items() if k != d):
                t[r[d]] = t.get(r[d], 0) + r["usd"]
        options[d] = _dim_order(d, t)
    tot_by, tot_split, cell, n_by = {}, {}, {}, {}
    for r in rows:
        tot_by[r[by]] = tot_by.get(r[by], 0) + r["usd"]
        n_by[r[by]] = n_by.get(r[by], 0) + 1
        if split:
            tot_split[r[split]] = tot_split.get(r[split], 0) + r["usd"]
            cell[(r[by], r[split])] = cell.get((r[by], r[split]), 0) + r["usd"]
    keys = _dim_order(split, tot_split)[:max_split] if split else []
    if split == "status":  # keep the pipeline order but only the biggest stages
        top = set(sorted(tot_split, key=lambda k: -tot_split[k])[:max_split])
        keys = [k for k in _dim_order(split, tot_split) if k in top]
    other = [k for k in tot_split if k not in keys]
    bars = []
    for k in _dim_order(by, tot_by):
        segs = [(s, cell.get((k, s), 0)) for s in keys]
        if other:
            segs.append((f"{len(other)} other{'s' if len(other) != 1 else ''}", sum(cell.get((k, s), 0) for s in other)))
        bars.append({"label": k, "usd": tot_by[k], "n": n_by[k], "segs": segs})
    cols = keys + (["Other"] if other else [])
    pivot = [{"label": b["label"], "usd": b["usd"], "cells": [v for _, v in b["segs"]]} for b in bars] if split else []
    return {"by": by, "split": split, "filters": filters, "dims": FUNDING_DIMS, "bars": bars, "skeys": keys, "other": other, "cols": cols,
            "pivot": pivot, "col_totals": [sum(p["cells"][i] for p in pivot) for i in range(len(cols))] if pivot else [],
            "total": sum(tot_by.values()), "n": len(rows), "options": options}
