"""Freight portal hover definitions. Merged into /glossary.json by glossary.as_json (site terms win on a clash)."""
FRA = {
    "Accidents": "FRA-reportable train accidents (Form 54): collisions, derailments and other events above the FRA damage threshold.",
    "Train accidents": "FRA-reportable train accidents (Form 54) in the period.",
    "Crossing collisions": "Highway-rail grade crossing collisions reported to FRA on Form 57.",
    "Collisions": "Highway-rail grade crossing collisions reported to FRA (Form 57).",
    "Crossing deaths": "People killed in grade crossing collisions (Form 57).",
    "Killed": "Fatalities reported to FRA for the event or period.",
    "Injured": "Non-fatal injuries reported to FRA for the event or period.",
    "Fatal": "Events with at least one fatality.",
    "Non-fatal": "Events with injuries but no fatality.",
    "Damage": "Railroad-reported equipment and track damage, US dollars as filed with FRA.",
    "Per M train-miles": "Train accidents per million train-miles (FRA Form 55 operations). The standard FRA safety rate.",
    "Per M": "Rate per million train-miles.",
    "Train-miles": "Miles run by trains, from FRA Form 55 monthly operations reports.",
    "Cause": "FRA primary cause code group: track, equipment, human factors, signal or miscellaneous.",
    "Human factors": "Accidents FRA attributes to human-factor causes (H-codes), such as switching or speed errors.",
    "Track": "Accidents caused by track, roadbed or structures (T-codes).",
    "Equipment": "Accidents caused by mechanical or electrical equipment failures (E-codes).",
    "Crossing": "Highway-rail grade crossing, by FRA/USDOT crossing inventory number.",
    "Crossings": "Open public at-grade crossings on the railroad's track in the FRA crossing inventory.",
    "Warning": "Warning device class at the crossing: gates, flashing lights, or passive signs only.",
    "Warning device (at grade)": "Highest warning device at the crossing from the FRA inventory.",
    "Warning at the time": "Warning device in place when the collision happened, as reported on Form 57.",
    "Trains/day": "Total daily train movements from the FRA crossing inventory.",
    "Passenger/day": "Daily passenger trains over the crossing from the FRA inventory.",
    "Road traffic": "Annual average daily road traffic (AADT) over the crossing.",
    "Max speed": "Maximum timetable train speed over the crossing, mph.",
    "Train speed": "Train speed at the time of the collision, mph.",
    "Vehicle speed": "Road vehicle speed at the time of the collision, mph.",
    "Road user": "Type of road user struck: auto, truck, pedestrian and so on.",
    "What the road user did": "Road user action reported on Form 57, such as drove around gates or stopped on crossing.",
    "Last collision": "Date of the most recent reported collision at the crossing.",
    "Ungated pax": "Crossings with passenger service and no gates.",
    "Ungated with collisions": "Ungated crossings with at least one collision since 2010.",
    "With passenger trains": "Crossings used by passenger trains.",
    "Passenger, gated": "Passenger-service crossings protected by gates.",
    "Passenger, ungated (public)": "Public passenger-service crossings without gates.",
    "Why it's linked": "How the crossing was matched to the operator: track owner, passenger trackage within 120 m, or a collision report.",
    "Description as filed": "Narrative the railroad filed with FRA, unedited.",
    "CAGR": "Compound annual growth rate over the years shown.",
    "Net change": "Change in units from the first to the last year shown.",
    "Rebuild % of new": "Rebuild cost as a share of a new unit's cost.",
    "Rebuild as % of new": "Rebuild cost as a share of a new unit's cost.",
    "Payback, yrs": "Years for the fuel and repair savings of a new unit to repay its extra cost over a rebuild.",
    "Sched. 710S lines": "STB R-1 Schedule 710S line items used for the figure.",
    "Schedule": "STB R-1 annual report schedule the figure comes from.",
    "Line": "Line number on the STB R-1 schedule.",
    "Line item": "Line item on the STB R-1 schedule.",
}


def terms():
    out = dict(FRA)
    try:
        from . import r1assets, freight, shortline
        for m in r1assets.M.values():
            if m.get("definition"):
                out.setdefault(m["label"], m["definition"])
        for m in freight.M.values():
            if m.get("definition"):
                out.setdefault(m["label"], m["definition"])
        for lab, d in shortline.DEF.values():
            out.setdefault(lab, d)
        from . import costidx, railcars, xfund
        for lab, d in list(costidx.DEF.values()) + list(railcars.DEF.values()) + list(xfund.DEF.values()):
            out.setdefault(lab, d)
    except Exception:
        pass
    return out
