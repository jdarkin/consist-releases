"""Small allowlist HTML sanitizer for admin-written email text (Ambassador invite notes), plus an HTML-to-plain-text fallback.
Keeps paragraphs, line breaks, bold, italic, underline, lists and http(s)/mailto links; drops every other tag and all attributes."""
import html
import re
from html.parser import HTMLParser

ALLOWED = {"p", "br", "b", "strong", "i", "em", "u", "ul", "ol", "li", "a"}
ALIAS = {"div": "p", "h1": "p", "h2": "p", "h3": "p", "h4": "p"}  # editors (and pasted text) use these for lines
VOID = {"br"}
BLOCKS = {"p", "ul", "ol"}
DROP_CONTENT = {"script", "style", "head", "title", "iframe", "object", "svg", "math", "template"}
LINK_STYLE = "color:#0b6b5d"


class _San(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out, self.stack, self.skip = [], [], 0

    def handle_starttag(self, tag, attrs):
        if tag in DROP_CONTENT:
            self.skip += 1
            return
        if self.skip:
            return
        tag = ALIAS.get(tag, tag)
        if tag not in ALLOWED:
            return
        if tag == "li" and self.stack and self.stack[-1] == "li":
            self.out.append("</li>")
            self.stack.pop()
        if tag in BLOCKS:
            self._close_p()  # no block inside a paragraph
        elif tag != "li" and not self.stack:
            self._open_p()  # loose inline text at the top level becomes a paragraph
        if tag in VOID:
            self.out.append("<br>")
            return
        if tag == "a":
            href = (dict(attrs).get("href") or "").strip()
            if not re.match(r"(?i)^(https?://|mailto:)", href):
                self.stack.append(None)  # unsafe link: keep the text, drop the link
                return
            self.out.append(f'<a href="{html.escape(href, quote=True)}" style="{LINK_STYLE}">')
        else:
            self.out.append(f"<{tag}>")
        self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag in DROP_CONTENT:
            self.skip = max(0, self.skip - 1)
            return
        if self.skip:
            return
        tag = ALIAS.get(tag, tag)
        if tag not in ALLOWED or tag in VOID:
            return
        if tag in self.stack or (tag == "a" and None in self.stack):
            while self.stack:
                t = self.stack.pop()
                if t:
                    self.out.append(f"</{t}>")
                if t == tag or (tag == "a" and t is None):
                    break

    def handle_data(self, data):
        if self.skip:
            return
        if not self.stack:
            if not data.strip():
                return
            self._open_p()
        self.out.append(html.escape(data, quote=False))

    def _open_p(self):
        self.out.append("<p>")
        self.stack.append("p")

    def _close_p(self):
        if "p" in self.stack:
            while self.stack:
                t = self.stack.pop()
                if t:
                    self.out.append(f"</{t}>")
                if t == "p":
                    break

    def close(self):
        super().close()
        while self.stack:
            t = self.stack.pop()
            if t:
                self.out.append(f"</{t}>")
        return "".join(self.out)


def clean(raw):
    """Sanitized HTML, or "" when there is no visible text."""
    p = _San()
    p.feed(raw or "")
    out = p.close()
    out = re.sub(r"<p>\s*(<br>\s*)*</p>", "", out)  # empty paragraphs from the editor
    out = _fake_bullets(out)
    return out.strip() if to_text(out) else ""


_BULLET_P = re.compile(r"<p>(?:\s|&nbsp;|\xa0)*[·•▪◦●○§\-–](?:\s|&nbsp;|\xa0)+(.*?)</p>", re.S)


def _fake_bullets(h):
    """Word and some apps paste bullets as paragraphs starting with a bullet character: make them real lists."""
    def run(m):
        return "<ul>" + "".join(f"<li>{x.strip()}</li>" for x in _BULLET_P.findall(m.group(0))) + "</ul>"
    return re.sub(r"(?:" + _BULLET_P.pattern + r"\s*){1,}", run, h, flags=re.S)


GREETING = re.compile(r"^\s*(dear|hi|hello|hey|good (morning|afternoon|evening)|greetings)\b", re.I)


def is_letter(h):
    """True when the text opens with its own greeting, so it is the whole letter."""
    return bool(GREETING.match(to_text(h)))


def email_safe(h):
    """Lists drawn as small tables with a bullet or number cell, and paragraphs with explicit spacing: Outlook (Windows and Mac)
    drops list padding and often the bullets themselves, so real <ul>/<ol> lists don't survive there."""
    li_re = re.compile(r"<li>(.*?)</li>", re.S)

    def one(m):
        kind, inner = m.group(1), m.group(2)
        rows = []
        for i, item in enumerate(li_re.findall(inner), 1):
            item = re.sub(r"</p>\s*$", "", re.sub(r"^\s*<p>", "", item.strip()))
            item = re.sub(r"</p>\s*<p>", "<br><br>", item).replace("<p>", "").replace("</p>", "<br>")
            mark = f"{i}." if kind == "ol" else "&#8226;"
            rows.append('<tr><td valign="top" style="padding:0 8px 6px 6px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#222">'
                        f'{mark}</td><td valign="top" style="padding:0 0 6px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#222">{item}</td></tr>')
        return ('<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 12px;border-collapse:collapse">'
                + "".join(rows) + "</table>")
    prev = None
    while prev != h:  # innermost lists first
        prev = h
        h = re.sub(r"<(ul|ol)>((?:(?!<(?:ul|ol)>).)*?)</\1>", one, h, flags=re.S)
    return h.replace("<p>", '<p style="margin:0 0 14px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#222">')


def from_text(text):
    """Plain text (an older note) as HTML paragraphs."""
    paras = [p.strip() for p in re.split(r"\n\s*\n", (text or "").strip()) if p.strip()]
    return "".join("<p>" + html.escape(p).replace("\n", "<br>") + "</p>" for p in paras)


def to_text(h):
    """Plain-text version for the text/plain part of the email."""
    t = h or ""
    t = re.sub(r'(?is)<a [^>]*href="([^"]*)"[^>]*>(.*?)</a>',
               lambda m: m.group(2) if html.unescape(m.group(1)) in html.unescape(m.group(2)) else f"{m.group(2)} ({html.unescape(m.group(1))})", t)
    t = re.sub(r"(?i)<br\s*/?>", "\n", t)
    t = re.sub(r"(?i)<li>", "\n  • ", t)
    t = re.sub(r"(?i)</(p|ul|ol)>", "\n\n", t)
    t = re.sub(r"<[^>]+>", "", t)
    t = html.unescape(t)
    t = re.sub(r"[ \t]+\n", "\n", t)
    return re.sub(r"\n{3,}", "\n\n", t).strip()
