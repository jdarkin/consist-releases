"""Market lenses (all rail, transit, passenger rail, freight) and the region filter.

Freight is parked: unless FREIGHT_PUBLIC is set, only admins see the freight lens, persona and railroad data. For everyone
else db.py shadows the freight rows out of fleet.db and bids.db (see db.hide_freight), so "All rail" means transit and
passenger rail.

Every list page in the member app reads the viewer's scope from here. The scope is set once per request by
ScopeMiddleware (from the user's saved prefs, or a ?lens= / ?region= override) and travels with the request context,
so query helpers don't need it passed in.
"""
import contextvars
from urllib.parse import parse_qs

LENSES = {"all": "All rail", "transit": "Transit", "passenger": "Passenger rail", "freight": "Freight locomotives"}
LENS_MODES = {"transit": ("HR", "LR", "SR", "MG", "APM", "CC", "IP"), "passenger": ("CR", "YR", "IC", "ICR", "AR"), "freight": ("FR",)}
REGIONS = {"US": "United States", "CA": "Canada"}  # MX parked 2026-10-30
LENS_BLURBS = {"transit": "Metro, light rail, streetcar, monorail and people movers.",
               "passenger": "Commuter, intercity, Amtrak, VIA and state corridors.",
               "freight": "Locomotive fleets of Class I, regional and short line railroads. Freight cars are not covered."}
# Paid features that follow the lens. On a plan without lens_all, lenses other than the paid one show these at Starter depth.
LENS_FEATURES = {"fleet_detail", "pipeline", "opportunities", "market", "export", "awards"}

# Personas: what the member sells. Sets the default lens, the home dashboard and starter alerts.
PERSONAS = {
    "oem": {"label": "Rolling stock", "lens": "transit", "home": "oem",
            "hint": "New cars, locomotives and options on existing orders"},
    "component": {"label": "Components and subsystems", "lens": "all", "home": "component",
                  "hint": "Doors, HVAC, brakes, propulsion, TCMS, PIS and CCTV"},
    "mro": {"label": "Overhaul and MRO", "lens": "transit", "home": "mro", "hint": "Midlife overhauls, truck and component rebuilds"},
    "freight": {"label": "Freight locomotives", "lens": "freight", "home": "freight",
                "hint": "Locomotives, modernization, aftermarket parts and leasing"},
    "systems": {"label": "Signals, track and power", "lens": "all", "home": "systems",
                "hint": "Train control, track, traction power, stations and O&M"},
    "consult": {"label": "Engineering consultants", "lens": "all", "home": "consult",
                "hint": "Signals, systems and design work: RFQs, on-calls, awards and who holds them"},
    "investor": {"label": "Investors and analysts", "lens": "all", "home": "investor",
                 "hint": "Orders, backlog, market share and demand by builder and supplier"},
    "agency": {"label": "Agency fleet and capital planning", "lens": "all", "home": "agency",
               "hint": "Benchmark your fleets and costs against peers, and plan buys and overhauls"},
    "lessor": {"label": "Leasing and rail finance", "lens": "all", "home": "lessor",
               "hint": "Who owns and leases the fleets, and large buys where lease finance could compete"},
}
# Starter bid trades for each persona (Bid Catcher categories).
PERSONA_TRADES = {
    "oem": ["vehicle_procurement", "overhaul_program"],
    "component": ["component_repair", "parts_supply", "onboard_systems"],
    "mro": ["overhaul_program", "component_repair", "maintenance_services"],
    "freight": ["vehicle_procurement", "overhaul_program", "parts_supply"],
    "systems": ["signals_communications", "track_infrastructure", "traction_power", "stations_facilities", "rail_operations"],
    "consult": ["rail_engineering", "engineering_support", "signals_communications"],
    "investor": ["vehicle_procurement", "overhaul_program", "signals_communications", "traction_power"],
    "agency": ["vehicle_procurement", "overhaul_program"],
    "lessor": ["vehicle_procurement", "overhaul_program"],
}


class Scope:
    def __init__(self, lens="all", regions=(), basic=False, paid=None, free_features=(), freight=None, territory=None):
        from . import config
        # 1.7.45 sales territory (territory.py): (operator ids, agency ids, label) while the member's Territory switch is on
        self.ter_ops, self.ter_ags, self.ter_label = territory if territory else (None, None, "")
        self.ter_saved = ""  # the member's saved territory label, on or off ("" when none is saved)
        self.freight = config.FREIGHT_PUBLIC if freight is None else bool(freight or config.FREIGHT_PUBLIC)
        self.lens = lens if lens in LENSES and (lens != "freight" or self.freight) else "all"
        self.regions = tuple(r for r in regions if r in REGIONS)
        self.basic = basic          # this lens is shown at Starter depth on the viewer's plan
        self.paid = paid            # the one lens a Pro plan includes (None when the plan has every lens, or none)
        self.free_features = set(free_features)

    @property
    def modes(self):
        return LENS_MODES.get(self.lens)

    @property
    def label(self):
        return LENSES[self.lens]

    @property
    def region_label(self):
        return " · ".join(self.regions) if self.regions else "All regions"

    @property
    def territory(self):
        """The member's sales territory is switched on."""
        return self.ter_ops is not None

    def in_territory(self, operator_ids=(), agency_id=None):
        """True when the territory is off, or any of these operators (a joint order lists several) or this agency is in it."""
        if not self.territory:
            return True
        if isinstance(operator_ids, str):
            operator_ids = [x for x in operator_ids.replace(",", ";").split(";") if x]
        return any(o in self.ter_ops for o in operator_ids or ()) or (agency_id is not None and agency_id in self.ter_ags)

    def passes(self, mode, country, operator_id=None):
        if self.modes and mode not in self.modes:
            return False
        if self.territory and operator_id is not None and operator_id not in self.ter_ops:
            return False
        return not self.regions or country in self.regions

    def ter_sql(self, op_col=None, agency_col=None):
        """(where clause, args) for the territory: rows whose operator or agency is in it. '1=1' when it is off."""
        if not self.territory:
            return "1=1", []
        where, args = [], []
        if op_col and self.ter_ops:
            where.append(f"{op_col} IN ({','.join('?' * len(self.ter_ops))})")
            args += sorted(self.ter_ops)
        if agency_col and self.ter_ags:
            where.append(f"{agency_col} IN ({','.join('?' * len(self.ter_ags))})")
            args += sorted(self.ter_ags)
        return ("(" + " OR ".join(where) + ")") if where else "0", args

    def sql(self, mode_col="p.ntd_mode", country_col="o.country", op_col=None, territory=True):
        """(where clause, args) restricting rows to this lens, region and (unless territory=False) sales territory. '1=1' when
        unscoped. The territory matches op_col, by default the operator_id of the table country_col is on (o.operator_id)."""
        where, args = [], []
        if territory and self.territory:
            oc = op_col or ((country_col.split(".")[0] + ".operator_id") if country_col and "." in country_col else "operator_id")
            w, a = self.ter_sql(oc)
            where.append(w)
            args += a
        if self.modes and mode_col:
            where.append(f"{mode_col} IN ({','.join('?' * len(self.modes))})")
            args += list(self.modes)
        if self.regions and country_col:
            where.append(f"{country_col} IN ({','.join('?' * len(self.regions))})")
            args += list(self.regions)
        return (" AND ".join(where) or "1=1"), args

    @property
    def key(self):
        return (self.lens, self.regions, self.freight, self.ter_ops, self.ter_ags)

    @property
    def scoped(self):
        """Anything narrows the view: a market lens, a region or the territory."""
        return bool(self.modes or self.regions or self.territory)

    @property
    def has_freight(self):
        """Freight railroads are in view: freight is visible to this viewer and the lens includes it."""
        return self.freight and self.lens in ("all", "freight")


_scope = contextvars.ContextVar("consist_scope", default=None)
_rail = contextvars.ContextVar("consist_rail", default=False)  # this request is inside the /rail portal


def current():
    return _scope.get() or Scope()


def set_current(s):
    return _scope.set(s)


def reset(token):
    _scope.reset(token)


def in_rail():
    """True while serving a /rail page: the shared R-1 and locomotive pages then link within /rail and use its shell."""
    return _rail.get()


def rail_ok(u):
    """The viewer can use the /rail portal: admins, and plans with the 'rail' feature (the add-on)."""
    return bool(u and (u.is_admin or "rail" in ((u.plan or {}).get("features") or [])))


def rail_team_ok(u):
    """Freight Team tools inside /rail (fuel surcharges, escalation forecasts, the rail-cost dollar switch, CSV export): admins and
    plans with the 'rail_team' feature (Freight Team, Master Analyst)."""
    return bool(u and (u.is_admin or "rail_team" in ((u.plan or {}).get("features") or [])))


def lenses():
    """The lenses this viewer can pick (no freight while it is parked, except for admins)."""
    return {k: v for k, v in LENSES.items() if k != "freight" or current().freight}


def personas():
    return {k: v for k, v in PERSONAS.items() if v["lens"] != "freight" or current().freight}


def parse_regions(v):
    return tuple(r for r in (v or "").upper().replace(" ", "").split(",") if r in REGIONS)


def persona_lens(persona):
    return PERSONAS.get(persona or "", {}).get("lens", "all")


def paid_lens(u, prefs):
    """The lens a Pro plan includes: chosen on the account page, else the persona's lens, else transit."""
    lp = prefs.get("lens_paid")
    if lp in LENS_MODES and lp != "freight":
        return lp
    pl = persona_lens(prefs.get("persona"))
    return pl if pl in LENS_MODES and pl != "freight" else "transit"


def scope_for(u, prefs, query=None):
    """Build the request scope for a user (or None for an anonymous visitor) from saved prefs plus query overrides."""
    from . import db
    query = query or {}
    lens = query.get("lens") or prefs.get("lens") or persona_lens(prefs.get("persona"))
    regions = parse_regions(query["region"]) if "region" in query else parse_regions(prefs.get("regions"))
    if not u:
        return Scope(lens, regions)
    ter = None
    from . import territory as tmod
    t = tmod.saved(prefs)
    on = t["on"] if query.get("territory") not in ("0", "1") else query["territory"] == "1"
    saved_label = tmod.label(t) if tmod.is_set(t) else ""
    if on and saved_label:
        ops, ags = tmod.resolve(t)
        ter = (ops, ags, saved_label)
    fr = False  # freight moved to the /rail portal (2026-10-31); the member app is passenger and transit only, admins included
    feats = set((u.plan or {}).get("features", []))
    free = set(db.get_plan("free").get("features", []))
    if "lens_all" in feats or u.plan.get("id") == "free" or not (feats & LENS_FEATURES):
        sc = Scope(lens, regions, free_features=free, freight=fr, territory=ter)
        sc.ter_saved = saved_label
        return sc
    paid = paid_lens(u, prefs)
    sc = Scope(lens, regions, paid=paid, free_features=free, freight=fr, territory=ter)
    sc.ter_saved = saved_label
    sc.basic = sc.lens != paid
    return sc


class ScopeMiddleware:
    """Sets the lens and region for /app requests, and whether freight is visible for /app, /admin and /rail requests (admins
    only while freight is parked; /rail shows it to everyone with rail access). Must sit inside SessionMiddleware."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope["path"].startswith(("/app", "/admin", "/rail")):
            return await self.app(scope, receive, send)
        token = None
        rtok = _rail.set(scope["path"] == "/rail" or scope["path"].startswith("/rail/"))
        dtok = None
        if _rail.get():  # dollar basis for the rail portal (cookie rdol, set at /rail/dollars): filed or rail-cost (RCAF) dollars
            from . import costidx
            ck = dict(h for h in scope.get("headers", []) if h[0] == b"cookie").get(b"cookie", b"").decode()
            dtok = costidx.set_basis("rcaf" if "rdol=rail" in ck else "cpi")
        try:
            from . import auth, db
            uid = (scope.get("session") or {}).get("uid")
            u = auth.load_user(uid) if uid else None
            u = auth.view_as(u, scope.get("session"), scope["path"]) if u else None
            if dtok is not None and not rail_team_ok(u):  # the rail-cost dollar switch is a Freight Team tool
                from . import costidx
                costidx.set_basis("cpi")
            prefs = {r["key"]: r["value"] for r in db.q("SELECT key, value FROM user_pref WHERE user_id = ?", (uid,))} if u else {}
            q = {k: v[0] for k, v in parse_qs(scope.get("query_string", b"").decode(), keep_blank_values=True).items() if k in ("lens", "region", "territory")}
            if q.get("lens") not in LENSES:
                q.pop("lens", None)
            if scope["path"].startswith("/admin"):  # the admin portal sees everything, unscoped
                token = set_current(Scope(freight=bool(u and u.is_admin)))
            elif _rail.get():  # the rail portal: unscoped, freight visible to everyone who can open it
                token = set_current(Scope(freight=rail_ok(u)))
            else:
                token = set_current(scope_for(u, prefs, q))
        except Exception:
            token = None
        try:
            await self.app(scope, receive, send)
        finally:
            if token is not None:
                reset(token)
            _rail.reset(rtok)
            if dtok is not None:
                from . import costidx
                costidx._basis.reset(dtok)

# Operator types (operator.category) as members read them.
CATEGORY_LABELS = {"heavy_rail": "Metro", "light_rail": "Light rail", "streetcar": "Streetcar", "monorail": "Monorail",
                   "automated_guideway": "People mover", "airport_apm": "Airport people mover", "inclined_plane": "Incline",
                   "commuter": "Commuter rail", "intercity_national": "National intercity", "intercity_state": "State corridor",
                   "intercity_private": "Private intercity", "freight_class1": "Class I", "freight_regional": "Regional railroad",
                   "freight_shortline": "Short line", "freight_switching": "Switching and terminal"}
