"""Operations and maintenance contracting: which agencies buy rail operations or maintenance from a contractor (NTD purchased
transportation, by function), who holds each contract (researched contracts plus O&M awards from Bid Catcher), and when each
contract is likely to be competed again."""
import datetime
import hashlib
import json
import os

from . import data, db, lens

RAIL_MODES = ("CR", "HR", "LR", "SR", "MG", "YR", "CC", "IP", "AR", "IC", "ICR")
SCOPE_KINDS = ("om", "operations", "maintenance", "mow", "concession", "facility")
# Typical base term (years) when a contract's end is not published, and how long before the end the agency usually goes out to bid.
TERM_YEARS = {"om": 8, "operations": 5, "maintenance": 5, "mow": 5, "facility": 5, "concession": 30}
LEAD_MONTHS = {"om": 24, "operations": 18, "maintenance": 18, "mow": 12, "facility": 12, "concession": 36}
FUNCTIONS = {"vehicle_operations": "Train operations", "vehicle_maintenance": "Vehicle maintenance",
             "facility_maintenance": "Facility and way maintenance", "general_administration": "Administration"}
AWARD_KINDS = {"rail_operations": "om", "maintenance_services": "maintenance"}
SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "om_contract_seed.json")


def seed():
    """Loads seed/om_contract_seed.json into fleet_contract once per version (admin edits and deletes stick)."""
    if not os.path.exists(SEED):
        return
    raw = open(SEED, "rb").read()
    digest = hashlib.sha256(raw).hexdigest()[:16]
    if db.settings().get("om_seed_hash") == digest:
        return
    c = db.connect()
    try:
        doc = json.loads(raw)
        have = {r[1] for r in c.execute("PRAGMA table_info(fleet_contract)")}
        for r in doc.get("retire", []):  # 1.7.84: seed rows proven wrong by a better source
            c.execute("DELETE FROM fleet_contract WHERE operator_id = ? AND coalesce(vendor, '') = ? AND confidence = 'C'", (r["operator_id"], r["vendor"]))
        for r in doc["fleet_contract"]:
            r = {k: v for k, v in r.items() if k in have}
            hit = c.execute("SELECT id, confidence FROM fleet_contract WHERE operator_id = ? AND kind = ? AND coalesce(vendor, '') = ?",
                            (r["operator_id"], r["kind"], r.get("vendor") or "")).fetchone()
            if not hit and r.get("vendor"):  # 1.7.84: same holder under a shorter or longer name (e.g. "Keolis" vs "Keolis Commuter Services")
                w = r["vendor"].split()[0].lower()
                hit = c.execute("SELECT id, confidence FROM fleet_contract WHERE operator_id = ? AND kind IN ('om', 'operations') AND ? IN ('om', 'operations') "
                                "AND lower(vendor) LIKE ? AND coalesce(mode, ?) = ?", (r["operator_id"], r["kind"], w + "%", r.get("mode"), r.get("mode"))).fetchone()
            if hit:
                if (r.get("confidence") or "C") < (hit[1] or "C"):  # better-graded source upgrades the row, keeping fields it does not give
                    sets = {k: v for k, v in r.items() if v is not None and k not in ("operator_id", "vendor", "kind")}
                    c.execute(f"UPDATE fleet_contract SET {', '.join(k + ' = ?' for k in sets)} WHERE id = ?", [*sets.values(), hit[0]])
                continue
            r = dict(r, created=db.now())
            cols = list(r)
            c.execute(f"INSERT INTO fleet_contract ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", [r[k] for k in cols])
        c.commit()
    finally:
        c.close()
    db.set_setting("om_seed_hash", digest)


def _rows(sql, args=(), name="fleet"):
    try:
        return [dict(r) for r in db.fq(sql, args, db=name)]
    except Exception:
        return []


def _date(s):
    try:
        return datetime.date.fromisoformat((s or "")[:10])
    except ValueError:
        return None


def _add_months(d, m):
    y, mo = divmod(d.month - 1 + m, 12)
    return datetime.date(d.year + y, mo + 1, min(d.day, 28))


def outsourcing():
    """One row per agency and rail mode from the latest NTD year: directly operated vs purchased cost by function."""
    yr = (_rows("SELECT max(report_year) y FROM ntd_opex_function") or [{"y": None}])[0]["y"]
    if not yr:
        return [], None
    ops = {}
    for o in _rows("SELECT operator_id, operator_name, ntd_id, modes, country FROM operator WHERE ntd_id IS NOT NULL AND ntd_id != ''"):
        ops.setdefault(o["ntd_id"], []).append(o)
    rows = _rows(f"SELECT ntd_id, agency, state, mode, type_of_service tos, vehicle_operations, vehicle_maintenance, facility_maintenance, "
                 f"general_administration, total FROM ntd_opex_function WHERE report_year = ? AND mode IN ({','.join('?' * len(RAIL_MODES))})",
                 (yr, *RAIL_MODES))
    prev = {(r["ntd_id"], r["mode"]): r["pt"] for r in _rows(
        "SELECT ntd_id, mode, sum(total) pt FROM ntd_opex_function WHERE report_year = ? AND type_of_service = 'PT' GROUP BY 1, 2", (yr - 5,))}
    by = {}
    for r in rows:
        k = (r["ntd_id"], r["mode"])
        d = by.setdefault(k, {"ntd_id": r["ntd_id"], "agency": r["agency"], "state": r["state"], "mode": r["mode"], "do": 0.0, "pt": 0.0,
                              "pt_fn": {f: 0.0 for f in FUNCTIONS}, "do_fn": {f: 0.0 for f in FUNCTIONS}})
        side = "pt" if r["tos"] == "PT" else "do"
        d[side] += r["total"] or 0
        for f in FUNCTIONS:
            d[side + "_fn"][f] += r[f] or 0
    sc = lens.current()
    out = []
    for (nid, mode), d in by.items():
        cand = ops.get(nid, [])
        op = next((o for o in cand if mode in (o["modes"] or "").split(";")), cand[0] if cand else None)
        d["operator_id"] = op["operator_id"] if op else None
        d["operator_name"] = op["operator_name"] if op else d["agency"]
        country = op["country"] if op else "US"
        if not sc.passes(data.MODE_ALIASES.get(mode, mode), country, (d["operator_id"] or "") if sc.territory else None):
            continue
        tot = d["do"] + d["pt"]
        if not tot:
            continue
        d["pt_pct"] = round(100 * d["pt"] / tot)
        d["fn_pct"] = {}
        for f in FUNCTIONS:
            ft = d["pt_fn"][f] + d["do_fn"][f]
            d["fn_pct"][f] = round(100 * d["pt_fn"][f] / ft) if ft else None
        if d["pt"] and not any(d["pt_fn"].values()):
            d["fn_pct"] = {f: None for f in FUNCTIONS}  # purchased cost reported as one total
        p0 = prev.get((nid, mode))
        d["pt_5y_pct"] = round(100 * (d["pt"] - p0) / p0) if p0 and d["pt"] else None
        d["model"] = "Contracted" if d["pt_pct"] >= 90 else "Mixed" if d["pt_pct"] >= 10 else "In-house"
        out.append(d)
    out.sort(key=lambda d: (-d["pt"], -d["do"]))
    return out, yr


def _forecast(c, today):
    """Adds end (known or estimated), the likely competition window and a status to one contract dict."""
    kind = c["kind"] if c["kind"] in TERM_YEARS else "maintenance"
    end = _date(c.get("options_end")) or _date(c.get("end_date"))
    c["end_basis"] = "options" if c.get("options_end") else "published" if end else None
    start = _date(c.get("start_date"))
    if not end and start:  # assume the typical term, renewed on the same cycle
        end = start
        while end <= today:
            end = _add_months(end, 12 * TERM_YEARS[kind])
        c["end_basis"] = f"estimated ({TERM_YEARS[kind]}-year terms from {start.year})"
    c["end"] = end
    if not end:
        c["status"], c["window"] = "unknown", None
        return c
    w = _add_months(end, -LEAD_MONTHS[kind])
    c["window"] = w
    c["months_left"] = (end.year - today.year) * 12 + end.month - today.month
    c["status"] = ("expired" if end < today else "window" if w <= today else "soon" if (w - today).days <= 730 else "later")
    return c


def contracts():
    """Researched O&M contracts (fleet_contract) and O&M awards from Bid Catcher, each with a re-competition forecast."""
    today = datetime.date.today()
    names = {o["operator_id"]: o for o in _rows("SELECT operator_id, operator_name, country FROM operator")}
    out = []
    for r in db.q(f"SELECT * FROM fleet_contract WHERE kind IN ({','.join('?' * len(SCOPE_KINDS))})", SCOPE_KINDS):
        c = dict(r)
        o = names.get(c["operator_id"])
        c["operator_name"] = o["operator_name"] if o else c["operator_id"]
        c["country"] = o["country"] if o else "US"
        c["origin"] = "research"
        out.append(_forecast(c, today))
    for a in _rows("SELECT a.award_id, a.agency_id, coalesce(g.agency, a.buyer) agency, a.title, a.vendor, a.amount_usd, a.award_date, "
                   "a.term_months, a.category, a.operator_id, a.country, a.source_url, a.confidence, g.fleet_operator_ids FROM award a "
                   "LEFT JOIN agency g USING (agency_id) WHERE a.category IN ('rail_operations', 'maintenance_services') AND a.relevance >= 50",
                   name="bids"):
        start = _date(a["award_date"])
        end = _add_months(start, a["term_months"]) if start and a["term_months"] else None
        op = a["operator_id"] or ((a["fleet_operator_ids"] or "").split(";")[0] or None)
        c = {"id": None, "award_id": a["award_id"], "operator_id": op, "operator_name": names[op]["operator_name"] if op in names else a["agency"],
             "country": a["country"] or "US", "mode": None, "kind": AWARD_KINDS[a["category"]], "vendor": a["vendor"], "scope": a["title"],
             "start_date": a["award_date"], "end_date": end.isoformat() if end else None, "options_end": None,
             "value_usd": a["amount_usd"], "annual_usd": round(a["amount_usd"] * 12 / a["term_months"]) if a["amount_usd"] and a["term_months"] else None,
             "confidence": a["confidence"], "source_url": a["source_url"], "notes": None, "origin": "award"}
        out.append(_forecast(c, today))
    sc = lens.current()
    out = [c for c in out if (not sc.regions or c["country"] in sc.regions)
           and sc.in_territory(c.get("operator_id") or c.get("fleet_operator_ids") or "")
           and (not sc.modes or data.MODE_ALIASES.get(c["mode"], c["mode"]) in sc.modes)]
    order = {"window": 0, "soon": 1, "later": 2, "unknown": 3, "expired": 4}
    out.sort(key=lambda c: (order[c["status"]], c["end"] or datetime.date.max))
    return out


def by_contractor(cs):
    by = {}
    for c in cs:
        v = c["vendor"] or "Unknown"
        d = by.setdefault(v, {"vendor": v, "n": 0, "agencies": [], "kinds": set(), "next_end": None})
        d["n"] += 1
        if c["operator_name"] not in d["agencies"]:
            d["agencies"].append(c["operator_name"])
        d["kinds"].add(c["kind"])
        if c["end"] and c["status"] != "expired" and (not d["next_end"] or c["end"] < d["next_end"]):
            d["next_end"] = c["end"]
    return sorted(by.values(), key=lambda d: (-d["n"], d["vendor"]))


def open_bids(limit=12):
    rows, _ = data.notices({"category": "rail_operations", "status": "open", "sort": "closing"}, per=limit)
    more, _ = data.notices({"category": "maintenance_services", "status": "open", "sort": "closing"}, per=limit)
    return sorted(rows + more, key=lambda n: n["closing"] or "9999")[:limit]
