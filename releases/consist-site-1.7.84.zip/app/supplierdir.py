"""Supplier directory: one row per company that supplies North American rail, built from
  - RSSI (Railway Systems Suppliers, Inc.) public member directory: membership flag and website only (rssi.org/member-directory),
  - APTA Public Transportation Vehicle Database: DERIVED counts only (rail cars active / on order by builder), never APTA rows,
  - Consist's own records (Supplier intelligence entities, fleet.db supplier register, Bid Catcher awards, SEC/annual-report financials).
Seed: seed/supplier_dir.csv.gz (tools/suppliers/build_directory.py). Live table supplier_dir in app.db; reconciliation:
RSSI monthly (alerts loop, Admin > Supplier directory > Run now), APTA when a new Vehicle Database file is uploaded in Admin."""
import csv, datetime, gzip, html, io, json, os, re, urllib.request, zipfile
import xml.etree.ElementTree as ET

from . import db

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "supplier_dir.csv.gz")
RSSI_URL = "https://rssi.org/member-directory/"
UA = "Consist (Sand and Style LLC) supplier directory check"
COLS = ["sid", "name", "website", "country", "sources", "segments", "status", "entity_id", "fleet_supplier_id",
        "apta_active", "apta_ordered", "apta_fleets", "apta_agencies", "apta_names"]
DDL = ["""CREATE TABLE IF NOT EXISTS supplier_dir (sid TEXT PRIMARY KEY, name TEXT, website TEXT, country TEXT, sources TEXT, segments TEXT,
  status TEXT, entity_id TEXT, fleet_supplier_id TEXT, apta_active INTEGER, apta_ordered INTEGER, apta_fleets INTEGER, apta_agencies INTEGER,
  apta_names TEXT, first_seen TEXT, updated TEXT)""",
       """CREATE TABLE IF NOT EXISTS supplier_dir_change (id INTEGER PRIMARY KEY, ts TEXT, source TEXT, kind TEXT, sid TEXT, name TEXT, detail TEXT)"""]
SEG_LABEL = {"pax_oem": "Passenger rolling stock", "loco": "Locomotives", "rolling_stock": "Rail cars (APTA builders)", "trucks_wheels": "Trucks, wheels and axles",
             "lessors": "Freight car lessors", "mro": "Overhaul, maintenance and services", "signal_wayside": "Signals, communications and wayside",
             "power": "Power, batteries and electrical", "comms_it": "Networks, software and IT", "construction": "Construction and engineering",
             "test": "Test, measurement and inspection", "hardware": "Cable, enclosures and hardware", "brakes_doors_hvac": "Brakes, doors, HVAC",
             "propulsion": "Propulsion and traction", "freight_cars": "Freight cars and leasing", "track": "Track and MOW", "services": "Services and MRO",
             "pis_control": "Passenger information and controls"}
SRC_LABEL = {"rssi": "RSSI member", "apta": "APTA Vehicle Database builder", "consist": "Consist research"}
KW = [("power", r"power|batter|solar|charg|electric(?!al eng)|energy|generator|ups\b"),
      ("comms_it", r"network|telecom|software|systems?\b|cisco|cambium|wireless|radio|data|digital|cyber|tech"),
      ("construction", r"construct|contract|engineer|benesch|builders?|services|crx"),
      ("test", r"test|instrument|calibrat|inspection|measure"),
      ("hardware", r"cable|wire|connector|enclos|precast|fiberglass|shelter|bungalow|hardware|mfg|manufactur|products")]
# APTA "Manufacturer Name" -> Supplier intelligence entity (current owner of the builder's business)
APTA_MAP = [(r"bombardier|utdc|hawker siddeley|canadian car|abb |adtranz|alstom|mbb|m\.b\.b", "alstom"), (r"kawasaki", "kawasaki"),
            (r"siemens|duewag", "siemens"), (r"nippon sharyo", "nippon_sharyo"), (r"kinki sharyo", "kinki_sharyo"), (r"stadler", "stadler"),
            (r"rotem|hyundai", "hyundai_rotem"), (r"motive ?power|wabtec|general electric", "wabtec"), (r"electro-motive|general motors|progress rail", "progress_rail"),
            (r"brookville", "brookville"), (r"hitachi|breda", "hitachi"), (r"crrc|china cnr|cnr ", "crrc"), (r"construcciones y auxiliar|caf\b|-caf", "caf"),
            (r"talgo", "talgo")]


def norm(s):
    s = html.unescape(s or "").lower()
    s = re.sub(r"\b(inc|llc|ltd|limited|corp|corporation|company|co|gmbh|ag|sa|s\.a|plc|lp|l\.l\.c)\b\.?", " ", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def slug(s):
    return re.sub(r"[^a-z0-9]+", "_", norm(s)).strip("_")[:48]


def tag_segments(name, base="signal_wayside"):
    tags = [base]
    for k, rx in KW:
        if re.search(rx, name or "", re.I):
            tags.append(k)
    return tags


def parse_rssi(page):
    """[(name, website)] from the RSSI member directory page (names inside the A-Z tab panels)."""
    i = page.find("e-n-tabs-content")
    seg = page[i:] if i >= 0 else page
    out, seen = [], set()
    for url, n in re.findall(r'<a [^>]*href="([^"]+)"[^>]*>(.*?)</a>', seg, flags=re.S):
        name = html.unescape(re.sub("<[^>]+>", "", n)).strip()
        if not name or not url.startswith("http") or "rssi.org" in url or url.lower().endswith(".pdf"):
            continue
        if norm(name) in seen:
            continue
        seen.add(norm(name))
        out.append((name, url.strip()))
    return out


def fetch_rssi():
    req = urllib.request.Request(RSSI_URL, headers={"User-Agent": UA})
    return parse_rssi(urllib.request.urlopen(req, timeout=60).read().decode("utf-8", "ignore"))


def apta_entity(mfr):
    m = (mfr or "").lower()
    for rx, e in APTA_MAP:
        if re.search(rx, m):
            return e
    return None


def apta_aggregate(rows):
    """Derived builder counts from APTA rail fleet rows (dicts with manufacturer, status, total, active, agency)."""
    agg = {}
    for r in rows:
        mfr = (r.get("manufacturer") or "").strip()
        if not mfr or mfr.lower() == "unknown":
            continue
        key = apta_entity(mfr) or "apta_" + slug(mfr)
        d = agg.setdefault(key, {"active": 0, "ordered": 0, "fleets": 0, "agencies": set(), "names": set()})
        n_total, n_active = _int(r.get("total")), _int(r.get("active"))
        if (r.get("status") or "").upper() in ("O", "P"):
            d["ordered"] += n_total
        else:
            d["active"] += n_active
        d["fleets"] += 1
        d["agencies"].add(r.get("agency"))
        d["names"].add(mfr)
    return agg


def _int(v):
    try:
        return int(float(v or 0))
    except (TypeError, ValueError):
        return 0


def read_xlsx_fleet(data):
    """APTA Vehicle Database .xlsx (sheet "Fleet") -> rail rows, without openpyxl. Keeps only the columns needed for derived counts."""
    z = zipfile.ZipFile(io.BytesIO(data))
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    rel = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", ns):
            shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    target = None
    for s in wb.find("m:sheets", ns):
        if s.get("name", "").lower() == "fleet":
            rid = s.get(rel)
            for r in rels:
                if r.get("Id") == rid:
                    target = "xl/" + r.get("Target").lstrip("/").replace("xl/", "")
    if not target:
        raise ValueError("No sheet named Fleet in this file")

    def col(ref):
        n = 0
        for ch in re.match(r"[A-Z]+", ref).group(0):
            n = n * 26 + ord(ch) - 64
        return n - 1
    head, out = None, []
    for row in ET.fromstring(z.read(target)).iter("{%s}row" % ns["m"]):
        vals = {}
        for c in row.findall("m:c", ns):
            v = c.find("m:v", ns)
            if v is None:
                t = c.find("m:is/m:t", ns)
                val = t.text if t is not None else None
            else:
                val = shared[int(v.text)] if c.get("t") == "s" else v.text
            vals[col(c.get("r"))] = val
        cells = [vals.get(i) for i in range(max(vals) + 1)] if vals else []
        if head is None:
            head = [str(x or "").strip() for x in cells]
            continue
        d = dict(zip(head, cells))
        if d.get("Mode Code") not in {"HR", "LR", "SR", "CR", "CRL", "YR", "OR", "MG", "AG", "CC", "IP", "MO"}:
            continue
        out.append({"manufacturer": d.get("Manufacturer Name"), "status": d.get("Status"), "total": d.get("Total Vehicles, Number of"),
                    "active": d.get("Active Vehicles,  Number of") or d.get("Active Vehicles, Number of"), "agency": d.get("Transit Agency Name")})
    return out


# ---------------- storage ----------------

def _ddl():
    for s in DDL:
        db.x(s)


def seed():
    """Load seed rows that are not in the table yet (reconciliation and admin edits stick)."""
    _ddl()
    if not os.path.exists(SEED):
        return
    have = {r["sid"] for r in db.q("SELECT sid FROM supplier_dir")}
    now = db.now()
    with gzip.open(SEED, "rt", newline="") as f:
        for r in csv.DictReader(f):
            if r["sid"] in have:
                continue
            db.x(f"INSERT INTO supplier_dir ({','.join(COLS)}, first_seen, updated) VALUES ({','.join('?' * (len(COLS) + 2))})",
                 [r.get(k) or None for k in COLS] + [now, now])


def rows():
    _ddl()
    if not db.q("SELECT 1 FROM supplier_dir LIMIT 1"):
        seed()
    return [dict(r) for r in db.q("SELECT * FROM supplier_dir ORDER BY name COLLATE NOCASE")]


def changes(limit=200):
    _ddl()
    return [dict(r) for r in db.q("SELECT * FROM supplier_dir_change ORDER BY id DESC LIMIT ?", (limit,))]


def _log(source, kind, sid, name, detail=""):
    db.x("INSERT INTO supplier_dir_change (ts, source, kind, sid, name, detail) VALUES (?,?,?,?,?,?)", (db.now(), source, kind, sid, name, detail))


def _srcs(r):
    return [s for s in (r.get("sources") or "").split(";") if s]


def reconcile_rssi(members=None):
    """Compare the live RSSI member list with the directory: add new members, mark members who left, log both."""
    _ddl()
    members = members if members is not None else fetch_rssi()
    if len(members) < 50:
        raise RuntimeError(f"RSSI page returned only {len(members)} members; layout may have changed, nothing updated")
    cur = {r["sid"]: r for r in rows()}
    by_norm = {norm(r["name"]): r for r in cur.values()}
    live = set()
    added = removed = 0
    for name, url in members:
        r = by_norm.get(norm(name))
        if r:
            live.add(r["sid"])
            if "rssi" not in _srcs(r):
                db.x("UPDATE supplier_dir SET sources = ?, updated = ? WHERE sid = ?", (";".join(_srcs(r) + ["rssi"]), db.now(), r["sid"]))
                _log("rssi", "joined", r["sid"], r["name"], "now listed as an RSSI member")
                added += 1
            continue
        sid = slug(name)
        while sid in cur:
            sid += "_1"
        db.x(f"INSERT INTO supplier_dir (sid, name, website, sources, segments, status, first_seen, updated) VALUES (?,?,?,?,?,?,?,?)",
             (sid, name, url, "rssi", ";".join(tag_segments(name)), "active", db.now(), db.now()))
        cur[sid] = {"sid": sid, "name": name}
        live.add(sid)
        _log("rssi", "added", sid, name, url)
        added += 1
    for r in list(cur.values()):
        if "rssi" in _srcs(r) and r["sid"] not in live:
            left = [s for s in _srcs(r) if s != "rssi"]
            db.x("UPDATE supplier_dir SET sources = ?, updated = ? WHERE sid = ?", (";".join(left), db.now(), r["sid"]))
            _log("rssi", "left", r["sid"], r["name"], "no longer on the RSSI member list")
            removed += 1
    db.set_setting("supplierdir_rssi_last", json.dumps({"ts": db.now(), "members": len(members), "added": added, "removed": removed}))
    return {"members": len(members), "added": added, "removed": removed}


def reconcile_apta(fleet_rows, edition=""):
    """Recompute derived builder counts from a new APTA Vehicle Database; log builders whose counts changed."""
    _ddl()
    agg = apta_aggregate(fleet_rows)
    cur = {r["sid"]: r for r in rows()}
    changed = 0
    for key, d in agg.items():
        r = cur.get(key) or next((x for x in cur.values() if x.get("entity_id") == key), None)
        vals = (d["active"], d["ordered"], d["fleets"], len(d["agencies"]), "; ".join(sorted(d["names"]))[:400])
        if r is None:
            name = sorted(d["names"])[0]
            db.x("INSERT INTO supplier_dir (sid, name, sources, segments, status, apta_active, apta_ordered, apta_fleets, apta_agencies, apta_names, "
                 "first_seen, updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (key, name, "apta", "rolling_stock", "historic builder") + vals + (db.now(), db.now()))
            _log("apta", "added", key, name, f"{d['active']} active, {d['ordered']} on order")
            changed += 1
            continue
        old = (r.get("apta_active"), r.get("apta_ordered"))
        db.x("UPDATE supplier_dir SET apta_active=?, apta_ordered=?, apta_fleets=?, apta_agencies=?, apta_names=?, sources=?, updated=? WHERE sid=?",
             vals + (";".join(sorted(set(_srcs(r) + ["apta"]))), db.now(), r["sid"]))
        if old != (d["active"], d["ordered"]):
            _log("apta", "updated", r["sid"], r["name"], f"active {old[0] or 0} -> {d['active']}, on order {old[1] or 0} -> {d['ordered']}")
            changed += 1
    db.set_setting("supplierdir_apta_last", json.dumps({"ts": db.now(), "edition": edition, "rows": len(fleet_rows), "builders": len(agg), "changed": changed}))
    return {"rows": len(fleet_rows), "builders": len(agg), "changed": changed}


def last_runs():
    s = db.settings()
    out = {}
    for k in ("rssi", "apta"):
        try:
            out[k] = json.loads(s.get(f"supplierdir_{k}_last") or "null")
        except ValueError:
            out[k] = None
    return out


def _older(ts, days):
    try:
        return datetime.datetime.fromisoformat((ts or "")[:19]) < datetime.datetime.now() - datetime.timedelta(days=days)
    except ValueError:
        return True


def monthly_due():
    """True once a month; after a failed attempt, waits a day before trying again."""
    tried = db.settings().get("supplierdir_rssi_try")
    if tried and not _older(tried, 1):
        return False
    r = last_runs().get("rssi")
    due = not r or _older(r.get("ts"), 30)
    if due:
        db.set_setting("supplierdir_rssi_try", db.now())
    return due


# ---------------- view ----------------

def directory(q=None):
    """Rows for the directory page with Consist-derived columns joined in."""
    from . import supplierintel as S, intel
    q = q or {}
    try:
        ib = {s["supplier_id"]: s for s in intel.suppliers()}
    except Exception:
        ib = {}
    try:
        aw, _, _ = S.awards()
    except Exception:
        aw = {}
    out = []
    for r in rows():
        e = S.ENT.get(r.get("entity_id") or "") if r.get("entity_id") else None
        summ = S.summary(e[0]) if e else {}
        f = ib.get(r.get("fleet_supplier_id") or "")
        a = aw.get(r.get("entity_id") or "", (0, 0.0))
        d = dict(r, sources_l=_srcs(r), segments_l=[s for s in (r.get("segments") or "").split(";") if s],
                 listing=e[4] if e else None, owner=e[2] if e else None, revenue=summ.get("revenue"), rev_year=summ.get("year"),
                 margin=summ.get("margin"), fleets=f["n_fleets"] if f else 0, cars=f["cars"] if f else 0, awards=a[0], award_usd=a[1],
                 public=bool(e and e[4] and not e[4].lower().startswith("private")))
        out.append(d)
    t = (q.get("q") or "").lower().strip()
    if t:
        out = [d for d in out if t in (d["name"] or "").lower() or t in (d.get("apta_names") or "").lower()]
    if q.get("source"):
        out = [d for d in out if q["source"] in d["sources_l"]]
    if q.get("segment"):
        out = [d for d in out if q["segment"] in d["segments_l"]]
    if q.get("own") == "public":
        out = [d for d in out if d["public"]]
    elif q.get("own") == "private":
        out = [d for d in out if not d["public"]]
    if q.get("fin"):
        out = [d for d in out if d["revenue"]]
    if q.get("na"):
        out = [d for d in out if (d.get("apta_active") or 0) or (d.get("apta_ordered") or 0) or d["fleets"]]
    if q.get("status"):
        out = [d for d in out if (d.get("status") or "") == q["status"]]
    key = q.get("sort") or "name"
    if key != "name":
        out.sort(key=lambda d: -(d.get(key) or 0))
    return out
