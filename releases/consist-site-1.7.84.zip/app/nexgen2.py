"""NexGen punch list (2026-11-07): the open items from the five persona reviews that the first waves left out.
Everything here is computed from data Consist already has; where a value is estimated (not researched) the page says so.
Items that need new research or licensed data are listed in GAPS so the pages can say what is missing."""
import datetime
import re
import urllib.parse
import secrets
import statistics

from . import data, db, intel, lens, nexgen, trainctl

GAPS = {
    "platform": "Platform height per station is not in our data yet (needs research).",
    "signal": "On-board train control (CBTC, ATC, PTC and supplier) comes from the November 2026 sweep of 62 operators. A few systems still need confirming, such as CTA cab signals, Miami Metrorail, PATCO and MBTA Green Line.",
    "subsystem": "The November 2026 subsystem sweep maps named suppliers for the largest transit fleets (live share on the platform map); commuter, intercity and smaller fleets still need research.",
    "spend": "Agency spend (open checkbook) data is a new source; the pilot needs a data pull per agency.",
    "credit": "Bond ratings (Moody's, S&P, Fitch) are licensed; this view uses NTD finance data only.",
    "pdf": "PDF uses the browser's Save as PDF; a server-made PDF needs a PDF library added to the image.",
}


def _q(vals, p):
    vals = sorted(v for v in vals if v)
    if not vals:
        return None
    k = (len(vals) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(vals) - 1)
    return vals[lo] + (vals[hi] - vals[lo]) * (k - lo)


# ---------------- investor: quarters and demand range ----------------

def quarter_of(d):
    d = str(d or "")
    if len(d) >= 7 and d[:4].isdigit() and d[5:7].isdigit():
        return f"{d[:4]}-Q{(int(d[5:7]) - 1) // 3 + 1}"
    return None


def orders_by_quarter(quarters=12):
    """Cars and value ordered per quarter, by builder (top 5 + Other), for the last N quarters."""
    rows = [dict(o, q=quarter_of(o.get("award_date"))) for o in nexgen.orders()]
    rows = [r for r in rows if r["q"]]
    yr, mo = datetime.date.today().year, datetime.date.today().month
    cur = yr * 4 + (mo - 1) // 3
    qs = [f"{(cur - i) // 4}-Q{(cur - i) % 4 + 1}" for i in range(quarters - 1, -1, -1)]
    rows = [r for r in rows if r["q"] in qs]
    tot = {}
    for r in rows:
        tot[r["builder"]] = tot.get(r["builder"], 0) + r["cars"]
    top = [b for b, _ in sorted(tot.items(), key=lambda kv: -kv[1])[:5]]
    by = {q: {} for q in qs}
    val = {q: 0 for q in qs}
    for r in rows:
        k = r["builder"] if r["builder"] in top else "Other"
        by[r["q"]][k] = by[r["q"]].get(k, 0) + r["cars"]
        val[r["q"]] += r["value"] or 0
    keys = top + (["Other"] if any("Other" in v for v in by.values()) else [])
    return by, keys, val, rows


CLASS_TO_TYPE = {"coach": "coach", "cab_car": "coach", "metro_car": "metro", "lrv": "lrv", "streetcar": "lrv", "heritage_streetcar": "lrv",
                 "locomotive": "locomotive", "emu": "multiple_unit", "dmu": "multiple_unit", "agt_vehicle": "apm", "monorail_car": "apm"}


def demand_range(years=10, open_only=False):
    """Replacement demand in dollars with a low / mid / high range: forecast buys priced at the 25th, 50th and 75th percentile of
    recent orders for the same vehicle type (escalated), falling back to the site's unit cost when a type has no priced orders."""
    yr = intel.this_year()
    buys = intel.work_timeline(["buy"], years)
    if open_only:
        buys = [o for o in buys if nexgen.stage_open(o["fleet"]["fleet_id"])]
    cache = {}
    out = {}
    for o in buys:
        t = CLASS_TO_TYPE.get(o["fleet"]["vehicle_class"], "other")
        y = max(o["year"], yr)
        if (t, y) not in cache:
            e = nexgen.estimate(t, 1, y)
            cache[(t, y)] = (e["low"], e["mid"], e["high"], e["n"])
        lo, mid, hi, n = cache[(t, y)]
        unit = o.get("unit") or (o["value"] / o["cars"] if o.get("value") and o["cars"] else None)
        if not mid:  # no priced orders of this type: the site's unit cost +/- 20%
            lo, mid, hi = (unit * 0.8 if unit else 0), (unit or 0), (unit * 1.2 if unit else 0)
        b = out.setdefault(y, {"cars": 0, "low": 0, "mid": 0, "high": 0, "n": 0})
        b["cars"] += o["cars"]
        b["low"] += lo * o["cars"]
        b["mid"] += mid * o["cars"]
        b["high"] += hi * o["cars"]
        b["n"] += 1
    rows = [dict(year=y, **v) for y, v in sorted(out.items())]
    tot = {k: sum(r[k] for r in rows) for k in ("cars", "low", "mid", "high", "n")}
    return rows, tot


# ---------------- fleet page: technical requirements, aftermarket, signal link ----------------

EPA_TIERS = [(2015, "Tier 4"), (2012, "Tier 3"), (2005, "Tier 2"), (2002, "Tier 1"), (1973, "Tier 0")]


def tech_requirements(fid):
    """What a replacement vehicle has to match, from the fleet, its model and the line's electrification."""
    fl = intel.snapshot_all().get(fid) or {}
    if not fl:
        return []
    vm = db.fq("SELECT m.* FROM fleet f JOIN vehicle_model m USING (model_id) WHERE f.fleet_id = ?", (fid,), one=True)
    vm = dict(vm) if vm else {}
    el = db.fq("SELECT * FROM v_fleet_electrification WHERE fleet_id = ? LIMIT 1", (fid,), one=True)
    el = dict(el) if el else {}
    rows = []
    prop = vm.get("propulsion") or fl.get("propulsion")
    if prop:
        rows.append(("Propulsion", str(prop).replace("_", " "), "model record"))
    if el.get("voltage_v"):
        coll = (el.get("collection") or "").replace("_", " ")
        rows.append(("Power supply", f"{el['voltage_v']} V {el.get('current_type') or ''}{(' ' + str(el['frequency_hz']) + ' Hz') if el.get('frequency_hz') else ''}, {coll}".strip(", "),
                     f"line electrification, grade {el.get('confidence') or '?'}"))
    if vm.get("car_length_ft"):
        rows.append(("Car length", f"{vm['car_length_ft']:g} ft", "model record"))
    if fl.get("seats_per_vehicle"):
        rows.append(("Seats per car", str(fl["seats_per_vehicle"]), "NTD"))
    if fl.get("ntd_mode") in ("CR", "YR"):
        rows.append(("Crashworthiness", "FRA passenger equipment rules (49 CFR 238): Tier I, or Tier III / alternative compliance", "rule for commuter rail"))
    if prop and "diesel" in str(prop) and fl.get("build_year"):
        tier = next((t for y, t in EPA_TIERS if fl["build_year"] >= y), "pre-Tier 0")
        rows.append(("Emissions", f"Built to about EPA {tier}; a new diesel must meet Tier 4", "estimated from build year"))
    if fl.get("ada_pct") is not None:
        rows.append(("Accessibility", f"{fl['ada_pct']}% of active cars ADA accessible", "NTD"))
    rows.append(("Platform height", "Not in our data yet", "needs research"))
    return rows


def aftermarket(fid):
    """Installed-base aftermarket for one fleet: overhauls coming due with cost, and consumables spend per year."""
    fl = intel.snapshot_all().get(fid) or {}
    yr = intel.this_year()
    rows = [dict(r) for r in db.fq("SELECT subsystem, projected_due_year, pct_of_interval_used, est_cost_usd FROM overhaul_projection "
                                   "WHERE fleet_id = ? AND subsystem NOT IN ('vehicle_ulb') ORDER BY projected_due_year", (fid,))]
    rows = [r for r in rows if r["projected_due_year"] and r["projected_due_year"] <= yr + 10]
    n = fl.get("qty_active") or 0
    for r in rows:
        r["label"] = r["subsystem"].replace("vehicle_", "").replace("_", " ").capitalize()
        r["total"] = (r["est_cost_usd"] or 0) * n if r.get("est_cost_usd") else None
    return {"rows": rows, "cars": n, "maint_year": (fl.get("maint_cost_per_car_year") or 0) * n or None}


SIGNAL_CATS = ("signals_communications",)


def _sig_rows(where="", args=()):
    try:
        return [dict(r) for r in db.fq("SELECT s.rowid sid, s.* FROM seed_subsystem s WHERE s.subsystem = 'signal_onboard'" + where, args)]
    except Exception:
        return []


def _op_ids(oid_field):
    return [x.strip() for x in (oid_field or "").split(";") if x.strip()]


def signal_link(fid):
    """The train control side of a fleet: the records that apply to this fleet, the operator's other train control,
    and recent signal bids at the operator."""
    fl = intel.snapshot_all().get(fid) or {}
    if not fl:
        return {}
    try:
        linked = {r["subsystem_rowid"] for r in db.fq("SELECT subsystem_rowid FROM fleet_subsystem WHERE fleet_id = ?", (fid,))}
    except Exception:
        linked = set()
    prof = signal_profile(fl["operator_id"])
    mine_ids = {sid for sid in linked}
    rows = _sig_rows(" AND (';' || s.operator_id || ';') LIKE ?", (f"%;{fl['operator_id']};%",))
    mine = trainctl.merge([dict(trainctl.parse(r), sid=r["sid"]) for r in rows if r["sid"] in mine_ids])
    try:
        bids = [dict(r) for r in db.bq("SELECT notice_id, title, published, closing FROM notice WHERE operator_id = ? AND category = 'signals_communications' "
                                       "ORDER BY published DESC LIMIT 5", (fl["operator_id"],))]
    except Exception:
        bids = []
    if not mine and not prof["recs"] and not bids:
        return {}
    return {"mine": mine, "profile": prof, "bids": bids}


# ---------------- signal and train control profiles ----------------

def signal_profile(oid):
    rows = _sig_rows(" AND (';' || s.operator_id || ';') LIKE ?", (f"%;{oid};%",))
    recs = trainctl.merge([trainctl.parse(r) for r in rows])
    return {"recs": recs, "summary": trainctl.summary(recs)}


SIGNAL_FILTERS = ("tech", "oem", "conf", "q", "mode")


def signal_profiles(f=None):
    """Every operator with its train control records parsed and merged, roll-ups by technology and OEM,
    and recent signal bids. f filters: tech (PTC/CBTC/ATC/ETCS/NONE), oem, conf ('confirmed' hides inferred), q, mode."""
    f = f or {}
    snap = intel.snapshot().values()
    by = {}
    cars_by_fleet = {}
    for fl in snap:
        o = by.setdefault(fl["operator_id"], {"operator_id": fl["operator_id"], "name": fl["operator_name"], "cars": 0, "modes": set(), "fleets": 0})
        o["cars"] += fl["qty_active"] or 0
        o["modes"].add(fl["ntd_mode"])
        o["fleets"] += 1
        cars_by_fleet[fl["fleet_id"]] = fl["qty_active"] or 0
    recs_by = {}
    for r in _sig_rows():
        p = trainctl.parse(r)
        p["sid"] = r["sid"]
        for oid in _op_ids(r["operator_id"]):
            recs_by.setdefault(oid, []).append(dict(p, operator_id=oid))
    try:
        links = {}
        for r in db.fq("SELECT fs.subsystem_rowid sid, fs.fleet_id FROM fleet_subsystem fs JOIN seed_subsystem s ON s.rowid = fs.subsystem_rowid "
                       "WHERE s.subsystem = 'signal_onboard'"):
            links.setdefault(r["sid"], set()).add(r["fleet_id"])
    except Exception:
        links = {}
    try:
        nb = {r["operator_id"]: r["n"] for r in db.bq("SELECT operator_id, COUNT(*) n FROM notice WHERE category = 'signals_communications' "
                                                      "AND published >= date('now', '-730 days') GROUP BY operator_id")}
    except Exception:
        nb = {}
    out = []
    tech_n, oem_ag, oem_cars = {}, {}, {}
    for oid, o in by.items():
        raw = recs_by.get(oid, [])
        recs = trainctl.merge(raw)
        o["recs"] = recs
        o["sum"] = trainctl.summary(recs)
        o["bids"] = nb.get(oid, 0)
        o["modes"] = sorted(m for m in o["modes"] if m)
        # cars covered per OEM: fleets linked to this operator's records
        for p in raw:
            fids = links.get(p["sid"], set())
            for oe in p["oems"]:
                oem_cars.setdefault(oe["name"], set()).update(fids)
        if recs:
            for t in o["sum"]["tech"]:
                tech_n[t] = tech_n.get(t, 0) + 1
            for n in o["sum"]["oems"]:
                oem_ag[n] = oem_ag.get(n, 0) + 1
        out.append(o)
    # operators with records but no active fleet in the snapshot (APMs and the like) still count
    for oid, raw in recs_by.items():
        if oid in by:
            continue
        recs = trainctl.merge(raw)
        o = {"operator_id": oid, "name": oid.replace("_", " ").title(), "cars": 0, "modes": [], "fleets": 0, "recs": recs,
             "sum": trainctl.summary(recs), "bids": nb.get(oid, 0), "no_fleet": True}
        for t in o["sum"]["tech"]:
            tech_n[t] = tech_n.get(t, 0) + 1
        for n in o["sum"]["oems"]:
            oem_ag[n] = oem_ag.get(n, 0) + 1
        out.append(o)
    try:
        names = {r["operator_id"]: r["operator_name"] for r in db.fq("SELECT operator_id, operator_name FROM operator")}
        for o in out:
            if o.get("no_fleet") and names.get(o["operator_id"]):
                o["name"] = names[o["operator_id"]]
    except Exception:
        pass
    oems = sorted(({"name": n, "agencies": a, "cars": sum(cars_by_fleet.get(x, 0) for x in oem_cars.get(n, ()))} for n, a in oem_ag.items()),
                  key=lambda x: (-x["agencies"], -x["cars"]))
    mapped_all = [o for o in out if o["recs"]]
    stats = {"agencies": len(out), "mapped": len(mapped_all),
             "tech": [(t, trainctl.TECH[t][0], tech_n[t]) for t in sorted(tech_n, key=lambda t: trainctl.TECH.get(t, trainctl.TECH["UNK"])[2])],
             "oems": oems,
             "inferred": sum(1 for o in mapped_all if o["sum"]["all_inferred"]),
             "records": sum(len(o["recs"]) for o in mapped_all)}
    # filters
    rows = out
    if f.get("tech"):
        rows = [o for o in rows if f["tech"] in o["sum"]["tech"] or (f["tech"] == "ETCS" and any("ETCS Level 2" in q["planned"] for q in o["recs"]))]
    if f.get("oem"):
        rows = [o for o in rows if f["oem"] in o["sum"]["oems"]]
    if f.get("conf") == "confirmed":
        rows = [dict(o, recs=[q for q in o["recs"] if not q["inferred"]]) for o in rows]
        rows = [o for o in rows if o["recs"]]
    if f.get("mode"):
        rows = [o for o in rows if f["mode"] in o["modes"]]
    if f.get("q"):
        ql = f["q"].lower()
        rows = [o for o in rows if data.qhit(ql, o["name"], o["operator_id"])
                or any(data.qhit(ql, q["product"], q["oem_label"], q["scope"], q["detail"]) for q in o["recs"])]
    rows.sort(key=lambda o: (not o["recs"], -o["cars"]))
    mapped = [o for o in rows if o["recs"]]
    unmapped = [o for o in rows if not o["recs"] and o["cars"] > 0]
    return {"mapped": mapped, "unmapped": unmapped, "stats": stats}


# ---------------- joint procurement and option map ----------------

def option_map():
    """Vehicle orders with options still open, and joint or piggyback buys, so a buyer sees where a contract can be extended or joined."""
    rows = []
    for p in data.procurements():
        ops = [o for o in (p.get("operator_id") or "").split(";") if o]
        notes = (p.get("notes") or "") + " " + (p.get("status") or "")
        joint = len(ops) > 1 or bool(re.search(r"joint|piggyback|assign|consorti|cooperative", notes, re.I))
        opts = data.first_int(p.get("qty_options"))
        exercised = bool(re.search(r"option[s]? (exercised|ordered)|exercised", notes, re.I))
        done = "complete" in (p.get("status") or "").lower()
        if not (joint or (opts and not done)):
            continue
        rows.append(dict(p, ops=ops, joint=joint, opts=opts, exercised=exercised, year=str(p.get("award_date") or "")[:4],
                         builder=nexgen._builder(p.get("manufacturer"))))
    # researched stages that name an option path
    for r in nexgen.proc_stages().values():
        if re.search(r"option", (r.get("replacement") or "") + " " + (r.get("note") or ""), re.I) and r.get("stage") in ("awarded", "delivering"):
            rows.append({"ops": [r["operator_id"]], "model": r.get("replacement"), "builder": r.get("awarded_to") or "", "joint": False,
                         "opts": None, "exercised": False, "year": str(r.get("expected_award") or "")[:4], "notes": r.get("note"),
                         "source_url": r.get("source_url"), "status": "researched stage", "fleet_id": r["fleet_id"]})
    rows.sort(key=lambda r: r.get("year") or "", reverse=True)
    return rows


# ---------------- builder delivery record ----------------

DELAY_RX = r"delay|slipp|postpon|late\b|behind schedule|not achievable|pushed back|customs|recall|withdrawn|sidelined|cracks?|defect"


def delivery_record():
    """Per builder: orders, cars, how many are in backlog, average years from award to first delivery where both are known,
    and orders whose record mentions a delay. From the order book and the researched procurement stages."""
    by = {}
    for o in nexgen.orders():
        b = by.setdefault(o["builder"], {"builder": o["builder"], "orders": 0, "cars": 0, "backlog": 0, "lead": [], "delays": [], "events": []})
        b["orders"] += 1
        b["cars"] += o["cars"]
        if o["backlog"]:
            b["backlog"] += o["cars"]
        m = re.search(r"(20\d\d)", str(o.get("delivery") or ""))
        if m and o["year"]:
            lead = int(m.group(1)) - o["year"]
            if 0 <= lead <= 10:
                b["lead"].append(lead)
        txt = f"{o.get('notes') or ''} {o.get('status') or ''} {o.get('delivery') or ''}"
        if re.search(DELAY_RX, txt, re.I):
            b["delays"].append({"what": f"{o.get('operator_id')} {o.get('model') or ''}".strip(), "note": txt.strip()[:220], "url": o.get("source_url")})
    for r in nexgen.proc_stages().values():
        b = (r.get("awarded_to") or "").strip()
        if not b:
            continue
        key = next((k for k in by if k.lower().startswith(b.lower()[:6])), b)
        e = by.setdefault(key, {"builder": key, "orders": 0, "cars": 0, "backlog": 0, "lead": [], "delays": [], "events": []})
        e["events"].append({"what": f"{r['operator_id']} {r.get('replacement') or ''}", "stage": r.get("stage"), "note": r.get("note"), "url": r.get("source_url"),
                            "checked": r.get("checked")})
        if re.search(DELAY_RX, r.get("note") or "", re.I):
            e["delays"].append({"what": f"{r['operator_id']} {r.get('replacement') or ''}", "note": (r.get("note") or "")[:220], "url": r.get("source_url")})
    out = []
    for b in by.values():
        b["lead_avg"] = round(statistics.mean(b["lead"]), 1) if b["lead"] else None
        seen = set()
        b["delays"] = [d for d in b["delays"] if not (d["what"] in seen or seen.add(d["what"]))]
        out.append(b)
    out.sort(key=lambda b: -(b["cars"] or 0))
    return out


# ---------------- agency replacement and overhaul planner ----------------

def planner(oid, overrides=None, years=20):
    """Year-by-year capital need for one agency: each fleet's replacement (researched stage, plan, or useful life) and midlife overhaul,
    priced from peer orders (mid case) and the overhaul norms. overrides = {fleet_id: replacement year} from the form."""
    overrides = overrides or {}
    yr = intel.this_year()
    costs = intel.unit_costs()
    fleets = sorted(nexgen.agency_fleets(oid), key=lambda f: -(f["qty_active"] or 0))
    plan = []
    by_year = {y: {"replace": 0, "overhaul": 0} for y in range(yr, yr + years)}
    for fl in fleets:
        n = fl["qty_active"] or 0
        if not n:
            continue
        st = nexgen.proc_stage(fl["fleet_id"]) or {}
        rep = overrides.get(fl["fleet_id"]) or fl.get("planned_retirement_year") or fl.get("ulb_year")
        basis = "your input" if fl["fleet_id"] in overrides else ("agency plan" if fl.get("planned_retirement_year") else "useful-life benchmark")
        if st.get("stage") in ("awarded", "delivering"):
            basis = f"already {st['stage']}" + (f" ({st.get('awarded_to')})" if st.get("awarded_to") else "")
        t = CLASS_TO_TYPE.get(fl["vehicle_class"], "other")
        unit = None
        if rep:
            e = nexgen.estimate(t, 1, max(rep, yr))
            unit = e["mid"] or intel.unit_cost(costs, "replace", fl["vehicle_class"])
        oh_year = fl.get("midlife_due_year") if fl.get("midlife_due_year") and not fl.get("last_rebuild_year") else None
        oh_unit = intel.unit_cost(costs, "midlife", fl["vehicle_class"]) if oh_year else None
        rep_cost = (unit or 0) * n if rep and st.get("stage") not in ("awarded", "delivering") else 0
        oh_cost = (oh_unit or 0) * n if oh_year and (not rep or oh_year < rep) else 0
        if rep and rep_cost:
            by_year.setdefault(max(rep, yr), {"replace": 0, "overhaul": 0})["replace"] += rep_cost
        if oh_cost:
            by_year.setdefault(max(oh_year, yr), {"replace": 0, "overhaul": 0})["overhaul"] += oh_cost
        plan.append({"fleet": fl, "cars": n, "rep": rep, "basis": basis, "unit": unit, "rep_cost": rep_cost, "oh_year": oh_year, "oh_cost": oh_cost,
                     "stage": st})
    by_year = {y: v for y, v in sorted(by_year.items()) if yr <= y < yr + years}
    return plan, by_year


def peers_by_region(oid, region="all", n=8):
    """Peers as nexgen.peer_ids, limited to US or Canadian operators when asked."""
    ids = nexgen.peer_ids(oid, 1000)  # every same-mode operator, closest in size first
    if region in ("US", "CA"):
        snap = intel.snapshot().values()
        country = {fl["operator_id"]: fl["country"] for fl in snap}
        ids = [i for i in ids if country.get(i) == region]
    return ids[:n]


# ---------------- platform supplier map and Supplier Intelligence additions ----------------

def platform_records():
    """One row per component seat: agency, platform (builder + model of the fleet it is on), subsystem, supplier and product, with
    the fleets and active cars it covers. A record that applies to several fleets ("*" = every fleet of the agency) is split by
    platform through fleet_subsystem; fleets outside the current lens and region are left out. Feeds the platform supplier map and
    its drill-down table (1.7.7)."""
    rows = [dict(r) for r in db.fq("SELECT s.rowid sid, s.operator_id, s.model, s.subsystem, s.supplier, s.product, s.source_url FROM seed_subsystem s")]
    links = {}
    for r in db.fq("SELECT subsystem_rowid, fleet_id FROM fleet_subsystem"):
        links.setdefault(r["subsystem_rowid"], []).append(r["fleet_id"])
    snap = intel.snapshot()
    allids = set(intel.snapshot_all()) if hasattr(intel, "snapshot_all") else set(snap)
    mfr, names = {}, {}
    for fl in snap.values():
        mfr.setdefault((fl["operator_id"], (fl["model_name"] or "").lower()), fl["manufacturer"])
        names.setdefault(fl["operator_id"], fl["operator_name"])
    out = {}
    def add(r, platform, fl=None, fid=None):
        sup = (r["supplier"] or "").strip() or "?"
        k = (r["operator_id"], platform, r["subsystem"], sup, r["product"] or "")
        d = out.get(k)
        if not d:
            d = out[k] = dict(r, platform=platform, sub=(r["subsystem"] or "").split("/")[0], supplier=sup,
                              operator_name=" / ".join(names.get(o) or o for o in (r["operator_id"] or "").split(";") if o), cars=0, fleets=0, fids={})
        if fl:
            d["fids"][fid] = fl["qty_active"] or 0
            d["fleets"] += 1
            d["cars"] += fl["qty_active"] or 0
    for r in rows:
        fids = links.get(r["sid"]) or []
        inscope = [snap[i] for i in fids if i in snap]
        if inscope:
            for i in fids:
                if i in snap:
                    fl = snap[i]
                    add(r, f"{fl['manufacturer'] or ''} {fl['model_name'] or ''}".strip(), fl, i)
        elif not any(i in allids for i in fids):  # no fleet linked yet: show the record as written
            m = r["model"] or ""
            add(r, f"{mfr.get((r['operator_id'], m.lower())) or ''} {m if not m.startswith('*') else '(all fleets)'}".strip())
    return list(out.values())


PLATFORM_FILTERS = ("supplier", "platform", "agency", "sub")


def unique_cars(sel):
    """Active cars on the fleets behind these rows, each fleet counted once (1.7.13: a fleet with several seats from one supplier,
    such as brakes and doors, used to be counted once per seat in the header)."""
    seen = {}
    for r in sel:
        seen.update(r.get("fids") or {})
    return sum(seen.values()), len(seen)


def platform_map(f=None, recs=None):
    """Vehicle platform (builder + model) x subsystem -> suppliers, from the mapped subsystem records. f (1.7.7): supplier,
    platform, agency (operator_id) and sub narrow both the matrix and the installed-base rows; returns (matrix, subsystems, rows)."""
    f = f or {}
    recs = platform_records() if recs is None else recs
    allsubs = sorted({r["sub"] for r in recs})
    sel = [r for r in recs if (not f.get("supplier") or r["supplier"] == f["supplier"]) and (not f.get("platform") or r["platform"] == f["platform"])
           and (not f.get("agency") or f["agency"] in (r["operator_id"] or "").split(";")) and (not f.get("sub") or r["sub"] == f["sub"])]
    keep = {(r["platform"]) for r in sel}
    plats = {}
    for r in recs:  # the matrix keeps every seat on the matching platforms, so a competitor's seats stay visible next to the supplier's
        if r["platform"] not in keep or (f.get("agency") and f["agency"] not in (r["operator_id"] or "").split(";")):
            continue
        p = plats.setdefault(r["platform"], {"platform": r["platform"], "operators": set(), "subs": {}, "cars": {}})
        p["operators"].update(o for o in (r["operator_id"] or "").split(";") if o)
        p["subs"].setdefault(r["sub"], set()).add(r["supplier"])
    out = sorted(plats.values(), key=lambda p: -len(p["subs"]))
    for p in out:
        p["operators"] = sorted(p["operators"])
        p["subs"] = {k: sorted(v) for k, v in p["subs"].items()}
    subs = [f["sub"]] if f.get("sub") in allsubs else allsubs
    sel.sort(key=lambda r: (-(r["cars"] or 0), r["platform"], r["sub"]))
    return out, subs, sel


CONSULT_RX = r"engineering|design|consult|program management|construction management|inspection|planning|environmental|architect"


def consultants(years=5):
    """Engineering and A/E firms ranked by rail contract awards Bid Catcher found (vendor, count, value, agencies)."""
    try:
        rows = [dict(r) for r in db.bq("SELECT vendor, vendor_norm, title, category, amount_usd, award_date, operator_id, buyer, source_url FROM award "
                                       f"WHERE award_date >= date('now', '-{int(years) * 365} days')")]
    except Exception:
        rows = []
    by = {}
    for r in rows:
        if r.get("category") not in ("rail_engineering", "engineering_support") and not re.search(CONSULT_RX, r.get("title") or "", re.I):
            continue
        k = r.get("vendor_norm") or r.get("vendor")
        if not k:
            continue
        b = by.setdefault(k, {"name": r.get("vendor") or k, "n": 0, "usd": 0, "agencies": set(), "last": ""})
        b["n"] += 1
        b["usd"] += r.get("amount_usd") or 0
        b["agencies"].add(r.get("buyer") or r.get("operator_id") or "")
        b["last"] = max(b["last"], r.get("award_date") or "")
    out = sorted(by.values(), key=lambda b: (-b["n"], -b["usd"]))
    for b in out:
        b["agencies"] = sorted(a for a in b["agencies"] if a)
    return out


def tier1():
    """Tier-1 subsystem suppliers ranked by cars mapped to them (supplier register + subsystem records)."""
    v = intel.subsystem_view(None)
    by = {}
    for r in v["rows"]:
        name = r.get("supplier_name") or "?"
        b = by.setdefault(name, {"name": name, "cars": 0, "fleets": 0, "subs": set(), "operators": set()})
        b["cars"] += r["fleet"]["qty_active"] or 0
        b["fleets"] += 1
        b["subs"].add(r["rec"].get("subsystem") if isinstance(r.get("rec"), dict) else "")
        b["operators"].add(r["fleet"]["operator_id"])
    out = sorted(by.values(), key=lambda b: -b["cars"])
    for b in out:
        b["subs"] = sorted(s for s in b["subs"] if s)
        b["operators"] = sorted(b["operators"])
    return out


# ---------------- capital projects and on-call expiry ----------------

ONCALL_RX = r"on[- ]call|\bidiq\b|indefinite delivery|task order|as[- ]needed|bench contract|master (services )?agreement|general engineering"


CAPITAL_CATS = ("rail_engineering", "engineering_support", "track_infrastructure", "traction_power", "stations_facilities", "signals_communications")
CAPITAL_KEYS = ("q", "buyer", "holder", "category", "tag", "since", "until", "ends", "min", "status")


def _lens_ops():
    """Operators in the viewer's lens and region (the All rail / Transit / Passenger rail and Region pills); None when unscoped."""
    sc = lens.current()
    if not sc.scoped:  # 1.7.45: the sales territory narrows data.operators() too
        return None
    return {o["operator_id"] for o in data.operators()}


def _in_lens(r, ops):
    if ops is None:
        return True
    sc = lens.current()
    if sc.territory and r.get("agency_id") and r["agency_id"] in sc.ter_ags and not sc.modes:  # 1.7.45: a territory agency with no fleet of its own
        return True
    ids = [x for x in ((r.get("fleet_operator_ids") or "").split(";") + [r.get("operator_id") or ""]) if x]
    if ids:
        return any(i in ops for i in ids)
    # a buyer we can't tie to a fleet operator: keep it only for a region-only filter it passes (never under a territory)
    return not sc.modes and not sc.territory and (not sc.regions or (r.get("country") or "") in sc.regions)


def _money_min(f):
    try:
        return float(re.sub(r"[^\d.]", "", f.get("min") or "")) * 1e6 if (f.get("min") or "").strip() else None
    except ValueError:
        return None


def _ym_add(ym, months):
    y, m = int(ym[:4]), int(ym[5:7]) - 1 + months
    return f"{y + m // 12:04d}-{m % 12 + 1:02d}"


def oncall_expiry(f=None):
    """On-call, IDIQ and standing-offer contracts by end date, one row per bench, so a firm knows when the next round is due.
    1.7.31: reads Bid Catcher's on-call fields (bids-push21: contract_type, end_date, end_with_options, ceiling_usd, spent_usd,
    bench_id, rebid_notice_id) when bids.db has them; before that, the title rule and award date + term as before.
    f: slicers (q, buyer, holder = any firm on the bench, ends = next12 | next24 | ended | unknown, min in $M); respects the lens and region pills.
    Returns (rows, all rows) where each row has ends (with options when known), base_end, rebid, firms, value, spent and rebid_notice_id."""
    f = f or {}
    have = data.bcols("award")
    new = "contract_type" in have
    extra = ", ".join(data.bcol("award", c, "a") for c in ("contract_type", "end_date", "end_with_options", "options_months",
                                                            "ceiling_usd", "spent_usd", "bench_id", "rebid_notice_id"))
    try:
        rows = [dict(r) for r in db.bq("SELECT a.award_id, a.agency_id, coalesce(g.agency, a.buyer) buyer, a.operator_id, a.title, a.vendor, a.amount_usd, a.award_date, "
                                       f"a.term_months, a.source_url, a.category, a.country, g.fleet_operator_ids, {extra} "
                                       "FROM award a LEFT JOIN agency g USING (agency_id)"
                                       + (" WHERE a.contract_type = 'oncall'" if new else ""))]
    except Exception:
        rows = []
    ops, today = _lens_ops(), datetime.date.today().isoformat()[:7]
    lo = _money_min(f)
    groups = {}
    for r in rows:
        if not new and not re.search(ONCALL_RX, r.get("title") or "", re.I):
            continue
        base = (r.get("end_date") or "")[:7] or None
        if not base:
            try:
                if r.get("award_date") and r.get("term_months"):
                    base = _ym_add(str(r["award_date"])[:7], int(r["term_months"]))
            except (ValueError, TypeError):
                base = None
        withopt = (r.get("end_with_options") or "")[:7] or None
        r = dict(r, base_end=base, with_options=withopt if withopt and withopt != base else None, ends=withopt or base)
        r["buyer"] = r.get("buyer") or r.get("operator_id") or ""
        key = ("b", r["bench_id"]) if r.get("bench_id") else ("a", r["award_id"])
        groups.setdefault(key, []).append(r)
    out = []
    for key, rs in groups.items():
        if not any(_in_lens(x, ops) for x in rs):  # a bench is in the lens when any of its rows is
            continue
        rs.sort(key=lambda x: (x.get("amount_usd") is None, -(x.get("amount_usd") or 0)))
        r = dict(rs[0])
        firms = sorted({x["vendor"] for x in rs if x.get("vendor")}, key=str.lower)
        r["firms"] = firms
        r["bench"] = key[0] == "b" and len(firms) > 1
        ceil = next((x["ceiling_usd"] for x in rs if x.get("ceiling_usd")), None)  # shared by the bench: one value, never summed
        r["value"] = ceil or (r.get("amount_usd") if not r["bench"] else None)
        r["value_is_ceiling"] = bool(ceil)
        sp = [x["spent_usd"] for x in rs if x.get("spent_usd")]
        r["spent"] = sum(sp) if sp else None  # spent_usd is per firm contract (NY ABO), never shared: always summed
        r["rebid_notice_id"] = next((x["rebid_notice_id"] for x in rs if x.get("rebid_notice_id")), None)
        for k in ("ends", "base_end", "with_options"):
            r[k] = max((x[k] for x in rs if x.get(k)), default=None)
        r["rebid"] = _ym_add(r["ends"], -12) if r["ends"] else None
        out.append(r)
    allrows = out
    if f.get("q"):
        ql = f["q"].lower()
        out = [r for r in out if data.qhit(ql, r.get("title"), r.get("buyer"), *r["firms"])]
    if f.get("buyer"):
        out = [r for r in out if r["buyer"] == f["buyer"]]
    if f.get("holder"):
        out = [r for r in out if f["holder"] in r["firms"]]
    if f.get("ends") in ("next12", "next24"):
        lim = _ym_add(today, 12 if f["ends"] == "next12" else 24)
        out = [r for r in out if r["ends"] and today <= r["ends"] <= lim]
    elif f.get("ends") == "ended":
        out = [r for r in out if r["ends"] and r["ends"] < today]
    elif f.get("ends") == "unknown":
        out = [r for r in out if not r["ends"]]
    if lo:
        out = [r for r in out if (r.get("value") or 0) >= lo]
    out.sort(key=lambda r: r["ends"] or "9999")
    return out, allrows


def capital_pipeline(days=365, f=None):
    """Notices for design, construction and systems work with the estimated value, largest first.
    f: slicers (q, buyer, category, tag, since, until, min in $M, status = open | all); respects the lens and region pills.
    Returns (rows, all rows in the window, for the slicer choices)."""
    f = f or {}
    try:
        rows = [dict(r) for r in db.bq("SELECT n.notice_id, n.agency_id, coalesce(g.agency, n.buyer) buyer, n.operator_id, n.title, n.summary, n.notice_type, n.category, "
                                       "n.value_est, n.currency, coalesce(n.published, date(n.first_seen)) published, n.closing, n.url, n.country, g.fleet_operator_ids "
                                       "FROM notice n LEFT JOIN agency g USING (agency_id) "
                                       "WHERE coalesce(n.published, date(n.first_seen)) >= date('now', ?) AND coalesce(n.notice_type, '') != 'award' "
                                       f"AND coalesce(n.relevance, n.kw_score, 0) >= 50 AND n.category IN ({','.join('?' * len(CAPITAL_CATS))}) "
                                       "ORDER BY COALESCE(n.value_est, 0) DESC, published DESC", (f"-{int(days)} days",) + CAPITAL_CATS)]
    except Exception:
        rows = []
    ops = _lens_ops()
    rows = [data.restrict(r) for r in rows if _in_lens(r, ops)]
    today = datetime.date.today().isoformat()
    for r in rows:
        r["tags"] = nexgen.bid_tags(r)
        r["buyer"] = r.get("buyer") or r.get("operator_id") or ""
        if not r.get("closing"):
            h = data.closing_hint(r.get("summary")) or data.closing_hint(r.get("title"))
            if h:
                r["closing_est"], r["closing_est_label"] = h
        c = r.get("closing") or r.get("closing_est")
        r["open"] = bool(c and c[:10] >= today) or (not c and (r.get("published") or "") >= (datetime.date.today() - datetime.timedelta(days=45)).isoformat())
    allrows = rows
    out = rows
    if f.get("q"):
        ql = f["q"].lower()
        out = [r for r in out if data.qhit(ql, r.get("title"), r.get("summary"), r.get("buyer"))]
    if f.get("buyer"):
        out = [r for r in out if r["buyer"] == f["buyer"]]
    if f.get("category"):
        out = [r for r in out if r.get("category") == f["category"]]
    if f.get("tag"):
        out = [r for r in out if any(l == f["tag"] for _, l in r["tags"])]
    if f.get("since"):
        out = [r for r in out if (r.get("published") or "") >= f["since"]]
    if f.get("until"):
        out = [r for r in out if (r.get("published") or "")[:10] <= f["until"]]
    lo = _money_min(f)
    if lo:
        out = [r for r in out if (r.get("value_est") or 0) >= lo]
    if f.get("status") == "open":
        out = [r for r in out if r["open"]]
    return out, allrows


# ---------------- funding, regulatory and retrofit drivers ----------------

def drivers():
    """Rules and programs that create work, with the fleets each one touches today (computed) and a source to read."""
    snap = list(intel.snapshot().values())
    yr = intel.this_year()

    def cars(fls):
        return sum(f["qty_active"] or 0 for f in fls)
    diesel_old = [f for f in snap if "diesel" in str(f.get("propulsion") or "") and f.get("build_year") and f["build_year"] < 2015]
    past_ulb = [f for f in snap if f.get("ulb_year") and f["ulb_year"] < yr]
    not_ada = [f for f in snap if f.get("ada_pct") is not None and f["ada_pct"] < 100]
    cr = [f for f in snap if f.get("ntd_mode") in ("CR", "YR")]
    midlife = [f for f in snap if f.get("midlife_due_year") and not f.get("last_rebuild_year") and f["midlife_due_year"] <= yr + 5]
    return [
        {"name": "EPA Tier 4 locomotive emissions", "kind": "Regulatory", "what": "New and remanufactured diesel locomotives must meet Tier 4; older units drive repower or replacement and state zero-emission grants.",
         "fleets": diesel_old, "cars": cars(diesel_old), "url": "https://www.epa.gov/regulations-emissions-vehicles-and-engines/regulations-emissions-locomotives", "link": "/app/work?type=buy&cls=locomotive"},
        {"name": "FTA state of good repair (useful-life benchmark)", "kind": "Funding", "what": "Transit Asset Management plans rank vehicles past their useful-life benchmark for replacement funding (5337 SGR, 5339, RVRP).",
         "fleets": past_ulb, "cars": cars(past_ulb), "url": "https://www.transit.dot.gov/TAM", "link": "/app/forecast"},
        {"name": "ADA accessibility", "kind": "Regulatory", "what": "Cars that are not accessible are replaced or retrofitted; level boarding and lifts drive vehicle and platform work.",
         "fleets": not_ada, "cars": cars(not_ada), "url": "https://www.transit.dot.gov/regulations-and-guidance/civil-rights-ada/americans-disabilities-act-guidance", "link": "/app/fleets"},
        {"name": "FRA passenger equipment safety (49 CFR 238)", "kind": "Regulatory", "what": "Commuter rail cars must meet crashworthiness tiers; Tier III and alternative compliance shape what can be bought.",
         "fleets": cr, "cars": cars(cr), "url": "https://www.ecfr.gov/current/title-49/subtitle-B/chapter-II/part-238", "link": "/app/fleets?mode=CR"},
        {"name": "Positive train control and CBTC", "kind": "Regulatory", "what": "PTC is in place on commuter rail; interoperability upgrades, CBTC conversions and on-board refreshes keep signal work coming.",
         "fleets": cr, "cars": cars(cr), "url": "https://railroads.dot.gov/train-control/ptc/positive-train-control-ptc", "link": "/app/signal-profiles"},
        {"name": "Buy America", "kind": "Funding rule", "what": "FTA-funded rolling stock needs 70% US content and final assembly in the US; shapes who can bid and where cars are built.",
         "fleets": [], "cars": None, "url": "https://www.transit.dot.gov/buyamerica", "link": None},
        {"name": "Midlife overhaul due in 5 years", "kind": "Retrofit", "what": "Fleets reaching midlife without a recorded rebuild: overhaul programs and component change-outs.",
         "fleets": midlife, "cars": cars(midlife), "url": None, "link": "/app/work?type=overhaul"},
    ]


def funding_for(oid, limit=12):
    """Federal grants to one operator, labelled by work type, so funding can be matched to scope."""
    try:
        from . import fundprog
        rows = fundprog.awards()
    except Exception:
        return []
    name = (db.fq("SELECT operator_name FROM operator WHERE operator_id = ?", (oid,), one=True) or {"operator_name": ""})["operator_name"]
    key = re.sub(r"[^a-z]", "", (name or "").lower())[:18]
    if not key:
        return []
    return [r for r in rows if key and key in re.sub(r"[^a-z]", "", (r.get("recipient") or "").lower())][:limit]


# ---------------- reliability benchmarks, past RFPs, agency finance ----------------

def reliability(mode=None):
    """Miles between major mechanical failures by operator and mode (NTD), with the peer median per mode."""
    oms = intel.operator_mode_stats()
    names = {r["operator_id"]: r["operator_name"] for r in db.fq("SELECT operator_id, operator_name FROM operator")}
    rows = []
    for (oid, m), d in oms.items():
        if not d.get("mdbf") or (mode and m != mode):
            continue
        rows.append({"operator_id": oid, "name": names.get(oid, oid), "mode": m, "mdbf": d["mdbf"], "change": d.get("mdbf_change_pct"),
                     "first_year": d.get("mdbf_first_year"), "year": d.get("year"), "vs_peer": d.get("mdbf_vs_peer_pct"), "spare": d.get("spare_pct")})
    meds = {}
    for r in rows:
        meds.setdefault(r["mode"], []).append(r["mdbf"])
    meds = {k: statistics.median(v) for k, v in meds.items()}
    rows.sort(key=lambda r: (r["mode"], -r["mdbf"]))
    return rows, meds


_STOP = set("the a an and or of for to in on at by with from rail transit services service contract project agency authority request proposals proposal rfp rfq ifb bid bids".split())


def _toks(t):
    return {w for w in re.findall(r"[a-z0-9]{3,}", (t or "").lower()) if w not in _STOP}


def _ref(r):
    return re.sub(r"[^a-z0-9]", "", (r or "").lower())


_CO_RX = re.compile(r"\b(inc|llc|l\.l\.c|corp|corporation|ltd|limited|co|company|lp|llp|gmbh|s\.a|ulc|ltee|ltée)\b\.?", re.I)
_SOL_RX = re.compile(r"\b(rfp|rfq|ifb|itb|bid|bids|tender|solicitation|contract|services?|procure\w*|purchase|supply|furnish|install\w*|repair|"
                     r"replace\w*|rehabilitat\w*|design|construct\w*|maintenance|overhaul|program|project|system|systems|fourniture|travaux|appel)\b", re.I)


def _vendor_title(t):
    """True for a title that is only a company name, e.g. 'VITAL RELAY B1 KB SIGNALING INC (ALSTOM)'."""
    t = (t or "").strip()
    return bool(t) and len(t) < 90 and bool(_CO_RX.search(t)) and not _SOL_RX.search(t)


def match_awards(notices, awards):
    """Link each closed notice to the award that followed it. Bid Catcher sets award.notice_id only when the award notice
    names the solicitation, so most awards (board minutes, award lists, open data) arrive unlinked. Tiers: the stored link;
    the same reference number at the same agency; then the same agency with a closely matching title, awarded within
    30 months after closing. Returns {notice_id: (award, how)}."""
    by_nid, by_ref, by_ag = {}, {}, {}
    for a in awards:
        if a.get("notice_id"):
            by_nid.setdefault(a["notice_id"], a)
        if a.get("ref_no") and len(_ref(a["ref_no"])) >= 4:
            by_ref.setdefault(_ref(a["ref_no"]), []).append(a)
        for k in {a.get("agency_id"), a.get("operator_id")} - {None, ""}:
            by_ag.setdefault(k, []).append(a)
    used, out = set(), {}
    for n in notices:  # pass 1 and 2: exact links
        a = by_nid.get(n["notice_id"])
        how = "linked"
        if not a and n.get("ref_no") and len(_ref(n["ref_no"])) >= 4:
            cands = [x for x in by_ref.get(_ref(n["ref_no"]), []) if not x.get("notice_id") and
                     ({x.get("agency_id"), x.get("operator_id")} & {n.get("agency_id"), n.get("operator_id")} - {None, ""})]
            a, how = (cands[0], "reference") if cands else (None, None)
        if a:
            out[n["notice_id"]] = (a, how)
            used.add(a["award_id"])
    for n in notices:  # pass 3: title similarity at the same agency
        if n["notice_id"] in out:
            continue
        nt = _toks(n.get("title"))
        if len(nt) < 2:
            continue
        close = (n.get("closing") or "")[:10]
        best = None
        for k in {n.get("agency_id"), n.get("operator_id")} - {None, ""}:
            for x in by_ag.get(k, []):
                if x["award_id"] in used or x.get("notice_id"):
                    continue
                ad = (x.get("award_date") or "")[:10]
                if close and ad and not (close[:7] <= ad[:7] <= _add_months(close, 30)):
                    continue
                xt = _toks(x.get("title"))
                if not xt:
                    continue
                sim = len(nt & xt) / min(len(nt), len(xt))
                if sim >= 0.6 and (best is None or sim > best[0]):
                    best = (sim, x)
        if best:
            out[n["notice_id"]] = (best[1], "title match")
            used.add(best[1]["award_id"])
    return out


def _add_months(d, m):
    try:
        y, mo = int(d[:4]), int(d[5:7]) - 1 + m
        return f"{y + mo // 12:04d}-{mo % 12 + 1:02d}"
    except (ValueError, IndexError):
        return "9999-12"


PAST_KEYS = ("q", "operator", "category", "tag", "mode", "since", "until", "outcome")


def past_rfps(oid=None, limit=200, f=None):
    """Closed solicitations with the award that followed (see match_awards), filtered by f, plus summary statistics."""
    f = dict(f or {})
    if oid:
        f["operator"] = oid
    try:
        notices = [dict(r) for r in db.bq(
            "SELECT notice_id, source, agency_id, buyer, operator_id, ref_no, title, category, notice_type, summary, published, closing, value_est, url "
            "FROM notice WHERE closing IS NOT NULL AND closing < date('now') "  # SEAO marks a tender 'award' once the winner is out: keep it
            "AND coalesce(relevance, kw_score, 0) >= 50 ORDER BY closing DESC LIMIT 5000")]
        awards = [dict(r) for r in db.bq("SELECT award_id, notice_id, agency_id, operator_id, ref_no, title, vendor, amount_usd, award_date, "
                                         "n_bidders, low_bid, high_bid, source_url FROM award")]
        tabs = {r["award_id"]: r for r in db.bq("SELECT award_id, COUNT(*) n, MIN(amount) lo, MAX(amount) hi FROM bid_tab GROUP BY award_id")}
    except Exception:
        notices, awards, tabs = [], [], {}
    sc = lens.current()
    if sc.territory and not f.get("operator"):  # 1.7.45 sales territory
        notices = [n for n in notices if sc.in_territory(n.get("operator_id") or "", n.get("agency_id"))]
    try:  # bidders recorded before the award is published (SEAO opens bids publicly): bid_tab rows with no award yet
        pending = {r["notice_id"]: r for r in db.bq("SELECT notice_id, COUNT(*) n, MIN(amount) lo FROM bid_tab WHERE award_id IS NULL "
                                                     "AND notice_id IS NOT NULL GROUP BY notice_id")}
    except Exception:
        pending = {}
    # an award notice read as a solicitation (outside SEAO, whose tenders turn into 'award' once the winner is out), or a
    # "solicitation" whose title is just a company name (an award line): not a past RFP
    notices = [n for n in notices if not ((n.get("notice_type") or "") == "award" and (n.get("source") or "") != "seao") and not _vendor_title(n.get("title"))]
    try:  # every bid recorded for a solicitation or award (bid tabulations, SEAO bid openings)
        bids_by_award, bids_by_notice = {}, {}
        for b in db.bq("SELECT award_id, notice_id, bidder, amount, rank, winner, source_url FROM bid_tab ORDER BY coalesce(rank, 999), amount"):
            b = dict(b)
            if b.get("award_id"):
                bids_by_award.setdefault(b["award_id"], []).append(b)
            if b.get("notice_id"):
                bids_by_notice.setdefault(b["notice_id"], []).append(b)
    except Exception:
        bids_by_award, bids_by_notice = {}, {}
    m = match_awards(notices, awards)
    # the same tender can be read more than once: same agency (or buyer) and reference number, or, with no usable reference,
    # the same buyer, title and closing date. Keep the copy with an award, else the one with bids, else the newest.
    def _dkey(n):
        r = _ref(n.get("ref_no")) or _ref((re.match(r"\s*([A-Z0-9][A-Z0-9./-]{4,})\s+-\s", n.get("title") or "") or [None, ""])[1])
        who = _ref(n.get("buyer"))[:60] or n.get("agency_id")
        if len(r) >= 4 and who:
            return ("ref", who, r)
        if who and n.get("title"):
            return ("title", who, _ref(n["title"])[:80], (n.get("closing") or "")[:10])
        return None

    def _rank(n):
        return (n["notice_id"] in m, n["notice_id"] in bids_by_notice, n["notice_id"])
    keep = {}
    for n in notices:
        k = _dkey(n)
        if k and (k not in keep or _rank(n) > _rank(keep[k])):
            keep[k] = n
    notices = [n for n in notices if not _dkey(n) or keep[_dkey(n)]["notice_id"] == n["notice_id"]]
    try:  # Bid Catcher agencies map to fleet operators (agency.fleet_operator_ids), so agency and mode filters work on notices
        amap = {r["agency_id"]: {x for x in (r["fleet_operator_ids"] or "").split(";") if x} for r in db.bq("SELECT agency_id, fleet_operator_ids FROM agency")}
    except Exception:
        amap = {}
    modes = {}
    if f.get("mode"):
        modes = {o["operator_id"]: set((o.get("modes") or "").split(";")) for o in data.operators()}
    rows = []
    for n in notices:
        n["tags"] = nexgen.bid_tags(n)
        a, how = m.get(n["notice_id"], (None, None))
        if a:
            t = tabs.get(a["award_id"])
            n.update(award_id=a["award_id"], vendor=a.get("vendor"), amount_usd=a.get("amount_usd"), award_date=a.get("award_date"),
                     n_bidders=a.get("n_bidders") or (t["n"] if t else None), low_bid=a.get("low_bid") or (t["lo"] if t else None),
                     high_bid=a.get("high_bid") or (t["hi"] if t else None), match=how, award_url=a.get("source_url"))
        else:
            pb = pending.get(n["notice_id"])
            n.update(award_id=None, vendor=None, amount_usd=None, award_date=None, n_bidders=pb["n"] if pb else None, match=None,
                     pending=bool(pb), low_bid=pb["lo"] if pb else None)
        n["bids"] = (bids_by_award.get(n.get("award_id")) if n.get("award_id") else None) or bids_by_notice.get(n["notice_id"]) or []
        if n["bids"] and not n.get("n_bidders"):
            n["n_bidders"] = len(n["bids"])
        ops = ({n["operator_id"]} if n.get("operator_id") else set()) | amap.get(n.get("agency_id"), set())
        if not n.get("operator_id") and len(ops) == 1:
            n["operator_id"] = next(iter(ops))
        if f.get("operator") and f["operator"] not in ops and f["operator"].lower() != (n.get("agency_id") or "").lower():
            continue
        if f.get("category") and n.get("category") != f["category"]:
            continue
        if f.get("tag") and f["tag"] not in [l for _, l in n["tags"]]:
            continue
        if f.get("mode") and not any(f["mode"] in modes.get(o, set()) for o in ops):
            continue
        if f.get("since") and (n.get("closing") or "")[:10] < f["since"]:
            continue
        if f.get("until") and (n.get("closing") or "")[:10] > f["until"]:
            continue
        if f.get("outcome") == "won" and not n["vendor"]:
            continue
        if f.get("outcome") == "open" and n["vendor"]:
            continue
        if f.get("outcome") == "pending" and not n.get("pending"):
            continue
        if f.get("q"):
            ql = f["q"].lower()
            if not data.qhit(ql, n.get("title"), n.get("buyer"), n.get("vendor")):
                continue
        rows.append(n)
    won = [r for r in rows if r["vendor"]]
    bidders = sorted(r["n_bidders"] for r in won if r.get("n_bidders"))
    winners = {}
    for r in won:
        w = winners.setdefault(r["vendor"], {"vendor": r["vendor"], "n": 0, "usd": 0})
        w["n"] += 1
        w["usd"] += r.get("amount_usd") or 0
    stats = {"n": len(rows), "won": len(won), "pending": sum(1 for r in rows if r.get("pending")), "pct": round(100 * len(won) / len(rows)) if rows else 0,
             "usd": sum(r.get("amount_usd") or 0 for r in won), "bidders_med": bidders[len(bidders) // 2] if bidders else None,
             "single": sum(1 for b in bidders if b == 1), "with_bidders": len(bidders),
             "winners": sorted(winners.values(), key=lambda w: (-w["n"], -w["usd"]))[:10],
             "by_match": {k: sum(1 for r in won if r["match"] == k) for k in ("linked", "reference", "title match")}}
    return rows[:limit], stats


def finance(oid):
    """Agency financial health from NTD: operating cost trend, farebox recovery, cost per passenger mile, against peers."""
    rows = [dict(r) for r in db.fq("SELECT ntd_mode, report_year, opex_per_car_rev_mile, farebox_recovery, opex_per_passenger_mile, yoy_change_pct, "
                                   "change_vs_2019_pct, delta_vs_peer_pct FROM operator_cost_trend WHERE operator_id = ? ORDER BY ntd_mode, report_year", (oid,))]
    latest = {}
    for r in rows:
        latest[r["ntd_mode"]] = r
    return rows, list(latest.values())


# ---------------- quarterly market note ----------------

def market_note():
    """A short, data-generated quarterly note: orders, backlog, open buys by stage, biggest open RFPs, reliability movers."""
    by, keys, val, qrows = orders_by_quarter(4)
    qs = list(by.keys())
    this_q, last_q = qs[-1], qs[-2] if len(qs) > 1 else None
    cars_q = sum(by[this_q].values())
    cars_lq = sum(by[last_q].values()) if last_q else 0
    bl, _ = nexgen.backlog()
    st = {}
    for r in nexgen.proc_stages().values():
        st[r.get("stage")] = st.get(r.get("stage"), 0) + 1
    rng, tot = demand_range(10, open_only=True)
    rfp = sorted([r for r in nexgen.proc_stages().values() if r.get("stage") in ("rfp_out", "evaluation", "rfi")],
                 key=lambda r: r.get("expected_award") or "9999")
    rel, meds = reliability()
    movers = sorted([r for r in rel if r.get("change") is not None], key=lambda r: -r["change"])
    return {"quarter": this_q, "last_q": last_q, "cars_q": cars_q, "cars_lq": cars_lq, "value_q": val.get(this_q, 0), "orders_q": [r for r in qrows if r["q"] == this_q],
            "backlog_cars": sum(b["cars"] for b in bl), "backlog": bl[:6], "stages": st, "open": tot, "rfp": rfp[:10],
            "up": movers[:5], "down": movers[-5:][::-1] if movers else []}


# ---------------- read-only API keys ----------------

API_SCHEMA = """CREATE TABLE IF NOT EXISTS api_key (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, prefix TEXT, key_hash TEXT UNIQUE, label TEXT,
  created TEXT, last_used TEXT, uses INTEGER DEFAULT 0, revoked TEXT)"""


def ensure():
    with db._lock:
        c = db.connect()
        try:
            c.execute(API_SCHEMA)
            c.commit()
        finally:
            c.close()


def _hash(k):
    import hashlib
    return hashlib.sha256(k.encode()).hexdigest()


def new_key(u, label=""):
    k = "cst_" + secrets.token_urlsafe(30)
    db.x("INSERT INTO api_key (user_id, prefix, key_hash, label, created) VALUES (?,?,?,?,?)", (u["id"], k[:10], _hash(k), (label or "")[:60], db.now()))
    return k


def keys_for(u):
    return [dict(r) for r in db.q("SELECT id, prefix, label, created, last_used, uses, revoked FROM api_key WHERE user_id = ? ORDER BY id DESC", (u["id"],))]


def revoke(u, kid):
    db.x("UPDATE api_key SET revoked = ? WHERE id = ? AND user_id = ?", (db.now(), kid, u["id"]))


def user_for_key(k):
    if not k or not k.startswith("cst_"):
        return None
    r = db.q("SELECT * FROM api_key WHERE key_hash = ? AND revoked IS NULL", (_hash(k),), one=True)
    if not r:
        return None
    db.x("UPDATE api_key SET last_used = ?, uses = uses + 1 WHERE id = ?", (db.now(), r["id"]))
    from . import auth
    return auth.load_user(r["user_id"])


# ---------------- lessor persona ----------------

def lessor_view():
    """Leasing and ownership: fleets that are leased or owned by someone other than the operator, and big near-term buys where
    lease finance could compete (from NTD ownership fields and the forecast)."""
    snap = list(intel.snapshot().values())
    leased = [f for f in snap if re.search(r"lease|leas", str(f.get("ownership") or ""), re.I) or (f.get("owner_entity") and f.get("owner_entity") != f.get("operator_name"))]
    by_owner = {}
    for f in leased:
        k = f.get("owner_entity") or str(f.get("ownership") or "").replace("_", " ") or "?"
        b = by_owner.setdefault(k, {"owner": k, "cars": 0, "fleets": 0, "operators": set()})
        b["cars"] += f["qty_active"] or 0
        b["fleets"] += 1
        b["operators"].add(f["operator_id"])
    owners = sorted(by_owner.values(), key=lambda b: -b["cars"])
    for b in owners:
        b["operators"] = sorted(b["operators"])
    own = {}
    for f in snap:
        k = str(f.get("ownership") or "not reported").replace("_", " ")
        own[k] = own.get(k, 0) + (f["qty_active"] or 0)
    buys = [o for o in intel.work_timeline(["buy"], 5) if nexgen.stage_open(o["fleet"]["fleet_id"])]
    buys.sort(key=lambda o: -(o["value"] or 0))
    return {"leased": leased, "owners": owners, "ownership": sorted(own.items(), key=lambda kv: -kv[1]), "buys": buys[:25], "n_buys": len(buys), "buys_value": sum(o["value"] or 0 for o in buys),
            "ownership_rows": [(k.capitalize(), n, f"{n:,} cars", "/app/fleets?" + urllib.parse.urlencode({"own": k})) for k, n in sorted(own.items(), key=lambda kv: -kv[1])[:10]]}
