"""Public-record uploads -> Bid Catcher (1.7.25, Justin 2026-11-11). Member uploads stay private to the uploader. But when an upload is
a public agency solicitation (RFP, RFQ, IFB, RFI, tender), its public facts are reconciled against bids.db: if the notice is already
there the upload is marked a duplicate; if not, a candidate notice is queued (upload_notice, status 'new') for Bid Catcher to add as
if it had found it. The candidate carries only the solicitation's public facts and the document's own text, never who uploaded it.
Bid Catcher pulls candidates from GET /admin/uploads/notices.json (admin, or header X-Bids-Key = setting bids_ingest_key) and marks
them taken with POST /admin/uploads/notices/ack. The site never writes bids.db.

Classification: one small model call per upload (UPLOAD_CLASSIFY_MODEL, default Haiku; about a cent), run in the background after
the upload is saved. Without an API key nothing is classified."""
import json
import re
import threading

from . import config, data, db

MODEL_DEFAULT = "claude-haiku-5-5"
PROMPT = """You read one document a member uploaded and decide whether it is a PUBLIC procurement record issued by a public agency
(government, transit or rail authority, public railroad such as Amtrak or VIA, port, airport, municipality, state DOT), for example an RFP,
RFQ, IFB, RFI, tender, addendum, or bid tabulation. Private company documents, internal estimates, quotes from a supplier, contracts
between private parties and anything marked confidential are NOT public records.
Return only JSON with these keys:
{"public_record": true|false, "reason": "<one short sentence>", "agency": "<issuing agency name or null>", "country": "US"|"CA"|null,
 "state_prov": "<2-letter or null>", "title": "<solicitation title or null>", "ref_no": "<solicitation number or null>",
 "notice_type": "rfp"|"rfq"|"ifb"|"rfi"|"tender"|"addendum"|"bid_tab"|"other", "published": "YYYY-MM-DD or null",
 "closing": "YYYY-MM-DD or null", "value_est": <number or null>, "currency": "USD"|"CAD"|null, "url": "<portal or notice URL printed in the document or null>",
 "rail": true|false, "summary": "<2-3 sentences in your own words: what is being bought and for which fleet or system>"}"""


def _norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _words(s):
    return {w for w in re.findall(r"[a-z0-9]{3,}", (s or "").lower()) if w not in {"the", "and", "for", "rfp", "rfq", "ifb", "services", "request", "proposal", "proposals"}}


def match_agency(name):
    """bids.db agency_id for an agency name, or None."""
    n = _norm(name)
    if not n:
        return None
    try:
        rows = db.bq("SELECT agency_id, agency FROM agency")
    except Exception:
        return None
    best = None
    for r in rows:
        a = _norm(r["agency"])
        if a and (a == n or (len(a) > 6 and (a in n or n in a))):
            if not best or len(a) > len(_norm(best["agency"])):
                best = r
    if not best:
        ws = _words(name)
        for r in rows:
            aw = _words(r["agency"])
            if aw and ws and len(aw & ws) / len(aw | ws) >= 0.6:
                return r["agency_id"]
    return best["agency_id"] if best else None


def reconcile(f):
    """Does bids.db already have this solicitation? Returns (notice_id or None, agency_id or None)."""
    aid = match_agency(f.get("agency"))
    ref = _norm(f.get("ref_no"))
    try:
        if ref and len(ref) >= 4:
            for r in db.bq("SELECT notice_id, ref_no, agency_id FROM notice WHERE ref_no IS NOT NULL AND ref_no != ''"):
                if _norm(r["ref_no"]) == ref and (not aid or not r["agency_id"] or r["agency_id"] == aid):
                    return r["notice_id"], aid
        tw = _words(f.get("title"))
        if tw:  # same agency: 60% of title words in common; agency unknown: 85%
            rows = db.bq("SELECT notice_id, title FROM notice WHERE agency_id = ?", (aid,)) if aid else \
                db.bq("SELECT notice_id, title FROM notice WHERE coalesce(published, date(first_seen)) >= date('now', '-3 years')")
            for r in rows:
                w = _words(r["title"])
                if w and len(tw & w) / len(tw | w) >= (0.6 if aid else 0.85):
                    return r["notice_id"], aid
    except Exception:
        pass
    return None, aid


def classify(text):
    import anthropic
    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY or None)
    model = (getattr(config, "UPLOAD_CLASSIFY_MODEL", "") or MODEL_DEFAULT).strip()
    resp = client.messages.create(model=model, max_tokens=900, system=PROMPT,
                                  messages=[{"role": "user", "content": "<<<DOCUMENT\n" + (text or "")[:24000] + "\nDOCUMENT>>>\nReturn the JSON only."}])
    out = "".join(getattr(b, "text", "") for b in resp.content)
    m = re.search(r"\{.*\}", out, re.S)
    return json.loads(m.group(0)) if m else {}


def check(upload_id):
    """Classify and reconcile one upload; store the outcome in upload_notice. Safe to call again (replaces the row)."""
    r = db.q("SELECT id, text, filename FROM analyst_upload WHERE id = ? AND deleted IS NULL", (upload_id,), one=True)
    if not r or not r["text"]:
        return None
    try:
        f = classify(r["text"])
    except Exception as e:
        db.x("INSERT OR REPLACE INTO upload_notice (upload_id, checked, status, note) VALUES (?,?,?,?)", (upload_id, db.now(), "error", str(e)[:300]))
        return None
    if not f.get("public_record"):
        status, nid, aid = "private", None, None
    else:
        nid, aid = reconcile(f)
        status = "duplicate" if nid else "new"
        f["description"] = (r["text"] or "")[:8000]  # public record: its own text goes with the candidate, as Bid Catcher keeps for any notice
        f["source_file"] = r["filename"]
    db.x("INSERT OR REPLACE INTO upload_notice (upload_id, checked, status, notice_id, agency_id, fields) VALUES (?,?,?,?,?,?)",
         (upload_id, db.now(), status, nid, aid, json.dumps(f, default=str)))
    return status


def check_async(upload_id):
    if not config.ANTHROPIC_API_KEY:
        return
    threading.Thread(target=check, args=(upload_id,), daemon=True).start()


def candidates(include_sent=False):
    """New public notices for Bid Catcher: the public facts only, keyed by a stable id, no member details."""
    rows = db.q("SELECT n.upload_id, n.checked, n.agency_id, n.fields, n.sent FROM upload_notice n JOIN analyst_upload u ON u.id = n.upload_id "
                "WHERE n.status = 'new' AND u.deleted IS NULL" + ("" if include_sent else " AND n.sent IS NULL") + " ORDER BY n.checked")
    out = []
    for r in rows:
        f = json.loads(r["fields"] or "{}")
        f.pop("reason", None)
        out.append(dict(f, source="member_upload", source_key="upl-" + r["upload_id"], agency_id=r["agency_id"], found=r["checked"]))
    return out


def ack(keys):
    n = 0
    for k in keys or []:
        k = str(k)
        if k.startswith("upl-"):
            db.x("UPDATE upload_notice SET sent = ? WHERE upload_id = ? AND sent IS NULL", (db.now(), k[4:]))
            n += 1
    return n


def status_map():
    return {r["upload_id"]: dict(r) for r in db.q("SELECT upload_id, status, notice_id, agency_id, sent, note FROM upload_notice")}
