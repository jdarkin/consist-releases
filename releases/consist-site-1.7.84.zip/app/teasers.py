"""Free previews of the Freight Rail Analytics Portal for members without a freight plan (the Starter tier and passenger plans).

Each card shows a small, real slice of one portal page (headline numbers only, never the tables behind them) and one line on what
the paid plan adds. They appear on the portal's locked page and on the /rail landing for signed-in members. The page a member
tried to open is shown first. A card whose data is missing is left out, so a partial data load never shows a broken card.

Proposal: "Consist pricing: three product lines" (2026-11-01), approved by Justin the same day."""
import logging

log = logging.getLogger("consist")

# (key, page paths it stands for, title, href, what the paid plan adds)
CARDS = [
    ("scoreboard", ("/rail/locomotives", "/rail/r1"), "Class I scoreboard", "/rail/locomotives",
     "The full scoreboard, R-1 history back to the 1990s and the R-1 vs 10-K comparison"),
    ("service", ("/rail/service",), "Weekly service metrics (EP 724)", "/rail/service",
     "Train speed, dwell and cars online by railroad, every week back to 2017, plus terminals and carloads"),
    ("flows", ("/rail/flows",), "Freight flows and 2050 outlook", "/rail/flows",
     "Tonnage and growth by commodity, state-to-state lanes and the low and high scenarios"),
    ("canada", ("/rail/canada",), "Canadian rail traffic", "/rail/canada",
     "Monthly history by commodity and railroad, cars per train and revenue tonne-km"),
    ("border", ("/rail/border",), "Cross-border rail", "/rail/border",
     "Every port by month, loaded and empty containers, and year-on-year change"),
    ("network", ("/rail/network",), "Network density and bridges", "/rail/network",
     "Density by subdivision, bridge and yard counts, intermodal terminals for every owner"),
    ("tankcars", ("/rail/tankcars",), "Tank car fleet", "/rail/tankcars",
     "The fleet by specification year by year, and the DOT-111 phase-out"),
    ("escalation", ("/rail/escalation", "/rail/costs", "/rail/fuel", "/rail/dollars"), "Cost escalation and forecasts", "/rail/costs",
     "Forecasts, fuel surcharge analysis and the 2025 rail-cost dollar switch"),
]


def _n(v, d=0):
    if v is None:
        return "—"
    return f"{v:,.{d}f}"


def _scoreboard():
    from . import ep724 as E, freight
    out = []
    try:
        c = freight.Cube()
        if c.latest:
            out = [(t["label"], t["show"]) for t in freight.tiles(c, c.latest) if t.get("show") not in (None, "", "—")][:2]
    except Exception:
        log.exception("teaser scoreboard")
    if not out:
        ids = E.rail_ids()
        if ids:
            out = [("Class I railroads tracked", str(len(ids)))]
    return out


def _service():
    from . import ep724 as E
    wk = E.latest_week()
    cur = [b for b in E.scoreboard() if b["last"] == wk]
    if not cur:
        return []
    spd = [b["speed"] for b in cur if b["speed"]]
    dw = [b["dwell"] for b in cur if b["dwell"]]
    on = sum(b["online"] or 0 for b in cur)
    return [("Week ending", wk), ("Average train speed", _n(sum(spd) / len(spd), 1) + " mph" if spd else "—"),
            ("Average terminal dwell", _n(sum(dw) / len(dw), 1) + " hours" if dw else "—"), ("Cars online, all Class I", _n(on))]


def _flows():
    from . import rdata as D
    tot = dict(D.faf_total())
    y0 = 2024 if 2024 in tot else min(tot or [0])
    if not tot or 2050 not in tot or not tot.get(y0):
        return []
    a, b = tot[y0][0], tot[2050][0]
    return [(f"US rail freight, {y0}", _n(a / 1e6, 2) + " billion tons"), ("2050 forecast (base)", _n(b / 1e6, 2) + " billion tons"),
            ("Growth to 2050", f"{100 * (b / a - 1):+.0f}%")]


def _canada():
    from . import statcan as S
    mo = S.monthly()
    if not mo:
        return []
    p, v = mo[-1]
    prev = next((x for q, x in mo if q == f"{int(p[:4]) - 1}{p[4:]}"), None)
    out = [("Latest month", p), ("Tonnes carried", _n(v / 1e6, 1) + " million")]
    if prev:
        out.append(("vs a year earlier", f"{100 * (v / prev - 1):+.1f}%"))
    return out


def _border():
    from . import rdata as D
    ports, y = D.border_ports("Trains")
    if not ports:
        return []
    ca = sum(p["v"] for p in ports if "Canada" in p["border"])
    mx = sum(p["v"] for p in ports if "Canada" not in p["border"])
    return [(f"Trains entering the US, {y}", _n(ca + mx)), ("From Canada", _n(ca)), ("From Mexico", _n(mx))]


def _network():
    from . import rdata as D
    own = D.owners()
    if not own:
        return []
    return [("Rail route miles mapped", _n(sum(o["miles"] for o in own))), ("Railroad bridges", _n(sum(o["bridges"] for o in own))),
            ("Owners covered", _n(len(own)))]


def _tankcars():
    from . import rdata as D
    t = D.tank_series()
    ys = sorted({y for v in t.values() for y in v})
    if not ys:
        return []
    y = ys[-1]
    tot = sum(v.get(y, 0) for v in t.values())
    d117 = sum(v.get(y, 0) for k, v in t.items() if k.startswith("DOT-117"))
    return [(f"Flammable liquid tank cars, {y}", _n(tot)), ("DOT-117 (new and retrofit)", f"{100 * d117 / tot:.0f}%" if tot else "—"),
            ("Specifications tracked", str(len(t)))]


def _escalation():
    from . import costidx as C
    r = C.rcaf()
    if not r:
        return []
    x = r[-1]
    out = [(f"RCAF, {x['year']} Q{x['quarter']}", _n(x.get("rcaf_unadj"), 3))]
    if x.get("rcaf_adj"):
        out.append(("Productivity-adjusted", _n(x["rcaf_adj"], 3)))
    return out


FN = {"scoreboard": _scoreboard, "service": _service, "flows": _flows, "canada": _canada, "border": _border, "network": _network,
      "tankcars": _tankcars, "escalation": _escalation}


def key_for(path):
    for k, paths, *_ in CARDS:
        if any(path == p or path.startswith(p + "/") for p in paths):
            return k
    return None


def cards(path=""):
    """The preview cards, the one for `path` first: [{key, title, href, stats: [(label, value)], adds}]."""
    first = key_for(path)
    out = []
    for k, _paths, title, href, adds in CARDS:
        try:
            stats = FN[k]()
        except Exception:
            log.exception("teaser %s", k)
            stats = []
        if stats:
            out.append(dict(key=k, title=title, href=href, stats=stats, adds=adds, here=k == first))
    return sorted(out, key=lambda c: not c["here"])
