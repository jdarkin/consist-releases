"""Account brief module picker (1.7.52, Justin 11-16): the Account brief button on an operator page opens a menu of every card on
that page plus the agency's funding and capital project records; the member ticks what to include and presses Generate brief.
The brief prints or saves as PDF from the browser, as before. Each module follows the member's plan: a module whose page is locked
is not offered, and a page on preview is trimmed to its first rows like the page itself. The last choice is remembered
(user_pref brief_mods). Funding and capital records are for this agency whatever the Territory switch or lens says."""
from . import data, db, intel, lens

# (key, label, group). Order here is the order in the menu and in the brief.
MODULES = [
    ("stats", "Key figures (cars, fleets, riders, operating cost)", "Overview"),
    ("signals", "Why now (signals)", "Overview"),
    ("fleets", "Fleets", "Fleet and costs"),
    ("costs", "Cost per car revenue-mile, by mode (charts)", "Fleet and costs"),
    ("consumables", "Consumables and overhauls", "Fleet and costs"),
    ("reliability", "Reliability, spares and contracting", "Fleet and costs"),
    ("reported", "Reported costs (agency annual reports)", "Fleet and costs"),
    ("roster", "Locomotive roster", "Fleet and costs"),
    ("r1", "Locomotive cost and use (STB R-1)", "Fleet and costs"),
    ("trainctl", "Train control", "Fleet and costs"),
    ("power", "Power supply", "Fleet and costs"),
    ("bids", "Recent rail bids", "Bids and buying"),
    ("meetings", "Board meetings and documents", "Bids and buying"),
    ("orders", "Vehicle orders", "Bids and buying"),
    ("awards", "Recent awards", "Bids and buying"),
    ("programs", "Programs, funding and contracts on file", "Funding"),
    ("grants", "Federal transit grants (FTA)", "Funding"),
    ("budget", "Budget, capital plan and board funding items", "Funding"),
    ("capital", "Capital projects out to bid", "Capital projects"),
    ("oncall", "On-call contracts and when they end", "Capital projects"),
    ("contacts", "Contacts", "Your team"),
    ("notes", "Team notes", "Your team"),
]
LABELS = {k: lbl for k, lbl, _ in MODULES}
PREVIEW_ROWS = 3


def _acc(u, path):
    if u.is_admin:
        return "full"
    from . import pages
    return pages.access(u.plan, path)


def access(u):
    """{module: 'full' | 'preview'} for the modules this member's plan includes."""
    from . import config
    out = {k: "full" for k, _, _ in MODULES}
    bids = "none" if not (u.is_admin or u.bids) else _acc(u, "/app/bids")
    out["meetings"] = bids
    if not u.can("awards"):
        out["awards"] = "none"
    fund = _acc(u, "/app/awards") if u.can("awards") else "none"
    out["grants"] = out["budget"] = fund
    cap = _acc(u, "/app/capital-pipeline")
    out["capital"] = out["oncall"] = cap
    if not u.can("account_notes"):
        out["contacts"] = out["notes"] = "none"
    if not config.NX_FEATURES:
        out["trainctl"] = "none"
    return {k: v for k, v in out.items() if v != "none"}


def offered(u, rail=False):
    """[(group, [(key, label)])] for the menu: what this member may include on this kind of operator page."""
    acc = access(u)
    skip = {"stats", "costs", "consumables", "reported", "meetings", "trainctl", "power"} if rail else {"roster", "r1"}
    groups = []
    for k, lbl, g in MODULES:
        if k not in acc or k in skip:
            continue
        if not groups or groups[-1][0] != g:
            groups.append((g, []))
        groups[-1][1].append((k, lbl))
    return groups


def chosen(u, request, rail=False):
    """The modules for this brief: ?m= from the menu (saved for next time), else the last choice, else everything offered."""
    ok = [k for _, items in offered(u, rail) for k, _ in items]
    picked = [m for m in request.query_params.getlist("m") if m in ok]
    if picked:
        try:
            intel.set_pref(u, "brief_mods", ",".join(picked))
        except Exception:
            pass
        return picked
    last = [m for m in (intel.pref(u, "brief_mods", "") or "").split(",") if m in ok]
    return last or ok


def remembered(u, rail=False):
    """The ticks the menu opens with."""
    ok = [k for _, items in offered(u, rail) for k, _ in items]
    last = [m for m in (intel.pref(u, "brief_mods", "") or "").split(",") if m in ok]
    return set(last or ok)


def agency_ids(oid):
    """Bid Catcher agencies that buy for this operator."""
    try:
        return [r["agency_id"] for r in db.bq("SELECT agency_id FROM agency WHERE operator_id = ? OR (';' || coalesce(fleet_operator_ids, '') || ';') LIKE ?",
                                              (oid, f"%;{oid};%"))]
    except Exception:
        try:
            return [r["agency_id"] for r in db.bq("SELECT agency_id FROM agency WHERE (';' || coalesce(fleet_operator_ids, '') || ';') LIKE ?", (f"%;{oid};%",))]
        except Exception:
            return []


def _mine(r, oid, ags):
    ids = [x for x in (r.get("fleet_operator_ids") or "").split(";") if x]
    return r.get("operator_id") == oid or oid in ids or (r.get("agency_id") and r["agency_id"] in ags)


def gather(u, oid, sel):
    """Funding and capital records for the chosen modules, unscoped (the brief is about one agency), trimmed on preview."""
    from . import award_analyst, nexgen2
    acc = access(u)
    ags = agency_ids(oid)
    out = {"agency_ids": ags, "trimmed": []}
    tok = lens.set_current(lens.Scope())
    try:
        if "grants" in sel:
            g = award_analyst.grants(ags, rail_only=False, limit=40) if ags else []
            for r in g:
                r["program_name"] = award_analyst.CFDA.get(r.get("cfda") or "", f"FTA program {r.get('cfda') or ''}".strip())
            if not g:  # no FTA grant rows tied to the agency: federal awards matched by recipient name
                from . import fundprog
                g = [dict(r, program_name=(fundprog.PROG.get(r.get("prog")) or (None, r.get("prog") or r.get("aln") or "Federal award"))[1]) for r in nexgen2.funding_for(oid, 20)]
            out["grants"] = g
        if "budget" in sel:
            out["budget"] = award_analyst.budget_items(ags, limit=40) if ags else []
            out["STAGES"] = award_analyst.STAGES
        if "capital" in sel:
            rows, _ = nexgen2.capital_pipeline(730, {})
            out["capital"] = [r for r in rows if _mine(r, oid, ags)][:25]
        if "oncall" in sel:
            rows, _ = nexgen2.oncall_expiry({})
            out["oncall"] = [r for r in rows if _mine(r, oid, ags)][:25]
    finally:
        lens.reset(tok)
    for k in ("grants", "budget", "capital", "oncall"):
        if k in out and acc.get(k) == "preview" and len(out[k]) > PREVIEW_ROWS:
            out[k] = out[k][:PREVIEW_ROWS]
            out["trimmed"].append(LABELS[k])
    return out
