"""Market lenses and the pages built on them: lens and region prefs, Upcoming work (one timeline over replacements,
overhauls, rebuilds and options), Subsystems and Cost benchmarks."""
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Request

from . import auth, config, costs as costmod, data, intel, lens, om, territory
from .main import flash, redirect, render
from .routes_app import bar_links, bar_pick, bar_rows, csv_response, params, procurements, pipeline
from .routes_intel import facets, forecast, locked, opportunities

router = APIRouter(prefix="/app")
U = Depends(auth.require_user)

WORK_KEYS = ("type", "years", "mode", "cls", "operator", "oem", "signal", "q", "pstage", "ordered")


# ---------- lens and region ----------

@router.post("/prefs/lens")
async def set_lens(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    v = form.get("lens") or ""
    if v in lens.lenses():
        intel.set_pref(u, "lens", v)
    if not form.get("keep_regions"):  # the freight portal's market switch changes only the lens
        intel.set_pref(u, "regions", ",".join(r for r in form.getlist("region") if r in lens.REGIONS))
    back = form.get("back") or "/app"
    # drop a one-off ?lens= or ?region= so the saved choice shows
    if "?" in back:
        path, q = back.split("?", 1)
        keep = [p for p in q.split("&") if not p.startswith(("lens=", "region="))]
        back = path + ("?" + "&".join(keep) if keep else "")
    return redirect(back if back.startswith("/app") else "/app")


@router.post("/account/market")
async def account_market(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    regions = [r for r in form.getlist("region") if r in lens.REGIONS]
    picks = form.getlist("persona")
    primary = form.get("primary") or ""
    if primary in picks:  # the dashboard you land on goes first
        picks = [primary] + [p for p in picks if p != primary]
    intel.set_personas(u, picks, regions)
    if form.get("lens_paid") in lens.LENS_MODES and form.get("lens_paid") in lens.lenses():
        intel.set_pref(u, "lens_paid", form.get("lens_paid"))
    flash(request, "Saved.")
    return redirect("/app/account#market")


@router.post("/account/territory")
async def account_territory(request: Request, u=U):
    """1.7.45: save the sales territory (states and provinces, picked agencies, national buyers)."""
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    if form.get("clear"):
        for k in ("ter_states", "ter_ops", "ter_ags", "ter_on"):
            intel.set_pref(u, k, "")
        flash(request, "Territory cleared. Every page shows all agencies again.")
    elif territory.save(u, form):
        flash(request, "Territory saved and switched on. Use the Territory switch at the top of any page to turn it off.")
    else:
        flash(request, "Nothing picked, so there is no territory to switch on.")
    return redirect("/app/account#territory")


@router.post("/prefs/territory")
async def set_territory(request: Request, u=U):
    """1.7.45: the header Territory switch."""
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    if not territory.is_set(territory.for_user(u)):
        return redirect("/app/account#territory")
    intel.set_pref(u, "ter_on", "1" if form.get("on") == "1" else "0")
    back = form.get("back") or "/app"
    if "?" in back:  # drop a one-off ?territory= so the saved choice shows
        path, q = back.split("?", 1)
        keep = [p for p in q.split("&") if not p.startswith("territory=")]
        back = path + ("?" + "&".join(keep) if keep else "")
    return redirect(back if back.startswith("/app") else "/app")


@router.post("/prefs/trades")
async def set_trades(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    intel.set_pref(u, "trades", ",".join(t for t in form.getlist("trade") if t in data.CATEGORIES))
    flash(request, "Your trades are saved. The bid feed shows them first.")
    return redirect("/app/bids?trade=mine")


# ---------- upcoming work ----------

def om_view(request, u):
    if not u.can("opportunities"):
        return locked(request, u, "opportunities", "O&M contracts")
    cs = om.contracts()
    st = request.query_params.get("status")
    shown = [c for c in cs if c["status"] == st] if st in ("window", "soon", "later", "unknown", "expired") else cs
    kind = request.query_params.get("kind") or None  # pill filters (1.7.4): contract kind, outsourcing model
    if kind:
        shown = [c for c in shown if c["kind"] == kind]
    out, yr = om.outsourcing()
    model = request.query_params.get("model") or None
    if model:
        out = [d for d in out if d.get("model") == model]
    if request.query_params.get("export"):
        if not u.can("export"):
            return locked(request, u, "export", "CSV export")
        return csv_response("om-contracts", ["operator_name", "mode", "kind", "vendor", "scope", "start_date", "end", "end_basis", "window",
                                             "status", "value_usd", "annual_usd", "confidence", "source_url"], shown)
    counts = {k: sum(1 for c in cs if c["status"] == k) for k in ("window", "soon", "later", "unknown", "expired")}
    # future opportunity chart (Justin, 2026-11-03): contracts by the year they are likely to be competed again, by kind; overdue counts as now
    yr = intel.this_year()
    rfp_year = lambda c: max(yr, c["window"].year) if c.get("window") else None
    for c in cs:
        c["rfp_year"] = rfp_year(c) if c["status"] not in ("expired", "unknown") else None
    kinds = [k for k in intel.CONTRACT_KINDS if any(c["kind"] == k and c["rfp_year"] for c in cs)]
    by_year = {y: {} for y in range(yr, yr + 8)}
    for c in cs:
        if c["rfp_year"] and c["rfp_year"] < yr + 8:
            by_year[c["rfp_year"]].setdefault(c["kind"], 0)
            by_year[c["rfp_year"]][c["kind"]] += 1
    sel = bar_pick(request)
    if sel:
        shown = [c for c in shown if c["rfp_year"] == sel[0] and (sel[1] is None or c["kind"] == sel[1])]
    f = {k: v for k, v in (("view", "om"), ("status", st), ("kind", kind), ("model", model)) if v}
    return render(request, "app/work_om.html", user=u, f=f, contracts=shown, by_year=by_year, kinds=kinds, sel=sel,
                  bar_href=bar_links("/app/work", {"view": "om", **({"status": st} if st else {})}), counts=counts, om_status=st, outs=out, ntd_year=yr,
                  contractors=om.by_contractor([c for c in cs if c["status"] != "expired"]), bids=om.open_bids(),
                  FUNCTIONS=om.FUNCTIONS, today=__import__("datetime").date.today())


@router.get("/work")
def work(request: Request, u=U):
    view = request.query_params.get("view", "timeline")
    if view == "ranked":
        return opportunities(request, u)
    if view == "forecast":
        return forecast(request, u)
    if view == "pipeline":
        return pipeline(request, u)
    if view == "orders":
        return procurements(request, u)
    if view == "om":
        return om_view(request, u)
    if not u.can("opportunities"):
        return locked(request, u, "opportunities", "Upcoming work")
    f = params(request, WORK_KEYS)
    types = [t for t in (f.get("type") or "").split(",") if t in intel.WORK_TYPES] or list(intel.WORK_TYPES)
    try:
        years = min(20, max(1, int(f.get("years") or 10)))
    except ValueError:
        years = 10
    rows = intel.work_timeline(types, years, {k: v for k, v in f.items() if k not in ("type", "years", "pstage")})
    if config.NX_FEATURES and f.get("pstage"):
        from . import nexgen
        if f["pstage"] == "open":
            rows = [o for o in rows if o["type"] != "buy" or nexgen.stage_open(o["fleet"]["fleet_id"])]
        elif f["pstage"] == "researched":
            rows = [o for o in rows if nexgen.proc_stage(o["fleet"]["fleet_id"])]
        elif f["pstage"] in nexgen.PROC_STAGES:
            rows = [o for o in rows if (nexgen.proc_stage(o["fleet"]["fleet_id"]) or {}).get("stage") == f["pstage"]]
    sel = bar_pick(request)
    if request.query_params.get("export"):
        if not u.can("export"):
            return locked(request, u, "export", "CSV export")
        flat = [{"year": o["year"], "type": intel.WORK_TYPES[o["type"]], "event": intel.EVENT_LABELS.get(o["event"], o["event"]),
                 "operator": o["fleet"]["operator_name"], "manufacturer": o["fleet"]["manufacturer"], "model": o["fleet"]["model_name"],
                 "mode": o["fleet"]["ntd_mode"], "country": o["fleet"]["country"], "cars": o["cars"], "value_usd": round(o["value"] or 0),
                 "score": o["score"], "detail": o.get("detail") or "",
                 "fleet_url": f"/app/fleets/{o['fleet']['fleet_id']}" if o["fleet"]["fleet_id"] else f"/app/work/orders/{o.get('order_id')}"} for o in rows]
        if config.NX_FEATURES:
            from . import nexgen
            for o, r in zip(rows, flat):
                ps = nexgen.proc_stage(o["fleet"]["fleet_id"]) or {}
                r.update(procurement_stage=ps.get("stage", ""), expected_rfp=ps.get("expected_rfp", ""), awarded_to=ps.get("awarded_to", ""), stage_checked=ps.get("checked", ""))
        return csv_response("consist-upcoming-work", list(flat[0].keys()) if flat else ["year"], flat)
    yr = intel.this_year()
    when = lambda o: max(o["year"], yr)  # the chart starts at the current year; overdue work counts as this year (Justin, 2026-11-03)
    by_year = {}
    for o in rows:
        by_year.setdefault(when(o), {}).setdefault(o["type"], 0)
        by_year[when(o)][o["type"]] += o["cars"]
    for y in range(yr, yr + min(years, 12)):
        by_year.setdefault(y, {})
    by_year = {y: v for y, v in by_year.items() if y <= yr + min(years, 12) - 1}
    counts = {t: sum(1 for o in rows if o["type"] == t) for t in intel.WORK_TYPES}
    base = {k: v for k, v in f.items() if k != "type"}
    n_all, total, cars = len(rows), sum(o["value"] or 0 for o in rows), sum(o["cars"] for o in rows)
    rows = bar_rows(rows, sel, when, lambda o: o["type"])
    on = f.get("ordered") == "1"
    n_ordered = intel.ordered_hidden({k: v for k, v in f.items() if k in ("mode", "cls", "operator", "oem", "q")}) if "buy" in types else 0
    ordered_href = "/app/work?" + urlencode({k: v for k, v in {**f, "ordered": "" if on else "1"}.items() if v}) + "#list"
    return render(request, "app/work.html", user=u, f=f, rows=rows[:300], n_ordered=n_ordered, ordered_on=on, ordered_href=ordered_href, n=len(rows), types=types, years=years, by_year=by_year,
                  counts=counts, total=total, cars=cars, facets=facets(),
                  base_qs=urlencode(base), qs=urlencode(f), WORK_TYPES=intel.WORK_TYPES, signals=intel.SIGNALS,
                  n_all=n_all, sel=sel, bar_href=bar_links("/app/work", f))


# ---------- subsystems ----------

@router.get("/subsystems")
def subsystems(request: Request, u=U):
    f = params(request, ("subsystem", "supplier", "due"))
    sub = f.get("subsystem") if f.get("subsystem") in data.SUBSYSTEMS else None
    v = intel.subsystem_view(sub, f.get("supplier"), f.get("due") if (f.get("due") or "").isdigit() else None)
    deep = u.can("market")
    if request.query_params.get("export") and u.can("export"):
        rows = [{"subsystem": r["rec"]["subsystem"], "supplier": r["supplier_name"], "product": r["rec"]["product"],
                 "operator": r["fleet"]["operator_name"], "manufacturer": r["fleet"]["manufacturer"], "model": r["fleet"]["model_name"],
                 "cars": r["fleet"]["qty_active"], "installed": r["installed"], "next_overhaul": r["next"], "confidence": r["rec"]["confidence"],
                 "source": r["rec"]["source_url"]} for r in v["rows"]]
        return csv_response("consist-subsystems", list(rows[0].keys()) if rows else ["subsystem"], rows)
    suppliers = sorted({(r["rec"]["supplier_id"] or r["supplier_name"], r["supplier_name"]) for r in intel.subsystem_view(sub)["rows"]},
                       key=lambda s: s[1])
    return render(request, "app/subsystems.html", user=u, f=f, sub=sub, v=v, rows=v["rows"][:300 if deep else 15], deep=deep,
                  suppliers=suppliers, qs=urlencode(f))


# ---------- cost benchmarks ----------

@router.get("/costs")
def costs(request: Request, u=U):
    if not u.can("fleet_detail"):
        return locked(request, u, "fleet_detail", "Cost benchmarks")
    sc = lens.current()
    p = costmod.parse(request)
    v = None if sc.lens == "freight" else costmod.view(p)
    frt, fcost, fmiles = intel.freight_costs()
    if request.query_params.get("export") and u.can("export"):
        which = request.query_params.get("export")
        if which == "freight":
            cols = ["r1_entity", "entity_name", "report_year", "units_end", "miles_per_unit", "repairs_per_unit_mile_2025usd",
                    "loco_cost_per_unit_mile_2025usd", "loco_cost_per_unit_mile_2025usd_yoy_pct", "fuel_gal_per_k_gtm", "source_url"]
            return csv_response("consist-freight-loco-costs", cols, frt)
        if v and which == "segments":
            dl = dict(v["dims"])
            cols = ["segment", "rows", "operators", "median", "p25", "p75", "mean", "min", "max"] + (["cars", "car_weighted_mean"] if p["level"] == "fleet" else [])
            rows = [{"segment": s["label"], "rows": s["n"], "operators": s["ops"], "median": s["median"], "p25": s["p25"], "p75": s["p75"],
                     "mean": s["mean"], "min": s["min"], "max": s["max"], "cars": s.get("cars"), "car_weighted_mean": s.get("wmean")} for s in v["segments"]]
            return csv_response(f"consist-cost-segments-{p['metric']}-by-{p['by']}", cols, rows)
        if v:
            cols, rows = costmod.export_rows(v, p["level"])
            return csv_response(f"consist-costs-{p['level']}", cols, rows)
    return render(request, "app/costs.html", user=u, v=v, p=p, levels=costmod.LEVELS, cqs=lambda **o: costmod.qs(p, **o),
                  frt=frt, fcost=fcost, fmiles=fmiles)
