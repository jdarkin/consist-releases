"""Short lines and regionals (FRA Class II and III) and the portal-wide definitions page, inside the Freight Rail Analytics Portal.
See shortline.py. Access follows the rest of /rail (routes_rail.gate)."""
from fastapi import APIRouter, HTTPException, Request

from . import freight, r1assets, shortline as S
from .main import render
from .routes_app import csv_response
from .routes_rail import gate

router = APIRouter(prefix="/rail")
COLS = ["railroad", "fra_class", "holding_company", "state", "train_miles", "yard_share", "fte", "miles_per_hour", "accidents", "acc_rate",
        "collisions", "crossings", "route_miles"]


def _y(request):
    ys = S.years()
    try:
        y = int(request.query_params.get("y") or 0)
    except ValueError:
        y = 0
    return y if y in ys else (ys[-1] if ys else None)


@router.get("/shortlines")
def home(request: Request):
    u, r = gate(request, "Short lines and regionals")
    if r:
        return r
    y, cls, hc = _y(request), request.query_params.get("cls", request.cookies.get("rseg", "")), request.query_params.get("hc", "")
    cls = cls if cls in S.CLASSES else ""
    rows = S.railroads(y, cls, hc) if y else []
    if request.query_params.get("export"):
        return csv_response("consist-shortlines", ["fra_code", "name"] + COLS[1:],
                            [{k: r.get(k) for k in ["fra_code", "name"] + COLS[1:]} for r in rows])
    return render(request, "rail/shortlines.html", user=u, S=S, y=y, cls=cls, hc=hc, rows=rows, groups=S.holding(y, cls) if y else [],
                  tot=S.totals(), ok=S.available())


@router.get("/shortlines/{code}")
def railroad(request: Request, code: str):
    u, r = gate(request, "Short lines and regionals")
    if r:
        return r
    rr = S.railroad(code)
    if not rr:
        raise HTTPException(404)
    return render(request, "rail/shortline.html", user=u, S=S, rr=rr)


@router.get("/shortlines/{code}/news")
def railroad_news(request: Request, code: str):
    u, r = gate(request, "Short lines and regionals")
    if r:
        return r
    rr = S.railroad(code)
    if not rr:
        raise HTTPException(404)
    from .routes_app import news_page
    return news_page(request, u, "sl:" + code, rr["name"], [], f"/rail/shortlines/{code}", rail=True)


@router.get("/definitions")
def definitions(request: Request):
    u, r = gate(request, "Definitions")
    if r:
        return r
    r1 = [(m["title"], [r1assets.M[k] for k in dict.fromkeys(m["tiles"] + m["table"] + m.get("mix", ("", []))[1] + m.get("mix2", ("", []))[1]
                                                            + [x for _, ks in m.get("statements", []) for x in ks]) if k in r1assets.M])
          for m in r1assets.MODULES.values()]
    loco = [(g, [d for d in freight.M.values() if d["group"] == g]) for g in freight.GROUPS]
    from . import costidx, railcars
    return render(request, "rail/definitions.html", user=u, r1=r1, loco=loco, sl=S.DEF, R=r1assets, ci=costidx.DEF, ci_credit=costidx.CREDIT,
                  rc=railcars.DEF, rc_credit=railcars.CREDIT)


# ----- segment switch (All / Class I / Regional / Short line), remembered in a cookie for a year -----
SEGS = ("all", "1", "2", "3")


@router.get("/seg")
def seg(request: Request, s: str = "all", next: str = "/rail"):
    from fastapi.responses import RedirectResponse
    dest = next if next.startswith("/rail") and "//" not in next else "/rail"
    if dest.startswith("/rail/shortlines"):  # the railroad list follows the segment
        dest = "/rail/shortlines" + (f"?cls={s}" if s in ("1", "2", "3") else "")
    r = RedirectResponse(dest, status_code=303)
    r.set_cookie("rseg", s if s in SEGS else "all", max_age=31536000, samesite="lax", httponly=True)
    return r


def segment(request):
    v = request.cookies.get("rseg", "all")
    return v if v in SEGS else "all"


# ----- R-1 (US railroad subsidiary) vs 10-K (listed parent) side by side -----
PAIRS = [("Revenue", "is_revenue", "x_revenue"), ("Operating expenses", "is_opex", "x_opex"), ("Operating income", "is_opinc", "x_opinc"),
         ("Operating margin", "is_op_margin", "x_op_margin"), ("Net income", "is_ni", "x_ni"), ("Net margin", "is_net_margin", "x_net_margin"),
         ("EBITDA", "is_ebitda", "x_ebitda"), ("Total assets", "bs_assets", "x_assets"), ("Debt", "bs_debt", "x_debt"),
         ("Equity", "bs_equity", "x_equity"), ("Return on equity", "r_roe", "x_roe"), ("Debt / EBITDA", "r_debt_ebitda", "x_debt_ebitda"),
         ("Cash from operations", "cf_cfo", "x_cfo"), ("Capital expenditures", "cf_capex", "x_capex"), ("Free cash flow", "cf_fcf", "x_fcf"),
         ("Dividends paid", "cf_dividends", "x_dividends")]
CAD = {"CN_RAIL", "CPKC"}


@router.get("/compare")
def compare(request: Request, rr: str = "", y: int = 0):
    u, r = gate(request, "R-1 vs 10-K")
    if r:
        return r
    R = r1assets
    ys = R.years()
    y = y if y in ys else (ys[-1] if ys else 0)
    rr = rr if rr in R.ids() else (R.ids()[0] if R.ids() else "")
    rows = []
    for lab, a, b in PAIRS:
        if a not in R.M or b not in R.M:
            continue
        va, vb = R.value(a, rr, y), R.value(b, rr, y)
        pct = R.M[a]["fmt"] == "pct" or R.M[a]["fmt"] in ("1", "2")
        gap = None
        if va is not None and vb is not None and rr not in CAD:
            gap = (vb - va) if pct else ((vb - va) / abs(va) * 100 if va else None)
        rows.append(dict(label=lab, a=a, b=b, sa=R.fmt(a, va), sb=R.fmt(b, vb), ha=R.link(a, rr, y), hb=R.link(b, rr, y),
                         da=R.M[a]["definition"], db=R.M[b]["definition"], gap=gap, ratio=pct))
    return render(request, "rail/compare.html", user=u, rows=rows, rr=rr, y=y, ys=ys, R=R, cad=rr in CAD)


# ----- dollar basis switch, cost escalation (RCAF + fuel index) and fuel surcharges -----
@router.get("/dollars")
def dollars(request: Request, d: str = "filed", next: str = "/rail"):
    from fastapi.responses import RedirectResponse
    dest = next if next.startswith("/rail") and "//" not in next else "/rail"
    from . import auth, lens
    if d == "rail" and not lens.rail_team_ok(auth.current_user(request)):  # a Freight Team tool
        return RedirectResponse("/pricing#freight", status_code=303)
    r = RedirectResponse(dest, status_code=303)
    r.set_cookie("rdol", "rail" if d == "rail" else "filed", max_age=31536000, samesite="lax", httponly=True)
    return r


def _rebase(pts, base_year=2020):
    b = [p[1] for p in pts if int(p[0]) == base_year and p[1]]
    b = sum(b) / len(b) if b else None
    return [(p[0], 100 * p[1] / b if b and p[1] else None) + tuple(p[2:]) for p in pts]


@router.get("/costs")
def costs(request: Request):
    u, r = gate(request, "Rail cost and fuel indexes")
    if r:
        return r
    return cost_indexes(request, u, True)


def cost_indexes(request, u, rail):
    """RCAF and AAR fuel indexes; also in the passenger app at /app/cost-indexes (Justin, 2026-11-03)."""
    from . import charts, costidx as C
    rq = [x for x in C.rcaf() if x["year"] >= 2018]
    fq = C.fuel_quarterly()
    q = lambda y, n: y + (n - 1) / 4
    if request.query_params.get("export"):
        cols = ["year", "quarter", "rcaf_unadj", "rcaf_adj", "rcaf5", "forecast_error", "fuel_idx"]
        rows = [dict(x, fuel_idx=fq.get((x["year"], x["quarter"]))) for x in rq]
        return csv_response("consist-rail-cost-indexes", cols, rows)
    ch = charts.line([("RCAF (unadjusted)", _rebase([(q(x["year"], x["quarter"]), x["rcaf_unadj"], f"#q{x['year']}{x['quarter']}") for x in rq])),
                      ("AAR fuel price index", _rebase([(q(*k), v, f"#q{k[0]}{k[1]}") for k, v in sorted(fq.items()) if k[0] >= 2018]))],
                     title="Rail input costs and fuel price, 2020 = 100")
    ch2 = charts.line([("RCAF (adjusted)", [(q(x["year"], x["quarter"]), x["rcaf_adj"], f"#q{x['year']}{x['quarter']}") for x in rq]),
                       ("RCAF-5", [(q(x["year"], x["quarter"]), x["rcaf5"], f"#q{x['year']}{x['quarter']}") for x in rq])], title="Productivity-adjusted RCAF")
    fa, ra = C.fuel_annual(), C.rcaf_annual()
    annual = [dict(year=y, rcaf=ra.get(y), fuel=fa.get(y), defl=C.deflator(y)) for y in sorted(set(ra) | set(fa)) if y >= 2018]
    return render(request, "rail/costs.html", user=u, C=C, rq=list(reversed(rq)), fq=fq, ch=ch, ch2=ch2, annual=annual, rail=rail,
                  root="/rail/costs" if rail else "/app/cost-indexes")


@router.get("/fuel")
def fuel(request: Request, y: int = 0, rr: str = ""):
    from . import charts, costidx as C
    u, r = gate(request, "Fuel cost and surcharges")
    if r:
        return r
    fa = C.fsc_annual()
    ys = sorted({k[1] for k in fa})
    y = y if y in ys else (ys[-1] if ys else 0)
    ops = r1assets.ids()
    rows = []
    for o in ops:
        a = fa.get((o, y))
        if not a:
            continue
        rev = r1assets.value("is_revenue", o, y) if "is_revenue" in r1assets.M else None
        a = dict(a, label=r1assets.RAILROADS[o][0], name=r1assets.RAILROADS[o][1],
                 fsc_share=100 * a["fsc_revenue"] / rev if rev else None)  # both $ thousands as filed
        rows.append(a)
    if request.query_params.get("export"):
        cols = ["op", "year", "quarter", "fuel_cost", "gallons", "per_gal", "fsc_revenue", "fsc_regulated", "recovery", "net_fuel"]
        return csv_response("consist-fuel-surcharges", cols, C.fsc())
    q = lambda yy, n: yy + (n - 1) / 4
    rec = charts.line([(r1assets.RAILROADS[o][0], [(q(x["year"], x["quarter"]), x["recovery"], f"/rail/fuel/{o}#q{x['year']}{x['quarter']}") for x in C.fsc() if x["op"] == o]) for o in ops],
                      title="Fuel surcharge recovery by quarter, %")
    lag = C.lag_table(rr or None)
    fq = C.fuel_quarterly()
    pg = charts.line([("Fuel cost per gallon", [(q(x["year"], x["quarter"]), x["per_gal"]) for x in lag]),
                      ("Surcharge per gallon", [(q(x["year"], x["quarter"]), x["fsc_per_gal"]) for x in lag])], prefix="$",
                     title="Class I fuel cost and surcharge per gallon")
    trend = []
    for yy in ys:
        g = [v for k, v in fa.items() if k[1] == yy]
        fc, rv, gl = sum(x["fuel_cost"] for x in g), sum(x["fsc_revenue"] for x in g), sum(x["gallons"] for x in g)
        trend.append(dict(year=yy, n=len(g), fuel_cost=fc, fsc_revenue=rv, recovery=100 * rv / fc if fc else None,
                          per_gal=fc / gl if gl else None, fuel_idx=C.fuel_annual().get(yy)))
    return render(request, "rail/fuel.html", user=u, C=C, R=r1assets, rows=rows, y=y, ys=ys, rec=rec, pg=pg, trend=trend,
                  lag=list(reversed(lag[-12:])), rr=rr)


# ----- freight cars: private (X-mark) vs railroad vs TTX -----
TANK_LABELS = {"tank_cars_class3_fl": "Tank cars moving Class 3 flammable liquids", "dot117_in_fl_service": "DOT-117 / 117R cars in that service",
               "dot117_non_crude": "DOT-117s in non-crude flammable service", "dot117_crude_share": "Crude oil share of DOT-117 use",
               "cpc1232_in_fl_service": "CPC-1232 cars still in that service", "projected_new_dot117": "New DOT-117s projected",
               "projected_dot117r_retrofits": "DOT-117R retrofits projected", "non_dot117_remaining": "Cars still to replace or retrofit by 2029",
               "dot117_needed_per_year": "DOT-117s needed per year to meet 2029", "fl_shipments_crude": "Crude oil tank car shipments",
               "fl_shipments_ethanol": "Ethanol tank car shipments", "fl_shipments_other": "Other flammable liquid shipments",
               "fl_shipments_total": "All flammable liquid tank car shipments"}


@router.get("/railcars")
def railcars(request: Request, y: int = 0, q: str = ""):
    from . import charts, db, railcars as RC
    if db.settings().get("railcars_on") != "1":  # switched off in Admin > Settings > General
        from . import auth
        cu = auth.current_user(request)
        if not (cu and cu.is_admin):
            raise HTTPException(404)
    u, r = gate(request, "Freight cars")
    if r:
        return r
    if not RC.available():
        return render(request, "rail/nofra.html", user=u, title="Freight cars")
    ys = RC.years()
    y = y if y in ys else ys[-1]
    trend = RC.share_trend()
    ch = charts.line([(RC.OWN[o], [(t["year"], t[o], f"/rail/railcars?y={t['year']}#types") for t in trend]) for o in RC.OWN], title="Share of carloads by car owner, %")
    if request.query_params.get("export"):
        return csv_response("consist-freight-car-ownership", ["year", "code", "car_type", "tot", "P", "R", "T"],
                            [dict(d, year=y) for d in RC.by_car_type(y)])
    les = RC.lessors()
    lch = charts.line([(c, [(int(str(x["fiscal_year_end"])[:4]), x["railcars"]) for x in les if x["company"] == c])
                       for c in dict.fromkeys(x["company"] for x in les)], title="Lessor fleets, railcars")
    return render(request, "rail/railcars.html", user=u, RC=RC, y=y, ys=ys, trend=trend, ch=ch, types=RC.by_car_type(y),
                  comm=RC.commodities(y), equip=RC.equipment(y), marks=RC.marks(q), cats=RC.mark_categories(), q=q,
                  les=les, lch=lch, tank=RC.tank_cars(), TL=TANK_LABELS, comparable=RC.comparable(y))


@router.get("/fuel/{op}")
def fuel_rr(request: Request, op: str):
    from . import charts, costidx as C
    u, r = gate(request, "Fuel cost and surcharges")
    if r:
        return r
    if op not in r1assets.RAILROADS:
        raise HTTPException(404)
    rows = [x for x in C.fsc() if x["op"] == op]
    fq = C.fuel_quarterly()
    q = lambda yy, n: yy + (n - 1) / 4
    ch = charts.line([("Fuel cost per gallon", [(q(x["year"], x["quarter"]), x["per_gal"], f"#q{x['year']}{x['quarter']}") for x in rows]),
                      ("Surcharge per gallon", [(q(x["year"], x["quarter"]), x["fsc_per_gal"], f"#q{x['year']}{x['quarter']}") for x in rows])],
                     prefix="$", title="Fuel cost and surcharge per gallon")
    return render(request, "rail/fuel_rr.html", user=u, C=C, op=op, rrname=r1assets.RAILROADS[op][1], label=r1assets.RAILROADS[op][0],
                  rows=list(reversed(rows)), fq=fq, ch=ch)


# ----- Operating summaries: the data set follows the segment switch -----
OPS_KEYS = ["train_miles", "road_train_miles", "yard_share", "fte", "miles_per_hour", "accidents", "acc_rate", "collisions"]


@router.get("/operations")
def operations(request: Request, y: int = 0):
    import datetime
    from . import charts
    u, r = gate(request, "Operating summaries")
    if r:
        return r
    seg = segment(request)
    cls = seg if seg in S.CLASSES else ""
    tot = S.totals()
    full = [t for t in tot if t["year"] < datetime.date.today().year] or tot
    ys = [t["year"] for t in full]
    y = y if y in ys else (ys[-1] if ys else 0)
    classes = [cls] if cls else list(S.CLASSES)
    # FRA operations for every class in the segment, by year (Form 55): what every freight railroad reports
    trend = []
    for t in full:
        row = dict(year=t["year"])
        agg = dict(train_miles=0, yard_miles=0, employee_hours=0, accidents=0, collisions=0, damage=0, railroads=0)
        for c in classes:
            for k in agg:
                agg[k] += t[c].get(k) or 0
        row.update(S._derive(agg), railroads=agg["railroads"], by={c: t[c] for c in classes})
        trend.append(row)
    lab = {"1": "Class I", "2": "Regional", "3": "Short line"}
    ch = charts.line([(S.CLASSES[c], [(t["year"], t["by"][c]["train_miles"], f"/rail/operations?y={t['year']}#rrs") for t in trend]) for c in classes],
                     title="Train-miles by FRA class")
    ch2 = charts.line([(S.CLASSES[c], [(t["year"], t["by"][c].get("acc_rate"), f"/rail/operations?y={t['year']}#rrs") for t in trend]) for c in classes],
                      title="Train accidents per million train-miles")
    rows = S.railroads(y, cls)[:60]
    if request.query_params.get("export"):
        return csv_response("consist-operating-summary", ["fra_code", "name", "fra_class", "holding_company", "state"] + OPS_KEYS + ["crossings"], S.railroads(y, cls))
    # Class I extra: STB R-1 operating statistics (only Class I files R-1)
    r1 = None
    if cls in ("", "1") and r1assets.years():
        ry = y if y in r1assets.years() else r1assets.years()[-1]
        keys = [k for k in r1assets.MODULES["overview"]["table"] if k in r1assets.M]
        grid, gtot = r1assets.grid(keys, ry)
        r1 = dict(y=ry, tiles=r1assets.tiles("overview", ry), cols=keys, grid=grid, tot=gtot)
    return render(request, "rail/operations.html", user=u, S=S, R=r1assets, seg=seg, cls=cls, lab=lab, y=y, ys=ys, trend=list(reversed(trend)),
                  ch=ch, ch2=ch2, rows=rows, r1=r1, keys=OPS_KEYS)


@router.get("/crossing-funding")
def crossing_funding(request: Request, fy: int = 0, cp: int = 0, cf: int = 0, sort: str = ""):
    from . import xfund as X
    u, r = gate(request, "Crossing safety funding")
    if r:
        return r
    cp = cp if 50_000 <= cp <= 2_000_000 else X.COST_PASSIVE_TO_GATES
    cf = cf if 20_000 <= cf <= 1_000_000 else X.COST_FLASHERS_TO_GATES
    ys = X.years()
    fy = fy if fy in ys else (ys[-1] if ys else 0)
    rows = X.states(fy or None, cp, cf)
    if sort in X.DEF and sort != "state":
        rows.sort(key=lambda x: -(x.get(sort) or 0))
    if request.query_params.get("export"):
        cols = ["state", "public", "gated", "flashers", "passive", "ungated", "ungated_pct", "high_risk", "collisions", "ungated_collisions",
                "killed", "amount", "per_ungated", "per_collision", "upgrade_cost", "years_to_gate"]
        return csv_response("consist-crossing-safety-funding", cols, rows)
    return render(request, "rail/crossing_funding.html", user=u, X=X, rows=rows, tot=X.national(rows), ca=X.canada(),
                  ys=ys, fy=fy, cp=cp, cf=cf, sort=sort)
