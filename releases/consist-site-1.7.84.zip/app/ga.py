"""GA4 conversion events sent from the server (Measurement Protocol): sign_up, begin_checkout and purchase.

The gtag script only runs on public marketing pages, never in the app, so the events that matter happen where it can't see
them. The server sends them instead, tied to the visitor's GA client id (from the _ga cookie set on the public pages, kept per
member in ga_client so the purchase after Stripe still matches). Needs the GA4 measurement ID (Admin > Settings > General >
Analytics, G-...) and a Measurement Protocol API secret (GA4 Admin > Data streams > the web stream > Measurement Protocol API
secrets > Create) saved in the same place. Production only; admins are never counted. Fire-and-forget: a GA hiccup never
affects sign-up or billing. In GA4 mark sign_up and purchase as key events (Admin > Events)."""
import json
import logging
import random
import re
import threading
import time
import urllib.request
from urllib.parse import urlparse

from . import config, db

log = logging.getLogger("ga")

URL = "https://www.google-analytics.com/mp/collect"
GA_COOKIE = re.compile(r"^GA\d\.\d\.(\d+\.\d+)$")


def _init():
    db.x("CREATE TABLE IF NOT EXISTS ga_client (user_id INTEGER PRIMARY KEY, cid TEXT, created TEXT)")


def _measurement_id():
    mid = (db.settings().get("analytics_id") or "").strip().upper()
    return mid if mid.startswith("G-") else ""


def _production():
    host = urlparse(config.SITE_URL).hostname or ""
    return config.SITE_URL.startswith("https://") and "." in host and not host.startswith(("staging.", "localhost"))


def enabled():
    return bool(_measurement_id() and config.GA_API_SECRET and _production())


def remember(request, user_id):
    """At sign-up: keep the visitor's GA client id for this member (a made-up one when there is no _ga cookie)."""
    try:
        _init()
        m = GA_COOKIE.match(request.cookies.get("_ga", ""))
        cid = m.group(1) if m else f"{random.randint(10**8, 10**9 - 1)}.{int(time.time())}"
        db.x("INSERT OR REPLACE INTO ga_client (user_id, cid, created) VALUES (?, ?, ?)", (user_id, cid, db.now()))
    except Exception as e:
        log.warning("GA client id not saved: %s", e)


def _cid(user_id):
    _init()
    r = db.q("SELECT cid FROM ga_client WHERE user_id = ?", (user_id,), one=True)
    return r["cid"] if r else None


def event(user_id, name, **params):
    """Send one event for a member, in the background. Does nothing unless set up, on production, for a non-admin."""
    try:
        if not enabled():
            return
        u = db.q("SELECT role FROM user WHERE id = ?", (user_id,), one=True)
        if u and u["role"] == "admin":
            return
        cid = _cid(user_id)
        if not cid:
            return
    except Exception as e:
        log.warning("GA event %s skipped: %s", name, e)
        return
    body = json.dumps({"client_id": cid, "user_id": str(user_id), "non_personalized_ads": True,
                       "events": [{"name": name, "params": {k: v for k, v in params.items() if v is not None}}]}).encode()
    url = f"{URL}?measurement_id={_measurement_id()}&api_secret={config.GA_API_SECRET}"

    def send():
        try:
            urllib.request.urlopen(urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": "application/json"}), timeout=8).read()
        except Exception as e:
            log.warning("GA event %s not sent: %s", name, e)
    threading.Thread(target=send, daemon=True).start()
