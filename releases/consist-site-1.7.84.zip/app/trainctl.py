"""Signal and train control records, read into structured fields.

seed_subsystem rows with subsystem 'signal_onboard' hold free text: supplier ("Siemens;Bombardier",
"Hitachi Rail (Ansaldo STS)"), product ("Wabtec I-ETMS onboard (PTC)", "ACSES II onboard + pulse-code cab signal / ATC")
and a detail sentence that mixes contract, integrator, wayside and caveats. This module turns each row into
OEMs, systems, technology, status, contract, wayside and confidence, and merges rows that say the same thing
about different fleets of one operator. TCMS (vehicle_control) is not train control and is left out.
"""
import re

# ---------------- vocab ----------------

TECH = {  # key: label, css pill class, sort order
    "PTC": ("PTC", "brand", 1),
    "CBTC": ("CBTC", "accent", 2),
    "ATC": ("ATC / cab signal", "", 3),
    "ETCS": ("ETCS", "warn", 4),
    "NONE": ("No onboard train control", "muted", 6),
    "UNK": ("Not identified", "muted", 7),
}

# (pattern, system name, technology, typical OEM); first match wins per component
SYSTEMS = [
    (r"i-?etms", "I-ETMS", "PTC", "Wabtec"),
    (r"acses ii", "ACSES II", "PTC", None),
    (r"\bases\b", "ASES (ACSES-compatible)", "PTC", None),
    (r"\bacses\b", "ACSES", "PTC", None),
    (r"\bitcs\b", "ITCS", "PTC", None),
    (r"e-atc", "E-ATC", "PTC", None),
    (r"trainguard", "Trainguard MT", "CBTC", "Siemens"),
    (r"seltrac", "SelTrac", "CBTC", "Hitachi Rail"),
    (r"cityflo", "CITYFLO 650", "CBTC", "Alstom"),
    (r"urbalis", "Urbalis 400", "CBTC", "Alstom"),
    (r"safenet", "SafeNet", "CBTC", "Argenia"),
    (r"nova pro", "NOVA Pro", "CBTC", "Stadler"),
    (r"etcs", "ETCS Level 2", "ETCS", None),
    (r"microcab", "MicroCab", "ATC", "Hitachi Rail"),
    (r"driverless train control|goa4 train control", "Automated train control", "CBTC", None),
    (r"\bcbtc\b", "CBTC", "CBTC", None),
    (r"transmission-based atc", "Transmission-based ATC", "ATC", None),
    (r"\batcs\b", "ATCS", "ATC", None),
    (r"pulse-code cab signal|cab signal|\batc\b|train control", "Cab signal / ATC", "ATC", None),
    (r"\bptc\b", "PTC (system not named)", "PTC", None),
]

CURRENT_OEMS = ("Hitachi Rail", "Alstom", "Wabtec", "Siemens", "Stadler", "Argenia", "Thales", "Bombardier", "PHW")

CONF = {"A": ("Confirmed", "ok", "Agency, supplier or government source"),
        "B": ("Reliable", "ok", "Trade press or contract report"),
        "C": ("Secondary", "", "Secondary source such as an encyclopedia; not checked against the agency"),
        "D": ("Inferred", "warn", "Inferred from the corridor, host railroad or sister fleets; needs confirming"),
        "E": ("Unverified", "warn", "Unverified")}

CLASS_LABEL = {"locomotive": "locomotives", "cab_car": "cab cars", "emu": "EMUs", "dmu": "DMUs", "metro_car": "metro cars",
               "coach": "coaches", "lrv": "light rail vehicles"}


# ---------------- parsing ----------------

def _clean(s):
    return re.sub(r"\s+", " ", (s or "").strip()).strip(" ;,.")


def oems(supplier):
    """'Hitachi Rail (Ansaldo STS)' -> [{'name': 'Hitachi Rail', 'formerly': 'Ansaldo STS'}];
    'Thales (Hitachi Rail)' -> Hitachi Rail, formerly Thales; 'Siemens;Bombardier' -> two."""
    out = []
    for part in re.split(r"\s*;\s*", supplier or ""):
        part = _clean(part)
        if not part:
            continue
        m = re.match(r"^(.*?)\s*\((.*?)\)$", part)
        name, other = (m.group(1), m.group(2)) if m else (part, None)
        if other:
            # the bracket is the current owner when it names one of today's OEMs and the outside does not lead with it
            cur = next((o for o in ("Hitachi Rail", "Alstom", "Wabtec", "Siemens") if other.startswith(o)), None)
            if cur and not name.startswith(cur):
                name, other = cur, name
        if not any(o["name"] == name for o in out):
            out.append({"name": name, "formerly": other})
    return out


def systems(product):
    """Split a product on '+' and name each component. Returns [{'name', 'tech', 'oem_hint', 'raw'}]."""
    p = product or ""
    low = p.lower()
    if not low.strip() or re.match(r"^\s*none\b", low):
        return []
    out = []
    for comp in re.split(r"\s\+\s", p):
        cl = comp.lower()
        for rx, name, tech, hint in SYSTEMS:
            if re.search(rx, cl):
                if not any(s["name"] == name for s in out):
                    out.append({"name": name, "tech": tech, "oem_hint": hint, "raw": _clean(comp)})
                break
    if not out:
        out.append({"name": _clean(p), "tech": "UNK", "oem_hint": None, "raw": _clean(p)})
    return out


def status(product, detail):
    p, d = (product or "").lower(), (detail or "").lower()
    if re.match(r"^\s*none\b", p):
        return ("planned", "None today, planned") if "planned" in p or "planned" in d or "to deliver" in d else ("none", "None")
    if "planned" in p:
        return "planned", "Planned"
    if "being installed" in p or "under contract" in p:
        return "upgrading", "In service, upgrade under way"
    if "being replaced" in d or "replacement solicitation" in d or "being retired" in d:
        return "replacing", "In service, being replaced"
    return "service", "In service"


_MON = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?"


def contract(detail):
    """Year and value of the contract named in the detail, if any."""
    d = detail or ""
    m = re.search(rf"[Cc]ontract(?: awarded| authorized| negotiated)?\s*(?:{_MON}\s+)?((?:19|20)\d\d)", d) \
        or re.search(rf"[Cc]ontract (?:{_MON} )?(?:authorized )?[^.;]*?((?:19|20)\d\d)", d) \
        or re.search(r"awarded to [^.;]*?((?:19|20)\d\d)", d)
    v = re.search(r"\$\s?([\d.,]+)\s?(M|m|B|bn|million|billion)\b", d)
    wi = d.lower().find("wayside")
    if v and wi >= 0 and v.start() > wi:
        v = None  # a value after the wayside note is the wayside contract, not the onboard one
    if not m and v:
        m = re.search(r"\(((?:19|20)\d\d)\)", d)
    year = int(m.group(1)) if m else None
    value = None
    if v:
        n = float(v.group(1).replace(",", ""))
        value = n * (1e9 if v.group(2).lower().startswith("b") else 1e6)
    return year, value


def integrator(detail):
    d = detail or ""
    m = re.search(r"([A-Z][A-Za-z&.\- ]{2,40}?) (?:as (?:PTC )?system )?integrator", d)
    if m:
        name = re.sub(r"^(?:about \$[\d.]+M, |\$[\d.]+M, )", "", m.group(1)).strip()
        name = re.split(r",\s*", name)[-1]
        return name
    return None


def wayside(detail):
    d = detail or ""
    m = re.search(r"Wayside:\s*(.+?)(?:$|(?<=\.)\s)", d)
    if m:
        return _clean(m.group(1))
    m = re.search(r"([^.;]*\bwayside\b[^.;]*)", d, re.I)
    if m and "wayside upgrade" not in m.group(1).lower():
        return _clean(m.group(1))
    return None


def notes(detail):
    """The detail with the parts shown elsewhere taken out."""
    d = detail or ""
    d = re.sub(r"Wayside:.*$", "", d)
    d = re.sub(r"^Inferred:\s*", "", d)
    d = re.sub(r"Confirm with [^.;]+[.;]?", "", d)
    return _clean(d) or None


def scope(model):
    m = (model or "").strip()
    if m in ("", "*"):
        return "All fleets"
    if m.startswith("*:"):
        cls = [CLASS_LABEL.get(c.strip(), c.strip().replace("_", " ")) for c in m[2:].split(",") if c.strip()]
        txt = ", ".join(cls)
        return (txt[:1].upper() + txt[1:]) if txt else "All fleets"
    return m


def parse(r):
    """One seed_subsystem row (dict) -> structured record."""
    product, detail, supplier = r.get("product") or "", r.get("detail") or "", r.get("supplier") or ""
    sy = systems(product)
    planned = []
    if re.match(r"^\s*none\b", product.lower()) and "planned" in product.lower():
        planned = [x["name"] for x in systems(re.sub(r"^\s*none[^;]*;\s*", "", product, flags=re.I))]
    oe = oems(supplier)
    st_key, st_label = status(product, detail)
    if st_key in ("none",) or (st_key == "planned" and re.match(r"^\s*none\b", product.lower())):
        tech = ["NONE"] + [s["tech"] for s in sy if s["tech"] != "NONE"]
    else:
        tech = list(dict.fromkeys(s["tech"] for s in sy)) or ["UNK"]
    if not oe:  # fill from a system that only one OEM makes, and say so
        hints = {s["oem_hint"] for s in sy if s["oem_hint"]}
        if len(hints) == 1 and st_key not in ("none", "planned"):
            oe = [{"name": hints.pop(), "formerly": None, "implied": True}]
    year, value = contract(detail)
    conf = (r.get("confidence") or "").strip().upper()[:1] or "E"
    inferred = conf == "D" or detail.strip().lower().startswith("inferred")
    cw = re.search(r"Confirm with ([^.;]+)", detail)
    goa4 = bool(re.search(r"goa4|driverless", (product + " " + detail).lower())) and "not used" not in detail.lower()
    ato = goa4 or bool(re.search(r"\bato\b", (product + " " + detail).lower()))
    return {
        "operator_id": r.get("operator_id"), "model": r.get("model"), "scope": scope(r.get("model")),
        "systems": sy, "tech": tech, "oems": oe,
        "oem_label": " and ".join(o["name"] for o in oe) if oe else ("No onboard equipment" if "NONE" in tech else "Not confirmed"),
        "planned": planned,
        "status": st_key, "status_label": st_label,
        "contract_year": year, "contract_value": value, "integrator": integrator(detail), "wayside": wayside(detail),
        "notes": notes(detail), "automation": "Driverless (GoA4)" if goa4 else ("ATO" if ato else None),
        "confidence": conf, "conf_label": CONF.get(conf, CONF["E"])[0], "conf_pill": CONF.get(conf, CONF["E"])[1],
        "conf_help": CONF.get(conf, CONF["E"])[2], "inferred": inferred, "confirm_with": _clean(cw.group(1)) if cw else None,
        "sources": [r["source_url"]] if r.get("source_url") else [], "product": _clean(product), "detail": detail,
    }


# ---------------- merging ----------------

def _key(p):
    return (tuple(s["name"] for s in p["systems"]) or (p["status"],), tuple(o["name"] for o in p["oems"]), p["status"])


def merge(parsed):
    """Rows saying the same thing (same systems, OEMs and status) for different fleets become one, with every scope,
    the best confidence, every source and the first non-blank contract, wayside and notes."""
    out, idx = [], {}
    for p in parsed:
        k = (p["operator_id"],) + _key(p)
        if k not in idx:
            q = dict(p, scopes=[p["scope"]], sources=list(p["sources"]), notes_all=[p["notes"]] if p["notes"] else [])
            idx[k] = q
            out.append(q)
            continue
        q = idx[k]
        if p["scope"] not in q["scopes"]:
            q["scopes"].append(p["scope"])
        for s in p["sources"]:
            if s not in q["sources"]:
                q["sources"].append(s)
        if p["notes"] and p["notes"] not in q["notes_all"]:
            q["notes_all"].append(p["notes"])
        if p["confidence"] < q["confidence"]:
            for f in ("confidence", "conf_label", "conf_pill", "conf_help", "inferred", "confirm_with"):
                q[f] = p[f]
        for f in ("contract_year", "contract_value", "integrator", "wayside", "automation"):
            if not q.get(f) and p.get(f):
                q[f] = p[f]
    for q in out:
        if "All fleets" in q["scopes"]:
            q["scopes"] = ["All fleets"]
        q["scope"] = ", ".join(q["scopes"])
    out.sort(key=lambda q: (min(TECH.get(t, TECH["UNK"])[2] for t in q["tech"]), q["scope"]))
    return out


def summary(recs):
    """Operator-level roll-up: technologies, OEMs, best and worst confidence, status flags."""
    tech = []
    for q in recs:
        for t in q["tech"]:
            if t not in tech:
                tech.append(t)
    if len(tech) > 1 and "UNK" in tech:
        tech.remove("UNK")
    tech.sort(key=lambda t: TECH.get(t, TECH["UNK"])[2])
    names = []
    for q in recs:
        for s in q["systems"]:
            if s["name"] not in names:
                names.append(s["name"])
    oem = []
    for q in recs:
        for o in q["oems"]:
            if o["name"] not in oem:
                oem.append(o["name"])
    confs = sorted(q["confidence"] for q in recs) or ["E"]
    return {"tech": tech, "systems": names, "oems": oem, "best": confs[0], "worst": confs[-1],
            "all_inferred": all(q["inferred"] for q in recs) if recs else False,
            "any_inferred": any(q["inferred"] for q in recs),
            "flags": sorted({q["status"] for q in recs if q["status"] in ("planned", "upgrading", "replacing")}),
            "automation": next((q["automation"] for q in recs if q["automation"] == "Driverless (GoA4)"), None) or
                          next((q["automation"] for q in recs if q["automation"]), None)}
