"""Statistics Canada rail tables (seed/statcan_rail.csv.gz, tools/statcan/build.py). Open Government Licence - Canada."""
import csv, gzip, os
SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "statcan_rail.csv.gz")
CREDIT = ("Statistics Canada, tables 23-10-0216, 23-10-0062, 23-10-0045, 23-10-0055, 23-10-0057 and 23-10-0058. "
          "Contains information licensed under the Open Government Licence - Canada.")
MAIN = "Total mainline companies"  # company detail (CN, CP, VIA) stops in 2009 (2015 for equipment), so the page shows the mainline industry by year
METRICS = [  # key, label, table, item, unit, definition
    ("rtk", "Revenue tonne-km (billions)", "summary", "Revenue freight, tonne-kilometres", 1e-9, "Revenue freight tonnes times kilometres carried, all lines in Canada."),
    ("haul", "Average haul (km)", "summary", "Revenue freight, average haul on each railway", 1, "Average distance a revenue tonne travels on the railway."),
    ("cpt", "Cars per freight train", "summary", "Transportation services, averages, cars per freight train", 1, "Average number of cars in a freight train."),
    ("speed", "Freight train speed (km/h)", "summary", "Transportation services, averages, freight train speed", 1, "Average freight train speed between terminals."),
    ("gtk", "Gross tonne-km, freight (billions)", "opstats", "Gross tonne-kilometres, freight train cars, contents and cabooses", 1e-9, "Weight of cars and contents times distance: the physical workload of the network."),
    ("loco", "Locomotives", "equipment", "Total locomotives", 1, "Locomotives in service at year end."),
    ("cars", "Freight cars (owned/leased)", "equipment", "Total freight cars", 1, "Railway-controlled freight cars in service at year end (private cars are not included)."),
    ("rev", "Operating revenues ($M CAD)", "income", "Total rail operating revenues", 1e-6, "Total rail operating revenues, Canadian dollars."),
    ("exp", "Operating expenses ($M CAD)", "income", "Total rail operating expenses", 1e-6, "Total rail operating expenses, Canadian dollars."),
]
_c = {}


def _load():
    if "d" not in _c:
        d = {}
        if os.path.exists(SEED):
            with gzip.open(SEED, "rt", newline="") as f:
                for r in csv.DictReader(f):
                    try:
                        d[(r["table"], r["entity"], r["item"], r["sub"], r["period"])] = float(r["value"])
                    except ValueError:
                        pass
        _c["d"] = d
    return _c["d"]


def available():
    return bool(_load())


def get(table, entity, item, period, sub=""):
    return _load().get((table, entity, item, sub, period))


def years(table="summary"):
    return sorted({k[4] for k in _load() if k[0] == table})


def industry_table(n=10):
    out = []
    for y in years()[-n:][::-1]:
        row = dict(label=y)
        for k, _, t, item, sc, _ in METRICS:
            v = get(t, "Total companies" if t == "summary" else MAIN, item, y)
            row[k] = v * sc if v is not None else None
        row["or"] = 100 * row["exp"] / row["rev"] if row.get("rev") and row.get("exp") else None
        out.append(row)
    return out


def trend(entity, key):
    m = next(x for x in METRICS if x[0] == key)
    return [(int(y), get(m[2], entity, m[3], y) * m[4]) for y in years(m[2]) if get(m[2], entity, m[3], y) is not None]


def monthly(item="Total traffic carried", unit="Tonnes"):
    return sorted((p, v) for (t, e, i, s, p), v in _load().items() if t == "carloads" and i == item and s == unit)


def commodities(unit="Tonnes"):
    """Last 12 months vs previous 12 by commodity."""
    rows = {}
    for (t, e, i, s, p), v in _load().items():
        if t == "carloads" and s == unit and not i.startswith("Total"):
            rows.setdefault(i, []).append((p, v))
    if not rows:
        return [], None
    last = max(p for v in rows.values() for p, _ in v)
    ly, lm = map(int, last.split("-"))
    cut = "%d-%02d" % (ly - 1, lm)
    cut2 = "%d-%02d" % (ly - 2, lm)
    out = []
    for i, s in rows.items():
        a = sum(v for p, v in s if cut < p <= last)
        b = sum(v for p, v in s if cut2 < p <= cut)
        out.append(dict(name=i, t12=a, chg=100 * (a / b - 1) if b else None))
    return sorted(out, key=lambda r: -r["t12"]), last


def od(y):
    regs = ["Atlantic Region", "Quebec", "Ontario", "Manitoba", "Saskatchewan", "Alberta", "British Columbia", "United States", "Mexico"]
    tot = "Total tonnage of all rail commodities"
    m = [[get("od", o, tot, y, d) for d in regs] for o in regs]
    return regs, m
