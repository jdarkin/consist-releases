"""Freight analytics portal: Class I locomotive fleets from STB R-1 plus 10-K operating KPIs. See freight.py for the metrics.
Every page here drills down: tiles and cells link to /app/freight/metric/<key>?rr=&y=, which shows the formula, inputs and source."""
from fastapi import APIRouter, Depends, HTTPException, Request

from . import auth, freight, lens
from .main import render
from .routes_app import csv_response
from .routes_intel import locked

router = APIRouter(prefix="/app/freight")
U = Depends(auth.require_user)
RATE = {"new": "new_rate", "rebuilt": "rebuild_rate", "retired": "retire_rate"}
EXPORT_COLS = ["operator_id", "railroad", "year", "metric", "label", "value", "unit", "currency", "source", "source_url"]


def _year(request, c):
    try:
        y = int(request.query_params.get("y") or 0)
    except ValueError:
        y = 0
    return y if y in c.years else c.latest


def _gate(request, u, title):
    if lens.in_rail():  # served inside /rail, which checks rail access itself (routes_rail.py)
        return None
    if not lens.current().freight:  # parked: admins only until FREIGHT_PUBLIC is set
        raise HTTPException(404)
    if not u.can("fleet_detail"):
        return locked(request, u, "fleet_detail", title)
    return None


def _export(u):
    return u.can("export") or lens.in_rail()


@router.get("")
def home(request: Request, u=U):
    if (r := _gate(request, u, "Freight locomotive analytics")):
        return r
    c = freight.Cube()
    y = _year(request, c)
    m = request.query_params.get("m") or "cost_per_unit_mile"
    if m not in freight.M:
        m = "cost_per_unit_mile"
    if request.query_params.get("export") and _export(u):
        return csv_response("consist-freight-analytics", EXPORT_COLS, freight.export_rows(c))
    rows, med = freight.scoreboard(c, y) if c.latest else ([], [])
    groups = [(g, [k for k, d in freight.M.items() if d["group"] == g and c.has(k)]) for g in freight.GROUPS]
    return render(request, "app/freight_home.html", user=u, c=c, y=y, m=m, F=freight, rows=rows, med=med,
                  tiles=freight.tiles(c, y) if c.latest else [], groups=groups, chart=freight.line_linked(c, m) if c.ids else "",
                  reb=[r for r in freight.rebuild_economics(c) if r["y"] == y])


@router.get("/rr/{op}")
def railroad(request: Request, op: str, u=U):
    if op not in freight.RAILROADS:
        raise HTTPException(404)
    if (r := _gate(request, u, "Freight locomotive analytics")):
        return r
    c = freight.Cube()
    if op not in c.ids:
        c.ids = c.ids + [op]
    y = _year(request, c)
    if request.query_params.get("export") and _export(u):
        return csv_response(f"consist-freight-{op.lower()}", EXPORT_COLS, [x for x in freight.export_rows(c) if x["operator_id"] == op])
    return render(request, "app/freight_rr.html", user=u, c=c, y=y, op=op, F=freight, rr=freight.RAILROADS[op],
                  tiles=freight.tiles(c, y, op), groups=freight.profile(c, op, y), mix=c.build_mix(op, y),
                  renew=freight.renewal(c, op), renew_href=lambda yy, k: freight.link(RATE.get(k, "renewal_cycle"), op, yy), reb=freight.rebuild_economics(c, ops=[op]),
                  cost_chart=freight.line_linked(c, "cost_per_unit_mile", sel_op=op), use_chart=freight.line_linked(c, "miles_per_unit", sel_op=op))


@router.get("/metric/{key}")
def metric(request: Request, key: str, u=U):
    if key not in freight.M:
        raise HTTPException(404)
    if (r := _gate(request, u, "Freight locomotive analytics")):
        return r
    c = freight.Cube()
    op = request.query_params.get("rr")
    op = op if op in freight.RAILROADS else None
    if op and op not in c.ids:
        c.ids = c.ids + [op]
    y = _year(request, c)
    if op and c.v(key, op, y) is None:
        y = c.last_year(key, op) or y
    if request.query_params.get("export") and _export(u):
        return csv_response(f"consist-freight-{key}", EXPORT_COLS, freight.export_rows(c, [key]))
    ys, grid = freight.metric_table(c, key)
    m = freight.M[key]
    sel = None
    if op:
        rk, n = c.rank(key, op, y)
        sel = dict(op=op, label=freight.RAILROADS[op][0], name=freight.RAILROADS[op][1], y=y, show=c.show(key, op, y), rank=rk, n=n,
                   med=freight.fmt(key, c.peer_median(key, y), c.currency(key, op, y)), inputs=c.inputs(key, op, y),
                   entities=(c.r1.get((op, y)) or {}).get("entities", []), sources=(c.r1.get((op, y)) or {}).get("sources", []),
                   prev=c.show(key, op, y - 1), chg=c.change(key, op, y - 1, y), cagr=c.cagr(key, op))
    related = [k for k, d in freight.M.items() if d["group"] == m["group"] and k != key and c.has(k)]
    return render(request, "app/freight_metric.html", user=u, c=c, y=y, op=op, key=key, m=m, F=freight, ys=ys, grid=grid, sel=sel,
                  chart=freight.line_linked(c, key, sel_op=op, sel_y=y if op else None), related=related,
                  med=[(yy, freight.fmt(key, c.peer_median(key, yy))) for yy in ys])


@router.get("/renewal")
def renewal_page(request: Request, u=U):
    if (r := _gate(request, u, "Freight locomotive analytics")):
        return r
    c = freight.Cube()
    y = _year(request, c)
    if y not in c.r1_years and c.r1_years:
        y = c.r1_years[-1]
    tot = freight.class1_totals(c)
    if request.query_params.get("export") and _export(u):
        return csv_response("consist-freight-retirements-overhauls", EXPORT_COLS,
                            freight.export_rows(c, ["units", "new_units", "rebuilt_units", "retired_units", "net_change", "retire_rate", "rebuild_rate", "rebuild_spend", "rebuild_cost_per_unit"]))
    grids = {k: freight.metric_table(c, k) for k in ("retired_units", "rebuilt_units", "retire_rate", "rebuild_rate")}
    return render(request, "app/freight_renewal.html", user=u, c=c, y=y, F=freight, tot=tot, cur=next((t for t in tot if t["y"] == y), None),
                  grids=grids, lines=freight.rebuild_lines(c, y), chart_ret=freight.line_linked(c, "retired_units"),
                  chart_reb=freight.line_linked(c, "rebuilt_units"))


@router.get("/about")
def about(request: Request, u=U):
    if (r := _gate(request, u, "Freight locomotive analytics")):
        return r
    c = freight.Cube()
    return render(request, "app/freight_about.html", user=u, c=c, F=freight)


@router.get("/rebuild")
def rebuild(request: Request, u=U):
    if (r := _gate(request, u, "Freight locomotive analytics")):
        return r
    c = freight.Cube()

    def num(name, d):
        try:
            return max(0.0, min(100.0, float(request.query_params.get(name) or d)))
        except ValueError:
            return d
    rs, fs = num("rs", 30.0), num("fs", 10.0)
    op = request.query_params.get("rr")
    rows = freight.rebuild_economics(c, rs, fs, ops=[op] if op in freight.RAILROADS else None)
    if request.query_params.get("export") and _export(u):
        cols = ["label", "y", "new_units", "new", "reb_units", "reb", "ratio", "rep_yr", "fuel_yr", "saving", "payback"]
        return csv_response("consist-freight-rebuild-vs-new", cols, rows)
    return render(request, "app/freight_rebuild.html", user=u, c=c, F=freight, rows=rows, rs=rs, fs=fs, op=op if op in freight.RAILROADS else None,
                  chart_new=freight.line_linked(c, "new_cost_per_unit"), chart_reb=freight.line_linked(c, "rebuild_cost_per_unit"))
