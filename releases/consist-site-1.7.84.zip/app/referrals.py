"""Referral program (Justin, 2026-11-08). Every paying member has a link /r/<code>. A visitor who signs up through it is
recorded as referred (user.referred_by) and gets REFEREE_PERCENT off their first paid month (Stripe coupon, once). When the
referred account has paid and is still paying HOLD_DAYS later, the referrer earns one free month of their own plan as a Stripe
customer-balance credit (billing.credit_balance), at most CAP_PER_YEAR a year. Guards: referrer must be on a self-serve paid
plan (not free, contact-only or an ambassador/comped grant), no self-referral, not the same Stripe customer, team seats don't
count, one reward per referred account. Admin > Referrals lists every referral with Approve now / Void / Credit now.
Settings: referral_on (1), referral_percent (50), referral_hold_days (30), referral_cap (12)."""
import datetime
import logging
import secrets

from fastapi import APIRouter, Depends, Form, Request

from . import auth, db

log = logging.getLogger("consist.referrals")
SCHEMA = """CREATE TABLE IF NOT EXISTS referral (id INTEGER PRIMARY KEY, referrer_id INTEGER NOT NULL, referee_id INTEGER NOT NULL UNIQUE,
  status TEXT DEFAULT 'signed_up', created TEXT, first_paid TEXT, eligible_at TEXT, credited TEXT, credit_cents INTEGER, credit_txn TEXT,
  note TEXT);
CREATE TABLE IF NOT EXISTS referral_invite (id INTEGER PRIMARY KEY, referrer_id INTEGER, email TEXT, sent TEXT);"""
SELF_SERVE_STATUSES = ("active", "past_due", "trialing")


def _s(key, default):
    try:
        return int(db.settings().get(key) or default)
    except (TypeError, ValueError):
        return default


def on():
    return db.settings().get("referral_on", "1") == "1"


def percent():
    return max(1, min(100, _s("referral_percent", 50)))


def ensure():
    with db._lock:
        c = db.connect()
        try:
            c.executescript(SCHEMA)
            cols = [r[1] for r in c.execute("PRAGMA table_info(user)")]
            if "ref_code" not in cols:
                c.execute("ALTER TABLE user ADD COLUMN ref_code TEXT")
            if "referred_by" not in cols:
                c.execute("ALTER TABLE user ADD COLUMN referred_by INTEGER")
            c.commit()
        finally:
            c.close()


def can_refer(u):
    """Self-serve paying members only: a paid, non-contact plan on a real Stripe subscription (not comped, ambassador or trial)."""
    if not u or u.get("team_owner_id") or (u.get("plan_id") or "free") == "free":
        return False
    p = db.get_plan(u["plan_id"])
    return not p.get("contact_only") and u.get("sub_status") in ("active", "past_due")


def code_for(u):
    if u.get("ref_code"):
        return u["ref_code"]
    code = secrets.token_urlsafe(6).replace("-", "").replace("_", "")[:8].lower()
    db.x("UPDATE user SET ref_code = ? WHERE id = ?", (code, u["id"]))
    return code


def info(u):
    """What the Account page card shows."""
    from . import config
    if not on() or not u:
        return None
    rows = db.q("SELECT r.*, x.email FROM referral r JOIN user x ON x.id = r.referee_id WHERE r.referrer_id = ? ORDER BY r.id DESC", (u["id"],))
    ok = can_refer(u)
    return {"ok": ok, "link": f"{config.SITE_URL}/r/{code_for(u)}" if ok else "", "percent": percent(), "hold": _s("referral_hold_days", 30),
            "cap": _s("referral_cap", 12), "rows": [dict(r) for r in rows], "earned": sum(1 for r in rows if r["status"] == "credited")}


def capture(request: Request, uid):
    """At sign-up: link the new account to the referrer whose code is in the session."""
    code = (request.session.pop("ref", None) or "").strip().lower()
    if not code or not on():
        return
    r = db.q("SELECT id FROM user WHERE ref_code = ?", (code,), one=True)
    if not r or r["id"] == uid:
        return
    db.x("UPDATE user SET referred_by = ? WHERE id = ? AND referred_by IS NULL", (r["id"], uid))
    db.x("INSERT OR IGNORE INTO referral (referrer_id, referee_id, status, created) VALUES (?,?, 'signed_up', ?)", (r["id"], uid, db.now()))


def coupon_for(user):
    """Stripe discount for a referred member's first checkout, or None."""
    if not on() or not user.get("referred_by") or user.get("stripe_subscription_id"):
        return None
    from . import billing
    pct = percent()
    cid = f"consist-referral-{pct}"
    c = billing.client()
    try:
        c.v1.coupons.retrieve(cid)
    except Exception:
        c.v1.coupons.create(params={"id": cid, "percent_off": pct, "duration": "once", "name": f"Referral: {pct}% off first month"})
    return cid


def _after(days):
    return (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=days)).replace(microsecond=0).isoformat()


def _credit(ref, referrer, by="auto"):
    from . import billing
    cap = _s("referral_cap", 12)
    year_ago = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=365)).isoformat()
    n = db.q("SELECT count(*) n FROM referral WHERE referrer_id = ? AND status = 'credited' AND credited >= ?", (referrer["id"], year_ago), one=True)["n"]
    if n >= cap:
        db.x("UPDATE referral SET status = 'capped', note = ? WHERE id = ?", (f"referrer reached {cap} free months this year", ref["id"]))
        return "capped"
    cents = billing.credit_month_cents(referrer)
    txn = billing.credit_balance(referrer, cents, f"Consist referral reward: one free month (referral #{ref['id']})")
    db.x("UPDATE referral SET status = 'credited', credited = ?, credit_cents = ?, credit_txn = ?, note = coalesce(note, ?) WHERE id = ?",
         (db.now(), cents, txn, by, ref["id"]))
    try:
        from . import mailer
        mailer.send(referrer["email"], "You earned a free month of Consist",
                    f"Thanks for recommending Consist. A colleague you referred is now a paying member, so we've added a credit of "
                    f"${cents / 100:,.2f} (one month of your plan) to your account. It comes off your next invoice automatically.", optional=True)
    except Exception:
        pass
    return "credited"


def tick():
    """Daily: move referrals along. signed_up -> paid (first real payment seen) -> credited after the hold, or void."""
    if not on():
        return
    hold = _s("referral_hold_days", 30)
    now = db.now()
    for ref in db.q("SELECT * FROM referral WHERE status IN ('signed_up', 'paid')"):
        ref = dict(ref)
        e = db.q("SELECT * FROM user WHERE id = ?", (ref["referee_id"],), one=True)
        r = db.q("SELECT * FROM user WHERE id = ?", (ref["referrer_id"],), one=True)
        if not e or not r:
            db.x("UPDATE referral SET status = 'void', note = 'account deleted' WHERE id = ?", (ref["id"],))
            continue
        e, r = dict(e), dict(r)
        paying = (e.get("plan_id") or "free") != "free" and e.get("sub_status") in ("active", "past_due") and not e.get("team_owner_id")
        if e.get("stripe_customer_id") and e.get("stripe_customer_id") == r.get("stripe_customer_id"):
            db.x("UPDATE referral SET status = 'void', note = 'same Stripe customer as referrer' WHERE id = ?", (ref["id"],))
            continue
        if ref["status"] == "signed_up":
            if paying:
                db.x("UPDATE referral SET status = 'paid', first_paid = ?, eligible_at = ? WHERE id = ?", (now, _after(hold), ref["id"]))
            continue
        if ref["eligible_at"] and ref["eligible_at"] <= now:
            if not paying:
                db.x("UPDATE referral SET status = 'void', note = 'referred member stopped paying before the hold ended' WHERE id = ?", (ref["id"],))
            elif not can_refer(r):
                db.x("UPDATE referral SET status = 'void', note = 'referrer is not on a self-serve paid plan' WHERE id = ?", (ref["id"],))
            else:
                try:
                    _credit(ref, r)
                except Exception:
                    log.exception("referral credit %s", ref["id"])


def start():
    import threading
    import time

    def loop():
        time.sleep(300)
        while True:
            try:
                tick()
            except Exception:
                log.exception("referral tick")
            time.sleep(6 * 3600)
    threading.Thread(target=loop, daemon=True).start()


# ---------------- routes ----------------

public = APIRouter()
member = APIRouter(prefix="/app")
admin = APIRouter(prefix="/admin")


@public.get("/r/{code}")
def landing(request: Request, code: str):
    from .main import redirect
    if on() and db.q("SELECT 1 FROM user WHERE ref_code = ?", (code.lower()[:20],), one=True):
        request.session["ref"] = code.lower()[:20]
        return redirect(f"/signup?ref={percent()}")
    return redirect("/pricing")


@member.post("/refer/invite")
def invite(request: Request, csrf: str = Form(""), email: str = Form(""), note: str = Form(""), u=Depends(auth.require_user)):
    from . import config, mailer
    from .main import flash, redirect
    auth.check_csrf(request, csrf)
    email = email.strip().lower()
    if not can_refer(u) or "@" not in email or len(email) > 200:
        flash(request, "Enter a colleague's email address.", "bad")
        return redirect("/app/account#refer")
    if auth.spend(request, "refer_invite", 20) or db.q("SELECT count(*) n FROM referral_invite WHERE referrer_id = ? AND sent >= ?",
                                                        (u["id"], db.now()[:10]), one=True)["n"] >= 20:
        flash(request, "That's the most invites for today. Try again tomorrow.", "bad")
        return redirect("/app/account#refer")
    who = u.get("name") or u["email"]
    body = (f"{who} uses Consist for rail fleet, bid and market intelligence across the US and Canada, and thought you'd find it useful.\n\n"
            + (f"\"{note.strip()[:500]}\"\n\n" if note.strip() else "")
            + f"Sign up with this link and get {percent()}% off your first paid month:\n{config.SITE_URL}/r/{code_for(u)}\n")
    try:
        mailer.send(email, f"{who} invited you to Consist", body, reply_to=u["email"])
        db.x("INSERT INTO referral_invite (referrer_id, email, sent) VALUES (?,?,?)", (u["id"], email, db.now()))
        flash(request, f"Invite sent to {email}.")
    except Exception:
        flash(request, "The invite couldn't be sent. Copy your link instead.", "bad")
    return redirect("/app/account#refer")


@admin.get("/referrals")
def admin_list(request: Request, u=Depends(auth.require_admin)):
    from .main import render
    rows = db.q("SELECT r.*, a.email referrer, b.email referee FROM referral r LEFT JOIN user a ON a.id = r.referrer_id "
                "LEFT JOIN user b ON b.id = r.referee_id ORDER BY r.id DESC LIMIT 500")
    return render(request, "admin/referrals.html", user=u, rows=rows, on=on(), pct=percent(), hold=_s("referral_hold_days", 30), cap=_s("referral_cap", 12))


@admin.post("/referrals/{rid}")
def admin_act(request: Request, rid: int, csrf: str = Form(""), action: str = Form(""), u=Depends(auth.require_admin)):
    from .main import flash, redirect
    auth.check_csrf(request, csrf)
    ref = db.q("SELECT * FROM referral WHERE id = ?", (rid,), one=True)
    if not ref:
        return redirect("/admin/referrals")
    ref = dict(ref)
    if action == "void" and ref["status"] != "credited":
        db.x("UPDATE referral SET status = 'void', note = ? WHERE id = ?", (f"voided by {u.email}", rid))
        flash(request, f"Referral #{rid} voided.")
    elif action == "credit" and ref["status"] in ("signed_up", "paid", "capped", "void"):
        r = db.q("SELECT * FROM user WHERE id = ?", (ref["referrer_id"],), one=True)
        try:
            out = _credit(ref, dict(r), by=f"credited by {u.email}") if r else "no referrer"
            flash(request, f"Referral #{rid}: {out}.")
        except Exception as e:
            flash(request, f"Stripe credit failed: {type(e).__name__}: {e}", "bad")
    elif action == "run":
        tick()
        flash(request, "Referrals processed.")
    db.audit("admin_referral", f"{rid}:{action}", None, u.email)
    return redirect("/admin/referrals")
