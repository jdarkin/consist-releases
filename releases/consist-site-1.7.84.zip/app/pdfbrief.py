"""Report exports of AI briefs and analyst answers.
1.7.15: PDF (Justin 2026-11-09). 1.7.20: redesigned branded PDF (Consist header band and logo, verdict badges, key-figure tiles,
styled tables and caveats) plus RTF (opens in Word, Pages, Google Docs) and plain-text exports (Justin 2026-11-11).
PDF uses fpdf2 and the DejaVu Sans fonts bundled in seed/fonts, so any character the AI writes (dashes, quotes, accents) prints.
1.7.21: report text in a bundled OFL font (1.7.22: IBM Plex Sans, Justin's pick) with HarfBuzz kerning when uharfbuzz is installed, DejaVu as the
fallback for rare characters, looser line spacing, and key-figure values that shrink (then wrap) to stay inside their tile (Justin 2026-11-11)."""
import datetime
import os
import re

import markdown as _md
from fpdf import FPDF
from fpdf.fonts import FontFace, TextStyle

FONTS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "fonts")
# Consist palette (static/css/app.css)
BRAND, BRAND_INK, BRAND_SOFT = (11, 107, 93), (8, 74, 64), (225, 240, 236)
ACCENT, ACCENT_SOFT = (232, 163, 23), (252, 241, 216)
INK, INK2, MUTED, LINE, SOFT, WHITE = (15, 27, 38), (37, 52, 65), (90, 103, 114), (226, 224, 216), (246, 245, 241), (255, 255, 255)
VERDICT = {"strong_fit": ("Strong fit", BRAND), "possible_fit": ("Possible fit", ACCENT), "weak_fit": ("Weak fit", MUTED)}
CONF = {"high": BRAND, "medium": ACCENT, "low": (176, 64, 48)}
# Report font sets: (regular, bold, italic). IBM Plex Sans is the default (Justin 2026-11-11); DejaVu kept as the fallback.
FONT_SETS = {"plex": ("IBMPlexSans-Regular.ttf", "IBMPlexSans-SemiBold.ttf", "IBMPlexSans-Italic.ttf"),
             "dejavu": ("DejaVuSans.ttf", "DejaVuSans-Bold.ttf", "DejaVuSans.ttf")}
REPORT_FONT = "plex"
LEADING = 1.42  # line height as a multiple of the font size
PT = 0.3528  # mm per point


def _lh(size_pt, k=LEADING):
    return size_pt * PT * k


DISCLAIMER = ("AI-generated from {site} fleet and bid data, which include estimates. For research and planning purposes only; "
              "not financial, legal or engineering advice. Check figures before you rely on them.")


def _clean(s):
    return re.sub(r"[​-‏﻿]", "", str(s or "")).strip()


def _kind_label(kind):
    return "Bid fit brief" if kind == "brief" else "Analyst answer"


class _Doc(FPDF):
    site, kind_label, when, domain = "Consist", "", "", ""

    def logo(self, x, y, h, light=False):
        """The Consist mark (three cars on wheels), drawn as shapes so it is crisp at any size."""
        s = h / 40.0
        a, b, c = (WHITE, (255, 255, 255), ACCENT) if light else (BRAND, BRAND, ACCENT)
        for i, (col, op) in enumerate(((a, 1), (b, .72), (c, 1))):
            cx = x + (1 + 23 * i) * s
            with self.local_context(fill_opacity=op):
                self.set_fill_color(*col)
                self.rect(cx, y + 6 * s, 20 * s, 24 * s, style="F", round_corners=True, corner_radius=5 * s)
                for dx in (6, 14):
                    self.ellipse(cx + (dx - 3) * s, y + 32 * s, 6 * s, 6 * s, style="F")
        return 68 * s

    def header(self):
        if self.page_no() == 1:
            self.set_fill_color(*BRAND)
            self.rect(0, 0, self.w, 30, style="F")
            self.set_fill_color(*ACCENT)
            self.rect(0, 30, self.w, 1.2, style="F")
            w = self.logo(self.l_margin, 8.5, 13, light=True)
            self.set_xy(self.l_margin + w + 3, 9)
            self.set_font("rp", "B", 18)
            self.set_text_color(*WHITE)
            self.cell(60, 9, self.site)
            self.set_xy(self.l_margin + w + 3.4, 18)
            self.set_font("rp", "", 7.5)
            self.set_text_color(205, 230, 224)
            self.cell(80, 4, "Rail market intelligence for North America")
            self.set_xy(self.w - self.r_margin - 80, 9.5)
            self.set_font("rp", "B", 8)
            self.set_text_color(*ACCENT)
            self.cell(80, 4, ("AI " + self.kind_label).upper(), align="R")
            self.set_xy(self.w - self.r_margin - 80, 15)
            self.set_font("rp", "", 8)
            self.set_text_color(*WHITE)
            self.cell(80, 4, self.when, align="R")
            self.set_y(38)
        else:
            w = self.logo(self.l_margin, 8, 6)
            self.set_xy(self.l_margin + w + 2, 8.6)
            self.set_font("rp", "B", 9)
            self.set_text_color(*BRAND_INK)
            self.cell(40, 5, self.site)
            self.set_xy(self.w - self.r_margin - 90, 8.6)
            self.set_font("rp", "", 7.5)
            self.set_text_color(*MUTED)
            self.cell(90, 5, f"{self.kind_label} · {self.when}", align="R")
            self.set_draw_color(*LINE)
            self.set_line_width(0.3)
            self.line(self.l_margin, 16, self.w - self.r_margin, 16)
            self.set_y(21)

    def footer(self):
        self.set_y(-13)
        self.set_draw_color(*LINE)
        self.set_line_width(0.3)
        self.line(self.l_margin, self.get_y() - 1.5, self.w - self.r_margin, self.get_y() - 1.5)
        self.set_font("rp", "", 7)
        self.set_text_color(*MUTED)
        self.cell(0, 4, f"{self.site} · {self.domain} · AI-generated, check figures before relying on them")
        self.set_x(self.l_margin)
        self.cell(0, 4, f"Page {self.page_no()} of {{nb}}", align="R")

    # ---- building blocks ----
    def pill(self, text, color, filled=True):
        self.set_font("rp", "B", 8)
        w = self.get_string_width(text) + 7
        x, y = self.get_x(), self.get_y()
        if filled:
            self.set_fill_color(*color)
            self.set_text_color(*(WHITE if color != ACCENT else INK))
            self.rect(x, y, w, 6, style="F", round_corners=True, corner_radius=3)
        else:
            self.set_draw_color(*color)
            self.set_line_width(0.35)
            self.set_text_color(*color)
            self.rect(x, y, w, 6, style="D", round_corners=True, corner_radius=3)
        self.set_xy(x, y + 0.6)
        self.cell(w, 4.8, text, align="C")
        self.set_xy(x + w + 2.5, y)

    def section(self, title):
        if self.get_y() > self.h - 40:
            self.add_page()
        self.ln(2)
        y = self.get_y()
        self.set_fill_color(*ACCENT)
        self.rect(self.l_margin, y + 1, 1.4, 4.6, style="F")
        self.set_x(self.l_margin + 3.5)
        self.set_font("rp", "B", 11)
        self.set_text_color(*BRAND_INK)
        self.cell(0, 6.5, title, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)


def _html(markdown_text):
    """Markdown -> the simple HTML fpdf2 can lay out."""
    h = _md.markdown(_clean(markdown_text), extensions=["sane_lists"])
    h = re.sub(r"</?(span|div|code|pre|blockquote)[^>]*>", "", h)
    h = re.sub(r"<h[1-6]>", "<h4>", h)
    h = re.sub(r"</h[1-6]>", "</h4>", h)
    h = re.sub(r"<(p|ul|ol)>", lambda m: f'<{m.group(1)} line-height="{LEADING}">', h)  # fpdf2 takes leading per block
    return h


def build(result, kind="ask", title="", question="", site="Consist", url="", when=None, meta=None, font=None):
    """result: the analyst job's result dict; meta: optional {agency, ref_no, closing, published} for a bid brief. Returns PDF bytes."""
    r, meta = result or {}, meta or {}
    when = when or datetime.datetime.now(datetime.timezone.utc)
    pdf = _Doc(format="Letter")
    pdf.site, pdf.kind_label, pdf.when = site, _kind_label(kind), f"{when:%B} {when.day}, {when:%Y}"
    pdf.domain = re.sub(r"^https?://", "", (url or "consist-na.com")).split("/")[0] or "consist-na.com"
    pdf.set_title(f"{site} {pdf.kind_label}" + (f": {_clean(title)}" if title else ""))
    pdf.set_author(site)
    pdf.set_creator(site)
    reg, bold, ital = FONT_SETS.get(font) or FONT_SETS[REPORT_FONT]
    for style, f in (("", reg), ("B", bold), ("I", ital), ("BI", bold)):
        pdf.add_font("rp", style, os.path.join(FONTS, f))
    for style, f in (("", "DejaVuSans.ttf"), ("B", "DejaVuSans-Bold.ttf")):
        pdf.add_font("dv", style, os.path.join(FONTS, f))
    pdf.set_fallback_fonts(["dv"], exact_match=False)  # arrows, symbols and scripts the report font lacks
    try:
        import uharfbuzz  # noqa: F401  kerning and ligatures
        pdf.set_text_shaping(True)
    except Exception:
        pass
    pdf.set_margins(18, 16, 18)
    pdf.set_auto_page_break(True, 20)
    pdf.add_page()
    w = pdf.w - pdf.l_margin - pdf.r_margin

    # Title block
    if title:
        pdf.set_font("rp", "B", 17)
        pdf.set_text_color(*INK)
        pdf.multi_cell(w, _lh(17, 1.2), _clean(title), new_x="LMARGIN", new_y="NEXT")
    elif question:
        pdf.set_font("rp", "B", 15)
        pdf.set_text_color(*INK)
        pdf.multi_cell(w, _lh(15, 1.2), _clean(question), new_x="LMARGIN", new_y="NEXT")
    bits = [x for x in (meta.get("agency"), meta.get("ref_no") and f"Ref. {meta['ref_no']}",
                        meta.get("published") and f"Posted {meta['published']}", meta.get("closing") and f"Closes {meta['closing']}") if x]
    if bits:
        pdf.ln(0.5)
        pdf.set_font("rp", "", 9.5)
        pdf.set_text_color(*MUTED)
        pdf.multi_cell(w, _lh(9.5), "  ·  ".join(_clean(b) for b in bits), align="L", new_x="LMARGIN", new_y="NEXT")
    if question and title and kind != "brief":
        pdf.set_font("rp", "", 9)
        pdf.set_text_color(*MUTED)
        pdf.multi_cell(w, _lh(9), "You asked: " + _clean(question), align="L", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    # Verdict and confidence
    if r.get("verdict") in VERDICT:
        lab, col = VERDICT[r["verdict"]]
        pdf.pill(lab, col)
    conf = (r.get("confidence") or "medium").lower()
    pdf.pill(f"{conf.capitalize()} confidence", CONF.get(conf, MUTED), filled=False)
    pdf.set_xy(pdf.l_margin, pdf.get_y() + 9)

    # Headline callout
    if r.get("headline"):
        pdf.set_font("rp", "B", 12.5)
        hl = _lh(12.5, 1.32)
        lines = pdf.multi_cell(w - 12, hl, _clean(r["headline"]), dry_run=True, output="LINES")
        hgt = len(lines) * hl + 8
        y = pdf.get_y()
        pdf.set_fill_color(*BRAND_SOFT)
        pdf.rect(pdf.l_margin, y, w, hgt, style="F", round_corners=True, corner_radius=2.5)
        pdf.set_fill_color(*BRAND)
        pdf.rect(pdf.l_margin, y, 1.8, hgt, style="F")
        pdf.set_xy(pdf.l_margin + 7, y + 4)
        pdf.set_text_color(*BRAND_INK)
        pdf.multi_cell(w - 12, hl, _clean(r["headline"]), new_x="LMARGIN", new_y="NEXT")
        pdf.set_y(y + hgt + 5)

    # Key figure tiles, three to a row. Values shrink from 15pt to 9pt to fit the tile, then wrap; labels wrap.
    figs = [k for k in (r.get("key_figures") or []) if isinstance(k, dict) and (k.get("value") or k.get("label"))][:9]
    if figs:
        pdf.section("Key figures")
        gap, per, pad = 4, 3, 4
        tw = (w - gap * (per - 1)) / per
        iw = tw - 2 * pad
        lab_pt = 8.5
        lab_lh = _lh(lab_pt, 1.3)

        def fit_value(v):
            for pt in (15, 14, 13, 12, 11, 10, 9):
                pdf.set_font("rp", "B", pt)
                if len(pdf.multi_cell(iw, _lh(pt, 1.2), v, dry_run=True, output="LINES")) == 1:
                    return pt, [v]
            pdf.set_font("rp", "B", 9)
            return 9, pdf.multi_cell(iw, _lh(9, 1.2), v, dry_run=True, output="LINES")

        def label_of(k):
            return _clean(k.get("label")) + (f" ({_clean(k.get('note'))})" if k.get("note") else "")

        for i in range(0, len(figs), per):
            row = figs[i:i + per]
            laid = []
            for k in row:
                v = _clean(k.get("value")) or "—"
                pt, vlines = fit_value(v)
                vh = len(vlines) * _lh(pt, 1.2)
                pdf.set_font("rp", "", lab_pt)
                llines = pdf.multi_cell(iw, lab_lh, label_of(k), dry_run=True, output="LINES") if label_of(k) else []
                laid.append((vlines, pt, vh, llines))
            vmax = max(x[2] for x in laid)
            th = 6 + vmax + 2 + max(len(x[3]) for x in laid) * lab_lh + 3.5
            if pdf.get_y() + th > pdf.h - 22:
                pdf.add_page()
            y = pdf.get_y()
            for j, (vlines, pt, vh, llines) in enumerate(laid):
                x = pdf.l_margin + j * (tw + gap)
                pdf.set_fill_color(*SOFT)
                pdf.set_draw_color(*LINE)
                pdf.set_line_width(0.25)
                pdf.rect(x, y, tw, th, style="DF", round_corners=True, corner_radius=2.5)
                pdf.set_fill_color(*ACCENT)
                pdf.rect(x + pad, y + 3.2, 6, 0.9, style="F")
                pdf.set_font("rp", "B", pt)
                pdf.set_text_color(*BRAND_INK)
                vy = y + 6 + (vmax - vh)  # values share a baseline row; labels line up below
                pdf.set_xy(x + pad, vy)
                pdf.multi_cell(iw, _lh(pt, 1.2), "\n".join(vlines), align="L")
                pdf.set_font("rp", "", lab_pt)
                pdf.set_text_color(*INK2)
                pdf.set_xy(x + pad, y + 6 + vmax + 2)
                if llines:
                    pdf.multi_cell(iw, lab_lh, "\n".join(llines), align="L")
            pdf.set_xy(pdf.l_margin, y + th + gap)
        pdf.ln(1)

    # Body
    body = r.get("answer_markdown") or ""
    if body.strip():
        pdf.section("Analysis")
        pdf.set_font("rp", "", 10.5)
        pdf.set_text_color(*INK)
        try:
            pdf.write_html(_html(body), tag_styles={"h4": FontFace(emphasis="BOLD", size_pt=11.5, color=BRAND_INK),
                                                     "a": FontFace(color=BRAND), "li": FontFace(color=INK),
                                                     "ul": TextStyle(t_margin=0.01), "ol": TextStyle(t_margin=0.01)},
                           ul_bullet_char="•", li_prefix_color=BRAND)
        except Exception:  # anything the HTML layout can't handle prints as plain text
            pdf.multi_cell(w, _lh(10.5), re.sub(r"[#*_`>]", "", _clean(body)), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)

    # Table
    tb = r.get("table") or {}
    cols, rows = tb.get("columns") or [], tb.get("rows") or []
    if cols and rows:
        pdf.section(_clean(tb.get("title")) or "Detail")
        pdf.set_font("rp", "", 9 if len(cols) <= 6 else 8)
        pdf.set_text_color(*INK)
        pdf.set_fill_color(*WHITE)
        pdf.set_draw_color(*LINE)
        try:
            with pdf.table(headings_style=FontFace(emphasis="BOLD", color=WHITE, fill_color=BRAND), line_height=_lh(9, 1.3), padding=(1.8, 2.2),
                           borders_layout="HORIZONTAL_LINES", cell_fill_color=SOFT, cell_fill_mode="ROWS", text_align="LEFT") as t:
                t.row([_clean(c) for c in cols])
                for rr in rows[:200]:
                    rr = list(rr) + [""] * (len(cols) - len(rr))
                    t.row([_clean(c) for c in rr[:len(cols)]])
        except Exception:
            for rr in rows[:200]:
                pdf.multi_cell(w, _lh(9), " | ".join(_clean(c) for c in rr), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    # Caveats
    cav = [c for c in (r.get("caveats") or []) if _clean(c)]
    if cav:
        pdf.set_font("rp", "", 9.5)
        cl = _lh(9.5, 1.38)
        hgt = 9 + sum(len(pdf.multi_cell(w - 14, cl, "• " + _clean(c), dry_run=True, output="LINES")) * cl + 1 for c in cav)
        if pdf.get_y() + hgt > pdf.h - 22:
            pdf.add_page()
        y = pdf.get_y()
        pdf.set_fill_color(*ACCENT_SOFT)
        pdf.rect(pdf.l_margin, y, w, hgt, style="F", round_corners=True, corner_radius=2.5)
        pdf.set_xy(pdf.l_margin + 6, y + 3)
        pdf.set_font("rp", "B", 9.5)
        pdf.set_text_color(122, 82, 0)
        pdf.cell(0, 5, "Caveats", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("rp", "", 9.5)
        pdf.set_text_color(*INK2)
        for c in cav:
            pdf.set_x(pdf.l_margin + 6)
            pdf.multi_cell(w - 14, cl, "• " + _clean(c), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(1)
        pdf.set_y(y + hgt + 4)

    # Key to terms (1.7.54): the pills and abbreviations this report uses, for readers away from the site's hover cards
    from . import reportkey
    key = reportkey.for_ai(r)
    if key:
        pdf.section("Key to terms")
        for t, d in key:
            pdf.set_font("rp", "B", 8.6)
            pdf.set_text_color(*INK)
            pdf.multi_cell(w, _lh(8.6, 1.3), _clean(t), align="L", new_x="LMARGIN", new_y="NEXT")
            pdf.set_font("rp", "", 8.6)
            pdf.set_text_color(*INK2)
            pdf.multi_cell(w, _lh(8.6, 1.3), _clean(d), align="L", new_x="LMARGIN", new_y="NEXT")
            pdf.ln(1)
        pdf.ln(2)

    # Source and disclaimer
    pdf.set_font("rp", "", 7.8)
    pdf.set_text_color(*MUTED)
    if url:
        pdf.set_font("rp", "B", 7.8)
        pdf.cell(0, 4.5, "Open in " + site + ": ", new_x="END")
        pdf.set_font("rp", "", 7.8)
        pdf.set_text_color(*BRAND)
        pdf.cell(0, 4.5, url, link=url, new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(*MUTED)
    pdf.multi_cell(w, _lh(7.8, 1.35), DISCLAIMER.format(site=site), align="L", new_x="LMARGIN", new_y="NEXT")
    return bytes(pdf.output())


# ---- plain text and RTF (1.7.20) ----

def _plain(markdown_text):
    """Markdown -> readable plain text: headings in capitals, bullets kept, emphasis marks dropped."""
    out = []
    for ln in _clean(markdown_text).splitlines():
        m = re.match(r"^\s*#{1,6}\s*(.+)$", ln)
        if m:
            out += ["", m.group(1).strip().upper()]
            continue
        ln = re.sub(r"^\s*[-*+]\s+", "  • ", ln)
        ln = re.sub(r"\*\*(.+?)\*\*|__(.+?)__", lambda x: x.group(1) or x.group(2), ln)
        ln = re.sub(r"(?<!\w)[*_](.+?)[*_](?!\w)", r"\1", ln)
        ln = re.sub(r"`([^`]*)`", r"\1", ln)
        ln = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1 (\2)", ln)
        out.append(ln.rstrip())
    return "\n".join(out).strip()


def _sections(result, kind, title, question, site, url, when, meta):
    """The report as (heading, [paragraphs or ('table', cols, rows) or ('bullets', items)]) sections, shared by TXT and RTF."""
    r, meta = result or {}, meta or {}
    when = when or datetime.datetime.now(datetime.timezone.utc)
    head = [f"{site.upper()} · AI {_kind_label(kind).upper()}", f"{when:%B} {when.day}, {when:%Y}"]
    top = []
    if title or question:
        top.append(("title", _clean(title or question)))
    bits = [x for x in (meta.get("agency"), meta.get("ref_no") and f"Ref. {meta['ref_no']}",
                        meta.get("published") and f"Posted {meta['published']}", meta.get("closing") and f"Closes {meta['closing']}") if x]
    if bits:
        top.append(("meta", "  ·  ".join(_clean(b) for b in bits)))
    if question and title and kind != "brief":
        top.append(("meta", "You asked: " + _clean(question)))
    tags = ([VERDICT[r["verdict"]][0]] if r.get("verdict") in VERDICT else []) + [f"{(r.get('confidence') or 'medium').capitalize()} confidence"]
    top.append(("meta", " | ".join(tags)))
    if r.get("headline"):
        top.append(("headline", _clean(r["headline"])))
    secs = [("", top)]
    figs = [k for k in (r.get("key_figures") or []) if isinstance(k, dict)]
    if figs:
        secs.append(("Key figures", [("bullets", [f"{_clean(k.get('value'))}: {_clean(k.get('label'))}" + (f" ({_clean(k.get('note'))})" if k.get("note") else "")
                                                  for k in figs])]))
    if (r.get("answer_markdown") or "").strip():
        secs.append(("Analysis", [("md", r["answer_markdown"])]))
    tb = r.get("table") or {}
    if tb.get("columns") and tb.get("rows"):
        secs.append((_clean(tb.get("title")) or "Detail", [("table", [_clean(c) for c in tb["columns"]], [[_clean(c) for c in rr] for rr in tb["rows"][:200]])]))
    cav = [_clean(c) for c in (r.get("caveats") or []) if _clean(c)]
    if cav:
        secs.append(("Caveats", [("bullets", cav)]))
    from . import reportkey  # 1.7.54 key to terms
    key = reportkey.for_ai(r)
    if key:
        secs.append(("Key to terms", [("bullets", [f"**{t}**: {d}" for t, d in key])]))
    tail = ([("meta", f"Open in {site}: {url}")] if url else []) + [("meta", DISCLAIMER.format(site=site))]
    secs.append(("", tail))
    return head, secs


def build_txt(result, kind="ask", title="", question="", site="Consist", url="", when=None, meta=None):
    head, secs = _sections(result, kind, title, question, site, url, when, meta)
    out = [head[0], head[1], "=" * 72, ""]
    for h, items in secs:
        if h:
            out += [h.upper(), "-" * len(h)]
        for it in items:
            k = it[0]
            if k == "title":
                out += [it[1], ""]
            elif k in ("meta", "headline"):
                out += [it[1], ""]
            elif k == "bullets":
                out += [f"  • {b.replace('**', '')}" for b in it[1]] + [""]
            elif k == "md":
                out += [_plain(it[1]), ""]
            elif k == "table":
                cols, rows = it[1], it[2]
                wd = [min(40, max(len(str(c)) for c in [cols[i]] + [rr[i] if i < len(rr) else "" for rr in rows])) for i in range(len(cols))]
                fmt = lambda rr: "  ".join(str(rr[i] if i < len(rr) else "")[:wd[i]].ljust(wd[i]) for i in range(len(cols))).rstrip()  # noqa: E731
                out += [fmt(cols), "  ".join("-" * x for x in wd)] + [fmt(rr) for rr in rows] + [""]
    return (re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip() + "\n").encode("utf-8")


def _rtf_esc(s):
    out = []
    for ch in str(s or ""):
        o = ord(ch)
        if ch in "\\{}":
            out.append("\\" + ch)
        elif ch == "\n":
            out.append("\\line ")
        elif o < 128:
            out.append(ch)
        else:
            b = ch.encode("utf-16-le")
            for i in range(0, len(b), 2):  # RTF \uN takes signed 16-bit units; astral characters become a surrogate pair
                v = int.from_bytes(b[i:i + 2], "little")
                out.append(f"\\u{v - 65536 if v > 32767 else v}?")
    return "".join(out)


def _rtf_inline(md_line):
    """Bold and italic markdown inside one line -> RTF."""
    s = _rtf_esc(md_line)
    s = re.sub(r"\*\*(.+?)\*\*", r"{\\b \1}", s)
    s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)\*(?!\w)", r"{\\i \1}", s)
    s = re.sub(r"`([^`]*)`", r"\1", s)
    return s


BULLET_RE = re.compile(r"^\s*[-*+]\s+")
NUM_RE = re.compile(r"^\s*(\d+)[.)]\s+")


def build_rtf(result, kind="ask", title="", question="", site="Consist", url="", when=None, meta=None):
    """An RTF report (Word, Pages, Google Docs, TextEdit) with the Consist colours, headings, bullets and a real table."""
    head, secs = _sections(result, kind, title, question, site, url, when, meta)
    col = lambda c: "\\red%d\\green%d\\blue%d;" % c  # noqa: E731
    o = ["{\\rtf1\\ansi\\ansicpg1252\\deff0\\uc1",
         "{\\fonttbl{\\f0\\fswiss\\fcharset0 Helvetica;}{\\f1\\fmodern\\fcharset0 Courier New;}}",
         "{\\colortbl;" + col(INK) + col(BRAND) + col(ACCENT) + col(MUTED) + col(BRAND_SOFT) + col(WHITE) + col(BRAND_INK) + "}",
         f"{{\\info{{\\title {_rtf_esc(site + ' ' + _kind_label(kind))}}}{{\\author {_rtf_esc(site)}}}}}",
         "\\paperw12240\\paperh15840\\margl1300\\margr1300\\margt1100\\margb1100\\f0\\fs20\\cf1",
         # header band
         f"\\pard\\plain\\f0\\fs40\\b\\cf2 {_rtf_esc(site)}\\b0\\fs18\\cf4\\tab {_rtf_esc(head[0].split(' · ', 1)[1])}\\par",
         f"\\pard\\plain\\f0\\fs16\\cf4 Rail market intelligence for North America  \\bullet  {_rtf_esc(head[1])}\\par",
         "\\pard\\brdrb\\brdrs\\brdrw30\\brdrcf3\\sb0\\sa200\\par"]
    for h, items in secs:
        if h:
            o.append(f"\\pard\\plain\\f0\\sb240\\sa80\\fs24\\b\\cf7 {_rtf_esc(h)}\\par")
        for it in items:
            k = it[0]
            if k == "title":
                o.append(f"\\pard\\plain\\f0\\sa80\\fs32\\b\\cf1 {_rtf_esc(it[1])}\\par")
            elif k == "meta":
                o.append(f"\\pard\\plain\\f0\\sa80\\fs17\\cf4 {_rtf_esc(it[1])}\\par")
            elif k == "headline":
                o.append(f"\\pard\\plain\\f0\\sb120\\sa160\\li200\\ri200\\brdrl\\brdrs\\brdrw40\\brdrcf2\\cbpat5\\fs24\\b\\cf7 {_rtf_esc(it[1])}\\par")
            elif k == "bullets":
                for b in it[1]:
                    o.append(f"\\pard\\plain\\f0\\fi-220\\li440\\sa60\\fs20\\cf1 \\bullet\\tab {_rtf_inline(b)}\\par")
            elif k == "md":
                for ln in _clean(it[1]).splitlines():
                    if not ln.strip():
                        continue
                    m = re.match(r"^\s*#{1,6}\s*(.+)$", ln)
                    if m:
                        o.append(f"\\pard\\plain\\f0\\sb160\\sa60\\fs21\\b\\cf7 {_rtf_inline(m.group(1))}\\par")
                    elif re.match(r"^\s*[-*+]\s+", ln):
                        txt = _rtf_inline(BULLET_RE.sub("", ln))
                        o.append(f"\\pard\\plain\\f0\\fi-220\\li440\\sa60\\fs20\\cf1 \\bullet\\tab {txt}\\par")
                    elif NUM_RE.match(ln):
                        n, txt = NUM_RE.match(ln).group(1), _rtf_inline(NUM_RE.sub("", ln))
                        o.append(f"\\pard\\plain\\f0\\fi-280\\li440\\sa60\\fs20\\cf1 {n}.\\tab {txt}\\par")
                    else:
                        o.append(f"\\pard\\plain\\f0\\sa100\\fs20\\cf1 {_rtf_inline(ln)}\\par")
            elif k == "table":
                cols, rows = it[1], it[2]
                tw = 9640
                cw = tw // max(1, len(cols))
                def rowdef(header):
                    d = "\\trowd\\trgaph80\\trleft0"
                    for i in range(len(cols)):
                        d += ("\\clcbpat2" if header else "") + "\\clbrdrb\\brdrs\\brdrw8\\brdrcf4" + f"\\cellx{cw * (i + 1)}"
                    return d
                o.append(rowdef(True))
                o.append("".join(f"\\pard\\intbl\\plain\\f0\\fs17\\b\\cf6 {_rtf_esc(c)}\\cell " for c in cols) + "\\row")
                for rr in rows:
                    rr = list(rr) + [""] * (len(cols) - len(rr))
                    o.append(rowdef(False))
                    o.append("".join(f"\\pard\\intbl\\plain\\f0\\fs17\\cf1 {_rtf_esc(c)}\\cell " for c in rr[:len(cols)]) + "\\row")
                o.append("\\pard\\plain\\sa120\\par")
    o.append("}")
    return "\n".join(o).encode("latin-1", "replace")


FORMATS = {"pdf": ("application/pdf", build), "rtf": ("application/rtf", build_rtf), "txt": ("text/plain; charset=utf-8", build_txt)}


def filename(kind, ref, job_id, ext="pdf"):
    base = f"consist-bid-fit-brief-{ref}" if kind == "brief" and ref else f"consist-analyst-answer-{job_id[:8]}"
    return re.sub(r"[^A-Za-z0-9._-]", "-", base) + "." + ext
