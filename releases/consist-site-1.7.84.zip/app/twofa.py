"""Two-factor sign-in with an authenticator app (TOTP, RFC 6238) and one-time recovery codes.

The admin setting 'twofa_mode' decides who needs it: off, optional (members turn it on in Account), admins (required for admins,
optional for members) or all (required for everyone). A member who must have it and has not set it up enrols during sign-in.
A signed 'remember this device' cookie skips the code for 30 days; changing the password or resetting 2FA voids it."""
import base64
import hashlib
import hmac
import io
import json
import secrets
import struct
import time
from urllib.parse import quote

from itsdangerous import BadSignature, URLSafeTimedSerializer

from . import config, db

MODES = {"off": "Off", "optional": "Optional for everyone", "admins": "Required for admins, optional for members", "all": "Required for everyone"}
STEP = 30
REMEMBER_DAYS = 30
REMEMBER_COOKIE = "consist_2fa"
PENDING_MINUTES = 10


def mode():
    m = db.settings().get("twofa_mode") or "optional"
    return m if m in MODES else "optional"


def enabled(u):
    return bool(u and u.get("totp_on"))


def required(u):
    m = mode()
    return m == "all" or (m == "admins" and (u.get("role") == "admin"))


def available():
    return mode() != "off"


# ---------- TOTP ----------

def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def _code(secret, step):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8))
    h = hmac.new(key, struct.pack(">Q", step), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return "%06d" % ((struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def check_code(secret, code, last_step=None, now=None):
    """The time step the code matches (one step of clock drift either way), or None. A step at or before last_step is refused,
    so a code can't be used twice."""
    code = "".join(ch for ch in (code or "") if ch.isdigit())
    if not secret or len(code) != 6:
        return None
    t = int((now or time.time()) // STEP)
    for s in (t, t - 1, t + 1):
        if hmac.compare_digest(_code(secret, s), code) and (last_step is None or s > last_step):
            return s
    return None


def otpauth_uri(secret, email):
    issuer = db.settings().get("site_name") or "Consist"
    return f"otpauth://totp/{quote(issuer)}:{quote(email)}?secret={secret}&issuer={quote(issuer)}&digits=6&period={STEP}"


def qr_svg(uri):
    import segno
    buf = io.BytesIO()
    segno.make(uri, error="m").save(buf, kind="svg", scale=5, border=2, dark="#0b1f1c", light="#ffffff", xmldecl=False, svgns=True)
    return buf.getvalue().decode()


def pretty_secret(secret):
    return " ".join(secret[i:i + 4] for i in range(0, len(secret), 4))


# ---------- recovery codes ----------

def _hash(c):
    return hashlib.sha256(c.replace("-", "").strip().lower().encode()).hexdigest()


def new_recovery_codes(uid, n=10):
    codes = [f"{secrets.token_hex(3)}-{secrets.token_hex(3)}" for _ in range(n)]
    db.x("UPDATE user SET totp_recovery = ? WHERE id = ?", (json.dumps([_hash(c) for c in codes]), uid))
    return codes


def recovery_left(u):
    try:
        return len(json.loads(u.get("totp_recovery") or "[]"))
    except ValueError:
        return 0


def use_recovery_code(u, code):
    try:
        left = json.loads(u.get("totp_recovery") or "[]")
    except ValueError:
        left = []
    h = _hash(code or "")
    if h not in left:
        return False
    left.remove(h)
    db.x("UPDATE user SET totp_recovery = ? WHERE id = ?", (json.dumps(left), u["id"]))
    return True


# ---------- turning it on and off ----------

def enable(uid, secret, step):
    db.x("UPDATE user SET totp_secret = ?, totp_on = 1, totp_last = ? WHERE id = ?", (secret, step, uid))
    return new_recovery_codes(uid)


def disable(uid):
    db.x("UPDATE user SET totp_secret = NULL, totp_on = 0, totp_last = NULL, totp_recovery = NULL WHERE id = ?", (uid,))


def verify(u, code):
    """True when code is a current authenticator code (recorded so it can't be replayed) or an unused recovery code."""
    s = check_code(u.get("totp_secret"), code, u.get("totp_last"))
    if s is not None:
        db.x("UPDATE user SET totp_last = ? WHERE id = ?", (s, u["id"]))
        return True
    return use_recovery_code(u, code)


# ---------- remember this device ----------

def _signer():
    return URLSafeTimedSerializer(config.SECRET_KEY, salt="consist-2fa-remember")


def _mark(u):
    """Changes whenever the password or the 2FA secret changes, which voids remembered devices."""
    return hashlib.sha256(f"{u.get('pw_hash') or ''}|{u.get('totp_secret') or ''}".encode()).hexdigest()[:16]


def remember_cookie(u):
    return _signer().dumps({"u": u["id"], "m": _mark(u)})


def remembered(request, u):
    raw = request.cookies.get(REMEMBER_COOKIE)
    if not raw:
        return False
    try:
        d = _signer().loads(raw, max_age=REMEMBER_DAYS * 86400)
    except BadSignature:
        return False
    return d.get("u") == u["id"] and d.get("m") == _mark(u)


def set_remember(resp, u):
    resp.set_cookie(REMEMBER_COOKIE, remember_cookie(u), max_age=REMEMBER_DAYS * 86400, httponly=True, samesite="lax",
                    secure=config.COOKIE_SECURE, path="/")
