"""STB EP 724 weekly Class I service metrics. Public domain (STB).

1.7.63 (Justin 11-17, "why aren't the weekly service metrics for freight being updated?"): the data was only the seed file baked
into each site build (seed/ep724.csv.gz, made by hand with tools/ep724/build.py), so it stopped at the last build. refresh() now runs
once a day from the alerts loop: it reads STB's Rail Service Data page, and when a newer "EP724 Consolidated Data through <date>.xlsx"
is posted it downloads it, keeps the same measures and writes DATA_DIR/ep724.csv.gz, which is read in preference to the seed.
Status in settings ep724_through / ep724_checked / ep724_ok / ep724_error (Admin > Diagnostics, Freight service data)."""
import csv, datetime, gzip, logging, os, re, tempfile, urllib.request
SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "ep724.csv.gz")
log = logging.getLogger("ep724")
PAGE = "https://www.stb.gov/reports-data/rail-service-data/"
UA = "ConsistBot/1.0 (+https://consist-na.com; weekly STB EP 724 download)"
LINK = re.compile(r'href="([^"]*EP724(?:%20| )Consolidated(?:%20| )Data(?:%20| )through(?:%20| )(\d{4}-\d{2}-\d{2})\.xlsx)"', re.I)
KEEP = {1: "speed", 2: "dwell", 3: "cars_online", 6: "stalled", 11: "carloads"}
LABEL = {1: "Speed", 2: "Terminal Dwell", 3: "Cars On Line", 6: "Not Moved", 11: "22"}


def data_file():
    from . import config
    return os.path.join(config.DATA_DIR, "ep724.csv.gz")


def path():
    """The refreshed copy in DATA_DIR when there is one, else the seed shipped with the build."""
    d = data_file()
    return d if os.path.exists(d) else SEED
RR = [("BNSF", "BNSF"), ("UP", "Union Pacific"), ("CSX", "CSX"), ("NS", "Norfolk Southern"), ("CN", "CN (US)"), ("CPKC", "CPKC (US)"),
      ("CP", "CP (US, reported separately to 2025)"), ("KCS", "KCS (reported separately to 2025)")]
CREDIT = "Surface Transportation Board, EP 724 Rail Service Data (weekly reports filed by each Class I railroad)."
DEF = {
    "speed": ("Average train speed", "Line-haul miles divided by hours in motion and stopped en route between terminals, by train type, mph. Excludes time in terminals. Each railroad measures slightly differently, so compare trends, not levels, across railroads."),
    "dwell": ("Terminal dwell", "Average hours a car sits in a terminal yard between arrival and departure, excluding cars on run-through trains. 'System' is the railroad-wide average."),
    "cars_online": ("Cars online", "Railcars on the railroad's lines at the end of the week, by car type (railroad-owned and private). Rising counts with flat volume signal congestion."),
    "stalled": ("Cars not moved 48h+", "Loaded and empty revenue cars that have not moved in 48 hours or more, weekly average."),
    "carloads": ("Weekly carloads", "Carloads and intermodal units originated (or received) in the week, by 22 commodity groups."),
}
_c = {}


def _load():
    if "d" not in _c:
        d = {}
        src = path()
        if os.path.exists(src):
            with gzip.open(src, "rt", newline="") as f:
                for r in csv.DictReader(f):
                    d.setdefault((r["rr"], r["measure"], r["variable"], r["sub"]), []).append((r["week"], float(r["value"])))
        _c["d"] = d
    return _c["d"]


def available():
    return bool(_load())


def series(rr, measure, variable, sub=""):
    return _load().get((rr, measure, variable, sub), [])


def variables(rr, measure, sub=""):
    return [k[2] for k in _load() if k[0] == rr and k[1] == measure and k[3] == sub]


def latest_week():
    return max((s[-1][0] for s in _load().values() if s), default=None)


def x(week):
    d = datetime.date.fromisoformat(week)
    return d.year + (d.timetuple().tm_yday - 1) / 365.25


def avg(s, n=4, end=None):
    s = [v for w, v in s if end is None or w <= end][-n:]
    return sum(s) / len(s) if s else None


def yoy(s, n=4):
    """Last n weeks average vs the same weeks a year earlier (52 weeks back), %."""
    if len(s) < 52 + n:
        return None
    a = sum(v for _, v in s[-n:]) / n
    b = sum(v for _, v in s[-52 - n:-52]) / n
    return 100 * (a / b - 1) if b else None


def system(rr, measure):
    for v in ("System", "System (U.S.)", "All Trains", "Total"):
        if series(rr, measure, v):
            return series(rr, measure, v)
    return []


def rail_ids():
    have = {k[0] for k in _load()}
    return [(r, n) for r, n in RR if r in have]


def carloads(rr):
    """Commodity rows: originated, 4-week avg and YoY."""
    out = []
    for v in variables(rr, "carloads", "Originated"):
        s = series(rr, "carloads", v, "Originated")
        out.append(dict(name=v, w4=avg(s), yoy=yoy(s), s=s))
    return sorted(out, key=lambda r: -(r["w4"] or 0))


def scoreboard():
    out = []
    for rr, name in rail_ids():
        sp = [series(rr, "speed", v) for v in variables(rr, "speed")]
        sp_all = system(rr, "speed")
        dw = system(rr, "dwell")
        co = series(rr, "cars_online", "Total")
        st = [series(rr, "stalled", v, sub) for sub in ("Loaded", "Empty") for v in variables(rr, "stalled", sub)]
        st_tot = sum(avg(s) or 0 for s in st) if st else None
        cl = [series(rr, "carloads", v, "Originated") for v in variables(rr, "carloads", "Originated")]
        cl_tot = sum(avg(s) or 0 for s in cl) if cl else None
        cl_prev = sum(sum(v for _, v in s[-56:-52]) / 4 for s in cl if len(s) >= 56) if cl else None
        last = max((s[-1][0] for s in [dw, co] + sp if s), default=None)
        out.append(dict(rr=rr, name=name, last=last, speed=avg(sp_all) if sp_all else None, dwell=avg(dw), dwell_yoy=yoy(dw),
                        online=avg(co), online_yoy=yoy(co), stalled=st_tot, carloads=cl_tot,
                        carloads_yoy=100 * (cl_tot / cl_prev - 1) if cl_tot and cl_prev else None))
    return out


MEASURES = [("speed", "", "Train speed by train type, mph"), ("dwell", "", "Terminal dwell by yard, hours"),
            ("cars_online", "", "Cars online by car type"), ("stalled", "Loaded", "Loaded cars not moved 48h+, by car type"),
            ("stalled", "Empty", "Empty cars not moved 48h+, by car type"), ("carloads", "Originated", "Carloads originated by commodity, per week")]


def week_no(week):
    return min(52, (datetime.date.fromisoformat(week).timetuple().tm_yday - 1) // 7 + 1)


def explorer(rr, mi, picked, view, d0, d1):
    """Rows for the slicer chart. view 'yoy': one line per year for the picked series (summed), x = week 1-52.
    view 'ts': one line per picked series, x = fractional year, every 2nd week from y0."""
    m, sub, _t = MEASURES[mi]
    vs = variables(rr, m, sub)
    picked = [v for v in picked if v in vs] or ([v for v in vs if v in ("System", "Total", "System (U.S.)", "All Trains")][:1] or vs[:1])
    if view == "yoy":
        tot = {}
        for v in picked:
            for w, val in series(rr, m, v, sub):
                if d0[:4] <= w[:4] <= d1[:4]:
                    k = (int(w[:4]), week_no(w))
                    tot[k] = tot.get(k, 0) + val
        avgmode = m in ("speed", "dwell") and len(picked) > 1
        n = len(picked)
        years = sorted({k[0] for k in tot})
        return vs, picked, [(str(y), [(wk, tot[(y, wk)] / (n if avgmode else 1)) for wk in range(1, 53) if (y, wk) in tot]) for y in years]
    keep = lambda s: [(x(w), val) for w, val in s if d0 <= w <= d1]
    pts = [(v, keep(series(rr, m, v, sub))) for v in picked]
    step = max(1, max((len(p) for _, p in pts), default=0) // 160)
    return vs, picked, [(v, p[::step]) for v, p in pts]


PRESETS = [("13w", "13 weeks"), ("52w", "52 weeks"), ("ytd", "Year to date"), ("3y", "3 years"), ("all", "All")]


def date_range(preset, d0, d1):
    """Resolve the chart window. A preset wins; otherwise the typed dates, clamped to the data. Returns (d0, d1, preset)."""
    lo = min((s[0][0] for s in _load().values() if s), default="2019-01-01")
    hi = latest_week() or datetime.date.today().isoformat()
    end = datetime.date.fromisoformat(hi)
    starts = {"13w": end - datetime.timedelta(weeks=13), "52w": end - datetime.timedelta(weeks=52), "ytd": datetime.date(end.year, 1, 1),
              "3y": end - datetime.timedelta(weeks=156), "all": datetime.date.fromisoformat(lo)}
    if preset in starts:
        return max(lo, starts[preset].isoformat()), hi, preset
    ok = lambda d: len(d) == 10 and d[4] == "-" and d[7] == "-"
    a = d0 if d0 and ok(d0) else (end - datetime.timedelta(weeks=156)).isoformat()
    b = d1 if d1 and ok(d1) else hi
    a, b = max(lo, min(a, hi)), max(lo, min(b, hi))
    if a > b:
        a, b = b, a
    return a, b, ("" if (d0 or d1) else "3y")


# ---------------- weekly refresh from STB (1.7.63) ----------------

def _get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def convert(xlsx, out):
    """STB consolidated workbook -> csv.gz with the columns the site reads (same rules as tools/ep724/build.py). Returns (values, last week)."""
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True)
    rows = wb.active.iter_rows(values_only=True)
    hdr = next(rows)
    weeks = [(j, h.date()) for j, h in enumerate(hdr) if isinstance(h, datetime.datetime) and h.year >= 2019]
    rrs = {r for r, _ in RR}
    n, last = 0, None
    with gzip.open(out, "wt", newline="") as f:
        w = csv.writer(f)
        w.writerow(["rr", "measure", "variable", "sub", "week", "value"])
        for r in rows:
            if len(r) < 6 or r[0] not in rrs or r[1] not in KEEP or LABEL[r[1]] not in str(r[3]):
                continue
            for j, d in weeks:
                v = r[j] if j < len(r) else None
                if isinstance(v, (int, float)):
                    w.writerow([r[0], KEEP[r[1]], str(r[4]).strip(), (r[5] or "").strip(), d.isoformat(), v])
                    n += 1
                    last = max(last or "", d.isoformat())
    wb.close()
    return n, last


def status():
    from . import db
    st = db.settings()
    return {"through": st.get("ep724_through") or latest_week(), "checked": st.get("ep724_checked"), "ok": st.get("ep724_ok"),
            "error": st.get("ep724_error") or "", "file": "refreshed copy" if os.path.exists(data_file()) else "build seed"}


def refresh(now_check=False):
    """Once a day (or now_check, from Admin): download STB's newest consolidated file when it is newer than what we hold. Returns a short result."""
    from . import db
    now = datetime.datetime.now(datetime.timezone.utc)
    st = db.settings()
    if not now_check and (st.get("ep724_checked") or "")[:10] == now.date().isoformat():
        return "checked today"
    db.set_setting("ep724_checked", now.isoformat(timespec="seconds"))
    try:
        m = LINK.search(_get(PAGE, 60).decode("utf-8", "replace"))
        if not m:
            raise RuntimeError("no 'EP724 Consolidated Data through' link on the STB page")
        url, through = m.group(1), m.group(2)
        if url.startswith("/"):
            url = "https://www.stb.gov" + url
        have = st.get("ep724_through") or latest_week() or ""
        if through <= have:
            db.set_setting("ep724_error", "")
            return f"up to date (through {have})"
        os.makedirs(os.path.dirname(data_file()), exist_ok=True)
        with tempfile.TemporaryDirectory(dir=os.path.dirname(data_file())) as tmp:
            x = os.path.join(tmp, "ep724.xlsx")
            with open(x, "wb") as f:
                f.write(_get(url.replace(" ", "%20"), 300))
            out = os.path.join(tmp, "ep724.csv.gz")
            n, last = convert(x, out)
            if n < 100000 or not last:  # a broken or partial workbook never replaces good data
                raise RuntimeError(f"STB file looked incomplete ({n} values)")
            os.replace(out, data_file())
        _c.clear()
        db.set_setting("ep724_through", last)
        db.set_setting("ep724_ok", now.isoformat(timespec="seconds"))
        db.set_setting("ep724_error", "")
        log.info("EP 724 refreshed: %s values through %s", n, last)
        return f"refreshed through {last}"
    except Exception as e:
        db.set_setting("ep724_error", f"{type(e).__name__}: {e}"[:300])
        log.warning("EP 724 refresh failed: %s", e)
        return f"failed: {e}"
