"""Crossing safety funding: FHWA Railway-Highway Crossings Program (23 U.S.C. 130, "Section 130") apportionments by state,
set against crossing need from the FRA crossing inventory (fra.db) and an upgrade-market estimate.
Apportionments: seed/s130_apportionment.csv.gz (state, fy, amount_usd) built from FHWA computational Table 6."""
import csv, gzip, os

from . import fra

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "s130_apportionment.csv.gz")
GATED = ("Gates", "Four-quadrant gates")
# Default installed-cost assumptions (2025 $), adjustable on the page. Ranges in FHWA/FRA guidance and state DOT bid tabs vary widely
# with track count, circuitry and road width; these are mid-range planning figures, not quotes.
COST_PASSIVE_TO_GATES = 450_000   # signs only / none -> flashing lights and gates, with circuitry
COST_FLASHERS_TO_GATES = 200_000  # add gate arms to an existing flashing-light crossing
CREDIT = ("Funding: FHWA Railway-Highway Crossings Program apportionments, FY2022-2023 actual and FY2024-2026 FHWA estimates (Nov 2021), "
          "before post-apportionment set-asides, penalties and sequestration. "
          "Crossings and collisions: FRA Highway-Rail Crossing Inventory (Form 71) and accident reports (Form 57), since 2010.")
DEF = {
    "state": ("State", "State of the crossing (FRA inventory)."),
    "public": ("Public at-grade crossings", "Open public highway-rail crossings at grade: the crossings Section 130 funds can treat."),
    "gated": ("Gated", "Public at-grade crossings with gates or four-quadrant gates."),
    "flashers": ("Flashing lights only", "Active warning without gates: candidates to add gate arms."),
    "passive": ("Passive", "Signs only or no warning device: candidates for flashing lights and gates, or closure."),
    "ungated_pct": ("Share without gates", "Public at-grade crossings without gates / all public at-grade crossings."),
    "collisions": ("Collisions since 2010", "Highway-rail collisions at the state's public at-grade crossings since 2010 (FRA Form 57)."),
    "ungated_collisions": ("Collisions at ungated crossings", "Collisions since 2010 at public at-grade crossings that have no gates today."),
    "killed": ("Deaths since 2010", "People killed in collisions at the state's public at-grade crossings since 2010."),
    "high_risk": ("High-exposure ungated", "Ungated public crossings in the top tenth nationally by exposure index (trains per day x road vehicles per day)."),
    "amount": ("Section 130 apportionment", "The state's share of the federal Railway-Highway Crossings Program for the fiscal year (set aside from HSIP: $245M a year FY2022-2026; 50% by public crossings, 50% by the old STP formula, minimum 0.5% per state). Federal share is 100% since the 2021 infrastructure law."),
    "per_ungated": ("Funding per ungated crossing", "Section 130 apportionment / ungated public at-grade crossings. Lower = less money per crossing needing treatment."),
    "per_collision": ("Funding per collision", "Section 130 apportionment / average yearly collisions since 2010 at public at-grade crossings."),
    "upgrade_cost": ("Upgrade market (estimate)", "Passive crossings x cost to install flashers and gates + flashers-only crossings x cost to add gates, at the cost assumptions shown. A planning-scale estimate of the work to gate every public at-grade crossing, not a forecast of spending."),
    "years_to_gate": ("Years of funding to gate all", "Upgrade market estimate / the latest annual apportionment: how many years of Section 130 money it would take at today's level, if all of it went to gates."),
}


def _seed():
    if not os.path.exists(SEED):
        return {}
    out = {}
    with gzip.open(SEED, "rt", newline="") as f:
        for r in csv.DictReader(f):
            try:
                out.setdefault(r["state"].upper(), {})[int(r["fy"])] = float(r["amount_usd"])
            except (KeyError, ValueError):
                pass
    return out


def years():
    return sorted({y for v in _seed().values() for y in v})


def states(fy=None, cost_passive=COST_PASSIVE_TO_GATES, cost_flash=COST_FLASHERS_TO_GATES):
    def load():
        return fra.q(f"""SELECT state, count(*) public, sum(warning IN {GATED}) gated, sum(warning = 'Flashing lights') flashers,
                         sum(warning IN ('Signs only', 'None')) passive, sum(collisions_since_2010) collisions,
                         sum(CASE WHEN warning NOT IN {GATED} THEN collisions_since_2010 END) ungated_collisions,
                         sum(killed_since_2010) killed
                         FROM fra_crossing WHERE crossing_type = 'Public' AND position = 'At Grade' AND state IS NOT NULL AND state <> ''
                         GROUP BY state""")
    rows = [dict(r) for r in fra.cached("xf_states", load)]
    risk = fra.cached("xf_risk", _high_risk)
    ap = _seed()
    fy = fy or (years()[-1] if years() else None)
    from datetime import date
    yrs = max(1, date.today().year - 2010)
    for r in rows:
        ung = (r["public"] or 0) - (r["gated"] or 0)
        r["ungated"] = ung
        r["ungated_pct"] = 100 * ung / r["public"] if r["public"] else None
        r["high_risk"] = risk.get(r["state"], 0)
        r["upgrade_cost"] = (r["passive"] or 0) * cost_passive + (r["flashers"] or 0) * cost_flash
        a = ap.get(r["state"], {}).get(fy) if fy else None
        r["amount"] = a
        r["per_ungated"] = a / ung if a and ung else None
        r["per_collision"] = a / ((r["collisions"] or 0) / yrs) if a and r["collisions"] else None
        r["years_to_gate"] = r["upgrade_cost"] / a if a else None
    return sorted(rows, key=lambda r: -(r["ungated_collisions"] or 0))


def _high_risk():
    """Ungated public at-grade crossings in the national top 10% by exposure index, per state."""
    n = fra.q("SELECT count(*) n FROM fra_crossing WHERE crossing_type = 'Public' AND position = 'At Grade' AND exposure_index > 0", one=True)["n"] or 0
    if not n:
        return {}
    cut = fra.q("SELECT exposure_index FROM fra_crossing WHERE crossing_type = 'Public' AND position = 'At Grade' AND exposure_index > 0 "
                "ORDER BY exposure_index DESC LIMIT 1 OFFSET ?", (max(0, n // 10 - 1),), one=True)["exposure_index"]
    return {r["state"]: r["n"] for r in fra.q(f"""SELECT state, count(*) n FROM fra_crossing WHERE crossing_type = 'Public' AND position = 'At Grade'
                                                AND warning NOT IN {GATED} AND exposure_index >= ? GROUP BY state""", (cut,))}


def national(rows):
    t = {k: sum((r.get(k) or 0) for r in rows) for k in ("public", "gated", "flashers", "passive", "ungated", "collisions", "ungated_collisions",
                                                          "killed", "high_risk", "upgrade_cost", "amount")}
    t["ungated_pct"] = 100 * t["ungated"] / t["public"] if t["public"] else None
    t["years_to_gate"] = t["upgrade_cost"] / t["amount"] if t["amount"] else None
    return t


def canada():
    try:
        return fra.q("""SELECT province, count(*) crossings, sum(coalesce(warning, '') NOT LIKE '%Gate%') ungated, sum(accidents) accidents,
                        sum(fatalities) fatalities FROM tc_crossing WHERE coalesce(access, 'Public') LIKE 'Public%' GROUP BY province ORDER BY 2 DESC""")
    except Exception:
        return []


GRANTS = [
    ("Railroad Crossing Elimination Program (FRA)", "https://railroads.dot.gov/grants-loans/competitive-discretionary-grant-programs/railroad-crossing-elimination-grant-program",
     "Competitive grants for grade separations, closures and crossing improvements; about $600M a year under the 2021 infrastructure law."),
    ("CRISI (FRA)", "https://railroads.dot.gov/grants-loans/competitive-discretionary-grant-programs/consolidated-rail-infrastructure-and-safety-2",
     "Consolidated Rail Infrastructure and Safety Improvements: rail safety and capital projects, including crossing safety."),
    ("Highway Safety Improvement Program (FHWA)", "https://highways.dot.gov/safety/hsip",
     "The parent program Section 130 is set aside from; states can also fund crossing projects from regular HSIP money."),
    ("Railway-Highway Crossings Program overview (FHWA)", "https://highways.dot.gov/safety/hsip/xings/railway-highway-crossing-program-overview",
     "Program rules, eligible work and state annual reports."),
]
