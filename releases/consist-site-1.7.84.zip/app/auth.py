"""Accounts: password hashing, the signed session cookie, CSRF, plan entitlements, one-time tokens."""
import datetime
import logging
import secrets
import time

import bcrypt
from fastapi import HTTPException, Request

from . import db

_attempts = {}  # ip -> [timestamps] for login throttling


def hash_pw(pw):
    return bcrypt.hashpw(pw.encode()[:72], bcrypt.gensalt()).decode()


def check_pw(pw, h):
    try:
        return bool(h) and bcrypt.checkpw(pw.encode()[:72], h.encode())
    except ValueError:
        return False


def throttled(ip, limit=10):
    t = time.time()
    hits = [s for s in _attempts.get(ip, []) if t - s < 600]
    _attempts[ip] = hits
    return len(hits) >= limit


def spend(request: Request, kind, limit):
    """Counts one use of a form that sends email or creates rows (sign-up, reset, contact) and says whether this IP is over the limit for ten minutes."""
    key = f"{kind}:{client_ip(request)}"
    if throttled(key, limit):
        return True
    note_failure(key)
    return False


def client_ip(request: Request):
    return request.client.host if request.client else "?"


def note_failure(ip):
    _attempts.setdefault(ip, []).append(time.time())


def csrf_token(request: Request):
    tok = request.session.get("csrf")
    if not tok:
        tok = secrets.token_urlsafe(24)
        request.session["csrf"] = tok
    return tok


def check_csrf(request: Request, token):
    if not token or token != request.session.get("csrf"):
        raise HTTPException(400, "Your session expired. Reload the page and try again.")


# Features a free-trial member never gets, whatever the plan: CSV/Excel downloads, CRM export and API keys.
TRIAL_LOCKED = {"export", "crm_export", "api"}


class User(dict):
    """A user row plus its effective plan (team members inherit the owner's plan)."""
    __getattr__ = dict.get

    def can(self, feature):
        if feature not in (self.plan or {}).get("features", []):
            return False
        if self.trialing and feature in TRIAL_LOCKED:  # free trial: no downloads, extracts or API (app/trial.py)
            return False
        from . import lens
        s = lens.current()
        return not (s.basic and feature in lens.LENS_FEATURES and feature not in s.free_features)

    def can_plan(self, feature):
        """The plan's entitlement, ignoring the lens being viewed."""
        return feature in (self.plan or {}).get("features", [])

    @property
    def bids(self):
        """The plan includes bid monitoring (the bid feed, bid alerts and bid briefs). A fleet-only plan has neither bid feature."""
        return self.is_admin or self.can_plan("bids_recent") or self.can_plan("bids_full")

    @property
    def trialing(self):
        """On a free trial (the team owner's Stripe subscription is 'trialing'). Admins and admin previews never are."""
        return (self.owner or self).get("sub_status") == "trialing" and self.get("role") != "admin"

    @property
    def is_admin(self):
        return self.get("role") == "admin"


def load_user(uid):
    r = db.q("SELECT * FROM user WHERE id = ?", (uid,), one=True)
    if not r or r["status"] != "active":
        return None
    u = User(dict(r))
    owner = u
    if u.team_owner_id:
        o = db.q("SELECT * FROM user WHERE id = ?", (u.team_owner_id,), one=True)
        if o:
            owner = dict(o)
    plan_id = owner["plan_id"] if billing_ok(owner) else "free"
    u["plan"] = db.get_plan(plan_id)
    u["owner"] = owner
    if (owner.get("sub_status") or "") == "trialing":  # free trial: a smaller analyst quota (Admin > Settings > Billing: trial_ai)
        try:
            cap = int(db.settings().get("trial_ai") or 10)
        except ValueError:
            cap = 10
        u["plan"] = dict(u["plan"], ai_quota=min(u["plan"].get("ai_quota") or 0, cap))
    return u


def billing_ok(u):
    """A paid plan counts while the subscription is active, trialing, past due (grace), or set by an admin/demo."""
    if u["plan_id"] == "free":
        return True
    if (u.get("sub_status") or "") == "ambassador":  # free Ambassador access (app/ambassadors.py), until its end date if one is set
        return not u.get("comp_until") or u["comp_until"] >= db.now()[:10]
    return (u.get("sub_status") or "") in ("active", "trialing", "past_due", "manual", "demo")


def pw_mark(u):
    """A short fingerprint of the password hash kept in the session, so changing or resetting a password signs out every other session."""
    return (u.get("pw_hash") or "")[-16:]


def view_as(u, session, path):
    """Admin 'View as plan' (Admin dashboard, or the banner on every page): outside /admin an admin who picked a plan sees the
    site exactly as a member on that plan does, with no admin bypasses. Only the admin's own session changes; their account,
    subscription and Stripe are untouched. Under /admin they stay a full admin, so they can always switch back."""
    pid = (session or {}).get("view_plan")
    if not (u and pid and u.get("role") == "admin") or path.startswith("/admin"):
        return u
    p = db.get_plan(pid)
    if p["id"] != pid:
        return u
    u = User(u)
    u.update(plan=p, role="user", viewing_as=p, real_admin=True)
    return u


def current_user(request: Request):
    uid = request.session.get("uid")
    u = load_user(uid) if uid else None
    u = view_as(u, request.session, request.url.path) if u else None
    if u:
        pv = request.session.get("pv")
        if pv is None:  # sessions from before this check: adopt the current mark
            request.session["pv"] = pw_mark(u)
        elif pv != pw_mark(u):
            request.session.clear()
            return None
    return u


def _here(request: Request):
    """The current path and query, URL-encoded for a ?next= parameter, so sign-in returns to the same tab and filters."""
    from urllib.parse import quote
    q = request.url.query
    return quote(request.url.path + ("?" + q if q else ""), safe="/")


def require_user(request: Request):
    u = current_user(request)
    if not u:
        raise HTTPException(303, headers={"Location": f"/login?next={_here(request)}"})
    return u


def require_admin(request: Request):
    u = current_user(request)
    if not u or not u.is_admin:  # the portal is invisible to visitors and members: admins sign in on the normal page
        raise HTTPException(404, "Not Found")
    return u


def login(request: Request, u):
    request.session.clear()
    request.session["uid"] = u["id"]
    r = db.q("SELECT pw_hash FROM user WHERE id = ?", (u["id"],), one=True)
    request.session["pv"] = pw_mark(dict(r) if r else {})
    db.x("UPDATE user SET prev_login = last_login, last_login = ? WHERE id = ?", (db.now(), u["id"]))


def delete_account(uid):
    """Remove a member and everything that belongs to them: searches, watches, analyst history, lists, notes, contacts and
    preferences. Team members of a deleted owner keep their own logins and drop to Starter. Returns the Stripe outcome:
    'cancelled', 'none' (no subscription) or 'failed' (cancel it in the Stripe dashboard)."""
    r = db.q("SELECT * FROM user WHERE id = ?", (uid,), one=True)
    if not r:
        return "none"
    try:
        from . import billing
        stripe_out = billing.cancel_all(dict(r))
    except Exception:
        logging.getLogger("consist").exception("stripe cancel for user %s", uid)
        stripe_out = "failed"
    for t in ("saved_search", "watch", "analyst_job", "source_request", "user_pref"):
        db.x(f"DELETE FROM {t} WHERE user_id = ?", (uid,))
    for t in ("fleet_list_item",):
        db.x(f"DELETE FROM {t} WHERE list_id IN (SELECT id FROM fleet_list WHERE owner_id = ?)", (uid,))
    for t in ("fleet_list", "account_note", "contact"):
        db.x(f"DELETE FROM {t} WHERE owner_id = ?", (uid,))
    db.x("DELETE FROM token WHERE user_id = ?", (uid,))
    db.x("UPDATE user SET team_owner_id = NULL, plan_id = 'free' WHERE team_owner_id = ?", (uid,))
    db.x("DELETE FROM user WHERE id = ?", (uid,))
    return stripe_out


def create_user(email, pw, name="", company="", role="user", plan_id="free", team_owner_id=None):
    uid = db.x("INSERT INTO user (email, name, company, pw_hash, role, plan_id, created, team_owner_id) VALUES (?,?,?,?,?,?,?,?)",
               (email.strip().lower(), name.strip(), company.strip(), hash_pw(pw) if pw else None, role, plan_id, db.now(), team_owner_id))
    return uid


def make_token(kind, user_id=None, email=None, hours=48):
    tok = secrets.token_urlsafe(32)
    exp = (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=hours)).isoformat()
    db.x("INSERT INTO token (token, kind, user_id, email, expires) VALUES (?,?,?,?,?)", (tok, kind, user_id, email, exp))
    return tok


def use_token(tok, kind, consume=True):
    r = db.q("SELECT * FROM token WHERE token = ? AND kind = ? AND used = 0", (tok, kind), one=True)
    if not r or r["expires"] < db.now():
        return None
    if consume:
        db.x("UPDATE token SET used = 1 WHERE token = ?", (tok,))
    return dict(r)


def ai_allowed(u):
    """AI (and anything else that costs money per use) is for paid plans only; Starter gets an upgrade prompt."""
    return (u.plan or {}).get("id", "free") != "free"


def ai_left(u):
    if not ai_allowed(u):
        return 0
    month = datetime.date.today().strftime("%Y-%m")
    owner = u.owner or u
    used = owner.get("ai_used", 0) if owner.get("ai_month") == month else 0
    return max(0, (u.plan or {}).get("ai_quota", 0) - used)


def ai_charge(u):
    month = datetime.date.today().strftime("%Y-%m")
    owner_id = (u.owner or u)["id"]
    db.x("UPDATE user SET ai_used = CASE WHEN ai_month = ? THEN ai_used + 1 ELSE 1 END, ai_month = ? WHERE id = ?",
         (month, month, owner_id))
