"""Cost escalation calculator + index forecasts with backtested accuracy (escalation.py).
Same tool twice: /rail/escalation (freight presets, Freight portal access) and /app/escalation (passenger presets, plan feature fleet_detail)."""
from fastapi import APIRouter, Depends, Request

from . import auth, escalation as E
from .main import render
from .routes_app import csv_response
from .routes_rail import gate

rail = APIRouter(prefix="/rail")
app = APIRouter(prefix="/app")


def _num(v, d=None):
    try:
        return float(v) if v not in (None, "") else d
    except ValueError:
        return d


def _yx(i):
    y, m = divmod(i, 12)
    return y + m / 12


def _ctx(request, seg):
    q = request.query_params
    mode = q.get("mode") if q.get("mode") in E.MODES else ("aar" if seg == "freight" else "bls")
    presets = E.presets(seg, mode) or E.presets(seg, "bls")
    pid = q.get("preset") or presets[0][0]
    pre = next((p for p in presets if p[0] == pid), presets[0])
    avail = E.available(seg, mode)
    custom = any(k.startswith("w_") for k in q)
    basket = {k: _num(q.get("w_" + k), 0) for k in avail} if custom else {k: w for k, w in pre[3].items() if k in avail}
    basket = {k: w for k, w in basket.items() if w and w > 0}
    lastp = max(E.last(k)[0] for k in E.available(seg))
    base = E.parse_period(q.get("base", "")) or lastp - 60
    target = E.parse_period(q.get("target", "")) or lastp + 12
    target = min(target, lastp + E.MAXF)
    lag = int(_num(q.get("lag"), 0) or 0)
    fixed = max(0.0, min(100.0, _num(q.get("fixed"), 0) or 0))
    floor, cap = _num(q.get("floor")), _num(q.get("cap"))
    amount = _num(q.get("amount"))
    terms = dict(lag=lag, fixed=fixed, floor=floor, cap=cap)
    res = E.escalate(basket, base, target, **terms) if basket else None
    sched = E.schedule(basket, base, base + 12, target, **terms) if basket else []
    # comparator (Justin, 2026-11-03): the same contract terms under a second index approach, from either mode
    choices = E.all_presets(seg)
    cid = q.get("cmp") or ""
    cpre = next(((m, p) for m, p in choices if p[0] == cid), None)
    cmp = None
    if cpre and basket:
        cb = cpre[1][3]
        cres = E.escalate(cb, base, target, **terms)
        if cres and "error" not in cres and res and "error" not in res:
            step = max(1, (target - base) // 60)
            months = list(range(base, target + 1, step)) + ([target] if (target - base) % step else [])
            def path(b):
                out = []
                for i in months:
                    r = E.escalate(b, base, i, **terms)
                    if r and "error" not in r:
                        out.append((_yx(i), round(100 * (r["factor"] - 1), 2)))
                return out
            a_name = "Your basket" if custom else pre[1]
            from .charts import line
            ch_cmp = line([(a_name, path(basket)), (cpre[1][1], path(cb))], title="Cumulative price change, %",
                          xtip=lambda x: E.plabel(int(round(x * 12))))
            csched = {s["i"]: s for s in E.schedule(cb, base, base + 12, target, **terms)}
            cmp = dict(mode=cpre[0], pre=cpre[1], res=cres, name=a_name, ch=ch_cmp,
                       rows=[dict(label=s["label"], a=s["change"], b=csched[s["i"]]["change"] if s["i"] in csched else None,
                                  fc=s["forecast"] or (s["i"] in csched and csched[s["i"]]["forecast"])) for s in sched])
    # index explorer, with a year range (Justin, 2026-11-03)
    allk = E.available(seg) + [x for x in E.available(seg, "aar") if x not in E.available(seg)]
    k = q.get("k") or (max(basket, key=basket.get) if basket else avail[0])
    k = k if k in allk else avail[0]
    f = E.forecast(k)
    s_all = E.series(k)
    y_first = (s_all[0][0] // 12) if s_all else lastp // 12 - 10
    y_last = (f["points"][-1]["i"] // 12) if f["points"] else lastp // 12
    y0 = int(_num(q.get("from"), max(y_first, lastp // 12 - 10)))
    y1 = int(_num(q.get("to"), y_last))
    y0, y1 = max(y_first, min(y0, y_last)), max(y_first, min(y1, y_last))
    if y1 < y0:
        y0, y1 = y1, y0
    hist = [(x, v) for x, v in s_all if y0 * 12 <= x < (y1 + 1) * 12]
    pts = [p for p in f["points"] if p["i"] < (y1 + 1) * 12]
    if not hist and s_all:
        hist = s_all[-1:]
    ch = fc_chart(E.SERIES[k][0], hist, pts) if hist else ""
    summ = E.describe(k, hist, pts)
    bt = f.get("bt") or {}
    meth = E._methods(E.SERIES[k][2])
    acc = [dict(m=m, name=meth[m][0], desc=meth[m][1], best=m == f.get("method"), hs=bt.get("methods", {}).get(m, {})) for m in meth]
    return dict(seg=seg, mode=mode, presets=presets, pre=pre, custom=custom, avail=avail, allk=allk, basket=basket, base=base, target=target, lag=lag,
                fixed=fixed, floor=floor, cap=cap, amount=amount, res=res, sched=sched, k=k, f=f, ch=ch, acc=acc, E=E,
                choices=choices, cmp=cmp, cid=cid, y0=y0, y1=y1, summ=summ, years=list(range(y_first, y_last + 1)),
                lastp=lastp, plabel=E.plabel, rail=seg == "freight", root="/rail/escalation" if seg == "freight" else "/app/escalation")


def fc_chart(title, hist, pts, w=720, h=260):
    """Actual line, forecast line and a shaded 90% range; y axis fitted to the data (indexes don't start at zero)."""
    import html
    xs = [x for x, _ in hist] + [p["i"] for p in pts]
    ys = [v for _, v in hist] + [p["lo"] for p in pts] + [p["hi"] for p in pts]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    from .charts import autorange
    y0, y1 = autorange(y0, y1)  # fitted to the data on round gridlines, like every other chart
    L, R, T, B = 52, 12, 12, 26
    sx = lambda x: L + (x - x0) / ((x1 - x0) or 1) * (w - L - R)
    sy = lambda y: T + (1 - (y - y0) / (y1 - y0)) * (h - T - B)
    o = [f'<svg viewBox="0 0 {w} {h}" class="chart" role="img" aria-label="{html.escape(title)}">']
    for i in range(5):
        v = y0 + (y1 - y0) * i / 4
        o.append(f'<line x1="{L}" x2="{w - R}" y1="{sy(v):.1f}" y2="{sy(v):.1f}" class="grid"/><text x="{L - 6}" y="{sy(v) + 4:.1f}" class="ax" text-anchor="end">{v:,.{3 if y1 < 10 else 0}f}</text>')
    for yr in range(x0 // 12 + 1, x1 // 12 + 1, max(1, (x1 - x0) // 96)):
        o.append(f'<text x="{sx(yr * 12):.1f}" y="{h - 8}" class="ax" text-anchor="middle">{yr}</text>')
    if pts:
        band = [(hist[-1][0], hist[-1][1])] + [(p["i"], p["hi"]) for p in pts] + [(p["i"], p["lo"]) for p in reversed(pts)]
        o.append('<path d="' + " ".join(f"{'M' if j == 0 else 'L'}{sx(x):.1f},{sy(y):.1f}" for j, (x, y) in enumerate(band)) + 'Z" fill="#2f6fde" opacity=".14"/>')
        f = [(hist[-1][0], hist[-1][1])] + [(p["i"], p["mid"]) for p in pts]
        o.append('<path d="' + " ".join(f"{'M' if j == 0 else 'L'}{sx(x):.1f},{sy(y):.1f}" for j, (x, y) in enumerate(f)) + '" fill="none" stroke="#2f6fde" stroke-width="2.25" stroke-dasharray="6 4"/>')
    o.append('<path d="' + " ".join(f"{'M' if j == 0 else 'L'}{sx(x):.1f},{sy(y):.1f}" for j, (x, y) in enumerate(hist)) + '" fill="none" stroke="#1d2b3a" stroke-width="2.25"/>')
    o.append("</svg>")
    return "".join(o) + '<div class="legend"><span><i style="background:#1d2b3a"></i>Actual</span><span><i style="background:#2f6fde"></i>Forecast (dashed) and 90% range (shaded)</span></div>'


def _page(request, u, seg):
    c = _ctx(request, seg)
    if request.query_params.get("export") == "schedule":
        return csv_response("consist-escalation", ["period", "factor", "change", "forecast"],
                            [dict(period=s["label"], factor=round(s["factor"], 5), change=round(s["change"], 3), forecast=s["forecast"]) for s in c["sched"]])
    if request.query_params.get("export") == "forecast":
        return csv_response("consist-forecast-" + c["k"].lower(), ["period", "forecast", "low_90", "high_90"],
                            [dict(period=p["label"], forecast=round(p["mid"], 3), low_90=round(p["lo"], 3), high_90=round(p["hi"], 3)) for p in c["f"]["points"]])
    return render(request, "escalation.html", user=u, **c)


@rail.get("/escalation")
def rail_page(request: Request):
    u, r = gate(request, "Cost escalation and forecasts")
    if r:
        return r
    return _page(request, u, "freight")


@app.get("/escalation")
def app_page(request: Request, u=Depends(auth.require_user)):
    if not (u.is_admin or u.can("fleet_detail")):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Cost escalation and forecasts")
    return _page(request, u, "passenger")


@app.get("/cost-indexes")
def app_cost_indexes(request: Request, u=Depends(auth.require_user)):
    """The freight portal's RCAF and AAR fuel index page, in the passenger and transit app (Justin, 2026-11-03)."""
    if not (u.is_admin or u.can("fleet_detail")):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Rail cost and fuel indexes")
    from .routes_shortline import cost_indexes
    return cost_indexes(request, u, False)


# Safety rates in the passenger and transit app (Justin, 2026-11-03): the freight portal's page with lens buttons, opening on All passenger.
@app.get("/safety")
def app_safety(request: Request, u=Depends(auth.require_user)):
    if not (u.is_admin or u.can("fleet_detail")):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Safety rates")
    from .routes_rail import safety_page
    return safety_page(request, u, False)


@app.get("/safety/{op}")
def app_safety_operator(request: Request, op: str, u=Depends(auth.require_user)):
    if not (u.is_admin or u.can("fleet_detail")):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Safety rates")
    from .routes_rail import safety_operator_page
    return safety_operator_page(request, u, op, False)
