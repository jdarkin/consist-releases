"""AI-drafted Ambassador invites (Admin > Ambassadors > Draft with AI, Justin 2026-11-04).

The admin pastes the person's LinkedIn profile text or uploads LinkedIn's "Save to PDF" export. The site never fetches LinkedIn:
LinkedIn forbids automated access, and Consist doesn't get around bot blocks. The URL is kept only as a reference on the invite."""
import base64
import json
import logging

import anthropic

from . import analyst, config, db, richtext

log = logging.getLogger("consist.invitedraft")

MAX_PDF = 8 * 1024 * 1024
MAX_TEXT = 30000

PRODUCT = """What Consist covers (US and Canada rail; pick only what fits this person):
- Bid Catcher: alerts on rail procurement from US and Canadian agencies and railroads (rolling stock, signaling, PTC, wayside, crossings,
  consulting, engineering, maintenance), plus upcoming work and forecast views that show what's planned before an RFP posts.
- Passenger and transit: fleet data for every system (counts, models, builders, build and rebuild dates, subsystems such as HVAC, doors,
  trucks, vehicle control, passenger information), duty cycles, operating cost per unit of service and cost trends, contract awards.
- Freight portal: Class I, regional and roughly 620 short line railroads; STB weekly service metrics (dwell, train speed, cars online),
  R-1 financials, locomotives, freight car and tank car fleets, wayside and signaling, FRA safety and crossing data.
- Funding: CRISI, Railroad Crossing Elimination, RAISE, INFRA, FTA programs, and Section 130 crossing funding by state.
- Costs: RCAF, the AAR fuel index, STB fuel surcharges, cost escalation indexes and forecasts.
- Supplier Intelligence: supplier directory, segment league tables and supplier financials (Wabtec, Siemens, Alstom, Hitachi, Stadler,
  Knorr-Bremse and others).
- An AI analyst that answers plain-language questions across the data; saved searches, alerts and exports."""

SYSTEM = """You write personal invitations for {site} (consist-na.com), a market intelligence platform for the US and Canadian rail
industry covering passenger, transit and freight. The sender is inviting one person to be a {site} Ambassador: full access to the
{plan} plan{until}, in exchange for honest feedback.

{product}

Write a short, warm, specific email from the sender to this person, based on their profile:
- Open with "Dear <first name>," (or "Hi <first name>," if the profile suggests a less formal tone). Use their real first name.
- One or two sentences that show you read their profile: their current role and company, and one concrete detail of their background.
  Never invent facts. If something is uncertain, leave it out.
- Then 3 to 5 bullet points, each naming a part of {site} and saying in one sentence how it helps in THEIR job. Start each bullet with a
  short bold phrase.
- Then one sentence asking for their candid feedback, and one saying the button below sets up their account in about two minutes.
- Close with "Best regards," and the sender's name on the next line ({sender}).
- Under 220 words in the body. Plain, direct business English. US and Canada wording only (never Mexico).
- Spam filters: never use the words "free", "no cost", "no credit card", "payment", "invitation", "invite", "offer", "exclusive",
  "limited time" or "act now", no ALL CAPS, no exclamation marks, no prices. Say "full access" and "Ambassador" instead.
- Do not include the setup link or a URL; the email adds a "Set up your account" button after your text.

Return JSON: "subject" (under 60 characters, personal, e.g. "<First name>, a Consist Ambassador seat for you"; avoid the spam words
above), "first_name", "full_name", "headline" (their current role and company in a few words), and "html": the email body as simple
HTML using only <p>, <ul>, <li>, <b>, <i>, <br>."""

SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {"type": "string"}, "first_name": {"type": "string"}, "full_name": {"type": "string"},
        "headline": {"type": "string"}, "html": {"type": "string"},
    },
    "required": ["subject", "first_name", "full_name", "headline", "html"],
    "additionalProperties": False,
}


class DraftError(Exception):
    pass


def available():
    return bool(config.ANTHROPIC_API_KEY)


def draft(profile_text="", pdf=b"", url="", context="", plan_name="", until="", sender=""):
    """Returns dict(subject, html, first_name, full_name, headline, cost)."""
    profile_text = (profile_text or "").strip()
    if not profile_text and not pdf:
        raise DraftError("Paste their profile text or upload LinkedIn's PDF of the profile. The site can't read LinkedIn pages itself.")
    if pdf and (len(pdf) > MAX_PDF or not pdf.startswith(b"%PDF")):
        raise DraftError("That file isn't a PDF under 8 MB. On LinkedIn, open the profile, click More, then Save to PDF.")
    site = db.settings().get("site_name", "Consist")
    system = SYSTEM.format(site=site, plan=plan_name or "top", until=f" through {until}" if until else "", product=PRODUCT,
                           sender=sender or "the sender")
    content = []
    if pdf:
        content.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                                        "data": base64.b64encode(pdf).decode()}})
    text = "Write the Ambassador email for this person."
    if url:
        text += f"\nLinkedIn URL (for reference only): {url}"
    if context.strip():
        text += f"\nSender's note on how they know this person or what to mention: {context.strip()[:2000]}"
    if profile_text:
        text += f"\n\nTheir profile, pasted by the sender:\n<profile>\n{profile_text[:MAX_TEXT]}\n</profile>"
    content.append({"type": "text", "text": text})
    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY or None)
    try:
        resp = client.beta.messages.create(
            model=config.ANALYST_MODEL, max_tokens=16000, system=system, messages=[{"role": "user", "content": content}],
            output_config={"effort": "medium", "format": {"type": "json_schema", "schema": SCHEMA}},
            betas=["server-side-fallback-2026-07-01"], fallbacks="default")
    except anthropic.AuthenticationError:
        raise DraftError("The AI key in Admin > Settings isn't working.")
    except anthropic.RateLimitError:
        raise DraftError("The AI service is busy. Try again in a minute.")
    except anthropic.APIStatusError as e:
        log.warning("invite draft failed: %s", e)
        raise DraftError("The AI service returned an error. Try again, or paste less text.")
    except anthropic.APIConnectionError:
        raise DraftError("Couldn't reach the AI service. Try again.")
    if resp.stop_reason == "refusal":
        raise DraftError("The AI declined this one. Try trimming the pasted text to their headline, About and experience.")
    if resp.stop_reason == "max_tokens":
        raise DraftError("The draft was cut off. Try again.")
    try:
        out = json.loads(next(b.text for b in resp.content if b.type == "text"))
    except (StopIteration, ValueError):
        raise DraftError("The AI reply couldn't be read. Try again.")
    out["html"] = richtext.clean(out.get("html", ""))
    out["cost"] = round(analyst._cost(resp.usage), 4)
    if not out["html"]:
        raise DraftError("The AI returned an empty draft. Try again.")
    return out
