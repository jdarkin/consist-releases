"""Server-side admin commands, for when nobody can sign in:
    docker exec -it consist-site python -m app.cli set-password you@example.com     # prompts for the new password
    docker exec -it consist-site python -m app.cli make-admin you@example.com       # creates the account if needed
    docker exec consist-site python -m app.cli reset-2fa you@example.com          # turns off two-factor sign-in (lost phone)
    docker exec consist-site python -m app.cli backup-check                       # emails support if backups are stale (daily cron)
    docker exec consist-site python -m app.cli list-admins
    docker exec consist-site python -m app.cli clean-test-data                      # removes what tests/smoke.py creates
    docker exec -i -w /srv consist-site python -m app.cli seo-import - < suggestions.json   # SEO suggestions queue (or a file path)"""
import getpass
import sys

from . import auth, db


def _password():
    pw = getpass.getpass("New password (12+ characters): ")
    if len(pw) < 12 or pw != getpass.getpass("Again: "):
        sys.exit("Passwords must match and be at least 12 characters.")
    return pw


def main(argv):
    db.init()
    cmd, email = (argv + ["", ""])[:2]
    email = email.strip().lower()
    if cmd == "list-admins":
        for r in db.q("SELECT email, status, last_login FROM user WHERE role = 'admin' ORDER BY id"):
            print(f"{r['email']}  {r['status']}  last sign-in {r['last_login'] or 'never'}")
        return
    if cmd == "clean-test-data":
        clean_test_data()
        return
    if cmd == "seo-import":
        import json
        from . import seosuggest
        src = argv[1] if len(argv) > 1 else "-"
        try:
            raw = sys.stdin.read() if src == "-" else open(src, encoding="utf-8").read()
            items = json.loads(raw or "[]")
        except (OSError, ValueError) as e:
            sys.exit(f"seo-import: could not read suggestions JSON ({e}).")
        added, skipped, errors = seosuggest.import_items(items)
        print(f"seo-import: {added} added, {skipped} skipped as duplicates, {len(errors)} rejected.")
        for e in errors[:20]:
            print("  " + e)
        return
    if cmd == "backup-check":
        from . import backups
        print(backups.check_and_alert())
        return
    if cmd == "reset-2fa" and "@" in email:
        from . import twofa
        r = db.q("SELECT id FROM user WHERE email = ?", (email,), one=True)
        if not r:
            sys.exit(f"No account for {email}.")
        twofa.disable(r["id"])
        db.audit("2fa_reset", "cli", r["id"], "server")
        print(f"Two-factor sign-in turned off for {email}. If it's required for them, they set it up again at the next sign-in.")
        return
    if cmd not in ("set-password", "make-admin") or "@" not in email:
        sys.exit(__doc__)
    r = db.q("SELECT id FROM user WHERE email = ?", (email,), one=True)
    if cmd == "set-password":
        if not r:
            sys.exit(f"No account for {email}.")
        db.x("UPDATE user SET pw_hash = ?, status = 'active' WHERE id = ?", (auth.hash_pw(_password()), r["id"]))
        db.audit("cli_set_password", email, r["id"], "server")
        print(f"Password set for {email}.")
    else:
        if r:
            db.x("UPDATE user SET role = 'admin', status = 'active' WHERE id = ?", (r["id"],))
        else:
            auth.create_user(email, _password(), name="Admin", role="admin", plan_id="team")
            db.x("UPDATE user SET sub_status = 'manual' WHERE email = ?", (email,))
        db.audit("cli_make_admin", email, None, "server")
        print(f"{email} is an admin. Sign in at /login; the Admin link appears after sign-in.")


def clean_test_data():
    """Undo what tests/smoke.py and tests/stub_analyst.py leave behind on a real server."""
    import json
    users = [r["id"] for r in db.q("SELECT id FROM user WHERE email GLOB 'test[0-9]*@example.com' OR email GLOB 'ai[0-9]*@example.com' "
                                   "OR email = 'colleague@example.com'")]
    for uid in users:
        for t in ("saved_search", "watch", "analyst_job", "source_request", "user_pref"):
            db.x(f"DELETE FROM {t} WHERE user_id = ?", (uid,))
        db.x("DELETE FROM fleet_list_item WHERE list_id IN (SELECT id FROM fleet_list WHERE owner_id = ?)", (uid,))
        for t in ("fleet_list", "account_note", "contact"):
            db.x(f"DELETE FROM {t} WHERE owner_id = ?", (uid,))
        db.x("DELETE FROM user WHERE team_owner_id = ?", (uid,))
        db.x("DELETE FROM user WHERE id = ?", (uid,))
    db.x("DELETE FROM token WHERE email = 'colleague@example.com'")
    db.x("DELETE FROM page WHERE slug = 'test-guide'")
    db.x("DELETE FROM announcement WHERE text = 'Launch week banner'")
    db.x("DELETE FROM lead WHERE email = 'lead@example.com'")
    db.x("DELETE FROM setting WHERE key = 'compare:smoke-rival'")
    pro = next(p for p in db.DEFAULT_PLANS if p["id"] == "pro")
    if db.q("SELECT 1 FROM plan WHERE id = 'pro' AND blurb = 'For BD teams'", one=True):
        db.x("UPDATE plan SET blurb = ?, bullets = ?, price_month = ?, price_year = ? WHERE id = 'pro'",
             (pro["blurb"], json.dumps(pro["bullets"]), pro["price_month"], pro["price_year"]))
    print(f"Removed {len(users)} test accounts and the smoke-test page, banner, lead and plan text.")


if __name__ == "__main__":
    main(sys.argv[1:])
