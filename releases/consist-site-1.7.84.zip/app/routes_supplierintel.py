"""Supplier intelligence pages (supplierintel.py): /app/supplier-intel (passenger, plan feature fleet_detail),
/rail/supplier-intel (freight portal access), and Admin > Supplier financials for figures from foreign annual reports."""
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import RedirectResponse

from . import auth, supplierintel as S
from .main import render
from .routes_app import csv_response
from .routes_rail import gate

app = APIRouter(prefix="/app")
rail = APIRouter(prefix="/rail")
admin = APIRouter(prefix="/admin")
COLS = ["name", "owner", "country", "listing", "year", "revenue", "rev_basis", "growth", "margin", "backlog", "ib", "ib_share", "awards", "award_usd", "award_share"]


def _home(request, u, portal, seg):
    segs = S.segments(portal)
    keys = [s[0] for s in segs]
    seg = seg if seg in keys else keys[0]
    rows = S.league(seg)
    if request.query_params.get("export"):
        return csv_response("consist-suppliers-" + seg, ["id"] + COLS, rows)
    return render(request, "supplierintel.html", user=u, S=S, segs=segs, seg=seg, rows=rows, rail=portal == "freight",
                  root="/rail/supplier-intel" if portal == "freight" else "/app/supplier-intel")


def _profile(request, u, portal, sid):
    if sid not in S.ENT:
        raise HTTPException(404)
    e = S.ENT[sid]
    f = S.fin(sid)
    ys = sorted({y for m in f.values() for y in m})[-10:]
    ib, ibt = S.installed_base()
    aw, _, awt = S.awards()
    return render(request, "supplierintel_profile.html", user=u, S=S, e=e, f=f, ys=ys, s=S.summary(sid), ib=ib.get(sid), ibt=ibt,
                  aw=aw.get(sid, (0, 0.0)), awt=awt, awards=S.award_list(sid), fleets=S.fleets(sid), rail=portal == "freight",
                  root="/rail/supplier-intel" if portal == "freight" else "/app/supplier-intel")


def _app_ok(u):
    return u.is_admin or u.can("fleet_detail")


@app.get("/supplier-intel")
def app_home(request: Request, seg: str = "", u=Depends(auth.require_user)):
    if not _app_ok(u):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Supplier intelligence")
    return _home(request, u, "passenger", seg)


@app.get("/supplier-intel/{sid}")
def app_profile(request: Request, sid: str, u=Depends(auth.require_user)):
    if not _app_ok(u):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Supplier intelligence")
    return _profile(request, u, "passenger", sid)


@rail.get("/supplier-intel")
def rail_home(request: Request, seg: str = ""):
    u, r = gate(request, "Supplier intelligence")
    return r or _home(request, u, "freight", seg)


@rail.get("/supplier-intel/{sid}")
def rail_profile(request: Request, sid: str):
    u, r = gate(request, "Supplier intelligence")
    return r or _profile(request, u, "freight", sid)


A = Depends(auth.require_admin)


@admin.get("/supplier-fin")
def admin_fin(request: Request, u=A):
    sid = request.query_params.get("sid", "")
    sid = sid if sid in S.ENT else ""
    return render(request, "admin/supplier_fin.html", user=u, S=S, rows=S.manual(), csrf=auth.csrf_token(request), cov=S.coverage(),
                  sid=sid, figs=S.figures(sid) if sid else [])


@admin.post("/supplier-fin")
def admin_fin_save(request: Request, csrf: str = Form(""), supplier_id: str = Form(""), year: int = Form(0), metric: str = Form(""),
                   value: str = Form(""), currency: str = Form("USD"), usd_rate: str = Form(""), source: str = Form(""), delete: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if supplier_id not in S.ENT or metric not in S.METRICS or not (1990 < year < 2100):
        raise HTTPException(400, "Pick a supplier, metric and year")
    if delete:
        S.delete_manual(supplier_id, year, metric)
    else:
        try:
            v = float(value.replace(",", ""))
            rate = float(usd_rate) if usd_rate else (1.0 if currency.upper() == "USD" else None)
        except ValueError:
            raise HTTPException(400, "Value and USD rate must be numbers")
        if rate is None:
            raise HTTPException(400, "Enter the USD rate for a non-USD figure (the year's average rate)")
        S.save_manual(supplier_id, year, metric, v, currency.upper()[:3], rate, source[:300], u.email)
    return RedirectResponse("/admin/supplier-fin", status_code=303)


# ---------------- supplier directory (supplierdir.py): freight portal view and Admin reconciliation ----------------

@rail.get("/suppliers")
def rail_directory(request: Request):
    u, r = gate(request, "Supplier directory")
    if r:
        return r
    from . import supplierdir as SD
    q = dict(request.query_params)
    drows = SD.directory(q)
    if q.get("export") and (u.is_admin or u.can("export") or u.can_plan("rail")):  # paid plans only
        cols = ["name", "website", "country", "sources", "segments", "status", "listing", "revenue", "rev_year", "margin", "apta_active",
                "apta_ordered", "apta_agencies", "fleets", "cars", "awards", "award_usd"]
        return csv_response("consist-supplier-directory", cols, drows)
    return render(request, "app/suppliers.html", user=u, rail=True, SD=SD, drows=drows, q=q, rows=[], covered=0, n_fleets=0, cars_cov=0, cars_all=0)


@admin.get("/supplier-directory")
def admin_dir(request: Request, u=A):
    from . import supplierdir as SD
    return render(request, "admin/supplier_dir.html", user=u, SD=SD, last=SD.last_runs(), changes=SD.changes(), n=len(SD.rows()),
                  csrf=auth.csrf_token(request), msg=request.query_params.get("msg", ""))


@admin.post("/supplier-directory/rssi")
def admin_dir_rssi(request: Request, csrf: str = Form(""), u=A):
    from . import supplierdir as SD
    auth.check_csrf(request, csrf)
    try:
        r = SD.reconcile_rssi()
        msg = f"RSSI checked: {r['members']} members, {r['added']} added, {r['removed']} left."
    except Exception as e:
        msg = f"RSSI check failed: {e}"
    from urllib.parse import quote
    return RedirectResponse("/admin/supplier-directory?msg=" + quote(msg), status_code=303)


@admin.post("/supplier-directory/apta")
async def admin_dir_apta(request: Request, u=A):
    from . import supplierdir as SD
    from urllib.parse import quote
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    up = form.get("file")
    try:
        data = await up.read()
        if len(data) > 60 * 1024 * 1024:
            raise ValueError("File is larger than 60 MB")
        if data[:2] == b"PK" and not (up.filename or "").lower().endswith(".zip"):
            fleet = SD.read_xlsx_fleet(data)
        elif data[:2] == b"PK":  # APTA ships a zip holding the xlsx
            import io, zipfile
            z = zipfile.ZipFile(io.BytesIO(data))
            name = next(n for n in z.namelist() if n.lower().endswith(".xlsx"))
            fleet = SD.read_xlsx_fleet(z.read(name))
        else:
            raise ValueError("Upload the APTA Vehicle Database .xlsx or the .zip it comes in")
        r = SD.reconcile_apta(fleet, form.get("edition", ""))
        msg = f"APTA file read: {r['rows']} rail fleet rows, {r['builders']} builders, {r['changed']} changed. Only derived counts were kept."
    except Exception as e:
        msg = f"APTA file not loaded: {e}"
    return RedirectResponse("/admin/supplier-directory?msg=" + quote(msg), status_code=303)



# ---------------- Recent in the news (supplier_news.py, GDELT, free) ----------------

def _news(request, u, portal, sid):
    from . import supplier_news as N
    if sid not in S.ENT:
        raise HTTPException(404)
    e = S.ENT[sid]
    w = request.query_params.get("w", "30d")
    meta = {}
    try:
        items, err = N.search(e, w, meta=meta), None
    except Exception:
        items, err = [], "busy"
    root = "/rail/supplier-intel" if portal == "freight" else "/app/supplier-intel"
    return render(request, "supplier_news.html", user=u, e=e, items=items, err=err, stale=meta.get("stale"), src=meta.get("source"), w=w if w in N.WINDOWS else "30d", N=N, rail=portal == "freight", root=root)


@app.get("/supplier-intel/{sid}/news")
def app_news(request: Request, sid: str, u=Depends(auth.require_user)):
    if not _app_ok(u):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Supplier intelligence")
    return _news(request, u, "passenger", sid)


@rail.get("/supplier-intel/{sid}/news")
def rail_news(request: Request, sid: str):
    u, r = gate(request, "Supplier intelligence")
    return r or _news(request, u, "freight", sid)
