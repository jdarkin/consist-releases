"""Stripe subscriptions: Checkout for sign-up and upgrades, the Customer Portal for card and plan changes, and a webhook that keeps
each user's plan in step with Stripe. Without a Stripe key the site runs in demo billing mode (admin setting 'billing_demo')."""
import json
import logging

import stripe

from . import config, db

log = logging.getLogger("consist")


def _d(o):
    """Stripe objects (stripe-python 15+) are not dicts: turn them into plain nested dicts so .get() works."""
    return o.to_dict() if hasattr(o, "to_dict") else o

ACTIVE = ("active", "trialing", "past_due")


def client():
    return stripe.StripeClient(config.STRIPE_SECRET_KEY)


def demo_mode():
    return not config.STRIPE_ENABLED and db.settings().get("billing_demo") == "1"


def _customer(c, user):
    if user.get("stripe_customer_id"):
        return user["stripe_customer_id"]
    cust = c.v1.customers.create(params={"email": user["email"], "name": user.get("name") or user["email"],
                                         "metadata": {"user_id": str(user["id"]), "company": user.get("company") or ""}})
    db.x("UPDATE user SET stripe_customer_id = ? WHERE id = ?", (cust.id, user["id"]))
    return cust.id


def checkout_url(user, plan, interval):
    """Returns the Stripe Checkout URL for a plan, or None when the plan has no Stripe price for that interval."""
    price = plan.get("stripe_price_year" if interval == "year" else "stripe_price_month")
    if not price:
        return None
    from . import ga
    ga.event(user["id"], "begin_checkout", currency="USD", plan=plan["id"], interval=interval)
    c = client()
    sub = {"metadata": {"user_id": str(user["id"]), "plan_id": plan["id"]}}
    extra = {}
    from . import trial
    days = trial.days_for(user, plan)
    if days:  # no card needed; if none is added by the end, Stripe cancels and the member drops to Starter
        sub["trial_period_days"] = days
        sub["trial_settings"] = {"end_behavior": {"missing_payment_method": "cancel"}}
        extra["payment_method_collection"] = "if_required"
    from . import referrals
    ref_coupon = referrals.coupon_for(user)
    if ref_coupon:  # referred member: % off the first paid month (promo codes can't be combined with a set discount)
        extra["discounts"] = [{"coupon": ref_coupon}]
    sess = c.v1.checkout.sessions.create(params={**extra,
        "mode": "subscription", "customer": _customer(c, user), "client_reference_id": str(user["id"]),
        "line_items": [{"price": price, "quantity": 1}], **({} if ref_coupon else {"allow_promotion_codes": True}), "billing_address_collection": "auto",
        "subscription_data": sub, "metadata": {"user_id": str(user["id"]), "plan_id": plan["id"]},
        "success_url": f"{config.SITE_URL}/app/account?upgraded=1&session_id={{CHECKOUT_SESSION_ID}}",
        "cancel_url": f"{config.SITE_URL}/pricing?canceled=1"})
    return sess.url


def portal_url(user):
    c = client()
    sess = c.v1.billing_portal.sessions.create(params={"customer": _customer(c, user), "return_url": f"{config.SITE_URL}/app/account"})
    return sess.url


def credit_month_cents(user):
    """One month of the user's plan price, in cents. Free and contact-only plans get the cheapest paid monthly price,
    so the credit is there when they upgrade."""
    p = db.q("SELECT price_month FROM plan WHERE id = ?", (user.get("plan_id") or "free",), one=True)
    if p and p["price_month"]:
        return p["price_month"]
    r = db.q("SELECT min(price_month) m FROM plan WHERE active = 1 AND contact_only = 0 AND price_month > 0", one=True)
    return r["m"] if r and r["m"] else 0


def credit_balance(user, cents, why):
    """Adds a credit to the user's Stripe customer balance; Stripe takes it off their next invoices. Returns the transaction id."""
    c = client()
    t = c.v1.customers.balance_transactions.create(_customer(c, user), params={
        "amount": -int(cents), "currency": "usd", "description": why[:350], "metadata": {"user_id": str(user["id"])}})
    return t.id


def plan_for_price(price_id):
    r = db.q("SELECT id FROM plan WHERE stripe_price_month = ? OR stripe_price_year = ?", (price_id, price_id), one=True)
    return r["id"] if r else None


def apply_subscription(sub):
    """Copies a Stripe subscription onto the user who owns its customer."""
    sub = _d(sub)
    cust = sub["customer"]
    u = db.q("SELECT * FROM user WHERE stripe_customer_id = ?", (cust,), one=True)
    if not u:
        uid = (sub.get("metadata") or {}).get("user_id")
        u = db.q("SELECT * FROM user WHERE id = ?", (uid,), one=True) if uid else None
        if not u:
            return None
        db.x("UPDATE user SET stripe_customer_id = ? WHERE id = ?", (cust, u["id"]))
    items = (sub.get("items") or {}).get("data") or []
    price = items[0]["price"] if items else {}
    plan_id = plan_for_price(price.get("id")) or (sub.get("metadata") or {}).get("plan_id") or u["plan_id"]
    status = sub["status"]
    period_end = items[0].get("current_period_end") if items else sub.get("current_period_end")
    import datetime
    pe = datetime.datetime.fromtimestamp(period_end, datetime.timezone.utc).date().isoformat() if period_end else None
    interval = (price.get("recurring") or {}).get("interval")
    if status in ("canceled", "incomplete_expired", "unpaid"):
        plan_id = "free"
    db.x("UPDATE user SET plan_id = ?, sub_status = ?, stripe_subscription_id = ?, period_end = ?, interval = ? WHERE id = ?",
         (plan_id, status, sub["id"], pe, interval, u["id"]))
    if not u["trial_used"]:  # any subscription, trial or paid, uses up the one free trial
        db.x("UPDATE user SET trial_used = ? WHERE id = ?", (db.now()[:10], u["id"]))
    return u["id"]


def sync_checkout(user, session_id):
    """Back from Stripe Checkout: copy the new subscription onto the member straight away, so the plan (and the subscription id
    that cancelling needs) never depends on the webhook arriving first. Only for a session this member started."""
    c = client()
    s = _d(c.v1.checkout.sessions.retrieve(session_id))
    if str(s.get("client_reference_id") or "") != str(user["id"]) or not s.get("subscription"):
        return None
    from . import ga  # GA4 drops a repeat purchase with the same transaction_id, so a reload of the return page is harmless
    ga.event(user["id"], "purchase", transaction_id=session_id, value=round((s.get("amount_total") or 0) / 100, 2),
             currency=(s.get("currency") or "usd").upper())
    return apply_subscription(c.v1.subscriptions.retrieve(s["subscription"]))


LIVE = ("active", "trialing", "past_due", "unpaid", "incomplete", "paused")


def refresh(user):
    """Re-read the member's subscription from Stripe (the Account page does this, e.g. on the way back from the billing portal),
    so a cancel or plan change shows even when a webhook was missed."""
    if not user.get("stripe_customer_id"):
        return None
    subs = [_d(s) for s in client().v1.subscriptions.list(params={"customer": user["stripe_customer_id"], "status": "all", "limit": 10}).data]
    if not subs:
        return None
    live = [s for s in subs if s["status"] in LIVE]
    return apply_subscription(max(live or subs, key=lambda s: s.get("created") or 0))


def cancel_all(user):
    """Cancel every live Stripe subscription a member has: the one on file plus any other on their Stripe customer (a missed
    webhook can leave the one on file blank). Returns 'cancelled', 'none' or 'failed'."""
    if not config.STRIPE_ENABLED:
        return "none"
    c = client()
    ids, failed = [], False
    if user.get("stripe_subscription_id"):
        ids.append(user["stripe_subscription_id"])
    if user.get("stripe_customer_id"):
        try:
            for s in c.v1.subscriptions.list(params={"customer": user["stripe_customer_id"], "status": "all", "limit": 100}).data:
                if s["status"] in LIVE and s["id"] not in ids:
                    ids.append(s["id"])
        except Exception:
            log.exception("stripe list subscriptions for user %s", user.get("id"))
            failed = True
    done = 0
    for sid in ids:
        try:
            if c.v1.subscriptions.retrieve(sid)["status"] in LIVE:
                c.v1.subscriptions.cancel(sid)
                done += 1
        except Exception:
            log.exception("stripe cancel %s for user %s", sid, user.get("id"))
            failed = True
    return "failed" if failed else ("cancelled" if done else "none")


def handle_webhook(payload, sig):
    event = _d(stripe.Webhook.construct_event(payload, sig, config.STRIPE_WEBHOOK_SECRET))
    etype, obj = event["type"], event["data"]["object"]
    if db.q("SELECT 1 FROM billing_event WHERE event_id = ?", (event["id"],), one=True):
        return "duplicate"
    uid, amount = None, None
    if etype == "checkout.session.completed" and obj.get("subscription"):
        sub = client().v1.subscriptions.retrieve(obj["subscription"])
        uid = apply_subscription(sub)
    elif etype in ("customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"):
        uid = apply_subscription(obj)
    elif etype in ("invoice.paid", "invoice.payment_failed"):
        r = db.q("SELECT id FROM user WHERE stripe_customer_id = ?", (obj.get("customer"),), one=True)
        uid = r["id"] if r else None
        amount = obj.get("amount_paid") if etype == "invoice.paid" else obj.get("amount_due")
        if etype == "invoice.payment_failed" and uid:
            db.x("UPDATE user SET sub_status = 'past_due' WHERE id = ?", (uid,))
    if uid is None and obj.get("customer"):
        r = db.q("SELECT id FROM user WHERE stripe_customer_id = ?", (obj.get("customer"),), one=True)
        uid = r["id"] if r else None
    from . import syslog
    syslog.stripe_event(etype, obj, uid)  # declines, failed payments, abandoned checkouts -> Admin > Diagnostics
    db.x("INSERT OR IGNORE INTO billing_event (ts, event_id, type, user_id, amount, detail) VALUES (?,?,?,?,?,?)",
         (db.now(), event["id"], etype, uid, amount, json.dumps({"object": obj.get("id")})))
    return etype


def create_prices():
    """Creates a Stripe product and monthly/yearly prices for every paid plan that has none yet. Returns a list of what it did."""
    c = client()
    done = []
    for p in db.plans(active_only=False):
        if p["contact_only"] or not p["price_month"]:
            continue
        if p["stripe_price_month"] and p["stripe_price_year"]:
            continue
        prod = c.v1.products.create(params={"name": f"{db.settings().get('site_name', 'Consist')} {p['name']}",
                                            "metadata": {"plan_id": p["id"]}})
        pm = c.v1.prices.create(params={"product": prod.id, "currency": "usd", "unit_amount": p["price_month"],
                                        "recurring": {"interval": "month"}, "metadata": {"plan_id": p["id"]}})
        py = c.v1.prices.create(params={"product": prod.id, "currency": "usd", "unit_amount": p["price_year"],
                                        "recurring": {"interval": "year"}, "metadata": {"plan_id": p["id"]}})
        db.x("UPDATE plan SET stripe_price_month = ?, stripe_price_year = ? WHERE id = ?", (pm.id, py.id, p["id"]))
        done.append(f"{p['name']}: {pm.id} / {py.id}")
    return done


def mrr(where="1=1", args=()):
    """Monthly recurring revenue from paying users, in cents (yearly plans count as 1/12). where/args narrow the users (alias u)."""
    total, by_plan = 0, {}
    for r in db.q("SELECT u.plan_id, u.interval, u.sub_status, p.price_month, p.price_year FROM user u JOIN plan p ON p.id = u.plan_id "
                  f"WHERE u.team_owner_id IS NULL AND u.plan_id != 'free' AND u.sub_status IN ('active','past_due') AND {where}", args):
        v = (r["price_year"] // 12) if r["interval"] == "year" else r["price_month"]
        total += v
        by_plan[r["plan_id"]] = by_plan.get(r["plan_id"], 0) + v
    return total, by_plan
