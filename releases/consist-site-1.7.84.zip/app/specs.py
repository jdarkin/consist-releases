"""Public specification links for vehicle models (seed/model_spec_links.csv, built by the Data thread 2026-11-06): mostly Wikipedia
articles, each checked to exist. References only; Consist's own figures come from the sources on the methodology page."""
import csv, functools, os

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "model_spec_links.csv")


@functools.lru_cache(maxsize=1)
def _table():
    exact, by_model = {}, {}
    try:
        with open(SEED, newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                if not (r.get("spec_url") or "").startswith("https://"):
                    continue
                v = {"url": r["spec_url"], "title": r.get("spec_title") or "",
                     "label": "Fleet and specifications (system page)" if r.get("page_kind") == "system" else "Specifications"}
                m = (r.get("model") or "").strip().lower()
                exact[((r.get("manufacturer") or "").strip().lower(), m)] = v
                by_model.setdefault(m, []).append(v)
    except OSError:
        pass
    # model-only fallback when every row with that model name points to the same page
    loose = {m: vs[0] for m, vs in by_model.items() if len({v["url"] for v in vs}) == 1}
    return exact, loose


def link(manufacturer, model):
    """{url, label, title} for a model, or None when there is no reliable page."""
    if not model:
        return None
    exact, loose = _table()
    m = str(model).strip().lower()
    return exact.get(((manufacturer or "").strip().lower(), m)) or loose.get(m)
