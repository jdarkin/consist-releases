"""Consumables and component-overhaul estimates per fleet and operator (brake pads, wheels, HVAC, doors, trucks...). Every figure is a
low-mid-high range per year from duty data x cited intervals x award prices. Dollars are award prices (parts or service contracts) in
nominal award-year dollars, without in-house labor. Read from fleet.db (fleet_consumable_estimate / operator_consumable_estimate) when
those tables exist, else from the CSVs shipped in seed/consumables (built by fleet-db/tools/consumables/model.py)."""
import csv
import os

from . import db

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "consumables")
LABELS = {
    "brake_pad": "Brake pads and shoes", "wheel_replace": "Wheel replacement", "wheel_reprofile": "Wheel reprofiling",
    "coupler_overhaul": "Coupler overhaul", "battery_replace": "Battery replacement", "brake_overhaul": "Brake unit overhaul",
    "door_operator_overhaul": "Door operator overhaul", "door_seal_edge": "Door seals and edges", "hvac_filter": "HVAC filters",
    "hvac_overhaul": "HVAC overhaul", "truck_overhaul": "Truck overhaul", "traction_motor_overhaul": "Traction motor overhaul",
    "pantograph_overhaul": "Pantograph overhaul", "pantograph_strip": "Pantograph carbon strips", "collector_shoe_overhaul": "Collector shoe overhaul",
}
BUCKETS = {"consumable": "Consumables (opex)", "component_overhaul": "Component overhauls (often capitalized)"}
NUM = ("qty_active", "miles_per_car", "events_per_car_low", "events_per_car_high", "fleet_events_low", "fleet_events_mid",
       "fleet_events_high", "usd_low", "usd_mid", "usd_high")
_cache = {}


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _csv(name):
    path = os.path.join(SEED, name)
    try:
        key = os.stat(path).st_mtime
    except OSError:
        return []
    if _cache.get(name, (None,))[0] != key:
        with open(path, newline="") as f:
            _cache[name] = (key, list(csv.DictReader(f)))
    return _cache[name][1]


def _table(name):
    try:
        return [dict(r) for r in db.fq(f"SELECT * FROM {name}")]
    except Exception:  # table not loaded into fleet.db yet
        return None


def _clean(r):
    r = dict(r)
    for k in NUM:
        if k in r:
            r[k] = _f(r[k])
    r["label"] = LABELS.get(r.get("component"), (r.get("component") or "").replace("_", " "))
    return r


def for_fleet(fid):
    rows = _table(f"fleet_consumable_estimate WHERE fleet_id = {int(fid)}")
    if rows is None:
        rows = [r for r in _csv("estimate_fleet_component.csv") if str(r["fleet_id"]) == str(fid)]
    return _shape([_clean(r) for r in rows])


def for_operator(oid, fleet_ids=None):
    """Operator roll-up; fleet_ids limits it to fleets the viewer can see (freight is filtered out by the fleet list)."""
    rows = _table("operator_consumable_estimate WHERE operator_id = '%s'" % str(oid).replace("'", "''"))
    if rows is None:
        rows = [r for r in _csv("estimate_operator_component.csv") if r["operator_id"] == oid]
    fl = _table("fleet_consumable_estimate WHERE operator_id = '%s'" % str(oid).replace("'", "''"))
    if fl is None:
        fl = [r for r in _csv("estimate_fleet_component.csv") if r["operator_id"] == oid]
    bucket = {r["component"]: r["bucket"] for r in fl}  # the roll-up has no bucket column
    rows = [dict(r, bucket=r.get("bucket") or bucket.get(r["component"])) for r in rows]
    out = _shape([_clean(r) for r in rows])
    if out:
        fl = [_clean(r) for r in fl if fleet_ids is None or str(r["fleet_id"]) in {str(i) for i in fleet_ids}]
        out["due"] = sorted([r for r in fl if r.get("next_due") and r.get("bucket") == "component_overhaul"],
                            key=lambda r: (r["next_due"], -(r["usd_mid"] or 0)))
    return out


def _shape(rows):
    if not rows:
        return {}
    rows.sort(key=lambda r: -(r["usd_mid"] or 0))
    top = max((r["usd_high"] or 0) for r in rows) or 1
    for r in rows:  # whisker geometry, as % of the card's widest high value
        lo, mid, hi = (r["usd_low"] or 0), (r["usd_mid"] or 0), (r["usd_high"] or 0)
        r["w"] = {"l": round(100 * lo / top, 1), "w": max(round(100 * (hi - lo) / top, 1), 0.6), "m": round(100 * mid / top, 1)}
    groups = []
    for b, lab in BUCKETS.items():
        g = [r for r in rows if r.get("bucket") == b]
        if g:
            groups.append({"bucket": b, "label": lab, "rows": g, "low": sum(r["usd_low"] or 0 for r in g),
                           "mid": sum(r["usd_mid"] or 0 for r in g), "high": sum(r["usd_high"] or 0 for r in g)})
    return {"rows": rows, "groups": groups, "due": sorted([r for r in rows if r.get("next_due") and r.get("bucket") == "component_overhaul"],
                                                          key=lambda r: r["next_due"]),
            "low": sum(r["usd_low"] or 0 for r in rows), "mid": sum(r["usd_mid"] or 0 for r in rows), "high": sum(r["usd_high"] or 0 for r in rows)}


def sources(rows):
    """The cited interval (norms) and award-price rows behind the components shown, matched on component and vehicle class."""
    norms, prices = _csv("norms.csv"), _csv("prices.csv")
    out, seen = [], set()
    for r in rows:
        comp, cls = r.get("component"), r.get("vehicle_class")
        for kind, table in (("Interval", norms), ("Price", prices)):
            hit = [x for x in table if x["component"] == comp and x["vehicle_class"] == cls] or \
                  [x for x in table if x["component"] == comp and x["vehicle_class"] == "*"]
            for x in hit[:1]:
                key = (kind, comp, x["vehicle_class"])
                if key in seen:
                    continue
                seen.add(key)
                urls = [u.strip() for u in (x.get("source_url") or "").split("|") if u.strip().startswith("http")]
                out.append({"kind": kind, "label": LABELS.get(comp, comp), "basis": x.get("basis") or "", "grade": x.get("confidence") or "",
                            "urls": urls})
    return out
