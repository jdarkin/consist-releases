"""Site-wide search (1.7.24, Justin 2026-11-11): one box in the header of every app page. Enter searches the whole site and
groups the hits by where they live (pages, operators, fleets, builders and models, subsystem suppliers, bids and RFPs, awards,
supplier directory). Each group follows the member's page access: locked pages are left out, preview pages show a few hits and an
upgrade note. Bid search never matches Amtrak description text and shows Amtrak notices restricted (data.NO_REDISTRIBUTE)."""
from . import data, intel, pages

PREVIEW_HITS = 3


def _access(u, path):
    return "full" if getattr(u, "is_admin", False) else pages.access(u.plan, path)


def _cap(rows, acc, n):
    return rows[:PREVIEW_HITS] if acc == "preview" else rows[:n]


def search(q, u, limit=10):
    q = (q or "").strip()[:100]
    if not q:
        return None
    words = [w for w in q.lower().split() if w]
    out = {"q": q, "groups": []}

    # Site pages whose name matches
    pg = []
    for grp, path, label in pages.PAGES:
        if all(w in (label + " " + grp).lower() for w in words):
            acc = _access(u, path)
            pg.append({"path": path, "label": label, "group": grp, "locked": acc == "none"})
    out["pages"] = pg

    # Installed base (operators, fleets, builders, models, subsystem suppliers)
    ib = intel.search_installed(q, limit=limit) if _access(u, "/app/search") != "none" else None
    if ib:
        if _access(u, "/app/operators") == "none":
            ib["operators"], ib["n_operators"] = [], 0
        fa = _access(u, "/app/fleets")
        if fa == "none":
            ib["fleets"], ib["n_fleets"] = [], 0
        elif fa == "preview":
            ib["fleets"] = ib["fleets"][:PREVIEW_HITS]
        ib["fleets_preview"] = fa == "preview"
    out["ib"] = ib

    # Bids and RFPs (open and closed; Amtrak text never searched or shown)
    ba = _access(u, "/app/bids")
    bids, nb = [], 0
    if ba != "none" and getattr(u, "bids", True):
        try:
            bids, nb = data.notices({"q": q, "status": "all", "min_rel": "0", "sort": "new"}, per=limit)
        except Exception:
            bids, nb = [], 0
    out["bids"], out["n_bids"], out["bids_preview"] = _cap(bids, ba, limit), nb, ba == "preview"

    # Contract awards
    aa = _access(u, "/app/awards")
    aw = []
    if aa != "none":
        try:
            aw = data.awards({"q": q}, limit=limit)
        except Exception:
            aw = []
    out["awards"], out["awards_preview"] = _cap(aw, aa, limit), aa == "preview"

    # Vehicle orders: the order book (1.7.39; Justin 11-12 couldn't find the MTA M9A order). Follows /app/work access.
    oa = _access(u, "/app/work")
    vo = []
    if oa != "none":
        try:
            vo = [p for p in data.procurements() if data.qhit(words, p.get("model"), p.get("manufacturer"), p.get("operator_id"),
                                                                 (p.get("operator_id") or "").replace(";", " "), p.get("notes"), p.get("award_date"))]
        except Exception:
            vo = []
    out["orders"], out["n_orders"], out["orders_preview"] = _cap(vo, oa, limit), len(vo), oa == "preview"

    # Supplier directory
    sa = _access(u, "/app/suppliers")
    sd = []
    if sa != "none":
        try:
            from . import supplierdir
            sd = [d for d in supplierdir.directory({}) if data.qhit(words, d.get("name"), d.get("apta_names"))]
        except Exception:
            sd = []
    out["suppliers"], out["n_suppliers"], out["suppliers_preview"] = _cap(sd, sa, limit), len(sd), sa == "preview"

    out["total"] = (len(pg) + (ib["n_operators"] + ib["n_fleets"] + len(ib["builders"]) + ib["n_models"] + ib["n_parts"] if ib else 0)
                    + nb + len(aw) + len(sd) + len(vo))
    return out
