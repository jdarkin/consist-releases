// Consist front end: mobile menu, theme toggle, filter auto-submit, pricing interval toggle, analyst job polling.
(function () {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));

  // mobile menu
  const head = $(".site-head");
  $(".menu-btn")?.addEventListener("click", () => head.classList.toggle("open"));

  // theme toggle (remembered per browser)
  try {
    const t = localStorage.getItem("theme");
    if (t) document.documentElement.dataset.theme = t;
  } catch (e) {}
  $$("[data-theme-toggle]").forEach((b) => b.addEventListener("click", () => {
    const dark = matchMedia("(prefers-color-scheme: dark)").matches;
    const cur = document.documentElement.dataset.theme || (dark ? "dark" : "light");
    const next = cur === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("theme", next); } catch (e) {}
  }));

  // filters submit on change
  $$("form[data-autosubmit] select, form[data-autosubmit] input[type=checkbox]").forEach((s) => s.addEventListener("change", () => s.form.requestSubmit()));

  // buttons show a spinner while their form submits
  $$("form[data-busy]").forEach((f) => f.addEventListener("submit", () => {
    const b = $("button[type=submit],button:not([type])", f);
    if (b) { b.disabled = true; b.insertAdjacentHTML("afterbegin", '<span class="spin"></span>'); }
  }));

  // pricing month/year toggle
  const tg = $("[data-interval-toggle]");
  if (tg) {
    $$("button", tg).forEach((b) => b.addEventListener("click", () => {
      const iv = b.dataset.iv;
      $$("button", tg).forEach((x) => x.setAttribute("aria-pressed", x === b ? "true" : "false"));
      $$("[data-price-month]").forEach((p) => { p.hidden = iv !== "month"; });
      $$("[data-price-year]").forEach((p) => { p.hidden = iv !== "year"; });
      $$("[data-plan-link]").forEach((a) => { a.href = a.href.replace(/interval=\w+/, "interval=" + iv); });
    }));
  }

  // pricing product line switch (#passenger, #freight, #master). Without JS every line shows, one after the other.
  const lt = $("[data-line-toggle]");
  if (lt) {
    const lines = $$("button", lt).map((b) => b.dataset.line);
    const show = (ln, push) => {
      if (!lines.includes(ln)) ln = lines[0];
      $$("button", lt).forEach((x) => x.setAttribute("aria-pressed", x.dataset.line === ln ? "true" : "false"));
      $$("[data-line-panel]").forEach((p) => { p.hidden = p.dataset.linePanel !== ln; });
      if (push) history.replaceState(null, "", "#" + ln);
    };
    $$("button", lt).forEach((b) => b.addEventListener("click", () => show(b.dataset.line, true)));
    $$("[data-line-link]").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); show(a.dataset.lineLink, true); lt.scrollIntoView({ behavior: "smooth" }); }));
    const h = location.hash.slice(1);
    show(h === "compare" ? "passenger" : h, false);
    window.addEventListener("hashchange", () => show(location.hash.slice(1), false));
  }

  // Getting started tour (/app?tour=1): steps through the app menu, one highlighted item at a time (app/guide.py).
  const tdata = $("#tour-steps"), tbox = $(".tour");
  if (tdata && tbox) {
    const steps = JSON.parse(tdata.textContent || "[]");
    let i = 0, hi = null;
    const done = (forGood = true) => {  // Skip closes for now; Finish and "Don't show again" turn the welcome and tour off for good
      tbox.hidden = true; hi && hi.classList.remove("tour-hi");
      const f = $("#tour-done");
      if (f) { const fd = new FormData(f); if (!forGood) fd.set("later", "1"); fetch(f.action, { method: "POST", body: fd, credentials: "same-origin" }).catch(() => {}); }
      history.replaceState(null, "", location.pathname);
    };
    const show = () => {
      const st = steps[i]; if (!st) return done();
      hi && hi.classList.remove("tour-hi");
      hi = $(`[data-tour="${st.k}"]`);
      if (hi && hi.offsetParent !== null) { hi.classList.add("tour-hi"); hi.scrollIntoView({ block: "nearest" }); }
      $(".tour-n", tbox).textContent = `${i + 1} of ${steps.length}`;
      $("#tour-t").textContent = st.t; $(".tour-s", tbox).textContent = st.s;
      const ex = $(".tour-ex", tbox);
      if (ex) { ex.replaceChildren(...(st.ex || []).map((q) => Object.assign(document.createElement("li"), { textContent: q }))); ex.hidden = !(st.ex || []).length; }
      $(".tour-lock", tbox).hidden = !!st.ok;
      $("[data-tour-prev]", tbox).disabled = i === 0;
      $("[data-tour-next]", tbox).textContent = i === steps.length - 1 ? "Finish" : "Next";
      const r = hi && hi.offsetParent !== null ? hi.getBoundingClientRect() : null;
      tbox.classList.toggle("float", !!r);
      if (r) {
        const w = tbox.offsetWidth, h = tbox.offsetHeight;
        if (r.right + 14 + w < innerWidth) {  // beside a menu item
          tbox.style.left = (r.right + 14) + "px"; tbox.style.top = Math.min(Math.max(8, r.top - 8), innerHeight - h - 8) + "px";
        } else {  // under a wide element such as the market bar
          tbox.style.left = Math.max(8, Math.min(r.left, innerWidth - w - 8)) + "px";
          tbox.style.top = (r.bottom + 10 + h < innerHeight ? r.bottom + 10 : Math.max(8, r.top - h - 10)) + "px";  // above an element at the bottom
        }
      }
      else { tbox.style.top = ""; tbox.style.left = ""; }
    };
    $("[data-tour-next]", tbox).addEventListener("click", () => { i++; show(); });
    $("[data-tour-prev]", tbox).addEventListener("click", () => { i = Math.max(0, i - 1); show(); });
    $("[data-tour-x]", tbox).addEventListener("click", () => done(false));
    const off = $("[data-tour-off]", tbox); if (off) off.addEventListener("click", () => done(true));
    document.addEventListener("keydown", (e) => { if (!tbox.hidden && e.key === "Escape") done(false); });
    tbox.hidden = false; show();
  }

  // suggestion chips fill the analyst box
  $$("[data-chip]").forEach((c) => c.addEventListener("click", () => {
    const ta = $("#question");
    if (ta) { ta.value = c.dataset.chip; ta.focus(); }
  }));

  // analyst job polling
  const box = $("[data-job]");
  if (box) {
    const id = box.dataset.job;
    const steps = $(".progress", box);
    let n = 0;
    const tick = async () => {
      n++;
      let j;
      try {
        const r = await fetch(`/app/analyst/job/${id}`, { headers: { Accept: "application/json" } });
        j = await r.json();
      } catch (e) { setTimeout(tick, 3000); return; }
      if (j.steps && steps) {
        const done = j.status !== "running";
        steps.innerHTML = ['<div class="st"><span class="dot"></span>Reading your question</div>']
          .concat(j.steps.map((s, i) => `<div class="st${!done && i === j.steps.length - 1 ? " cur" : ""}"><span class="dot"></span>${s.replace(/</g, "&lt;")}</div>`))
          .concat(done ? [] : ['<div class="st cur"><span class="dot"></span>Thinking…</div>']).join("");
      }
      if (j.status === "done") { box.innerHTML = j.html; box.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
      if (j.status === "error") { box.innerHTML = `<div class="alert bad">${(j.error || "Something went wrong.").replace(/</g, "&lt;")}</div>`; return; }
      if (n < 200) setTimeout(tick, n < 10 ? 1500 : 3000);
    };
    tick();
  }

  // auto-hide flash toasts
  $$(".toast").forEach((t) => setTimeout(() => t.remove(), 6000));
})();

// Admin portal: slide-out navigation on small screens, and close the account menu on outside click.
(() => {
  const adm = document.querySelector("[data-adm]");
  if (!adm) return;
  document.querySelector("[data-adm-open]")?.addEventListener("click", () => adm.classList.add("nav-open"));
  document.querySelector("[data-adm-close]")?.addEventListener("click", () => adm.classList.remove("nav-open"));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") adm.classList.remove("nav-open"); });
  document.addEventListener("click", (e) => {
    document.querySelectorAll(".adm-me[open]").forEach((d) => { if (!d.contains(e.target)) d.removeAttribute("open"); });
  });
})();

// Tables marked data-sort: click a column header to sort its rows up or down in the browser.
// Cells sort by data-v when set (dates), else their text; numbers, money ($1.2M, $45k) and percents sort as numbers; blanks go last.
(() => {
  const MULT = { k: 1e3, M: 1e6, B: 1e9 };
  const val = (td) => {
    if (!td) return null;
    const raw = (td.dataset.v ?? td.textContent).trim();
    if (!raw || raw === "—" || raw === "–" || raw === "…") return null;
    const m = raw.replace(/,/g, "").match(/^([-+−]?)(?:US|C|CA)?\$?(\d*\.?\d+)\s*([kMB%])?(?![\d-])/);
    if (m) return (m[1] && m[1] !== "+" ? -1 : 1) * parseFloat(m[2]) * (MULT[m[3]] || 1);
    return raw.toLowerCase();
  };
  const cmp = (a, b) => (typeof a === "number" && typeof b === "number") ? a - b : String(a).localeCompare(String(b), undefined, { numeric: true });
  // Every data table sorts (Justin, 2026-11-03), not only those marked data-sort; opt out with data-nosort on the table.
  document.querySelectorAll("table").forEach((table) => {
    if (table.hasAttribute("data-nosort") || table.closest(".chart, svg")) return;
    const body = table.tBodies[0];
    if (!body || body.rows.length < 2) return;
    const cols = Math.max(...Array.from(body.rows).slice(0, 5).map((r) => r.cells.length));
    const headRows = Array.from(table.tHead?.rows || []);
    const hr = headRows.reverse().find((r) => r.cells.length === cols) || (headRows.length ? null : null);
    const ths = Array.from(hr?.cells || []);
    if (!ths.length || ths.some((c) => c.colSpan > 1)) return;
    ths.forEach((th, i) => {
      if (!th.textContent.trim() || th.hasAttribute("data-nosort")) return;
      const label = th.innerHTML;
      th.classList.add("sortable");
      th.innerHTML = `<button type="button" title="Sort">${label}<span class="sort-ind" aria-hidden="true"></span></button>`;
      th.firstChild.addEventListener("click", () => {
        const rows = Array.from(body.rows).filter((r) => r.cells.length === ths.length);
        // first click: numbers high to low, text A to Z; next click flips
        const cur = th.getAttribute("aria-sort");
        const vals = rows.map((r) => val(r.cells[i]));
        const numeric = vals.some((v) => typeof v === "number");
        const asc = cur ? cur === "descending" : !numeric;
        const keyed = rows.map((r, n) => ({ r, v: vals[n], n }));
        keyed.sort((a, b) => (a.v === null) - (b.v === null) || (a.v === null ? 0 : (asc ? 1 : -1) * cmp(a.v, b.v)) || a.n - b.n);
        keyed.forEach((k) => body.appendChild(k.r));
        ths.forEach((h) => h.removeAttribute("aria-sort"));
        th.setAttribute("aria-sort", asc ? "ascending" : "descending");
      });
    });
  });
})();

// Picking from the fleet explorer's Sort menu replaces any column-header sort direction.
document.querySelector("[data-sort-menu]")?.addEventListener("change", (e) => {
  e.target.form.querySelector("input[name=dir]")?.remove();
}, true);

// Chart bars that narrow the list below (Upcoming work, overhaul pipeline). With the whole list on the page the filter runs
// in place; otherwise each bar is a plain link and the server narrows the list.
(() => {
  const list = document.querySelector("[data-bar-list]");
  const chart = document.querySelector("svg.chart.linked");
  if (!list || !chart || list.dataset.complete !== "1") return;
  const status = document.querySelector("[data-bar-status]");
  const label = status?.querySelector("[data-bar-label]");
  let cur = null;
  const apply = (y, k, text) => {
    cur = y ? y + "|" + k : null;
    let n = 0;
    list.querySelectorAll("tbody tr[data-y]").forEach((tr) => {
      const ok = !y || (tr.dataset.y === y && (!k || tr.dataset.k === k));
      tr.hidden = !ok;
      if (ok) n++;
    });
    chart.classList.toggle("has-sel", !!y);
    chart.querySelectorAll("a.seg").forEach((a) => a.classList.toggle("on", !!y && a.dataset.y === y && (!k || a.dataset.k === k)));
    if (status) {
      status.hidden = !y;
      if (y) label.textContent = `Showing ${n.toLocaleString()} in ${text}`;
    }
    const u = new URL(location.href);
    u.searchParams.delete("y"); u.searchParams.delete("k");
    if (y) { u.searchParams.set("y", y); if (k) u.searchParams.set("k", k); }
    history.replaceState(null, "", u.pathname + u.search);
  };
  chart.addEventListener("click", (e) => {
    const a = e.target.closest("a.seg");
    if (!a) return;
    e.preventDefault();
    const y = a.dataset.y, k = a.dataset.k || "";
    if (cur === y + "|" + k) return apply(null);
    // the bar's tooltip reads "2027 Overhaul: 1,234 · …"
    const t = (a.querySelector("title")?.textContent || "").split(":")[0];
    apply(y, k, k ? `${y} · ${t.slice(y.length + 1)}` : y);
    list.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  status?.querySelector("[data-bar-clear]")?.addEventListener("click", (e) => { e.preventDefault(); apply(null); });
})();

// Hover cards: any element with data-tip (lines separated by "\n"; the first is bold) shows a floating card on hover or focus.
// Used by the award price dots and the subsystem share bars. A link underneath still opens on click.
(() => {
  let tip = null, cur = null;
  const show = (el, x, y) => {
    if (!tip) { tip = document.createElement("div"); tip.className = "hovertip"; tip.setAttribute("role", "tooltip"); document.body.appendChild(tip); }
    if (cur !== el) {
      const [head, ...rest] = el.dataset.tip.split("\n");
      tip.replaceChildren();
      const b = document.createElement("b"); b.textContent = head; tip.appendChild(b);
      rest.forEach((l) => { const d = document.createElement("div"); d.textContent = l; tip.appendChild(d); });
      cur = el;
    }
    tip.hidden = false;
    const r = tip.getBoundingClientRect(), pad = 12;
    let left = x + pad, top = y + pad;
    if (left + r.width > innerWidth - 8) left = Math.max(8, x - r.width - pad);
    if (top + r.height > innerHeight - 8) top = Math.max(8, y - r.height - pad);
    tip.style.left = left + "px"; tip.style.top = top + "px";
  };
  const hide = () => { if (tip) tip.hidden = true; cur = null; };
  document.addEventListener("mousemove", (e) => {
    const el = e.target.closest?.("[data-tip]");
    el ? show(el, e.clientX, e.clientY) : cur && hide();
  });
  document.addEventListener("focusin", (e) => {
    const el = e.target.closest?.("[data-tip]");
    if (!el) return;
    const r = el.getBoundingClientRect();
    show(el, r.left + r.width / 2, r.bottom);
  });
  document.addEventListener("focusout", hide);
  document.addEventListener("scroll", hide, { passive: true });
})();

// Definitions on headings: every table column heading and report-card label (<th>, <dt>) whose text is in the site glossary
// (app/glossary.py, served at /glossary.json) gets a hover card with the data element's definition.
(() => {
  const els = [...document.querySelectorAll("th, dt")].filter((el) => !el.hasAttribute("data-tip"));
  if (!els.length) return;
  fetch("/glossary.json").then((r) => (r.ok ? r.json() : {})).then((g) => {
    els.forEach((el) => {
      const label = el.textContent.replace(/[▲▼↑↓↕⇅]/g, "").replace(/\s+/g, " ").trim();
      const def = g[label.toLowerCase()];
      if (!def) return;
      el.dataset.tip = label + "\n" + def;
      el.classList.add("has-def");
    });
  }).catch(() => {});
})();

// Click-to-copy values (Admin > Bid Catcher > Sign-ups): any button with data-copy puts that text on the clipboard.
document.addEventListener("click", (e) => {
  const b = e.target.closest?.("[data-copy]");
  if (!b) return;
  navigator.clipboard?.writeText(b.dataset.copy).then(() => {
    const t = b.textContent; b.classList.add("copied"); b.textContent = "Copied";
    setTimeout(() => { b.textContent = t; b.classList.remove("copied"); }, 900);
  });
});

// Plan tags inside another link (the sidebar's lock tags): a click or Enter goes to the plan section of Account, not the page.
const planTag = (e) => {
  const t = e.target.closest?.(".plan-tag[data-href]");
  if (!t || (e.type === "keydown" && e.key !== "Enter")) return;
  e.preventDefault(); e.stopPropagation();
  location.href = t.dataset.href;
};
document.addEventListener("click", planTag, true);
document.addEventListener("keydown", planTag, true);

// Tables (Justin, 2026-11-02): every table scrolls sideways inside its own box, and long column headings wrap onto two or three lines.
// A heading gets a minimum width of its longest word or a third of its text, whichever is wider, so it never stacks one word per line.
(function () {
  const run = () => {
    document.querySelectorAll("table").forEach((t) => {
      if (t.closest(".tbl, .tw, .brief, .tbl-x, svg")) return;
      const box = document.createElement("div");
      box.className = "tbl-x";
      t.parentNode.insertBefore(box, t); box.appendChild(t);
    });
    document.querySelectorAll("thead th").forEach((th) => {
      const txt = th.textContent.replace(/\s+/g, " ").trim();
      if (txt.length <= 16 || th.classList.contains("wrap")) return;
      const words = txt.split(" ");
      const longest = Math.max(...words.map((w) => w.length));
      const ch = Math.min(Math.max(longest, Math.ceil(txt.length / 3), 9), 22);
      th.classList.add("wrap");
      th.style.minWidth = `calc(${(ch * 1.15).toFixed(1)}ch + 30px)`;  // + cell padding and the sort arrow
    });
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run); else run();
})();

// Period picker on time-series charts (2026-11-03): charts.py wraps each chart that spans 3+ years in .chart-range with its
// year span; this adds From / To selects that reload the page with ?rcN=from-to and come back to the chart.
(() => {
  document.querySelectorAll(".chart-range[data-cid]").forEach((box) => {
    const { cid, min, max, a, b } = box.dataset;
    const bar = document.createElement("div");
    bar.className = "chart-range-bar";
    const mk = (label, val) => {
      const l = document.createElement("label");
      l.textContent = label + " ";
      const s = document.createElement("select");
      for (let y = +min; y <= +max; y++) s.add(new Option(y, y, false, y === +val));
      l.appendChild(s);
      bar.appendChild(l);
      return s;
    };
    const f = mk("From", a), t = mk("to", b);
    const go = () => {
      let x = +f.value, y = +t.value;
      if (y < x) [x, y] = [y, x];
      const u = new URL(location.href);
      if (x === +min && y === +max) u.searchParams.delete(cid); else u.searchParams.set(cid, x + "-" + y);
      u.hash = cid;
      location.assign(u.toString());
    };
    f.addEventListener("change", go); t.addEventListener("change", go);
    if (+a !== +min || +b !== +max) {
      const r = document.createElement("a"); r.href = "#"; r.textContent = "All years"; r.className = "small";
      r.addEventListener("click", (e) => { e.preventDefault(); f.value = min; t.value = max; go(); });
      bar.appendChild(r);
    }
    box.prepend(bar);
  });
})();

// "Recent ... in the news": the GDELT search takes a few seconds, so say so while the next page loads.
(function () {
  const show = (a) => {
    a.classList.add("busy");
    a.setAttribute("aria-busy", "true");
    let box = document.getElementById("news-wait");
    if (!box) {
      box = document.createElement("div");
      box.id = "news-wait";
      box.setAttribute("role", "status");
      box.innerHTML = '<span class="spin" aria-hidden="true"></span><div><b>Searching the news…</b><br><span>Checking thousands of news sites. This usually takes 5 to 15 seconds, and up to about 45 seconds when the news service is busy.</span></div>';
      document.body.appendChild(box);
    }
    box.hidden = false;
  };
  document.addEventListener("click", (ev) => {
    const a = ev.target.closest("a[data-news]");
    if (!a || ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.button) return;
    show(a);
  });
  window.addEventListener("pageshow", () => {  // back button: the page comes from the cache, so clear the notice
    const box = document.getElementById("news-wait");
    if (box) box.hidden = true;
    document.querySelectorAll("a[data-news].busy").forEach((a) => { a.classList.remove("busy"); a.removeAttribute("aria-busy"); });
  });
})();

// Select all / Clear in checklist pop-ups
document.addEventListener("click", (ev) => {
  const b = ev.target.closest("[data-check]");
  if (!b) return;
  const on = b.dataset.check === "all";
  b.closest("form").querySelectorAll("input[type=checkbox]").forEach((c) => { c.checked = on; });
});

/* 1.7.24 header search: typing filters the lists on this page (table rows, list items, cards in a grid); Enter searches the whole site */
(function(){
  var f=document.querySelector('form.top-search');if(!f||f.getAttribute('data-pagefilter')!=='1')return;
  var inp=f.querySelector('input[name=q]'),hint=f.querySelector('.top-q-hint'),main=document.querySelector('.main');if(!inp||!main)return;
  function items(){
    var out=[];
    main.querySelectorAll('table tbody tr').forEach(function(tr){if(!tr.closest('.topbar'))out.push(tr);});
    main.querySelectorAll('.list > .li, ul.rows > li, .grid > .card').forEach(function(el){if(!el.closest('.topbar'))out.push(el);});
    return out;
  }
  var all=null,t=null;
  function run(){
    var q=inp.value.trim().toLowerCase(),words=q.split(/\s+/).filter(Boolean);
    all=all||items();
    if(!words.length){all.forEach(function(el){el.classList.remove('pf-hide');});hint.textContent='';return;}
    var shown=0;
    all.forEach(function(el){var tx=(el.textContent||'').toLowerCase(),ok=words.every(function(w){return tx.indexOf(w)>=0;});el.classList.toggle('pf-hide',!ok);if(ok)shown++;});
    hint.textContent=all.length?('Showing '+shown+' of '+all.length+' on this page. Press Enter to search all of the site.'):'Press Enter to search all of the site.';
  }
  inp.addEventListener('input',function(){clearTimeout(t);t=setTimeout(run,120);});
  inp.addEventListener('keydown',function(e){if(e.key==='Escape'){inp.value='';run();}});
})();

/* 1.7.26 analyst document upload: a chosen file needs the consent box ticked before the question is sent */
(function(){
  var f=document.querySelector('form.ask');if(!f)return;
  var file=f.querySelector('input[type=file][name=doc]'),ok=f.querySelector('input[name=consent]'),box=f.querySelector('.consent');if(!file||!ok)return;
  function sync(){ok.required=!!(file.files&&file.files.length);if(file.files&&file.files.length){var d=f.querySelector('details.ask-doc');if(d)d.open=true;}}
  file.addEventListener('change',sync);sync();
  f.addEventListener('submit',function(e){if(file.files&&file.files.length&&!ok.checked){e.preventDefault();e.stopImmediatePropagation();if(box){box.classList.add('need');box.scrollIntoView({block:'center',behavior:'smooth'});}ok.focus();}},true);
  ok.addEventListener('change',function(){if(box)box.classList.remove('need');});
})();

// 1.7.34 (UI standard, rule 2): click anywhere on a table row to open the record it lists. A row's record is its data-href, else its
// a.row-link, else the first site link in its first two cells that is not a filter pill, button or download. Links, pills, buttons
// and form fields inside the row keep their own action; Ctrl/Cmd-click opens a new tab. Opt a table out with data-norow.
(function () {
  const pick = (tr) => {
    if (tr.dataset.href) return tr.dataset.href;
    const own = tr.querySelector("a.row-link");
    if (own) return own.getAttribute("href");
    // otherwise the first link to a record page (a path with no query: /app/fleets/12, not a filtered list) in the first three cells
    const cells = Array.from(tr.cells).slice(0, 3);
    for (const td of cells) {
      for (const a of td.querySelectorAll("a[href]")) {
        const h = a.getAttribute("href") || "";
        if (!h.startsWith("/") || h.startsWith("//") || h.includes("?") || a.classList.contains("fp") || a.classList.contains("pill")
            || a.classList.contains("btn") || a.hasAttribute("download") || a.target === "_blank") continue;
        return h;
      }
    }
    // no record link: fall back to the row's first drill link to a filtered list (/app/awards?vendor=X), skipping filter pills,
    // buttons, downloads, sort links and in-page anchors, so every row that names something opens that thing's details
    for (const td of cells) {
      for (const a of td.querySelectorAll("a[href]")) {
        const h = a.getAttribute("href") || "";
        if (!(h.startsWith("/") || h.startsWith("?")) || h.startsWith("//") || a.classList.contains("fp") || a.classList.contains("pill")
            || a.classList.contains("btn") || a.hasAttribute("download") || a.target === "_blank" || a.closest("th")) continue;
        return h;
      }
    }
    // a row whose first cell is only a filter pill (Platform, Agency): the pill is the drill
    const lead = cells[0] && cells[0].querySelector("a.fp[href], a.pill[href]");
    if (lead) return lead.getAttribute("href");
    // last resort: the record lives on another site (a grant on USAspending, a notice on Grants.gov): open it in a new tab
    for (const td of cells) {
      const a = td.querySelector('a[href^="http"][target="_blank"]');
      if (a) { tr.dataset.blank = "1"; return a.getAttribute("href"); }
    }
    return null;
  };
  const run = () => {
    document.querySelectorAll(".main table tbody tr, main table tbody tr").forEach((tr) => {
      if (tr.closest("table[data-norow], .chart, svg") || tr.querySelector("input:not([type=hidden]), textarea, select")) return;
      const h = pick(tr);
      if (h) { tr.dataset.href = h; tr.classList.add("row-go"); if (!tr.title) tr.title = "Click the row to open it"; }
    });
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run); else run();
  document.addEventListener("click", (e) => {
    const tr = e.target.closest && e.target.closest("tr[data-href]");
    if (!tr || e.target.closest("a,button,input,select,textarea,label,summary,details,form") || (window.getSelection && String(window.getSelection()).length)) return;
    const h = tr.getAttribute("data-href");
    if (e.metaKey || e.ctrlKey || tr.dataset.blank) { window.open(h, "_blank", "noopener"); return; }
    window.location.href = h;
  });
})();
