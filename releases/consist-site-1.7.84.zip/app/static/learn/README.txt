Optional recorded clips for the training portal: <module>-<step>.mp4 (e.g. analyst-1.mp4) replaces that step's SVG.
