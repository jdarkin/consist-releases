"""Sales territory (1.7.45, Justin 11-13): a member saves the states, provinces and agencies they cover (My account > Your
territory), then turns the Territory switch in the header on or off. While it is on, every agency list in the member app
(bids and RFPs, early signals, awards, board items, vehicle orders, fleets, operators, upcoming work, opportunities,
dashboards, header search) shows only that territory. It rides on the request scope in lens.py, like the market lens and
the US/Canada region, so query helpers read it from lens.current().

Saved in user_pref:
  ter_states    comma list of state and province codes (NY,NJ,ON)
  ter_ops       comma list of fleet operator ids picked by hand (fleet.db operator.operator_id)
  ter_ags       comma list of bid agency ids picked by hand (bids.db agency.agency_id)
  ter_national  "1" to keep national buyers (Amtrak, VIA Rail, federal buyers) whose country is in the territory
  ter_on        "1" while the switch is on

A territory resolves to two id sets: fleet operators and bid agencies. An operator is in when one of its states is in the
territory or it was picked; an agency is in when its state_prov is, it was picked, or it buys for an operator that is in.
A link to one named agency or operator always shows it (see data.notice_filters), so a drill never comes back empty.
Alert emails and the API are not filtered: they run outside a member's page view."""
import re
import time

US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California", "CO": "Colorado", "CT": "Connecticut",
    "DE": "Delaware", "DC": "District of Columbia", "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois",
    "IN": "Indiana", "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana",
    "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania",
    "PR": "Puerto Rico", "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas",
    "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming"}
CA_PROVS = {"AB": "Alberta", "BC": "British Columbia", "MB": "Manitoba", "NB": "New Brunswick", "NL": "Newfoundland and Labrador",
            "NS": "Nova Scotia", "NT": "Northwest Territories", "NU": "Nunavut", "ON": "Ontario", "PE": "Prince Edward Island",
            "QC": "Quebec", "SK": "Saskatchewan", "YT": "Yukon"}
PLACES = {**US_STATES, **CA_PROVS}

# Region shortcuts on the account page: one click ticks the group (members can still untick any state).
GROUPS = {
    "New England": ["CT", "MA", "ME", "NH", "RI", "VT"],
    "Mid-Atlantic": ["DC", "DE", "MD", "NJ", "NY", "PA", "VA", "WV"],
    "Southeast": ["AL", "FL", "GA", "KY", "MS", "NC", "PR", "SC", "TN"],
    "Midwest": ["IA", "IL", "IN", "KS", "MI", "MN", "MO", "ND", "NE", "OH", "SD", "WI"],
    "Texas and South Central": ["AR", "LA", "NM", "OK", "TX"],
    "Mountain": ["AZ", "CO", "ID", "MT", "NV", "UT", "WY"],
    "West Coast and Pacific": ["AK", "CA", "HI", "OR", "WA"],
    "Eastern Canada": ["NB", "NL", "NS", "ON", "PE", "QC"],
    "Western Canada": ["AB", "BC", "MB", "SK", "NT", "NU", "YT"],
}
NATIONAL = {"national", "multi"}  # state values for buyers that cover a whole country
NAT_UP = {x.upper() for x in NATIONAL}

_SPLIT = re.compile(r"[;,/|]+")
_cache = {}


def places(v):
    """State and province codes from a stored value ('NY;NJ', 'NY/NJ', 'national')."""
    return [p.strip().upper() for p in _SPLIT.split(v or "") if p.strip()]


def country_of(code):
    return "CA" if code in CA_PROVS else "US" if code in US_STATES else None


def saved(prefs):
    """The member's saved territory from their prefs (whether or not it is switched on)."""
    def lst(k):
        return [x for x in (prefs.get(k) or "").split(",") if x]
    return {"states": [s for s in lst("ter_states") if s in PLACES], "ops": lst("ter_ops"), "ags": lst("ter_ags"),
            "national": prefs.get("ter_national", "1") != "0", "on": prefs.get("ter_on") == "1"}


def for_user(u):
    """saved() for a member, read from user_pref."""
    from . import db
    return saved({r["key"]: r["value"] for r in db.q("SELECT key, value FROM user_pref WHERE user_id = ? AND key LIKE 'ter_%'", (u["id"],))})


def save(u, form):
    """Store the territory from the account form (states, picked agencies, national) and switch it on when anything is picked."""
    from . import intel
    states = [s for s in form.getlist("ter_state") if s in PLACES]
    picks = form.getlist("ter_pick")
    ops = [p[3:] for p in picks if p.startswith("op:") and re.fullmatch(r"[\w.-]{1,60}", p[3:])]
    ags = [p[3:] for p in picks if p.startswith("ag:") and re.fullmatch(r"[\w.-]{1,60}", p[3:])]
    intel.set_pref(u, "ter_states", ",".join(dict.fromkeys(states)))
    intel.set_pref(u, "ter_ops", ",".join(dict.fromkeys(ops)))
    intel.set_pref(u, "ter_ags", ",".join(dict.fromkeys(ags)))
    intel.set_pref(u, "ter_national", "1" if form.get("ter_national") else "0")
    intel.set_pref(u, "ter_on", "1" if (states or ops or ags) and form.get("ter_on", "1") == "1" else "0")
    return bool(states or ops or ags)


def is_set(t):
    return bool(t["states"] or t["ops"] or t["ags"])


def label(t):
    """'NY, NJ, PA + 3 agencies' for the header chip."""
    st = t["states"]
    bits = []
    if st:
        bits.append(", ".join(st[:4]) + (f" +{len(st) - 4}" if len(st) > 4 else ""))
    n = len(t["ops"]) + len(t["ags"])
    if n:
        bits.append(f"{n} picked agenc{'y' if n == 1 else 'ies'}")
    return " · ".join(bits) or "not set"


def _operators():
    from . import db
    try:
        return [dict(r) for r in db.fq("SELECT operator_id, operator_name, country, states FROM operator")]
    except Exception:
        return []


def _agencies():
    from . import db
    try:
        return [dict(r) for r in db.bq("SELECT agency_id, agency, country, state_prov, fleet_operator_ids FROM agency")]
    except Exception:
        return []


def resolve(t):
    """(operator ids, agency ids) in the territory. Cached ten minutes per territory."""
    key = (tuple(t["states"]), tuple(t["ops"]), tuple(t["ags"]), t["national"])
    hit = _cache.get(key)
    if hit and hit[0] > time.time() - 600:
        return hit[1], hit[2]
    states = set(t["states"])
    countries = {country_of(s) for s in states} - {None}
    ops, ags = set(t["ops"]), set(t["ags"])
    agencies = _agencies()

    def national_ok(country):
        return t["national"] and (not countries or (country or "US") in countries)
    for o in _operators():
        ps = set(places(o.get("states")))
        if ps & states or (ps & NAT_UP and national_ok(o.get("country"))):
            ops.add(o["operator_id"])
    for a in agencies:
        ps = set(places(a.get("state_prov")))
        if ps & states or (ps & NAT_UP and national_ok(a.get("country"))):
            ags.add(a["agency_id"])
    for a in agencies:  # an agency buys for operators: picked agencies bring their operators, and the other way round
        fo = set(places(a.get("fleet_operator_ids")))
        if a["agency_id"] in ags:
            ops |= fo
        elif fo & ops:
            ags.add(a["agency_id"])
    out = (frozenset(ops), frozenset(ags))
    if len(_cache) > 200:
        _cache.clear()
    _cache[key] = (time.time(), *out)
    return out


def choices(keep=()):
    """Agencies a member can pick by hand: fleet operators, then bid agencies not tied to one. [(value, name, where)]."""
    out, seen = [], set()
    for o in sorted(_operators(), key=lambda o: (o.get("operator_name") or "").lower()):
        where = "national" if (o.get("states") or "").lower() in NATIONAL else ", ".join(places(o.get("states"))[:3])
        out.append(("op:" + o["operator_id"], o["operator_name"] or o["operator_id"], where))
        seen.add(o["operator_id"])
    for a in sorted(_agencies(), key=lambda a: (a.get("agency") or "").lower()):
        fo = places(a.get("fleet_operator_ids"))
        if fo and all(x in seen for x in fo) and a["agency_id"] not in keep:
            continue
        ps = places(a.get("state_prov"))
        out.append(("ag:" + a["agency_id"], a.get("agency") or a["agency_id"], "national" if set(ps) & NAT_UP else ", ".join(ps[:3])))
    return out
