"""Social posting cadence (Justin approved 2026-11-16, 1.7.58): post more often without reading as spam.

Content mix, each kind a social_draft row (promo.py):
  bid       a notable new rail bid (estimated value >= $5M, or a rail vehicle / subsystem bid), from bids.db
  award     a notable contract award (>= $1M, rail-relevant), from bids.db
  spotlight operator fleet facts (promo.build_spotlight)
  chart     a chart image (promo.build_chart_post)
  roundup   the Friday weekly roundup: bids and awards of the week
  monthly   the monthly report drafts (promo.build_drafts)

Limits:
  LinkedIn  at most one a day and MAX_LI_WEEK (4) a Mon-Sun week, at least 20 hours apart: three rotation posts Mon-Thu and
            the roundup on Friday (a quiet week skips it).
  Bluesky   at most one post a day. Shorter items (single bids) can go to Bluesky only, on days with no other Bluesky post,
            but only once the Make scenario filters on the 'platforms' field (setting promo_bsky_only, default off).
Variety and anti-spam rules:
  - the same kind never twice in a row; each post one link, at most 3 hashtags (1 on Bluesky: short_text has none)
  - an operator or agency is not featured again within 60 days
  - nothing that reads like one of the last 10 posts (difflib ratio >= 0.8)
  - only real news: bids and awards must clear the thresholds; a quiet week gets fewer posts, never filler
Links carry ?ref=linkedin-<kind> (Bluesky: ?ref=bluesky-<kind> in bsky_url) so Site usage > Sources shows which kinds bring visitors."""
import datetime
import difflib
import logging

from . import config, db

log = logging.getLogger("cadence")

MAX_LI_WEEK = 4
BID_MIN_USD = 5_000_000
AWARD_MIN_USD = 1_000_000
REPEAT_DAYS = 60
SIMILAR = 0.8
VEHICLE_CATS = ("vehicle", "overhaul", "rebuild", "onboard", "propulsion", "train control", "signal")
ROTATION = ("bid", "spotlight", "chart", "award")  # weekday kinds; roundup is Fridays, monthly follows the report

HASHTAGS = {"bid": "#rail #transit #RFP", "award": "#rail #transit #procurement", "roundup": "#rail #transit #procurement"}


def _now():
    return datetime.datetime.now(datetime.timezone.utc)


def _iso(t):
    return t.isoformat(timespec="seconds")


def on():
    return db.settings().get("promo_cadence", "1") == "1"


def bsky_only_on():
    return db.settings().get("promo_bsky_only", "0") == "1"


def ref_url(path, kind, platform="linkedin"):
    u = path if path.startswith("http") else config.SITE_URL + path
    return u.split("?")[0] + f"?ref={platform}-{kind}"


def bsky_url(r):
    """The draft's link tagged for Bluesky, for the webhook's bsky_url field."""
    u = (r["url"] if r else "") or ""
    return u.replace("ref=linkedin", "ref=bluesky") if "ref=linkedin" in u else u


def _money(v):
    return f"${v / 1e9:.1f}B" if v >= 1e9 else f"${v / 1e6:.0f}M" if v >= 1e6 else f"${v:,.0f}"


# ---------- variety and repeat checks ----------

def _last_kind():
    r = db.q("SELECT kind FROM social_draft WHERE body != '' AND (posted IS NOT NULL OR scheduled IS NOT NULL) "
             "ORDER BY coalesce(scheduled, posted) DESC LIMIT 1", one=True)
    return (r["kind"] if r else None) or "monthly"


def _recent_refs():
    since = _iso(_now() - datetime.timedelta(days=REPEAT_DAYS))
    refs = set()
    for r in db.q("SELECT ref, subject FROM social_draft WHERE created >= ?", (since,)):
        for x in (r["ref"], r["subject"]):
            if x:
                refs.add(str(x).lower())
    return refs


def too_similar(text):
    """True when text reads like one of the last 10 posts or drafts."""
    for r in db.q("SELECT body FROM social_draft WHERE body != '' ORDER BY id DESC LIMIT 10"):
        if difflib.SequenceMatcher(None, text.lower(), (r["body"] or "").lower()).ratio() >= SIMILAR:
            return True
    return False


# ---------- content builders ----------

def _bids_ok():
    try:
        db.bq("SELECT 1 FROM notice LIMIT 1")
        return True
    except Exception:
        return False


def notable_bids(days=4, limit=10):
    from . import data
    if not _bids_ok():
        return []
    since = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
    cats = " OR ".join(f"lower(coalesce(n.category, '')) LIKE '%{c}%'" for c in VEHICLE_CATS)
    rows = db.bq("SELECT n.notice_id, n.title, n.summary, n.category, n.value_est, n.currency, n.closing, n.operator_id, n.agency_id, "
                 "coalesce(g.agency, n.buyer) agency, g.state_prov FROM notice n LEFT JOIN agency g USING (agency_id) "
                 "WHERE coalesce(n.published, date(n.first_seen)) >= ? AND coalesce(n.relevance, 0) >= 70 "
                 "AND coalesce(n.notice_type, '') NOT IN ('award', 'cancelled', 'addendum') "
                 f"AND (coalesce(n.value_est, 0) >= ? OR {cats}) ORDER BY coalesce(n.value_est, 0) DESC, n.relevance DESC LIMIT ?",
                 (since, BID_MIN_USD, limit))
    return [d for d in map(dict, rows) if not data.restricted(d)]


def notable_awards(days=10, limit=10):
    from . import data
    if not _bids_ok():
        return []
    since = (datetime.date.today() - datetime.timedelta(days=days)).isoformat()
    rows = db.bq("SELECT award_id, title, vendor, coalesce(amount_usd, amount) amt, award_date, operator_id, agency_id, buyer, category "
                 "FROM award WHERE coalesce(award_date, date(first_seen)) >= ? AND coalesce(relevance, 0) >= 50 "
                 "AND coalesce(amount_usd, amount, 0) >= ? AND vendor IS NOT NULL ORDER BY amt DESC LIMIT ?", (since, AWARD_MIN_USD, limit))
    return [d for d in map(dict, rows) if not data.restricted(d)]


def _short(s, n=110):
    s = " ".join((s or "").split())
    return s if len(s) <= n else s[:n - 1].rsplit(" ", 1)[0].rstrip(",;:") + "…"


def build_bid(b):
    url = ref_url("/data/rail-bids-this-month", "bid")
    where = f"{b['agency']}" + (f" ({b['state_prov']})" if b.get("state_prov") else "")
    val = f", estimated at {_money(b['value_est'])}" if b.get("value_est") and b["value_est"] >= 1e5 else ""
    hook = f"New rail bid: {where} is seeking {_short(b['title'], 90).rstrip('.')}{val}."
    close = ""
    if b.get("closing"):
        try:
            close = f"Responses are due {datetime.date.fromisoformat(b['closing'][:10]):%B %-d}."
        except ValueError:
            pass
    summ = b.get("summary") or ""
    if b.get("agency") and summ.lower().startswith(b["agency"].lower()):
        summ = summ[len(b["agency"]):].lstrip(" :,-")
        summ = summ[:1].upper() + summ[1:]
    detail = " ".join(x for x in [_short(summ, 180), close] if x)
    text = "\n\n".join(x for x in [hook, detail, f"This month's rail bids by category and state:\n{url}", HASHTAGS["bid"]] if x)
    return text, url, f"notice:{b['notice_id']}", (b.get("operator_id") or b.get("agency") or "").lower()


def build_award(a):
    from . import data
    path = f"/operators/{data.slug(a['operator_id'])}" if a.get("operator_id") else "/data/rail-bids-this-month"
    url = ref_url(path, "award")
    buyer = a.get("buyer") or "A transit agency"
    hook = f"Contract award: {buyer} awarded {_money(a['amt'])} to {a['vendor']}."
    detail = f"The work: {_short(a['title'], 160).rstrip('.')}." if a.get("title") else ""
    more = (f"{buyer}'s fleet, orders and recent bids:" if a.get("operator_id") else "More rail bids and awards:") + f"\n{url}"
    text = "\n\n".join(x for x in [hook, detail, more, HASHTAGS["award"]] if x)
    return text, url, f"award:{a['award_id']}", (a.get("operator_id") or buyer).lower()


def build_roundup():
    """The Friday weekly roundup, or None in a quiet week (fewer than 3 notable items)."""
    bids, awards = notable_bids(days=7, limit=20), notable_awards(days=7, limit=20)
    if len(bids) + len(awards) < 3:
        return None
    url = ref_url("/data/rail-bids-this-month", "roundup")
    d = datetime.date.today()
    lines = [f"Rail procurement this week in the US and Canada: {len(bids)} notable new bid{'s' if len(bids) != 1 else ''}"
             + (f" and {len(awards)} contract award{'s' if len(awards) != 1 else ''} over $1M." if awards else ".")]
    if bids:
        lines.append("Bids worth a look:\n" + "\n".join(f"• {b['agency']}: {_short(b['title'], 70)}"
                                                      + (f" ({_money(b['value_est'])})" if b.get("value_est") and b["value_est"] >= 1e5 else "")
                                                      for b in bids[:3]))
    if awards:
        lines.append("Awards:\n" + "\n".join(f"• {a['buyer'] or 'Agency'} to {a['vendor']}, {_money(a['amt'])}" for a in awards[:3]))
    lines += [f"Every rail bid this month by category and state:\n{url}", HASHTAGS["roundup"]]
    return "\n\n".join(lines), url, f"roundup:{d.isocalendar()[0]}-{d.isocalendar()[1]}", ""


# ---------- scheduling ----------

def _week_start(d):
    return d - datetime.timedelta(days=d.weekday())


def _li_day_counts(d0, d1):
    """{date: n} of LinkedIn posts posted or scheduled between two dates (inclusive), by Eastern date."""
    from . import promo
    out = {}
    for r in db.q("SELECT coalesce(posted, scheduled) t FROM social_draft WHERE body != '' AND coalesce(platforms, 'linkedin,bluesky') LIKE '%linkedin%' "
                  "AND (posted IS NOT NULL OR scheduled IS NOT NULL)"):
        t = promo._parse(r["t"])
        d = (t - datetime.timedelta(hours=promo._et_offset(t.date()))).date()
        if d0 <= d <= d1:
            out[d] = out.get(d, 0) + 1
    return out


def next_li_slot(salt=0, friday=False):
    """Next weekday morning (Friday only for the roundup) with no LinkedIn post that day and under MAX_LI_WEEK that week.
    One post a day at about 9am Eastern keeps posts about 24 hours apart."""
    from . import promo
    now = _now()
    d = now.date()
    counts = _li_day_counts(d - datetime.timedelta(days=7), d + datetime.timedelta(days=60))
    for _ in range(60):
        wk = _week_start(d)
        week_n = sum(n for k, n in counts.items() if wk <= k < wk + datetime.timedelta(days=7))
        # Mon-Thu for the rotation (3 a week, leaving room for the roundup); Friday belongs to the roundup
        ok_day, cap = (d.weekday() == 4, MAX_LI_WEEK) if friday else (d.weekday() < 4, MAX_LI_WEEK - 1)
        if ok_day and not counts.get(d) and week_n < cap and promo._parse(promo._slot_utc(d, salt)) > now + datetime.timedelta(minutes=5):
            return promo._slot_utc(d, salt)
        d += datetime.timedelta(days=1)
    return promo._slot_utc(d, salt)


def _queue_ahead(days=7):
    return db.q("SELECT kind FROM social_draft WHERE posted IS NULL AND body != '' AND scheduled IS NOT NULL AND scheduled <= ? "
                "AND coalesce(platforms, 'linkedin,bluesky') LIKE '%linkedin%'", (_iso(_now() + datetime.timedelta(days=days)),))


def _add(kind, built, platforms="linkedin,bluesky", friday=False, image=None):
    from . import promo
    text, url, ref, subject = built
    if too_similar(text):
        return None
    now = _now()
    did = db.x("INSERT INTO social_draft (month, channel, body, url, created, kind, ref, subject, platforms, image) "
               "VALUES (?, 'linkedin', ?, ?, ?, ?, ?, ?, ?, ?)", (now.strftime("%Y-%m"), text, url, db.now(), kind, ref, subject, platforms, image))
    if platforms == "bluesky":
        when = promo._slot_utc(now.date() if now.hour < 20 else now.date() + datetime.timedelta(days=1), did + 11)
        when = max(when, _iso(now + datetime.timedelta(minutes=30)))
    else:
        when = next_li_slot(did, friday=friday)
    db.x("UPDATE social_draft SET scheduled = ? WHERE id = ?", (when, did))
    return did


def _pick(kind, recent):
    from . import promo
    if kind == "bid":
        for b in notable_bids():
            built = build_bid(b)
            if built[2] not in recent and built[3] not in recent:
                return built, None
    elif kind == "award":
        for a in notable_awards():
            built = build_award(a)
            if built[2] not in recent and built[3] not in recent:
                return built, None
    elif kind == "chart" and db.settings().get("promo_charts", "1") == "1":
        start = promo.CHART_ORDER.index(promo._next_chart())
        for k in range(len(promo.CHART_ORDER)):
            c = promo.CHART_ORDER[(start + k) % len(promo.CHART_ORDER)]
            built = promo.build_chart_post(c)
            if built:
                return (built[0].replace("ref=linkedin", "ref=linkedin-chart"), ref_url(built[1], "chart"), f"chart:{c}", ""), c
    elif kind == "spotlight":
        o = promo._spotlight_pick()
        if o and o["operator_id"].lower() not in recent:
            text, url = promo.build_spotlight(o)
            return (text.replace("ref=linkedin", "ref=linkedin-spotlight"), ref_url(url, "spotlight"), o["operator_id"], o["operator_id"].lower()), None
    return None, None


def fill():
    """Top the queue up to MAX_LI_WEEK LinkedIn posts in the next 7 days, varying kinds; add the Friday roundup; and, when
    allowed, one Bluesky-only bid on a day that has none. Returns the ids added."""
    from . import promo
    promo._init()
    added = []
    recent = _recent_refs()
    today = datetime.date.today()
    # Friday roundup, made from Wednesday on for this week's Friday
    if today.weekday() in (2, 3) and not db.q("SELECT 1 FROM social_draft WHERE kind = 'roundup' AND created >= ?",
                                              (_iso(_now() - datetime.timedelta(days=5)),), one=True):
        built = build_roundup()
        if built:
            did = _add("roundup", built, friday=True)
            if did:
                added.append(did)
    queued = _queue_ahead()
    room = MAX_LI_WEEK - 1 - len([q for q in queued if q["kind"] != "roundup"])
    last = _last_kind()
    tried = 0
    while room > 0 and tried < len(ROTATION) * 2:
        start = (ROTATION.index(last) + 1) % len(ROTATION) if last in ROTATION else 0
        made = False
        for k in range(len(ROTATION)):
            kind = ROTATION[(start + k) % len(ROTATION)]
            tried += 1
            if kind == last:
                continue
            try:
                built, image = _pick(kind, recent)
            except Exception as e:  # one source failing (bids.db busy, a bad row) never stops the others
                log.warning("cadence %s failed: %s", kind, e)
                built, image = None, None
            if not built:
                continue
            did = _add(kind, built, image=image)
            if did:
                added.append(did)
                recent |= {built[2].lower(), built[3]}
                last, room, made = kind, room - 1, True
                break
        if not made:
            break  # a quiet week: no filler
    if bsky_only_on():
        day0 = _iso(datetime.datetime.combine(today, datetime.time(), datetime.timezone.utc))
        if not db.q("SELECT 1 FROM social_draft WHERE coalesce(platforms, 'linkedin,bluesky') LIKE '%bluesky%' "
                    "AND coalesce(posted, scheduled) >= ? AND coalesce(posted, scheduled) < ?",
                    (day0, _iso(datetime.datetime.combine(today + datetime.timedelta(days=1), datetime.time(), datetime.timezone.utc))), one=True):
            for b in notable_bids(days=2):
                built = build_bid(b)
                if built[2] not in recent:
                    did = _add("bid", built, platforms="bluesky")
                    if did:
                        added.append(did)
                    break
    return added


def can_send(r):
    """Per-platform limits checked again at send time (a hand-edited date can't break them)."""
    from . import promo
    now = _now()
    plats = r["platforms"] or "linkedin,bluesky"
    since20 = _iso(now - datetime.timedelta(hours=20))
    if "linkedin" in plats:
        if db.q("SELECT 1 FROM social_draft WHERE posted >= ? AND coalesce(platforms, 'linkedin,bluesky') LIKE '%linkedin%'", (since20,), one=True):
            return False
        et = (now - datetime.timedelta(hours=promo._et_offset(now.date()))).date()
        if et.weekday() > 4:
            return False
        wk = _iso(datetime.datetime.combine(_week_start(et), datetime.time(), datetime.timezone.utc))
        n = db.q("SELECT count(*) n FROM social_draft WHERE posted >= ? AND coalesce(platforms, 'linkedin,bluesky') LIKE '%linkedin%'", (wk,), one=True)["n"]
        if n >= MAX_LI_WEEK and r["kind"] != "monthly":
            return False
    if "bluesky" in plats and db.q("SELECT 1 FROM social_draft WHERE posted >= ? AND coalesce(platforms, 'linkedin,bluesky') LIKE '%bluesky%'",
                                   (since20,), one=True):
        return False
    return True


def engagement(days=14):
    """For the Admin card: the best-performing kind (visits by ref) and this week's post to reshare."""
    from . import usage
    try:
        rows = db.q("SELECT source, count(DISTINCT sid) v FROM usage_event WHERE ts >= ? AND kind = 'view' AND (source LIKE 'linkedin%' OR source LIKE 'bluesky%') "
                    "GROUP BY source ORDER BY v DESC", (usage.since(days),))
    except Exception:
        rows = []
    by_kind = {}
    for r in rows:
        k = r["source"].split("-", 1)[1] if "-" in r["source"] else "other"
        by_kind[k] = by_kind.get(k, 0) + r["v"]
    week = db.q("SELECT * FROM social_draft WHERE posted >= ? AND body != '' ORDER BY posted DESC", (_iso(_now() - datetime.timedelta(days=7)),))
    best = None
    if week:
        best = max(week, key=lambda r: by_kind.get(r["kind"] or "", 0))
    return {"by_kind": sorted(by_kind.items(), key=lambda x: -x[1]), "reshare": best,
            "due": datetime.date.today().weekday() in (1, 3)}
