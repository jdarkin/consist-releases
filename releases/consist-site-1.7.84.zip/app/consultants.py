"""Engineering and A/E consultants: firms ranked by the rail engineering awards Bid Catcher records, and a detail page per
firm with every award cited, what kind of work it was, the firm's website, Wikipedia and news (version 1.2, 2026-11-07).

Firm websites and Wikipedia articles come from seed/consultant_firms.csv (curated; a Wikipedia link is listed only where the
article exists), falling back to the supplier directory's website."""
import csv
import datetime
import os
import re

from . import db

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "consultant_firms.csv")
CONSULT_CATS = ("rail_engineering", "engineering_support")
CONSULT_RX = (r"engineering services|design services|consultant|consulting|program management|construction management|on[- ]call|"
              r"\bidiq\b|inspection services|owner'?s representative|feasibility|environmental|planning services|a/e\b|architect")

# what the work was, read from the award title and category; first matches win, several can apply
NATURE = [
    ("oncall", "On-call / IDIQ", r"on[- ]call|\bidiq\b|indefinite delivery|task order|as[- ]needed|bench contract|master (services )?agreement|general engineering"),
    ("pm", "Program and construction management", r"program management|construction management|\bpmc\b|owner'?s rep|\bcm\b services|project management"),
    ("signals", "Signals and train control", r"signal|train control|\bcbtc\b|\bptc\b|\batc\b"),
    ("systems", "Systems, power and communications", r"systems engineering|traction power|communications|scada|catenary|\bocs\b|electrification"),
    ("vehicles", "Vehicle engineering", r"vehicle|railcar|rail car|rolling stock|car procurement|fleet|locomotive|\blrv\b"),
    ("design", "Design and engineering", r"design|engineering services|preliminary engineering|final design|\bpe\b"),
    ("inspection", "Inspection and quality", r"inspection|quality assurance|\bqa\b|resident engineer|testing"),
    ("planning", "Planning and environmental", r"planning|environmental|feasibility|study|alternatives analysis|\bnepa\b|ridership"),
]

CAT_LABEL = {"rail_engineering": "Rail engineering", "engineering_support": "Engineering support"}


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")[:80]


def nature(title, category=None):
    t = (title or "").lower()
    out = [(k, lab) for k, lab, rx in NATURE if re.search(rx, t)]
    if not out and category in CAT_LABEL:
        out = [("design", "Design and engineering")]
    return out


_PROF = None


def _profiles():
    global _PROF
    if _PROF is None:
        out = []
        try:
            with open(SEED, newline="", encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    al = [a.strip().lower() for a in (r.get("aliases") or "").split(";") if a.strip()] + [r["name"].lower()]
                    out.append({"name": r["name"], "aliases": sorted(set(al), key=len, reverse=True),
                                "website": (r.get("website") or "").strip() or None, "wikipedia": (r.get("wikipedia") or "").strip() or None})
        except OSError:
            pass
        _PROF = out
    return _PROF


def profile(name):
    """Website and Wikipedia for a firm, matching the curated list by alias (longest alias first, whole words)."""
    n = " " + re.sub(r"[^a-z0-9&é ]+", " ", (name or "").lower()) + " "
    best = None
    for p in _profiles():
        for a in p["aliases"]:
            if f" {a} " in n and (best is None or len(a) > best[0]):
                best = (len(a), p)
    if best:
        return dict(best[1])
    try:  # fall back to the supplier directory's website
        r = db.q("SELECT name, website FROM supplier_dir WHERE lower(name) = ? AND website IS NOT NULL AND website != ''", ((name or "").lower().strip(),), one=True)
        if r:
            return {"name": r["name"], "website": r["website"], "wikipedia": None, "aliases": []}
    except Exception:
        pass
    return {"name": None, "website": None, "wikipedia": None, "aliases": []}


def _awards(years):
    try:
        rows = [dict(r) for r in db.bq(
            "SELECT award_id, notice_id, vendor, vendor_norm, title, category, amount_usd, amount, currency, award_date, term_months, "
            "n_bidders, low_bid, high_bid, operator_id, buyer, country, ref_no, source, source_url, confidence, notes FROM award "
            f"WHERE award_date >= date('now', '-{int(years) * 365} days')")]
    except Exception:
        return []
    out = []
    for r in rows:
        if r.get("category") in CONSULT_CATS or re.search(CONSULT_RX, r.get("title") or "", re.I):
            if r.get("vendor_norm") or r.get("vendor"):
                out.append(r)
    return out


def _end(r):
    try:
        if r.get("award_date") and r.get("term_months"):
            d = datetime.date.fromisoformat(str(r["award_date"])[:10])
            m = d.month - 1 + int(r["term_months"])
            return datetime.date(d.year + m // 12, m % 12 + 1, 1).isoformat()[:7]
    except (ValueError, TypeError):
        pass
    return None


def firms(years=5, q=None, agency=None, kind=None):
    """Firms ranked by award count then value, with agencies, the kinds of work, and the newest award."""
    by = {}
    for r in _awards(years):
        k = slug(r.get("vendor_norm") or r.get("vendor"))
        b = by.setdefault(k, {"key": k, "names": {}, "n": 0, "usd": 0, "agencies": set(), "last": "", "kinds": {}, "oncall_open": 0})
        nm = r.get("vendor") or k
        b["names"][nm] = b["names"].get(nm, 0) + 1
        b["n"] += 1
        b["usd"] += r.get("amount_usd") or 0
        b["agencies"].add(r.get("buyer") or r.get("operator_id") or "")
        b["last"] = max(b["last"], r.get("award_date") or "")
        for kk, lab in nature(r.get("title"), r.get("category")):
            b["kinds"][lab] = b["kinds"].get(lab, 0) + 1
        e = _end(r)
        if e and e >= datetime.date.today().isoformat()[:7] and any(kk == "oncall" for kk, _ in nature(r.get("title"))):
            b["oncall_open"] += 1
    out = []
    for b in by.values():
        b["name"] = max(b["names"].items(), key=lambda x: x[1])[0]
        b["agencies"] = sorted(a for a in b["agencies"] if a)
        b["kinds"] = [k for k, _ in sorted(b["kinds"].items(), key=lambda x: -x[1])]
        b["profile"] = profile(b["name"])
        out.append(b)
    if q:
        ql = q.lower()
        out = [b for b in out if ql in b["name"].lower() or ql in b["key"]]
    if agency:
        out = [b for b in out if agency in b["agencies"]]
    if kind:
        out = [b for b in out if kind in b["kinds"]]
    out.sort(key=lambda b: (-b["n"], -b["usd"]))
    return out


def firm(key, years=10):
    """One firm: its awards (newest first) with the kind of work, term and end date, bidders and source."""
    rows = [r for r in _awards(years) if slug(r.get("vendor_norm") or r.get("vendor")) == key]
    if not rows:
        return None
    names = {}
    for r in rows:
        names[r.get("vendor")] = names.get(r.get("vendor"), 0) + 1
    name = max(names.items(), key=lambda x: x[1])[0] or key
    for r in rows:
        r["nature"] = nature(r.get("title"), r.get("category"))
        r["end"] = _end(r)
        r["cat_label"] = CAT_LABEL.get(r.get("category"), (r.get("category") or "").replace("_", " ").capitalize())
        r["agency"] = r.get("buyer") or r.get("operator_id") or ""
    rows.sort(key=lambda r: r.get("award_date") or "", reverse=True)
    agencies = {}
    for r in rows:
        a = agencies.setdefault(r["agency"], {"agency": r["agency"], "operator_id": r.get("operator_id"), "n": 0, "usd": 0})
        a["n"] += 1
        a["usd"] += r.get("amount_usd") or 0
    kinds = {}
    for r in rows:
        for _, lab in r["nature"]:
            kinds[lab] = kinds.get(lab, 0) + 1
    today = datetime.date.today().isoformat()[:7]
    return {"key": key, "name": name, "aliases": [n for n in names if n and n != name], "awards": rows, "n": len(rows),
            "usd": sum(r.get("amount_usd") or 0 for r in rows), "agencies": sorted(agencies.values(), key=lambda a: (-a["n"], -a["usd"])),
            "kinds": sorted(kinds.items(), key=lambda x: -x[1]), "profile": profile(name),
            "open_terms": [r for r in rows if r["end"] and r["end"] >= today], "years": years}


def news_entity(f):
    """A supplier_news entity tuple for a firm: (id, name, '', '', '', [], aliases)."""
    al = [a for a in (f["profile"].get("aliases") or []) if len(a) > 4][:3]
    nm = f["profile"].get("name") or re.sub(r"\b(inc|llc|ltd|corp|corporation|co|pc|pllc)\b\.?", "", f["name"], flags=re.I).strip(" ,.")
    return ("cons-" + f["key"], nm, "", "", "", [], [a.title() for a in al])
