"""Supplier intelligence: financial size and performance, installed-base share and award share of rail suppliers by segment.
Financials: SEC 10-K XBRL for US filers (seed/supplier_fin_sec.csv.gz, tools/suppliers/sec_fin.py) plus figures admins enter
from foreign annual reports (app.db supplier_fin_manual, Admin > Supplier financials). Shares are Consist-derived:
installed base from fleet.db (cars in service by builder) and awards from Bid Catcher (relevance >= 50, last 5 years)."""
import csv, gzip, os

from . import db

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "supplier_fin_sec.csv.gz")

SEGMENTS = [  # key, label, portal (passenger | freight | both), definition
    ("pax_oem", "Passenger rolling stock", "passenger", "Builders of commuter, intercity, metro and light rail cars."),
    ("loco", "Locomotives", "both", "Builders and rebuilders of freight and passenger locomotives."),
    ("propulsion", "Propulsion and traction", "passenger", "Traction motors, inverters, converters and power electronics."),
    ("brakes_doors_hvac", "Brakes, doors, couplers, HVAC", "passenger", "Car-borne subsystems: friction brakes, door systems, couplers, heating and air conditioning."),
    ("trucks_wheels", "Trucks, wheels and axles", "both", "Bogies, wheelsets, wheels, axles and bearings."),
    ("pis_control", "Passenger information and vehicle control", "passenger", "Passenger information, vehicle control and monitoring, CCTV and onboard connectivity."),
    ("freight_cars", "Freight car builders", "freight", "Builders of freight cars and tank cars."),
    ("lessors", "Freight car lessors", "freight", "Owners that lease freight cars and tank cars to shippers and railroads."),
    ("signal_wayside", "Signaling, PTC and wayside", "both", "Train control, PTC, signals, detectors and track products."),
    ("mro", "Overhaul, maintenance and services", "both", "Contract maintenance, overhaul, track services and rebuilds."),
]
SEG = {s[0]: s for s in SEGMENTS}

# id, name, parent / ownership, country, listing, segments, aliases (lower-case substrings matched against fleet.db builder
# names and award vendor names; keep them specific)
ENTITIES = [
    ("alstom", "Alstom", "Alstom SA (Paris)", "France", "Euronext ALO", ["pax_oem", "propulsion", "signal_wayside", "mro", "loco"], ["alstom", "bombardier"]),
    ("kawasaki", "Kawasaki Rail Car", "Kawasaki Heavy Industries", "Japan", "TSE 7012", ["pax_oem"], ["kawasaki"]),
    ("siemens", "Siemens Mobility", "Siemens AG", "Germany", "XETRA SIE", ["pax_oem", "loco", "propulsion", "signal_wayside", "mro"], ["siemens"]),
    ("hitachi", "Hitachi Rail", "Hitachi Ltd (incl. Ansaldo STS, Thales GTS)", "Japan", "TSE 6501", ["pax_oem", "propulsion", "signal_wayside", "pis_control"], ["hitachi", "ansaldo", "thales"]),
    ("nippon_sharyo", "Nippon Sharyo", "Central Japan Railway", "Japan", "TSE 7102", ["pax_oem"], ["nippon sharyo", "sumitomo"]),
    ("kinki_sharyo", "Kinki Sharyo", "Kintetsu Group", "Japan", "TSE 7122", ["pax_oem"], ["kinki sharyo"]),
    ("hyundai_rotem", "Hyundai Rotem", "Hyundai Motor Group", "South Korea", "KRX 064350", ["pax_oem"], ["hyundai rotem", "rotem"]),
    ("crrc", "CRRC", "CRRC Corporation (state-owned)", "China", "SSE/HKEX 1766", ["pax_oem"], ["crrc"]),
    ("stadler", "Stadler", "Stadler Rail AG", "Switzerland", "SIX SRAIL", ["pax_oem", "loco"], ["stadler"]),
    ("caf", "CAF", "CAF SA", "Spain", "BME CAF", ["pax_oem"], ["caf usa", "construcciones y auxiliar", "caf "]),
    ("brookville", "Brookville Equipment", "Private", "USA", "Private", ["pax_oem", "loco", "mro"], ["brookville"]),
    ("talgo", "Talgo", "Talgo SA", "Spain", "BME TLGO", ["pax_oem", "mro"], ["talgo"]),
    ("wabtec", "Wabtec", "Westinghouse Air Brake Technologies", "USA", "NYSE WAB", ["loco", "brakes_doors_hvac", "propulsion", "pis_control", "signal_wayside", "freight_cars", "mro", "trucks_wheels"],
     ["wabtec", "wabco", "ge transportation", "general electric", "motivepower", "faiveley", "vapor", "stone air", "quester tangent", "digital recorders", "frauscher"]),
    ("progress_rail", "Progress Rail (EMD)", "Caterpillar Inc.", "USA", "NYSE CAT (parent)", ["loco", "signal_wayside", "mro"], ["progress rail", "emd", "electro-motive"]),
    ("knorr", "Knorr-Bremse", "Knorr-Bremse AG (incl. KB Signaling, ex-Alstom/GE NA conventional signaling, 2024; Selectron)", "Germany", "XETRA KBX", ["brakes_doors_hvac", "signal_wayside", "pis_control"], ["knorr", "new york air brake", "merak", "kb signaling", "selectron"]),
    ("mitsubishi", "Mitsubishi Electric", "Mitsubishi Electric Corp.", "Japan", "TSE 6503", ["propulsion"], ["mitsubishi"]),
    ("toshiba", "Toshiba", "Toshiba Corp.", "Japan", "Private (2023)", ["propulsion"], ["toshiba"]),
    ("dellner", "Dellner", "Private", "Sweden", "Private", ["brakes_doors_hvac"], ["dellner"]),
    ("luminator", "Luminator", "Private", "USA", "Private", ["pis_control"], ["luminator"]),
    ("icomera", "Icomera", "Equans", "Sweden", "Private", ["pis_control"], ["icomera"]),
    ("amsted", "Amsted Rail", "Amsted Industries (employee-owned)", "USA", "Private", ["trucks_wheels", "freight_cars"], ["amsted", "griffin wheel", "asf-keystone"]),
    ("standard_steel", "Standard Steel", "Nippon Steel", "USA", "TSE 5401 (parent)", ["trucks_wheels"], ["standard steel"]),
    ("trinity", "Trinity Industries", "Trinity Industries Inc.", "USA", "NYSE TRN", ["freight_cars", "lessors"], ["trinity"]),
    ("greenbrier", "Greenbrier", "The Greenbrier Companies", "USA", "NYSE GBX", ["freight_cars", "lessors", "mro"], ["greenbrier", "gunderson"]),
    ("freightcar_america", "FreightCar America", "FreightCar America Inc.", "USA/Mexico", "NASDAQ RAIL", ["freight_cars"], ["freightcar america"]),
    ("national_steel_car", "National Steel Car", "Private", "Canada", "Private", ["freight_cars"], ["national steel car"]),
    ("utlx", "Union Tank Car", "Berkshire Hathaway", "USA", "NYSE BRK (parent)", ["freight_cars", "lessors"], ["union tank car", "utlx", "procor"]),
    ("gatx", "GATX", "GATX Corporation", "USA", "NYSE GATX", ["lessors"], ["gatx"]),
    ("ttx", "TTX", "Owned by Class I railroads", "USA", "Private", ["lessors"], ["ttx"]),
    ("lb_foster", "L.B. Foster", "L.B. Foster Company", "USA", "NASDAQ FSTR", ["signal_wayside"], ["l.b. foster", "lb foster"]),
    ("enviri", "Enviri (Harsco Rail)", "Enviri Corporation", "USA", "NYSE NVRI", ["signal_wayside", "mro"], ["harsco", "enviri"]),
    ("loram", "Loram", "Private", "USA", "Private", ["mro"], ["loram"]),
    ("herzog", "Herzog", "Private", "USA", "Private", ["mro"], ["herzog"]),
    ("railworks", "RailWorks", "Private", "USA", "Private", ["mro", "signal_wayside"], ["railworks"]),
]
ENT = {e[0]: e for e in ENTITIES}
CONGLOMERATE = {"caterpillar": "progress_rail", "utlx": None}  # parent-level filings: rail is a segment inside
SEC_PARENT = {"caterpillar": "progress_rail"}
SUBSIDIARY_OF = {"progress_rail": "Caterpillar"}  # rail unit not reported separately by the parent
METRICS = {"revenue": "Revenue", "op_income": "Operating income", "net_income": "Net income", "backlog": "Backlog (remaining performance obligations)",
           "capex": "Capital spending", "assets": "Total assets", "rd": "R&D spending", "rail_revenue": "Rail segment revenue", "orders": "Orders received"}
DEF = {
    "revenue": "Company revenue for the fiscal year, US dollars. For conglomerates the figure is the whole parent; see rail segment revenue.",
    "rail_revenue": "Revenue of the rail or mobility segment as the company reports it (global, not North America only).",
    "growth": "Compound annual growth of revenue over the last three reported years.",
    "margin": "Operating income / revenue for the latest year.",
    "backlog": "Orders received but not yet delivered (remaining performance obligations), latest year end.",
    "ib_share": "Share of passenger cars and locomotives in service in North America built by this supplier (Consist fleet database).",
    "award_share": "Share of the dollar value of rail contract awards tracked by Consist Bid Catcher over the last five years that this supplier won.",
}
DDL = """CREATE TABLE IF NOT EXISTS supplier_fin_manual (
  supplier_id TEXT, year INTEGER, metric TEXT, value REAL, currency TEXT, usd_rate REAL, source TEXT, entered_by TEXT, entered TEXT,
  PRIMARY KEY (supplier_id, year, metric))"""
_c = {}


def _ddl():
    if "ddl" not in _c:
        db.x(DDL)
        _c["ddl"] = 1


def _sec():
    if "sec" not in _c:
        rows = []
        if os.path.exists(SEED):
            with gzip.open(SEED, "rt", newline="") as f:
                for r in csv.DictReader(f):
                    sid = SEC_PARENT.get(r["supplier_id"], r["supplier_id"])
                    rows.append(dict(supplier_id=sid, year=int(r["year"]), metric=r["metric"], value=float(r["value"]), usd=float(r["value"]),
                                     currency="USD", source=r["source"], parent=r["supplier_id"] in SEC_PARENT))
        _c["sec"] = rows
    return _c["sec"]


FOREIGN = os.path.join(os.path.dirname(SEED), "supplier_fin_foreign.csv.gz")
BASIS = {"reported": "Reported: the company's own figure for this measure, converted to US dollars at the average rate shown.",
         "converted": "Converted: the company reports a different measure (for example adjusted EBIT, segment profit or a rail segment), mapped to this one.",
         "estimated": "Estimated: Consist-derived from the company's reported growth rates or partial figures."}


def _foreign():
    """Annual-report figures for suppliers outside SEC XBRL (tools/suppliers/foreign_fin.py), each labelled reported/converted/estimated."""
    if "foreign" not in _c:
        rows = []
        if os.path.exists(FOREIGN):
            with gzip.open(FOREIGN, "rt", newline="") as f:
                for r in csv.DictReader(f):
                    v, rate = float(r["value"]), float(r["usd_rate"] or 0)
                    rows.append(dict(supplier_id=r["supplier_id"], year=int(r["year"]), metric=r["metric"], value=v, currency=r["currency"],
                                     usd_rate=rate, usd=v * rate if rate else None, basis=r["basis"],
                                     source=f"{r['basis'].capitalize()}: {r['note']}. {r['source']}", parent=False))
        _c["foreign"] = rows
    return _c["foreign"]


def manual():
    _ddl()
    return [dict(r) for r in db.q("SELECT * FROM supplier_fin_manual ORDER BY supplier_id, year DESC, metric")]


def save_manual(sid, year, metric, value, currency, usd_rate, source, who):
    _ddl()
    db.x("INSERT OR REPLACE INTO supplier_fin_manual VALUES (?,?,?,?,?,?,?,?,?)", (sid, year, metric, value, currency, usd_rate, source, who, db.now()))


def delete_manual(sid, year, metric):
    _ddl()
    db.x("DELETE FROM supplier_fin_manual WHERE supplier_id=? AND year=? AND metric=?", (sid, year, metric))


def fin(sid):
    """{metric: {year: row}}; admin-entered figures win over SEC for the same metric-year."""
    out = {}
    for r in _sec():
        if r["supplier_id"] == sid:
            out.setdefault(r["metric"], {})[r["year"]] = r
    for r in _foreign():
        if r["supplier_id"] == sid:
            out.setdefault(r["metric"], {})[r["year"]] = r
    for r in manual():
        if r["supplier_id"] == sid:
            usd = r["value"] * (r["usd_rate"] or (1 if r["currency"] == "USD" else 0)) if r["value"] is not None else None
            out.setdefault(r["metric"], {})[r["year"]] = dict(r, usd=usd or None, parent=False)
    return out


def origin(r):
    """Where a figure came from: an admin entry, a company annual report (foreign seed) or an SEC 10-K filing."""
    return "Admin entry" if r.get("entered_by") is not None or r.get("entered") else "Annual report" if r.get("basis") else "SEC 10-K"


def coverage():
    """1.7.83 (Justin 11-19, "Supplier financials are empty"): what is on file for every supplier, for Admin > Supplier financials."""
    out = []
    for e in ENTITIES:
        f = fin(e[0])
        rows = [r for m in f.values() for r in m.values()]
        yrs = sorted({r["year"] for r in rows})
        sm = summary(e[0]) if rows else {}
        out.append(dict(sid=e[0], name=e[1], owner=e[2], country=e[3], listing=e[4], n=len(rows), y0=yrs[0] if yrs else None,
                        y1=yrs[-1] if yrs else None, origins=sorted({origin(r) for r in rows}), metrics=len(f), year=sm.get("year"),
                        revenue=sm.get("revenue"), rev_basis=sm.get("rev_basis"), note=SUBSIDIARY_OF.get(e[0])))
    return sorted(out, key=lambda r: (r["n"] == 0, -(r["revenue"] or 0), r["name"]))


def figures(sid):
    """Every figure on file for one supplier, newest year first, with its origin."""
    f = fin(sid)
    rows = [dict(r, metric=m, year=y, origin=origin(r)) for m, ys in f.items() for y, r in ys.items()]
    order = list(METRICS)
    return sorted(rows, key=lambda r: (-r["year"], order.index(r["metric"]) if r["metric"] in order else 99))


def _latest(series):
    ys = [y for y, r in series.items() if r.get("usd") is not None]
    return (max(ys), series[max(ys)]["usd"]) if ys else (None, None)


def summary(sid):
    f = fin(sid)
    rev_key = "rail_revenue" if f.get("rail_revenue") else "revenue"
    rev = f.get(rev_key, {})
    y, v = _latest(rev)
    growth = None
    if y and rev.get(y - 3, {}).get("usd"):
        growth = 100 * ((v / rev[y - 3]["usd"]) ** (1 / 3) - 1)
    oi = f.get("op_income", {}).get(y, {}).get("usd") if y else None
    full_rev = f.get("revenue", {}).get(y, {}).get("usd") if y else None
    by, bl = _latest(f.get("backlog", {}))
    return dict(year=y, revenue=v, rev_basis=rev_key, growth=growth, margin=100 * oi / full_rev if oi and full_rev else None,
                backlog=bl, backlog_year=by, parent=any(r.get("parent") for r in rev.values()))


def _match(name):
    n = (name or "").lower()
    for e in ENTITIES:
        if any(a in n for a in e[6]):
            return e[0]
    return None


def link(name):
    """Award analytics: the Supplier Intelligence page for an awardee name, or None when it isn't one of the tracked companies."""
    sid = _match(name)
    return f"/app/supplier-intel/{sid}" if sid else None


def installed_base():
    """{supplier_id: cars}, plus total, from fleet.db active fleets (passenger cars and locomotives)."""
    if "ib" in _c:
        return _c["ib"]
    out, tot = {}, 0
    try:
        rows = db.fq("SELECT manufacturer, sum(qty_active) n FROM v_fleet_profile GROUP BY manufacturer")
    except Exception:
        rows = []
    for r in rows:
        n = r["n"] or 0
        tot += n
        sid = _match(r["manufacturer"])
        if sid:
            out[sid] = out.get(sid, 0) + n
    _c["ib"] = (out, tot)
    return _c["ib"]


def awards(years=5):
    """{supplier_id: (count, usd)}, plus totals, from Bid Catcher awards (relevance >= 50) in the last `years` years."""
    out, tc, tu = {}, 0, 0.0
    try:
        rows = db.bq("SELECT vendor, vendor_norm, supplier_id, count(*) n, sum(amount_usd) usd FROM award WHERE relevance >= 50 AND vendor IS NOT NULL "
                     "AND award_date >= date('now', ?) GROUP BY vendor_norm, supplier_id", ("-%d years" % years,))
    except Exception:
        rows = []
    for r in rows:
        tc += r["n"]; tu += r["usd"] or 0
        sid = (r["supplier_id"] if r["supplier_id"] in ENT else None) or _match(r["vendor"]) or _match(r["vendor_norm"])
        if sid:
            c, u = out.get(sid, (0, 0.0))
            out[sid] = (c + r["n"], u + (r["usd"] or 0))
    return out, tc, tu


def segments(portal=None):
    return [s for s in SEGMENTS if portal is None or s[2] in ("both", portal)]


def league(seg):
    ib, ibt = installed_base()
    aw, _, awt = awards()
    rows = []
    for e in ENTITIES:
        if seg not in e[5]:
            continue
        s = summary(e[0])
        c, u = aw.get(e[0], (0, 0.0))
        rows.append(dict(id=e[0], name=e[1], owner=e[2], country=e[3], listing=e[4], **s,
                         ib=ib.get(e[0]), ib_share=100 * ib[e[0]] / ibt if ib.get(e[0]) and ibt else None,
                         awards=c, award_usd=u, award_share=100 * u / awt if u and awt else None))
    return sorted(rows, key=lambda r: (-(r["revenue"] or 0), -(r["ib"] or 0), -(r["award_usd"] or 0)))


def award_list(sid, n=25):
    e = ENT[sid]
    try:
        rows = db.bq("SELECT a.award_id, a.agency_id, a.award_date, a.vendor, a.supplier_id, a.title, a.amount_usd, a.category, coalesce(g.agency, a.buyer) agency, a.source_url "
                     "FROM award a LEFT JOIN agency g USING (agency_id) WHERE a.relevance >= 50 ORDER BY a.award_date DESC")
    except Exception:
        return []
    return [dict(r) for r in rows if r["supplier_id"] == sid or _match(r["vendor"]) == sid][:n]


def fleets(sid, n=40):
    try:
        rows = db.fq("SELECT fleet_id, operator_id, model_name, manufacturer, qty_active FROM v_fleet_profile ORDER BY qty_active DESC")
    except Exception:
        return []
    return [dict(r) for r in rows if _match(r["manufacturer"]) == sid][:n]
