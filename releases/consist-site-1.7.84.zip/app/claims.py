"""Live numbers for marketing copy, so every page states the same counts and prices. Copy uses tokens such as {agencies},
{fleets}, {prices}; fill() swaps them for the current values. Counts are rounded down ("over 130") so they stay true between refreshes."""
import re
import time

_cache = {"t": 0, "v": None}


def _over(n):
    n = int(n or 0)
    if n < 20:
        return str(n)
    step = 100 if n >= 1000 else 10
    base = n // step * step
    return f"over {base:,}" if base < n else f"{n:,}"


def freight_counts():
    """Freight railroads that ran in the latest full year on file: {'year', 'class1', 'others', 'total'} (see shortline.active_count).
    {} if the FRA data isn't loaded. 1.7.60: replaces the old count of every FRA code ever on file (601, shown as "600+"), which
    included railroads that had merged or stopped filing, tourist lines and each Class I subsidiary separately."""
    try:
        from . import shortline
        return shortline.active_count() or {}
    except Exception:
        return {}


def freight_railroads():
    """Total of freight_counts(), 0 if unavailable."""
    return (freight_counts() or {}).get("total", 0)


def short_lines_text():
    """'470+ regional and short line railroads' style phrase for copy, or 'regional and short line railroads' if unknown."""
    n = (freight_counts() or {}).get("others", 0)
    return f"{plus(n)} regional and short line railroads" if n else "regional and short line railroads"


# The old hardcoded claim, as it may still sit in Admin-edited copy (Settings > Home page freight text).
OLD_FREIGHT_RX = re.compile(r"\b600\+? (?:regional and )?short[- ]lines?(?: railroads)?|\b(?:other )?600\+? freight railroads", re.I)


def fix_freight(text):
    """Swap the {short_lines} token, and any leftover "600+ ... railroads" claim, for the live phrase."""
    if not text:
        return text
    t = str(text)
    if "{short_lines}" in t or OLD_FREIGHT_RX.search(t):
        phrase = short_lines_text()
        t = OLD_FREIGHT_RX.sub(phrase, t.replace("{short_lines}", phrase))
    return t


def plus(n):
    """473 -> '470+', 4,541 -> '4,500+': a round floor for a headline count (tens under 1,000, so it doesn't undersell by 15%)."""
    n = int(n or 0)
    if n < 20:
        return str(n)
    step = 100 if n >= 1000 else 10
    base = n // step * step
    return f"{base:,}+" if base < n else f"{n:,}"


def cents(v):
    return f"${(v or 0) / 100:,.0f}"


def _price(p):
    if p.get("contact_only"):
        return f"{p['name']} from {cents(p['price_year'])} a year" if p.get("price_year") else f"{p['name']} on request"
    if not p.get("price_month"):
        return "a free plan" if p["name"].strip().lower() in ("free", "free plan") else f"a free {p['name']} plan"
    return f"{p['name']} at {cents(p['price_month'])} a month" + (f" for {p['seats']} seats" if (p.get("seats") or 1) > 1 else "")


def _short(p):
    if p.get("contact_only"):
        return f"{p['name']} from {cents(p['price_year'])}/yr" if p.get("price_year") else f"{p['name']} on request"
    if not p.get("price_month"):
        return "Free"
    seats = p.get("seats") or 1
    return f"{p['name']} {cents(p['price_month'])}/mo" + (f" ({seats} seats)" if seats > 1 else "")


def price_line(plans):
    """Every active plan as one line: passenger plans, then freight and the all-rail plan (once the portal is open), then plans on request:
    'Free · Pro $99/mo · Team $450/mo (5 seats) · Freight Analyst $79/mo · ...'. Read live from the plan rows."""
    from . import db
    rail_open = db.settings().get("rail_open") == "1"
    sell = [p for p in plans if not p.get("contact_only")]
    pas = [p for p in sell if db.plan_line(p) == "passenger"]
    fr = [p for p in sell if db.plan_line(p) == "freight"] if rail_open else []
    both = [p for p in sell if db.plan_line(p) == "master"] if rail_open else []
    other = [p for p in plans if p.get("contact_only")]
    return " · ".join(_short(p) for p in pas + fr + both + other)


def reset():
    """Drop the cached values, e.g. after a plan's price changes in Admin > Plans."""
    _cache.update(t=0, v=None)


def values():
    if _cache["v"] and time.time() - _cache["t"] < 600:
        return _cache["v"]
    from . import data, db
    try:
        bs, fs = data.bid_stats(), data.fleet_stats(scoped=False)
    except Exception:
        bs, fs = {}, {}
    plans = db.plans()
    paid = [p for p in plans if p.get("price_month") and not p.get("contact_only")]
    free = next((p for p in plans if not p.get("price_month") and not p.get("contact_only")), None)
    v = {"agencies": _over(bs.get("agencies")), "fleets": _over(fs.get("fleets")), "operators": _over(fs.get("operators")),
         "cars": _over(fs.get("cars")), "prices": ", ".join(_price(p) for p in plans),
         "prices_short": ", ".join(["free"] + [f"{p['name']} {cents(p['price_month'])}/mo" for p in paid]),
         "top_price": cents(max((p["price_month"] for p in paid), default=0)),
         "price_line": price_line(plans),
         "low_year": cents(min((p["price_year"] for p in paid if p.get("price_year")), default=0)),
         "high_price": str(max((p["price_month"] for p in paid), default=0) // 100), "offer_count": str(len(plans)),
         "free_plan": free["name"] if free else "Free",
         "free_includes": "; ".join(free.get("bullets") or []) if free else ""}
    _cache.update(t=time.time(), v=v)
    return v


def fill(text):
    if not text or "{" not in str(text):
        return text
    v = values()
    return re.sub(r"\{(\w+)\}", lambda m: v.get(m.group(1), m.group(0)), str(text))


def fill_all(obj):
    """fill() through nested lists, tuples and dicts of strings."""
    if isinstance(obj, str):
        return fill(obj)
    if isinstance(obj, dict):
        return {k: fill_all(x) for k, x in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(fill_all(x) for x in obj)
    return obj


# Stored CMS pages: hard counts of agencies become the live token (applied once by content.seed_pages).
AGENCY_RX = re.compile(r"\b(?:over |more than |nearly |about )?\d{2,3}\+?( US and Canadian)?( rail| transit)? agencies")


def tokenize_agencies(text):
    return AGENCY_RX.sub(lambda m: "{agencies}" + (m.group(1) or "") + (m.group(2) or "") + " agencies", text or "")
