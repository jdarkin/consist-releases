"""Bot protection for self-serve sign-up (1.7.47, Justin 11-16: "prevent bots from creating accounts"). No paid services.

Layers, each set in Admin > Settings > General > Sign-up protection:
  1. Hidden trap field: the form's "website" box is hidden from people; bots that fill every field are turned away.
  2. Minimum fill time: the form carries a signed time stamp; a post sooner than signup_min_secs (default 3) after the page
     loaded, or a stamp that is missing, forged or over a day old, is refused.
  3. Per-network limits: 5 sign-ups per ten minutes (existing) and signup_daily_ip (default 10) per day from one address.
  4. Throwaway email domains (signup_block_disposable): known disposable inbox services are refused.
  5. Email confirmation (signup_verify, on by default): the account is created as 'unconfirmed' and opens only when the link
     we email is clicked (48 hours; the login page can send a new one). Unconfirmed accounts can't sign in or use anything.
  6. Cloudflare Turnstile (turnstile_on, off by default; free): a privacy-friendly challenge on the sign-up form. Needs the site
     key (setting) and the secret key (integrations, TURNSTILE_SECRET) from the Cloudflare dashboard.
Every refusal is logged in signup_block (Admin > Settings shows the latest), with the address and reason, never the password."""
import hashlib
import hmac
import time

from . import config, db

DEFAULTS = {"signup_verify": "1", "signup_min_secs": "3", "signup_daily_ip": "10", "signup_block_disposable": "1",
            "turnstile_on": "0", "turnstile_site_key": ""}
REASONS = {"trap": "Hidden trap field filled", "fast": "Form sent too fast", "stamp": "Missing or bad form stamp",
           "burst": "Over 5 sign-ups in 10 minutes from one network", "daily": "Over the daily sign-up limit for one network",
           "disposable": "Throwaway email domain", "turnstile": "Failed the Turnstile check"}
# Common disposable inbox services (not exhaustive; the other layers catch the rest).
DISPOSABLE = {
    "mailinator.com", "guerrillamail.com", "guerrillamail.net", "guerrillamail.org", "sharklasers.com", "grr.la", "10minutemail.com",
    "10minutemail.net", "tempmail.com", "temp-mail.org", "temp-mail.io", "tempmailo.com", "tempr.email", "throwawaymail.com",
    "yopmail.com", "yopmail.net", "trashmail.com", "trashmail.de", "getnada.com", "nada.email", "dispostable.com", "maildrop.cc",
    "mailnesia.com", "mintemail.com", "mohmal.com", "fakeinbox.com", "emailondeck.com", "spamgourmet.com", "mailcatch.com",
    "moakt.com", "burnermail.io", "inboxkitten.com", "tmail.ws", "tmpmail.org", "tmpmail.net", "minuteinbox.com", "discard.email",
    "spambox.us", "trbvm.com", "byom.de", "33mail.com", "mytemp.email", "emailfake.com", "crazymailing.com", "1secmail.com",
    "1secmail.net", "1secmail.org", "linshiyouxiang.net", "mail.tm", "mailpoof.com", "dropmail.me", "anonaddy.me",
}


def setting(s, k):
    return s.get(k, DEFAULTS.get(k, ""))


def _sig(ts):
    return hmac.new(config.SECRET_KEY.encode(), f"signup:{ts}".encode(), hashlib.sha256).hexdigest()[:24]


def stamp():
    """The signed time stamp the sign-up form carries (hidden field 'fs')."""
    ts = str(int(time.time()))
    return f"{ts}.{_sig(ts)}"


def _stamp_age(v):
    try:
        ts, sig = (v or "").split(".", 1)
        if not hmac.compare_digest(sig, _sig(ts)):
            return None
        return time.time() - int(ts)
    except (ValueError, TypeError):
        return None


def disposable(email):
    dom = (email or "").rsplit("@", 1)[-1].lower()
    return any(dom == d or dom.endswith("." + d) for d in DISPOSABLE)


def daily_count(ip):
    r = db.q("SELECT count(*) n FROM audit WHERE action = 'signup' AND actor = ? AND ts >= ?",
             (f"ip:{ip}", time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - 86400))), one=True)
    return r["n"] if r else 0


def check(request, form_stamp, trap, email, turnstile_token=""):
    """The reason key this sign-up is refused, or None. The 10-minute burst limit stays in routes_public (auth.spend)."""
    from . import auth
    s = db.settings()
    ip = auth.client_ip(request)
    if trap:
        return "trap"
    age = _stamp_age(form_stamp)
    if age is None or age > 86400:
        return "stamp"
    try:
        min_secs = max(0, int(setting(s, "signup_min_secs") or 0))
    except ValueError:
        min_secs = 3
    if age < min_secs:
        return "fast"
    try:
        cap = int(setting(s, "signup_daily_ip") or 0)
    except ValueError:
        cap = 10
    if cap and daily_count(ip) >= cap:
        return "daily"
    if setting(s, "signup_block_disposable") == "1" and disposable(email):
        return "disposable"
    if turnstile_ready(s) and not turnstile_ok(turnstile_token, ip):
        return "turnstile"
    return None


def turnstile_ready(s=None):
    s = s if s is not None else db.settings()
    return setting(s, "turnstile_on") == "1" and bool(setting(s, "turnstile_site_key")) and bool(getattr(config, "TURNSTILE_SECRET", ""))


def turnstile_ok(token, ip):
    """Cloudflare's siteverify answer. A network failure lets the sign-up through (the other layers still apply)."""
    if not token:
        return False
    try:
        import httpx
        r = httpx.post("https://challenges.cloudflare.com/turnstile/v0/siteverify",
                       data={"secret": config.TURNSTILE_SECRET, "response": token, "remoteip": ip}, timeout=8)
        return bool(r.json().get("success"))
    except Exception:
        return True


def log(request, email, reason):
    from . import auth
    try:
        db.x("INSERT INTO signup_block (ts, ip, email, reason) VALUES (?,?,?,?)", (db.now(), auth.client_ip(request), (email or "")[:200], reason))
    except Exception:
        pass


def recent(limit=30):
    try:
        rows = [dict(r) for r in db.q("SELECT * FROM signup_block ORDER BY id DESC LIMIT ?", (int(limit),))]
    except Exception:
        return [], {}
    for r in rows:
        r["why"] = REASONS.get(r["reason"], r["reason"])
    by = {r["reason"]: r["n"] for r in db.q("SELECT reason, count(*) n FROM signup_block WHERE ts >= ? GROUP BY 1",
                                            (time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - 30 * 86400)),))}
    return rows, {REASONS.get(k, k): v for k, v in by.items()}


def unconfirmed_count():
    r = db.q("SELECT count(*) n FROM user WHERE status = 'unconfirmed'", one=True)
    return r["n"] if r else 0


def send_confirm(u, nxt="/app"):
    """Email the confirmation link (48 hours). The next page after confirming rides in the token's email column."""
    from . import auth, mailer
    tok = auth.make_token("confirm", u["id"], nxt if nxt.startswith("/app") else "/app", hours=48)
    site = db.settings().get("site_name") or "Consist"
    link = f"{config.SITE_URL}/confirm/{tok}"
    return mailer.send(u["email"], f"Confirm your email for {site}",
                       f"Welcome to {site}.\n\nConfirm your email to open your account:\n{link}\n\nThe link works for 48 hours. "
                       "If you didn't sign up, ignore this email and the account will never open.", personal=True)
