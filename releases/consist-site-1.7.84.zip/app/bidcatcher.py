"""Bid Catcher's configuration, edited from Admin > Bid Catcher.
Bid Catcher keeps it in its own config.json (data/bids/config.json in the fleet-db data folder) and rereads it every
cycle, so a change here applies without restarting the bid-monitor container. Registration status lives in bids.db
and is editable only when BIDS_DB_WRITABLE is set, like the bid sources page."""
import datetime
import json
import os
import re
import shutil
import smtplib
import ssl
from email.message import EmailMessage

from . import config, db

MODES = [("immediate", "Immediately"), ("daily", "Daily digest"), ("weekly", "Weekly digest"), ("off", "Off")]
STATUSES = ["todo", "submitted", "verify_pending", "verified", "active", "skipped"]
COUNTRIES = [("US", "US bids"), ("CA", "Canadian bids")]
# relevance.CATEGORIES in Bid Catcher, in its order
CATEGORIES = ["overhaul_program", "component_repair", "parts_supply", "maintenance_services", "onboard_systems", "shop_equipment",
              "cleaning_interior", "vehicle_procurement", "engineering_support", "track_infrastructure", "signals_communications",
              "traction_power", "stations_facilities", "rail_operations", "rail_engineering", "other"]
EMAIL = re.compile(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$")
SUB_KEYS = ("name", "email", "mode", "min_score", "countries", "agencies", "categories", "keywords", "include_bus", "awards", "admin", "active")
# bidcore.DEFAULTS
DEFAULT_SUB = {"name": "", "email": "", "mode": "immediate", "min_score": 60, "countries": ["US", "CA"], "agencies": [],
               "categories": [], "keywords": [], "include_bus": False, "awards": True, "admin": False, "active": True}
GENERAL = {"digest_time": "07:00", "max_usd_per_day": 2.0, "auto_verify": True, "page_watch": True, "open_data": True}
MAIL = {"address": "bidcatcher@echoreel.net", "from_name": "Bid Catcher", "imap_host": "imap.ionos.com", "imap_port": 993,
        "smtp_host": "smtp.ionos.com", "smtp_port": 587, "folder": "INBOX"}
# bidcore.DEFAULTS["sender"]: alert emails come from this account once its password file exists, else from MAIL
SENDER = {"address": "opportunity@consist-na.com", "from_name": "Consist Opportunities", "reply_to": "", "smtp_host": "smtp.ionos.com",
          "smtp_port": 587}
SENDER_PW = "sender_password.txt"
# (key, label, server default, kind, help). Blank in the form = use the server's setting (docker-compose env, then this default).
SCHEDULE = [
    ("mail_minutes", "Check the bids mailbox every (minutes)", "15", "int", ""),
    ("scan_time", "Daily scan time (open data and agency pages)", "06:15", "time", "24-hour time, server time zone (America/New_York)."),
    ("awards_schedule", "Awards research schedule", "1st Tue 08:00", "monthly", "Monthly, e.g. <code>1st Tue 08:00</code>. <code>off</code> stops it."),
    ("awards_max_usd", "Awards research cap per run (USD)", "4", "float", ""),
    ("awards_batch", "Agencies per awards research batch", "10", "int", ""),
    ("awards_batch_usd", "Cap per awards batch (USD)", "1.0", "float", ""),
    ("budgets_schedule", "Funding collector schedule (board minutes, capital plans, FTA grants)", "Sat 08:00", "weekly",
     "Weekly, e.g. <code>Sat 08:00</code>. <code>off</code> stops it."),
    ("budgets_max_usd", "Funding collector cap per run (USD)", "3", "float", ""),
    ("budgets_discover_usd", "Of which, finding new agency pages (USD)", "0.8", "float", ""),
    ("budgets_docs_per_page", "Documents read per listing page", "3", "int", ""),
]
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def path():
    return config.BIDS_CONFIG


def folder():
    return os.path.dirname(path())


def available():
    """(ok, reason): whether the site can see and write Bid Catcher's settings folder."""
    d = folder()
    if not os.path.isdir(d):
        return False, f"Bid Catcher's settings folder isn't mounted here ({d})."
    if not os.access(d, os.W_OK) or (os.path.exists(path()) and not os.access(path(), os.W_OK)):
        return False, "Bid Catcher's settings file is read-only from the site."
    return True, ""


def _raw():
    try:
        with open(path()) as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


def _write(raw):
    p = path()
    if os.path.exists(p):
        shutil.copy2(p, p + ".bak")
    tmp = p + ".site.tmp"
    with open(tmp, "w") as f:
        json.dump(raw, f, indent=2)
    os.replace(tmp, p)


def load():
    """Effective settings, as Bid Catcher sees them (config.json over its defaults)."""
    try:
        raw = _raw()
    except (OSError, ValueError):
        raw = {}
    subs = raw.get("subscribers") or [{**DEFAULT_SUB, "name": "Admin", "admin": True}]
    mail = {**MAIL, **(raw.get("mail") or {})}
    mail.pop("password_file", None)
    mail["password_set"] = os.path.exists(os.path.join(folder(), "mail_password.txt"))
    sender = {**SENDER, **(raw.get("sender") or {})}
    sender.pop("password_file", None)
    sender["password_set"] = os.path.exists(os.path.join(folder(), SENDER_PW))
    return {"subscribers": [{**DEFAULT_SUB, **s} for s in subs], **{k: raw.get(k, v) for k, v in GENERAL.items()},
            "schedule": dict(raw.get("schedule") or {}), "mail": mail, "sender": sender}


# ---------- saving ----------

def save_alerts(subs):
    raw = _raw()
    raw["subscribers"] = subs
    _write(raw)


def save_general(vals):
    raw = _raw()
    raw.update(vals)
    _write(raw)


def save_schedule(vals):
    raw = _raw()
    sched = {k: v for k, v in vals.items() if v != ""}
    if sched:
        raw["schedule"] = sched
    else:
        raw.pop("schedule", None)
    _write(raw)


# ---------- form parsing ----------

def _lst(form, k):
    return [str(v) for v in form.getlist(k) if str(v).strip()]


def parse_alerts(form):
    """Returns (subscribers, errors). The last row index is the blank 'add a recipient' row."""
    subs, errors = [], []
    n = int(form.get("n") or 0)
    for i in range(n + 1):
        p = f"s{i}_"
        email, name = str(form.get(p + "email", "")).strip(), str(form.get(p + "name", "")).strip()
        if (i == n and not email) or form.get(p + "remove"):
            continue
        if not EMAIL.match(email):
            errors.append(f"'{email or name or 'row ' + str(i + 1)}' isn't a valid email address.")
            continue
        mode = form.get(p + "mode", "immediate")
        try:
            score = max(0, min(100, int(form.get(p + "min_score") or 60)))
        except ValueError:
            score = 60
        subs.append({"name": name, "email": email, "mode": mode if mode in dict(MODES) else "immediate", "min_score": score,
                     "countries": [c for c in _lst(form, p + "countries") if c in dict(COUNTRIES)],
                     "agencies": _lst(form, p + "agencies"),
                     "categories": [c for c in _lst(form, p + "categories") if c in CATEGORIES],
                     "keywords": [k.strip() for k in str(form.get(p + "keywords", "")).split(",") if k.strip()],
                     "include_bus": bool(form.get(p + "include_bus")), "awards": bool(form.get(p + "awards")),
                     "admin": bool(form.get(p + "admin")), "active": bool(form.get(p + "active"))})
    if not subs and not errors:
        errors.append("Keep at least one recipient. Set it to Off instead of removing it.")
    return subs, errors


def parse_general(form):
    errors = []
    t = str(form.get("digest_time", "")).strip() or "07:00"
    if not HHMM.match(t):
        errors.append("Digest time needs to be HH:MM.")
    try:
        usd = max(0.0, float(form.get("max_usd_per_day") or 0))
    except ValueError:
        usd = 0.0
        errors.append("The daily spend cap needs to be a number.")
    return {"digest_time": t, "max_usd_per_day": usd, "auto_verify": bool(form.get("auto_verify")),
            "page_watch": bool(form.get("page_watch")), "open_data": bool(form.get("open_data"))}, errors


def _valid(kind, v):
    if v == "off" and kind in ("monthly", "weekly"):
        return True
    p = v.split()
    if kind == "time":
        return bool(HHMM.match(v))
    if kind == "monthly":
        return len(p) == 3 and p[0] in ("1st", "2nd", "3rd", "4th") and p[1] in DAYS and bool(HHMM.match(p[2]))
    if kind == "weekly":
        return len(p) == 2 and p[0] in DAYS and bool(HHMM.match(p[1]))
    try:
        x = int(v) if kind == "int" else float(v)
    except ValueError:
        return False
    return x >= (1 if kind == "int" else 0)


def parse_schedule(form):
    vals, errors = {}, []
    for k, label, _, kind, _ in SCHEDULE:
        v = " ".join(str(form.get(k, "")).split())
        if v and not _valid(kind, v):
            errors.append(f"{label}: '{v}' isn't valid.")
        vals[k] = v
    return vals, errors


# ---------- bids.db (read-only unless BIDS_DB_WRITABLE) ----------

def agencies():
    return db.bq("SELECT agency_id, agency, country FROM agency ORDER BY country DESC, agency") or []


def registrations():
    return db.bq("SELECT * FROM registration ORDER BY status = 'active', status = 'verified', platform") or []


def runs(limit=15):
    return db.bq("SELECT started, task, status, found, new, cost_usd, message FROM run_log ORDER BY id DESC LIMIT ?", (limit,)) or []


def spent_today():
    r = db.bq("SELECT coalesce(sum(cost_usd), 0) v FROM run_log WHERE started >= ?",
              (datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d"),), one=True)
    return float(r["v"]) if r else 0.0


def set_registration(key, status, notes=None):
    if status not in STATUSES:
        raise ValueError("Unknown status.")
    c = db.bids_rw()
    try:
        if notes is None:
            c.execute("UPDATE registration SET status = ?, updated = ? WHERE account_key = ?", (status, db.now(), key))
        else:
            c.execute("UPDATE registration SET status = ?, notes = ?, updated = ? WHERE account_key = ?", (status, notes[:500], db.now(), key))
        c.commit()
    finally:
        c.close()


# ---------- mailbox ----------

def save_sender(vals, password=""):
    """Alert sender address and name; a new password (typed in Admin, never shown back) replaces the password file."""
    raw = _raw()
    raw["sender"] = {**(raw.get("sender") or {}), **vals}
    _write(raw)
    if password:
        p = os.path.join(folder(), SENDER_PW)
        fd = os.open(p + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(password)
        os.replace(p + ".tmp", p)
        os.chmod(p, 0o600)


def parse_sender(form):
    vals, errors = {}, []
    address, reply_to = str(form.get("address", "")).strip(), str(form.get("reply_to", "")).strip()
    if not EMAIL.match(address):
        errors.append(f"'{address}' isn't a valid sender address.")
    if reply_to and not EMAIL.match(reply_to):
        errors.append(f"'{reply_to}' isn't a valid Reply-To address.")
    host = str(form.get("smtp_host", "")).strip() or SENDER["smtp_host"]
    try:
        port = int(form.get("smtp_port") or SENDER["smtp_port"])
    except ValueError:
        port, _ = 0, errors.append("SMTP port must be a number (587 or 465).")
    vals.update(address=address, reply_to=reply_to, smtp_host=host, smtp_port=port,
                from_name=str(form.get("from_name", "")).strip()[:80] or SENDER["from_name"])
    return vals, errors


def test_email(to):
    """Sends a test the way Bid Catcher sends alerts: from the Consist sender once its password is set, else the bids mailbox."""
    s = load()
    m, pw_file = s["sender"], os.path.join(folder(), SENDER_PW)
    if not m["password_set"]:
        m, pw_file = s["mail"], os.path.join(folder(), "mail_password.txt")
    if not os.path.exists(pw_file):
        raise ValueError("The sending mailbox's password file is missing on the server.")
    with open(pw_file) as f:
        password = f.read().strip()
    msg = EmailMessage()
    msg["From"] = f"{m.get('from_name') or 'Consist Opportunities'} <{m['address']}>"
    msg["To"] = to
    if m.get("reply_to"):
        msg["Reply-To"] = m["reply_to"]
    msg["Subject"] = "Consist bid alerts: test message"
    msg.set_content(f"This is a test from Consist Admin > Bid Catcher. Bid alerts will come from {m['address']}.")
    from . import mailer
    ctx = ssl.create_default_context()
    try:
        if int(m["smtp_port"]) == 465:
            with smtplib.SMTP_SSL(m["smtp_host"], 465, context=ctx, timeout=60) as smtp:
                smtp.login(m["address"], password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(m["smtp_host"], int(m["smtp_port"]), timeout=60) as smtp:
                smtp.starttls(context=ctx)
                smtp.login(m["address"], password)
                smtp.send_message(msg)
    except Exception as ex:
        mailer.record(to, msg["Subject"], "Bid Catcher mailbox test", m["address"], "failed", f"{type(ex).__name__}: {ex}")  # 1.7.81
        raise
    mailer.record(to, msg["Subject"], "Bid Catcher mailbox test", m["address"], "sent")
    return m["address"]


# ---------- admin-run tasks (permission requests, hand checks, queued actions, feeds, sign-ups) ----------
# The site never sends mail for these: it writes rows to bids.db (permission_request, admin_action, hand_check) and keys in
# config.json, and the bid-monitor daemon acts on them within about 30 seconds. The tables appear once Bid Catcher runs the
# new code, so every read is guarded.

PERM_STATUSES = ["draft", "approved", "sent", "granted", "declined", "needs_human", "enabled", "closed"]
ACTIONS = {"coverage": "Coverage report", "checklist": "Hand-check list", "checklist_checked": "Hand check recorded",
           "rescore": "Re-score notices", "test_email": "Test email", "scan": "Scan now", "permission_seed": "Create missing drafts",
           "permission_enable": "Enable source", "permission_replies": "Check replies", "federal_history": "Load federal contract history",
           "retag": "Re-tag subsystems"}
SAM_NAICS_DEFAULT = ["336510", "488210", "811310", "485112"]
BUSINESS = [("Company", "Sand and Style, LLC"), ("Address", "13 Emerald Lake Ct, Palm Coast FL 32137"), ("Phone", "(321) 291-3280"),
            ("Email", "bidcatcher@echoreel.net")]  # the FEIN stays in the private registration kit, never on the site, never on the site
NAICS = [("336510", "Railroad Rolling Stock Manufacturing"), ("488210", "Support Activities for Rail Transportation"),
         ("811310", "Commercial and Industrial Machinery and Equipment Repair and Maintenance"),
         ("423860", "Transportation Equipment and Supplies (except Motor Vehicle) Merchant Wholesalers"),
         ("333415", "Air-Conditioning, Warm Air Heating and Commercial Refrigeration Equipment Manufacturing"),
         ("335312", "Motor and Generator Manufacturing"), ("541330", "Engineering Services"),
         ("237990", "Other Heavy and Civil Engineering Construction (track, rail infrastructure)"),
         ("238210", "Electrical Contractors (traction power, signals, catenary)"),
         ("334290", "Other Communications Equipment Manufacturing (railway signals)"), ("485112", "Commuter Rail Systems")]
KEYWORDS = ["rail car", "railcar", "light rail vehicle", "LRV", "rolling stock", "locomotive", "overhaul", "mid-life", "midlife",
            "truck overhaul", "wheel set", "wheelset", "traction motor", "propulsion", "HVAC rail", "door operator", "coupler",
            "brake rail", "pantograph", "passenger information system", "event recorder", "wheel truing", "car wash", "streetcar",
            "subway car", "commuter rail", "matériel roulant", "voitures de métro",
            "light rail", "track rehabilitation", "special trackwork", "catenary", "overhead contact system", "traction power",
            "signal system", "train control", "CBTC", "positive train control", "grade crossing", "rail station", "rail yard",
            "rail maintenance facility", "rail operations", "rail engineering", "ferroviaire"]


def _rows(sql, args=()):
    """Rows from bids.db, or None when the table isn't there yet (Bid Catcher not updated)."""
    try:
        return [dict(r) for r in db.bq(sql, args)]
    except Exception:
        return None


def _rw(sql, args=()):
    c = db.bids_rw()
    try:
        cur = c.execute(sql, args)
        c.commit()
        return cur.rowcount
    finally:
        c.close()


def permission_rows():
    return _rows("SELECT * FROM permission_request ORDER BY CASE status WHEN 'needs_human' THEN 0 WHEN 'granted' THEN 1 WHEN 'draft' THEN 2 "
                 "WHEN 'approved' THEN 3 WHEN 'sent' THEN 4 ELSE 5 END, kind DESC, label")


def save_draft(pid, to_addr, subject, body):
    to_addr = to_addr.strip()
    if to_addr and not EMAIL.match(to_addr):
        raise ValueError(f"'{to_addr}' isn't a valid email address.")
    return _rw("UPDATE permission_request SET to_addr = ?, subject = ?, body = ?, updated = ? WHERE id = ? AND status = 'draft'",
               (to_addr, subject.strip()[:300], body.strip()[:8000], db.now(), pid))


def approve(ids, who):
    """Mark ticked drafts that have an address as approved. Bid Catcher sends them, one every 3 minutes."""
    n = 0
    for pid in ids:
        n += _rw("UPDATE permission_request SET status = 'approved', approved_by = ?, approved_at = ?, updated = ? "
                 "WHERE id = ? AND status = 'draft' AND coalesce(to_addr, '') != ''", (who, db.now(), db.now(), pid))
    return n


def set_perm_status(pid, status, who):
    if status not in ("declined", "closed"):
        raise ValueError("Unknown status.")
    return _rw("UPDATE permission_request SET status = ?, decided_by = ?, decided_at = ?, updated = ? WHERE id = ?",
               (status, who, db.now(), db.now(), pid))


def queue(action, args, who):
    if action not in ACTIONS:
        raise ValueError("Unknown action.")
    c = db.bids_rw()
    try:
        cur = c.execute("INSERT INTO admin_action (action, args, requested_by, requested, status) VALUES (?,?,?,?, 'queued')",
                        (action, json.dumps(args or {}), who, db.now()))
        c.commit()
        return cur.lastrowid
    finally:
        c.close()


def action_rows(limit=20):
    rows = _rows("SELECT * FROM admin_action ORDER BY id DESC LIMIT ?", (limit,))
    for r in rows or []:
        r["label"] = ACTIONS.get(r["action"], r["action"])
        try:
            r["args_d"] = json.loads(r["args"] or "{}")
        except ValueError:
            r["args_d"] = {}
    return rows


def _blocked(err):
    e = (err or "").lower()
    return "robots" in e or "403" in e or "401" in e


def hand_checks():
    """Pages Bid Catcher may not read (robots.txt, a bot wall or a login), with the last hand check of each."""
    pages = _rows("SELECT p.url, p.agency_id, a.agency, p.last_error FROM page_watch p LEFT JOIN agency a USING(agency_id) "
                  "WHERE p.kind IN ('solicitations', 'awards') ORDER BY p.agency_id")
    if pages is None:
        return None
    last = {}
    for h in _rows("SELECT url, checked, note FROM hand_check ORDER BY checked") or []:
        last[h["url"]] = h
    out = []
    for p in pages:
        if not _blocked(p["last_error"]):
            continue
        h = last.get(p["url"]) or {}
        out.append({**p, "agency": p["agency"] or p["agency_id"], "checked": (h.get("checked") or "")[:10], "note": h.get("note") or "",
                    "why": "blocked by robots.txt" if "robots" in (p["last_error"] or "").lower() else "refuses automated readers"})
    return out


def record_check(url, agency_id, note):
    return _rw("INSERT INTO hand_check (url, agency_id, checked, note) VALUES (?,?,?,?)", (url, agency_id, db.now(), (note or "nothing new")[:500]))


def feeds():
    try:
        f = dict(_raw().get("feeds") or {})
    except (OSError, ValueError):
        f = {}
    f.setdefault("rss", [])
    f.setdefault("permissions", {})
    f.setdefault("sam_naics", SAM_NAICS_DEFAULT)
    f["sam_key_set"] = os.path.exists(os.path.join(folder(), "sam_api_key.txt"))
    return f


def save_feeds(**changes):
    """Set (or, with None, remove) keys under config.json "feeds"."""
    raw = _raw()
    f = raw.setdefault("feeds", {})
    for k, v in changes.items():
        if v is None:
            f.pop(k, None)
        else:
            f[k] = v
    _write(raw)


def remove_permission(host):
    raw = _raw()
    (raw.setdefault("feeds", {}).get("permissions") or {}).pop(host, None)
    _write(raw)


def parse_rss(form):
    rows, errors = [], []
    for i in range(int(form.get("rss_n") or 0) + 1):
        url, aid, basis = (form.get(f"rss{i}_url") or "").strip(), (form.get(f"rss{i}_agency") or "").strip(), (form.get(f"rss{i}_basis") or "").strip()
        if form.get(f"rss{i}_remove") or not url:
            continue
        if not url.lower().startswith(("http://", "https://")):
            errors.append(f"'{url}' isn't a web address.")
        if not basis:
            errors.append(f"Add the basis for {url} (why we may read it). Bid Catcher skips feeds without one.")
        rows.append({"url": url, "agency_id": aid, "basis": basis[:300]})
    return rows, errors


def save_sam_key(key):
    p = os.path.join(folder(), "sam_api_key.txt")
    fd = os.open(p + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(key.strip())
    os.replace(p + ".tmp", p)
    os.chmod(p, 0o600)


def remove_sam_key():
    p = os.path.join(folder(), "sam_api_key.txt")
    if os.path.exists(p):
        os.remove(p)


SIGNUP_GROUPS = [("todo", "To do", ("todo", "")), ("waiting", "Submitted, waiting on agency", ("submitted", "verify_pending")),
                 ("done", "Done", ("active", "verified")), ("skip", "No account needed", ("skipped",))]


def signup_groups():
    regs = registrations()
    out = []
    for key, label, sts in SIGNUP_GROUPS:
        out.append((key, label, [r for r in regs if (r["status"] or "") in sts]))
    known = {s for _, _, sts in SIGNUP_GROUPS for s in sts}
    other = [r for r in regs if (r["status"] or "") not in known]
    if other:
        out[0] = (out[0][0], out[0][1], out[0][2] + other)
    return out
