"""Cost escalation (price adjustment) and index forecasting for freight and passenger rail equipment and services.

Series: BLS PPI / ECI / CPI (seed/bls_index.csv.gz, tools/escalation/build_bls.py), STB RCAF and the AAR monthly
railroad fuel index (costidx seeds; AAR values are shown as published index values with credit, never redistributed as tables).
Forecasts: three simple methods on log index values, each backtested on every month since 2010 using only data known at that
time. The method with the lowest backtest error is used per series, and forecast ranges come from that method's own past errors,
so a "90% range" means 90% of past forecasts at that horizon landed inside it."""
import bisect, csv, gzip, math, os

from . import costidx

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEED = os.path.join(HERE, "seed")

# id: (short label, description, frequency months, source, segments)
SERIES = {
    "ECI_MFG": ("Labor: manufacturing", "BLS Employment Cost Index, total compensation, private industry, manufacturing (CIU2013000000000I). Wages and benefits of railcar builders and overhaul shops.", 3, "BLS", "both"),
    "ECI_TRN": ("Labor: transportation", "BLS Employment Cost Index, total compensation, private industry, transportation and warehousing (CIU2014300000000I). Operating and maintenance labor.", 3, "BLS", "both"),
    "PPI_RS": ("Rolling stock manufacturing", "BLS Producer Price Index, railroad rolling stock manufacturing, NAICS 336510 (PCU336510336510). Prices railcar and locomotive builders get.", 1, "BLS", "both"),
    "PPI_RREQ": ("Railroad equipment", "BLS Producer Price Index, commodity group railroad equipment (WPU144): cars, locomotives and parts.", 1, "BLS", "both"),
    "PPI_RAILSVC": ("Line-haul rail service", "BLS Producer Price Index, line-haul railroads (PCU482111482111): the price of freight rail transportation.", 1, "BLS", "freight"),
    "PPI_IRONSTEEL": ("Iron and steel", "BLS Producer Price Index, iron and steel (WPU101).", 1, "BLS", "both"),
    "PPI_STEEL": ("Steel mill products", "BLS Producer Price Index, steel mill products (WPU1017): plate, sheet, bar. Wheels, axles, carbodies, frames.", 1, "BLS", "both"),
    "PPI_ALUM": ("Aluminum mill shapes", "BLS Producer Price Index, aluminum mill shapes (WPU102501). Carbodies and extrusions.", 1, "BLS", "both"),
    "PPI_WIRE": ("Copper wire and cable", "BLS Producer Price Index, nonferrous wire and cable (WPU1026). Car wiring, traction cable.", 1, "BLS", "both"),
    "PPI_ELEC": ("Electrical equipment", "BLS Producer Price Index, electrical machinery and equipment (WPU117). Propulsion, controls, passenger information.", 1, "BLS", "both"),
    "PPI_XFMR": ("Transformers", "BLS Producer Price Index, transformers and power regulators (WPU1174). Traction transformers and converters.", 1, "BLS", "both"),
    "PPI_HVAC": ("HVAC equipment", "BLS Producer Price Index, air conditioning and refrigeration equipment (WPU1148).", 1, "BLS", "both"),
    "PPI_DIESEL": ("Diesel fuel (producer)", "BLS Producer Price Index, No. 2 diesel fuel (WPU057303).", 1, "BLS", "both"),
    "ECI_CON": ("Labor: construction", "BLS Employment Cost Index, total compensation, private industry, construction (CIU2012300000000I). Track, bridge and civil crews.", 3, "BLS", "both"),
    "PPI_CONC": ("Concrete products", "BLS Producer Price Index, concrete products (WPU133): ready-mix, precast, block and pipe. Concrete ties, platforms, bridges, culverts.", 1, "BLS", "both"),
    "PPI_AGG": ("Ballast and aggregates", "BLS Producer Price Index, construction sand, gravel and crushed stone (WPU1321). Ballast, subballast and fill.", 1, "BLS", "both"),
    "PPI_STRUCT": ("Fabricated structural steel", "BLS Producer Price Index, fabricated structural metal products (WPU107). Bridge girders, catenary structures, canopies.", 1, "BLS", "both"),
    "PPI_HRSTEEL": ("Hot rolled bars, plates, shapes", "BLS Producer Price Index, hot rolled bars, plates and structural shapes (WPU101704). Rail-adjacent steel, plate and shapes.", 1, "BLS", "both"),
    "PPI_TIES": ("Treated wood (crossties)", "BLS Producer Price Index, treated wood and contract wood preserving (WPU087101). Timber crossties and bridge timber.", 1, "BLS", "both"),
    "PPI_CONEQ": ("Construction machinery", "BLS Producer Price Index, construction machinery and equipment (WPU112). Contractor and maintenance-of-way equipment ownership.", 1, "BLS", "both"),
    "PPI_PAVE": ("Asphalt paving mixtures", "BLS Producer Price Index, asphalt and tar paving mixtures and blocks (WPU1394). Grade crossings, access roads, parking.", 1, "BLS", "both"),
    "CPI": ("CPI-U", "BLS Consumer Price Index for all urban consumers, US city average, all items (CUUR0000SA0). General inflation.", 1, "BLS", "both"),
    "RCAF_UNADJ": ("RCAF (unadjusted)", "STB Rail Cost Adjustment Factor before productivity (4Q2022 = 1.000), quarterly. Railroad input prices.", 3, "STB / AAR", "freight"),
    "RCAF_ADJ": ("RCAF (adjusted)", "STB Rail Cost Adjustment Factor adjusted for railroad productivity, quarterly. The rate escalator in many rail contracts.", 3, "STB / AAR", "freight"),
    "AAR_FUEL": ("AAR railroad fuel index", "AAR Monthly Railroad Fuel Price Index (1990 = 100): diesel price railroads pay including taxes and handling.", 1, "AAR", "freight"),
}
BLS_ID = {"ECI_MFG": "CIU2013000000000I", "ECI_TRN": "CIU2014300000000I", "PPI_RS": "PCU336510336510", "PPI_RREQ": "WPU144",
          "PPI_RAILSVC": "PCU482111482111", "PPI_IRONSTEEL": "WPU101", "PPI_STEEL": "WPU1017", "PPI_ALUM": "WPU102501",
          "PPI_WIRE": "WPU1026", "PPI_ELEC": "WPU117", "PPI_XFMR": "WPU1174", "PPI_HVAC": "WPU1148", "PPI_DIESEL": "WPU057303",
          "CPI": "CUUR0000SA0",
          "ECI_CON": "CIU2012300000000I", "PPI_CONC": "WPU133", "PPI_AGG": "WPU1321", "PPI_STRUCT": "WPU107",
          "PPI_HRSTEEL": "WPU101704", "PPI_TIES": "WPU087101", "PPI_CONEQ": "WPU112", "PPI_PAVE": "WPU1394"}
CREDIT = ("Price and wage indexes: US Bureau of Labor Statistics (PPI, ECI, CPI). Rail Cost Adjustment Factor: Surface Transportation Board, "
          "computed by the Association of American Railroads. Fuel index: AAR Monthly Railroad Fuel Price Indexes. Forecasts are Consist estimates.")

# Starting baskets (weights in %). Typical shapes of rail equipment and service escalation clauses; users edit them.
PRESETS = {
    "passenger": [
        ("p_newcar", "New passenger railcars", "Car builder labor, rolling stock prices, metals and electrical systems.",
         {"ECI_MFG": 40, "PPI_RS": 25, "PPI_ELEC": 15, "PPI_STEEL": 10, "PPI_ALUM": 5, "CPI": 5}),
        ("p_overhaul", "Mid-life overhaul", "Shop labor heavy, with materials and electrical upgrades.",
         {"ECI_MFG": 55, "PPI_RS": 15, "PPI_ELEC": 15, "PPI_STEEL": 5, "CPI": 10}),
        ("p_hvac", "HVAC overhaul and parts", None, {"ECI_MFG": 40, "PPI_HVAC": 45, "PPI_ELEC": 10, "CPI": 5}),
        ("p_prop", "Propulsion and power electronics", None, {"ECI_MFG": 35, "PPI_ELEC": 35, "PPI_XFMR": 20, "PPI_WIRE": 10}),
        ("p_consum", "Wheels, brakes and consumables", None, {"PPI_STEEL": 45, "PPI_RS": 25, "ECI_MFG": 20, "CPI": 10}),
        ("p_om", "Operations and maintenance service", "Contracted operations and vehicle maintenance.", {"ECI_TRN": 65, "PPI_DIESEL": 10, "CPI": 25}),
    ],
    "aar": [  # the AAR index mode (Justin, 2026-11-03): rail-industry indexes instead of a BLS basket
        ("a_rcafa", "RCAF (adjusted)", "The STB productivity-adjusted Rail Cost Adjustment Factor, the escalator in many rail transportation contracts.", {"RCAF_ADJ": 100}),
        ("a_rcafu", "RCAF (unadjusted)", "Railroad input prices before productivity: labor, fuel, materials, equipment rents and other.", {"RCAF_UNADJ": 100}),
        ("a_mix", "RCAF unadjusted with fuel", "80% RCAF (unadjusted), 20% AAR fuel index: a common shape where fuel is called out.", {"RCAF_UNADJ": 80, "AAR_FUEL": 20}),
        ("a_fuel", "AAR fuel index", "The AAR monthly railroad fuel price index alone.", {"AAR_FUEL": 100}),
    ],
    "freight": [
        ("f_rcaf", "Rail rates (RCAF adjusted)", "The STB productivity-adjusted escalator used in many rail transportation contracts.", {"RCAF_ADJ": 100}),
        ("f_rcafu", "Rail input costs (RCAF unadjusted)", None, {"RCAF_UNADJ": 100}),
        ("f_car", "New freight cars", "Steel heavy.", {"PPI_STEEL": 45, "ECI_MFG": 30, "PPI_RS": 20, "CPI": 5}),
        ("f_loco", "Locomotive overhaul and parts", None, {"ECI_MFG": 45, "PPI_ELEC": 20, "PPI_RS": 15, "PPI_STEEL": 10, "CPI": 10}),
        ("f_mow", "Track and maintenance-of-way services", None, {"ECI_TRN": 50, "PPI_STEEL": 25, "PPI_DIESEL": 15, "CPI": 10}),
        ("f_fuel", "Fuel", "AAR railroad fuel index.", {"AAR_FUEL": 100}),
    ],
}
CIVIL = [  # rail infrastructure civil works market baskets (Justin, 2026-11-06). Consist weights from typical
    # rail civil cost breakdowns (labor about a third, then materials, equipment and fuel); users edit them.
    ("c_civil", "Rail infrastructure civil works", "All-round civil works basket: construction labor, concrete, ballast, structural steel, ties, equipment and fuel.",
     {"ECI_CON": 35, "PPI_CONC": 15, "PPI_AGG": 10, "PPI_STRUCT": 10, "PPI_TIES": 5, "PPI_CONEQ": 10, "PPI_DIESEL": 8, "PPI_PAVE": 2, "CPI": 5}),
    ("c_track", "Track construction and renewal", "Ballast, ties, rail steel, machinery and fuel heavy.",
     {"ECI_CON": 30, "PPI_AGG": 15, "PPI_TIES": 12, "PPI_CONC": 8, "PPI_HRSTEEL": 15, "PPI_CONEQ": 10, "PPI_DIESEL": 10}),
    ("c_struct", "Bridges and structures", "Concrete and fabricated steel heavy.",
     {"ECI_CON": 35, "PPI_CONC": 25, "PPI_STRUCT": 20, "PPI_HRSTEEL": 5, "PPI_CONEQ": 8, "PPI_DIESEL": 4, "CPI": 3}),
    ("c_sitework", "Earthwork, drainage and sitework", "Equipment, fuel and aggregates heavy.",
     {"ECI_CON": 35, "PPI_CONEQ": 20, "PPI_DIESEL": 15, "PPI_AGG": 15, "PPI_CONC": 10, "PPI_PAVE": 5}),
    ("c_systems", "Signals and electrification civil", "Foundations, duct bank, poles and cable.",
     {"ECI_CON": 40, "PPI_CONC": 15, "PPI_STRUCT": 15, "PPI_WIRE": 15, "PPI_ELEC": 10, "PPI_DIESEL": 5}),
]
PRESETS["passenger"] += CIVIL
PRESETS["freight"] += CIVIL

HORIZONS = (3, 6, 12, 24)
MAXH = 36  # longest backtested horizon (months)
MAXF = 120  # longest forecast offered (months); beyond MAXH the range is extrapolated from the MAXH errors
WIDEN = (1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 4.0)
BT_START = (2010, 1)


def _mi(y, m):
    return y * 12 + m - 1


def _ym(i):
    return divmod(i, 12)[0], divmod(i, 12)[1] + 1


def plabel(i):
    y, m = _ym(i)
    return "%d-%02d" % (y, m)


def parse_period(s):
    try:
        y, m = s.split("-")[:2]
        return _mi(int(y), int(m))
    except (ValueError, AttributeError):
        return None


_cache = {}


def _load():
    if "s" in _cache:
        return _cache["s"]
    rev = {v: k for k, v in BLS_ID.items()}
    s = {k: {} for k in SERIES}
    p = os.path.join(SEED, "bls_index.csv.gz")
    if os.path.exists(p):
        with gzip.open(p, "rt", newline="") as f:
            for r in csv.DictReader(f):
                k = rev.get(r["series_id"])
                if k:
                    s[k][parse_period(r["period"])] = float(r["value"])
    for r in costidx.rcaf():  # RCAF applies to the quarter: dated at its last month, like the ECI
        i = _mi(r["year"], r["quarter"] * 3)
        if r.get("rcaf_unadj"):
            s["RCAF_UNADJ"][i] = r["rcaf_unadj"]
        if r.get("rcaf_adj"):
            s["RCAF_ADJ"][i] = r["rcaf_adj"]
    for r in costidx.fuel_monthly():
        if r["idx"]:
            s["AAR_FUEL"][_mi(r["year"], r["month"])] = r["idx"]
    _cache["s"] = {k: sorted(v.items()) for k, v in s.items() if v}
    return _cache["s"]


MODES = {"bls": ("BLS basket models", "A weighted basket of BLS producer price, wage and consumer price indexes."),
         "aar": ("AAR indexes", "The rail-industry indexes: the STB Rail Cost Adjustment Factor (computed by the AAR) and the AAR railroad fuel index.")}


def family(k):
    return "aar" if SERIES[k][3] in ("STB / AAR", "AAR") else "bls"


def available(segment=None, mode=None):
    """Indexes for a portal segment, or for one index mode (the AAR mode is open to both portals)."""
    s = _load()
    if mode == "aar":
        return [k for k in SERIES if k in s and family(k) == "aar"]
    return [k for k in SERIES if k in s and (segment is None or SERIES[k][4] in ("both", segment)) and (mode is None or family(k) == mode)]


def presets(segment, mode):
    """Starting baskets for a segment in one mode, keeping only baskets whose indexes are all in that mode and loaded."""
    av = set(available(segment, mode))
    pool = PRESETS["aar"] if mode == "aar" else PRESETS[segment]
    return [p for p in pool if p[3] and all(k in av for k in p[3])]


def all_presets(segment):
    """(mode, preset) for every basket either mode offers this segment: the comparator's choices."""
    return [(m, p) for m in MODES for p in presets(segment, m)]


def series(k):
    return _load().get(k, [])


def last(k):
    s = series(k)
    return s[-1] if s else (None, None)


def value_at(k, i, fc=True):
    """Latest value on or before month i (quarterly series hold for the quarter). Past the data, the forecast if fc.
    Returns (value, is_forecast)."""
    s = series(k)
    if not s:
        return None, False
    if i <= s[-1][0]:
        j = bisect.bisect_right([p for p, _ in s], i) - 1
        return (s[j][1], False) if j >= 0 else (None, False)
    if not fc:
        return s[-1][1], False
    f = forecast(k)
    step = SERIES[k][2]
    h = (i - s[-1][0]) // step  # steps ahead, holding within a quarter
    if h == 0:
        return s[-1][1], False
    pt = f["points"]
    return (pt[min(h, len(pt)) - 1]["mid"], True) if pt else (s[-1][1], False)


# ---------- forecasting ----------
def _drift(y, h, w):
    w = min(w, len(y) - 1)
    d = (y[-1] - y[-1 - w]) / w if w > 0 else 0
    return [y[-1] + d * k for k in range(1, h + 1)]


def _damped(y, h, a=0.6, b=0.1, phi=0.95):
    lv, tr = y[0], (y[min(12, len(y) - 1)] - y[0]) / min(12, len(y) - 1) if len(y) > 1 else 0
    for v in y[1:]:
        pl = lv
        lv = a * v + (1 - a) * (lv + phi * tr)
        tr = b * (lv - pl) + (1 - b) * phi * tr
    out, acc = [], 0
    for k in range(1, h + 1):
        acc += phi ** k
        out.append(lv + acc * tr)
    return out


def _trend(y, h, w):
    y = y[-w:]
    n = len(y)
    mx = (n - 1) / 2
    my = sum(y) / n
    sxx = sum((i - mx) ** 2 for i in range(n)) or 1
    b = sum((i - mx) * (v - my) for i, v in enumerate(y)) / sxx
    a = my - b * mx
    return [a + b * (n - 1 + k) for k in range(1, h + 1)]


def _methods(step):
    py = 12 // step  # observations per year
    return {
        "drift": ("Recent trend", "Continues the average growth of the last five years.", lambda y, h: _drift(y, h, 5 * py)),
        "damped": ("Damped trend", "Exponential smoothing that follows recent momentum and lets it fade over time.", lambda y, h: _damped(y, h)),
        "linear": ("Long-run trend", "Straight-line growth fitted to the last ten years.", lambda y, h: _trend(y, h, 10 * py)),
        "flat": ("No change", "Latest value carried forward. The benchmark every method must beat.", lambda y, h: [y[-1]] * h),
    }


def _q(xs, p):
    xs = sorted(xs)
    if not xs:
        return 0.0
    k = (len(xs) - 1) * p
    f = int(k)
    c = min(f + 1, len(xs) - 1)
    return xs[f] + (xs[c] - xs[f]) * (k - f)


def backtest(k):
    """Rolling-origin backtest: forecast from every origin since 2010 with data up to that origin only."""
    ck = ("bt", k)
    if ck in _cache:
        return _cache[ck]
    s = series(k)
    step = SERIES[k][2]
    hmax = MAXH // step
    idx = [p for p, _ in s]
    y = [math.log(v) for _, v in s]
    meth = _methods(step)
    start = bisect.bisect_left(idx, _mi(*BT_START))
    minobs = 6 * (12 // step)
    errs = {m: {} for m in meth}  # method -> h -> list of (origin_pos, log error actual - forecast)
    for o in range(max(start, minobs), len(y) - 1):
        hist = y[:o + 1]
        for m, (_, _, fn) in meth.items():
            fc = fn(hist, hmax)
            for h in range(1, min(hmax, len(y) - 1 - o) + 1):
                errs[m].setdefault(h, []).append((o, y[o + h] - fc[h - 1]))
    res = {}
    for m in meth:
        hs = {}
        for hm in HORIZONS:
            h = hm // step
            e = errs[m].get(h, [])
            if len(e) < 8:
                continue
            ape = [abs(math.exp(x) - 1) * 100 for _, x in e]
            bias = sum((math.exp(x) - 1) * 100 for _, x in e) / len(e)
            # honest coverage: each origin's 90% range uses only errors already observable at that origin.
            # The range is widened by the smallest multiplier that would have caught at least 88% of outcomes.
            cov = {c: [0, 0] for c in WIDEN}
            for o, x in e:
                past = [xx for oo, xx in e if oo + h <= o]
                if len(past) >= 12:
                    lo, md, hi = _q(past, 0.05), _q(past, 0.5), _q(past, 0.95)
                    for c in WIDEN:
                        cov[c][1] += 1
                        cov[c][0] += md + c * (lo - md) <= x <= md + c * (hi - md)
            pct = {c: 100 * a / b for c, (a, b) in cov.items() if b}
            mult = next((c for c in WIDEN if pct.get(c, 0) >= 88), WIDEN[-1])
            hit, n = cov[1.0]
            hs[hm] = dict(mape=sum(ape) / len(ape), p90=_q(ape, 0.9), bias=bias, n=len(e),
                          coverage=100 * hit / n if n else None, mult=mult, coverage_cal=pct.get(mult))
        res[m] = hs
    score = {m: sum(v["mape"] for v in hs.values()) / len(hs) for m, hs in res.items() if hs}
    best = min(score, key=score.get) if score else "drift"
    out = dict(methods=res, best=best, score=score, errs=errs, step=step,
               origins=len(y) - 1 - max(start, minobs), since=plabel(idx[max(start, minobs)]) if len(idx) > minobs else None)
    _cache[ck] = out
    return out


def forecast(k, method=None):
    ck = ("fc", k, method)
    if ck in _cache:
        return _cache[ck]
    s = series(k)
    if len(s) < 24:
        return dict(points=[], method=None)
    bt = backtest(k)
    m = method if method in _methods(1) else bt["best"]
    step = bt["step"]
    hmax = MAXF // step
    y = [math.log(v) for _, v in s]
    name, desc, fn = _methods(step)[m]
    fc = fn(y, hmax)
    pts = []
    hb = max([h for h, e in bt["errs"][m].items() if len(e) >= 12] or [0])  # longest horizon with enough backtest errors
    for h in range(1, hmax + 1):
        e = [x for _, x in bt["errs"][m].get(h, [])]
        c = 1.0  # full-history error quantiles already include the 2021-22 shock; widening again overstates the range
        if len(e) >= 12:
            md = _q(e, 0.5)
            lo, hi = md + c * (_q(e, 0.05) - md), md + c * (_q(e, 0.95) - md)
        elif hb and h > hb:  # past the backtested horizon: grow the last measured range with the square root of time
            eb = [x for _, x in bt["errs"][m][hb]]
            md, g = _q(eb, 0.5), (h / hb) ** 0.5
            lo, hi = md + g * (_q(eb, 0.05) - md), md + g * (_q(eb, 0.95) - md)
        else:
            lo, hi = -0.03 * h ** 0.5, 0.03 * h ** 0.5
        mid = math.exp(fc[h - 1])
        pts.append(dict(i=s[-1][0] + h * step, label=plabel(s[-1][0] + h * step), mid=mid,
                        lo=mid * math.exp(lo), hi=mid * math.exp(hi), h_months=h * step, extrap=h * step > MAXH))
    out = dict(points=pts, method=m, name=name, desc=desc, bt=bt)
    _cache[ck] = out
    return out


def yoy(k, months=12):
    s = series(k)
    if not s:
        return None
    v1, _ = value_at(k, s[-1][0], fc=False)
    v0, _ = value_at(k, s[-1][0] - months, fc=False)
    return 100 * (v1 / v0 - 1) if v0 else None


# ---------- escalation ----------
def escalate(basket, base, target, lag=0, fixed=0.0, floor=None, cap=None):
    """basket: {series: weight %}; base/target: month index; lag: months; fixed: % of price not escalated.
    floor/cap: limits on the cumulative change in %. Returns dict with factor, change %, components, forecast flag."""
    tot = sum(w for w in basket.values() if w > 0)
    if not tot:
        return None
    var = (100 - fixed) / 100
    comps, f, anyfc = [], fixed / 100, False
    for k, w in basket.items():
        if w <= 0 or k not in SERIES:
            continue
        b, _ = value_at(k, base - lag, fc=False)
        t, isf = value_at(k, target - lag)
        if not b or t is None:
            return dict(error="%s has no value for %s" % (SERIES[k][0], plabel(base - lag)))
        share = var * w / tot
        f += share * t / b
        anyfc |= isf
        comps.append(dict(k=k, label=SERIES[k][0], w=100 * share, b=b, t=t, rel=100 * (t / b - 1), contrib=100 * share * (t / b - 1), fc=isf))
    raw = 100 * (f - 1)
    ch = raw
    if floor is not None:
        ch = max(ch, floor)
    if cap is not None:
        ch = min(ch, cap)
    return dict(factor=1 + ch / 100, change=ch, raw=raw, limited=ch != raw, comps=comps, forecast=anyfc)


def schedule(basket, base, start, end, every=12, **kw):
    out, i = [], start
    while i <= end and len(out) < 60:
        r = escalate(basket, base, i, **kw)
        if r and "error" not in r:
            out.append(dict(i=i, label=plabel(i), **r))
        i += every
    return out


def describe(k, hist, pts=()):
    """Plain-language summary of the selected period: total and yearly change, high and low, and the forecast part if shown."""
    if len(hist) < 2:
        return None
    (i0, v0), (i1, v1) = hist[0], hist[-1]
    yrs = (i1 - i0) / 12
    out = dict(start=plabel(i0), end=plabel(i1), v0=v0, v1=v1, change=100 * (v1 / v0 - 1) if v0 else None, years=yrs,
               cagr=100 * ((v1 / v0) ** (1 / yrs) - 1) if v0 and yrs >= 1 else None)
    hi = max(hist, key=lambda t: t[1]); lo = min(hist, key=lambda t: t[1])
    out.update(high=hi[1], high_at=plabel(hi[0]), low=lo[1], low_at=plabel(lo[0]))
    steps = [100 * (b[1] / a[1] - 1) for a, b in zip(hist, hist[1:]) if a[1]]
    ups = sum(1 for x in steps if x > 0)
    out["up_share"] = 100 * ups / len(steps) if steps else None
    # largest 12-month rise and fall inside the period
    st = SERIES[k][2]
    span = max(1, 12 // st)
    yy = [(hist[j][0], 100 * (hist[j][1] / hist[j - span][1] - 1)) for j in range(span, len(hist)) if hist[j - span][1]]
    if yy:
        mx, mn = max(yy, key=lambda t: t[1]), min(yy, key=lambda t: t[1])
        out.update(max12=mx[1], max12_at=plabel(mx[0]), min12=mn[1], min12_at=plabel(mn[0]))
    if pts:
        p = pts[-1]
        fy = (p["i"] - i1) / 12
        out.update(fc_end=p["label"], fc_mid=p["mid"], fc_lo=p["lo"], fc_hi=p["hi"], fc_change=100 * (p["mid"] / v1 - 1) if v1 else None,
                   fc_cagr=100 * ((p["mid"] / v1) ** (1 / fy) - 1) if v1 and fy >= 1 else None, fc_extrap=bool(p.get("extrap")))
    return out
