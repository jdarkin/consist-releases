"""Award analyst, rolling stock side: vehicle and locomotive orders (rail cars, LRVs, multiple units, coaches, locomotives, APM
vehicles) with what matters when pricing one: units, price per unit, builder, type, base order or option.
Two sources: contract awards Bid Catcher files as vehicle procurement (bids.db), and the researched order book in fleet.db
(seed_procurement). An order found in both is shown once, from the award. Quantities and unit prices are read from the award
title or the order record; an order that bundles long-term support or rebuilds is flagged and kept out of the unit-price statistics."""
import re
import statistics

from . import award_analyst, data, db

TYPES = {"locomotive": "Locomotives", "multiple_unit": "Multiple units (EMU, DMU, BEMU)", "metro": "Subway and metro cars",
         "lrv": "Light rail and streetcars", "coach": "Coaches and cab cars", "trainset": "Intercity trainsets", "apm": "APM and people movers",
         "other": "Other rolling stock"}
TYPE_RX = [("apm", r"\bapm\b|people mover|innovia|skyway|automated guideway"),
           ("locomotive", r"locomotive|charger|\balc-42|\bsc-4|\bsd70|\bes44|evolution series|\balp-45|\bhsp46|\bf125|\bmp36"),
           ("trainset", r"trainset|high[- ]speed train"),
           ("coach", r"coach|bi-?level|multi-?level|cab car|single-level|gallery|comet|viaggio"),
           ("trainset", r"avelia|\bairo\b|venture"),
           ("multiple_unit", r"multiple[- ]unit|\bemu|\bdmu|\bbemu|flirt|kiss|\bm-?9a?\b|\bm-?8\b|silverliner|\bkiss\b"),
           ("lrv", r"light rail|\blrv|streetcar|tram|citylink|s200|s700|type \d"),
           ("metro", r"subway|metro(polis)?\b|heavy rail|\br\d{3}|hr\d{4}|rapid transit car|\bnst\b"),
           ("coach", r"passenger car|\bcars?\b")]
PROPULSION = {"dual": r"dual[- ]mode|dual[- ]power|alp-45", "battery": r"battery|bemu|\bbel\b|akku", "diesel": r"diesel|\bdmu|tier 4|charger|\bsd70|evolution",
              "electric": r"electric|\bemu|catenary|subway|light rail|metro|lrv|streetcar"}
PROP_LABEL = {"battery": "Battery or hybrid", "dual": "Dual-mode", "diesel": "Diesel", "electric": "Electric", "": "Not stated"}
KINDS = {"base": "New order", "option": "Option exercise", "used": "Used, lease or transfer"}
MIXED_RX = r"technical support|maintenance services|long-term|modernization|rebuild|overhaul|\bplus\b.*(support|parts|spares)|\btsa\b"
UNIT_RX = (r"(?<![\w\-.])(\d[\d,]*)\s+(?:base\b|(?:[\w\-/]+\s+){0,5}?"
           r"(cars?|railcars?|vehicles?|lrvs?|locomotives?|trainsets?|trains?|coaches|units?|emus?|dmus?)\b)")


def _text(*parts):
    return " ".join(str(p or "") for p in parts).lower()


def classify(text, *more):
    """Vehicle type from the order's own name first; notes and values only break a tie when the name says nothing (notes often
    mention other equipment, such as the locomotives that will haul new coaches)."""
    for part in (text, *more):
        t = (part or "").lower()
        k = next((k for k, rx in TYPE_RX if re.search(rx, t)), None)
        if k:
            return k
    return "other"


def propulsion_of(text):
    t = text.lower()
    return next((k for k, rx in PROPULSION.items() if re.search(rx, t)), "")


def units_of(text):
    """(units, per-train multiplier note) from free text such as '316 cars', '70 six-car trains', '7 trainsets'."""
    m = re.search(UNIT_RX, text, re.I)
    if not m:
        return None, ""
    n = int(m.group(1).replace(",", ""))
    if not 0 < n < 5000:
        return None, ""
    cars = re.search(r"(\d+|four|six|eight)[- ]car", m.group(0), re.I)
    if cars and re.search(r"trains?\b", m.group(2) or "", re.I):
        per = {"four": 4, "six": 6, "eight": 8}.get(cars.group(1).lower()) or int(cars.group(1))
        return n * per, f"{n} trains of {per} cars"
    return n, ""


def _money_of(v):
    """First dollar figure in a free-text value like '279000000 base; 203000000 (41 option ...)' or '~2000000000 (estimate)'."""
    m = re.search(r"\d{6,}", str(v or "").replace(",", ""))
    return float(m.group(0)) if m else None


def _year(d):
    m = re.search(r"(19|20)\d{2}", str(d or ""))
    return m.group(0) if m else ""


def _kind(text):
    t = text.lower()
    if re.search(r"\bused\b|lease|ex-|transfer|second-hand", t):
        return "used"
    if re.search(r"option|additional", t) and not re.search(r"\bbase\b", t):
        return "option"
    return "base"


BUILDERS = ["Alstom", "Siemens", "Kawasaki", "Stadler", "Hyundai Rotem", "Wabtec", "CAF", "Bombardier", "Progress Rail", "CRRC", "Talgo",
            "Brookville", "Nippon Sharyo", "Sumitomo", "Kinkisharyo", "Inekon", "Skoda", "Gomaco", "Doppelmayr"]


def _vendor(v):
    v = re.sub(r"\(.*?\)", "", v or "").strip()
    known = next((b for b in BUILDERS if v.lower().startswith(b.lower())), None)
    if known:
        return known
    v = re.sub(r",?\s*(inc|llc|corp(oration)?|company|co|ltd|usa|us|na|north america|transport(ation)?( canada| usa)?|mobility)\.?\b", "", v, flags=re.I)
    return re.sub(r"\s+", " ", v).strip(" ,.") or "Not published"


def orders(unpriced=False):
    """Every vehicle and locomotive order with a price, newest first. unpriced=True returns the orders with no published price
    instead (listed, but kept out of the price statistics)."""
    out, nop = [], []
    for a in award_analyst._q("SELECT a.*, coalesce(g.agency, a.buyer) agency, g.rail_modes FROM award a LEFT JOIN agency g USING (agency_id) "
                              "WHERE a.category = 'vehicle_procurement'"):
        a = dict(a)
        if not (a["amount_usd"] or 0) > 0:
            t = _text(a["title"], a.get("notes"))
            nop.append({"id": f"a{a['award_id']}", "href": f"/app/awards/{a['award_id']}", "date": a["award_date"] or "", "year": _year(a["award_date"]),
                        "buyer": a.get("agency") or a.get("buyer") or a["agency_id"], "country": a.get("country") or "", "title": a["title"],
                        "builder": _vendor(a["vendor"]), "usd": None, "units": units_of(a["title"] or "")[0], "units_note": "", "type": classify(a["title"], a.get("notes")),
                        "propulsion": propulsion_of(t), "kind": _kind(t), "segments": award_analyst.segment_of(a.get("rail_modes")),
                        "source": "Contract award", "source_url": a.get("source_url"), "status": ""})
            continue
        t = _text(a["title"], a.get("notes"))
        units, note = units_of(a["title"] or "")
        if not units and a.get("notes"):  # the count is sometimes only in the notes
            units, note = units_of(a["notes"])
        out.append({"id": f"a{a['award_id']}", "href": f"/app/awards/{a['award_id']}", "date": a["award_date"] or "", "year": _year(a["award_date"]),
                    "buyer": a.get("agency") or a.get("buyer") or a["agency_id"], "agency_id": a["agency_id"], "country": a.get("country") or "",
                    "title": a["title"], "builder": _vendor(a["vendor"]), "usd": a["amount_usd"], "units": units, "units_note": note,
                    "type": classify(a["title"], a.get("notes")), "propulsion": propulsion_of(t), "kind": _kind(t), "mixed": bool(re.search(MIXED_RX, (a["title"] or "").lower())),
                    "segments": award_analyst.segment_of(a.get("rail_modes")), "source": "Contract award", "source_url": a.get("source_url")})
    ops = {o["operator_id"]: o for o in data.operators(scoped=False)}
    for p in db.fq("SELECT rowid AS order_id, * FROM seed_procurement"):
        p = dict(p)
        usd = _money_of(p["value_usd"])
        if re.search(r"overhaul|rebuild", _text(p["model"])):  # rebuilds are services: the main analyst covers them
            continue
        if re.search(r"rfp|planned|cancel", p["status"] or "", re.I):
            continue
        if not usd or re.search(r"estimate|program", str(p["value_usd"]), re.I):
            first = (p["operator_id"] or "").split(";")[0]
            o = ops.get(first, {})
            t = _text(p["model"], p["notes"], p["value_usd"])
            modes = ";".join(data.MODE_ALIASES.get(m, m) for m in str(o.get("modes") or "").split(";"))
            nop.append({"id": f"n{len(nop)}", "href": f"/app/work/orders/{p['order_id']}", "date": str(p["award_date"] or ""),
                        "year": _year(p["award_date"]), "buyer": " / ".join(ops.get(x, {}).get("operator_name", x) for x in (p["operator_id"] or "").split(";") if x),
                        "country": o.get("country") or "", "title": f"{p['model']}: {p['qty_base']}" if p["qty_base"] else p["model"],
                        "builder": _vendor(p["manufacturer"]), "usd": None, "units": data.first_int(p["qty_base"]) or None, "units_note": "",
                        "type": classify(p["model"], p["notes"], p["value_usd"]), "propulsion": propulsion_of(t), "kind": _kind(_text(p["model"], p["status"])),
                        "segments": award_analyst.segment_of(modes), "source": "Order book", "source_url": p.get("source_url"), "status": p["status"] or ""})
            continue
        units = data.first_int(p["qty_base"]) or None
        if units and re.search(r"trainsets?", str(p["qty_base"]), re.I):
            cars = re.search(r"(\d+)\s*cars", _text(p["qty_base"], p["model"]))
            units = int(cars.group(1)) if cars else None
        if re.search(r"option", str(p["value_usd"]), re.I) and not re.search(r"base", str(p["value_usd"]), re.I):
            m = re.search(r"(\d+)[- ](?:cars?|units?|locomotives?|trainsets?|coaches)\b", str(p["value_usd"]), re.I)
            units = int(m.group(1)) if m else None  # the price is for an option tranche: use its own count when stated
        first = (p["operator_id"] or "").split(";")[0]
        o = ops.get(first, {})
        t = _text(p["model"], p["notes"], p["value_usd"])
        modes = ";".join(data.MODE_ALIASES.get(m, m) for m in str(o.get("modes") or "").split(";"))
        out.append({"id": f"s{len(out)}", "href": f"/app/work/orders/{p['order_id']}", "date": str(p["award_date"] or ""),
                    "year": _year(p["award_date"]), "buyer": " / ".join(ops.get(x, {}).get("operator_name", x) for x in (p["operator_id"] or "").split(";") if x),
                    "agency_id": None, "country": o.get("country") or "", "title": f"{p['model']}: {p['qty_base']}{' units' if str(p['qty_base']).strip().isdigit() else ''}" if p["qty_base"] else p["model"],
                    "builder": _vendor(p["manufacturer"]), "usd": usd, "units": units, "units_note": "", "type": classify(p["model"], p["notes"], p["value_usd"]),
                    "propulsion": propulsion_of(t), "kind": _kind(_text(p["model"], p["status"])),
                    "mixed": bool(re.search(MIXED_RX + r"|support|maintenance|spares|\blease", _text(p["value_usd"]))),
                    "segments": award_analyst.segment_of(modes), "source": "Order book", "source_url": p.get("source_url")})
    # the same order from both sources: keep the award
    awards = [o for o in out if o["source"] == "Contract award"]
    keep = []
    for o in out:
        if o["source"] == "Order book" and any(abs(a["usd"] - o["usd"]) <= 0.02 * o["usd"] for a in awards):
            continue
        o["unit_all"] = o["usd"] / o["units"] if o["units"] else None  # shown on the row
        o["unit_usd"] = o["unit_all"] if not o["mixed"] else None   # used in the statistics: vehicles only
        keep.append(o)
    keep.sort(key=lambda o: o["date"], reverse=True)
    if unpriced:
        nop.sort(key=lambda o: o["date"], reverse=True)
        return nop
    return keep


def options(rows):
    return {"type": [(k, v) for k, v in TYPES.items() if any(r["type"] == k for r in rows)],
            "builder": sorted({r["builder"] for r in rows}, key=str.lower),
            "propulsion": [(k, v) for k, v in PROP_LABEL.items() if k and any(r["propulsion"] == k for r in rows)]}


def filtered(rows, f):
    q = (f.get("q") or "").lower().split()
    out = []
    for r in rows:
        if f.get("type") and r["type"] != f["type"]:
            continue
        if f.get("builder") and r["builder"] != f["builder"]:
            continue
        if f.get("propulsion") and r["propulsion"] != f["propulsion"]:
            continue
        if f.get("order") and r["kind"] != f["order"]:
            continue
        if f.get("segment") and f["segment"] not in r["segments"]:
            continue
        if f.get("country") and r["country"] != f["country"]:
            continue
        if f.get("since") and (r["date"] or "") < f["since"]:
            continue
        if q and not data.qhit(q, _text(r["title"], r["buyer"], r["builder"], TYPES.get(r["type"]), PROP_LABEL.get(r["propulsion"]))):
            continue
        out.append(r)
    return out


def _group(rows, key, labels=None):
    by = {}
    for r in rows:
        k = r[key]
        g = by.setdefault(k, {"key": k, "label": (labels or {}).get(k, k), "n": 0, "usd": 0.0, "units": 0, "unit_prices": [], "buyers": set()})
        g["n"] += 1
        g["usd"] += r["usd"]
        g["units"] += r["units"] or 0
        g["buyers"].add(r["buyer"])
        if r["unit_usd"]:
            g["unit_prices"].append(r["unit_usd"])
    total = sum(g["usd"] for g in by.values()) or 1
    for g in by.values():
        g["share"] = round(100 * g["usd"] / total)
        g["unit_median"] = statistics.median(g["unit_prices"]) if g["unit_prices"] else None
    return sorted(by.values(), key=lambda g: -g["usd"])


def analyze(rows):
    unit = [r["unit_usd"] for r in rows if r["unit_usd"]]
    st = None
    if rows:
        st = {"n": len(rows), "usd": sum(r["usd"] for r in rows), "units": sum(r["units"] or 0 for r in rows), "n_unit": len(unit),
              "unit_median": statistics.median(unit) if unit else None, "unit_p25": award_analyst.pct(unit, .25), "unit_p75": award_analyst.pct(unit, .75),
              "unit_min": min(unit) if unit else None, "unit_max": max(unit) if unit else None,
              "option_pct": round(100 * sum(1 for r in rows if r["kind"] == "option") / len(rows))}
    years = {}
    for r in rows:
        if r["year"] and r["unit_usd"]:
            years.setdefault(r["year"], []).append(r["unit_usd"])
    return {"rows": rows, "stats": st, "builders": _group(rows, "builder"), "types": _group(rows, "type", TYPES),
            "years": [{"year": y, "n": len(v), "median": statistics.median(v)} for y, v in sorted(years.items())],
            "strip": strip_svg(rows)}


def strip_svg(rows, w=640, h=86):
    """One dot per order on a log price-per-unit axis, colored by vehicle type, with the middle half shaded."""
    import math
    pts = [r for r in rows if r["unit_usd"]]
    if not pts:
        return ""
    v = [r["unit_usd"] for r in pts]
    lo, hi = math.log10(min(v)), math.log10(max(v))
    if hi - lo < 0.3:
        lo, hi = lo - 0.15, hi + 0.15
    x = lambda u: 20 + (w - 40) * (math.log10(u) - lo) / (hi - lo)  # noqa: E731
    q1, q3, med = award_analyst.pct(v, .25), award_analyst.pct(v, .75), statistics.median(v)
    tcol = type_colors()
    parts = [f'<svg class="strip" viewBox="0 0 {w} {h}" role="img" aria-label="Price per unit">',
             f'<rect x="{x(q1):.1f}" y="18" width="{max(2, x(q3) - x(q1)):.1f}" height="30" rx="4" class="box"/>',
             f'<line x1="{x(med):.1f}" x2="{x(med):.1f}" y1="12" y2="54" class="med"/>']
    for i, r in enumerate(pts):
        tip = "\n".join([r["title"] or "Order", f"{r['builder']} · {r['units']} units · ${r['unit_usd']:,.0f} per unit",
                         f"{r['buyer']} · {r['date'] or 'date unknown'} · {TYPES[r['type']]}"] + (["Click for the details"] if r["href"] else []))
        dot = f'<circle cx="{x(r["unit_usd"]):.1f}" cy="{33 + ((i * 7) % 15) - 7}" r="4.5" style="fill:{tcol[r["type"]]};stroke:var(--card);stroke-width:1"/>'
        parts.append(f'<a href="{r["href"]}" data-tip="{award_analyst._esc(tip)}">{dot}</a>' if r["href"]
                     else f'<g data-tip="{award_analyst._esc(tip)}" tabindex="0">{dot}</g>')
    for u in (min(v), med, max(v)):
        parts.append(f'<text x="{x(u):.1f}" y="{h - 8}" text-anchor="middle">{award_analyst._money(u)}</text>')
    parts.append("</svg>")
    return "".join(parts)


def type_colors():
    """The five common types get the series colors; the rest share grey."""
    return {k: (f"var(--c{i + 1})" if i < 5 else "var(--muted)") for i, k in enumerate(TYPES)}
