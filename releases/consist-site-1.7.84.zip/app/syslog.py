"""Platform system log and Admin > Diagnostics (Justin, 2026-11-07).

One table, sys_event, collects everything unexpected the site runs into, so it can be read in one place:
  * http       server errors (5xx with the traceback), client errors (4xx), and slow requests (SyslogMiddleware)
  * stripe     declined cards, failed payments, failed checkouts and webhook failures (billing.py and the webhook route)
  * app        anything the site's own code logs as a warning or error ("consist.*" loggers: news, alerts, analyst, mail, ...)
  * mail       outgoing email that failed to send
Card numbers never reach the site (Stripe Checkout takes them); only Stripe's decline code and message are kept.

Writes never break a request. Identical events within THROTTLE_S are counted on the first row instead of adding a new one, so a
burst of bot 404s or a failing job can't flood the table. Rows older than RETAIN_DAYS are deleted."""
import datetime
import json
import logging
import re
import threading
import time
import traceback

from . import config, db

RETAIN_DAYS = 90
SLOW_MS = 8000          # a page that takes longer than this is logged as slow
THROTTLE_S = 300        # repeats of the same event inside 5 minutes add to its count
LEVELS = ("error", "warning", "info")
CATEGORIES = {"http": "Site requests", "stripe": "Payments (Stripe)", "app": "Site code", "mail": "Email", "news": "News search",
              "job": "Scheduled jobs"}
SKIP = re.compile(r"^/(static/|favicon|apple-touch|healthz)")
BOT = re.compile(r"bot|crawl|spider|slurp|scan|curl|wget|python|httpx|go-http|java/|okhttp|zgrab|masscan|nmap", re.I)
PROBE = re.compile(r"\.(php|asp|aspx|jsp|cgi|env|git|bak|sql)\b|wp-|/\.|phpmyadmin|xmlrpc", re.I)  # vulnerability scanners
_recent, _rlock = {}, threading.Lock()
_alert = {"t": 0.0}
_ready = {"ok": False}
STARTED = time.time()


def ensure():
    with db._lock:
        c = db.connect()
        try:
            c.executescript("""
CREATE TABLE IF NOT EXISTS sys_event (id INTEGER PRIMARY KEY, ts TEXT, last_ts TEXT, level TEXT, category TEXT, code TEXT, method TEXT,
  path TEXT, message TEXT, detail TEXT, user_id INTEGER, ip TEXT, ms INTEGER, count INTEGER DEFAULT 1);
CREATE INDEX IF NOT EXISTS sys_event_ts ON sys_event (ts);
CREATE INDEX IF NOT EXISTS sys_event_cat ON sys_event (category, level, ts);
""")
            c.commit()
        finally:
            c.close()
    _ready["ok"] = True


def record(level, category, message, code="", path="", method="", detail=None, user_id=None, ip="", ms=None):
    """Add one event (or bump the count of the same event seen in the last few minutes). Never raises."""
    try:
        if not _ready["ok"]:
            return
        level = level if level in LEVELS else "info"
        key = (level, category, str(code), path, (message or "")[:120])
        now = time.time()
        with _rlock:
            hit = _recent.get(key)
            if hit and now - hit[0] < THROTTLE_S:
                _recent[key] = (hit[0], hit[1])
                rid = hit[1]
            else:
                rid = None
            if len(_recent) > 5000:
                _recent.clear()
        if rid:
            db.x("UPDATE sys_event SET count = count + 1, last_ts = ? WHERE id = ?", (db.now(), rid))
            return
        det = detail if isinstance(detail, str) or detail is None else json.dumps(detail, default=str)
        db.x("INSERT INTO sys_event (ts, last_ts, level, category, code, method, path, message, detail, user_id, ip, ms) "
             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
             (db.now(), db.now(), level, category, str(code or ""), method or "", (path or "")[:300], (message or "")[:500],
              (det or "")[:8000] or None, user_id, ip or "", ms))
        new = db.q("SELECT max(id) i FROM sys_event", one=True)["i"]
        with _rlock:
            _recent[key] = (now, new)
        if new % 500 == 0:
            db.x("DELETE FROM sys_event WHERE ts < ?", (since(RETAIN_DAYS),))
        if level == "error":
            _maybe_alert(category, message, path)
    except Exception:
        pass


def _maybe_alert(category, message, path):
    """Email the admins about an error, at most once an hour (Admin > Diagnostics > Email alerts)."""
    s = db.settings()
    if s.get("diag_alerts") != "1" or time.time() - _alert["t"] < 3600:
        return
    _alert["t"] = time.time()
    to = s.get("diag_alert_to") or config.ADMIN_EMAIL
    if not to:
        return

    def go():
        from . import mailer
        try:
            n = db.q("SELECT count(*) n FROM sys_event WHERE level = 'error' AND ts >= ?", (since(1),), one=True)["n"]
            mailer.send(to, f"{s.get('site_name', 'Consist')}: site error ({CATEGORIES.get(category, category)})",
                        f"The site logged an error:\n\n{message}\n{path or ''}\n\n{n} error(s) in the last 24 hours.\n"
                        f"Details: {config.SITE_URL}/admin/diagnostics?tab=log&level=error\n\n"
                        "You get at most one of these an hour. Turn them off in Admin > Diagnostics.", alerts=True)
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def since(days):
    return (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)).replace(microsecond=0).isoformat()


def ack_ts(category):
    """When an admin last marked this area's problems as seen (Admin > Diagnostics, 1.7.10), or ''."""
    try:
        return db.settings().get("diag_ack_" + category, "") or ""
    except Exception:
        return ""


def since_ack(category, days):
    """The later of 'days ago' and the area's last acknowledgement: health checks and counts only look at newer events."""
    a = ack_ts(category)
    s = since(days)
    return a if a > s else s


def _short_ip(scope):
    from .usage import short_ip
    h = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
    ip = (h.get("x-forwarded-for") or "").split(",")[0].strip() or (scope.get("client") or ("",))[0]
    return short_ip(ip), h.get("user-agent", "")


class SyslogMiddleware:
    """Times each request and records 5xx (with traceback), 4xx and slow responses. Never breaks a request."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or SKIP.match(scope.get("path", "")):
            return await self.app(scope, receive, send)
        t0, meta = time.time(), {"status": 0}

        async def wrap(msg):
            if msg["type"] == "http.response.start":
                meta["status"] = msg.get("status", 0)
            await send(msg)
        try:
            await self.app(scope, receive, wrap)
        except Exception as ex:
            _http(scope, 500, t0, "".join(traceback.format_exception(type(ex), ex, ex.__traceback__))[-6000:], f"{type(ex).__name__}: {ex}")
            raise
        else:
            _http(scope, meta["status"], t0)


def _http(scope, status, t0, tb=None, msg=None):
    try:
        ms = int((time.time() - t0) * 1000)
        path = scope.get("path", "")
        qs = scope.get("query_string", b"").decode("latin-1")
        uid = (scope.get("session") or {}).get("uid") if "session" in scope else None
        ip, ua = _short_ip(scope)
        bot = bool(BOT.search(ua)) or not ua
        full = path + ("?" + qs[:200] if qs else "")
        det = {"ua": ua[:200]} if ua else {}
        if tb:
            det["traceback"] = tb
        if path == "/stripe/webhook" and status < 500:
            return  # the webhook route logs its own failures with the reason
        if status == 503 and db.settings().get("maintenance_on") == "1":
            return  # the maintenance page, switched on in Admin > Settings
        if status >= 500:
            record("error", "http", msg or f"Server error {status}", status, full, scope.get("method"), det, uid, ip, ms)
        elif status >= 400:
            if status == 404 and (bot or PROBE.search(path)):
                return  # scanners and crawlers probing for pages that don't exist: not worth a row each
            lvl = "info" if status in (401, 404) else "warning"
            label = {400: "Bad request", 401: "Sign-in needed", 403: "Forbidden", 404: "Page not found", 405: "Method not allowed",
                     413: "Upload too large", 422: "Form could not be read", 429: "Too many requests"}.get(status, "Client error")
            record(lvl, "http", f"{label} ({status})", status, full, scope.get("method"), det, uid, ip, ms)
        if ms >= SLOW_MS and status < 500:
            record("warning", "http", f"Slow response: {ms / 1000:.1f} s", "slow", path, scope.get("method"), det, uid, ip, ms)
    except Exception:
        pass


class _Handler(logging.Handler):
    """The site's own warnings and errors (the "consist" loggers) go to the system log as well as the container log."""
    def emit(self, rec):
        try:
            if rec.levelno < logging.WARNING:
                return
            name = rec.name
            cat = ("news" if name.startswith("consist.news") else "mail" if "mail" in name else "job" if name.split(".")[-1] in
                   ("alerts", "promo", "seo", "backups", "bidcatcher") else "app")
            text = rec.getMessage()
            if "stripe" in text.lower():
                cat = "stripe"
            det = {"logger": name, "where": f"{rec.module}.{rec.funcName}:{rec.lineno}"}
            if rec.exc_info:
                det["traceback"] = "".join(traceback.format_exception(*rec.exc_info))[-6000:]
            record("error" if rec.levelno >= logging.ERROR else "warning", cat, text[:500], detail=det)
        except Exception:
            pass


def install_logging():
    lg = logging.getLogger("consist")
    if not any(isinstance(h, _Handler) for h in lg.handlers):
        lg.addHandler(_Handler())


# ---- Stripe ----

def stripe_event(etype, obj, uid=None):
    """Log the payment problems in a Stripe webhook event. Returns True when it logged something."""
    o = obj or {}
    amt = o.get("amount_due") or o.get("amount") or o.get("amount_total")
    money = f" ({amt / 100:,.2f} {(o.get('currency') or '').upper()})" if isinstance(amt, (int, float)) and amt else ""
    err = o.get("last_payment_error") or {}
    base = {"stripe_event": etype, "object": o.get("id"), "customer": o.get("customer")}
    if etype == "invoice.payment_failed":
        record("error", "stripe", f"Payment failed on invoice, attempt {o.get('attempt_count') or 1}{money}", "payment_failed",
               detail=dict(base, billing_reason=o.get("billing_reason"), next_attempt=o.get("next_payment_attempt")), user_id=uid)
    elif etype == "invoice.payment_action_required":
        record("warning", "stripe", f"Payment needs the customer to confirm (3-D Secure){money}", "action_required", detail=base, user_id=uid)
    elif etype == "payment_intent.payment_failed":
        code = err.get("decline_code") or err.get("code") or "failed"
        record("error", "stripe", f"Card payment failed: {err.get('message') or code}{money}", code,
               detail=dict(base, type=err.get("type"), code=err.get("code"), decline_code=err.get("decline_code")), user_id=uid)
    elif etype == "charge.failed":
        out = o.get("outcome") or {}
        code = o.get("failure_code") or out.get("reason") or "failed"
        record("error", "stripe", f"Charge declined: {o.get('failure_message') or out.get('seller_message') or code}{money}", code,
               detail=dict(base, outcome_type=out.get("type"), risk=out.get("risk_level"), network_status=out.get("network_status")),
               user_id=uid)
    elif etype == "checkout.session.async_payment_failed":
        record("error", "stripe", f"Checkout payment failed{money}", "checkout_failed", detail=base, user_id=uid)
    elif etype == "checkout.session.expired":
        record("info", "stripe", "Checkout abandoned (session expired without payment)", "checkout_expired", detail=base, user_id=uid)
    elif etype == "customer.subscription.updated" and o.get("status") in ("past_due", "unpaid", "incomplete_expired"):
        record("warning", "stripe", f"Subscription is {o.get('status').replace('_', ' ')}", o.get("status"), detail=base, user_id=uid)
    elif etype == "charge.dispute.created":
        record("error", "stripe", f"Payment disputed (chargeback){money}: {o.get('reason') or ''}", "dispute", detail=base, user_id=uid)
    else:
        return False
    return True


# ---- reports for Admin > Diagnostics ----

def counts(days=1):
    out = {}
    for cat in CATEGORIES:
        for r in db.q("SELECT level, sum(count) n FROM sys_event WHERE category = ? AND last_ts > ? GROUP BY 1", (cat, since_ack(cat, days))):
            out.setdefault(cat, {})[r["level"]] = r["n"]
    return out


def http_summary(days=1):
    r = db.q("SELECT sum(CASE WHEN code >= '500' AND code < '600' AND length(code) = 3 THEN count ELSE 0 END) e5, "
             "sum(CASE WHEN code >= '400' AND code < '500' AND length(code) = 3 THEN count ELSE 0 END) e4, "
             "sum(CASE WHEN code = 'slow' THEN count ELSE 0 END) slow FROM sys_event WHERE category = 'http' AND last_ts > ?",
             (since_ack("http", days),), one=True)
    return {k: r[k] or 0 for k in ("e5", "e4", "slow")}


def top_paths(days=7, n=10):
    return db.q("SELECT code, path, sum(count) n, max(last_ts) last FROM sys_event WHERE category = 'http' AND last_ts >= ? "
                "GROUP BY code, path ORDER BY n DESC LIMIT ?", (since(days), n))


def daily(days=14):
    return db.q("SELECT substr(ts, 1, 10) d, level, sum(count) n FROM sys_event WHERE ts >= ? GROUP BY 1, 2 ORDER BY 1", (since(days),))


def events(level="", category="", q="", days=7, limit=200, offset=0, unseen=False):
    where, args = ["last_ts >= ?"], [since(days)]
    if unseen and category:  # only what came in after the area was last marked as seen
        where.append("last_ts > ?")
        args.append(ack_ts(category))
    if level:
        where.append("level = ?")
        args.append(level)
    if category:
        where.append("category = ?")
        args.append(category)
    if q:
        where.append("(message LIKE ? OR path LIKE ? OR code LIKE ? OR detail LIKE ?)")
        args += [f"%{q}%"] * 4
    w = " AND ".join(where)
    total = db.q(f"SELECT count(*) n FROM sys_event WHERE {w}", args, one=True)["n"]
    rows = db.q(f"SELECT * FROM sys_event WHERE {w} ORDER BY id DESC LIMIT ? OFFSET ?", args + [limit, offset])
    return rows, total


def event(eid):
    return db.q("SELECT * FROM sys_event WHERE id = ?", (eid,), one=True)
