"""Home dashboards by persona: the numbers and lists each kind of seller opens first. Everything respects the current lens."""
import datetime
import statistics

from . import data, db, intel, lens


def _open_bids(trades, per=8):
    f = {"status": "open", "sort": "closing", "trades": ",".join(trades)}
    return data.notices(f, per=per, full_history=True)


def _median(xs):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else None


def oem():
    yr = intel.this_year()
    buys = intel.work_timeline(["buy"], 5)
    opts, n_contracts = intel.options_left()
    bids, n_bids = _open_bids(["vehicle_procurement"], 1)
    cutoff = (datetime.date.today() - datetime.timedelta(days=365)).isoformat()
    funds = [r for r in intel.funding_rows() if (r["award_date"] or "") >= cutoff]
    orders = data.procurements()[:6]
    return {
        "title": "Vehicle sales", "lead": "Car and locomotive buys coming up, options left on existing orders, and what competitors are winning.",
        "kpis": [("Cars due for replacement", sum(o["cars"] for o in buys), f"by {yr + 4}, {len({o['fleet']['fleet_id'] for o in buys})} fleets", "/app/work?type=buy&years=5"),
                 ("Open vehicle procurements", n_bids, "bids out now", "/app/bids?category=vehicle_procurement"),
                 ("Options left on orders", opts, f"cars, {n_contracts} contracts", "/app/work?type=option"),
                 ("Funding awarded, 12 months", sum(r["amount_usd"] or 0 for r in funds), f"{len(funds)} awards", "/app/awards?tab=funding")],
        "money": {3},
        "table": {"title": "Upcoming vehicle buys", "more": "/app/work?type=buy", "kind": "work", "rows": sorted(buys, key=lambda o: -o["score"])[:8]},
        "side": {"title": "Recent orders", "more": "/app/work?view=orders",
                 "items": [(f"{p['manufacturer'] or ''} · {p['operator_id'] or ''}".strip(" ·"), f"{p['model'] or ''}: {p['qty_base'] or '?'} cars, {p['status'] or ''}",
                            (p["award_date"] or "")[:7], f"/app/work/orders/{p['order_id']}") for p in orders]},
        "feature": "opportunities",
    }


def component():
    v = intel.subsystem_view()
    yr = intel.this_year()
    soon = intel.subsystem_view(due_within=3)
    soon_fleets = {r["fleet"]["fleet_id"]: r["fleet"]["qty_active"] or 0 for r in soon["rows"]}
    trades = lens.PERSONA_TRADES["component"]
    bids, n_bids = _open_bids(trades, 1)
    # the subsystem with the widest coverage gets the share chart
    counts = {}
    for r in v["rows"]:
        counts[r["rec"]["subsystem"]] = counts.get(r["rec"]["subsystem"], 0) + (r["fleet"]["qty_active"] or 0)
    top = max(counts, key=counts.get) if counts else None
    share = intel.subsystem_view(top)["share"] if top else []
    return {
        "title": "Component sales", "lead": "Where each supplier's equipment is installed, and which fleets reach a midlife overhaul soon.",
        "kpis": [("Cars with a mapped subsystem", v["cars"], f"{v['fleets']} fleets", "/app/subsystems"),
                 (f"Leader, {data.SUBSYSTEMS.get(top, top) if top else 'subsystems'}", f"{share[0][2]}%" if share else "—", share[0][0] if share else "no records yet", f"/app/subsystems?subsystem={top or ''}"),
                 ("Midlife windows ≤ 3 years", sum(soon_fleets.values()), f"cars, {len(soon_fleets)} mapped fleets", "/app/subsystems?due=3"),
                 ("Open component bids", n_bids, "repair, parts and onboard systems", "/app/bids?trade=mine")],
        "table": {"title": "Mapped fleets coming due", "more": "/app/subsystems?due=5", "kind": "subsystem", "rows": intel.subsystem_view(due_within=5)["rows"][:8]},
        "bars": {"title": f"Supplier share, {data.SUBSYSTEMS.get(top, top)}" if top else "Supplier share", "rows": [(n, p, f"{c:,.0f} cars") for n, c, p in share[:6]], "suffix": "%"},
        "feature": "market",
    }


def mro():
    yr = intel.this_year()
    ovh = intel.work_timeline(["overhaul"], 3)
    snap = intel.snapshot()
    high = [fl for fl in snap.values() if (fl["delta_vs_benchmark_pct"] or 0) > 15]
    transit, _, cdy = intel.transit_costs()
    med = _median([r["vm_per_car_rev_mile"] for r in transit])
    yoy = _median([r["yoy_change_pct"] for r in transit])
    bids, n_bids = _open_bids(["overhaul_program", "component_repair"], 1)
    cands = [fl for fl in snap.values() if fl["midlife_due_year"] and not fl["last_rebuild_year"] and fl["midlife_due_year"] <= yr + 5]
    cands.sort(key=lambda fl: -(fl["est_annual_miles_per_car"] or 0))
    by_year = {}
    for o in intel.work_timeline(["overhaul"], 5):
        by_year[o["year"]] = by_year.get(o["year"], 0) + o["cars"]
    return {
        "title": "Overhaul and MRO", "lead": "Fleets in their overhaul window, the hardest-working cars, and what maintenance costs per car-mile.",
        "kpis": [("Fleets in overhaul window", len({o["fleet"]["fleet_id"] for o in ovh}), f"{sum(o['cars'] for o in ovh):,} cars, next 3 years", "/app/work?type=overhaul&years=3"),
                 ("Maintenance cost well above peers", len(high), "fleets more than 15% over", "/app/fleets?sort=delta"),
                 ("Median maintenance / car-mile", f"${med:,.2f}" if med else "—", (f"{yoy:+.0f}% YoY, {cdy} $" if yoy is not None else "NTD"), "/app/costs"),
                 ("Overhaul bids open", n_bids, "overhaul and component repair", "/app/bids?category=overhaul_program")],
        "table": {"title": "Overhaul candidates by duty cycle", "more": "/app/work?type=overhaul", "kind": "duty", "rows": cands[:8]},
        "bars": {"title": "Cars coming due for overhaul, by year", "rows": [(str(y), c, "") for y, c in sorted(by_year.items())], "suffix": ""},
        "feature": "fleet_detail",
    }


def freight():
    top, _, _ = intel.freight_costs()
    ops = data.operators(category="freight_")
    class1 = [o for o in ops if (o.get("category") or "") == "freight_class1"]
    smaller = [o for o in ops if (o.get("category") or "") != "freight_class1"]
    snap = intel.snapshot()
    yr = intel.this_year()
    # Class I railroads modernize road units at roughly 20 to 28 years (STB R-1 Sched. 710S rebuild history)
    reps = [fl for fl in snap.values() if fl["ntd_mode"] == "FR" and fl["build_year"] and fl["build_year"] <= yr - 20]
    ages = []
    for fl in snap.values():
        if fl["build_year"] and fl["ntd_mode"] == "FR":
            ages += [yr - fl["build_year"]] * min(int(fl["qty_active"] or 0), 5000)
    rows = []
    for o in class1:
        roster = intel.freight_roster(o["operator_id"])
        r1 = [r for r in top if r["operator_id"] == o["operator_id"]]
        rows.append({"op": o, "units": o["cars"], "models": [m["model"] for m in roster if m["model"] and not m["model"].lower().startswith("other")][:3],
                     "cost": _median([r["loco_cost_per_unit_mile_2025usd"] for r in r1]), "miles": _median([r["miles_per_unit"] for r in r1]),
                     "r1_units": sum(r["units_end"] or 0 for r in r1)})
    cost_all = _median([r["loco_cost_per_unit_mile_2025usd"] for r in top])
    return {
        "title": "Freight locomotives", "lead": "Locomotive rosters by railroad, R-1 cost and miles per unit, and who is due for modernization.",
        "kpis": [("Class I road and switcher units", sum(r["r1_units"] for r in rows) or sum(r["units"] or 0 for r in rows), "STB R-1, US operations" if top else "from railroad filings", "/app/operators?category=freight_class1"),
                 ("Median locomotive age", f"{statistics.median(ages):.0f} yrs" if ages else "—", "where build years are known", "/app/fleets?mode=FR&sort=age"),
                 ("Units 20+ years old", sum(fl["qty_active"] or 0 for fl in reps), f"modernization window, {len(reps)} fleets", "/app/fleets?mode=FR&sort=age"),
                 ("Cost per locomotive-mile", f"${cost_all:,.2f}" if cost_all else "—", "median, 2025 $" if cost_all else "R-1 not loaded", "/app/freight")],
        "table": {"title": "Class I locomotive fleets", "more": "/app/operators?category=freight_class1", "kind": "freight", "rows": rows},
        "side": {"title": "Regional and short line railroads", "more": "/app/operators?category=freight_",
                 "items": [(o["operator_name"], f"{(o['cars'] or 0):,} units · {o['country']}", (o.get("category") or "").replace("freight_", "")) for o in smaller[:8]]
                 + ([("Roster build-out under way", "More regionals and short lines are being added", "")] if len(smaller) < 20 else [])},
        "feature": None,
    }


def systems():
    trades = lens.PERSONA_TRADES["systems"]
    rows, n = _open_bids(trades, 8)
    _, n_all = data.notices({"status": "open"}, per=1)
    week = data.notices({"status": "open", "trades": ",".join(trades), "sort": "closing"}, per=200)[0]
    soon = [r for r in week if r["closing"] and r["closing"] <= (datetime.date.today() + datetime.timedelta(days=7)).isoformat()]
    w, a = data.scope_sql("e.ntd_mode", "o.country")
    elec = [dict(r) for r in db.fq("SELECT e.*, o.operator_name FROM seed_electrification e JOIN operator o USING (operator_id) "
                                    f"WHERE {w} AND e.status != 'removed' ORDER BY (e.status = 'active'), o.operator_name", a)]
    cutoff = (datetime.date.today() - datetime.timedelta(days=90)).isoformat()
    aw = [r for r in data.awards({"since": cutoff}, 500) if r.get("category") in trades]
    return {
        "title": "Systems and infrastructure", "lead": "Signals, track, power, stations and operations work out for bid now, and the systems that are electrifying.",
        "kpis": [("Open bids in your trades", n, f"of {n_all} open rail bids", "/app/bids?trade=mine"),
                 ("Closing in 7 days", len(soon), "in your trades", "/app/bids?trade=mine&sort=closing"),
                 ("Electrified or planned systems", len(elec), f"{sum(1 for e in elec if e['status'] == 'planned')} planned", "/app/fleets"),
                 ("Awards, last 90 days", sum(r["amount_usd"] or 0 for r in aw), f"{len(aw)} in your trades", "/app/awards?tab=awards")],
        "money": {3},
        "table": {"title": "Open bids in your trades", "more": "/app/bids?trade=mine", "kind": "bids", "rows": rows},
        "side": {"title": "Electrification", "more": None,
                 "items": [(e["operator_name"], f"{e['scope'] or ''} · {e['voltage_v'] or '?'} V {e['current_type'] or ''}".strip(), e["status"]) for e in elec[:8]]},
        "feature": None,
    }


def consult():
    """Engineering consultants (NexGen: reworked from 'Consulting and finance' for signals, systems and design firms)."""
    trades = lens.PERSONA_TRADES["consult"]
    rows, n = _open_bids(trades, 8)
    week = data.notices({"status": "open", "trades": ",".join(trades), "sort": "closing"}, per=200)[0]
    soon = [r for r in week if r["closing"] and r["closing"] <= (datetime.date.today() + datetime.timedelta(days=7)).isoformat()]
    cutoff = (datetime.date.today() - datetime.timedelta(days=180)).isoformat()
    aw = [r for r in data.awards({"since": cutoff}, 500) if r.get("category") in trades]
    fcut = (datetime.date.today() - datetime.timedelta(days=365)).isoformat()
    funds = [r for r in intel.funding_rows() if (r["award_date"] or "") >= fcut]
    return {
        "title": "Engineering and systems consulting", "lead": "Design, PM/CM, signals and systems engineering work out for bid, who won recent contracts, and the agencies with new money.",
        "kpis": [("Open bids in your trades", n, "engineering, signals and systems", "/app/bids?trade=mine"),
                 ("Closing in 7 days", len(soon), "in your trades", "/app/bids?trade=mine&sort=closing"),
                 ("Awards, last 6 months", sum(r["amount_usd"] or 0 for r in aw), f"{len(aw)} in your trades", "/app/awards?tab=awards"),
                 ("Funding awarded, 12 months", sum(r["amount_usd"] or 0 for r in funds), f"{len(funds)} grants to agencies", "/app/awards?tab=funding")],
        "money": {2, 3},
        "table": {"title": "Open bids in your trades", "more": "/app/bids?trade=mine", "kind": "bids", "rows": rows},
        "side": {"title": "Who won recently", "more": "/app/awards?tab=awards",
                 "items": [((r.get("awardee") or r.get("vendor") or "Awardee not published")[:40], f"{(r.get('agency') or r.get('operator_name') or '')[:40]} · {(r.get('title') or '')[:50]}",
                            (r.get("award_date") or "")[:7]) for r in aw[:8]]},
        "feature": None,
    }


def investor():
    """Investors and analysts (NexGen): orders, share of new orders, backlog and replacement demand by builder."""
    from . import nexgen
    yr = intel.this_year()
    share, tot = nexgen.share_new_orders(5)
    bl, _ = nexgen.backlog()
    buys = intel.work_timeline(["buy"], 5)
    med = nexgen.median_price()
    recent = nexgen.orders(5)
    priced = [{"order": f"{o['operator_id']} {o['model'] or ''}", "year": o["year"], "cars": o["cars"], "per_car": o["per_car"], "manufacturer": o["builder"], "order_id": o.get("order_id")}
              for o in recent if o["cars"]]
    demand_cars = sum(o["cars"] for o in buys)
    return {
        "title": "Orders, share and demand", "lead": "North American passenger rail orders by builder, backlog still to deliver, and replacement demand ahead.",
        "kpis": [("Cars ordered, last 5 years", tot, f"{len(recent)} orders recorded", "/app/investors"),
                 ("Cars in backlog", sum(b["cars"] for b in bl), f"{len(bl)} builders, not yet delivered", "/app/investors#backlog"),
                 ("Replacement demand", demand_cars, f"cars due by {yr + 4}", "/app/forecast"),
                 ("Demand value, 5 years", demand_cars * med if med else sum(o.get("value") or 0 for o in buys), "at the median recent price per car" if med else "estimated", "/app/investors#demand")],
        "money": {3},
        "bars": {"title": "Share of new orders, last 5 years (cars)", "rows": [(b, p, f"{c:,} cars") for b, p, c in share[:7]], "suffix": "%"},
        "table": {"title": "Recent vehicle orders", "more": "/app/investors", "kind": "orders", "rows": priced[:8]},
        "feature": "market",
    }


def agency(u=None):
    """Agency fleet and capital planning (NexGen): my agency against its peers."""
    from . import nexgen
    me = nexgen.my_agency(u) if u else None
    if not me:  # public preview or not picked yet: the largest operator in view, as an example
        snap = intel.snapshot().values()
        by = {}
        for fl in snap:
            by[fl["operator_id"]] = by.get(fl["operator_id"], 0) + (fl["qty_active"] or 0)
        oid = max(by, key=by.get) if by else None
        me = dict(db.fq("SELECT * FROM operator WHERE operator_id = ?", (oid,), one=True) or {}) if oid else {}
        example = True
    else:
        example = False
    oid = me.get("operator_id")
    yr = intel.this_year()
    mine = nexgen.agency_fleets(oid) if oid else []
    peers = nexgen.peer_ids(oid) if oid else []
    snap = intel.snapshot().values()
    peer_fleets = [fl for fl in snap if fl["operator_id"] in peers]
    my_age, peer_age = nexgen.avg_age(mine), nexgen.avg_age(peer_fleets)
    costs, _, cdy = intel.transit_costs()
    my_cost = _median([r["vm_per_car_rev_mile"] for r in costs if r["operator_id"] == oid])
    peer_cost = _median([r["vm_per_car_rev_mile"] for r in costs if r["operator_id"] in peers])
    work = [o for o in intel.work_timeline(["buy", "overhaul"], 10) if o["fleet"]["operator_id"] == oid]
    due = sum(fl["qty_active"] or 0 for fl in mine if fl.get("ulb_year") and fl["ulb_year"] <= yr + 5)  # same rule as the peer scorecard
    names = {r["operator_id"]: r["operator_name"] for r in db.fq("SELECT operator_id, operator_name FROM operator")}
    title = (me.get("operator_name") or "Your agency") + (" (example)" if example else "")
    return {
        "title": title, "lead": ("Pick your agency on the Account page to see your own fleets against your peers. " if example else "")
                 + f"Peers: {', '.join(names.get(p, p) for p in peers[:5]) or 'none found'}.",
        "kpis": [("Active cars", sum(fl["qty_active"] or 0 for fl in mine), f"{len(mine)} fleets", f"/app/fleets?operator={oid or ''}"),
                 ("Average fleet age", f"{my_age:.0f} yrs" if my_age is not None else "—", f"peers {peer_age:.0f} yrs" if peer_age is not None else "no peer data", "/app/my-agency"),
                 ("Maintenance cost / car-mile", f"${my_cost:,.2f}" if my_cost else "—", f"peer median ${peer_cost:,.2f}" if peer_cost else "NTD, no peer data", "/app/costs"),
                 ("Cars at end of life within 5 years", due, f"useful-life benchmark, by {yr + 5}", "/app/my-agency")],
        "table": {"title": "Your upcoming buys and overhauls", "more": "/app/my-agency", "kind": "work", "rows": work[:8]},
        "side": {"title": "What peers ordered recently", "more": "/app/procurements",
                 "items": [(f"{names.get((p['operator_id'] or '').split(';')[0], p['operator_id'])}", f"{p['manufacturer'] or ''} {p['model'] or ''}: {p['qty_base'] or '?'} cars",
                            (p["award_date"] or "")[:7]) for p in data.procurements() if any(x in peers for x in (p["operator_id"] or "").split(";"))][:8]},
        "feature": None,
    }


def lessor():
    """Leasing and rail finance (NexGen): ownership of the installed base and open buys big enough for lease finance."""
    from . import nexgen2
    v = nexgen2.lessor_view()
    leased_cars = sum(f["qty_active"] or 0 for f in v["leased"])
    return {
        "title": "Leasing and ownership", "lead": "Who owns the passenger and transit fleets, which are leased, and large open procurements where lease finance could compete.",
        "kpis": [("Leased or third-party owned cars", leased_cars, f"{len(v['leased'])} fleets", "/app/lessors"),
                 ("Owners and lessors", len(v["owners"]), "named in NTD or our records", "/app/lessors#owners"),
                 ("Open buys, next 5 years", v["n_buys"], "with an open procurement", "/app/lessors#buys"),
                 ("Value of those buys", v["buys_value"], "at recorded unit costs", "/app/lessors#buys")],
        "money": {3},
        "bars": {"title": "Active cars by ownership type", "rows": [(k.capitalize(), n, f"{n:,} cars") for k, n in v["ownership"][:7]], "suffix": ""},
        "table": {"title": "Largest open buys", "more": "/app/lessors#buys", "kind": "work", "rows": v["buys"][:8]},
        "feature": "market",
    }


BUILDERS = {"lessor": lessor, "oem": oem, "component": component, "mro": mro, "freight": freight, "systems": systems, "consult": consult,
            "investor": investor, "agency": agency}


def home(persona, u=None):
    if persona not in lens.personas():  # freight is parked: a member who picked it before gets the rolling stock dashboard
        persona = "oem" if persona else persona
    fn = BUILDERS.get(persona)
    if not fn:
        return None
    d = fn(u) if persona == "agency" else fn()
    d["persona"] = persona
    d["label"] = lens.PERSONAS[persona]["label"]
    return d
