"""Funding programs (fundprog.py): program catalog and pages, funding deadline calendar, freight funding view and locomotive
demand signal. Passenger app under /app/funding-programs (plan feature fleet_detail); freight portal under /rail/funding."""
from fastapi import APIRouter, Depends, HTTPException, Request

from . import auth, fundprog as F
from .main import render
from .routes_app import csv_response
from .routes_rail import gate

app = APIRouter(prefix="/app")
rail = APIRouter(prefix="/rail")
COLS = ["start_date", "program", "recipient", "state", "segment", "work", "amount_usd", "award_id", "description"]


def _rows(rows):
    return [dict(r, program=F.PROG[r["prog"]][1] if r.get("prog") in F.PROG else r["aln"]) for r in rows]


def _render(request, u, portal, view, arg=None):
    railp = portal == "freight"
    root = "/rail/funding" if railp else "/app/funding-programs"
    q = request.query_params
    ctx = dict(user=u, F=F, rail=railp, root=root, view=view)
    if view == "catalog":
        ctx["rows"] = F.catalog("freight" if railp else None if q.get("all") else "passenger")
    elif view == "program":
        p = F.program(arg)
        if not p:
            raise HTTPException(404)
        if q.get("export"):
            return csv_response("consist-awards-" + arg, COLS, _rows(p["awards"]))
        ctx["p"] = p
    elif view == "calendar":
        ctx["up"], ctx["recent"] = F.calendar()
    elif view == "freight":
        seg, work, prog = q.get("seg") or "", q.get("work") or "", q.get("prog") or ""
        rows, summ = F.freight(seg or None, work or None, prog or None)
        if q.get("export"):
            return csv_response("consist-freight-grants", COLS, _rows(rows))
        ctx.update(rows=rows[:400], n=len(rows), total=sum(r["amount_usd"] for r in rows), summ=summ, seg=seg, work=work, prog=prog)
    elif view == "loco":
        rows, by_year = F.locomotives()
        if q.get("export"):
            return csv_response("consist-locomotive-grants", COLS, _rows(rows))
        ctx.update(rows=rows, by_year=by_year, total=sum(r["amount_usd"] for r in rows))
    return render(request, "fundprog.html", **ctx)


def _app_ok(u):
    return u.is_admin or u.can("fleet_detail")


def _locked(request, u):
    return render(request, "app/locked.html", user=u, feature="fleet_detail", title="Funding programs")


@app.get("/funding-programs")
def app_catalog(request: Request, u=Depends(auth.require_user)):
    return _render(request, u, "passenger", "catalog") if _app_ok(u) else _locked(request, u)


@app.get("/funding-programs/calendar")
def app_calendar(request: Request, u=Depends(auth.require_user)):
    return _render(request, u, "passenger", "calendar") if _app_ok(u) else _locked(request, u)


@app.get("/funding-programs/{pid}")
def app_program(request: Request, pid: str, u=Depends(auth.require_user)):
    return _render(request, u, "passenger", "program", pid) if _app_ok(u) else _locked(request, u)


def _g(request, title):
    return gate(request, title)


@rail.get("/funding")
def rail_freight(request: Request):
    u, r = _g(request, "Freight rail funding")
    return r or _render(request, u, "freight", "freight")


@rail.get("/funding/programs")
def rail_catalog(request: Request):
    u, r = _g(request, "Funding programs")
    return r or _render(request, u, "freight", "catalog")


@rail.get("/funding/calendar")
def rail_calendar(request: Request):
    u, r = _g(request, "Funding calendar")
    return r or _render(request, u, "freight", "calendar")


@rail.get("/funding/locomotives")
def rail_loco(request: Request):
    u, r = _g(request, "Locomotive funding signal")
    return r or _render(request, u, "freight", "loco")


@rail.get("/funding/programs/{pid}")
def rail_program(request: Request, pid: str):
    u, r = _g(request, "Funding programs")
    return r or _render(request, u, "freight", "program", pid)
