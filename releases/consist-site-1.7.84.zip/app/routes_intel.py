"""Sales tools in the member app: opportunities, replacement forecast, suppliers, builders, market share, fleet lists,
account notes and contacts, account briefs, fleet change updates and CRM export."""
import json
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Form, HTTPException, Request

from . import auth, data, db, intel, lens, mailer
from .main import flash, redirect, render
from .routes_app import FLEET_KEYS, bar_links, bar_pick, bar_rows, csv_response, params, watched

router = APIRouter(prefix="/app")
U = Depends(auth.require_user)

OPP_KEYS = ("offering", "years", "mode", "cls", "country", "operator", "oem", "signal", "subsystem", "supplier", "q", "sort", "dir", "ordered")
OPP_SORTS = {"score": (lambda o: o["score"], "desc"), "year": (lambda o: o["year"], "asc"), "value": (lambda o: o["value"], "desc"),
             "cars": (lambda o: o["cars"], "desc"), "fleet": (lambda o: f"{o['fleet']['manufacturer'] or ''} {o['fleet']['model_name']}".lower(), "asc"),
             "operator": (lambda o: (o["fleet"]["operator_name"] or "").lower(), "asc"), "built": (lambda o: o["fleet"]["build_year"], "asc")}


def locked(request, u, feature, title):
    return render(request, "app/locked.html", user=u, feature=feature, title=title)


def facets():
    snap = intel.snapshot().values()
    return {"modes": sorted({f["ntd_mode"] for f in snap if f["ntd_mode"]}), "classes": sorted({data.cls_key(f["vehicle_class"]) for f in snap if f["vehicle_class"]}),
            "oems": sorted({f["manufacturer"] for f in snap if f["manufacturer"]}),
            "operators": sorted({(f["operator_id"], f["operator_name"]) for f in snap}, key=lambda o: o[1] or ""),
            "suppliers": [(s["supplier_id"], s["name"]) for s in intel.suppliers() if s["n_fleets"]]}


# ---------- opportunities ----------

@router.get("/opportunities")
def opportunities_old(request: Request, u=U):
    if request.query_params.get("export"):
        return opportunities(request, u)
    return redirect("/app/work?" + urlencode({"view": "ranked", **request.query_params}))


def opportunities(request: Request, u):
    if not u.can("opportunities"):
        return locked(request, u, "opportunities", "Opportunity finder")
    f = params(request, OPP_KEYS)
    offering = f.get("offering") if f.get("offering") in intel.OFFERINGS else "vehicles"
    try:
        years = min(20, max(1, int(f.get("years") or 10)))
    except ValueError:
        years = 10
    rows = intel.opportunities(offering, years, f)
    sort = f.get("sort") if f.get("sort") in OPP_SORTS else "score"
    sdir = f.get("dir") if f.get("dir") in ("asc", "desc") else OPP_SORTS[sort][1]
    if sort != "score" or sdir != "desc":
        rows = data.sort_rows(rows, OPP_SORTS, sort, sdir)
    exp = request.query_params.get("export")
    if exp:
        if exp in ("salesforce", "hubspot"):
            if not u.can("crm_export"):
                raise HTTPException(403, "CRM export is on paid plans.")
            out = intel.crm_rows(rows, exp)
            return csv_response(f"consist-{exp}-opportunities", list(out[0].keys()) if out else ["Opportunity Name"], out)
        if not u.can("export"):
            raise HTTPException(403, "CSV export is on paid plans.")
        flat = [{"score": o["score"], "event": intel.EVENT_LABELS.get(o["event"]), "year": o["year"], "value_usd": round(o["value"]),
                 "unit_cost_usd": o["unit"], "cars": o["cars"], "operator": o["fleet"]["operator_name"], "manufacturer": o["fleet"]["manufacturer"],
                 "model": o["fleet"]["model_name"], "vehicle_class": o["fleet"]["vehicle_class"], "mode": o["fleet"]["ntd_mode"],
                 "built": o["fleet"]["build_year"], "incumbent": o["incumbent"], "signals": "; ".join(s[1] for s in o["fleet"]["signals"]),
                 "fleet_url": f"/app/fleets/{o['fleet']['fleet_id']}"} for o in rows]
        return csv_response("consist-opportunities", list(flat[0].keys()) if flat else ["score"], flat)
    total = sum(o["value"] for o in rows)
    base = {k: v for k, v in f.items() if k not in ("sort", "dir")}
    base.update(offering=offering, years=years)
    on = f.get("ordered") == "1"
    n_ordered = intel.ordered_hidden({k: v for k, v in f.items() if k in ("mode", "cls", "country", "operator", "oem", "q")}) if offering == "vehicles" else 0
    ordered_href = "/app/work?" + urlencode({k: v for k, v in {"view": "ranked", **f, "ordered": "" if on else "1"}.items() if v})
    return render(request, "app/opportunities.html", user=u, f=f, offering=offering, years=years, rows=rows[:300], n=len(rows), total=total,
                  n_ordered=n_ordered, ordered_on=on, ordered_href=ordered_href,
                  cars=sum(o["cars"] for o in rows), facets=facets(), offerings=intel.OFFERINGS, signals=intel.SIGNALS, sort=sort, sdir=sdir,
                  sort_base="/app/work?" + urlencode({"view": "ranked", **base}), qs=urlencode({**base, "sort": sort, "dir": sdir}),
                  lists=intel.lists_for(u) if u.can("lists") else [])


# ---------- replacement forecast ----------

@router.get("/forecast")
def forecast_old(request: Request, u=U):
    if request.query_params.get("export"):
        return forecast(request, u)
    return redirect("/app/work?" + urlencode({"view": "forecast", **request.query_params}))


def forecast(request: Request, u):
    if not u.can("opportunities"):
        return locked(request, u, "opportunities", "Replacement forecast")
    f = params(request, ("mode", "cls", "country", "group", "years"))
    group = f.get("group") if f.get("group") in ("vehicle_class", "ntd_mode", "country", "manufacturer") else "vehicle_class"
    try:
        years = min(25, max(5, int(f.get("years") or 15)))
    except ValueError:
        years = 15
    items = []
    by_year, totals, overdue = intel.forecast(years, group, f, items)
    keys = [k for k, _ in sorted(totals.items(), key=lambda kv: -kv[1]["cars"])][:6]
    other = [k for k in totals if k not in keys]
    if other:
        for y, d in by_year.items():
            d["other"] = sum(d.pop(k, 0) for k in other if k in d) + d.get("other", 0)
        keys.append("other")
    lab = {"vehicle_class": data.CLASSES, "ntd_mode": data.MODES}.get(group, {})
    labels = {k: lab.get(k, k or "Other") for k in keys}
    labels["other"] = "Other"
    if request.query_params.get("export") and u.can("export"):
        rows = [{"group": labels.get(k, k), "fleets": t["fleets"], "cars": t["cars"], "replacement_value_usd": round(t["value"])}
                for k, t in sorted(totals.items(), key=lambda kv: -kv[1]["cars"])]
        return csv_response("consist-replacement-forecast", ["group", "fleets", "cars", "replacement_value_usd"], rows)
    for it in items:
        it["bar"] = it["group"] if it["group"] in keys else "other"
    items.sort(key=lambda it: (it["year"], -it["cars"]))
    sel = bar_pick(request)
    n_all = len(items)
    items = bar_rows(items, sel, lambda it: it["year"], lambda it: it["bar"])
    bar_href = bar_links("/app/work", {"view": "forecast", **f})
    return render(request, "app/forecast.html", user=u, f=f, group=group, years=years, by_year=by_year, keys=keys, labels=labels, bar_href=bar_href,
                  totals=sorted(totals.items(), key=lambda kv: -kv[1]["cars"]), overdue=overdue, facets=facets(), glabels=lab,
                  items=items[:300], n=len(items), n_all=n_all, sel=sel, qs=urlencode({"view": "forecast", **f}),
                  total_cars=sum(t["cars"] for t in totals.values()), total_value=sum(t["value"] for t in totals.values()))


# ---------- suppliers, builders, market ----------

@router.get("/suppliers")
def suppliers(request: Request, u=U):
    rows = intel.suppliers()
    if request.query_params.get("sub"):  # a subsystem pill was clicked (1.7.4)
        rows = [r for r in rows if request.query_params["sub"] in (r.get("subsystems") or [])]
    snap = intel.snapshot()
    covered = sum(1 for fl in snap.values() if fl["installed"])
    from . import supplierdir as SD
    q = dict(request.query_params)
    drows = SD.directory(q)
    if q.get("export") and (u.is_admin or u.can("export")):  # CSV export is a paid feature
        cols = ["name", "website", "country", "sources", "segments", "status", "listing", "revenue", "rev_year", "margin", "apta_active",
                "apta_ordered", "apta_agencies", "fleets", "cars", "awards", "award_usd"]
        return csv_response("consist-supplier-directory", cols, drows)
    return render(request, "app/suppliers.html", user=u, rows=rows, covered=covered, n_fleets=len(snap), SD=SD, drows=drows, q=q,
                  cars_cov=sum(fl["qty_active"] or 0 for fl in snap.values() if fl["installed"]),
                  cars_all=sum(fl["qty_active"] or 0 for fl in snap.values()))


@router.get("/suppliers/{sid}")
def supplier(request: Request, sid: str, u=U):
    d = intel.supplier(sid)
    if not d:
        raise HTTPException(404)
    if not u.can("market"):
        return locked(request, u, "market", f"{d['name']} installed base")
    if request.query_params.get("export") and u.can("export"):
        rows = [{"subsystem": r["subsystem"], "product": r["product"], "operator": r["fleet"]["operator_name"], "manufacturer": r["fleet"]["manufacturer"],
                 "model": r["fleet"]["model_name"], "cars": r["fleet"]["qty_active"], "built": r["fleet"]["build_year"],
                 "midlife_due": r["fleet"]["midlife_due_year"], "confidence": r["confidence"], "source": r["source_url"]} for r in d["rows"]]
        return csv_response(f"consist-installed-base-{sid}", list(rows[0].keys()) if rows else ["subsystem"], rows)
    return render(request, "app/supplier.html", user=u, d=d)


@router.get("/market")
def market(request: Request, u=U):
    if not u.can("market"):
        return locked(request, u, "market", "Market share")
    f = params(request, ("cls", "mode", "sub"))
    comps = dict(intel.COMPONENTS, prime_mover="Prime mover", hep="Head-end power", signal_onboard="Onboard signaling")
    if f.get("sub") and f["sub"] not in comps:
        f.pop("sub")
    m = intel.market(f.get("cls"), f.get("mode"))
    ms = intel.market_sub(f["sub"], f.get("cls"), f.get("mode")) if f.get("sub") else None
    from . import marketmap  # 1.7.76 market map (Marimekko)
    fq = "".join(f"&{k}={f[k]}" for k in ("cls", "mode") if f.get(k))
    mm = None if ms else marketmap.blob(m, comps, fq, bool(u.bids), f.get("cls"), f.get("mode"))
    return render(request, "app/market.html", user=u, f=f, m=m, ms=ms, facets=facets(), components=comps, mm=mm)


@router.get("/search")
def search(request: Request, u=U):
    q = (request.query_params.get("q") or "").strip()[:100]
    from . import sitesearch
    rs = sitesearch.search(q, u)
    return render(request, "app/search.html", user=u, q=q, rs=rs, r=(rs or {}).get("ib"))


@router.get("/market/drill")
def market_drill(request: Request, u=U):
    if not u.can("market"):
        return locked(request, u, "market", "Market share")
    f = params(request, ("cls", "mode", "by", "name", "comp"))
    if f.get("by") not in ("builder", "supplier") or not f.get("name"):
        return redirect("/app/market")
    d = intel.market_drill(f["by"], f["name"], f.get("comp"), f.get("cls"), f.get("mode"))
    comps = dict(intel.COMPONENTS, prime_mover="Prime mover", hep="Head-end power", signal_onboard="Onboard signaling")
    if request.query_params.get("export") and u.can("export"):
        rows = [{"operator": o["operator_name"], "fleet_id": h["fl"]["fleet_id"], "model": h["fl"]["model_name"], "builder": h["fl"]["manufacturer"],
                 "type": h["fl"]["vehicle_class"], "mode": h["fl"]["ntd_mode"], "built": h["fl"]["build_year"], "active_cars": h["fl"]["qty_active"],
                 "cars_counted": round(h["cars"], 1), "product": h["product"]} for o in d["operators"] for h in o["fleets"]]
        return csv_response("market-share-" + data.slug(f["name"]), list(rows[0].keys()) if rows else ["operator"], rows)
    return render(request, "app/market_drill.html", user=u, f=f, d=d, comp_label=comps.get(f.get("comp") or "", f.get("comp")),
                  qs=urlencode(f), builder_slug=data.slug(f["name"]))


@router.get("/builders")
def builders(request: Request, u=U):
    return render(request, "app/builders.html", user=u, rows=intel.builders())


@router.get("/builders/{slug}")
def builder(request: Request, slug: str, u=U):
    d = intel.builder(slug)
    if not d:
        raise HTTPException(404)
    model = request.query_params.get("model")
    pick = next((m for m in d["models"] if m["model"] == model), None)
    customers = []
    if pick:
        by = {}
        for fl in pick["fleets"]:
            c = by.setdefault(fl["operator_id"], {"operator_id": fl["operator_id"], "operator_name": fl["operator_name"], "fleets": [], "cars": 0})
            c["fleets"].append(fl)
            c["cars"] += fl["qty_active"] or 0
        customers = sorted(by.values(), key=lambda c: -c["cars"])
    return render(request, "app/builder.html", user=u, d=d, pick=pick, customers=customers)


# ---------- roster ----------

@router.get("/fleets/{fid}/roster")
def roster(request: Request, fid: int, u=U):
    fl = intel.snapshot_all().get(fid)
    if not fl:
        raise HTTPException(404)
    if not u.can("fleet_detail"):
        return locked(request, u, "fleet_detail", "Car-by-car roster")
    rows = intel.roster(fid)
    if request.query_params.get("export") and u.can("export"):
        return csv_response(f"roster-{fid}", ["unit_number", "position", "build_year", "status", "disposition", "car_role", "number_basis",
                                               "confidence", "notes"], rows)
    return render(request, "app/roster.html", user=u, fl=fl, rows=rows)


# ---------- lists ----------

@router.get("/lists")
def lists(request: Request, u=U):
    if not u.can("lists"):
        return locked(request, u, "lists", "Fleet lists")
    return render(request, "app/lists.html", user=u, rows=intel.lists_for(u))


@router.post("/lists")
async def list_create(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    if not u.can("lists"):
        raise HTTPException(403, "Fleet lists are on paid plans.")
    name = str(form.get("name") or "").strip()[:80] or "Untitled list"
    lid = db.x("INSERT INTO fleet_list (owner_id, name, created, updated) VALUES (?,?,?,?)", (intel.owner_id(u), name, db.now(), db.now()))
    ids = _ids_from_form(form)
    _add(lid, ids)
    flash(request, f"Created \"{name}\"" + (f" with {len(ids)} fleets." if ids else "."))
    back = str(form.get("back") or "")
    return redirect(back if back.startswith("/app") and not ids else f"/app/lists/{lid}")


def _ids_from_form(form):
    ids = [int(x) for x in form.getlist("fleet_id") if str(x).isdigit()]
    if form.get("from_filter"):
        import json
        f = {k: v for k, v in json.loads(form.get("from_filter")).items() if k in FLEET_KEYS + ("signal", "subsystem", "supplier")}
        restrict = intel.fleet_ids_matching(f)
        if restrict is not None:
            f["_ids"] = restrict
        rows, _, _ = data.fleets(f, per=500)
        ids += [r["fleet_id"] for r in rows]
    if form.get("from_opps"):
        import json
        f = json.loads(form.get("from_opps"))
        rows = intel.opportunities(f.get("offering", "vehicles"), int(f.get("years") or 10), f)
        ids += [o["fleet"]["fleet_id"] for o in rows[:500]]
    return list(dict.fromkeys(ids))


def _add(lid, ids):
    for fid in ids:
        db.x("INSERT OR IGNORE INTO fleet_list_item (list_id, fleet_id, added) VALUES (?,?,?)", (lid, fid, db.now()))
    db.x("UPDATE fleet_list SET updated = ? WHERE id = ?", (db.now(), lid))


@router.get("/lists/{lid}")
def list_view(request: Request, lid: int, u=U):
    if not u.can("lists"):
        return locked(request, u, "lists", "Fleet lists")
    lst = intel.get_list(u, lid)
    if not lst:
        raise HTTPException(404)
    items = intel.list_fleets(lid)
    if request.query_params.get("export") and u.can("export"):
        rows = [{"operator": i["fleet"]["operator_name"], "manufacturer": i["fleet"]["manufacturer"], "model": i["fleet"]["model_name"],
                 "vehicle_class": i["fleet"]["vehicle_class"], "cars": i["fleet"]["qty_active"], "built": i["fleet"]["build_year"],
                 "midlife_due": i["fleet"]["midlife_due_year"], "end_of_life": i["fleet"]["ulb_year"],
                 "maint_usd_per_car_mile": i["fleet"]["maint_cost_per_car_mile"], "signals": "; ".join(s[1] for s in i["fleet"]["signals"]),
                 "note": i["note"]} for i in items]
        return csv_response(f"consist-list-{lid}", list(rows[0].keys()) if rows else ["operator"], rows)
    return render(request, "app/list.html", user=u, lst=lst, items=items)


@router.post("/lists/{lid}")
async def list_update(request: Request, lid: int, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    lst = intel.get_list(u, lid)
    if not lst:
        raise HTTPException(404)
    action = form.get("action")
    if action == "delete":
        db.x("DELETE FROM fleet_list_item WHERE list_id = ?", (lid,))
        db.x("DELETE FROM fleet_list WHERE id = ?", (lid,))
        flash(request, f"Deleted \"{lst['name']}\".")
        return redirect("/app/lists")
    if action == "rename":
        db.x("UPDATE fleet_list SET name = ?, updated = ? WHERE id = ?", (str(form.get("name") or lst["name"])[:80], db.now(), lid))
    elif action == "add":
        ids = _ids_from_form(form)
        _add(lid, ids)
        flash(request, f"Added {len(ids)} fleet{'s' if len(ids) != 1 else ''} to \"{lst['name']}\".")
        back = str(form.get("back") or "")
        if back.startswith("/app"):
            return redirect(back)
    elif action == "remove":
        db.x("DELETE FROM fleet_list_item WHERE list_id = ? AND fleet_id = ?", (lid, int(form.get("fleet_id") or 0)))
    elif action == "note":
        db.x("UPDATE fleet_list_item SET note = ? WHERE list_id = ? AND fleet_id = ?", (str(form.get("note") or "")[:500], lid, int(form.get("fleet_id") or 0)))
    return redirect(f"/app/lists/{lid}")


# ---------- account notes and contacts ----------

def _team_feature(u):
    if not u.can("account_notes"):
        raise HTTPException(403, "Account notes and contacts are on paid plans.")


@router.post("/operators/{oid}/notes")
def note_add(request: Request, oid: str, csrf: str = Form(""), body: str = Form(""), fleet_id: str = Form(""), back: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    _team_feature(u)
    if body.strip():
        db.x("INSERT INTO account_note (owner_id, operator_id, fleet_id, body, author, ts) VALUES (?,?,?,?,?,?)",
             (intel.owner_id(u), oid, int(fleet_id) if fleet_id.isdigit() else None, body.strip()[:4000], u.name or u.email, db.now()))
    return redirect(back if back.startswith("/app") else f"/app/operators/{oid}#notes")


@router.post("/notes/{nid}/delete")
def note_delete(request: Request, nid: int, csrf: str = Form(""), back: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    db.x("DELETE FROM account_note WHERE id = ? AND owner_id = ?", (nid, intel.owner_id(u)))
    return redirect(back if back.startswith("/app") else "/app")


@router.post("/operators/{oid}/contacts")
def contact_save(request: Request, oid: str, csrf: str = Form(""), cid: str = Form(""), name: str = Form(""), title: str = Form(""),
                 email: str = Form(""), phone: str = Form(""), notes: str = Form(""), delete: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    _team_feature(u)
    own = intel.owner_id(u)
    if delete and cid.isdigit():
        db.x("DELETE FROM contact WHERE id = ? AND owner_id = ?", (int(cid), own))
    elif name.strip():
        vals = (name.strip()[:120], title.strip()[:120], email.strip()[:160], phone.strip()[:60], notes.strip()[:1000], db.now())
        if cid.isdigit():
            db.x("UPDATE contact SET name=?, title=?, email=?, phone=?, notes=?, updated=? WHERE id = ? AND owner_id = ?", vals + (int(cid), own))
        else:
            db.x("INSERT INTO contact (name, title, email, phone, notes, updated, owner_id, operator_id) VALUES (?,?,?,?,?,?,?,?)", vals + (own, oid))
    return redirect(f"/app/operators/{oid}#contacts")


# ---------- account brief ----------

@router.get("/operators/{oid}/brief")
def brief(request: Request, oid: str, u=U):
    """1.7.52: the modules come from the Account brief menu on the operator page (?m=, remembered), else the last choice."""
    if not u.can("fleet_detail"):
        return locked(request, u, "fleet_detail", "Account brief")
    from . import brief as B
    from .routes_app import operator_ctx
    ctx = operator_ctx(u, oid, n_bids=10, n_awards=10)
    rail = bool(ctx["rail"])
    sel = B.chosen(u, request, rail)
    acc = B.access(u)
    if acc.get("meetings") == "preview":
        ctx["meet"] = dict(ctx["meet"], agenda=ctx["meet"]["agenda"][:3], docs=ctx["meet"]["docs"][:3])
    from . import reportkey  # 1.7.54 key to terms at the end of the brief
    x = ctx["x"]
    grades = {str(r.get("confidence") or "")[:1].upper() for r in (x.get("plans") or []) + (x.get("funding") or []) + (x.get("contracts") or [])} - {""}
    extra = B.gather(u, oid, sel)
    meet, d = ctx["meet"], ctx["d"]
    has = {"grants": extra.get("grants"), "budget": extra.get("budget"), "capital": extra.get("capital"), "oncall": extra.get("oncall"),
           "meetings": meet.get("upcoming") or meet.get("agenda") or meet.get("docs"), "orders": d.get("procurements"),
           "programs": x.get("plans") or x.get("funding") or x.get("contracts"), "signals": x.get("signals"),
           "reliability": x.get("modes"), "costs": ctx.get("series"), "r1": (ctx["rail"] or {}).get("hist")}
    shown = [k for k in sel if k not in has or has[k]]  # only define what the brief actually shows
    key = reportkey.for_brief(shown, modes=list((x.get("modes") or {}).keys()), mode_names=data.MODES, grades=grades)
    return render(request, "app/brief.html", user=u, **ctx, sel=set(sel), sel_labels=[B.LABELS[k] for k in sel], extra=extra,
                  costs=intel.unit_costs(), groups=B.offered(u, rail), pro=True, key_terms=key)


# ---------- fleet change updates ----------

@router.get("/updates")
def updates_old(request: Request, u=U):
    return redirect("/app/alerts?tab=fleet")


def updates(request: Request, u):
    if not u.can("fleet_alerts"):
        return locked(request, u, "fleet_alerts", "Fleet change alerts")
    from . import territory
    t = territory.for_user(u)
    ops = sorted({(f["operator_id"], f["operator_name"] or f["operator_id"]) for f in intel.snapshot_all().values()}, key=lambda x: x[1].lower())
    return render(request, "app/updates.html", user=u, rows=intel.events_for_user(u, limit=200), freq=intel.pref(u, "fleet_email", "weekly"),
                  n_watch=len(watched(u, "fleet")) + len(watched(u, "operator")), n_lists=len(intel.lists_for(u)), ff=intel.fleet_filter(u),
                  kinds=[(k, v) for k, v in intel.FIELD_LABELS.items()], op_opts=ops, ter_label=territory.label(t) if territory.is_set(t) else "",
                  mail_on=mailer.configured())


@router.post("/updates/test")
async def updates_test(request: Request, u=U):
    """1.7.79 (Justin 11-19): email a fleet update digest built from the member's current settings, marked as a test."""
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    if not u.can("fleet_alerts"):
        return redirect("/app/alerts?tab=fleet")
    from . import alerts
    ok, msg = alerts.send_test_fleet(u)
    flash(request, msg, "ok" if ok else "bad")
    return redirect("/app/alerts?tab=fleet")


@router.post("/updates/prefs")
async def updates_prefs(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    fleet_email = form.get("fleet_email", "")
    if fleet_email in ("off", "daily", "weekly"):
        intel.set_pref(u, "fleet_email", fleet_email)
    if form.get("settings") == "1":  # 1.7.74: what Fleet updates covers
        from . import data
        ok_ops = {f["operator_id"] for f in intel.snapshot_all().values()}
        pick = lambda k, ok: list(dict.fromkeys(v for v in form.getlist(k) if v in ok))  # noqa: E731
        ff = {"scope": "all" if form.get("scope") == "all" else "followed", "kinds": pick("kinds", intel.FIELD_LABELS),
              "modes": pick("modes", data.MODES), "classes": pick("classes", data.CLASSES), "ops": pick("ops", ok_ops),
              "countries": pick("countries", lens.REGIONS), "territory": form.get("territory") == "1"}
        if ff["scope"] == "all" and not any(ff[k] for k in ("kinds", "modes", "classes", "ops", "countries", "territory")):
            flash(request, "Saved. Every fleet change in the database is a lot of email: narrow it with the boxes below if it gets noisy.")
        else:
            flash(request, "Fleet update settings saved.")
        intel.set_pref(u, "fleet_filter", json.dumps(ff))
    elif fleet_email in ("off", "daily", "weekly"):
        flash(request, "Fleet change emails: " + fleet_email + ".")
    return redirect("/app/alerts?tab=fleet")
