"""First-party site usage log and the Admin > Usage reports (Justin, 2026-11-04).

Every page view and member action on the public site, /app and /rail is written to usage_event by UsageMiddleware. No cookies and
no third-party services: anonymous visitors are grouped by a daily-rotating hash of a shortened IP address and browser, so a visitor
can't be followed from one day to the next. Signed-in members are recorded by account. Admins and bots are not logged. Rows older
than RETAIN_DAYS are deleted."""
import datetime
import hashlib
import ipaddress
import random
import re
import time
from urllib.parse import parse_qsl, urlsplit

from . import config, db

RETAIN_DAYS = 400  # about 13 months, so a year-over-year comparison is possible
LIVE_MINUTES = 5
SKIP = re.compile(r"^/(static|admin|healthz|robots\.txt|sitemap|feed\.xml|favicon|apple-touch|indexnow|stripe|unsubscribe|ambassador/preview|"
                  r"\.well-known)|\.(xml|txt|json|png|jpg|svg|ico|js|css|map)$")
BOT = re.compile(r"bot|crawl|spider|slurp|preview|monitor|uptime|curl|wget|python|httpx|headless|lighthouse|scan|facebookexternal|"
                 r"embedly|pingdom|validator|feedfetcher|go-http|java/|okhttp", re.I)
_admins = {"t": 0, "ids": set()}


def ensure():
    with db._lock:
        c = db.connect()
        try:
            c.executescript("""
CREATE TABLE IF NOT EXISTS usage_event (id INTEGER PRIMARY KEY, ts TEXT, sid TEXT, user_id INTEGER, kind TEXT, path TEXT, detail TEXT,
  source TEXT, device TEXT, ip TEXT);
CREATE INDEX IF NOT EXISTS usage_event_ts ON usage_event (ts);
CREATE INDEX IF NOT EXISTS usage_event_user ON usage_event (user_id, ts);
""")
            c.commit()
        finally:
            c.close()


def short_ip(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return ""
    net = ipaddress.ip_network(f"{ip}/{24 if a.version == 4 else 48}", strict=False)
    return str(net.network_address)


def device(ua):
    ua = ua or ""
    kind = "phone" if re.search(r"iPhone|Android.+Mobile|Mobile Safari", ua) else "tablet" if re.search(r"iPad|Android", ua) else "desktop"
    br = ("Edge" if "Edg/" in ua else "Chrome" if "Chrome/" in ua else "Firefox" if "Firefox/" in ua
          else "Safari" if "Safari/" in ua else "Outlook" if "Outlook" in ua else "other")
    os_ = ("Windows" if "Windows" in ua else "iOS" if re.search(r"iPhone|iPad", ua) else "Mac" if "Mac OS" in ua
           else "Android" if "Android" in ua else "Linux" if "Linux" in ua else "")
    return " ".join(x for x in (kind, br, os_) if x)


def source(referer, query, host):
    """Where the visit came from: utm_source, or the referring site's host (internal clicks are blank)."""
    q = dict(query)
    if q.get("utm_source"):
        return q["utm_source"][:60].lower()
    if q.get("ref"):
        return q["ref"][:60].lower()
    if not referer:
        return ""
    h = (urlsplit(referer).hostname or "").lower()
    if not h or h == host or h.endswith("consist-na.com"):
        return ""
    h = h[4:] if h.startswith("www.") else h
    for k, v in (("google.", "google"), ("bing.", "bing"), ("duckduckgo", "duckduckgo"), ("linkedin", "linkedin"), ("lnkd.in", "linkedin"),
                 ("yahoo.", "yahoo"), ("chatgpt", "chatgpt"), ("perplexity", "perplexity"), ("claude.ai", "claude"),
                 ("outlook", "email"), ("mail.", "email")):
        if k in h:
            return v
    return h[:60]


def classify(method, path, query, status, ctype):
    q = dict(query)
    if method == "GET":
        if status == 200 and (q.get("export") or path.endswith(".csv") or "text/csv" in ctype):
            return "export"
        return "view" if status == 200 and "text/html" in ctype else None
    if method != "POST" or status >= 400:
        return None
    if path in ("/signup",) and status in (302, 303):
        return "signup"
    if path == "/login" and status in (302, 303):
        return "login"
    if path.endswith("/analyst") or path.endswith("/brief"):
        return "ai"
    if path.startswith("/app/alerts"):
        return "alert"
    if path in ("/app/upgrade", "/app/billing/portal"):
        return "billing"
    if path == "/app/watch":
        return "watch"
    if path.startswith(("/app/", "/rail/")) or path in ("/contact", "/request"):
        return "action"
    return None


def _is_admin(uid):
    now = time.time()
    if now - _admins["t"] > 300:
        _admins["ids"] = {r["id"] for r in db.q("SELECT id FROM user WHERE role = 'admin'")}
        _admins["t"] = now
    return uid in _admins["ids"]


def log(scope, status, ctype, uid):
    method, path = scope.get("method", ""), scope.get("path", "")
    if SKIP.search(path):
        return
    headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
    ua = headers.get("user-agent", "")
    if not ua or BOT.search(ua):
        return
    if uid and _is_admin(uid):
        return
    query = parse_qsl(scope.get("query_string", b"").decode("latin-1"))
    kind = classify(method, path, query, status, ctype)
    if not kind:
        return
    xff = headers.get("x-forwarded-for", "").split(",")[0].strip()
    ip = short_ip(xff or (scope.get("client") or ("", 0))[0])
    day = datetime.date.today().isoformat()
    sid = hashlib.sha256(f"{config.SECRET_KEY}|{ip}|{ua}|{day}".encode()).hexdigest()[:16]
    detail = ""
    keep = [(k, v) for k, v in query if k in ("q", "y", "seg", "mode", "op", "rail", "lens", "export", "cmp", "plan")]
    if keep:
        detail = "&".join(f"{k}={v[:60]}" for k, v in keep)[:200]
    host = (headers.get("host") or "").split(":")[0].lower()
    db.x("INSERT INTO usage_event (ts, sid, user_id, kind, path, detail, source, device, ip) VALUES (?,?,?,?,?,?,?,?,?)",
         (db.now(), sid, uid, kind, path[:200], detail, source(headers.get("referer", ""), query, host), device(ua), ip))
    if random.random() < 0.002:
        cut = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=RETAIN_DAYS)).replace(microsecond=0).isoformat()
        db.x("DELETE FROM usage_event WHERE ts < ?", (cut,))


class UsageMiddleware:
    """Records each page view and member action after the response is sent. Never breaks a request."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("method") not in ("GET", "POST"):
            return await self.app(scope, receive, send)
        meta = {"status": 0, "ctype": ""}

        async def wrap(msg):
            if msg["type"] == "http.response.start":
                meta["status"] = msg.get("status", 0)
                for k, v in msg.get("headers", []):
                    if k.lower() == b"content-type":
                        meta["ctype"] = v.decode("latin-1")
            await send(msg)
        try:
            await self.app(scope, receive, wrap)
        finally:
            try:
                uid = (scope.get("session") or {}).get("uid")
                log(scope, meta["status"], meta["ctype"], uid)
            except Exception:
                pass


# ---- reports ----

def since(days):
    return (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)).replace(microsecond=0).isoformat()


AREAS = [("/rail/r1", "Freight: R-1 portal"), ("/rail/safety", "Freight: safety"), ("/rail/crossing", "Freight: crossings"),
         ("/rail/locomotives", "Freight: locomotives"), ("/rail/railcars", "Freight: freight cars"), ("/rail/tank", "Freight: tank cars"),
         ("/rail/service", "Freight: service metrics"), ("/rail/shortline", "Freight: short lines"), ("/rail/costs", "Freight: costs and fuel"),
         ("/rail/suppliers", "Suppliers"), ("/rail/supplier-intel", "Supplier Intelligence"), ("/rail/funding", "Funding"),
         ("/rail/wayside", "Freight: wayside"), ("/rail", "Freight portal (other)"),
         ("/app/bids", "Bids"), ("/app/work", "Upcoming work"), ("/app/awards", "Awards"), ("/app/fleets", "Fleets"), ("/app/fleet", "Fleets"),
         ("/app/operators", "Operators"), ("/app/analyst", "AI analyst"), ("/app/alerts", "Alerts"), ("/app/escalation", "Cost escalation"),
         ("/app/cost-indexes", "Cost and fuel indexes"), ("/app/safety", "Safety"), ("/app/suppliers", "Suppliers"),
         ("/app/supplier-intel", "Supplier Intelligence"), ("/app/market", "Market"), ("/app/funding", "Funding"), ("/app/account", "Account"),
         ("/app", "Passenger app (other)"),
         ("/pricing", "Pricing"), ("/signup", "Sign-up"), ("/login", "Sign-in"), ("/compare", "Comparison pages"), ("/data", "Data pages"),
         ("/solutions", "Solutions pages"), ("/blog", "Blog"), ("/p/", "Info pages"), ("/ambassador", "Ambassador invites"),
         ("/operator", "Operator pages"), ("/", "Home and public pages")]


EXACT = {"/": "Home page", "/app": "Passenger: My dashboard", "/rail": "Freight: overview"}


def area(path):
    if path in EXACT:
        return EXACT[path]
    for pre, lab in AREAS:
        if pre == "/" or path == pre.rstrip("/") or path.startswith(pre.rstrip("/") + "/"):
            return lab
    return "Other"


def _q(sql, args=()):
    return [dict(r) for r in db.q(sql, args)]


def live():
    rows = _q("SELECT e.sid, e.user_id, e.path, e.ts, e.device, e.source, u.name, u.email, u.plan_id FROM usage_event e "
              "LEFT JOIN user u ON u.id = e.user_id WHERE e.ts >= ? AND e.kind = 'view' ORDER BY e.ts DESC", (since(LIVE_MINUTES / 1440),))
    member_sids = {r["sid"] for r in rows if r["user_id"]}
    seen, out = set(), []
    for r in rows:
        if not r["user_id"] and r["sid"] in member_sids:  # the same browser before it signed in
            continue
        key = r["user_id"] or r["sid"]
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def summary(days):
    s = since(days)
    one = lambda sql: (db.q(sql, (s,), one=True) or [0])[0] or 0  # noqa: E731
    return {
        "visitors": one("SELECT count(DISTINCT sid) FROM usage_event WHERE ts >= ?"),
        "members": one("SELECT count(DISTINCT user_id) FROM usage_event WHERE ts >= ? AND user_id IS NOT NULL"),
        "views": one("SELECT count(*) FROM usage_event WHERE ts >= ? AND kind = 'view'"),
        "ai": one("SELECT count(*) FROM usage_event WHERE ts >= ? AND kind = 'ai'"),
        "exports": one("SELECT count(*) FROM usage_event WHERE ts >= ? AND kind = 'export'"),
        "signups": one("SELECT count(*) FROM user WHERE created >= ? AND role != 'admin' AND email NOT LIKE '%@example.com'"),
    }


def daily(days):
    rows = _q("SELECT substr(ts, 1, 10) d, count(DISTINCT sid) v, count(DISTINCT user_id) m, sum(kind = 'view') pv FROM usage_event "
              "WHERE ts >= ? GROUP BY d ORDER BY d", (since(days),))
    by = {r["d"]: r for r in rows}
    today = datetime.datetime.now(datetime.timezone.utc).date()
    out = []
    for i in range(days - 1, -1, -1):
        d = (today - datetime.timedelta(days=i)).isoformat()
        r = by.get(d, {})
        out.append({"d": d, "visitors": r.get("v", 0) or 0, "members": r.get("m", 0) or 0, "views": r.get("pv", 0) or 0})
    return out


def top_pages(days, n=25, members_only=False):
    return _q("SELECT path, count(*) views, count(DISTINCT sid) visitors, count(DISTINCT user_id) members FROM usage_event "
              f"WHERE ts >= ? AND kind = 'view'{' AND user_id IS NOT NULL' if members_only else ''} GROUP BY path ORDER BY views DESC LIMIT ?",
              (since(days), n))


def top_areas(days):
    agg = {}
    for r in _q("SELECT path, count(*) n, count(DISTINCT user_id) m FROM usage_event WHERE ts >= ? AND kind = 'view' GROUP BY path",
                (since(days),)):
        a = agg.setdefault(area(r["path"]), [0, 0])
        a[0] += r["n"]
        a[1] += r["m"]
    return sorted(([k, v[0], v[1]] for k, v in agg.items()), key=lambda x: -x[1])


def sources(days):
    return _q("SELECT coalesce(nullif(source, ''), 'direct or internal') source, count(DISTINCT sid) visitors, count(*) views "
              "FROM usage_event WHERE ts >= ? AND kind = 'view' GROUP BY 1 ORDER BY visitors DESC LIMIT 15", (since(days),))


CHANNELS = [("linkedin", "LinkedIn"), ("social", "X and Bluesky"), ("email", "Member email"), ("embed", "Embedded charts"), ("press", "Trade press pitch"),
            ("amb-", "Ambassadors")]
SEARCH = ("google", "bing", "duckduckgo", "yahoo", "ecosia", "brave", "yandex", "baidu")


def channel(src):
    """Group a source (a ?ref= tag or referring host) into a marketing channel for the Sources tab."""
    s = (src or "").lower()
    for k, lab in CHANNELS:
        if s == k or (k.endswith("-") and s.startswith(k)) or (k == "linkedin" and "linkedin" in s) or (k == "social" and s.startswith("bluesky")):
            return lab
    if any(e in s for e in SEARCH):
        return "Search engines"
    return "Direct or internal" if not s else "Other sites"


def channels(days):
    """Visitors, sign-ups and paid members per channel and per source (awareness plan Phase 1). A visit counts toward its
    source for the day (visitor ids are daily); a sign-up counts when the same visitor signed up that day; paid counts members
    who signed up or signed in during such a visit and are on a paid plan now."""
    rows = _q("WITH s AS (SELECT DISTINCT sid, substr(ts, 1, 10) d, source FROM usage_event WHERE ts >= ? AND kind = 'view') "
              "SELECT s.source, count(DISTINCT s.sid || s.d) visitors, "
              "count(DISTINCT CASE WHEN e.kind = 'signup' THEN e.sid END) signups, "
              "count(DISTINCT CASE WHEN coalesce(u.plan_id, 'free') != 'free' AND coalesce(u.sub_status, '') IN ('active', 'trialing', 'ambassador', 'manual') "
              "THEN u.id END) paid "
              "FROM s LEFT JOIN usage_event e ON e.sid = s.sid AND substr(e.ts, 1, 10) = s.d LEFT JOIN user u ON u.id = e.user_id "
              "GROUP BY s.source ORDER BY visitors DESC", (since(days),))
    agg = {}
    for r in rows:
        r["source"] = r["source"] or ""
        c = agg.setdefault(channel(r["source"]), {"channel": channel(r["source"]), "visitors": 0, "signups": 0, "paid": 0, "sources": []})
        for k in ("visitors", "signups", "paid"):
            c[k] += r[k] or 0
        c["sources"].append(r)
    return sorted(agg.values(), key=lambda c: -c["visitors"])


def members(days):
    s = since(days)
    rows = _q("SELECT e.user_id, u.name, u.email, u.plan_id, u.sub_status, u.company, max(e.ts) last, count(DISTINCT substr(e.ts, 1, 10)) days, "
              "sum(e.kind = 'view') views, sum(e.kind = 'ai') ai, sum(e.kind = 'export') exports, sum(e.kind IN ('alert', 'watch', 'action')) actions "
              "FROM usage_event e JOIN user u ON u.id = e.user_id WHERE e.ts >= ? AND u.email NOT LIKE '%@example.com' "
              "GROUP BY e.user_id ORDER BY last DESC", (s,))
    for r in rows:
        paths = _q("SELECT path, count(*) n FROM usage_event WHERE user_id = ? AND ts >= ? AND kind = 'view' GROUP BY path", (r["user_id"], s))
        agg = {}
        for p in paths:
            agg[area(p["path"])] = agg.get(area(p["path"]), 0) + p["n"]
        r["top"] = ", ".join(k for k, _ in sorted(agg.items(), key=lambda x: -x[1])[:3])
    return rows


def timeline(uid, limit=400):
    rows = _q("SELECT ts, kind, path, detail, source, device FROM usage_event WHERE user_id = ? ORDER BY ts DESC LIMIT ?", (uid, limit))
    days = []
    for r in rows:
        r["area"] = area(r["path"])
        d = r["ts"][:10]
        if not days or days[-1]["d"] != d:
            days.append({"d": d, "events": []})
        days[-1]["events"].append(r)
    return days


def user_stats(uid):
    r = db.q("SELECT min(ts) first, max(ts) last, count(DISTINCT substr(ts, 1, 10)) days, sum(kind = 'view') views, sum(kind = 'ai') ai, "
             "sum(kind = 'export') exports FROM usage_event WHERE user_id = ?", (uid,), one=True)
    return dict(r) if r else {}
