# Consist: rail fleet and procurement intelligence (subscription site)

A FastAPI web app that sells subscriptions to the fleet database (Fleet Explorer) and Bid Catcher. It runs as its own Docker
container on the IONOS VPS and **only reads** `fleet.db` and `bids.db` from `/opt/fleet-db-docker/data`. It does not change
the fleet-db, fleet-agent or bid-monitor containers.

"Consist" is a working name. Change it in Admin > Settings (site name, tagline, home page text); check trademark and domain
availability before launch.

## What's in it

| Area | Pages |
|---|---|
| Public | `/` landing, `/pricing`, `/coverage`, `/compare` hub, `/compare/{bidprime,govspend,bidnet-direct,sci-verkehr}`, `/blog`, `/p/<slug>` CMS pages, `/contact`, `/sitemap.xml`, `/robots.txt` |
| Accounts | `/signup`, `/login`, `/forgot` + `/reset/<token>`, team invites `/invite/<token>` |
| Member app `/app` | dashboard, bid feed + detail (AI bid fit brief), alerts (saved searches emailed instantly/daily/weekly), saved bids, award analytics, fleet explorer + fleet detail (duty cycle, cost, overhaul timing, subsystems, power), operators + cost trends, overhaul pipeline, vehicle orders, AI analyst, account/billing/team |
| Admin `/admin` (sign in at `/admin/login`) | MRR and usage overview; users and teams (plan, status, role, comp accounts, reset links, delete); plans and pricing (prices, limits, features, one-click Stripe price creation); pages and guides plus the announcement banner; comparison page editor (edit, add, hide, restore); settings (site name, home page text, Stripe keys, SMTP, AI model and key, trials, sign-ups); data and AI usage; bid sources; leads; activity log; your own admin account and password |

Plans (editable in Admin > Plans): Starter free, Pro $129/mo ($1,290/yr), Team $399/mo ($3,990/yr, 5 seats), Enterprise by contact.

## The AI analyst

`app/analyst.py`. Claude (`claude-opus-5-5`, server-side fallbacks on) answers questions by running read-only SQL against
fleet.db and bids.db through a `run_sql` tool (SELECT only, SQLite authorizer, 8-second timeout, 80-row cap; award tables blocked
for plans without award analytics), then returns a structured answer (headline, key figures, table, caveats, fit verdict for bid
briefs). Each question costs one from the plan's monthly quota; the per-question API spend cap is `ANALYST_MAX_USD`.

## Run locally

```bash
pip install -r requirements.txt
python seed/make_sample_bids.py /tmp/bids.db path/to/fleet.db     # SAMPLE bid data, for development only
DATA_DIR=./data FLEET_DB=path/to/fleet.db BIDS_DB=/tmp/bids.db ADMIN_EMAIL=you@x.com ADMIN_PASSWORD=change-me-now \
  uvicorn app.main:app --port 8080
python tests/smoke.py http://localhost:8080 you@x.com change-me-now   # end-to-end test (about 70 checks)
python tests/stub_analyst.py                                          # analyst plumbing without an API key
```

## Deploy on the VPS

1. Copy this folder to `/opt/consist-site` on the VPS.
2. `cp .env.example .env && chmod 600 .env`, then fill in `SECRET_KEY`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` (and Stripe, SMTP and
   Anthropic keys when you have them). For the AI key you can point at the existing file:
   `ANTHROPIC_API_KEY_FILE=/fleetdata/agent/anthropic_api_key.txt`.
3. `docker compose up -d --build` starts the site on `127.0.0.1:8080` only.
4. Preview from the Mac: `ssh -L 8080:127.0.0.1:8080 root@74.208.37.200`, then open http://localhost:8080.

### Going public (domain + HTTPS)

1. Point the domain's DNS A record (and `www`) at 74.208.37.200 in the IONOS DNS panel.
2. Open ports 80 and 443 in the IONOS firewall policy for the VPS.
3. In `.env` set `SITE_DOMAIN=yourdomain.com` and `SITE_URL=https://yourdomain.com`.
4. `docker compose --profile public up -d` adds Caddy, which gets and renews the HTTPS certificate automatically.

### Admin access

Sign in at `/admin/login` (there is also an "Admin" link in the site footer). Change your password under the account menu > My admin account.
Locked out? On the server: `docker exec -it consist-site python -m app.cli set-password you@example.com` (prompts for a new password);
`make-admin` promotes or creates an admin and `list-admins` lists them.

### Stripe

Everything below can be done in the browser: Admin > Settings > Billing and Stripe takes the secret key and webhook secret (stored on
the server in `data/integrations.json`, chmod 600, never shown again in full) and has a "Test Stripe key" button. Keys in `.env` also work;
values saved in the admin take precedence. Email (SMTP) and the AI key work the same way.

1. Stripe Dashboard > Developers > API keys: put the secret key in Admin > Settings or `STRIPE_SECRET_KEY` (start with test mode `sk_test_...`).
2. Developers > Webhooks: add `https://yourdomain.com/stripe/webhook` with events `checkout.session.completed`,
   `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`,
   `invoice.payment_failed`. Put the signing secret in Admin > Settings or `STRIPE_WEBHOOK_SECRET`.
3. Settings > Billing > Customer portal: turn it on (lets members change cards, switch plans and cancel).
4. Admin > Plans and pricing > **Create missing Stripe prices**. Or paste existing price IDs.
5. Test with card 4242 4242 4242 4242, then switch to live keys.

Without Stripe keys the site runs in **demo billing** (upgrades apply without payment, marked "demo"); turn that off in
Admin > Settings > Billing and Stripe before launch.

## Before launch

- Have counsel review `/p/terms` and `/p/privacy` (templates) and the data licences (NTD is public domain; researched and
  news-derived records need review).
- Re-check competitor facts on the comparison pages (Admin > Comparison pages; defaults in `app/compare.py`, checked October 2026).
- Set `support_email`, turn off demo billing, and make sure `BIDS_DB` points at the live bid-monitor database (the admin overview
  warns if it sees sample rows).
