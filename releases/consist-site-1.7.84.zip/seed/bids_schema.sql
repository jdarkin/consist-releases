-- bids.db: rail procurement bid monitor (bid-monitor container). Separate from fleet.db, which the NTD refresh swaps.
CREATE TABLE IF NOT EXISTS agency (
  agency_id TEXT PRIMARY KEY,
  agency TEXT,
  country TEXT,                 -- US | CA
  state_prov TEXT,
  rail_modes TEXT,              -- NTD-style codes separated by ';' (CR, HR, LR, SC, ICR, AG...)
  fleet_operator_ids TEXT,      -- fleet.db operator_id values separated by ';'
  platform TEXT,
  portal_url TEXT,
  listing_public TEXT,          -- yes | partial | login | no
  alert_channel TEXT,
  account_key TEXT,             -- registration account(s) that cover this agency, separated by ';'
  verified TEXT,
  notes TEXT,
  watch INTEGER DEFAULT 1       -- 0 turns off page watching for this agency
);

CREATE TABLE IF NOT EXISTS notice (
  notice_id INTEGER PRIMARY KEY,
  source TEXT NOT NULL,         -- canadabuys | seao | mail | page | research | manual
  source_key TEXT NOT NULL UNIQUE,
  agency_id TEXT,
  buyer TEXT,                   -- buyer name as published
  country TEXT,
  ref_no TEXT,
  title TEXT,
  description TEXT,
  notice_type TEXT,             -- tender | planned | addendum | award | cancelled | other
  published TEXT,               -- ISO date
  closing TEXT,                 -- ISO date/time
  url TEXT,
  value_est REAL,
  currency TEXT,
  kw_score INTEGER,             -- keyword score (0-100)
  relevance INTEGER,            -- final score (0-100), after Claude review when one ran
  category TEXT,                -- see relevance.CATEGORIES
  subsystems TEXT,              -- fleet subsystem codes separated by ';'
  rail INTEGER,                 -- 1 rail vehicles, 0 bus/other, null unknown
  operator_id TEXT,             -- fleet.db operator_id, when known
  summary TEXT,                 -- one line from the review
  reviewed TEXT,                -- 'keywords' | 'claude' | 'manual'
  first_seen TEXT,
  last_seen TEXT,
  notified TEXT,                -- time the first alert went out
  raw_json TEXT
);
CREATE INDEX IF NOT EXISTS notice_agency ON notice(agency_id);
CREATE INDEX IF NOT EXISTS notice_rel ON notice(relevance);

CREATE TABLE IF NOT EXISTS award (
  award_id INTEGER PRIMARY KEY,
  source_key TEXT UNIQUE,
  notice_id INTEGER,            -- the tender it closes, when matched
  agency_id TEXT,
  buyer TEXT,
  country TEXT,
  ref_no TEXT,
  title TEXT,
  vendor TEXT,                  -- as published
  vendor_norm TEXT,             -- normalized for grouping
  supplier_id TEXT,             -- fleet.db supplier register id, when matched
  amount REAL,
  currency TEXT,
  amount_usd REAL,
  award_date TEXT,
  term_months INTEGER,
  n_bidders INTEGER,
  low_bid REAL,
  high_bid REAL,
  category TEXT,
  subsystems TEXT,
  operator_id TEXT,
  procurement_rowid INTEGER,    -- fleet.db seed_procurement rowid, when it is a vehicle order
  relevance INTEGER,            -- relevance to rail vehicle maintenance (0-100), from the review; analytics use >= 50
  source TEXT,                  -- seao | canadabuys | mail | page | research | manual
  source_url TEXT,
  confidence TEXT,              -- A agency doc, B trade press, C secondary, D inferred, E unconfirmed
  notes TEXT,
  first_seen TEXT
);
CREATE INDEX IF NOT EXISTS award_vendor ON award(vendor_norm);

CREATE TABLE IF NOT EXISTS bid_tab (     -- bidders and prices from bid tabulations
  id INTEGER PRIMARY KEY,
  award_id INTEGER,
  notice_id INTEGER,
  bidder TEXT,
  bidder_norm TEXT,
  amount REAL,
  rank INTEGER,
  winner INTEGER,
  source_url TEXT
);

CREATE TABLE IF NOT EXISTS page_watch (
  url TEXT PRIMARY KEY,
  agency_id TEXT,
  kind TEXT,                    -- solicitations | awards
  last_hash TEXT,
  last_text TEXT,
  last_checked TEXT,
  last_changed TEXT,
  last_error TEXT
);

CREATE TABLE IF NOT EXISTS mail_msg (
  id INTEGER PRIMARY KEY,
  uid TEXT UNIQUE,              -- IMAP UIDVALIDITY:UID
  message_id TEXT,
  received TEXT,
  sender TEXT,
  subject TEXT,
  platform TEXT,
  kind TEXT,                    -- alert | verification | award | other
  notices INTEGER,              -- notices extracted
  action TEXT,                  -- what the agent did (e.g. clicked verification link)
  error TEXT
);

CREATE TABLE IF NOT EXISTS registration (
  account_key TEXT PRIMARY KEY,
  platform TEXT,
  signup_url TEXT,
  agencies TEXT,                -- agency_ids it covers
  status TEXT DEFAULT 'todo',   -- todo | submitted | verify_pending | verified | active | skipped
  cost TEXT,
  updated TEXT,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS notify_log (
  id INTEGER PRIMARY KEY,
  ts TEXT,
  subscriber TEXT,
  kind TEXT,                    -- immediate | digest | system | test
  notice_ids TEXT,
  ok INTEGER,
  error TEXT
);

CREATE TABLE IF NOT EXISTS run_log (
  id INTEGER PRIMARY KEY,
  started TEXT,
  finished TEXT,
  task TEXT,
  status TEXT,
  found INTEGER,
  new INTEGER,
  cost_usd REAL,
  message TEXT
);

-- analytics
CREATE VIEW IF NOT EXISTS v_open_bids AS
  SELECT n.notice_id, n.relevance, n.category, n.subsystems, coalesce(a.agency, n.buyer) AS agency, n.country,
         n.ref_no, n.title, n.closing, n.url, n.summary, n.source, n.first_seen
  FROM notice n LEFT JOIN agency a USING (agency_id)
  WHERE n.notice_type IN ('tender', 'planned', 'addendum') AND n.relevance >= 50
    AND (n.closing IS NULL OR n.closing >= date('now'))
  ORDER BY n.closing IS NULL, n.closing;

CREATE VIEW IF NOT EXISTS v_award_by_vendor AS
  SELECT vendor_norm AS vendor, count(*) AS awards, count(DISTINCT agency_id) AS agencies,
         round(sum(amount_usd)) AS total_usd, round(avg(amount_usd)) AS avg_usd, max(award_date) AS latest,
         group_concat(DISTINCT category) AS categories
  FROM award WHERE vendor_norm IS NOT NULL AND relevance >= 50 GROUP BY vendor_norm ORDER BY total_usd DESC;

CREATE VIEW IF NOT EXISTS v_award_share_by_category AS
  SELECT category, vendor_norm AS vendor, count(*) AS awards, round(sum(amount_usd)) AS total_usd,
         round(100.0 * sum(amount_usd) / (SELECT sum(amount_usd) FROM award b WHERE b.category IS a.category AND b.relevance >= 50), 1) AS pct_of_category
  FROM award a WHERE vendor_norm IS NOT NULL AND relevance >= 50 GROUP BY category, vendor_norm ORDER BY category, total_usd DESC;

CREATE VIEW IF NOT EXISTS v_award_by_agency AS
  SELECT coalesce(g.agency, a.buyer) AS agency, a.vendor_norm AS vendor, count(*) AS awards,
         round(sum(a.amount_usd)) AS total_usd, min(a.award_date) AS first, max(a.award_date) AS latest
  FROM award a LEFT JOIN agency g USING (agency_id) WHERE a.relevance >= 50 GROUP BY 1, 2 ORDER BY 1, total_usd DESC;

CREATE VIEW IF NOT EXISTS v_award_price_trend AS
  SELECT category, substr(award_date, 1, 4) AS year, count(*) AS awards, round(avg(amount_usd)) AS avg_usd,
         round(min(amount_usd)) AS min_usd, round(max(amount_usd)) AS max_usd
  FROM award WHERE amount_usd IS NOT NULL AND award_date IS NOT NULL AND relevance >= 50 GROUP BY 1, 2 ORDER BY 1, 2;

CREATE VIEW IF NOT EXISTS v_competition AS
  SELECT a.award_id, coalesce(g.agency, a.buyer) AS agency, a.title, a.vendor_norm AS winner, a.amount_usd,
         coalesce(a.n_bidders, nullif((SELECT count(*) FROM bid_tab t WHERE t.award_id = a.award_id), 0)) AS bidders,
         CASE WHEN a.low_bid > 0 AND a.high_bid > 0 THEN round(100.0 * (a.high_bid - a.low_bid) / a.low_bid, 1) END AS spread_pct
  FROM award a LEFT JOIN agency g USING (agency_id) WHERE a.relevance >= 50 ORDER BY a.award_date DESC;
