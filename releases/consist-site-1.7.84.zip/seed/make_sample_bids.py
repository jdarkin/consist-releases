"""Builds a SAMPLE bids.db for local development and demos (every row has source='sample').
Production reads the real bids.db written by the bid-monitor container; never copy this file there.

usage: python seed/make_sample_bids.py OUT.db [fleet.db]
"""
import csv
import datetime
import json
import os
import random
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
rnd = random.Random(20261023)

TEMPLATES = [
    ("overhaul_program", "trucks;brakes;hvac;doors", 92, "Midlife Overhaul of {model} {cls} Fleet",
     "Contractor to perform a midlife overhaul of {qty} {model} cars including trucks, HVAC, door operators, brake equipment and interior refresh."),
    ("overhaul_program", "prime_mover;hep", 90, "Locomotive Prime Mover Overhaul Program",
     "Overhaul of diesel prime movers and head-end power units on {qty} passenger locomotives, with options for traction motor rewind."),
    ("component_repair", "trucks", 88, "Truck and Wheelset Overhaul Services",
     "Disassembly, inspection, repair and reassembly of trucks and wheelsets for {model} vehicles. Exchange pool of {qty} truck assemblies."),
    ("component_repair", "propulsion_traction", 87, "Traction Motor Repair and Rewind",
     "Repair, rewind and testing of AC traction motors for the {model} fleet. Estimated {qty} motors over a three year term."),
    ("component_repair", "hvac", 84, "HVAC Unit Rebuild for Rail Vehicles",
     "Rebuild of roof-mounted HVAC units and compressors for {model} cars, including refrigerant conversion where required."),
    ("component_repair", "doors", 83, "Door Operator Overhaul and Spare Parts",
     "Overhaul of electric door operators and controllers for {qty} {model} vehicles, plus supply of critical spares."),
    ("component_repair", "brakes", 85, "Air Brake Equipment Repair",
     "Repair and testing of brake valves, compressors and brake control units for rail vehicles."),
    ("parts_supply", "coupler", 76, "Supply of Coupler and Draft Gear Components",
     "Indefinite quantity contract for coupler heads, draft gear and related spare parts for the {model} fleet."),
    ("parts_supply", "", 72, "Rail Vehicle Spare Parts, Brake Shoes and Filters",
     "Two year supply contract for brake shoes, HVAC filters, wiper blades and consumables for passenger rail vehicles."),
    ("parts_supply", "trucks", 78, "Supply of Wheels and Axles",
     "Supply of forged wheels and axles to agency drawing for {model} trucks; quantities per year estimated at {qty}."),
    ("onboard_systems", "pis_passenger_info", 82, "Passenger Information System Upgrade",
     "Design, supply and installation of LCD passenger information displays and automatic announcements on {qty} {model} cars."),
    ("onboard_systems", "cctv", 80, "Onboard CCTV Retrofit",
     "Supply and retrofit of digital onboard video surveillance with forward-facing and interior cameras on {qty} vehicles."),
    ("onboard_systems", "vehicle_control", 81, "Event Recorder and TCMS Software Upgrade",
     "Upgrade of train control and monitoring system software and replacement of event recorders on the {model} fleet."),
    ("onboard_systems", "signal_onboard", 79, "PTC Onboard Equipment Maintenance",
     "Maintenance and life-cycle support of positive train control onboard equipment on locomotives and cab cars."),
    ("shop_equipment", "", 74, "Underfloor Wheel Truing Machine Replacement",
     "Furnish and install a tandem underfloor wheel truing machine at the main rail maintenance facility."),
    ("shop_equipment", "", 70, "Portable Lifting Jacks for Rail Car Maintenance",
     "Supply of synchronized portable lifting jack sets rated for passenger rail cars, with training and spares."),
    ("maintenance_services", "", 86, "Rail Fleet Maintenance Services Contract",
     "Contract operations and maintenance of the {model} fleet including running maintenance, inspections and heavy repair."),
    ("cleaning_interior", "passenger_experience", 66, "Rail Car Interior Cleaning and Seat Reupholstery",
     "Interior cleaning, graffiti removal and seat reupholstery for passenger rail cars at two yards."),
    ("vehicle_procurement", "", 95, "Procurement of New {cls_pl}",
     "Design, manufacture and delivery of up to {qty} new {cls_pl} with options, including spares, training and warranty."),
    ("engineering_support", "", 68, "Rolling Stock Engineering and Inspection Services",
     "On-call engineering, vendor inspection and reliability support for rolling stock procurements and overhauls."),
]
VENDORS = {
    "overhaul_program": ["Alstom", "Siemens Mobility", "Wabtec", "Talgo", "Kawasaki Rail Car", "Hyundai Rotem", "Stadler US", "Progress Rail"],
    "component_repair": ["Wabtec", "Knorr-Bremse", "Amsted Rail", "Voith", "Merak", "Sepsa", "Bombardier Services", "Kinkisharyo Services"],
    "parts_supply": ["Wabtec", "Knorr-Bremse", "Amsted Rail", "Standard Steel", "Lucchini", "Dellner", "Voith", "GMI"],
    "onboard_systems": ["Luminator", "Wabtec", "Siemens Mobility", "Hitachi Rail", "r2p", "Alstom", "Thales"],
    "shop_equipment": ["Hegenscheidt-MFD", "Stertil-Koni", "Whiting", "Mechan", "Portec Rail"],
    "maintenance_services": ["Alstom", "Bombardier Services", "Keolis", "Transdev", "Herzog", "Siemens Mobility"],
    "cleaning_interior": ["ABM", "Herzog", "Scotty's Contracting", "Coach & Car Equipment"],
    "vehicle_procurement": ["Siemens Mobility", "Alstom", "Stadler US", "Hyundai Rotem", "Kawasaki Rail Car", "CAF USA", "Hitachi Rail"],
    "engineering_support": ["LTK Engineering (Hatch)", "STV", "WSP", "HNTB", "Jacobs"],
}
CLS = {"coach": ("coach", "Coaches"), "cab_car": ("cab car", "Cab Cars"), "locomotive": ("locomotive", "Locomotives"),
       "emu": ("EMU", "Electric Multiple Units"), "dmu": ("DMU", "Diesel Multiple Units"), "metro_car": ("subway car", "Rail Transit Vehicles"),
       "lrv": ("LRV", "Light Rail Vehicles"), "streetcar": ("streetcar", "Streetcars")}


def main(out, fleet_db=None):
    if os.path.exists(out):
        os.remove(out)
    c = sqlite3.connect(out)
    c.executescript(open(os.path.join(HERE, "bids_schema.sql")).read())
    fleets = {}
    ops = set()
    if fleet_db and os.path.exists(fleet_db):
        f = sqlite3.connect(f"file:{fleet_db}?mode=ro", uri=True)
        ops = {r[0] for r in f.execute("SELECT operator_id FROM operator")}
        for oid, model, cls, qty in f.execute("SELECT operator_id, model_name, vehicle_class, qty_active FROM v_fleet_profile WHERE qty_active > 4"):
            fleets.setdefault(oid, []).append((model, cls, qty))
    agencies = list(csv.DictReader(open(os.path.join(HERE, "portals.csv"))))
    for a in agencies:
        if not a["fleet_operator_ids"] and a["agency_id"] in ops:
            a["fleet_operator_ids"] = a["agency_id"]
        c.execute("INSERT INTO agency (agency_id, agency, country, state_prov, rail_modes, fleet_operator_ids, platform, portal_url, "
                  "listing_public, alert_channel, account_key, verified, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  [a[k] for k in ("agency_id", "agency", "country", "state_prov", "rail_modes", "fleet_operator_ids", "platform", "portal_url",
                                  "listing_public", "alert_channel", "account_key", "verified", "notes")])
    rich = [a for a in agencies if any(o in fleets for o in a["fleet_operator_ids"].split(";") if o)]
    today = datetime.date.today()
    nid = 0
    for i in range(240):
        a = rnd.choice(rich) if rnd.random() < 0.85 else rnd.choice(agencies)
        op = next((o for o in a["fleet_operator_ids"].split(";") if o in fleets), "")
        model, cls, qty = rnd.choice(fleets[op]) if op else ("rail", "coach", 20)
        cat, subs, rel, title, desc = rnd.choice(TEMPLATES)
        cls_s, cls_pl = CLS.get(cls, ("rail car", "Rail Cars"))
        kw = dict(model=model, cls=cls_s, cls_pl=cls_pl, qty=max(4, int(qty or 10) // rnd.choice([1, 1, 2, 3])))
        pub = today - datetime.timedelta(days=int(rnd.triangular(0, 400, 10)))
        closing = pub + datetime.timedelta(days=rnd.choice([21, 28, 30, 35, 45, 60]))
        ntype = "planned" if rnd.random() < 0.08 else ("addendum" if rnd.random() < 0.08 else "tender")
        value = rnd.choice([None, None, round(rnd.uniform(0.2, 40), 1) * 1e6])
        if cat == "vehicle_procurement":
            value = value and value * 8
        nid += 1
        ref = f"{a['agency_id'][:4]}-{pub.year % 100}-{rnd.randint(100, 999)}"
        r = max(40, min(99, rel + rnd.randint(-12, 8)))
        c.execute("INSERT INTO notice (source, source_key, agency_id, buyer, country, ref_no, title, description, notice_type, published, closing, "
                  "url, value_est, currency, kw_score, relevance, category, subsystems, rail, operator_id, summary, reviewed, first_seen, last_seen) "
                  "VALUES ('sample',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,'claude',?,?)",
                  (f"sample:{nid}", a["agency_id"], a["agency"], a["country"], ref, title.format(**kw), desc.format(**kw), ntype,
                   pub.isoformat(), closing.isoformat(), a["portal_url"], value, "CAD" if a["country"] == "CA" else "USD", r - 5, r, cat, subs,
                   op or None, f"{a['agency'].split(' (')[0]}: {title.format(**kw).lower()}" + (f" for the {model} fleet." if op else "."),
                   pub.isoformat(), today.isoformat()))
    for i in range(160):
        a = rnd.choice(rich)
        op = next((o for o in a["fleet_operator_ids"].split(";") if o in fleets), "")
        model, cls, qty = rnd.choice(fleets[op])
        cat, subs, rel, title, desc = rnd.choice(TEMPLATES)
        cls_s, cls_pl = CLS.get(cls, ("rail car", "Rail Cars"))
        kw = dict(model=model, cls=cls_s, cls_pl=cls_pl, qty=max(4, int(qty or 10) // 2))
        vendor = rnd.choice(VENDORS[cat])
        scale = {"vehicle_procurement": 25, "overhaul_program": 4, "cleaning_interior": 0.3, "engineering_support": 0.5,
                 "shop_equipment": 0.6, "parts_supply": 0.5}.get(cat, 1)
        amt = round(min(rnd.lognormvariate(14.2, 0.9), 2.5e7) * scale, -3)
        n_b = rnd.randint(1, 6)
        d = today - datetime.timedelta(days=rnd.randint(5, 6 * 365))
        c.execute("INSERT INTO award (source_key, agency_id, buyer, country, ref_no, title, vendor, vendor_norm, amount, currency, amount_usd, "
                  "award_date, term_months, n_bidders, low_bid, high_bid, category, subsystems, operator_id, relevance, source, source_url, "
                  "confidence, first_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'sample',?, 'E', ?)",
                  (f"sample-award:{i}", a["agency_id"], a["agency"], a["country"], f"{a['agency_id'][:4]}-{d.year % 100}-{rnd.randint(100, 999)}",
                   title.format(**kw), vendor, vendor, amt, "USD", amt, d.isoformat(), rnd.choice([12, 24, 36, 60]), n_b, amt,
                   round(amt * rnd.uniform(1.05, 1.6), -3) if n_b > 1 else None, cat, subs, op, rel, a["portal_url"], today.isoformat()))
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (today.isoformat(), today.isoformat(), "sample", "done", 240, 240, 0, "sample data for development"))
    c.commit()
    c.close()
    print(f"wrote {out}: 240 sample notices, 160 sample awards")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
