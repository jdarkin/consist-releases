"""Exercises the AI analyst plumbing without an API key: a scripted stand-in for the Anthropic client makes one run_sql call,
then give_answer. Checks SQL guarding, the job lifecycle and the rendered answer card, through the real web app (in-process)."""
import json
import os
import sys
import time
import types

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("ALERTS_ENABLED", "0")
os.environ["ANTHROPIC_API_KEY"] = "test-key"

from fastapi.testclient import TestClient  # noqa: E402

from app import analyst, config  # noqa: E402

config.ANTHROPIC_API_KEY = "test-key"


def block(**kw):
    return types.SimpleNamespace(**kw)


usage = types.SimpleNamespace(input_tokens=3000, output_tokens=400, cache_read_input_tokens=0, cache_creation_input_tokens=0)
SCRIPT = [
    types.SimpleNamespace(stop_reason="tool_use", usage=usage, content=[
        block(type="tool_use", id="t1", name="run_sql", input={"database": "fleet", "sql":
              "SELECT operator_id, model_name, qty_active, midlife_due_year FROM v_fleet_profile WHERE vehicle_class='coach' "
              "AND midlife_due_year BETWEEN 2026 AND 2030 ORDER BY qty_active DESC LIMIT 5"}),
        block(type="tool_use", id="t2", name="run_sql", input={"database": "bids", "sql": "DELETE FROM notice"})]),
    types.SimpleNamespace(stop_reason="tool_use", usage=usage, content=[
        block(type="tool_use", id="t3", name="give_answer", input={
            "headline": "Five big coach fleets reach midlife by 2030.", "answer_markdown": "- **LIRR** leads\n- Then MNR",
            "key_figures": [{"label": "Cars due", "value": "1,240", "note": "2026-2030"}],
            "table": {"title": "Fleets", "columns": ["Operator", "Cars"], "rows": [["LIRR", "300"]]},
            "verdict": "none", "confidence": "medium", "caveats": ["Projections, not agency plans."]})]),
]
seen = []


class FakeMessages:
    def create(self, **kw):
        seen.append(kw)
        if len(seen) == 2:  # the tool results we sent back
            res = kw["messages"][-1]["content"]
            assert res[0]["is_error"] is False and "rows" in res[0]["content"], res[0]
            assert res[1]["is_error"] is True, res[1]
            print("run_sql rows ok; DELETE blocked:", res[1]["content"][:60])
        return SCRIPT[len(seen) - 1]


class FakeClient:
    def __init__(self, **kw):
        self.beta = types.SimpleNamespace(messages=FakeMessages())


analyst.anthropic.Anthropic = FakeClient

from app.main import app  # noqa: E402

with TestClient(app) as c:
    page = c.get("/login").text
    import re
    tok = re.search(r'name="csrf" value="([^"]+)"', page).group(1)
    r = c.post("/signup", data={"csrf": tok, "email": f"ai{int(time.time())}@example.com", "password": "correct-horse-1"}, follow_redirects=False)
    assert r.status_code == 303
    tok = re.search(r'name="csrf" value="([^"]+)"', c.get("/app/analyst").text).group(1)
    r = c.post("/app/analyst", data={"csrf": tok, "question": "Which coach fleets reach midlife by 2030?"}, follow_redirects=False)
    job = r.headers["location"].split("job=")[1]
    for _ in range(50):
        j = c.get(f"/app/analyst/job/{job}").json()
        if j["status"] != "running":
            break
        time.sleep(0.1)
    assert j["status"] == "done", j
    assert "Five big coach fleets" in j["html"] and "Cars due" in j["html"] and "not financial" in j["html"]
    print("steps:", j["steps"])
    req = seen[0]
    assert req["model"] == "claude-opus-5-5" and req["fallbacks"] == "default" and req["output_config"]["effort"]
    assert any(t["name"] == "give_answer" for t in req["tools"])
    print("analyst plumbing OK; answer card rendered,", len(j["html"]), "bytes")
