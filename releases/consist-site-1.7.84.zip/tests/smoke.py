"""End-to-end smoke test against a running site: python tests/smoke.py http://localhost:8080 ADMIN_EMAIL ADMIN_PASSWORD
On a real server, run `python -m app.cli clean-test-data` afterwards to remove the test accounts and content it creates.
Signs up a free user, walks every page, saves an alert, upgrades (demo billing), checks paid pages, then walks the admin portal."""
import re
import sys
import time

import httpx

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080"
ADMIN = sys.argv[2] if len(sys.argv) > 2 else "admin@example.com"
ADMIN_PW = sys.argv[3] if len(sys.argv) > 3 else "admin-pass-123"
fails = []


def csrf(html):
    m = re.search(r'name="csrf" value="([^"]+)"', html)
    return m.group(1) if m else ""


def get(c, path, want=200, contains=None):
    r = c.get(path)
    ok = r.status_code == want and (contains is None or contains in r.text)
    print(f"{'ok ' if ok else 'FAIL'} {r.status_code} GET {path}" + ("" if ok or contains is None else f" (missing {contains!r})"))
    if not ok:
        fails.append(path)
    return r


def absent(c, path, text):
    r = c.get(path)
    ok = r.status_code == 200 and text not in r.text
    print(f"{'ok ' if ok else 'FAIL'} {r.status_code} GET {path} (without {text!r})")
    if not ok:
        fails.append(path + " has " + text)
    return r


def post(c, path, data, page="/"):
    tok = csrf(c.get(page).text)
    r = c.post(path, data={**data, "csrf": tok})
    ok = r.status_code in (200, 303)
    print(f"{'ok ' if ok else 'FAIL'} {r.status_code} POST {path}")
    if not ok:
        fails.append("POST " + path)
    return r


pub = httpx.Client(base_url=BASE, follow_redirects=False, timeout=30)
for p in ["/", "/pricing", "/compare", "/compare/bidprime", "/compare/govspend", "/compare/bidnet-direct", "/compare/sci-verkehr", "/compare/railmarket", "/compare/rail-market-research", "/compare/global-mass-transit", "/compare/ftr", "/data", "/data/oldest-rail-fleets", "/data/midlife-overhauls-due", "/data/rail-bids-this-month", "/feed.xml",
          "/coverage", "/blog", "/p/about", "/p/methodology", "/p/terms", "/p/privacy", "/p/find-rail-car-overhaul-bids", "/contact",
          "/signup", "/login", "/sitemap.xml", "/robots.txt", "/solutions", "/solutions/rolling-stock",
          "/signup?persona=freight", "/operators/septa"]:
    get(pub, p)
# freight is parked (admins only): its old public links redirect, and nothing public lists it
get(pub, "/solutions/freight-equipment", 301)
get(pub, "/coverage?lens=freight", 301)
r = get(pub, "/sitemap.xml")
if "freight" in r.text or "/operators/bnsf" in r.text:
    print("FAIL sitemap lists freight"); fails.append("sitemap freight")
get(pub, "/app", 303)
get(pub, "/favicon.ico", 301)
get(pub, "/sitemap.xml", contains="/data/oldest-rail-fleets")
get(pub, "/data/oldest-rail-fleets", contains='"@type": "Dataset"')
get(pub, "/builders", contains="Rail car builders in the US and Canada")  # 1.7.58 public builder and model pages
get(pub, "/builders/kawasaki", contains="/builders/kawasaki/")
get(pub, "/sitemap.xml", contains="/builders/")
get(pub, "/operators/septa", contains="fleet roster")
get(pub, "/pricing", contains='"@type": "Service"')
get(pub, "/operators/no-such-operator", 404)
get(pub, "/admin", 404)  # the portal is hidden from visitors (1030sec)
for p in ["/compare/bidprime", "/compare/govspend"]:
    t = pub.get(p).text
    for needle in ['"@type": "FAQPage"', '"@type": "BreadcrumbList"', 'og:title', '<h1>']:
        if needle not in t:
            print("FAIL missing", needle, "on", p)
            fails.append(p + needle)

# A server that runs invite-only has sign-ups paused: open them for this run and put the setting back on exit.
import atexit
import html as _h
_a0 = httpx.Client(base_url=BASE, follow_redirects=False, timeout=30)
post(_a0, "/login", {"email": ADMIN, "password": ADMIN_PW, "next": "/admin"}, "/login")
_gen = _a0.get("/admin/settings?tab=general").text
if 'name="signup_open" checked' not in _gen:
    _vals = {k: _h.unescape(v) for k, v in re.findall(r'<input name="(\w+)"[^>]*value="([^"]*)"', _gen)}
    _vals.update({k: _h.unescape(v) for k, v in re.findall(r'<textarea name="(\w+)"[^>]*>([^<]*)</textarea>', _gen)})
    _vals = {k: v for k, v in _vals.items() if k in ("site_name", "tagline", "support_email", "footer_note")}
    print("   sign-ups are paused: opening them for this run")
    post(_a0, "/admin/settings", {"tab": "general", **_vals, "signup_open": "on"}, "/admin/settings?tab=general")
    atexit.register(lambda: (post(_a0, "/admin/settings", {"tab": "general", **_vals}, "/admin/settings?tab=general"),
                             print("   sign-ups paused again")))

# 1.7.47 sign-up protection: email confirmation would leave the test accounts unopened, so it is off for this run (the whole
# General form is posted back so no other setting changes) and put back on exit.
def _general_form(html):
    f = re.search(r'<form method="post" action="/admin/settings".*?</form>', html, re.S).group(0)
    vals = {}
    for tag in re.findall(r'<input [^>]*>', f):
        n = re.search(r'name="([^"]+)"', tag)
        if not n or n.group(1) in ("csrf",) or 'type="password"' in tag:
            continue
        if 'type="checkbox"' in tag:
            if " checked" in tag:
                vals[n.group(1)] = "on"
            continue
        v = re.search(r'value="([^"]*)"', tag)
        vals[n.group(1)] = _h.unescape(v.group(1)) if v else ""
    for n, body in re.findall(r'<select [^>]*name="(\w+)"[^>]*>(.*?)</select>', f, re.S):
        m = re.search(r'<option value="([^"]*)"[^>]*selected', body)
        if m:
            vals[n] = _h.unescape(m.group(1))
    for n, v in re.findall(r'<textarea [^>]*name="(\w+)"[^>]*>(.*?)</textarea>', f, re.S):
        vals[n] = _h.unescape(v)
    return vals
_gen = _a0.get("/admin/settings?tab=general").text
if 'name="signup_verify"' in _gen:
    _g0 = _general_form(_gen)
    post(_a0, "/admin/settings", {**{k: v for k, v in _g0.items() if k != "signup_verify"}, "signup_daily_ip": "0"}, "/admin/settings?tab=general")
    print("   email confirmation and the daily sign-up cap off for this run")
    atexit.register(lambda: (post(_a0, "/admin/settings", _g0, "/admin/settings?tab=general"), print("   sign-up protection settings restored")))


def signup(c, data):
    """Sign up the way a person does: the form's stamp, then a pause longer than the minimum fill time."""
    page = c.get("/signup").text
    fs = re.search(r'name="fs" value="([^"]+)"', page)
    time.sleep(3.2)
    r = c.post("/signup", data={**data, "csrf": csrf(page), "fs": fs.group(1) if fs else ""})
    ok = r.status_code in (200, 303)
    print(f"{'ok ' if ok else 'FAIL'} {r.status_code} POST /signup")
    if not ok:
        fails.append("POST /signup")
    return r


# The admin plan edit below overwrites Pro: save the live Pro form now and put it back on exit, and check members against what Pro
# really includes on this server.
def _plan_form(html, pid):
    m = re.search(r'<form method="post" action="/admin/plans/' + pid + r'".*?</form>', html, re.S)
    f = m.group(0) if m else ""
    vals = {k: _h.unescape(v) for k, v in re.findall(r'<input name="(\w+)"[^>]*value="([^"]*)"', f)}
    vals.update({k: "on" for k in re.findall(r'<input type="checkbox" name="(\w+)" checked', f)})
    t = re.search(r'<textarea name="bullets">(.*?)</textarea>', f, re.S)
    vals["bullets"] = _h.unescape(t.group(1)) if t else ""
    return vals
_pro0 = _plan_form(_a0.get("/admin/plans").text, "pro")
PRO_AWARDS, PRO_ALL = "f_awards" in _pro0, "f_lens_all" in _pro0
if _pro0.get("name"):
    atexit.register(lambda: (post(_a0, "/admin/plans/pro", _pro0, "/admin/plans"), print("   Pro plan restored")))

u = httpx.Client(base_url=BASE, follow_redirects=False, timeout=60)
email = f"test{int(time.time())}@example.com"
# a bot that posts without the form's stamp is turned away (1.7.47)
_b = httpx.Client(base_url=BASE, follow_redirects=False, timeout=30)
r = post(_b, "/signup", {"email": f"bot{int(time.time())}@example.com", "password": "correct-horse-1"}, "/signup")
if "form expired" not in r.text:
    fails.append("sign-up without a form stamp was not refused")
r = signup(u, {"email": email, "password": "correct-horse-1", "name": "Test User", "company": "Test Rail Co"})
assert r.headers.get("location") == "/app", r.headers
# sign-up with a persona sets the market and a starter alert
u2 = httpx.Client(base_url=BASE, follow_redirects=False, timeout=60)
signup(u2, {"email": f"test{int(time.time())}9@example.com", "password": "correct-horse-1", "persona": "component", "region": "US"})
get(u2, "/app", contains="Component sales")
# Google Tag Manager: on public marketing pages, never inside the app (SEO thread, 2026-10-30)
get(pub, "/", contains="G-SCJWC2HBS3")
absent(u2, "/app/account", "googletagmanager")
get(u2, "/app/alerts", contains="My trades")
# Free plan page access (Admin > Plans page grid, app/pages.py): a page locked for the plan redirects to /app/upgrade?locked=...
_free_locked = lambda p: (lambda r: r.status_code == 303 and "/app/upgrade?locked=" in r.headers.get("location", ""))(u.get(p))
for p in ["/app", "/app/bids", "/app/bids?status=all&category=component_repair", "/app/fleets", "/app/fleets?mode=CR&sort=age",
          "/app/operators", "/app/operators/LIRR", "/app/fleets/1", "/app/work", "/app/work?view=pipeline", "/app/awards", "/app/work?view=orders",
          "/app/analyst", "/app/alerts", "/app/account", "/app/saved", "/app/upgrade?plan=pro", "/app/subsystems", "/app/costs",
          "/app/awards?tab=funding", "/app/awards?tab=analyst", "/app/awards?tab=analyst&category=component_repair&q=truck+overhaul", "/app/work?view=om", "/app/awards/1", "/app/market/drill?by=builder&name=Alstom", "/app/market/drill?by=supplier&comp=brakes&name=Wabtec", "/app/search", "/app/search?q=alstom", "/app/search?q=zzzz", "/app/awards?tab=funding&segment=freight", "/app/awards?tab=funding&segment=transit&stage=budgeted", "/app/builders/alstom?model=R160", "/app/bids/1", "/app/fleets?lens=freight&region=US"]:
    if _free_locked(p):  # locked for Free in Admin > Plans: the redirect to the upgrade page is the expected answer
        print(f"ok  303 GET {p} (locked for Free)")
        continue
    get(u, p)
for p in ["/app/freight/renewal", "/app/freight/renewal?y=2019", "/app/freight/about", "/app/freight/metric/retired_units?rr=BNSF&y=2024", "/app/freight/metric/rebuilt_units"]:
    get(u, p, 404)  # freight is parked: admins only
_m = re.search(r'/app/bids/(\d+)', u.get("/app/bids").text) or re.search(r'/app/bids/(\d+)', u.get("/app/bids?status=all").text)
if _m:
    get(u, f"/app/bids/{_m.group(1)}")
else:
    print("   note: no bids in the free 30-day window, bid detail check skipped")
if not _free_locked("/app/work?view=pipeline"):
    get(u, "/app/work?view=pipeline", contains="is on a paid plan")
# old addresses now redirect into the new sections
for p_ in ["/app/pipeline", "/app/procurements", "/app/opportunities", "/app/forecast", "/app/updates"]:
    get(u, p_, 303)
# market lens, region, trades and persona
post(u, "/app/prefs/lens", {"lens": "passenger", "region": "US", "back": "/app/fleets?lens=transit"}, "/app")
get(u, "/app/fleets", contains='aria-pressed="true">Passenger rail')
r = get(u, "/app/fleets?lens=freight")  # parked: the freight lens isn't offered and falls back to all rail
if ">Freight locomotives<" in r.text:
    print("FAIL member sees the freight lens"); fails.append("freight lens visible")
post(u, "/app/prefs/lens", {"lens": "all", "back": "/app"}, "/app")
get(u, "/app/fleets", contains="All regions")
post(u, "/app/prefs/trades", {"trade": "signals_communications"}, "/app/bids")
post(u, "/app/account/market", {"persona": "component", "region": "US"}, "/app/account")
get(u, "/app", contains="Component sales")
post(u, "/app/account/market", {"persona": "oem"}, "/app/account")
get(u, "/app/bids?export=1", 403)
post(u, "/app/alerts", {"name": "HVAC", "q": "HVAC", "frequency": "weekly"}, "/app/alerts")
get(u, "/app/alerts", contains="HVAC")
post(u, "/app/watch", {"kind": "operator", "ref": "LIRR", "back": "/app/operators"}, "/app/operators")
post(u, "/app/upgrade", {"plan": "pro", "interval": "month"}, "/app/upgrade?plan=pro")
get(u, "/app/account", contains="Pro")
get(u, "/app/work?view=pipeline", contains="Overhaul pipeline")
get(u, "/app/work", contains="Upcoming work")
get(u, "/app/costs", contains="Cost benchmarks")
get(u, "/app/operators?category=freight_", 303)
for p in ["/app/freight", "/app/freight?m=operating_ratio_pct&y=2024", "/app/freight/rr/UNION_PACIFIC", "/app/freight/rr/CPKC?y=2022",
          "/app/freight/metric/cost_per_unit_mile?rr=CSX&y=2025", "/app/freight/metric/terminal_dwell_hrs", "/app/freight/rebuild?rs=40&fs=5"]:
    get(u, p, 404)  # freight analytics portal: parked, admins only
if not PRO_ALL:
    get(u, "/app/work?lens=passenger", contains="free-plan depth")  # Pro includes one market
get(u, "/app/fleets/1", contains="Miles per car per year")
r = get(u, "/app/bids?export=1")
print("   csv rows:", r.text.count("\n"))
get(u, "/app/awards?tab=awards", contains="Who wins" if PRO_AWARDS else "is on a paid plan")
post(u, "/app/upgrade", {"plan": "team", "interval": "year"}, "/app/upgrade?plan=team")
get(u, "/app/awards", contains="Who wins")
# sales intel (Team plan has every feature)
for p_, needle in [("/app/work?view=ranked", "Score"), ("/app/work?view=ranked&offering=component:hvac&years=10", None), ("/app/work?view=forecast", None),
                   ("/app/suppliers", None), ("/app/market", None), ("/app/builders", None), ("/app/lists", None), ("/app/alerts?tab=fleet", None), ("/app/subsystems?subsystem=doors", None),
                   ("/app/fleets?signal=past_ulb", None), ("/app/fleets?subsystem=brakes", None), ("/app/fleets/1/roster", None),
                   ("/app/operators/LIRR/brief", "Print"), ("/app/operators/SEPTA", "Programs, funding and contracts"),
                   ("/app/fleets/93", "Reliability and spares")]:
    get(u, p_, contains=needle)
for ex in ["csv", "salesforce", "hubspot"]:
    get(u, f"/app/opportunities?export={ex}")
sid = re.search(r'/app/suppliers/([\w.-]+)"', u.get("/app/suppliers").text)
if sid:
    get(u, f"/app/suppliers/{sid.group(1)}")
bslug = re.search(r'/app/builders/([\w.-]+)"', u.get("/app/builders").text)
if bslug:
    get(u, f"/app/builders/{bslug.group(1)}")
r = post(u, "/app/lists", {"name": "Smoke list", "fleet_id": "1"}, "/app/lists")
lid = re.search(r"/app/lists/(\d+)", r.headers.get("location", ""))
if lid:
    post(u, f"/app/lists/{lid.group(1)}", {"action": "add", "from_filter": '{"mode": "CR"}'}, f"/app/lists/{lid.group(1)}")
    get(u, f"/app/lists/{lid.group(1)}", contains="Smoke list")
    get(u, f"/app/lists/{lid.group(1)}?export=csv")
post(u, "/app/operators/LIRR/notes", {"body": "Smoke note"}, "/app/operators/LIRR")
post(u, "/app/operators/LIRR/contacts", {"name": "Smoke Contact", "title": "CMO"}, "/app/operators/LIRR")
get(u, "/app/operators/LIRR", contains="Smoke Contact")
post(u, "/app/watch", {"kind": "fleet", "ref": "1", "back": "/app/fleets/1"}, "/app/fleets/1")
post(u, "/app/updates/prefs", {"fleet_email": "daily"}, "/app/alerts?tab=fleet")
post(u, "/app/team/invite", {"email": "colleague@example.com"}, "/app/account")
get(u, "/app/account", contains="colleague@example.com")
get(u, "/admin", 404)

a = httpx.Client(base_url=BASE, follow_redirects=False, timeout=30)
r = post(a, "/login", {"email": ADMIN, "password": ADMIN_PW, "next": "/admin"}, "/login")
assert r.headers.get("location") == "/admin", r.headers
for p in ["/admin", "/admin/users", "/admin/plans", "/admin/content", "/admin/content/edit?slug=about", "/admin/data", "/admin/sources", "/admin/coverage", "/admin/coverage?quiet=1", "/app/coverage",
          "/admin/leads", "/admin/intel", "/admin/intel?t=unit_cost", "/admin/intel?t=funding_award", "/admin/intel?t=fleet_contract",
          "/admin/intel?t=operator_cost_manual"]:
    get(a, p)
# freight moved into the rail portal: the old URLs redirect there for admins
for p, to in (("/app/freight/rr/UNION_PACIFIC", "/rail/locomotives/rr/UNION_PACIFIC"), ("/admin/freight/m/financials", "/rail/r1/m/financials")):
    get(a, p, 301)
    loc = a.get(p).headers.get("location", "")
    if loc != to:
        print(f"FAIL {p} redirects to {loc!r}"); fails.append(p + " redirect")
uid = re.search(r'/admin/users/(\d+)">' + re.escape(email), a.get("/admin/users").text).group(1)
get(a, f"/admin/users/{uid}", contains=email)
post(a, f"/admin/users/{uid}", {"name": "Test User", "company": "X", "role": "user", "plan_id": "pro", "status": "active",
                                 "sub_status": "manual", "notes": "comped", "ai_used": "0"}, f"/admin/users/{uid}")
post(a, "/admin/plans/pro", {"name": "Pro", "blurb": "For BD teams", "price_month": "249", "price_year": "2388", "seats": "1", "ai_quota": "60",
                              "search_limit": "10", "sort": "1", "active": "on", "highlight": "on", "f_bids_recent": "on", "f_bids_full": "on",
                              "f_fleet_basic": "on", "f_fleet_detail": "on", "f_pipeline": "on", "f_export": "on", "f_alerts_instant": "on",
                              "f_bid_brief": "on", "f_opportunities": "on", "f_market": "on", "f_lists": "on", "f_fleet_alerts": "on",
                              "bullets": "Full bid history\nInstant alerts"}, "/admin/plans")
get(pub, "/pricing", contains="For BD teams")
post(a, "/admin/content/edit", {"slug": "test-guide", "orig": "", "title": "Test guide", "description": "d", "body": "## Hello\n\nWorld",
                                 "kind": "post", "published": "on"}, "/admin/content/edit")
get(pub, "/p/test-guide", contains="Hello")
post(a, "/admin/announcements", {"action": "add", "text": "Launch week banner", "audience": "all"}, "/admin/content")
get(pub, "/", contains="Launch week banner")
post(pub, "/contact", {"name": "Lead", "email": "lead@example.com", "company": "Acme", "message": "Enterprise please"}, "/contact")
get(a, "/admin/leads", contains="Enterprise please")
# the rail portal: admins always get in; visitors get a 404 while it's closed, the landing page once it's open
for p in ["/rail", "/rail/r1/m/financials", "/rail/locomotives", "/rail/safety", "/rail/causes", "/rail/crossings", "/rail/crossings/ungated", "/rail/about"]:
    get(a, p)
r = pub.get("/rail")
ok = r.status_code == 404 or (r.status_code == 200 and "vs-hero" in r.text and "adm-side" not in r.text)
print(f"{'ok ' if ok else 'FAIL'} {r.status_code} GET /rail signed out (404 or landing)")
if not ok:
    fails.append("/rail signed out")
# admin portal: no public sign-in page; visitors and members get 404, admins sign in on /login
get(pub, "/admin/login", 404)
get(httpx.Client(base_url=BASE, follow_redirects=False, timeout=30), "/admin/settings", 404)
a2 = httpx.Client(base_url=BASE, follow_redirects=False, timeout=30)
r = post(a2, "/login", {"email": ADMIN, "password": ADMIN_PW, "next": "/admin/settings"}, "/login")
assert r.headers.get("location") == "/admin/settings", r.headers
for t in ["general", "home", "billing", "email", "ai"]:
    get(a2, f"/admin/settings?tab={t}")
for p in ["/admin/compare", "/admin/compare/edit?slug=bidprime", "/admin/compare/edit", "/admin/account", "/admin/audit"]:
    get(a2, p)
import html as _html
_home = a2.get("/admin/settings?tab=home").text
orig_home = {k: _html.unescape(v) for k, v in re.findall(r'<input name="(\w+)" value="([^"]*)"', _home)}
orig_home.update({k: _html.unescape(v) for k, v in re.findall(r'<textarea name="(\w+)"[^>]*>([^<]*)</textarea>', _home)})
post(a2, "/admin/settings", {"tab": "home", "hero_title": "Smoke headline here.", "hero_highlight": "headline", "hero_sub": "Sub",
                              "hero_cta": "Go now", "features_title": "F", "features_intro": "{site} intro", "cta_title": "C", "cta_sub": "S",
                              "meta_description": ""}, "/admin/settings?tab=home")
get(pub, "/", contains="<em>headline</em>")
post(a2, "/admin/settings", {"tab": "home", **orig_home}, "/admin/settings?tab=home")  # put the real home page text back
get(pub, "/", contains=_html.escape(orig_home.get("hero_sub", ""))[:40])
post(a2, "/admin/settings", {"tab": "email", "SMTP_HOST": "", "SMTP_PORT": "587", "SMTP_USER": "x@example.com", "SMTP_FROM": "",
                              "SMTP_PASSWORD": "secret-pass-9876"}, "/admin/settings?tab=email")
t = a2.get("/admin/settings?tab=email").text
if "secret-pass-9876" in t or "9876" not in t:
    print("FAIL secret not masked properly"); fails.append("secret mask")
post(a2, "/admin/settings", {"tab": "email", "SMTP_HOST": "", "SMTP_PORT": "587", "SMTP_USER": "", "SMTP_FROM": "", "clear_SMTP_PASSWORD": "on",
                              "clear_SMTP_USER": "on"}, "/admin/settings?tab=email")
ed = a2.get("/admin/compare/edit?slug=govspend").text
rows = re.search(r'name="rows"[^>]*>([^<]*)</textarea>', ed).group(1)
post(a2, "/admin/compare/edit", {"orig": "govspend", "slug": "govspend", "name": "GovSpend", "category": "c", "one_liner": "o",
                                  "blurb": "b", "summary": "Smoke summary text", "verdict": "Pick {site} if rail.", "rows": rows + "\nSmoke row | a | b | us",
                                  "pricing": "p", "free": "f", "us_pros": "x", "us_cons": "y", "them_pros": "z", "them_cons": "w", "sources": "", "checked": "Now"},
     "/admin/compare/edit?slug=govspend")
get(pub, "/compare/govspend", contains="Smoke summary text")
get(pub, "/compare/govspend", contains="Smoke row")
post(a2, "/admin/compare/edit", {"orig": "govspend", "action": "reset"}, "/admin/compare")
get(pub, "/compare/govspend", contains="purchase order")
post(a2, "/admin/compare/edit", {"orig": "", "slug": "smoke-rival", "name": "Smoke Rival", "summary": "s", "verdict": "v",
                                  "rows": "Coverage | rail | all\nbad line", "us_pros": "", "us_cons": "", "them_pros": "", "them_cons": ""}, "/admin/compare/edit")
get(pub, "/compare/smoke-rival", contains="Smoke Rival")
get(pub, "/sitemap.xml", contains="/compare/smoke-rival")
post(a2, "/admin/compare/edit", {"orig": "smoke-rival", "action": "reset"}, "/admin/compare")
get(pub, "/compare/smoke-rival", 404)
get(a2, "/admin/audit", contains="admin compare")
print("\nFAILURES:", fails if fails else "none")
sys.exit(1 if fails else 0)
