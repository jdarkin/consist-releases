"""Settings from the environment. Any secret can also be given as NAME_FILE pointing at a file (Docker secrets style)."""
import json
import os
import secrets


def env(name, default=""):
    path = os.environ.get(name + "_FILE")
    if path and os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    return os.environ.get(name, default)


def flag(name, default="0"):
    return env(name, default).lower() in ("1", "true", "yes", "on")


HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = env("DATA_DIR", os.path.join(os.path.dirname(HERE), "data"))
APP_DB = os.path.join(DATA_DIR, "app.db")
# The live fleet-db data folder, mounted into this container. The site only reads it (bid sources can be edited if allowed).
FLEET_DB = env("FLEET_DB", "/fleetdata/fleet.db")
BIDS_DB = env("BIDS_DB", "/fleetdata/bids.db")
BIDS_DB_WRITABLE = flag("BIDS_DB_WRITABLE")
NEXGEN = flag("NEXGEN")  # NexGen sandbox only: sandbox banner and draft plans on /pricing (paused 2026-11-07)
VERSION = "1.7.50"  # 1.7.50 = SEO thread fixes (weekly reports): compare pages lead with "{X} alternatives" in title, H1 and meta (alternatives section above the table), home meta description 151 characters; GA4 key events sent from the server by the Measurement Protocol (app/ga.py, ga_client table, GA_API_SECRET in Admin > Settings > General > Analytics): sign_up when the account opens (after email confirmation), begin_checkout, purchase (Stripe session as transaction_id), production only, never admins; Caddyfile in the source is a reference copy and site zips leave it out (Justin 11-16 megawatch rule); 1.7.49 = Promote button (Justin 11-16, Pi/hosting thread): Admin > Builds and deploys lists Releases waiting from deploy-state.json (zips the server pulled from the consist-releases GitHub repo, staged by consist-deploy), Promote to production writes an HMAC-signed request (DEPLOY_REQUEST_KEY, production .env only) to /fleetdata/deploy-requests that consist-deploy runs within a minute; type-the-name confirm, audit log, glossary terms; 1.7.48 = agency coverage (Bids thread contract coverage-data-contract.md, bids-push27 agency_coverage): member page /app/coverage (Find work > Agency coverage, gated like Bids, follows the territory and region) with status pills, channels in plain words, last posting, open bids, 90-day notices, last checked, soft quiet note and tiles, no scraper internals; admin /admin/coverage (Bid coverage health) with every column, status/quiet/blocked filters, page_watch and meeting_source details per agency, latest run_log per task, registrations and news sources; empty until push27; training step and glossary; 1.7.47 = sign-up bot protection (Justin 11-16) and territory bid alerts: signed form time stamp with a minimum fill time (signup_min_secs, default 3), daily sign-ups per network (signup_daily_ip, default 10) on top of 5 per ten minutes, throwaway email domains refused (signup_block_disposable), email confirmation before the account opens (signup_verify, on: status unconfirmed until /confirm/<token>, 48 hours, resend from sign-in), optional Cloudflare Turnstile (turnstile_on + site key, TURNSTILE_SECRET in integrations; CSP allows challenges.cloudflare.com), every refusal logged in signup_block and shown in Admin > Settings > Sign-up protection (app/signupguard.py); bid alerts can be limited to the member's saved territory (query territory=1, Only bids in my territory on Alerts); training steps and glossary; 1.7.46 = Ambassador invite delivery (Justin 11-13 "not getting my invites reliably"): invites go out as personal mail without List-Unsubscribe headers (the bulk signal that sent them to Promotions, Junk or quarantine while the header-free test reached Justin; the opt-out check stays), each invite row records why it was not emailed (ambassador.send_error), and a Copy letter button puts the subject, letter and link on the clipboard to send from his own mailbox or LinkedIn; training and glossary; 1.7.45 = sales territory (Justin 11-13): Account > Your territory saves states and provinces (region quick picks), agencies picked by name and national buyers (user_pref ter_states, ter_ops, ter_ags, ter_national, ter_on; app/territory.py resolves them to fleet operator and bid agency ids); the Territory switch in the header turns it on or off (?territory=0/1 for one page); while on, the request scope (lens.Scope.ter_ops/ter_ags) narrows bids, early signals, awards, board items, vehicle orders, fleets, operators, upcoming work, opportunities, capital projects, on-call contracts, past RFPs, O&M contracts, dashboards and header search; a filter naming one agency or operator still shows it; cost benchmarks, vehicle price analysts, alert emails and the API stay national; training step and glossary; 1.7.44 = Early signals shows what comes before an RFP (Justin 11-12: "doesn't show much"; production had 88 RFI-type notices in a year but 85 scored under 25, so the default relevance floor of 50 showed 1): no relevance floor for RFIs, sources sought, industry days, letters of interest and pre-solicitations, plus Bid Catcher notice.stage = 'early' when present (bids-push26); new sections for agency procurement forecasts (notice_type planned), board solicitation and budget items, on-call rebids due within 12 months and planned or RFP vehicle orders; notices ntype and stage filters; training step and glossary; 1.7.43 = social webhook short_text is the headline only (250 characters at most, no link), since Make adds the url for X and Bluesky; 1.7.42 = social reach (Social thread): short_text on the social webhook (headline + link, 280 characters or fewer, ?ref=social) for X and Bluesky, "Copy as LinkedIn newsletter" card in Admin > Social posts, Bluesky setting with footer icon and sameAs, Site usage "X and Bluesky" channel, training step "Follow us anywhere"; 1.7.41 = LinkedIn Insight Tag (Justin 11-12): Admin > Settings > Analytics on/off + Partner ID (linkedin_tag_on, linkedin_partner_id; main.linkedin_tag), public marketing pages only like GA, never app/admin/admins; opt-in cookie banner (Accept/Decline, localStorage consist_ads_consent, Global Privacy Control = decline, footer Cookie choices); CSP adds snap.licdn.com and *.linkedin.com; Privacy page LinkedIn wording applied once (flag legal_linkedin_1112, old body kept as privacy-before-1112); training step and glossary; 1.7.40 = every row, tile and card drills (Justin 11-12): supplier profile Fleets in service and Recent awards rows open the fleet and award (agency opens its awards), tiles jump to their lists; row click falls back to a filtered-list drill, a lead filter pill, then an outside record in a new tab (app.js); vendors, bidders, winners and contractors open the company (Supplier Intelligence, else its awards; data.vendor_href/vlink), builders open the builder page (data.builder_href/blink), overhaul and work-package rows open the subsystem market or Upcoming work (data.overhaul_href/ohlink), operator mode rows open that agency's fleets, lessors open Fleet Explorer by owner, forecast groups and demand years open their lists, persona order rows open the order, drivers, train control, funding awards (USAspending) and programs, budget rows, suppliers list, R-1 railroads and admin compare/content/supplier financials rows drill; count tiles on operator, award, order, supplier, analyst, consultant, market and funding pages are links (a.tile, ›); announced-program pills, plan titles and plan rows on Upcoming work open the announcement (source) in a new tab; training step and glossary; 1.7.39 = MTA M9A findability (Data audit 11-12, Justin): search ignores hyphens, spaces, dots and slashes (data.norm/qhit/sqln; header search, Fleet Explorer, bids, awards, vehicle awards, opportunities, platforms, capital projects, past RFPs), header search has a Vehicle orders group (order book, opens /app/work/orders/<id>; follows /app/work access), award analyst order-book rows open the order page; fleets whose replacement is already ordered (order notes "replaces M3/M3A", intel.replacement_orders) are left out of the buy ranking with a Replacement ordered pill and a Show already ordered link, Replacement RFP out pill for orders out to bid or planned; training and glossary; 1.7.38 = Admin > Builds and deploys (Justin 11-12): what is on production and staging (site version, zip, package SHA-256, container image, when) and the last Bid Catcher push and check, with full history including failed runs, read from deploys.jsonl that consist-stage/promote.sh and bids-stage/promote.sh now append to (/opt/fleet-db-docker/data, /fleetdata in the site); flags a production copy whose version differs from the last recorded deploy; glossary terms; 1.7.37 = option exercise rows read plainly (Justin 11-12): an option row sits on a fleet only when that fleet is the ordered model, otherwise it shows the order itself ("on order, not in service yet", links to the order page, New cars on order pill, no borrowed fleet signals, score = timing + size); detail reads "<agency> can still buy N more on the <year> <builder> order (M ordered)"; joint orders list every agency and match the operator filter for each; year and value marked est. with the basis on hover; CSV fleet_url and API order_id for order rows; training step Option exercises; 1.7.36 = awareness plan Phase 1 (Justin 11-12): weekly LinkedIn chart image posts (app/socialimg.py, /img/chart/<chart>.png, webhook image_url, promo_charts), Embed this chart on /data pages (?ref=embed backlink), monthly member email with ambassador share kits and press pitch drafter (app/awareness.py, Admin > Social posts), Site usage > Sources tab (channels, sign-ups, paid); requirements add Pillow; 1.7.35 = chart drills (Justin 11-12): Orders and backlog by-year chart opens Vehicle orders for that builder and award year (new builder and award-year filters and pills on Vehicle orders), share-of-new-orders bars open the builder page (or its orders when it has no fleets on file), capital planner bars narrow the table to that year and type (other rows hidden, still recalculated), supplier change window coverage bars open Subsystems for that subsystem, leasing ownership bars open Fleet Explorer filtered by ownership (new own filter); trend lines unchanged; training step updated; 1.7.34 = one UI standard on every page (Justin 11-12): click any record row to open it (app.js picks the row's record link; Ctrl/Cmd-click new tab; data-norow opts out), pills that name a value filter (order status on Vehicle orders, operator and order pages; work type and subsystem in the award analyst; kinds of work on consultant pages), status pills explain themselves on hover, dashboard overhaul chart drills to the pipeline, 183 new heading definitions (freight portal, escalation, funding programs, investors, agency planner, API keys and more), export links read Export CSV / Export Excel everywhere; training module "How every page works"; 1.7.33 = vehicle order detail page (/app/work/orders/<id>: details, still to come, fleets at the operator with the matching fleet marked, builder's other orders, Ask the analyst); Vehicle orders rows and dashboard Recent orders open it (rows with data-href are clickable anywhere); bid alert emails lead with the English title of French and Spanish notices (original below, original alone until translated); training step Vehicle orders; 1.7.32 = Capital projects tables: long buyer names and firm lists wrap in their own columns, contract and project titles get the width, on-call Ends shows "options to" under it, value cell shows Spent over the shared ceiling; French and Spanish bid notices (Bid Catcher bids-push22, read only when present): English machine translation shown with the original on bid pages and as the main line in lists (original below), lang attributes on originals, search matches the English, CSV and API add lang and title_en, training step and glossary; 1.7.31 = on-call and IDIQ contracts from Bid Catcher bids-push21 fields (read only when bids.db has them; title rule before): Capital projects on-call table one row per bench (all firms, holder filter matches any firm), base end and With options columns, rebid due a year before, Next round posted pill, shared ceiling or Spent X of Y; dashboard card the same; award pages show contract type, task order to parent contract link, task orders under an on-call with total, other bench firms, ceiling, spent, end dates; Bids On-call / IDIQ pill uses contract_type; training step "On-call expiry" and glossary terms; 1.7.30 = estimated operating costs (R&D peer model, allocation_method peer_estimate / r1_freight): "Est." badge with grade and range on Fleet Explorer, operator Fleets card, fleet page cost and remaining-life cards; fleet page shows the estimate per car-year, likely range, the comparable fleets (linked) and basis; estimates left out of peer benchmark display, the operators list average and fleet change alerts; fleet CSV adds cost_basis, estimate_grade and range columns; training step "Reported or estimated cost" and glossary terms; 1.7.29 = operator news: wider aliases per operator (NEWS_ALIASES, e.g. TransEd = Valley Line LRT/Southeast/West, Edmonton LRT) and rail context with LRT, light rail, streetcar, tram, subway; cache keyed by the query so new terms take effect at once; an empty result is rechecked after an hour and never shown as a saved copy when the services are busy (busy message instead); an empty GDELT answer tries Google News; 1.7.28 = Training link moved to the top of the sidebar (under My dashboard) and added to the top menu bar; 1.7.27 = 1.7.27 = training portal at /app/learn (Training: start here in the sidebar, button on Getting started): Start here plus 8 lessons (search, Fleet Explorer, operator pages, Bid Catcher, AI analyst and exports, document uploads, market intelligence, account and alerts), each step an animated SVG walkthrough drawn by app/learn.py (reduced-motion safe; a static/learn/<slug>-<n>.mp4 clip replaces it when present), "Try it now" links, per-member progress (user_pref learn_done); 1.7.26 = analyst upload panel is one card with the consent checkbox left of its text; a chosen file needs the box ticked before sending (browser check); a question that says "attached" or "uploaded" with no document is stopped before it uses a question; answers show the attached document; on-screen answers and briefs use IBM Plex Sans (self-hosted) like the exports; 1.7.25 = AI analyst document uploads (app/uploads.py: PDF, Word, text, CSV up to 10 MB, consent box, private to the uploader, reuse and delete, Admin > Analyst uploads); public agency solicitations in uploads are checked against bids.db and queued for Bid Catcher with no member details (app/uploadrec.py, /admin/uploads/notices.json + ack, X-Bids-Key); Privacy and Terms upload sections appended once (flag legal_uploads_1111); agency_document notices labelled "Agency solicitation document"; 1.7.24 = site-wide search bar in the header of every app page (app/sitesearch.py): typing filters the lists on the current page, Enter searches the whole site (pages, operators, fleets, builders and models, subsystem suppliers, bids and RFPs, awards, supplier directory), each group gated by page access (preview = 3 hits), Amtrak restricted; "Ask about this fleet" now sends the fleet record with the question (analyst.fleet_context, job ref fleet:<id>, exports titled with the fleet); 1.7.23 = Fleet explorer: an operator name opens that operator's page at its Fleets card (/app/operators/<id>#fleets); a small "only these" link keeps the filter-to-operator option; 1.7.22 = brief PDF report font is IBM Plex Sans (Justin's pick; Source Sans 3 dropped); 1.7.21 = brief PDF typography: bundled report font (bundled, SIL OFL) with kerning (uharfbuzz), looser line spacing, key-figure values shrink then wrap to stay inside their tiles; 1.7.20 = AI brief exports redesigned: branded PDF (Consist header band and logo, verdict badges, key-figure tiles, styled table and caveats) plus RTF and TXT downloads; 1.7.19 = Amtrak notices shown restricted (data.NO_REDISTRIBUTE: title, ref, dates, category, subsystems and a portal link only; no description, summary or value) on every page, export, API and alert email, and the AI analyst is told not to quote them; 1.7.18 = Market share: click a subsystem (card title or pill) to zoom to its supplier market: every supplier, share, cars, fleets, products and the car builders it supplies (?sub=); 1.7.17 = Bids page Relevance filter (All, 25+, 50+ default, 75+, 90+; ?min_rel= clamped 0-100); 1.7.16 = operator pages: Board meetings and documents (upcoming meetings, rail agenda items, recent documents) from Bid Catcher push16 meeting tables, gated like Bids, empty until push16 is installed; board_agenda awards labelled; 1.7.15 = AI briefs and analyst answers download as PDF (app/pdfbrief.py, fpdf2 + bundled DejaVu fonts); "Update the brief" re-runs a bid fit brief (1 question); 1.7.14 = home page stats: "N passenger and transit operators · 600+ freight railroads" headline line and "past awards tracked" in the stats strip (replaces the duplicate 128 agencies watched); 1.7.13 = Free gets Early signals as a preview (flag plan_access_1108c); Platform map installed-base header counts each fleet once; freight CSV export (?export= on /rail pages) also needs the export feature, so view-only Rail Expert cannot download; pricing compare table follows it; 1.7.12 = referral program (app/referrals.py: /r/<code> links, 50% off first month for the referred, free month for the referrer after 30 days, cap 12/yr, Admin > Referrals); 1.7.11 = plan audit answers (Justin 11-08): Freight Markets Analyst locks the passenger and transit Find Work pages (upcoming work, early signals, past RFPs, capital projects, awards, drivers) and drops their features, Free sees the first 10 fleets (paid columns blurred), pricing table and upgrade notes follow page access, Free bullet and FAQ updated; 1.7.10 = 1.7.10 = Admin > Diagnostics: "Mark as seen" (and Undo) per health check, on Payments and for everything; counts and checks only count newer problems, nothing is deleted; 1.7.9 = plan audit fixes: previews trim nested tables (Past RFPs) and card lists (train control, delivery record), awards funding tab and supplier directory previews trimmed, no bid cards on dashboards when Bids is locked; 1.7.8 = plan saves without the page grid keep page access; smoke test expects Free-locked pages to redirect; 1.7.7 = Platform supplier map drill-down: click a supplier, platform, agency or subsystem to filter the map and an installed-base table (with export); 1.7.6 = CRM export + API keys enterprise-only (api feature), page access per plan (app/pages.py: Full/Preview/Locked per page in Admin > Plans, Justin matrix 11-08 applied once), enterprise-by-quote line on pricing; 1.7.5 = 14-day no-card free trial (app/trial.py): exports, downloads and API off while trialing, 10 AI questions, 300 pages a day; 1.7.4 = every pill that names a value filters its list the same way (shared partials/filters.html: outline + ✕ when active, click again to clear, Filtered by chips); 1.7.3 = Past RFPs: type, method, outcome and winner pills filter the list (click again to clear), active filter chips; 1.7.2 = Past RFPs: click bidders for who bid and prices, better dedupe, award lines dropped; Capital projects slicers (buyer, contract holder, work type, method, status, dates, value, on-call end) + clickable tag pills + lens and region pills filter it + projects export; 1.7.1 = the app's full Content-Security-Policy reaches visitors (Caddy no longer replaces it); 1.7 = SEO suggestions queue (Admin > SEO suggestions, seo-import CLI, report.json, page overrides) + security fixes (consultant/tier-1 plan gate, API rate limit, CSV formula guard, http-only external links); 1.6 = dashboard bid cards: just posted = last 30 days, role fallback to all rail, closing date read from notice text; 1.5 = past RFP fixes (SEAO award notices, dedupe, pending bids), supplier intel labels; 1.4 = news fallback (Google News RSS), background refresh, operator aliases; 1.3 = past RFPs slicers + award matching; 1.1 = NexGen merged (2026-11-07); 1.2 = train control UI, consultants and tier-1 portals, per-role dashboards
NX_FEATURES = True  # persona tools from NexGen, on everywhere since 1.1
# FRA safety and grade crossing data (built monthly by the fleet-db stack's fra-update step); read only, by the /rail portal
FRA_DB = env("FRA_DB", os.path.join(os.path.dirname(FLEET_DB), "fra.db"))
# Freight (railroad locomotive fleets, freight bids, /app/freight) is parked: only admins see it until this is set.
FREIGHT_PUBLIC = flag("FREIGHT_PUBLIC")
# Bid Catcher's own settings (alert recipients); the site edits only the subscribers list in it
BIDS_CONFIG = env("BIDS_CONFIG", os.path.join(os.path.dirname(BIDS_DB), "bids", "config.json"))

SITE_URL = env("SITE_URL", "http://localhost:8080").rstrip("/")
COOKIE_SECURE = flag("COOKIE_SECURE", "1" if SITE_URL.startswith("https") else "0")


def _secret_key():
    key = env("SECRET_KEY")
    if key:
        return key
    # No key configured: keep one in the data folder so sessions survive restarts.
    os.makedirs(DATA_DIR, exist_ok=True)
    path = os.path.join(DATA_DIR, ".secret_key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_urlsafe(48))
        os.chmod(path, 0o600)
    with open(path) as f:
        return f.read().strip()


SECRET_KEY = _secret_key()

# Integration settings (Stripe, email, AI) can come from the server .env or be entered in Admin > Settings. Values saved in the
# admin are kept in DATA_DIR/integrations.json (chmod 600, never shown back in full) and take precedence over .env.
INTEGRATIONS_FILE = os.path.join(DATA_DIR, "integrations.json")
SECRET_FIELDS = {"STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET", "ANTHROPIC_API_KEY", "SMTP_PASSWORD", "ALERT_SMTP_PASSWORD",
                 "LINKEDIN_CLIENT_SECRET", "LINKEDIN_TOKEN", "LINKEDIN_REFRESH", "LINKEDIN_WEBHOOK_URL", "SEO_REPORT_KEY", "BIDS_INGEST_KEY", "TURNSTILE_SECRET",
                 "GA_API_SECRET"}
INTEGRATION_FIELDS = {
    "STRIPE_SECRET_KEY": "", "STRIPE_WEBHOOK_SECRET": "",
    "ANTHROPIC_API_KEY": "", "ANALYST_MODEL": "claude-opus-5-5", "ANALYST_EFFORT": "medium", "ANALYST_MAX_USD": "0.80",
    "SMTP_HOST": "", "SMTP_PORT": "587", "SMTP_USER": "", "SMTP_PASSWORD": "", "SMTP_FROM": "",
    # optional second mailbox (same SMTP host) that bid alert emails come from, e.g. opportunity@consist-na.com
    "ALERT_SMTP_USER": "", "ALERT_SMTP_PASSWORD": "", "ALERT_SMTP_FROM": "",
    # LinkedIn company page posting (app/linkedin.py; set up in Admin > Social posts)
    "GA_API_SECRET": "",  # GA4 Measurement Protocol secret for server-side sign_up / begin_checkout / purchase (app/ga.py)
    "LINKEDIN_WEBHOOK_URL": "", "LINKEDIN_CLIENT_ID": "", "LINKEDIN_CLIENT_SECRET": "", "LINKEDIN_ORG_ID": "", "LINKEDIN_PERSON_ID": "", "LINKEDIN_TOKEN": "", "LINKEDIN_REFRESH": "", "LINKEDIN_EXPIRES": "",
    # the key the weekly SEO routine sends as X-SEO-Key to read /admin/seo/report.json (Admin > Settings > SEO automation)
    "SEO_REPORT_KEY": "",
    # 1.7.25: Bid Catcher sends this as X-Bids-Key to pull public-record uploads (/admin/uploads/notices.json); classifier model
    "BIDS_INGEST_KEY": "", "UPLOAD_CLASSIFY_MODEL": "claude-haiku-5-5",
    # 1.7.47: Cloudflare Turnstile secret key for the sign-up check (site key and on/off are in Admin > Settings > General)
    "TURNSTILE_SECRET": "",
}


def stored():
    try:
        with open(INTEGRATIONS_FILE) as f:
            return {k: v for k, v in json.load(f).items() if k in INTEGRATION_FIELDS}
    except (OSError, ValueError):
        return {}


def save_stored(values):
    os.makedirs(DATA_DIR, exist_ok=True)
    cur = stored()
    for k, v in values.items():
        if k not in INTEGRATION_FIELDS:
            continue
        if v is None:
            cur.pop(k, None)
        else:
            cur[k] = v
    tmp = INTEGRATIONS_FILE + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(cur, f, indent=1)
    os.replace(tmp, INTEGRATIONS_FILE)
    reload()


def source(name):
    """Where a setting comes from: 'admin', 'env' or '' (not set)."""
    if stored().get(name, "") != "":
        return "admin"
    return "env" if env(name) else ""


def masked(name):
    v = globals().get(name) or ""
    return ("•" * 8 + str(v)[-4:]) if v else ""


def reload():
    g, st = globals(), stored()
    for k, default in INTEGRATION_FIELDS.items():
        v = st.get(k, "")
        g[k] = v if v != "" else env(k, default)
    g["SMTP_PORT"] = int(g["SMTP_PORT"] or 587)
    try:
        g["ANALYST_MAX_USD"] = float(g["ANALYST_MAX_USD"])
    except ValueError:
        g["ANALYST_MAX_USD"] = 0.80
    g["SMTP_FROM"] = g["SMTP_FROM"] or g["SMTP_USER"]
    g["ALERT_SMTP_FROM"] = g["ALERT_SMTP_FROM"] or g["ALERT_SMTP_USER"]
    # Without Stripe keys the site runs in demo billing mode: upgrades apply at once and are marked "demo".
    g["STRIPE_ENABLED"] = bool(g["STRIPE_SECRET_KEY"])


reload()

ADMIN_EMAIL = env("ADMIN_EMAIL")
ADMIN_PASSWORD = env("ADMIN_PASSWORD")
ALERTS_ENABLED = flag("ALERTS_ENABLED", "1")
