"""Funding and budget intelligence: what agencies plan, budget, authorize and award, before and after a bid.

Three collectors, all polite (robots.txt is honoured through bc.fetch / bc.render) and capped by BIDS_BUDGETS_MAX_USD:
- discover: Claude finds each agency's board meeting documents, capital plan, budget and contract-award pages (doc_source).
- watch: polls those pages, reads new documents (newest first, a few per page per run, so the backlog fills in over time)
  and extracts rail line items: capital projects, budget lines, board authorizations, intents to award and awards.
  Awards with a vendor also go to the award inventory (and bidders to bid_tab), so the analyst sees them.
- usaspending: Federal Transit Administration grants to the tracked agencies (open API, no Claude cost).
"""
import base64, datetime, json, os, re, urllib.parse

import bidcore as bc
import sources
from relevance import CATEGORIES, SUBSYSTEMS

MAX_USD = float(os.environ.get("BIDS_BUDGETS_MAX_USD", "3"))
DISCOVER_USD = float(os.environ.get("BIDS_BUDGETS_DISCOVER_USD", "0.8"))  # share of each run spent finding new pages
PER_PAGE = int(os.environ.get("BIDS_BUDGETS_DOCS_PER_PAGE", "3"))
MAX_PDF_MB = float(os.environ.get("BIDS_BUDGETS_MAX_PDF_MB", "4"))  # PDFs sent to Claude whole when pypdf is missing

SCHEMA = """
CREATE TABLE IF NOT EXISTS doc_source (      -- agency governance and finance pages we poll
  url TEXT PRIMARY KEY, agency_id TEXT, kind TEXT NOT NULL,  -- board_documents | capital_plan | budget | award_list | grant_list
  title TEXT, added TEXT, added_by TEXT, active INTEGER DEFAULT 1,
  last_hash TEXT, last_checked TEXT, last_changed TEXT, last_error TEXT);
CREATE TABLE IF NOT EXISTS doc_discovery (agency_id TEXT PRIMARY KEY, checked TEXT, found INTEGER, note TEXT);
CREATE TABLE IF NOT EXISTS doc_seen (        -- documents read (or skipped) from those pages
  url TEXT PRIMARY KEY, source_url TEXT, agency_id TEXT, kind TEXT, title TEXT, read_at TEXT, items INTEGER, cost_usd REAL, error TEXT);
CREATE TABLE IF NOT EXISTS budget_item (
  item_id INTEGER PRIMARY KEY, source_key TEXT UNIQUE, agency_id TEXT, operator_id TEXT, country TEXT,
  stage TEXT NOT NULL,   -- planned | budgeted | authorized | solicitation | intent_to_award | awarded | amended
  doc_kind TEXT, doc_title TEXT, doc_date TEXT, fiscal_year INTEGER,
  project TEXT NOT NULL, description TEXT, category TEXT, subsystems TEXT, qty INTEGER,
  amount REAL, currency TEXT, amount_usd REAL, amount_basis TEXT,  -- total | this_year | not_to_exceed | estimate | award
  funding_source TEXT, vendor TEXT, vendor_norm TEXT, ref_no TEXT, expected_date TEXT,
  notice_id INTEGER, award_id INTEGER, source_url TEXT, confidence TEXT, notes TEXT, first_seen TEXT);
CREATE INDEX IF NOT EXISTS budget_item_agency ON budget_item(agency_id);
CREATE TABLE IF NOT EXISTS funding_grant (   -- federal assistance awards from USAspending
  grant_id TEXT PRIMARY KEY, agency_id TEXT, recipient TEXT, program TEXT, cfda TEXT, amount_usd REAL,
  start_date TEXT, end_date TEXT, description TEXT, rail INTEGER, source_url TEXT, first_seen TEXT, last_seen TEXT);
"""

STAGES = ["planned", "budgeted", "authorized", "solicitation", "intent_to_award", "awarded", "amended"]
DOC_KINDS = ["board_documents", "capital_plan", "budget", "award_list", "grant_list"]
DOC_WORDS = re.compile(r"minute|agenda|board|committee|resolution|staff report|capital|budget|\bcip\b|improvement program|"
                       r"award|bid (tab|result)|procurement|contract|financial plan|\.pdf", re.I)
RAIL_WORDS = re.compile(r"rail ?car|railcar|rolling stock|locomotive|light rail vehicle|\blrv|subway car|streetcar|\bemu\b|\bdmu\b|"
                        r"overhaul|rebuild|midlife|mid-life|wheel|truck|bogie|propulsion|traction|hvac|door|brake|coupler|"
                        r"vehicle maintenance|fleet|signal|catenary|track|interlocking|cbtc|ptc", re.I)


def ensure(c):
    c.executescript(SCHEMA)
    c.commit()


# ---------------- discover ----------------

DISCOVER_SYSTEM = """You find the public web pages where a US or Canadian rail transit agency publishes its governance and finance documents, so a monitor can poll them for rail vehicle and rail system spending.

For each agency in the list, look for (official agency sites only, not news):
- board_documents: the page that lists board (and finance or operations committee) meeting agendas, minutes and staff reports
- capital_plan: the capital improvement program / capital plan / CIP page or document list
- budget: the operating and capital budget page (adopted budgets by fiscal year)
- award_list: a page listing contract awards, bid results or bid tabulations, if the agency has one
Call add_source once per page you confirmed by fetching it. Prefer the listing page over a single document, so new documents show up there. Skip pages behind a login. When an agency has nothing usable, call add_source with url "none" and say why in title.
Finish with one line per agency saying what you recorded."""

DISCOVER_TOOLS = [
    {"type": "web_search_20260209", "name": "web_search", "max_uses": 30},
    {"type": "web_fetch_20260209", "name": "web_fetch", "max_uses": 30},
    {"name": "add_source", "description": "Record one governance or finance page for an agency.",
     "input_schema": {"type": "object", "properties": {
         "agency_id": {"type": "string"}, "url": {"type": "string"}, "kind": {"type": "string", "enum": DOC_KINDS},
         "title": {"type": "string"}}, "required": ["agency_id", "url", "kind", "title"], "additionalProperties": False}, "strict": True},
]


def _agent(system, tools, first, handle, max_usd, max_turns=30, effort=None):
    """A small tool loop (like awards.run). handle(name, input) returns the tool result text. Returns (cost, final_text, status)."""
    import anthropic
    client = anthropic.Anthropic()
    messages = [{"role": "user", "content": first}]
    cost, final, status = 0.0, "", "done"
    for _ in range(max_turns):
        if cost >= max_usd:
            status = "over_budget"
            break
        resp = client.beta.messages.create(
            model=bc.MODEL, max_tokens=12000, system=system, tools=tools, messages=messages,
            output_config={"effort": effort or bc.EFFORT}, cache_control={"type": "ephemeral"},
            betas=["server-side-fallback-2026-07-01"], fallbacks="default")
        cost += bc.cost_of(resp.usage)
        messages.append({"role": "assistant", "content": resp.content})
        final = "".join(b.text for b in resp.content if b.type == "text") or final
        if resp.stop_reason == "pause_turn":
            continue
        if resp.stop_reason != "tool_use":
            break
        results = []
        for b in resp.content:
            if b.type == "tool_use":
                try:
                    results.append({"type": "tool_result", "tool_use_id": b.id, "content": handle(b.name, b.input)})
                except Exception as e:
                    results.append({"type": "tool_result", "tool_use_id": b.id, "content": str(e), "is_error": True})
        if cost >= max_usd * 0.8:
            results.append({"type": "text", "text": "Budget nearly used: stop and write your summary now."})
        messages.append({"role": "user", "content": results})
    return cost, final, status


def discover(c, max_usd=DISCOVER_USD, batch=6):
    """Finds doc pages for agencies not yet checked, rail operators first, batch by batch until the budget is used.
    Returns (pages added, cost)."""
    added, cost = 0, 0.0
    while cost < max_usd * 0.9:
        n, k, left = _discover_batch(c, max_usd - cost, batch)
        added, cost = added + n, cost + k
        if not left:
            break
    return added, cost


def _discover_batch(c, max_usd, batch):
    todo = c.execute("SELECT a.agency_id, a.agency, a.country, a.portal_url FROM agency a LEFT JOIN doc_discovery d USING (agency_id) "
                     "WHERE d.agency_id IS NULL ORDER BY (a.fleet_operator_ids IS NULL OR a.fleet_operator_ids = ''), a.agency_id "
                     f"LIMIT {int(batch)}").fetchall()
    if not todo or max_usd <= 0:
        return 0, 0.0, False
    ids = {r["agency_id"] for r in todo}
    added = {"n": 0}
    found = {i: 0 for i in ids}

    def handle(name, a):
        if name != "add_source":
            raise ValueError(f"unknown tool {name}")
        if a["agency_id"] not in ids:
            raise ValueError("agency_id must be one of the listed agencies")
        if a["url"] == "none":
            c.execute("INSERT OR REPLACE INTO doc_discovery (agency_id, checked, found, note) VALUES (?,?,?,?)",
                      (a["agency_id"], bc.now(), 0, a["title"][:300]))
            return "noted"
        if not a["url"].startswith("http"):
            raise ValueError("url must be absolute")
        cur = c.execute("INSERT OR IGNORE INTO doc_source (url, agency_id, kind, title, added, added_by) VALUES (?,?,?,?,?,?)",
                        (a["url"], a["agency_id"], a["kind"], a["title"][:200], bc.now(), "discover"))
        c.commit()
        added["n"] += cur.rowcount
        found[a["agency_id"]] += 1
        return "saved" if cur.rowcount else "already recorded"

    first = "Agencies (agency_id: name, country, procurement portal):\n" + "\n".join(
        f"{r['agency_id']}: {r['agency']} ({r['country']}) {r['portal_url'] or ''}" for r in todo)
    cost, final, status = _agent(DISCOVER_SYSTEM, DISCOVER_TOOLS, first, handle, max_usd)
    for i in ids:  # agencies the run reached are not asked again; the rest wait for the next run
        if found[i] or status == "done":
            c.execute("INSERT OR IGNORE INTO doc_discovery (agency_id, checked, found, note) VALUES (?,?,?,?)",
                      (i, bc.now(), found[i], None if found[i] else (final or "")[:300]))
    c.commit()
    bc.log(f"budgets discover: {added['n']} pages for {len(ids)} agencies, ${cost:.2f} ({status})")
    return added["n"], cost, True


# ---------------- watch ----------------

EXTRACT_SYSTEM = f"""You read a public document of a US or Canadian transit or rail agency (board agenda, minutes, staff report, capital plan, budget, or contract award list) and list every line item about rail: rail vehicles (purchase, overhaul, component work, parts, maintenance services, onboard systems), shops and yards, track, signals and train control, traction power, rail stations and rail engineering.

For each item give the stage it is at in this document:
- planned: in a capital plan or long-range program, not yet budgeted
- budgeted: appropriated in an adopted budget (say the fiscal year)
- authorized: the board authorized staff to solicit, or approved funding or a budget amendment for it
- solicitation: the document announces a bid or RFP for it
- intent_to_award: a recommendation or notice of intent to award to a named firm, not yet approved
- awarded: the board approved the award or the contract was executed
- amended: a change order, option exercise or contract modification
Record amounts exactly as stated, in the stated currency, and say in amount_basis whether it is the total project cost, this fiscal year's amount, a not-to-exceed value, an estimate, or the award value. Give the vendor only when the document names one, and the bidders with their prices when a tabulation is shown. Never guess: leave a field empty (0 for numbers) when the document does not state it. Dates as YYYY-MM-DD. Skip bus-only, paratransit-only and non-rail items.
Category values: {json.dumps(list(CATEGORIES))}. Subsystem values: {json.dumps(SUBSYSTEMS)}."""

EXTRACT_SCHEMA = {"type": "object", "properties": {
    "doc_date": {"type": "string"}, "doc_title": {"type": "string"},
    "items": {"type": "array", "items": {"type": "object", "properties": {
        "stage": {"type": "string", "enum": STAGES}, "project": {"type": "string"}, "description": {"type": "string"},
        "category": {"type": "string", "enum": list(CATEGORIES)}, "subsystems": {"type": "array", "items": {"type": "string", "enum": SUBSYSTEMS}},
        "fiscal_year": {"type": "integer"}, "qty": {"type": "integer"}, "amount": {"type": "number"},
        "currency": {"type": "string", "enum": ["USD", "CAD"]},
        "amount_basis": {"type": "string", "enum": ["total", "this_year", "not_to_exceed", "estimate", "award", ""]},
        "funding_source": {"type": "string"}, "vendor": {"type": "string"}, "ref_no": {"type": "string"},
        "expected_date": {"type": "string"}, "term_months": {"type": "integer"},
        "bidders": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "amount": {"type": "number"}},
                                                "required": ["name", "amount"], "additionalProperties": False}}},
        "required": ["stage", "project", "description", "category", "subsystems", "fiscal_year", "qty", "amount", "currency",
                     "amount_basis", "funding_source", "vendor", "ref_no", "expected_date", "term_months", "bidders"],
        "additionalProperties": False}}},
    "required": ["doc_date", "doc_title", "items"], "additionalProperties": False}


def _links(raw_html, base):
    """(absolute url, link text) for every anchor on a page, in page order."""
    out = []
    for m in re.finditer(r"<a\b[^>]*href=[\"']([^\"'#]+)[\"'][^>]*>(.*?)</a>", raw_html, re.I | re.S):
        text = re.sub(r"<[^>]+>|\s+", " ", m.group(2)).strip()
        out.append((urllib.parse.urljoin(base, m.group(1).strip()), text))
    return out


def _page_html(url):
    host = urllib.parse.urlparse(url).netloc.lower()
    if not any(host == h or host.endswith("." + h) for h in sources.JS_HOSTS):
        raw, cs, final = bc.fetch(url)
        html = raw.decode(cs, "replace")
        if len(sources.page_text(raw, cs)) >= 400 or not bc.RENDER_URL:
            return html, final
    return bc.render(url)


def _pdf_text(raw):
    """Text of the rail-relevant pages of a PDF (with a page of context either side), or None without pypdf."""
    try:
        import io
        import pypdf
    except ImportError:
        return None
    pages = [(p.extract_text() or "") for p in pypdf.PdfReader(io.BytesIO(raw)).pages]
    keep = set()
    for i, t in enumerate(pages):
        if RAIL_WORDS.search(t) and re.search(r"\$\s?\d|\d{1,3}(,\d{3}){2,}", t):
            keep |= {i - 1, i, i + 1}
    if len(pages) <= 12:
        keep = set(range(len(pages)))
    return "\n".join(f"[page {i + 1}]\n{pages[i]}" for i in sorted(k for k in keep if 0 <= k < len(pages)))[:80000]


def _claude_pdf_json(raw, prompt):
    """Whole-PDF read when pypdf is not installed: Claude reads the file directly."""
    import anthropic
    resp = anthropic.Anthropic().beta.messages.create(
        model=bc.MODEL, max_tokens=8000, system=EXTRACT_SYSTEM,
        messages=[{"role": "user", "content": [
            {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": base64.b64encode(raw).decode()}},
            {"type": "text", "text": prompt}]}],
        output_config={"effort": bc.EFFORT, "format": {"type": "json_schema", "schema": EXTRACT_SCHEMA}},
        betas=["server-side-fallback-2026-07-01"], fallbacks="default")
    text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
    return json.loads(text), bc.cost_of(resp.usage)


def read_doc(c, url, src, suppliers):
    """Reads one document and stores its items. Returns (items, cost)."""
    raw, cs, final = bc.fetch(url, timeout=120)
    prompt = f"Agency: {src['agency_id']}\nDocument: {final}\nListed on: {src['url']} ({src['kind']})\n"
    if raw[:5] == b"%PDF-":
        text = _pdf_text(raw)
        if text is None:
            if len(raw) > MAX_PDF_MB * 1e6:
                raise RuntimeError(f"PDF of {len(raw) / 1e6:.0f} MB is too large to read without pypdf")
            out, cost = _claude_pdf_json(raw, prompt + "List the rail line items in the attached document.")
            return store(c, out, src, final, suppliers), cost
    else:
        text = sources.page_text(raw, cs)[:80000]
    if not RAIL_WORDS.search(text or ""):
        return 0, 0.0
    out, cost = bc.claude_json(EXTRACT_SYSTEM, prompt + f"Text:\n{text}", EXTRACT_SCHEMA)
    return store(c, out, src, final, suppliers), cost


def store(c, out, src, url, suppliers):
    agency = c.execute("SELECT country, fleet_operator_ids FROM agency WHERE agency_id=?", (src["agency_id"],)).fetchone()
    country = agency["country"] if agency else "US"
    op = ((agency["fleet_operator_ids"] or "").split(";") if agency else [""])[0] or None
    n = 0
    for it in out["items"]:
        cur = it.get("currency") or ("CAD" if country == "CA" else "USD")
        ref = it["ref_no"] or re.sub(r"\W+", "-", it["project"].lower())[:70]
        key = f"doc:{src['agency_id']}:{it['stage']}:{ref}:{it['fiscal_year'] or ''}:{it['amount'] or ''}"
        row = {"source_key": key, "agency_id": src["agency_id"], "operator_id": op, "country": country, "stage": it["stage"],
               "doc_kind": src["kind"], "doc_title": out.get("doc_title") or None, "doc_date": sources.iso(out.get("doc_date")) or None,
               "fiscal_year": it["fiscal_year"] or None, "project": it["project"], "description": it["description"] or None,
               "category": it["category"], "subsystems": ";".join(it["subsystems"]) or None, "qty": it["qty"] or None,
               "amount": it["amount"] or None, "currency": cur, "amount_usd": bc.to_usd(it["amount"] or None, cur),
               "amount_basis": it["amount_basis"] or None, "funding_source": it["funding_source"] or None,
               "vendor": it["vendor"] or None, "vendor_norm": sources.norm_vendor(it["vendor"]) if it["vendor"] else None,
               "ref_no": it["ref_no"] or None, "expected_date": sources.iso(it["expected_date"]) or None,
               "source_url": url, "confidence": "A", "first_seen": bc.now()}
        cols = [k for k, v in row.items() if v is not None]
        r = c.execute(f"INSERT OR IGNORE INTO budget_item ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", [row[k] for k in cols])
        n += r.rowcount
        if it["stage"] == "awarded" and it["vendor"]:
            bids = [b for b in it["bidders"] if b.get("name")]
            amounts = [b["amount"] for b in bids if b.get("amount")]
            a = {"source_key": f"doc-award:{src['agency_id']}:{it['ref_no'] or it['project'][:60]}:{it['vendor']}", "source": "board_docs",
                 "agency_id": src["agency_id"], "country": country, "ref_no": it["ref_no"] or None, "title": it["project"],
                 "vendor": it["vendor"], "amount": it["amount"] or None, "currency": cur, "award_date": row["doc_date"],
                 "term_months": it["term_months"] or None, "n_bidders": len(bids) or None,
                 "low_bid": min(amounts) if amounts else None, "high_bid": max(amounts) if amounts else None,
                 "category": it["category"], "subsystems": row["subsystems"], "operator_id": op, "relevance": 80,
                 "source_url": url, "confidence": "A", "notes": it["description"][:500] or None}
            if sources.add_award(c, a, suppliers):
                aid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                c.execute("UPDATE budget_item SET award_id=? WHERE source_key=?", (aid, key))
                for rank, b in enumerate(sorted(bids, key=lambda b: b.get("amount") or 9e18), 1):
                    c.execute("INSERT INTO bid_tab (award_id, bidder, bidder_norm, amount, rank, winner, source_url) VALUES (?,?,?,?,?,?,?)",
                              (aid, b["name"], sources.norm_vendor(b["name"]), b.get("amount") or None, rank,
                               int(sources.norm_vendor(b["name"]) == sources.norm_vendor(it["vendor"])), url))
    c.commit()
    return n


def watch(c, max_usd, per_page=None):
    """Polls every doc_source page; reads up to PER_PAGE unread documents from each, newest (top of page) first."""
    found, cost, docs = 0, 0.0, 0
    suppliers = sources.supplier_ids()
    for src in c.execute("SELECT * FROM doc_source WHERE active=1 ORDER BY coalesce(last_checked, '')").fetchall():
        if cost >= max_usd:
            bc.log("budgets watch: budget reached; the remaining pages wait for the next run")
            break
        try:
            html, final = _page_html(src["url"])
        except Exception as e:
            c.execute("UPDATE doc_source SET last_checked=?, last_error=? WHERE url=?", (bc.now(), str(e)[:300], src["url"]))
            c.commit()
            continue
        h = bc.sha(html)
        c.execute("UPDATE doc_source SET last_checked=?, last_error=NULL, last_hash=?" + (", last_changed=?" if h != src["last_hash"] else "") +
                  " WHERE url=?", (bc.now(), h, bc.now(), src["url"]) if h != src["last_hash"] else (bc.now(), h, src["url"]))
        c.commit()
        host = urllib.parse.urlparse(final).netloc
        cands, seen_here = [], set()
        for u, text in _links(html, final):
            if u in seen_here or urllib.parse.urlparse(u).netloc != host and not u.lower().endswith(".pdf"):
                continue
            seen_here.add(u)
            if DOC_WORDS.search(u) or DOC_WORDS.search(text):
                cands.append((u, text))
        if src["kind"] in ("capital_plan", "budget", "award_list") and not cands:
            cands = [(final, src["title"] or "")]  # the page itself is the document
        unread = [x for x in cands if not c.execute("SELECT 1 FROM doc_seen WHERE url=?", (x[0],)).fetchone()]
        for u, text in unread[:per_page or PER_PAGE]:
            if cost >= max_usd:
                break
            try:
                n, k = read_doc(c, u, src, suppliers)
                err = None
            except PermissionError as e:
                bc.log(f"budgets doc {u}: {e}")  # robots.txt says no: not recorded, so it is tried again if that changes
                continue
            except Exception as e:
                n, k, err = 0, 0.0, str(e)[:300]
            cost += k
            found += n
            docs += 1
            c.execute("INSERT OR REPLACE INTO doc_seen (url, source_url, agency_id, kind, title, read_at, items, cost_usd, error) "
                      "VALUES (?,?,?,?,?,?,?,?,?)", (u, src["url"], src["agency_id"], src["kind"], text[:200], bc.now(), n, round(k, 4), err))
            c.commit()
    return docs, found, cost


# ---------------- USAspending (FTA grants) ----------------

USA_URL = "https://api.usaspending.gov/api/v2/search/spending_by_award/"
USA_KEYWORDS = ["rail car", "railcar", "rail vehicle", "light rail", "commuter rail", "locomotive", "rolling stock", "subway",
                "streetcar", "overhaul", "heavy rail", "rail fleet"]
USA_FIELDS = ["Award ID", "Recipient Name", "Award Amount", "Description", "Start Date", "End Date", "CFDA Number", "generated_internal_id"]
RAIL_GRANT = re.compile(r"rail|locomotive|rolling stock|subway|streetcar|lrv|railcar|catenary|metro", re.I)


def _agency_patterns(c):
    """agency_id -> lower-case name patterns for matching recipient legal names."""
    pats = {}
    for r in c.execute("SELECT agency_id, agency FROM agency"):
        name = (r["agency"] or "").lower()
        full = re.sub(r"\s*\(.*?\)", "", name).strip()
        p = [x for x in {full, re.sub(r"^the ", "", full)} if len(x) >= 8]
        if p:
            pats[r["agency_id"]] = p
    return pats


def usaspending(c, years=3, pages=10):
    """FTA grants (assistance types 02-05) with rail keywords; recipients matched to tracked agencies. Returns (seen, new)."""
    end = datetime.date.today()
    body = {"filters": {"award_type_codes": ["02", "03", "04", "05"],
                        "agencies": [{"type": "awarding", "tier": "subtier", "name": "Federal Transit Administration"}],
                        "time_period": [{"start_date": (end - datetime.timedelta(days=365 * years)).isoformat(), "end_date": end.isoformat()}],
                        "keywords": USA_KEYWORDS},
            "fields": USA_FIELDS, "limit": 100, "sort": "Award Amount", "order": "desc"}
    pats = _agency_patterns(c)
    seen = new = 0
    for page in range(1, pages + 1):
        body["page"] = page
        raw, _, _ = bc.fetch(USA_URL, timeout=90, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"},
                             check_robots=False)  # a public API, not a crawled page
        out = json.loads(raw)
        for r in out.get("results") or []:
            seen += 1
            aid = sources.match_agency(c, r.get("Recipient Name"), pats)
            if not aid:
                continue
            gid = r.get("generated_internal_id") or r.get("Award ID")
            cur = c.execute("INSERT INTO funding_grant (grant_id, agency_id, recipient, program, cfda, amount_usd, start_date, end_date, "
                            "description, rail, source_url, first_seen, last_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) "
                            "ON CONFLICT(grant_id) DO UPDATE SET amount_usd=excluded.amount_usd, end_date=excluded.end_date, "
                            "description=excluded.description, last_seen=excluded.last_seen",
                            (gid, aid, r.get("Recipient Name"), "FTA " + (r.get("Award ID") or ""), r.get("CFDA Number"),
                             r.get("Award Amount"), r.get("Start Date"), r.get("End Date"), (r.get("Description") or "")[:1000],
                             int(bool(RAIL_GRANT.search(r.get("Description") or ""))),
                             f"https://www.usaspending.gov/award/{urllib.parse.quote(str(gid))}", bc.now(), bc.now()))
            new += cur.rowcount if cur.lastrowid else 0
        c.commit()
        if not (out.get("page_metadata") or {}).get("hasNext"):
            break
    return seen, new


# ---------------- link ----------------

def _tokens(s):
    return {w for w in re.findall(r"[a-z0-9]{4,}", (s or "").lower())} - {"rail", "transit", "contract", "services", "agreement", "authority"}


def link(c):
    """Ties budget items to the tracked bid (same agency, ref no. or title overlap) and to the recorded award."""
    notices = {}
    for n in c.execute("SELECT notice_id, agency_id, ref_no, title FROM notice WHERE coalesce(notice_type,'') != 'award' AND agency_id IS NOT NULL"):
        notices.setdefault(n["agency_id"], []).append(n)
    for b in c.execute("SELECT item_id, agency_id, ref_no, project FROM budget_item WHERE notice_id IS NULL").fetchall():
        best, score = None, 0.0
        t = _tokens(b["project"])
        for n in notices.get(b["agency_id"], []):
            if b["ref_no"] and n["ref_no"] and b["ref_no"].lower() == n["ref_no"].lower():
                best, score = n["notice_id"], 1.0
                break
            u = _tokens(n["title"])
            s = len(t & u) / len(t | u) if t and u else 0
            if s > score:
                best, score = n["notice_id"], s
        if best and score >= 0.45:
            c.execute("UPDATE budget_item SET notice_id=? WHERE item_id=?", (best, b["item_id"]))
    c.execute("UPDATE budget_item SET award_id = (SELECT a.award_id FROM award a WHERE a.notice_id = budget_item.notice_id LIMIT 1) "
              "WHERE award_id IS NULL AND notice_id IS NOT NULL")
    c.commit()


def run(c, max_usd=MAX_USD, discover_usd=DISCOVER_USD, per_page=None):
    ensure(c)
    started, msgs, cost = bc.now(), [], 0.0
    if bc.api_key():
        try:
            n, k = discover(c, min(discover_usd, max_usd))
            cost += k
            msgs.append(f"discover: {n} new pages")
        except Exception as e:
            msgs.append(f"discover: FAILED {e}")
        try:
            docs, items, k = watch(c, max(0.0, max_usd - cost), per_page)
            cost += k
            msgs.append(f"documents: {docs} read, {items} items")
        except Exception as e:
            msgs.append(f"documents: FAILED {e}")
        try:  # whatever is left of this same cap: Claude reads the most rail-heavy board agendas the meetings scanner found
            import meetings
            docs, items, k = meetings.claude_pass(c, max(0.0, max_usd - cost))
            cost += k
            msgs.append(f"meeting documents: {docs} read, {items} items")
        except Exception as e:
            msgs.append(f"meeting documents: FAILED {e}")
    else:
        msgs.append("no Anthropic key: discovery and document reading skipped")
    try:
        s, n = usaspending(c)
        msgs.append(f"usaspending: {s} seen, {n} new")
    except Exception as e:
        msgs.append(f"usaspending: FAILED {e}")
    link(c)
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (started, bc.now(), "budgets", "done", None, None, round(cost, 4), "; ".join(msgs)))
    c.commit()
    bc.log("budgets: " + "; ".join(msgs) + f"; ${cost:.2f}")
    return "; ".join(msgs), cost
