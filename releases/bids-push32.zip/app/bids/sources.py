"""Collectors: CanadaBuys and SEAO open data, and public agency pages (page watch).

Portal alert emails are handled in mailbox.py. Nothing here logs in anywhere or fetches pages behind a login.
"""
import csv, datetime, html.parser, io, json, os, re, sqlite3, urllib.parse

import bidcore as bc

# ---------------------------------------------------------------- shared upserts

SUFFIX = re.compile(r"[,.]?\s+(inc|incorporated|llc|l\.l\.c|ltd|limited|corp|corporation|co|company|ltée|ltee|s\.a|sa|gmbh|ag|lp|llp|ulc|plc)\.?$", re.I)


def norm_vendor(name):
    if not name:
        return None
    n = re.sub(r"\s+", " ", name).strip().strip(".,")
    for _ in range(2):
        n = SUFFIX.sub("", n).strip()
    return n.title() if n.isupper() else n


def supplier_ids():
    """aliases from fleet.db's supplier register -> supplier_id"""
    try:
        c = sqlite3.connect(f"file:{bc.FLEET_DB}?mode=ro", uri=True)
        out = {}
        for sid, name, aliases in c.execute("SELECT supplier_id, name, aliases FROM supplier"):
            for a in [name] + (aliases or "").split(";"):
                if a and a.strip():
                    out[a.strip().lower()] = sid
        c.close()
        return out
    except Exception:
        return {}


MONTHS = {m: i for i, ms in enumerate([("jan", "janv"), ("feb", "fév", "fev"), ("mar", "mars"), ("apr", "avr"), ("may", "mai"), ("jun", "juin"),
                                         ("jul", "juil"), ("aug", "aoû", "aou"), ("sep", "sept"), ("oct",), ("nov",), ("dec", "déc")], 1) for m in ms}
_MON = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|janv|f[ée]v|mars|avr|mai|juin|juil|ao[ûu]|d[ée]c)[a-zéû]*\.?"
_CUE = r"(?:clos(?:ing|es?|ed)|due|deadline|submissions?|proposals? due|bids? due|responses? due|opening|date limite|fermeture|ouverture)"
CLOSE_RX = [
    re.compile(_CUE + r"[^.;\n]{0,40}?\b(\d{4})-(\d{2})-(\d{2})", re.I),
    re.compile(_CUE + r"[^.;\n]{0,40}?\b(\d{1,2})/(\d{1,2})/(\d{4})", re.I),
    re.compile(_CUE + r"[^.;\n]{0,40}?\b" + _MON + r"\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})", re.I),
    re.compile(_CUE + r"[^.;\n]{0,40}?\b(\d{1,2})(?:er)?\s+" + _MON + r"\s+(\d{4})", re.I),
    re.compile(_CUE + r"[^.;\n]{0,40}?\b" + _MON + r"\s+(\d{4})\b", re.I)]


def closing_from_text(text, published=None):
    """A closing / due date stated in a notice's text, as ISO, for when the portal's closing field is blank. "closing Feb 2027"
    (month only) gives the last day of that month. Dates before the publish date are ignored."""
    import calendar
    t = text or ""
    for i, rx in enumerate(CLOSE_RX):
        for m in rx.finditer(t):
            g = m.groups()
            try:
                if i == 0:
                    y, mo, d = int(g[0]), int(g[1]), int(g[2])
                elif i == 1:
                    mo, d, y = int(g[0]), int(g[1]), int(g[2])
                elif i == 2:
                    mo, d, y = MONTHS.get(g[0].lower().rstrip(".")[:4]) or MONTHS.get(g[0].lower()[:3]), int(g[1]), int(g[2])
                elif i == 3:
                    d, mo, y = int(g[0]), MONTHS.get(g[1].lower().rstrip(".")[:4]) or MONTHS.get(g[1].lower()[:3]), int(g[2])
                else:
                    mo, y = MONTHS.get(g[0].lower().rstrip(".")[:4]) or MONTHS.get(g[0].lower()[:3]), int(g[1])
                    d = calendar.monthrange(y, mo)[1] if mo else None
                iso_d = datetime.date(y, mo, d).isoformat()
            except (TypeError, ValueError):
                continue
            if 2000 <= y <= 2100 and (not published or iso_d >= str(published)[:10]):
                return iso_d
    return None


def closing_backfill(c):
    """Fills notice.closing from the description or the review summary where the portal left it blank. Returns rows filled."""
    n = 0
    for r in c.execute("SELECT notice_id, published, description, summary, title FROM notice WHERE closing IS NULL "
                       "AND coalesce(notice_type,'') NOT IN ('award','cancelled')").fetchall():
        d = closing_from_text(f"{r['title'] or ''}. {r['description'] or ''}. {r['summary'] or ''}", r["published"])
        if d:
            c.execute("UPDATE notice SET closing=? WHERE notice_id=? AND closing IS NULL", (d, r["notice_id"]))
            n += 1
    c.commit()
    return n


HISTORY = False  # set by history.py: backfilled notices are never alerted and never sent to the Claude review


def add_notice(c, n):
    """Inserts a notice (dict with source, source_key...). Returns True when new."""
    t = bc.now()
    if HISTORY:
        n = dict(n, notified=t, reviewed="history")
    if not n.get("closing") and n.get("notice_type") not in ("award", "cancelled"):
        n = dict(n, closing=closing_from_text(f"{n.get('title') or ''}. {n.get('description') or ''}", n.get("published")))
    cur = c.execute("SELECT notice_id FROM notice WHERE source_key=?", (n["source_key"],)).fetchone()
    if not cur and n.get("source") in ("mail", "page") and n.get("agency_id") and n.get("title"):
        # portals re-send the same opportunity (daily digests, "changes" emails) with a slightly different ref or title
        slug = re.sub(r"[^a-z0-9]+", "", n["title"].lower())[:60]
        for r in c.execute("SELECT notice_id, title, closing FROM notice WHERE agency_id=? AND source=? AND coalesce(notice_type,'')=? "
                           "AND first_seen >= ?", (n["agency_id"], n["source"], n.get("notice_type") or "",
                                                   (datetime.datetime.utcnow() - datetime.timedelta(days=30)).isoformat())).fetchall():
            if re.sub(r"[^a-z0-9]+", "", (r["title"] or "").lower())[:60] == slug and (not n.get("closing") or not r["closing"] or r["closing"] == n["closing"]):
                cur = r
                break
    if cur:
        c.execute("UPDATE notice SET last_seen=? WHERE notice_id=?", (t, cur[0]))
        return False
    cols = [k for k in ("source", "source_key", "agency_id", "buyer", "country", "ref_no", "title", "description", "notice_type",
                        "published", "closing", "url", "value_est", "currency", "raw_json", "notified", "reviewed") if n.get(k) is not None]
    c.execute(f"INSERT INTO notice ({','.join(cols)}, first_seen, last_seen) VALUES ({','.join('?' * len(cols))}, ?, ?)",
              [n[k] for k in cols] + [t, t])
    return True


def add_award(c, a, suppliers=None):
    if a.get("source_key") and c.execute("SELECT 1 FROM award WHERE source_key=?", (a["source_key"],)).fetchone():
        return False
    a = dict(a)
    import oncall  # on-call / IDIQ / task-order fields: contract type, term, options, ceiling, end dates
    oncall.ensure(c)
    oncall.enrich_award(a)
    a["vendor_norm"] = norm_vendor(a.get("vendor"))
    if suppliers and a["vendor_norm"] and not a.get("supplier_id"):
        v = a["vendor_norm"].lower()
        a["supplier_id"] = suppliers.get(v) or suppliers.get((a.get("vendor") or "").lower()) or next(
            (sid for alias, sid in sorted(suppliers.items(), key=lambda x: -len(x[0])) if len(alias) >= 4 and re.match(re.escape(alias) + r"\b", v)), None)
    a["amount_usd"] = bc.to_usd(a.get("amount"), a.get("currency"))
    import taxonomy
    a["subsystems"] = taxonomy.merge(a.get("subsystems"), f"{a.get('title') or ''} {a.get('notes') or ''}") or None
    if a.get("ref_no") and not a.get("notice_id"):
        r = c.execute("SELECT notice_id, category, subsystems, operator_id FROM notice WHERE ref_no=? AND notice_type!='award' "
                      "AND (agency_id IS ? OR buyer IS ?) LIMIT 1", (a["ref_no"], a.get("agency_id"), a.get("buyer"))).fetchone()
        if r:
            a["notice_id"] = r["notice_id"]
            for k in ("category", "subsystems", "operator_id"):
                a.setdefault(k, r[k])
    cols = [k for k in ("source_key", "notice_id", "agency_id", "buyer", "country", "ref_no", "title", "vendor", "vendor_norm",
                        "supplier_id", "amount", "currency", "amount_usd", "award_date", "term_months", "n_bidders", "low_bid",
                        "high_bid", "category", "subsystems", "operator_id", "procurement_rowid", "relevance", "source", "source_url",
                        "confidence", "notes") + tuple(oncall.AWARD_COLS) if a.get(k) is not None]
    c.execute(f"INSERT INTO award ({','.join(cols)}, first_seen) VALUES ({','.join('?' * len(cols))}, ?)",
              [a[k] for k in cols] + [bc.now()])
    return True


def match_agency(c, buyer, patterns):
    b = (buyer or "").lower()
    for agency_id, pats in patterns.items():
        if any(p in b for p in pats):
            return agency_id
    return None


def iso(d):
    if not d:
        return None
    d = str(d).strip()
    m = re.match(r"(\d{4}-\d{2}-\d{2})(?:[T ](\d{2}:\d{2}))?", d)
    if m:
        return m.group(1) + (f" {m.group(2)}" if m.group(2) else "")
    for fmt in ("%m/%d/%Y", "%d/%m/%Y", "%B %d, %Y", "%b %d, %Y", "%Y/%m/%d"):
        try:
            return datetime.datetime.strptime(d[:20].strip(), fmt).date().isoformat()
        except ValueError:
            pass
    return d[:25]


# ---------------------------------------------------------------- CanadaBuys (Open Government Licence - Canada)

CKAN_CA = "https://open.canada.ca/data/api/3/action/"
CANADABUYS_SETS = {"tender": "6abd20d4-7a1c-4b38-baa2-9525d0bb2fd2"}  # award set is found by search


def ckan_resources(base, dataset_id=None, query=None):
    if dataset_id:
        body, _, _ = bc.fetch(f"{base}package_show?id={dataset_id}", check_robots=False)
        return json.loads(body)["result"]["resources"]
    body, _, _ = bc.fetch(f"{base}package_search?q={query.replace(' ', '+')}&rows=5", check_robots=False)
    res = json.loads(body)["result"]["results"]
    return res[0]["resources"] if res else []


def col(row, *needles):
    """value of the first column whose name contains every needle (CanadaBuys headers are bilingual and long)"""
    for k, v in row.items():
        kl = (k or "").lower()
        if all(n in kl for n in needles) and v not in (None, ""):
            return v
    return None


def canadabuys(c):
    found = new = 0
    files, awards = [], []
    for r in ckan_resources(CKAN_CA, CANADABUYS_SETS["tender"]):
        u = r.get("url", "")
        if re.search(r"(new|open)TenderNotice", u, re.I) and u.lower().endswith(".csv"):
            files.append(("tender", u))
    try:
        for r in ckan_resources(CKAN_CA, query="CanadaBuys award notices"):
            u = r.get("url", "")
            if re.search(r"award", u, re.I) and u.lower().endswith(".csv") and not re.search(r"complete|all", u, re.I):
                awards.append(u)
        # one file per fiscal year back to 2009: read only the newest, the NAS has 2 GB of memory
        if awards:
            files.append(("award", max(awards, key=lambda u: max(re.findall(r"20\d\d", u) or ["0"]))))
    except Exception as e:
        bc.log(f"canadabuys: award dataset not found ({e})")
    suppliers = supplier_ids()
    for kind, u in files:
        try:
            path = bc.download(u)
        except Exception as e:  # one refused file (CanadaBuys briefly 403s during refreshes) shouldn't stop the others
            bc.log(f"canadabuys: {kind} file {u} failed: {e}")
            continue
        try:
            found, new = _canadabuys_file(c, kind, u, path, suppliers, found, new)
        finally:
            os.remove(path)
        c.commit()
    return found, new


def _canadabuys_file(c, kind, u, path, suppliers, found, new):
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
        for row in csv.DictReader(f):
            title = col(row, "title", "eng") or col(row, "title")
            ref = col(row, "referencenumber") or col(row, "solicitationnumber")
            buyer = col(row, "contractingentityname", "eng") or col(row, "contractingentity") or col(row, "endusername")
            desc = col(row, "tenderdescription", "eng") or col(row, "description", "eng") or ""
            ntype = col(row, "noticetype", "eng") or col(row, "noticetype") or col(row, "procurementmethod", "eng")
            if ntype and kind == "tender":
                desc = f"{ntype}. {desc}"  # "Letter of Interest (LOI)/Request for Information (RFI)" marks an early-stage notice
            unspsc = col(row, "unspsc") or ""
            if not title or not ref:
                continue
            found += 1
            text = f"{title} {desc} {unspsc}"
            if kind == "tender":
                if not re.search(r"rail|train|locomot|rolling|tram|metro|via\b|transit", text, re.I):
                    continue  # the federal file is large; keep only transport-related rows
                new += add_notice(c, {"source": "canadabuys", "source_key": f"canadabuys:{ref}", "buyer": buyer, "country": "CA",
                                      "ref_no": ref, "title": title, "description": desc[:4000], "notice_type": "tender",
                                      "published": iso(col(row, "publicationdate")), "closing": iso(col(row, "closingdate")),
                                      "url": col(row, "noticeurl", "eng") or col(row, "url"),
                                      "agency_id": "VIA" if re.search(r"via rail", buyer or "", re.I) else "FEDERAL_CA"})
            else:
                if not re.search(r"rail|train|locomot|rolling|tram|via\b", text, re.I):
                    continue
                amount = col(row, "contractamount") or col(row, "totalcontractvalue") or col(row, "value")
                try:
                    amount = float(str(amount).replace(",", "").replace("$", "")) if amount else None
                except ValueError:
                    amount = None
                via = "VIA" if re.search(r"via rail", buyer or "", re.I) else "FEDERAL_CA"
                add_notice(c, {"source": "canadabuys", "source_key": f"canadabuys-award:{ref}", "agency_id": via, "buyer": buyer,
                               "country": "CA", "ref_no": ref, "title": title, "description": desc[:4000], "notice_type": "award",
                               "published": iso(col(row, "awarddate") or col(row, "contractawarddate"))})
                new += add_award(c, {"source_key": f"canadabuys-award:{ref}:{col(row, 'suppliername') or ''}", "source": "canadabuys",
                                     "agency_id": via, "buyer": buyer, "country": "CA", "ref_no": ref, "title": title,
                                     "vendor": col(row, "suppliername", "eng") or col(row, "suppliername") or col(row, "supplier"),
                                     "amount": amount, "currency": "CAD", "award_date": iso(col(row, "awarddate") or col(row, "contractawarddate")),
                                     "start_date": (iso(col(row, "contractstart") or col(row, "startdate")) or "")[:10] or None,
                                     "end_date": (iso(col(row, "contractend") or col(row, "enddate") or col(row, "expirydate")) or "")[:10] or None,
                                     "notes": " ".join(x for x in (col(row, "procurementmethod", "eng") or col(row, "procurementmethod"),
                                                                   col(row, "instrumenttype", "eng") or col(row, "agreementtype", "eng")) if x) or None,
                                     "source_url": col(row, "noticeurl", "eng") or u, "confidence": "A"}, suppliers)
    return found, new


# ---------------------------------------------------------------- SEAO, Québec (CC-BY 4.0)

CKAN_QC = "https://www.donneesquebec.ca/recherche/api/3/action/"
SEAO_SET = "systeme-electronique-dappel-doffres-seao"
SEAO_BUYERS = {"STM": ["société de transport de montréal", "societe de transport de montreal"],
               "EXO": ["exo", "réseau de transport métropolitain", "reseau de transport metropolitain"],
               "ARTM": ["autorité régionale de transport métropolitain", "autorite regionale de transport metropolitain", "cdpq infra", "réseau express métropolitain"],
               "RTC_QC": ["réseau de transport de la capitale", "reseau de transport de la capitale", "ville de québec", "ville de quebec"]}


def seao(c, weeks=2):
    res = [r for r in ckan_resources(CKAN_QC, SEAO_SET) if re.search(r"hebdo_(\d{8})_(\d{8})", r.get("url", "") + r.get("name", ""))]
    res.sort(key=lambda r: re.search(r"hebdo_(\d{8})_(\d{8})", r.get("url", "") + r.get("name", "")).group(2))
    done = {r[0] for r in c.execute("SELECT url FROM page_watch WHERE kind='seao'")}
    found = new = skipped_big = 0
    suppliers = supplier_ids()
    for r in res[-weeks:]:
        u = r["url"]
        if u in done:
            continue
        path = bc.download(u, timeout=300)
        try:
            mb = os.path.getsize(path) / 1e6
            # the history backfill runs alone, so it may parse bigger weekly files than the daily scan
            cap = float(os.environ.get("BIDS_SEAO_MAX_MB", "60" if HISTORY else "25"))
            if mb > cap:  # skip this week, not the rest; it stays un-done so a later run with a higher cap picks it up
                bc.log(f"seao: {u} is {mb:.0f} MB, over BIDS_SEAO_MAX_MB={cap:.0f}; skipped")
                skipped_big += 1
                continue
            with open(path, encoding="utf-8-sig") as f:
                data = json.load(f)
        finally:
            os.remove(path)
        for rel in data.get("releases", []):
            buyer = (rel.get("buyer") or {}).get("name") or ""
            agency = match_agency(c, buyer, SEAO_BUYERS)
            tender = rel.get("tender") or {}
            title = tender.get("title") or ""
            if not agency and not re.search(r"ferroviaire|matériel roulant|voitures? de métro|tramway|locomotive", title, re.I):
                continue
            found += 1
            ref = tender.get("id") or rel.get("ocid")
            url = next((d.get("url") for d in tender.get("documents", []) if d.get("url")), None) or "https://seao.gouv.qc.ca/"
            new += add_notice(c, {"source": "seao", "source_key": f"seao:{rel.get('ocid')}:{rel.get('id')}", "agency_id": agency,
                                  "buyer": buyer, "country": "CA", "ref_no": ref, "title": title,
                                  "description": (tender.get("description") or "")[:4000],
                                  "notice_type": "award" if rel.get("awards") else "tender",
                                  "published": iso(rel.get("date")), "closing": iso((tender.get("tenderPeriod") or {}).get("endDate")),
                                  "url": url, "value_est": (tender.get("value") or {}).get("amount"), "currency": "CAD",
                                  "raw_json": json.dumps(rel, ensure_ascii=False)[:20000]})
            # SEAO publishes every bidder and its price (tender.tenderers + bids); keep them for win statistics
            names = {t.get("id"): t.get("name") for t in tender.get("tenderers") or []}
            bids = [(names.get(b.get("id")) or b.get("id"), b.get("value")) for b in rel.get("bids") or []]
            amounts = [v for _, v in bids if isinstance(v, (int, float)) and v > 0]
            nb = tender.get("numberOfTenderers") or len(names) or None
            for aw in rel.get("awards") or []:
                for sup in aw.get("suppliers") or [{}]:
                    v = aw.get("value") or {}
                    key = f"seao-award:{rel.get('ocid')}:{aw.get('id')}:{sup.get('name')}"
                    if ref and c.execute("SELECT 1 FROM award WHERE source='seao' AND ref_no=? AND buyer IS ? AND vendor IS ? AND source_key != ?",
                                         (ref, buyer, sup.get("name"), key)).fetchone():
                        continue  # older SEAO files re-publish the same award under another release id
                    added = add_award(c, {"source_key": key,
                                          "source": "seao", "agency_id": agency, "buyer": buyer, "country": "CA", "ref_no": ref,
                                          "title": title, "vendor": sup.get("name"), "amount": v.get("amount"),
                                          "currency": v.get("currency") or "CAD", "award_date": iso(aw.get("date")),
                                          "n_bidders": nb, "low_bid": min(amounts) if amounts else None,
                                          "high_bid": max(amounts) if amounts else None,
                                          "start_date": ((aw.get("contractPeriod") or tender.get("contractPeriod") or {}).get("startDate") or "")[:10] or None,
                                          "end_date": ((aw.get("contractPeriod") or tender.get("contractPeriod") or {}).get("endDate") or "")[:10] or None,
                                          "notes": tender.get("procurementMethodDetails") or None,
                                          "source_url": url, "confidence": "A"}, suppliers)
                    new += added
                    aid = c.execute("SELECT award_id, notice_id FROM award WHERE source_key=?", (key,)).fetchone()
                    if aid and bids and not c.execute("SELECT 1 FROM bid_tab WHERE award_id=?", (aid[0],)).fetchone():
                        ranked = sorted(bids, key=lambda b: (b[1] is None, b[1] or 0))
                        for i, (who, amt) in enumerate(ranked, 1):
                            c.execute("INSERT INTO bid_tab (award_id, notice_id, bidder, bidder_norm, amount, rank, winner, source_url) VALUES (?,?,?,?,?,?,?,?)",
                                      (aid[0], aid[1], who, norm_vendor(who), amt, i, int((who or "").lower() == (sup.get("name") or "").lower()), url))
        c.execute("INSERT OR REPLACE INTO page_watch (url, kind, last_checked) VALUES (?, 'seao', ?)", (u, bc.now()))
        c.commit()
    if skipped_big:
        bc.log(f"seao: {skipped_big} weekly file(s) skipped as too big")
    return found, new


# ---------------------------------------------------------------- page watch (public agency pages)

class _Text(html.parser.HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "head"}

    def __init__(self):
        super().__init__()
        self.out, self.skip, self.links = [], 0, []

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag == "a":
            href = dict(attrs).get("href")
            if href:
                self.links.append(href)
        if tag in ("p", "div", "tr", "li", "br", "h1", "h2", "h3", "h4", "td", "table"):
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1

    def handle_data(self, d):
        if not self.skip:
            self.out.append(d)


def page_text(raw, cs):
    p = _Text()
    p.feed(raw.decode(cs, "replace"))
    lines = [re.sub(r"\s+", " ", l).strip() for l in "".join(p.out).split("\n")]
    return "\n".join(l for l in lines if l)


EXTRACT_SYSTEM = """You read the text of a public procurement web page of a transit or rail agency and list the procurement items on it.
Return every solicitation (bid, RFP, RFQ, IFB, tender, sole-source notice, upcoming procurement) and every award or bid result you can see, with the fields stated on the page. Leave a field empty when the page does not state it; never guess amounts, dates or vendors. Dates as YYYY-MM-DD."""
EXTRACT_SCHEMA = {"type": "object", "properties": {
    "items": {"type": "array", "items": {"type": "object", "properties": {
        "kind": {"type": "string", "enum": ["tender", "planned", "addendum", "award", "cancelled"]},
        "ref_no": {"type": "string"}, "title": {"type": "string"}, "description": {"type": "string"},
        "closing": {"type": "string"}, "url": {"type": "string"},
        "vendor": {"type": "string"}, "amount": {"type": "number"}, "award_date": {"type": "string"},
        "bidders": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "amount": {"type": "number"}},
                                                "required": ["name", "amount"], "additionalProperties": False}}},
        "required": ["kind", "ref_no", "title", "description", "closing", "url", "vendor", "amount", "award_date", "bidders"],
        "additionalProperties": False}}},
    "required": ["items"], "additionalProperties": False}


def store_items(c, items, agency_id, country, page_url, source, suppliers=None):
    new = 0
    import urllib.parse
    for it in items:
        url = urllib.parse.urljoin(page_url, it["url"]) if it.get("url") else page_url
        key_ref = it["ref_no"] or re.sub(r"\W+", "-", it["title"].lower())[:80]
        if it["kind"] == "award" and it.get("vendor"):
            bids = [b for b in it.get("bidders") or [] if b.get("name")]
            amounts = [b["amount"] for b in bids if b.get("amount")]
            ok = add_award(c, {"source_key": f"{source}-award:{agency_id}:{key_ref}:{it['vendor']}", "source": source,
                               "agency_id": agency_id, "country": country, "ref_no": it["ref_no"] or None, "title": it["title"],
                               "vendor": it["vendor"], "amount": it.get("amount") or None, "currency": "CAD" if country == "CA" else "USD",
                               "award_date": iso(it.get("award_date")) or None, "n_bidders": len(bids) or None,
                               "low_bid": min(amounts) if amounts else None, "high_bid": max(amounts) if amounts else None,
                               "source_url": url, "confidence": "A"}, suppliers)
            if ok:
                aid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                for rank, b in enumerate(sorted(bids, key=lambda b: b.get("amount") or 9e18), 1):
                    c.execute("INSERT INTO bid_tab (award_id, bidder, bidder_norm, amount, rank, winner, source_url) VALUES (?,?,?,?,?,?,?)",
                              (aid, b["name"], norm_vendor(b["name"]), b.get("amount") or None, rank,
                               int(norm_vendor(b["name"]) == norm_vendor(it["vendor"])), url))
            new += ok
        new += add_notice(c, {"source": source, "source_key": f"{source}:{agency_id}:{key_ref}:{it['kind']}", "agency_id": agency_id,
                              "country": country, "ref_no": it["ref_no"] or None, "title": it["title"],
                              "description": it.get("description") or None, "notice_type": it["kind"],
                              "published": iso(it.get("published")) or bc.now()[:10],  # pages and alert emails: first seen
                              "closing": iso(it.get("closing")) or None, "url": url})
    return new


def watch_urls(c):
    """(url, agency_id, country, kind) for agencies whose inventory says page watch, plus their extra pages"""
    out = []
    for r in c.execute("SELECT agency_id, country, portal_url, alert_channel FROM agency WHERE watch=1 AND portal_url LIKE 'http%'"):
        if "page watch" in (r["alert_channel"] or ""):
            out.append((r["portal_url"], r["agency_id"], r["country"], "solicitations"))
    rss_on = bool((bc.settings().get("feeds") or {}).get("bonfire_rss_permission"))
    for url, aid, kind in EXTRA_PAGES + PLATFORM_PAGES:
        if rss_on and "bonfirehub.com" in url:
            continue  # read through the agency's Bonfire RSS feed instead (coverage.bonfire_rss); the page itself is robots-blocked
        out.append((url, aid, "US", kind))
    seen, res = set(), []
    for row in out:
        if row[0] not in seen:
            seen.add(row[0])
            res.append(row)
    return res


# public results pages that feed the awards inventory
EXTRA_PAGES = [("https://www.bart.gov/node/12407", "BART", "awards"),         # Bids Received
               ("https://www.bart.gov/node/11634", "BART", "awards"),         # Recently Awarded
               ("https://www.bart.gov/node/12406", "BART", "solicitations"),  # Out for Bid
               ("https://www.bart.gov/node/11639", "BART", "solicitations")]  # Upcoming Procurement Events


# Public bid lists on the e-procurement platforms where we hold an account. They are built with JavaScript,
# so they are read through the bid-render service. (url, agency_id, kind)
PLATFORM_PAGES = [(f"https://{slug}.bonfirehub.com/portal/?tab=openOpportunities", aid, "solicitations") for slug, aid in [
    ("metra", "METRA"), ("transitchicago", "CTA"), ("nfta", "NFTA"), ("charlottenc", "CATS"), ("dart", "DART"),
    ("ridemetro", "METRO_HOU"), ("utah", "UTA"), ("smctd", "CALTRAIN"), ("sonomamarintrain", "SMART"), ("gohart", "HART_TPA"),
    ("tri-rail", "SFRTA"), ("cincinnati-oh", "SORTA"), ("kcmo", "KCSC"), ("detroit", "DTC_QLINE"), ("dfwairport", "DFW_AIRPORT"),
    ("lawa", "LAWA"), ("flypittsburgh", "ACAA")]] + \
    [(f"https://procurement.opengov.com/portal/{slug}", aid, "solicitations") for slug, aid in [
        ("rtd-denver", "RTD"), ("vta", "VTA"), ("valleymetro", "VALLEYMETRO"), ("jtafla", "JTA"), ("go-metro", "SORTA"),
        ("goaa", "GOAA"), ("seattle", "SEATTLE_MONO"), ("cvgairport", "KCAB_CVG"), ("phoenix", "PHX_AVN")]] + \
    [(f"https://vendors.planetbids.com/portal/{pid}/bo/bo-search", aid, "solicitations") for pid, aid in [
        ("14771", "SDMTS"), ("20134", "NCTD"), ("39494", "CAPMETRO"), ("13821", "METROLINK")]]
JS_HOSTS = ("bonfirehub.com", "opengov.com", "planetbids.com", "ariba.com", "bidnetdirect.com", "demandstar.com")


def read_page(url):
    """(text, final_url) for a watched page. JavaScript-built pages (platform hosts, or a near-empty plain fetch)
    go through the bid-render service when one is configured. robots.txt is honoured either way."""
    host = urllib.parse.urlparse(url).netloc.lower()
    text, final = "", url
    if not any(host == h or host.endswith("." + h) for h in JS_HOSTS):
        raw, cs, final = bc.fetch(url)
        text = page_text(raw, cs)[:60000]
        if len(text) >= 400 or not bc.RENDER_URL:
            return text, final
    html, final = bc.render(url)
    return page_text(html.encode("utf-8"), "utf-8")[:60000], final


def prune_page_watch(c, urls):
    """Drops page_watch rows for pages no longer watched (an agency's URL changed, or a feed now covers it), so stale
    errors stop showing on Bid sources. Feed, SEAO and hand-check rows are kept."""
    keep = set(urls)
    gone = [r[0] for r in c.execute("SELECT url FROM page_watch WHERE kind IN ('solicitations','awards')") if r[0] not in keep]
    c.executemany("DELETE FROM page_watch WHERE url=?", [(u,) for u in gone])
    c.commit()
    return len(gone)


def page_watch(c, budget=None):
    found = new = 0
    cost = 0.0
    have_key = bc.api_key()
    suppliers = supplier_ids()
    urls = watch_urls(c)
    prune_page_watch(c, [u[0] for u in urls])
    for url, aid, country, kind in urls:
        prev = c.execute("SELECT last_hash, last_text FROM page_watch WHERE url=?", (url,)).fetchone()
        try:
            text, final = read_page(url)
        except Exception as e:
            c.execute("INSERT INTO page_watch (url, agency_id, kind, last_checked, last_error) VALUES (?,?,?,?,?) "
                      "ON CONFLICT(url) DO UPDATE SET last_checked=excluded.last_checked, last_error=excluded.last_error",
                      (url, aid, kind, bc.now(), str(e)[:300]))
            continue
        if not have_key:  # keep the page unseen so it is read in full once a key is added
            c.execute("INSERT INTO page_watch (url, agency_id, kind, last_checked) VALUES (?,?,?,?) "
                      "ON CONFLICT(url) DO UPDATE SET last_checked=excluded.last_checked, last_error=NULL", (url, aid, kind, bc.now()))
            c.commit()
            continue
        h = bc.sha(text)
        changed = not prev or prev["last_hash"] != h

        def mark(saved):
            # the new text and hash are saved only once its lines have been read (or need no reading), so a page whose
            # extraction failed or waited for the daily budget is read again next run instead of being skipped for good
            if saved:
                c.execute("INSERT INTO page_watch (url, agency_id, kind, last_hash, last_text, last_checked, last_changed, last_error) "
                          "VALUES (?,?,?,?,?,?,?,NULL) ON CONFLICT(url) DO UPDATE SET last_hash=excluded.last_hash, last_text=excluded.last_text, "
                          "last_checked=excluded.last_checked, last_error=NULL" + (", last_changed=excluded.last_changed" if changed else ""),
                          (url, aid, kind, h, text, bc.now(), bc.now()))
            else:
                c.execute("INSERT INTO page_watch (url, agency_id, kind, last_checked) VALUES (?,?,?,?) "
                          "ON CONFLICT(url) DO UPDATE SET last_checked=excluded.last_checked, last_error=NULL", (url, aid, kind, bc.now()))
            c.commit()
        if not changed or len(text) < 200:
            mark(True)
            continue
        # send only the lines that are new since last time (the whole page on first sight)
        old = set((prev["last_text"] or "").split("\n")) if prev else set()
        delta = "\n".join(l for l in text.split("\n") if l not in old) if prev else text
        if len(delta) < 40:
            mark(True)
            continue
        if budget is not None and cost >= budget:
            mark(False)
            bc.log("page watch: daily budget reached; remaining changed pages wait for tomorrow")
            break
        try:
            out, k = bc.claude_json(EXTRACT_SYSTEM, f"Agency: {aid}\nPage: {final}\nPage kind: {kind}\n"
                                    f"{'New or changed lines' if prev else 'Page text'}:\n{delta[:40000]}", EXTRACT_SCHEMA)
        except Exception as e:
            mark(False)
            bc.log(f"page watch: extraction failed for {url}: {e}")
            continue
        mark(True)
        cost += k
        found += len(out["items"])
        new += store_items(c, out["items"], aid, country, final, "page", suppliers)
        c.commit()
    return found, new, cost
