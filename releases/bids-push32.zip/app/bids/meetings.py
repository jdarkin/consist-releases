"""Board and committee meetings: upcoming meetings, their agenda documents, and the rail contract items in them.

No Claude calls here. Every page and document is fetched politely (robots.txt honoured by bidcore.fetch / render), and
documents are read with pypdf plus keyword rules (relevance.kw_score, taxonomy.tag). The weekly budgets run may spend its
existing cap on the most rail-heavy documents (claude_pass), nothing more.

  bidmon meetings                          poll every meeting source, read new agendas (the daily scan does this too)
  bidmon meetings --load FILE.csv          add sources (agency_id,platform,url,client,body_hint,notes)
  bidmon meetings --agency DART --no-docs  one agency, calendar only

Platforms: legistar (open Web API), primegov (public portal API), civicclerk (public API), escribe, granicus, civicplus,
html (any listing page with agenda / minutes links next to dates), events (a calendar whose meetings are event pages). Unknown platforms are read as html.

Tables (read by the site, read-only):
  meeting_source  where each agency publishes meetings
  meeting         one row per meeting: agency_id, body, meeting_date, status (scheduled | held | cancelled), document links
  meeting_doc     each agenda / packet / minutes document read: pages, rail pages, an extractive summary
  meeting_item    each rail item found in a document: title, action, vendor, amount, bidders, category, subsystems, relevance
"""
import csv
import datetime as dt
import html as _html
import io
import json
import os
import re
import urllib.parse

import bidcore as bc
import oncall
import sources
import taxonomy
from relevance import kw_score

SCHEMA = """
CREATE TABLE IF NOT EXISTS meeting_source (
  url TEXT PRIMARY KEY, agency_id TEXT, platform TEXT, client TEXT, body_hint TEXT, notes TEXT, active INTEGER DEFAULT 1,
  added TEXT, last_checked TEXT, last_error TEXT, meetings INTEGER);
CREATE TABLE IF NOT EXISTS meeting (
  meeting_id INTEGER PRIMARY KEY, source_key TEXT UNIQUE, agency_id TEXT, body TEXT, meeting_date TEXT, meeting_time TEXT,
  title TEXT, location TEXT, status TEXT, agenda_url TEXT, packet_url TEXT, minutes_url TEXT, video_url TEXT, detail_url TEXT,
  source_url TEXT, platform TEXT, first_seen TEXT, last_seen TEXT, rail_items INTEGER DEFAULT 0, top_relevance INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS meeting_agency_date ON meeting(agency_id, meeting_date);
CREATE TABLE IF NOT EXISTS meeting_doc (
  url TEXT PRIMARY KEY, meeting_id INTEGER, agency_id TEXT, doc_type TEXT, title TEXT, fetched TEXT, bytes INTEGER,
  pages INTEGER, rail_pages INTEGER, items INTEGER, summary TEXT, summary_by TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS meeting_item (
  item_id INTEGER PRIMARY KEY, source_key TEXT UNIQUE, meeting_id INTEGER, agency_id TEXT, item_no TEXT, title TEXT,
  action TEXT, vendor TEXT, amount REAL, currency TEXT, amount_usd REAL, bidders TEXT, ref_no TEXT, category TEXT,
  subsystems TEXT, relevance INTEGER, doc_url TEXT, page INTEGER, excerpt TEXT, award_id INTEGER, first_seen TEXT);
CREATE INDEX IF NOT EXISTS meeting_item_agency ON meeting_item(agency_id);
"""

PAST_DAYS = int(os.environ.get("BIDS_MEETINGS_PAST_DAYS", "45"))     # held meetings whose documents are still read
AHEAD_DAYS = int(os.environ.get("BIDS_MEETINGS_AHEAD_DAYS", "90"))   # scheduled meetings listed
DOCS_PER_RUN = int(os.environ.get("BIDS_MEETINGS_DOCS_PER_RUN", "30"))
MAX_MB = float(os.environ.get("BIDS_MEETINGS_MAX_MB", "40"))
MAX_PAGES = int(os.environ.get("BIDS_MEETINGS_MAX_PAGES", "800"))
AWARD_MIN_REL = 45  # an item this rail-relevant, with a vendor, also goes to the awards inventory (as a recommendation)


def ensure(c):
    c.executescript(SCHEMA)
    c.commit()
    import oncall  # on-call columns on meeting_item (type, term, options, ceiling, firms, parent contract)
    oncall._READY.discard("meeting_item")
    oncall.ensure(c)


def load_sources(c, path):
    ensure(c)
    n = 0
    for r in csv.DictReader(open(path, newline="", encoding="utf-8-sig")):
        url, plat = (r.get("url") or "").strip(), (r.get("platform") or "html").strip().lower()
        if not url.startswith("http") or plat == "unknown":
            continue
        cur = c.execute("INSERT OR IGNORE INTO meeting_source (url, agency_id, platform, client, body_hint, notes, added) VALUES (?,?,?,?,?,?,?)",
                        (url, (r.get("agency_id") or "").strip() or None, plat, (r.get("client") or "").strip() or None,
                         (r.get("body_hint") or "").strip() or None, (r.get("notes") or "").strip()[:500] or None, bc.now()))
        n += cur.rowcount
        if (r.get("active") or "").strip() == "0":  # a row can switch off a source it replaces
            c.execute("UPDATE meeting_source SET active=0 WHERE url=?", (url,))
    c.commit()
    return n


# ---------------------------------------------------------------- dates

_MON = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|janv|f[ée]v|mars|avr|mai|juin|juil|ao[ûu]|d[ée]c)[a-zéû]*\.?"
_DATE_RX = [
    (re.compile(r"\b(20\d\d)-(\d{1,2})-(\d{1,2})\b"), "ymd"),
    (re.compile(r"\b(\d{1,2})/(\d{1,2})/(20\d\d)\b"), "mdy"),
    (re.compile(r"\b" + _MON + r"\s+(\d{1,2}),?\s+(20\d\d)\b", re.I), "Mdy"),
    (re.compile(r"\b(\d{1,2})(?:er)?\s+" + _MON + r"\s+(20\d\d)\b", re.I), "dMy"),
]


def find_date(text):
    """The first date in text, as a date, or None."""
    best = None
    for rx, kind in _DATE_RX:
        m = rx.search(text or "")
        if not m:
            continue
        try:
            if kind == "ymd":
                d = dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            elif kind == "mdy":
                d = dt.date(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            elif kind == "Mdy":
                d = dt.date(int(m.group(3)), sources.MONTHS[m.group(1).lower()[:4].rstrip(".")] if m.group(1).lower()[:4].rstrip(".") in sources.MONTHS
                            else sources.MONTHS[m.group(1).lower()[:3]], int(m.group(2)))
            else:
                mon = m.group(2).lower()
                d = dt.date(int(m.group(3)), sources.MONTHS.get(mon[:4].rstrip("."), sources.MONTHS.get(mon[:3])), int(m.group(1)))
        except (ValueError, KeyError, TypeError):
            continue
        if best is None or m.start() < best[0]:
            best = (m.start(), d)
    return best[1] if best else None


def _iso_dt(s):
    """(date ISO, time HH:MM or None) from an API datetime string."""
    s = (s or "").strip()
    m = re.match(r"(\d{4}-\d{2}-\d{2})(?:[T ](\d{2}:\d{2}))?", s)
    if m:
        t = m.group(2)
        return m.group(1), (t if t and t != "00:00" else None)
    d = find_date(s)
    return (d.isoformat() if d else None), None


# ---------------------------------------------------------------- platform adapters
# each returns a list of meetings: {key, body, date, time, title, location, status, agenda_url, packet_url, minutes_url,
# video_url, detail_url, docs: [(url, doc_type, title)], items: [{item_no, title, url}]}

def _json(url, data=None, headers=None):
    raw, cs, _ = bc.fetch(url, timeout=60, data=data, headers={"Accept": "application/json", **(headers or {})})
    return json.loads(raw.decode(cs, "replace"))


def _window():
    t = dt.date.today()
    return t - dt.timedelta(days=PAST_DAYS), t + dt.timedelta(days=AHEAD_DAYS)


def legistar(src):
    client = src["client"] or urllib.parse.urlparse(src["url"]).netloc.split(".")[0]
    lo, hi = _window()
    base = f"https://webapi.legistar.com/v1/{client}"
    q = urllib.parse.urlencode({"$filter": f"EventDate ge datetime'{lo}' and EventDate le datetime'{hi}'", "$orderby": "EventDate"})
    out = []
    for e in _json(f"{base}/events?{q}"):
        body = e.get("EventBodyName") or ""
        if src["body_hint"] and not _body_ok(body, src["body_hint"]):
            continue
        date, _ = _iso_dt(e.get("EventDate"))
        m = {"key": f"legistar:{client}:{e.get('EventId')}", "body": body, "date": date, "time": (e.get("EventTime") or "").strip() or None,
             "title": body, "location": e.get("EventLocation"), "status": "cancelled" if re.search(r"cancel", e.get("EventAgendaStatusName") or "", re.I) else None,
             "agenda_url": e.get("EventAgendaFile"), "minutes_url": e.get("EventMinutesFile"), "video_url": e.get("EventVideoPath"),
             "detail_url": e.get("EventInSiteURL"), "docs": [], "items": [], "_items_url": f"{base}/events/{e.get('EventId')}/eventitems?AgendaNote=1&Attachments=1"}
        for u, t in ((m["agenda_url"], "agenda"), (m["minutes_url"], "minutes")):
            if u:
                m["docs"].append((u, t, f"{body} {t}"))
        out.append(m)
    return out


def _legistar_items(m):
    """Agenda items of one Legistar meeting (titles are structured; attachments are the staff reports)."""
    items = []
    for it in _json(m["_items_url"]):
        title = (it.get("EventItemTitle") or "").strip()
        if not title:
            continue
        atts = [a.get("MatterAttachmentHyperlink") for a in it.get("EventItemMatterAttachments") or [] if a.get("MatterAttachmentHyperlink")]
        items.append({"item_no": it.get("EventItemAgendaNumber") or it.get("EventItemMatterFile"), "title": title,
                      "ref_no": it.get("EventItemMatterFile"), "attachments": atts})
    return items


def primegov(src):
    host = urllib.parse.urlparse(src["url"]).netloc
    base = f"https://{host}"
    rows = []
    for path in ("/api/v2/PublicPortal/ListUpcomingMeetings", f"/api/v2/PublicPortal/ListArchivedMeetings?year={dt.date.today().year}"):
        try:
            rows += _json(base + path)
        except Exception as e:
            bc.log(f"meetings primegov {host}{path}: {e}")
    lo, hi = _window()
    out = []
    for r in rows:
        date, time = _iso_dt(r.get("dateTime") or r.get("date"))
        if not date or not (lo.isoformat() <= date <= hi.isoformat()):
            continue
        body = r.get("title") or ""
        if src["body_hint"] and not _body_ok(body, src["body_hint"]):
            continue
        docs = []
        for d in r.get("documentList") or []:
            tid = d.get("templateId") or d.get("id")
            name = d.get("templateName") or "document"
            if tid:
                docs.append((f"{base}/Public/CompiledDocument?meetingTemplateId={tid}&compileOutputType=1", _doc_type(name), name))
        out.append({"key": f"primegov:{host}:{r.get('id')}", "body": body, "date": date, "time": time, "title": body,
                    "location": r.get("location"), "status": None, "video_url": r.get("videoUrl"),
                    "detail_url": f"{base}/Portal/MeetingPreview?compiledMeetingDocumentFileId={(r.get('documentList') or [{}])[0].get('id', '')}",
                    "docs": docs, "items": []})
    return out


def civicclerk(src):
    host = urllib.parse.urlparse(src["url"]).netloc
    client = src["client"] or host.split(".")[0]
    api = f"https://{client}.api.civicclerk.com/v1"
    lo, hi = _window()
    q = urllib.parse.urlencode({"$filter": f"startDateTime ge {lo}T00:00:00Z and startDateTime le {hi}T23:59:59Z", "$orderby": "startDateTime"})
    data = _json(f"{api}/Events?{q}")
    out = []
    for e in data.get("value", data if isinstance(data, list) else []):
        body = e.get("eventName") or e.get("categoryName") or ""
        if src["body_hint"] and not _body_ok(body + " " + (e.get("categoryName") or ""), src["body_hint"]):
            continue
        date, time = _iso_dt(e.get("startDateTime") or e.get("eventDate"))
        docs = [(f"{api}/Meetings/GetMeetingFileStream(fileId={f.get('fileId')},plainText=false)", _doc_type(f.get("type") or f.get("name") or ""),
                 f.get("name") or f.get("type") or "document") for f in e.get("publishedFiles") or [] if f.get("fileId")]
        out.append({"key": f"civicclerk:{client}:{e.get('id')}", "body": body, "date": date, "time": time, "title": body,
                    "location": (e.get("eventLocation") or {}).get("address1") if isinstance(e.get("eventLocation"), dict) else None,
                    "status": None, "detail_url": f"https://{host}/event/{e.get('id')}/overview", "docs": docs, "items": []})
    return out


def escribe(src):
    host = urllib.parse.urlparse(src["url"]).netloc
    lo, hi = _window()
    body = json.dumps({"calendarStartDate": lo.isoformat(), "calendarEndDate": hi.isoformat()}).encode()
    try:
        rows = _json(f"https://{host}/MeetingsCalendarView.aspx/GetCalendarMeetings", data=body,
                     headers={"Content-Type": "application/json; charset=utf-8"}).get("d") or []
    except Exception as e:
        bc.log(f"meetings escribe {host}: calendar API failed ({e}); reading the page")
        return html_list(src)
    out = []
    for r in rows:
        name = r.get("MeetingName") or r.get("MeetingType") or ""
        if src["body_hint"] and not _body_ok(name, src["body_hint"]):
            continue
        date, time = _iso_dt(r.get("StartDate") or r.get("FormattedStart"))
        detail = urllib.parse.urljoin(f"https://{host}/", r.get("Url") or "")
        docs = [(urllib.parse.urljoin(f"https://{host}/", l.get("Url") or ""), _doc_type(l.get("Title") or l.get("Type") or ""), l.get("Title") or "")
                for l in r.get("MeetingDocumentLink") or [] if l.get("Url")]
        out.append({"key": f"escribe:{host}:{r.get('ID') or detail}", "body": name, "date": date, "time": time, "title": name,
                    "location": r.get("Location"), "status": "cancelled" if r.get("IsCancelled") else None, "detail_url": detail,
                    "docs": docs, "items": []})
    return out


DOC_RX = re.compile(r"agenda|packet|minutes|staff report|board report|resolution|procès|ordre du jour|summary|action|video|watch|"
                    r"procurements?\b|board book|committee book", re.I)


def _doc_type(text):
    t = (text or "").lower()
    if "packet" in t or "agenda package" in t or "complete" in t or "book" in t:
        return "packet"
    if "minute" in t or "procès" in t:
        return "minutes"
    if "agenda" in t or "ordre du jour" in t:
        return "agenda"
    if "video" in t or "watch" in t or "mediaplayer" in t:
        return "video"
    if "report" in t or "resolution" in t or "procurement" in t:
        return "report"
    return "other"


def html_list(src):
    """Any listing page: links to agendas / minutes / packets grouped by the date nearest before them in the page."""
    url = src["url"]
    host = urllib.parse.urlparse(url).netloc.lower()
    if any(host == h or host.endswith("." + h) for h in sources.JS_HOSTS + ("escribemeetings.com", "boarddocs.com", "civicclerk.com")) and bc.RENDER_URL:
        html, final = bc.render(url)
    else:
        raw, cs, final = bc.fetch(url)
        html = raw.decode(cs, "replace")
        if len(sources.page_text(raw, cs)) < 400 and bc.RENDER_URL:
            html, final = bc.render(url)
    meetings, cur = {}, None
    pos = 0
    for m in re.finditer(r"<a\b[^>]*href=[\"']([^\"'#]+)[\"'][^>]*>(.*?)</a>", html, re.I | re.S):
        between = re.sub(r"<[^>]+>", " ", html[pos:m.start()])
        pos = m.end()
        text = re.sub(r"<[^>]+>|\s+", " ", m.group(2)).strip()
        href = urllib.parse.urljoin(final, m.group(1).strip())
        d = find_date(between[-400:]) or find_date(text) or find_date(urllib.parse.unquote(href))
        if d:
            cur = d
        if not (DOC_RX.search(text) or DOC_RX.search(href)) or cur is None:
            continue
        label = between[-300:]
        for rx, _ in _DATE_RX:
            label = rx.sub(" ", label)
        label = next((x.strip() for x in reversed(re.split(r"\s{2,}|\|", label)) if len(x.strip()) > 3), "")[:120]
        mt = meetings.setdefault(cur.isoformat(), {"key": f"html:{bc.sha(url)[:12]}:{cur.isoformat()}", "body": (src["body_hint"] or "Board").split(";")[0].strip(),
                                                   "date": cur.isoformat(), "time": None, "title": label or (src["body_hint"] or "Board meeting"),
                                                   "location": None, "status": None, "detail_url": url, "docs": [], "items": []})
        t = _doc_type(text + " " + href)
        if t == "video":
            mt["video_url"] = mt.get("video_url") or href
        elif href not in [x[0] for x in mt["docs"]]:
            mt["docs"].append((href, t, text[:200]))
    lo, hi = _window()
    return [m for d, m in meetings.items() if lo.isoformat() <= d <= hi.isoformat()]


MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]


def monthly(src):
    """A site with one page per month (MTA: /transparency/board-and-committee-meetings/june-2025). The source URL is a template
    with {month} (january), {mon} (jan), {mm} (06) and {yyyy}; every month in the meeting window is read like an html source."""
    lo, hi = _window()
    out, y, m = [], lo.year, lo.month
    while (y, m) <= (hi.year, hi.month):
        name = MONTHS[m - 1]
        url = src["url"].format(month=name, mon=name[:3], mm=f"{m:02d}", yyyy=y)
        try:
            out += html_list(dict(src, url=url))
        except Exception as e:
            if "404" not in str(e):  # a month whose page isn't up yet
                raise
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def granicus(src):
    return html_list(src)  # ViewPublisher pages are plain tables: name, date, Agenda / Minutes / Video links


_PATH_DATE = re.compile(r"/(20\d\d)/(\d{1,2})/(\d{1,2})(?:/|$|\?)")
_A_RX = re.compile(r"<a\b[^>]*href=[\"']([^\"'#]+)[\"'][^>]*>(.*?)</a>", re.I | re.S)


def events(src):
    """A site whose meetings are separate event pages (Valley Metro: the /event calendar and /archive list each meeting
    at /event/<type>/YYYY/MM/DD, and the packet PDFs are on that page). src.client is a regex the event links must match.
    The listing is rendered when its links only appear after JavaScript; every event page in the meeting window is read
    for its agenda / packet / minutes links."""
    url = src["url"]
    pat = re.compile(src["client"] or r"/event/", re.I)
    raw, cs, final = bc.fetch(url)
    html = raw.decode(cs, "replace")
    if not any(pat.search(urllib.parse.urljoin(final, m.group(1))) for m in _A_RX.finditer(html)) and bc.RENDER_URL:
        html, final = bc.render(url)
    lo, hi = _window()
    out, seen = [], set()
    for m in _A_RX.finditer(html):
        href = urllib.parse.urljoin(final, m.group(1).strip())
        text = re.sub(r"<[^>]+>|\s+", " ", m.group(2)).strip()
        if not pat.search(href) or href in seen or not text:
            continue
        pd = _PATH_DATE.search(urllib.parse.urlparse(href).path + "/")
        try:
            d = dt.date(int(pd.group(1)), int(pd.group(2)), int(pd.group(3))) if pd else find_date(text)
        except ValueError:
            d = find_date(text)
        if not d or not (lo <= d <= hi):
            continue
        seen.add(href)
        body = re.split(r"\s+[-\u2013]\s+(?:Mon|Tues|Wednes|Thurs|Fri|Satur|Sun)day\b", text)[0].strip() or (src["body_hint"] or "Board")
        if src["body_hint"] and not _body_ok(body + " " + href, src["body_hint"]):
            continue
        docs = []
        try:
            praw, pcs, pfin = bc.fetch(href)
            page = praw.decode(pcs, "replace")
            # links in the HTML, plus the page's embedded JSON (Valley Metro's resources: {"title": ..., "download": [{"url": ...pdf}]})
            pairs = [(urllib.parse.urljoin(pfin, a.group(1).strip()), re.sub(r"<[^>]+>|\s+", " ", a.group(2)).strip()) for a in _A_RX.finditer(page)]
            js = _html.unescape(page).replace("\\/", "/")
            for u in re.finditer(r'"url"\s*:\s*"(https?://[^"]+?\.pdf)"', js, re.I):
                t = re.findall(r'"title"\s*:\s*"([^"]{1,200})"', js[max(0, u.start() - 600):u.start()])
                pairs.append((u.group(1), t[-1] if t else ""))
            for h, t in pairs:
                if ".pdf" not in h.lower() or not (DOC_RX.search(t) or DOC_RX.search(h)) or h in [x[0] for x in docs]:
                    continue
                docs.append((h, _doc_type(t + " " + h), t[:200]))
        except Exception as e:
            bc.log(f"meetings events {src['agency_id']} {href}: {e}")
        out.append({"key": f"event:{href}", "body": body[:200], "date": d.isoformat(), "time": None, "title": text[:300],
                    "location": None, "status": "cancelled" if re.search(r"\bcancel+ed\b", text, re.I) else None,
                    "detail_url": href, "docs": docs, "items": []})
    return out


ADAPTERS = {"legistar": legistar, "primegov": primegov, "civicclerk": civicclerk, "escribe": escribe, "granicus": granicus,
            "civicplus": html_list, "html": html_list, "monthly": monthly, "events": events}


def _body_ok(body, hint):
    """A source shared with a city or regional council: keep only the bodies named in body_hint (';'-separated words)."""
    b = (body or "").lower()
    return any(h.strip().lower() in b for h in re.split(r"[;|]", hint) if h.strip())


# ---------------------------------------------------------------- polling

def poll(c, src):
    """Lists one source's meetings into the meeting table. Returns the meeting dicts (with ids) that have documents."""
    fn = ADAPTERS.get(src["platform"], html_list)
    found = fn(src)
    today = dt.date.today().isoformat()
    out = []
    for m in found:
        if not m.get("date"):
            continue
        status = m.get("status") or ("held" if m["date"] < today else "scheduled")
        docs = m.get("docs") or []
        first = lambda kind: next((u for u, t, _ in docs if t == kind), None)  # noqa: E731
        row = {"agency_id": src["agency_id"], "body": (m.get("body") or "")[:200], "meeting_date": m["date"], "meeting_time": m.get("time"),
               "title": (m.get("title") or "")[:300], "location": (m.get("location") or "")[:300] or None, "status": status,
               "agenda_url": m.get("agenda_url") or first("agenda"), "packet_url": m.get("packet_url") or first("packet"),
               "minutes_url": m.get("minutes_url") or first("minutes"), "video_url": m.get("video_url"), "detail_url": m.get("detail_url"),
               "source_url": src["url"], "platform": src["platform"], "last_seen": bc.now()}
        ex = c.execute("SELECT meeting_id FROM meeting WHERE source_key=?", (m["key"],)).fetchone()
        if ex:
            sets = ", ".join(f"{k}=coalesce(?, {k})" for k in row)
            c.execute(f"UPDATE meeting SET {sets} WHERE meeting_id=?", list(row.values()) + [ex[0]])
            mid = ex[0]
        else:
            row.update(source_key=m["key"], first_seen=bc.now())
            c.execute(f"INSERT INTO meeting ({','.join(row)}) VALUES ({','.join('?' * len(row))})", list(row.values()))
            mid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
        m["meeting_id"] = mid
        out.append(m)
    c.execute("UPDATE meeting_source SET last_checked=?, last_error=NULL, meetings=? WHERE url=?", (bc.now(), len(found), src["url"]))
    c.commit()
    return out


# ---------------------------------------------------------------- reading documents (keywords only)

ACTION_RX = re.compile(r"\b(award|contract|agreement|purchase|procure|procurement|amend|amendment|change order|task order|"
                       r"modification|option|exercise|solicitation|rfp|ifb|invitation for bids|request for proposals|sole source|"
                       r"lease|authoriz|approv|ratif|budget|capital)", re.I)
ITEM_START = re.compile(r"^\s*(?:item\s+)?(?:[A-Z]|\d{1,2}|[IVX]{1,5})(?:[.)]|\.\d{1,2}\.?)\s+\S|^\s*(?:SUBJECT|RE|TITLE|RESOLUTION|ACTION ITEM)\s*:|"
                        r"^\s*(?:Approval|Award|Authoriz|Adopt|Amend|Approve|Recommendation)\w*\s+(?:of|to|a|the)\b", re.I)
AMOUNT_RX = re.compile(r"\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?|\d+(?:\.\d+)?)\s*(million|billion|m\b|mm\b|k\b)?", re.I)
VENDOR_RX = [
    re.compile(r"(?:award(?:ed|ing)?|execute|enter into|negotiate)\s+(?:of\s+)?(?:a|an|the)?\s*(?:[\w\-/ ]{0,60}?)?(?:contract|agreement|purchase order|task order)\s+"
               r"(?:no\.?\s*[\w\-]+\s+)?(?:to|with)\s+([A-Z][\w&.,'\- ]{2,80}?)(?=,|\s+\(|\s+for\b|\s+in\b|\s+of\b|\s+to\b|\s+dba\b|\.\s|;|$)", re.S),
    re.compile(r"\b(?:to|with)\s+([A-Z][\w&.,'\- ]{2,60}?(?:Inc|LLC|L\.L\.C|Corp|Corporation|Company|Co|Ltd|LP|LLP|JV|Joint Venture|Group|USA|America)\.?)\b"),
]
BIDDER_RX = re.compile(r"([A-Z][A-Za-z0-9&.,'\- ]{2,70}?(?:Inc|LLC|Corp|Corporation|Company|Co|Ltd|LP|JV|USA|Group|Rail|Systems|Engineering)\.?"
                       r"(?:,?\s+(?:dba|d/b/a)\s+[A-Z][\w&.\- ]{1,40}?)?)\s*\*?\s+(?:\([A-Z]{2,8}\)\s+)?\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?)")
REF_RX = re.compile(r"\b(?:C|P|RFP|IFB|RFQ|CN|Contract(?: No\.?)?)[\s#-]*\d{4,}(?:-\d+)?\b|\b[A-Z]{1,4}-\d{5,}(?:-\d{1,3})?\b")


def _amount(s):
    best = None
    for m in AMOUNT_RX.finditer(s):
        try:
            v = float(m.group(1).replace(",", ""))
        except ValueError:
            continue
        mult = (m.group(2) or "").lower()
        v *= 1e9 if mult.startswith("b") else 1e6 if mult in ("million", "m", "mm") else 1e3 if mult == "k" else 1
        if v >= 1000 and (best is None or v > best):
            best = v
    return best


CAT_RULES = [
    ("vehicle_procurement", r"(purchase|procure|acquisition|order|option)\w* (of )?(\d+ )?(new )?(rail ?cars?|light rail vehicles?|lrvs?|locomotives?|vehicles|trainsets?|subway cars?|streetcars?)"),
    ("overhaul_program", r"overhaul|mid-?life|rebuild|remanufactur|refurbish"),
    ("component_repair", r"repair|exchange|inverter|traction motor|hvac|door operator|wheelset|truck|bogie|coupler|compressor"),
    ("parts_supply", r"parts|spares|supply of|consumables"),
    ("onboard_systems", r"onboard|on-board|cctv|passenger information|ptc onboard|event recorder|tcms|apc"),
    ("signals_communications", r"signal|train control|cbtc|ptc|interlocking|grade crossing|scada|radio"),
    ("traction_power", r"traction power|catenary|overhead contact|substation|third rail|electrification"),
    ("track_infrastructure", r"track|rail grinding|ties|ballast|switch|bridge|tunnel|right[- ]of[- ]way"),
    ("stations_facilities", r"station|platform|yard|maintenance facility|shop|elevator|escalator"),
    ("rail_engineering", r"engineering|design|consult|construction management|inspection services"),
    ("maintenance_services", r"maintenance services|fleet maintenance|operations and maintenance"),
]


def _category(text):
    t = (text or "").lower()
    return next((k for k, p in CAT_RULES if re.search(p, t)), "other")


def _action(text):
    t = (text or "").lower()
    if re.search(r"amend|modification|change order|increase|extend|extension|exercise .{0,20}option", t):
        return "amendment"
    if re.search(r"award|execute .{0,40}(contract|agreement)|enter into|approv\w* .{0,30}contract|contract (with|to) ", t):
        return "award"
    if re.search(r"solicitation|issue .{0,20}(rfp|ifb|invitation)|request for proposals|invitation for bids|procurement of", t):
        return "solicitation"
    if re.search(r"budget|capital (program|plan|improvement)|appropriat|grant", t):
        return "budget"
    return "other"


def _vendor(text):
    for rx in VENDOR_RX:
        m = rx.search(text or "")
        if m:
            v = m.group(1).strip(" ,.-")
            if len(v.split()) <= 12 and not re.match(r"(the|a|an|this|staff|board|authority|agency)\b", v, re.I):
                return v
    return None


def _blocks(pages):
    """(page number, block text) for each agenda item-ish block: a new block starts at an item heading."""
    out = []
    for pno, text in enumerate(pages, 1):
        cur = []
        for line in (text or "").splitlines():
            if ITEM_START.search(line) and sum(len(x) for x in cur) > 80:
                out.append((pno, "\n".join(cur)))
                cur = []
            cur.append(line)
        if cur:
            out.append((pno, "\n".join(cur)))
    return out


def extract_items(text_pages, agency_rail=True):
    """Rail contract / budget items in a document, by keyword rules. Returns a list of item dicts."""
    items, seen = [], set()
    for pno, block in _blocks(text_pages):
        flat = re.sub(r"\s+", " ", block).strip()
        if len(flat) < 40 or not ACTION_RX.search(flat):
            continue
        score = kw_score(("rail " if agency_rail else "") + flat[:3000])
        if score < 30 and not (score >= 20 and _category(flat[:600]) != "other" and _action(flat) != "other"):
            continue  # a rail agency's contract item names its rail work (track, signals, cars...) even when it never says "rail"
        score = max(score, 45)
        title = next((re.sub(r"\s+", " ", l).strip() for l in block.splitlines()
                      if re.search(r"approv|award|contract|agreement|purchase|overhaul|authoriz|amend|procure|subject", l, re.I) and len(l.strip()) > 15),
                     flat[:160])
        title = re.sub(r"^\s*(?:SUBJECT|RE|TITLE)\s*:\s*", "", title, flags=re.I)[:300]
        k = re.sub(r"\W+", " ", title.lower()).strip()[:120]
        if k in seen:
            continue
        seen.add(k)
        vendor = _vendor(flat)
        bidders = []
        for m in BIDDER_RX.finditer(flat):
            name = re.sub(r"^\W*(?:\d+\.?,?\s*)", "", m.group(1)).strip(" ,.")
            if name and name not in [b["name"] for b in bidders]:
                bidders.append({"name": name, "amount": float(m.group(2).replace(",", ""))})
        ref = REF_RX.search(flat)
        ct = oncall.classify(title + " " + flat[:4000])
        tr = oncall.terms(flat[:4000]) if ct else {}
        fs = oncall.firms(flat[:4000]) if ct == "oncall" else []
        items.append({"contract_type": ct, "term_months": tr.get("term_months"), "options_months": tr.get("options_months"),
                      "ceiling": tr.get("ceiling"), "start_date": tr.get("start_date"), "end_date": tr.get("end_date"),
                      "firms": fs, "parent_ref": tr.get("parent_ref") if ct == "task_order" else None,
                      "excerpt_full": flat[:4000] if ct else None,"title": title, "action": _action(flat), "vendor": vendor, "amount": _amount(flat), "bidders": bidders[:12],
                      "ref_no": ref.group(0) if ref else None, "category": _category(title + " " + flat[:600]),
                      "subsystems": ";".join(sorted(taxonomy.tag(flat))) or None, "relevance": score, "page": pno,
                      "excerpt": flat[:1500] if ct else flat[:700]})
    return items


def _pdf_pages(raw):
    import pypdf
    reader = pypdf.PdfReader(io.BytesIO(raw))
    return [(p.extract_text() or "") for p in reader.pages[:MAX_PAGES]], len(reader.pages)


def read_doc(c, meeting, url, doc_type, title, country="US"):
    """Downloads one agenda / packet / minutes document, stores its rail items. Returns items stored."""
    if c.execute("SELECT 1 FROM meeting_doc WHERE url=?", (url,)).fetchone():
        return 0
    pages, npages, size, err = [], 0, 0, None
    try:
        raw, cs, final = bc.fetch(url, timeout=180)
        size = len(raw)
        if size > MAX_MB * 1e6:
            raise RuntimeError(f"{size / 1e6:.0f} MB is over BIDS_MEETINGS_MAX_MB")
        if raw[:5] == b"%PDF-":
            pages, npages = _pdf_pages(raw)
        else:
            text = sources.page_text(raw, cs)
            pages = [text[i:i + 6000] for i in range(0, len(text), 6000)] or [""]
            npages = len(pages)
    except PermissionError as e:
        bc.log(f"meetings doc {url}: {e}")  # robots.txt says no: not recorded, so it is tried again if that changes
        return 0
    except Exception as e:
        err = str(e)[:300]
    items = extract_items(pages) if pages else []
    rail_pages = len({it["page"] for it in items})
    n = 0
    for it in items:
        key = f"mtg:{meeting['meeting_id']}:{bc.sha(it['title'].lower())[:16]}"
        cur = "CAD" if country == "CA" else "USD"
        r = c.execute("INSERT OR IGNORE INTO meeting_item (source_key, meeting_id, agency_id, item_no, title, action, vendor, amount, currency, amount_usd, "
                      "bidders, ref_no, category, subsystems, relevance, doc_url, page, excerpt, first_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (key, meeting["meeting_id"], meeting["agency_id"], None, it["title"], it["action"], it["vendor"], it["amount"], cur,
                       bc.to_usd(it["amount"], cur) if it["amount"] else None, json.dumps(it["bidders"]) if it["bidders"] else None,
                       it["ref_no"], it["category"], it["subsystems"], it["relevance"], url, it["page"], it["excerpt"], bc.now()))
        n += r.rowcount
        if r.rowcount and it.get("contract_type"):
            c.execute("UPDATE meeting_item SET contract_type=?, term_months=?, options_months=?, ceiling=?, start_date=?, end_date=?, firms=?, parent_ref=? "
                      "WHERE source_key=?", (it["contract_type"], it["term_months"], it["options_months"], it["ceiling"], it["start_date"],
                                             it["end_date"], json.dumps(it["firms"]) if it["firms"] else None, it["parent_ref"], key))
    top = sorted(items, key=lambda x: -(x["relevance"] + (20 if x["amount"] else 0)))[:5]
    summary = "; ".join(f"{t['title'][:140]}" + (f" ({t['vendor']})" if t["vendor"] else "") + (f" ${t['amount']:,.0f}" if t["amount"] else "") for t in top)
    c.execute("INSERT OR REPLACE INTO meeting_doc (url, meeting_id, agency_id, doc_type, title, fetched, bytes, pages, rail_pages, items, summary, summary_by, error) "
              "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", (url, meeting["meeting_id"], meeting["agency_id"], doc_type, (title or "")[:300], bc.now(), size,
                                                    npages, rail_pages, len(items), (f"{len(items)} rail items: " + summary) if items else None,
                                                    "keywords" if items else None, err))
    c.execute("UPDATE meeting SET rail_items=(SELECT count(*) FROM meeting_item WHERE meeting_id=?), "
              "top_relevance=coalesce((SELECT max(relevance) FROM meeting_item WHERE meeting_id=?),0) WHERE meeting_id=?",
              (meeting["meeting_id"], meeting["meeting_id"], meeting["meeting_id"]))
    c.commit()
    return n


def _legistar_doc_items(c, m, country):
    """Legistar: agenda item titles are structured; rail ones become items, and their staff reports are read."""
    n = 0
    for it in _legistar_items(m):
        score = kw_score("rail " + it["title"])
        if not ACTION_RX.search(it["title"]) or (score < 30 and not (score >= 20 and _category(it["title"]) != "other")):
            continue
        score = max(score, 45)
        for u in it["attachments"][:2]:
            n += read_doc(c, m, u, "report", it["title"], country)
        key = f"mtg:{m['meeting_id']}:{bc.sha(it['title'].lower())[:16]}"
        r = c.execute("INSERT OR IGNORE INTO meeting_item (source_key, meeting_id, agency_id, item_no, title, action, vendor, amount, currency, ref_no, "
                      "category, subsystems, relevance, doc_url, first_seen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (key, m["meeting_id"], m["agency_id"], it["item_no"], it["title"][:500], _action(it["title"]), _vendor(it["title"]), _amount(it["title"]),
                       "CAD" if country == "CA" else "USD", it["ref_no"], _category(it["title"]), ";".join(sorted(taxonomy.tag(it["title"]))) or None,
                       score, m.get("detail_url"), bc.now()))
        n += r.rowcount
    c.commit()
    return n


def _bench_awards(c, it, bench, suppliers):
    """An on-call bench approved on an agenda: one award row per firm, sharing a bench_id and the bench's ceiling.
    amount stays empty (the ceiling is shared, so summing it per firm would multiply it); ceiling holds it."""
    bench_id = f"{it['agency_id']}|board:{it['source_key']}"
    first = None
    for name in bench:
        a = {"source_key": f"board:{it['source_key']}:{sources.norm_vendor(name)}", "source": "board_agenda", "agency_id": it["agency_id"],
             "country": "CA" if it["currency"] == "CAD" else "US", "ref_no": it["ref_no"], "title": it["title"], "vendor": name,
             "currency": it["currency"], "award_date": it["meeting_date"], "category": it["category"], "subsystems": it["subsystems"],
             "relevance": it["relevance"], "source_url": it["doc_url"], "confidence": "B", "contract_type": "oncall", "bench_id": bench_id,
             "term_months": it["term_months"], "options_months": it["options_months"], "ceiling": it["ceiling"] or it["amount"],
             "start_date": it["start_date"], "end_date": it["end_date"],
             "notes": f"{it['body'] or 'Board'} agenda {it['meeting_date']}: on-call bench of {len(bench)} firms recommended for approval; "
                      "the ceiling is shared by the bench" + (" (meeting held; check minutes for the vote)" if it["status"] == "held" else " (meeting not yet held)")}
        if sources.add_award(c, a, suppliers) and first is None:
            first = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    c.execute("UPDATE meeting_item SET award_id=coalesce(?, -1) WHERE item_id=?", (first, it["item_id"]))
    return 1 if first else 0


def to_awards(c):
    """Agenda items recommending a contract award to a named vendor, as awards (confidence B, marked as a board recommendation)."""
    suppliers = sources.supplier_ids()
    n = 0
    ensure(c)
    for it in c.execute("SELECT i.*, m.meeting_date, m.body, m.status FROM meeting_item i JOIN meeting m USING (meeting_id) "
                        "WHERE i.award_id IS NULL AND i.action='award' AND (i.vendor IS NOT NULL OR i.firms IS NOT NULL) AND i.relevance >= ?",
                        (AWARD_MIN_REL,)).fetchall():
        bench = json.loads(it["firms"]) if it["firms"] else []
        if len(bench) >= 2:
            n += _bench_awards(c, it, bench, suppliers)
            continue
        if not it["vendor"]:
            continue
        a = {"source_key": f"board:{it['source_key']}", "source": "board_agenda", "agency_id": it["agency_id"],
             "country": "CA" if it["currency"] == "CAD" else "US", "ref_no": it["ref_no"], "title": it["title"], "vendor": it["vendor"],
             "amount": it["amount"], "currency": it["currency"], "award_date": it["meeting_date"], "category": it["category"],
             "subsystems": it["subsystems"], "relevance": it["relevance"], "source_url": it["doc_url"], "confidence": "B",
             "n_bidders": len(json.loads(it["bidders"])) if it["bidders"] else None,
             "contract_type": it["contract_type"], "term_months": it["term_months"], "options_months": it["options_months"],
             "ceiling": it["ceiling"], "start_date": it["start_date"], "end_date": it["end_date"], "parent_ref": it["parent_ref"],
             "notes": f"{it['body'] or 'Board'} agenda {it['meeting_date']}: recommended for approval" +
                      (" (meeting held; check minutes for the vote)" if it["status"] == "held" else " (meeting not yet held)")}
        if sources.add_award(c, a, suppliers):
            aid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            c.execute("UPDATE meeting_item SET award_id=? WHERE item_id=?", (aid, it["item_id"]))
            for rank, b in enumerate(sorted(json.loads(it["bidders"] or "[]"), key=lambda b: b.get("amount") or 9e18), 1):
                c.execute("INSERT INTO bid_tab (award_id, bidder, bidder_norm, amount, rank, winner, source_url) VALUES (?,?,?,?,?,?,?)",
                          (aid, b["name"], sources.norm_vendor(b["name"]), b.get("amount"), rank,
                           int(sources.norm_vendor(b["name"]) == sources.norm_vendor(it["vendor"])), it["doc_url"]))
            n += 1
    c.commit()
    return n


def run(c, agency=None, docs=True, max_docs=None):
    """Polls every active meeting source, then reads unread agenda / packet documents of recent and upcoming meetings
    (newest first, at most DOCS_PER_RUN per run). Returns (meetings seen, documents read, items found)."""
    ensure(c)
    q = "SELECT * FROM meeting_source WHERE active=1" + (" AND agency_id=?" if agency else "") + " ORDER BY coalesce(last_checked,'')"
    seen, todo = 0, []
    for src in c.execute(q, (agency,) if agency else ()).fetchall():
        try:
            ms = poll(c, src)
        except Exception as e:
            c.execute("UPDATE meeting_source SET last_checked=?, last_error=? WHERE url=?", (bc.now(), str(e)[:300], src["url"]))
            c.commit()
            continue
        seen += len(ms)
        todo += [(m, src) for m in ms]
    if not docs:
        return seen, 0, 0
    country = {r["agency_id"]: r["country"] for r in c.execute("SELECT agency_id, country FROM agency")}
    read = found = 0
    limit = max_docs or DOCS_PER_RUN
    today = dt.date.today().isoformat()
    # upcoming meetings first (their agendas are the news), then the most recent held ones
    todo.sort(key=lambda x: (x[0]["date"] < today, -int(x[0]["date"].replace("-", "")) if x[0]["date"] < today else int(x[0]["date"].replace("-", ""))))
    for m, src in todo:
        if read >= limit:
            break
        m["agency_id"] = src["agency_id"]
        cc = country.get(src["agency_id"], "US")
        try:
            if src["platform"] == "legistar" and m.get("_items_url"):
                if not c.execute("SELECT 1 FROM meeting_doc WHERE url=?", (m["_items_url"],)).fetchone():
                    found += _legistar_doc_items(c, m, cc)
                    c.execute("INSERT OR REPLACE INTO meeting_doc (url, meeting_id, agency_id, doc_type, title, fetched, items) VALUES (?,?,?,?,?,?,?)",
                              (m["_items_url"], m["meeting_id"], src["agency_id"], "agenda_items", m.get("body"), bc.now(), found))
                    read += 1
            for u, t, title in m.get("docs") or []:
                if t in ("agenda", "packet", "report") and read < limit and not c.execute("SELECT 1 FROM meeting_doc WHERE url=?", (u,)).fetchone():
                    found += read_doc(c, m, u, t, title, cc)
                    read += 1
        except Exception as e:
            bc.log(f"meetings {src['agency_id']} {m.get('date')}: {e}")
    try:
        to_awards(c)
    except Exception as e:
        bc.log(f"meetings to_awards: {e}")
    c.commit()
    return seen, read, found


def week_text(c, days=7):
    """For the Monday checklist email: rail items on agendas of the past and coming week."""
    lo = (dt.date.today() - dt.timedelta(days=days)).isoformat()
    hi = (dt.date.today() + dt.timedelta(days=days)).isoformat()
    try:
        rows = c.execute("SELECT m.agency_id, m.meeting_date, m.body, i.title, i.vendor, i.amount_usd, i.relevance FROM meeting_item i "
                         "JOIN meeting m USING (meeting_id) WHERE m.meeting_date BETWEEN ? AND ? AND i.relevance >= 45 "
                         "ORDER BY m.meeting_date, i.relevance DESC LIMIT 60", (lo, hi)).fetchall()
    except Exception:
        return ""
    if not rows:
        return ""
    lines = [f"Rail items on board agendas, {lo} to {hi}:"]
    lines += [f"- {r['meeting_date']} {r['agency_id']} {r['body'] or ''}: {r['title'][:150]}" + (f" | {r['vendor']}" if r["vendor"] else "") +
              (f" | ${r['amount_usd']:,.0f}" if r["amount_usd"] else "") for r in rows]
    return "\n".join(lines)


def claude_pass(c, max_usd):
    """Within the weekly budgets cap only: Claude reads the most rail-heavy agenda documents not yet read by budgets.read_doc,
    for richer items (stages, funding, bidders). Returns (docs, items, cost)."""
    import budgets
    budgets.ensure(c)
    cost = docs = items = 0
    suppliers = sources.supplier_ids()
    rows = c.execute("SELECT d.url, d.agency_id, m.detail_url, m.source_url FROM meeting_doc d JOIN meeting m USING (meeting_id) "
                     "WHERE d.items > 0 AND d.doc_type IN ('agenda','packet','report') AND d.url NOT IN (SELECT url FROM doc_seen) "
                     "ORDER BY d.items DESC, d.fetched DESC LIMIT 20").fetchall()
    for r in rows:
        if cost >= max_usd:
            break
        src = {"agency_id": r["agency_id"], "kind": "board_documents", "url": r["detail_url"] or r["source_url"]}
        try:
            n, k = budgets.read_doc(c, r["url"], src, suppliers)
            err = None
        except Exception as e:
            n, k, err = 0, 0.0, str(e)[:300]
        cost += k
        docs += 1
        items += n
        c.execute("INSERT OR REPLACE INTO doc_seen (url, source_url, agency_id, kind, title, read_at, items, cost_usd, error) VALUES (?,?,?,?,?,?,?,?,?)",
                  (r["url"], src["url"], r["agency_id"], "board_documents", "meeting document", bc.now(), n, round(k, 4), err))
        if n:
            c.execute("UPDATE meeting_doc SET summary_by='keywords+claude' WHERE url=?", (r["url"],))
        c.commit()
    return docs, items, cost
