"""Shared plumbing for the bid monitor: paths, bids.db, settings, logging, polite HTTP and Claude calls."""
import csv, datetime, gzip, hashlib, json, os, sqlite3, urllib.error, urllib.parse, urllib.request, urllib.robotparser

DATA = os.environ.get("FLEET_DATA", "/data")
HERE = os.path.dirname(os.path.abspath(__file__))
DIR = os.path.join(DATA, "bids")
DB = os.path.join(DATA, "bids.db")
CONFIG = os.path.join(DIR, "config.json")
LOG = os.path.join(DATA, "logs", "bids.log")
FLEET_DB = os.path.join(DATA, "fleet.db")

MODEL = os.environ.get("BIDS_MODEL", "claude-opus-5-5")
EFFORT = os.environ.get("BIDS_EFFORT", "low")
# USD per million tokens (input, output, cache write, cache read) and per web search; Claude Opus 5.5 rates
PRICE = {"in": 4.0, "out": 20.0, "cw": 5.0, "cr": 0.20, "search": 0.01}
CAD_USD = float(os.environ.get("BIDS_CAD_USD", "0.72"))

DEFAULTS = {
    "mail": {"address": "bidcatcher@echoreel.net", "from_name": "Bid Catcher",
             "imap_host": "imap.ionos.com", "imap_port": 993, "smtp_host": "smtp.ionos.com", "smtp_port": 587,
             "password_file": os.path.join(DIR, "mail_password.txt"), "folder": "INBOX", "extra_folders": ["Spam", "Junk", "Trash"]},
    # Alert emails go out from the Consist domain once its password file exists (set in Consist Admin > Bid Catcher);
    # until then they fall back to the bids mailbox above. Portal alerts and permission replies still arrive at "mail".
    "sender": {"address": "opportunity@consist-na.com", "from_name": "Consist Opportunities", "reply_to": "",
               "smtp_host": "smtp.ionos.com", "smtp_port": 587, "password_file": os.path.join(DIR, "sender_password.txt")},
    "subscribers": [
        {"name": "Justin", "email": "", "mode": "immediate", "min_score": 60, "countries": ["US", "CA"],
         "agencies": [], "categories": [], "keywords": [], "include_bus": False, "awards": True, "admin": True,
         "active": True}],
    "digest_time": "07:00",
    "page_watch": True,
    "open_data": True,
    "auto_verify": True,
    "max_usd_per_day": 2.0,
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def log(msg):
    line = f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
    print(line, flush=True)
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def settings():
    s = json.loads(json.dumps(DEFAULTS))
    if os.path.exists(CONFIG):
        user = json.load(open(CONFIG))
        for k, v in user.items():
            s[k] = {**s[k], **v} if isinstance(s.get(k), dict) and isinstance(v, dict) else v
    return s


def sender():
    """SMTP account alert emails are sent from: the Consist sender when its password file is there, else the bids mailbox."""
    s = settings()
    snd = s.get("sender") or {}
    if snd.get("address") and os.path.exists(snd.get("password_file") or ""):
        return snd
    return {**s["mail"], "reply_to": ""}


def opt(key, env, default, cast=str):
    """A schedule or cap: config.json "schedule" (set from the Consist admin) wins, then the container env, then the default.
    "off" turns a schedule off (returned as "")."""
    v = (settings().get("schedule") or {}).get(key)
    if v is None or v == "":
        v = os.environ.get(env, default)
    if v == "off":
        return ""
    return cast(v)


def save_settings(s):
    os.makedirs(DIR, exist_ok=True)
    tmp = CONFIG + ".tmp"
    with open(tmp, "w") as f:
        json.dump(s, f, indent=2)
    os.replace(tmp, CONFIG)


def connect(readonly=False):
    if readonly:
        c = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=30)
    else:
        os.makedirs(DIR, exist_ok=True)
        c = sqlite3.connect(DB, timeout=30)
        c.execute("PRAGMA journal_mode=WAL")
    c.row_factory = sqlite3.Row
    return c


def init_db(portals_csv=None):
    """Creates bids.db and loads the agency inventory and registration list (keeps edits to watch/status)."""
    c = connect()
    c.executescript(open(os.path.join(HERE, "schema.sql")).read())
    path = portals_csv or os.path.join(DIR, "portals.csv")
    if not os.path.exists(path):
        path = os.path.join(HERE, "portals.csv")
    rows = list(csv.DictReader(open(path, newline="", encoding="utf-8")))
    cols = [k for k in rows[0] if k != "watch"]
    for r in rows:
        c.execute(f"INSERT INTO agency ({','.join(cols)}) VALUES ({','.join('?' * len(cols))}) "
                  f"ON CONFLICT(agency_id) DO UPDATE SET {','.join(f'{k}=excluded.{k}' for k in cols if k != 'agency_id')}",
                  [r[k] for k in cols])
    from kit import PLATFORMS  # noqa: E402  (registration list comes from the kit's platform table)
    for key, p in PLATFORMS.items():
        agencies = ";".join(r["agency_id"] for r in rows if key in (r["account_key"] or "").split(";"))
        c.execute("INSERT INTO registration (account_key, platform, signup_url, agencies, cost, updated) VALUES (?,?,?,?,?,?) "
                  "ON CONFLICT(account_key) DO UPDATE SET platform=excluded.platform, signup_url=excluded.signup_url, "
                  "agencies=excluded.agencies, cost=excluded.cost",
                  (key, p["name"], p["signup"], agencies, p.get("cost", "free"), now()))
    c.commit()
    return c


UA = "BidCatcher/1.0 (rail procurement monitor; contact {email})"


_ROBOTS = {}


def permitted(netloc):
    """The written-permission note for a host, from config.json "feeds": {"permissions": {"host": "who, when"}}, else None.
    A host listed there is read even where its robots.txt says no; only add one when its owner has said yes in writing."""
    perms = (settings().get("feeds") or {}).get("permissions") or {}
    host = netloc.lower().split(":")[0]
    return next((v for h, v in perms.items() if v and (host == h.lower() or host.endswith("." + h.lower()))), None)


def check_robots_txt(url, ua):
    """Raises PermissionError when the site's robots.txt disallows url. robots.txt is read with a 20 s timeout
    (RobotFileParser.read() has none, and one silent server once stalled a whole backfill) and cached per host for the run."""
    p = urllib.parse.urlparse(url)
    if permitted(p.netloc):
        return  # the site owner gave written permission (config.json feeds.permissions)
    host = f"{p.scheme}://{p.netloc}"
    rp = _ROBOTS.get(host)
    if rp is None:
        rp = urllib.robotparser.RobotFileParser(host + "/robots.txt")
        try:
            req = urllib.request.Request(host + "/robots.txt", headers={"User-Agent": ua})
            with urllib.request.urlopen(req, timeout=20) as r:
                rp.parse(r.read(512 * 1024).decode("utf-8", "replace").splitlines())
        except urllib.error.HTTPError as e:
            # RFC 9309 2.3.1.3/2.3.1.4: a 4xx robots.txt is "unavailable", so there are no rules and crawling is
            # allowed (this includes 401/403, e.g. a private cloud bucket); a 5xx is "unreachable", so assume
            # complete disallow. Python's RobotFileParser.read() treats 401/403 as disallow, which the RFC does not.
            if 400 <= e.code < 500:
                rp.allow_all = True
            else:
                rp.disallow_all = True
        except Exception:
            rp.disallow_all = True  # unreachable (timeout, DNS, TLS): RFC 9309 says assume complete disallow
        _ROBOTS[host] = rp
    if not rp.can_fetch(ua, url):
        raise PermissionError(f"robots.txt disallows {url}")


def fetch(url, timeout=60, data=None, headers=None, check_robots=True):
    """GET (or POST) with an honest user agent; honours robots.txt for page watching."""
    ua = UA.format(email=settings()["mail"]["address"])
    if check_robots:
        check_robots_txt(url, ua)
    req = urllib.request.Request(url, data=data, headers={"User-Agent": ua, "Accept-Encoding": "gzip", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            body = gzip.decompress(body)
        return body, r.headers.get_content_charset() or "utf-8", r.geturl()


RENDER_URL = os.environ.get("BIDS_RENDER_URL", "")  # the bid-render service (headless Chromium), e.g. http://bid-render:3001


def render(url, wait_ms=2500):
    """The page's HTML after its JavaScript has run, from the bid-render service. robots.txt is checked here first.
    Returns (html, final_url). Raises when no renderer is configured."""
    if not RENDER_URL:
        raise RuntimeError("no renderer configured (BIDS_RENDER_URL)")
    check_robots_txt(url, UA.format(email=settings()["mail"]["address"]))
    q = urllib.parse.urlencode({"url": url, "wait": wait_ms})
    with urllib.request.urlopen(f"{RENDER_URL}/render?{q}", timeout=120) as r:
        out = json.loads(r.read())
    if out.get("error"):
        raise RuntimeError(out["error"])
    if (out.get("status") or 200) >= 400:
        raise RuntimeError(f"HTTP {out['status']} from {url}")
    return out["html"], out.get("final_url") or url


def download(url, timeout=180):
    """Stream a large open-data file to a temp file (never held in memory); returns its path. Caller deletes it."""
    import shutil, tempfile
    os.makedirs(os.path.join(DIR, "tmp"), exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": UA.format(email=settings()["mail"]["address"]), "Accept-Encoding": "gzip"})
    fd, path = tempfile.mkstemp(dir=os.path.join(DIR, "tmp"))
    with urllib.request.urlopen(req, timeout=timeout) as r, os.fdopen(fd, "wb") as out:
        src = gzip.GzipFile(fileobj=r) if r.headers.get("Content-Encoding") == "gzip" else r
        shutil.copyfileobj(src, out, 1 << 20)
    return path


def sha(text):
    return hashlib.sha256(text.encode("utf-8", "ignore")).hexdigest()


def api_key():
    path = os.environ.get("ANTHROPIC_API_KEY_FILE", os.path.join(DATA, "agent", "anthropic_api_key.txt"))
    if not os.environ.get("ANTHROPIC_API_KEY") and os.path.exists(path):
        os.environ["ANTHROPIC_API_KEY"] = open(path).read().strip()
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def cost_of(u):
    st = getattr(u, "server_tool_use", None)
    return (((u.input_tokens or 0) * PRICE["in"] + (u.output_tokens or 0) * PRICE["out"]
             + (getattr(u, "cache_creation_input_tokens", 0) or 0) * PRICE["cw"]
             + (getattr(u, "cache_read_input_tokens", 0) or 0) * PRICE["cr"]) / 1e6
            + (getattr(st, "web_search_requests", 0) or 0) * PRICE["search"])


def spent_today(c):
    r = c.execute("SELECT coalesce(sum(cost_usd), 0) FROM run_log WHERE started >= ?", (now()[:10],)).fetchone()
    return r[0]


def claude_json(system, prompt, schema, max_tokens=8000):
    """One Claude call that must answer with JSON matching schema. Returns (parsed, cost_usd)."""
    import anthropic
    client = anthropic.Anthropic()
    resp = client.beta.messages.create(
        model=MODEL, max_tokens=max_tokens, system=system, messages=[{"role": "user", "content": prompt}],
        output_config={"effort": EFFORT, "format": {"type": "json_schema", "schema": schema}},
        betas=["server-side-fallback-2026-07-01"], fallbacks="default")
    cost = cost_of(resp.usage)
    if resp.stop_reason == "refusal":
        raise RuntimeError("Claude declined the request")
    text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
    return json.loads(text), cost


def to_usd(amount, currency):
    if amount is None:
        return None
    return round(amount * CAD_USD, 2) if (currency or "").upper() == "CAD" else amount
