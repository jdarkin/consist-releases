"""Free trial (Justin, 2026-11-08): one 14-day trial per member on self-serve paid plans, no card needed. While a member's
subscription is 'trialing' they see everything on the plan except downloads and data extracts (auth.TRIAL_LOCKED: CSV/Excel
exports, CRM export, API keys), get a smaller analyst quota (setting trial_ai) and a daily page-view cap (setting trial_views).
TrialGuardMiddleware is the safety net: any CSV/Excel/JSON-download response to a trialing member becomes a 403, even from a
route that forgot to check u.can("export"). Settings live in Admin > Settings (trial_on, trial_days, trial_ai, trial_views)."""
import datetime
import time

from starlette.responses import HTMLResponse

from . import auth, db

DOWNLOAD_TYPES = ("text/csv", "application/vnd.openxmlformats", "application/vnd.ms-excel", "application/zip")
_cache = {}  # uid -> (monotonic time, trialing?)


def _setting(key, default):
    try:
        return int(db.settings().get(key) or default)
    except (ValueError, TypeError):
        return default


def days_for(user, plan):
    """Trial days for this checkout, or 0: trials on, a self-serve paid plan, and the member has never had a subscription."""
    if db.settings().get("trial_on", "1") != "1" or plan.get("contact_only") or plan.get("id") in ("free", "enterprise"):
        return 0
    if user.get("trial_used") or user.get("stripe_subscription_id") or user.get("team_owner_id"):
        return 0
    return max(0, min(30, _setting("trial_days", 14)))


def eligible(user):
    return bool(user) and days_for(user, {"id": "x"}) > 0


def _trialing(uid):
    hit = _cache.get(uid)
    if hit and time.monotonic() - hit[0] < 60:
        return hit[1]
    u = auth.load_user(uid)
    t = bool(u and u.trialing)
    if len(_cache) > 5000:
        _cache.clear()
    _cache[uid] = (time.monotonic(), t)
    return t


def views_today(uid):
    day = datetime.datetime.now(datetime.timezone.utc).date().isoformat()
    try:
        r = db.q("SELECT count(*) n FROM usage_event WHERE user_id = ? AND kind = 'view' AND ts >= ?", (uid, day), one=True)
    except Exception:  # usage table not made yet: never block a page over it
        return 0
    return r["n"] if r else 0


_PAGE = """<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>{t}</title>
<body style="font-family:system-ui;max-width:560px;margin:15vh auto;padding:0 16px;line-height:1.5"><h1>{t}</h1><p>{m}</p>
<p><a href="/app/account">Add a payment method to unlock it now</a> &middot; <a href="/app">Back to Consist</a></p></body>"""


class TrialGuardMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        uid = (scope.get("session") or {}).get("uid") if scope["type"] == "http" else None
        path = scope.get("path", "") if uid else ""
        if not uid or path.startswith(("/static", "/admin", "/stripe", "/logout", "/app/account", "/app/upgrade", "/app/billing")):
            return await self.app(scope, receive, send)
        try:
            trialing = _trialing(uid)
        except Exception:
            trialing = False
        if not trialing:
            return await self.app(scope, receive, send)
        if scope.get("method") == "GET" and path.startswith(("/app", "/rail")):
            cap = _setting("trial_views", 300)
            if cap and views_today(uid) >= cap:
                resp = HTMLResponse(_PAGE.format(t="Daily trial limit reached", m=f"Free trials include {cap} pages a day. It resets at midnight UTC."), status_code=429)
                return await resp(scope, receive, send)
        blocked = {"on": False}

        async def guard(msg):
            if msg["type"] == "http.response.start":
                ctype = dict((k.lower(), v) for k, v in msg.get("headers", [])).get(b"content-type", b"").decode("latin-1")
                disp = dict((k.lower(), v) for k, v in msg.get("headers", [])).get(b"content-disposition", b"").decode("latin-1")
                if ctype.startswith(DOWNLOAD_TYPES) or "attachment" in disp:
                    blocked["on"] = True
                    resp = HTMLResponse(_PAGE.format(t="Downloads start with your paid plan", m="Exports and data downloads are not included in the free trial."), status_code=403)
                    return await resp(scope, receive, send)
            elif blocked["on"]:
                return
            await send(msg)
        await self.app(scope, receive, guard)
