"""1.7.61 Market Explorer (Justin 11-17): one map, a filter rail and a table that stay in step, plus an "In view" summary, for
every operator in the member's lens and territory. Each operator row joins its fleets (fleet.db), overhauls due in the next five
years (overhaul_projection), open bids and the last two years of awards (bids.db, through agency.fleet_operator_ids) and the
estimated yearly consumables spend (consumables estimates). Self-contained: this file, templates/app/explorer.html and one
include line in main.py. The member-facing name lives only in LABEL / TITLE below so it can be renamed in one place."""
import csv
import datetime
import json
import os

from fastapi import APIRouter, Depends, Request

from . import auth, data, db, lens

LABEL = "Market Explorer"          # menu label (one place to rename)
TITLE = "Consist Market Explorer"  # page title
PATH = "/app/explorer"

router = APIRouter(prefix="/app")
U = Depends(auth.require_user)

# State and province centroids: where an operator sits when neither it nor its bid agency has a head-office point on file
# (marked "approx." in the popup).
CENTROIDS = {
    "AL": (32.8, -86.8), "AK": (61.4, -152.3), "AZ": (34.2, -111.7), "AR": (34.9, -92.4), "CA": (36.8, -119.4), "CO": (39.0, -105.5),
    "CT": (41.6, -72.7), "DE": (39.0, -75.5), "DC": (38.9, -77.0), "FL": (28.6, -82.4), "GA": (32.7, -83.4), "HI": (21.3, -157.8),
    "ID": (44.4, -114.6), "IL": (40.0, -89.2), "IN": (39.9, -86.3), "IA": (42.1, -93.5), "KS": (38.5, -98.4), "KY": (37.5, -85.3),
    "LA": (31.1, -92.0), "ME": (45.4, -69.2), "MD": (39.0, -76.8), "MA": (42.3, -71.8), "MI": (44.3, -85.4), "MN": (46.3, -94.3),
    "MS": (32.7, -89.7), "MO": (38.4, -92.5), "MT": (47.0, -109.6), "NE": (41.5, -99.8), "NV": (39.3, -116.6), "NH": (43.7, -71.6),
    "NJ": (40.2, -74.7), "NM": (34.4, -106.1), "NY": (42.9, -75.5), "NC": (35.6, -79.4), "ND": (47.5, -100.5), "OH": (40.3, -82.8),
    "OK": (35.6, -97.5), "OR": (43.9, -120.6), "PA": (40.9, -77.8), "RI": (41.7, -71.5), "SC": (33.9, -80.9), "SD": (44.4, -100.2),
    "TN": (35.9, -86.4), "TX": (31.5, -99.3), "UT": (39.3, -111.7), "VT": (44.1, -72.7), "VA": (37.5, -78.9), "WA": (47.4, -120.5),
    "WV": (38.6, -80.6), "WI": (44.6, -89.9), "WY": (43.0, -107.6), "PR": (18.2, -66.5),
    "AB": (53.9, -116.6), "BC": (53.7, -127.6), "MB": (53.8, -98.8), "NB": (46.5, -66.2), "NL": (53.1, -57.7), "NS": (45.0, -63.0),
    "ON": (44.5, -79.5), "PE": (46.4, -63.2), "QC": (46.8, -71.2), "SK": (52.9, -106.5), "YT": (64.3, -135.0), "NT": (64.8, -124.8),
}
YEARS_AHEAD = 5
AWARD_DAYS = 730


_XGEO = {}


def _geo():
    """Agency head offices (seed/agency_geo.csv, 1.7.51) plus operator points (seed/explorer_geo.csv) for operators whose id
    differs from their bid agency's. Upper-case id -> (lat, lon, place)."""
    from . import coverage
    out = dict(coverage.geo())
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "explorer_geo.csv")
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return out
    if _XGEO.get("mt") != mt:
        m = {}
        with open(path, newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                try:
                    m[r["operator_id"].strip().upper()] = (float(r["lat"]), float(r["lon"]), r.get("place") or "")
                except (KeyError, ValueError):
                    continue
        _XGEO.update(mt=mt, m=m)
    out.update(_XGEO["m"])
    return out


def _consumables():
    """operator_id -> estimated yearly consumables and component spend (USD, mid case)."""
    out = {}
    try:
        rows = [dict(r) for r in db.fq("SELECT operator_id, usd_mid FROM operator_consumable_estimate")]
    except Exception:
        rows = None
    if rows is None:
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "consumables", "estimate_operator_component.csv")
        try:
            with open(path, newline="", encoding="utf-8") as fh:
                rows = list(csv.DictReader(fh))
        except OSError:
            rows = []
    for r in rows:
        try:
            out[r["operator_id"]] = out.get(r["operator_id"], 0) + float(r["usd_mid"] or 0)
        except (KeyError, TypeError, ValueError):
            continue
    return out


def _overhauls(start):
    sw, sa = data.scope_sql()
    try:
        rows = db.fq("SELECT p.operator_id, count(DISTINCT op.fleet_id) fleets, sum(p.qty_active) cars, min(op.projected_due_year) first "
                     "FROM overhaul_projection op JOIN v_fleet_profile p USING (fleet_id) JOIN operator o USING (operator_id) "
                     f"WHERE op.projected_due_year BETWEEN ? AND ? AND coalesce(p.qty_active,0) > 0 AND {sw} GROUP BY 1",
                     [start, start + YEARS_AHEAD - 1] + sa)
        return {r["operator_id"]: dict(r) for r in rows}
    except Exception:
        return {}


def _bids_side():
    """(operator_id -> [agency ids], agency_id -> open bids, (agency_id|operator_id) -> [awards, usd])."""
    op_ags = {}
    for r in data._bq_safe("SELECT agency_id, fleet_operator_ids FROM agency"):
        for o in (r.get("fleet_operator_ids") or "").replace(",", ";").split(";"):
            if o.strip():
                op_ags.setdefault(o.strip(), []).append(r["agency_id"])
    open_b = {r["agency_id"]: r["n"] for r in data._bq_safe(
        f"SELECT n.agency_id, count(*) n FROM notice n WHERE {data.open_clause()} AND coalesce(n.relevance, n.kw_score, 0) >= 50 "
        "AND coalesce(n.notice_type, '') != 'award' GROUP BY 1")}
    aw = {}
    for r in data._bq_safe("SELECT agency_id, operator_id, count(*) n, sum(amount_usd) usd FROM award WHERE relevance >= 50 "
                           "AND award_date >= date('now', ?) GROUP BY 1, 2", (f"-{AWARD_DAYS} days",)):
        aw[(r.get("agency_id"), r.get("operator_id"))] = (r["n"] or 0, r["usd"] or 0)
    return op_ags, open_b, aw


def rows():
    sc = lens.current()
    year = datetime.date.today().year
    g, cons, oh = _geo(), _consumables(), _overhauls(year)
    op_ags, open_b, aw = _bids_side()
    out = []
    for o in data.operators():
        oid = o["operator_id"]
        if sc.territory and oid not in (sc.ter_ops or ()):
            continue
        ags = sorted(set(op_ags.get(oid, [])) | ({oid} if oid in open_b or oid in g else set()))
        loc, approx = g.get(oid.upper()), 0
        for a in ags:
            loc = loc or g.get(a.upper())
        states = [s for s in (o.get("states") or "").replace(",", ";").split(";") if s.strip()]
        if not loc and states and states[0].strip() in CENTROIDS:
            c = CENTROIDS[states[0].strip()]
            loc, approx = (c[0], c[1], states[0].strip()), 1
        n_aw = usd_aw = 0
        seen = set()
        for (ag, op), (n, usd) in aw.items():
            if (op == oid or (ag in ags and not op)) and (ag, op) not in seen:
                seen.add((ag, op))
                n_aw += n
                usd_aw += usd
        h = oh.get(oid, {})
        avg = o.get("avg_build")
        out.append({
            "id": oid, "n": o.get("operator_name") or oid, "co": o.get("country") or "", "st": [s.strip() for s in states],
            "md": [m for m in (o.get("modes") or "").split(";") if m], "cat": o.get("category") or "",
            "lat": loc[0] if loc else None, "lon": loc[1] if loc else None, "ap": approx, "pl": loc[2] if loc else "",
            "fl": o.get("fleets") or 0, "cars": int(o.get("cars") or 0), "age": (year - int(avg)) if avg else None,
            "old": o.get("oldest"), "cpm": o.get("maint_cpm"),
            "ohf": h.get("fleets") or 0, "ohc": int(h.get("cars") or 0), "oh1": h.get("first"),
            "ob": sum(open_b.get(a, 0) for a in ags), "aw": n_aw, "awu": round(usd_aw or 0),
            "cs": round(cons.get(oid, 0)), "ags": ags,
        })
    return out


def allowed(u):
    """Paid feature: members whose plan opens fleet detail (or admins). Bid and award columns follow the Bids access."""
    return u.is_admin or u.can("fleet_detail")


@router.get("/explorer")
def explorer_page(request: Request, u=U):
    from .main import render
    if not allowed(u):
        return render(request, "app/locked.html", user=u, feature="fleet_detail", title=LABEL)
    rs = rows()
    if not u.bids:
        for r in rs:
            r["ob"] = r["aw"] = r["awu"] = None
    pts = json.dumps(rs).replace("</", "<\\/")
    return render(request, "app/explorer.html", user=u, pts=pts, n=len(rs), LABEL=LABEL, TITLE=TITLE, MODES=data.MODES,
                  can_export=u.is_admin or u.can("export"), show_bids=bool(u.bids), years=YEARS_AHEAD, year=datetime.date.today().year)
