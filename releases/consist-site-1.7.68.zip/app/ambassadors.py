"""Ambassadors: people the admin invites to a free subscription with full access, with no Stripe involved (Justin, 2026-11-02).

Admin > Ambassadors sends an invite link (valid 30 days). Accepting it creates the account (or upgrades an existing one) on the
chosen plan, normally US & Canada - Rail Expert, with sub_status 'ambassador' and an optional end date (user.comp_until). auth.billing_ok
honours it like a paid subscription until that date, after which the member drops to Free. Revoking ends it at once."""
import logging

from . import auth, config, db, mailer

log = logging.getLogger("consist.ambassadors")

INVITE_DAYS = 30


def default_plan():
    return "enterprise"


def rows():
    out = []
    for r in db.q("SELECT a.*, u.sub_status, u.plan_id cur_plan, u.comp_until, u.stripe_subscription_id FROM ambassador a "
                  "LEFT JOIN user u ON u.id = a.user_id ORDER BY a.id DESC"):
        d = dict(r)
        if d["revoked"]:
            d["state"] = "revoked"
        elif not d["accepted"]:
            d["state"] = "invited" if auth.use_token(d["token"], "ambassador", consume=False) else "link expired"
        elif d["sub_status"] != "ambassador":
            d["state"] = "ended"
        elif d["comp_until"] and d["comp_until"] < db.now()[:10]:
            d["state"] = "expired"
        else:
            d["state"] = "active"
        d["link"] = f"{config.SITE_URL}/ambassador/{d['token']}" if d["state"] == "invited" else ""
        d["copy_text"] = ""
        if d["link"]:  # 1.7.46: the letter as plain text, to paste into Outlook, Gmail or LinkedIn from the admin's own mailbox
            try:
                subj, text, _ = compose(d, d["link"])
                d["copy_text"] = f"Subject: {subj}\n\n{text}"
            except Exception:
                log.exception("ambassador copy text %s", d["id"])
        out.append(d)
    return out


def invite(email, name, plan_id, until, note, actor, send=True, note_html="", subject="", note_full=False, linkedin=""):
    """Creates the invite and emails it. Returns (row id, emailed?). note_html is the admin's rich-text note (sanitized here)."""
    from . import richtext
    note_html = richtext.clean(note_html)
    if note_html:
        note = richtext.to_text(note_html)
    tok = auth.make_token("ambassador", None, email, hours=24 * INVITE_DAYS)
    note_full = bool((note_full or (note_html and richtext.is_letter(note_html))) and (note_html or note))
    aid = db.x("INSERT INTO ambassador (email, name, note, note_html, subject, note_full, linkedin, plan_id, until, token, invited_by, created) "
               "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
               (email, name, note, note_html or None, (subject or "").strip()[:150] or None, int(note_full),
                (linkedin or "").strip()[:300] or None, plan_id, until or None, tok, actor, db.now()))
    db.audit("ambassador_invite", f"{email} {plan_id} until {until or 'open-ended'}", None, actor)
    return aid, (send_invite(aid) if send else False)


def esc(s):
    return __import__("html").escape(str(s or ""))


def legal_line(site):
    ent = (db.settings().get("legal_entity") or "").strip()
    return f"{site} is a trade name of {ent}" if ent else site


def email_html(site, inner, link, button, small):
    """Branded, email-client-safe layout (tables and inline styles only, no images)."""
    host = config.SITE_URL.split("//")[-1].rstrip("/")
    from . import richtext
    inner = richtext.email_safe(inner)
    return (
        '<!doctype html><html><body style="margin:0;padding:0;background:#f4f1ea">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f1ea"><tr><td align="center" style="padding:28px 12px">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:580px;background:#ffffff;border:1px solid #e4ded2;border-radius:10px">'
        f'<tr><td style="padding:22px 32px;border-bottom:3px solid #0b6b5d;font-family:Arial,Helvetica,sans-serif;font-size:20px;font-weight:bold;color:#084a40;letter-spacing:.3px">{esc(site)}</td></tr>'
        f'<tr><td style="padding:26px 32px 8px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#222">{inner}</td></tr>'
        '<tr><td style="padding:6px 32px 26px"><table role="presentation" cellpadding="0" cellspacing="0"><tr>'
        f'<td style="background:#0b6b5d;border-radius:6px"><a href="{esc(link)}" style="display:inline-block;padding:12px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:bold;color:#ffffff;text-decoration:none">{esc(button)}</a></td>'
        f'</tr></table><p style="margin:14px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#666">{esc(small)}</p></td></tr>'
        f'<tr><td style="padding:16px 32px;border-top:1px solid #eee;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#888">{esc(legal_line(site))} · '
        f'<a href="{esc(config.SITE_URL)}" style="color:#0b6b5d">{esc(host)}</a></td></tr>'
        '</table></td></tr></table></body></html>')


def nice_date(d):
    try:
        import datetime
        x = datetime.date.fromisoformat(str(d)[:10])
        return f"{x:%B} {x.day}, {x.year}"
    except ValueError:
        return str(d)


def compose(a, link):
    """(subject, text, html) for an invite row (or a dict with the same keys, for Preview)."""
    from . import richtext
    site = db.settings().get("site_name", "Consist")
    plan = db.get_plan(a["plan_id"])
    until = f" through {nice_date(a['until'])}" if a.get("until") else ""
    first = (a.get("name") or "").split()
    hi = first[0] if first else "there"
    note_html = a.get("note_html") or richtext.from_text(a.get("note") or "")
    note_text = richtext.to_text(note_html)
    small = f"This setup link works for {INVITE_DAYS} days" + (f"; your access runs{until}." if until else ".")
    # Plain, personal wording: words like "free", "no card or payment" and "invitation" push mail toward junk folders
    intro = (f"I'd like you to be one of the first {site} Ambassadors. That means full access to {plan['name']}{until}, "
             "in exchange for your honest feedback on what works and what we should add.")
    if a.get("note_full") or (note_html and richtext.is_letter(note_html)):  # the note is the whole letter, with its own greeting
        text = note_text + f"\n\nSet up your account here ({small[0].lower() + small[1:]}):\n{link}\n\n{site}\n{config.SITE_URL}"
        html = email_html(site, note_html, link, f"Set up your {site} account", small)
    else:
        text = (f"Hi {hi},\n\n" + (note_text + "\n\n" if note_text else "") + intro + "\n\n"
                f"To set up your account, open this link ({small[0].lower() + small[1:]}):\n{link}\n\n"
                f"If you have questions, just reply to this email.\n\n{site}\n{config.SITE_URL}")
        html = email_html(site, f"<p>Hi {esc(hi)},</p>" + note_html + f"<p>{esc(intro)}</p>",
                          link, f"Set up your {site} account", small + " If you have questions, just reply to this email.")
    subj = a.get("subject") or (f"{first[0]}, join {site} as an Ambassador" if first else f"Join {site} as an Ambassador")
    return subj, text, html


def send_invite(aid):
    a = db.q("SELECT * FROM ambassador WHERE id = ?", (aid,), one=True)
    if not a:
        return False
    ok, err = False, ""
    try:
        subj, text, html = compose(dict(a), f"{config.SITE_URL}/ambassador/{a['token']}")
        from . import unsub
        if not mailer.configured():
            err = "email is not set up on the server"
        elif unsub.is_out(a["email"]):
            err = "this address opted out of Consist email"
        else:
            ok = mailer.send(a["email"], subj, text, html, optional=True, personal=True)
            err = "" if ok else "the mail server did not accept it"
    except Exception as ex:
        log.exception("ambassador invite %s failed", aid)
        ok, err = False, f"{type(ex).__name__}: {ex}"[:300]
    # 1.7.46: keep the result on the row, so Admin > Ambassadors shows why an invite was not emailed
    db.x("UPDATE ambassador SET sent = ?, send_error = ? WHERE id = ?", (db.now() if ok else None, err or None, aid))
    return ok


def renew(aid):
    """A fresh invite link (the old one stops working)."""
    a = db.q("SELECT * FROM ambassador WHERE id = ?", (aid,), one=True)
    if not a or a["accepted"] or a["revoked"]:
        return False
    db.x("UPDATE token SET used = 1 WHERE token = ?", (a["token"],))
    tok = auth.make_token("ambassador", None, a["email"], hours=24 * INVITE_DAYS)
    db.x("UPDATE ambassador SET token = ? WHERE id = ?", (tok, aid))
    return send_invite(aid)


def pending(tok):
    if not auth.use_token(tok, "ambassador", consume=False):
        return None
    a = db.q("SELECT * FROM ambassador WHERE token = ? AND revoked IS NULL AND accepted IS NULL", (tok,), one=True)
    return dict(a) if a else None


def grant(uid, a):
    db.x("UPDATE user SET plan_id = ?, sub_status = 'ambassador', comp_until = ?, team_owner_id = NULL WHERE id = ?",
         (a["plan_id"], a["until"], uid))


def accept(tok, name="", password=""):
    """Returns the user id, creating the account when the email is new (password required then)."""
    a = pending(tok)
    if not a:
        return None
    u = db.q("SELECT id FROM user WHERE email = ?", (a["email"],), one=True)
    uid = u["id"] if u else auth.create_user(a["email"], password, name or a["name"] or "")
    grant(uid, a)
    auth.use_token(tok, "ambassador")
    db.x("UPDATE ambassador SET user_id = ?, accepted = ? WHERE id = ?", (uid, db.now(), a["id"]))
    db.audit("ambassador_accepted", a["email"], uid)
    return uid


def set_until(aid, until):
    a = db.q("SELECT * FROM ambassador WHERE id = ?", (aid,), one=True)
    if not a:
        return
    db.x("UPDATE ambassador SET until = ? WHERE id = ?", (until or None, aid))
    if a["user_id"]:
        db.x("UPDATE user SET comp_until = ? WHERE id = ? AND sub_status = 'ambassador'", (until or None, a["user_id"]))


def revoke(aid, actor):
    a = db.q("SELECT * FROM ambassador WHERE id = ?", (aid,), one=True)
    if not a:
        return
    db.x("UPDATE ambassador SET revoked = ? WHERE id = ?", (db.now(), aid))
    db.x("UPDATE token SET used = 1 WHERE token = ?", (a["token"],))
    if a["user_id"]:
        db.x("UPDATE user SET plan_id = 'free', sub_status = NULL, comp_until = NULL WHERE id = ? AND sub_status = 'ambassador'", (a["user_id"],))
    db.audit("ambassador_revoked", a["email"], a["user_id"], actor)
