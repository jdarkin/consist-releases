"""Sales intelligence on top of fleet.db: per-fleet signals, reliability, spares, energy, opportunity sizing, suppliers and market share.

fleet.db stays read-only. Things the site's own team keeps (unit costs, planned programs, funding awards, contracts and warranties,
Canadian costs, saved lists, account notes and contacts, detected fleet changes) live in app.db, in the tables below. Admins edit the
market-intel tables in Admin > Market intel; members keep their own lists, notes and contacts.

The fleet snapshot is built once per fleet.db version (keyed on the file's mtime) and shared by every page."""
import datetime
import hashlib
import json
import os
import re
import statistics
import threading

from . import config, data, db, lens, units
from .parents import parent as _parent

SCHEMA = """
CREATE TABLE IF NOT EXISTS unit_cost (
  event TEXT NOT NULL, vehicle_class TEXT NOT NULL DEFAULT '*', usd_per_car REAL NOT NULL, basis TEXT, source_url TEXT, updated TEXT,
  PRIMARY KEY (event, vehicle_class));
CREATE TABLE IF NOT EXISTS plan_event (
  id INTEGER PRIMARY KEY, operator_id TEXT NOT NULL, fleet_id INTEGER, event_type TEXT NOT NULL, title TEXT, qty INTEGER,
  year_planned INTEGER, funded TEXT, value_usd REAL, confidence TEXT DEFAULT 'C', source_url TEXT, notes TEXT, created TEXT,
  UNIQUE (operator_id, title));
CREATE TABLE IF NOT EXISTS funding_award (
  id INTEGER PRIMARY KEY, operator_id TEXT NOT NULL, program TEXT NOT NULL, grantor TEXT, amount_usd REAL, award_date TEXT,
  purpose TEXT, fleet_id INTEGER, confidence TEXT DEFAULT 'B', source_url TEXT, notes TEXT, created TEXT,
  UNIQUE (operator_id, program, award_date, purpose));
CREATE TABLE IF NOT EXISTS fleet_contract (
  id INTEGER PRIMARY KEY, operator_id TEXT NOT NULL, fleet_id INTEGER, kind TEXT NOT NULL, vendor TEXT, start_date TEXT, end_date TEXT,
  value_usd REAL, confidence TEXT DEFAULT 'C', source_url TEXT, notes TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS operator_cost_manual (
  id INTEGER PRIMARY KEY, operator_id TEXT NOT NULL, mode TEXT, report_year INTEGER NOT NULL, currency TEXT DEFAULT 'CAD',
  opex_total REAL, vehicle_maint REAL, car_km REAL, active_cars INTEGER, usd_per_unit REAL DEFAULT 0.73, confidence TEXT DEFAULT 'C',
  source_url TEXT, notes TEXT, created TEXT, UNIQUE (operator_id, mode, report_year));
CREATE TABLE IF NOT EXISTS fleet_list (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, name TEXT NOT NULL, created TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS fleet_list_item (list_id INTEGER NOT NULL, fleet_id INTEGER NOT NULL, note TEXT, added TEXT, PRIMARY KEY (list_id, fleet_id));
CREATE TABLE IF NOT EXISTS account_note (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, operator_id TEXT NOT NULL, fleet_id INTEGER,
  body TEXT NOT NULL, author TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS contact (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, operator_id TEXT NOT NULL, name TEXT NOT NULL,
  title TEXT, email TEXT, phone TEXT, notes TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS fleet_snapshot (fleet_id INTEGER PRIMARY KEY, vals TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS fleet_event (id INTEGER PRIMARY KEY, ts TEXT, fleet_id INTEGER, operator_id TEXT, kind TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS user_pref (user_id INTEGER, key TEXT, value TEXT, PRIMARY KEY (user_id, key));
"""

# What a seller can be selling. The opportunity finder sizes each fleet event for the chosen offering.
OFFERINGS = {"vehicles": "New vehicles (replacement)", "overhaul": "Overhaul and rebuild programs", "repower": "Locomotive repower / Tier 4",
             "services": "Maintenance services"}
COMPONENTS = {"hvac": "HVAC", "doors": "Doors", "brakes": "Brakes", "trucks": "Trucks", "propulsion_traction": "Propulsion and traction",
              "vehicle_control": "Vehicle control / TCMS", "pis_passenger_info": "Passenger information", "cctv": "CCTV",
              "coupler": "Couplers"}
for _k, _v in COMPONENTS.items():
    OFFERINGS[f"component:{_k}"] = f"Components: {_v}"

EVENT_LABELS = {"replace": "Replacement", "midlife": "Midlife overhaul", "engine": "Engine overhaul", "repower": "Repower",
                "retrofit": "Component retrofit", "services": "Maintenance spend (per year)", "plan": "Announced program"}

PLAN_TYPES = {"replace": "Replacement", "order": "New order", "option": "Option exercise", "overhaul": "Overhaul program",
              "retire": "Retirement", "study": "Study or planning", "expansion": "Fleet expansion"}
CONTRACT_KINDS = {"warranty": "Warranty", "maintenance": "Maintenance contract", "tsa": "Technical support / spares (TSA)",
                  "overhaul": "Overhaul contract", "operations": "Operations contract", "om": "Operations and maintenance",
                  "mow": "Maintenance of way", "concession": "P3 / DBFOM concession", "facility": "Facility and station maintenance"}

# Default unit costs per car (constant US dollars). Rough planning numbers, grade D: admins replace them with cited figures.
DEFAULT_COSTS = {
    "replace": {"coach": 3.0e6, "cab_car": 3.3e6, "locomotive": 8.5e6, "emu": 3.5e6, "dmu": 4.0e6, "metro_car": 2.6e6, "lrv": 4.5e6,
                "streetcar": 5.0e6, "heritage_streetcar": 1.5e6, "agt_vehicle": 4.0e6, "monorail_car": 4.0e6, "cable_car": 1.0e6,
                "incline_car": 1.5e6, "*": 3.5e6},
    "midlife": {"coach": 0.9e6, "cab_car": 1.0e6, "locomotive": 2.5e6, "emu": 1.1e6, "dmu": 1.2e6, "metro_car": 0.8e6, "lrv": 1.3e6,
                "streetcar": 1.4e6, "heritage_streetcar": 0.5e6, "agt_vehicle": 1.2e6, "monorail_car": 1.2e6, "*": 1.0e6},
    "engine": {"locomotive": 1.0e6, "dmu": 0.4e6, "*": 0.6e6},
    "repower": {"locomotive": 2.2e6, "dmu": 0.6e6, "*": 1.5e6},
    "hvac": {"*": 120e3}, "doors": {"*": 60e3}, "brakes": {"*": 80e3}, "trucks": {"*": 150e3}, "propulsion_traction": {"*": 400e3},
    "vehicle_control": {"*": 150e3}, "pis_passenger_info": {"*": 40e3}, "cctv": {"*": 25e3}, "coupler": {"*": 30e3},
}
COST_BASIS = "Consist planning estimate (grade D); replace with cited figures"

SIGNALS = {
    "past_ulb": ("Past useful life", "bad"), "ulb_soon": ("Useful life ends soon", "warn"), "midlife_due": ("Midlife due", "warn"),
    "cost_high": ("Cost well above peers", "bad"), "reliability_low": ("Reliability below peers", "bad"),
    "reliability_falling": ("Reliability falling", "warn"), "bid_recent": ("Recent bid", "accent"), "funded": ("Recent funding", "ok"),
    "planned": ("Announced program", "ok"), "spare_tight": ("Tight spare ratio", "warn"), "warranty_ending": ("Warranty ending", "accent"),
    "repower_candidate": ("Pre-Tier 4 diesel", "warn"),
}

# Where each signal's evidence lives: a card on the fleet page, the operator page, or the bid feed.
SIG_TARGETS = {"past_ulb": "timing", "ulb_soon": "timing", "midlife_due": "timing", "repower_candidate": "timing", "cost_high": "cost",
               "reliability_low": "reliability", "reliability_falling": "reliability", "spare_tight": "reliability",
               "planned": "programs", "warranty_ending": "programs", "funded": "op:programs", "bid_recent": "bids"}


# 1.8.16 (Justin 11-23): "Announced program", "Recent bid" and "Recent funding" pills open the original document the signal came
# from. Bids go only to the agency posting or the agency's bidding portal, never to an aggregator.
SOURCE_SIGS = ("planned", "bid_recent", "funded")
AGGREGATOR_HOSTS = ("bidnet", "govspend", "periscope", "demandstar", "bidprime", "govwin", "deltek", "onvia", "findrfp", "rfpdb",
                    "bidsusa", "govtribe", "highergov", "instantmarkets", "mygovwatch", "bidsync", "govdirections", "rfpmart")
NO_SOURCE_WHY = {
    "planned": "No source document is on file for this program yet (it comes from our fleet research notes).",
    "bid_recent": "We could not find the agency posting or the agency's bidding portal for this bid.",
    "funded": "No source document is on file for this funding award yet."}


def source_ok(u):
    """An http(s) link that is not a bid aggregator."""
    u = (u or "").strip()
    if not re.match(r"(?i)^https?://", u):
        return ""
    host = re.sub(r"(?i)^https?://", "", u).split("/")[0].lower()
    return "" if any(a in host for a in AGGREGATOR_HOSTS) else u


def _resolve_bid_sources(fleet_bids):
    """Add the agency posting (or bidding portal) link to each fleet bid: (date, title, info) -> info['src'] = (label, url)."""
    infos = [v[2] for v in fleet_bids.values() if len(v) > 2]
    if not infos:
        return
    rows = {i["notice_id"]: dict(i, url=source_ok(i.get("url"))) for i in infos}
    try:
        from . import alerts
        got = alerts.sources(list(rows.values()))
    except Exception:
        got = {}
    for i in infos:
        lab, u = got.get(i["notice_id"], ("", ""))
        if source_ok(u):
            i["src"] = (lab, u)


def _budget_plan_docs():
    """operator_id -> [budget_item rows with a source document] from the agency board, budget and capital plan documents Bid Catcher
    reads; used to find the document behind an announced program that has no link of its own."""
    out = {}
    try:
        rows = db.bq("SELECT operator_id, project, description, doc_title, doc_date, source_url FROM budget_item WHERE operator_id IS NOT NULL "
                     "AND coalesce(source_url,'') LIKE 'http%' AND stage IN ('planned','budgeted','authorized') ORDER BY doc_date DESC")
    except Exception:
        return out
    for r in rows:
        out.setdefault(r["operator_id"], []).append(dict(r))  # 1.8.17: plain dicts (_sig_sources calls .get)
    return out


def _sig_sources(f, fleet_bids, funds, cutoff, budget_plans):
    """{code: (label, url)} for the source-backed pills of fleet f."""
    out = {}
    v = fleet_bids.get(f["fleet_id"])
    if v and len(v) > 2 and v[2].get("src"):
        out["bid_recent"] = v[2]["src"]
    src = next((source_ok(p.get("source_url")) for p in (f.get("plans") or []) if source_ok(p.get("source_url"))), "")
    if src:
        out["planned"] = ("the announcement", src)
    elif f.get("plans") or f.get("planned_text") or f.get("planned_retirement_year"):
        words = [w for w in {(f.get("model_name") or "").lower()} if len(w) >= 3]
        rx = _CLASS_RX.get(f.get("vehicle_class"))
        for b in budget_plans.get(f["operator_id"], []):
            text = " ".join(str(b.get(k) or "") for k in ("project", "description"))
            if any(re.search(r"(?<![a-z0-9])" + re.escape(w) + r"(?![a-z0-9])", text.lower()) for w in words) or (rx and rx.search(text)):
                if source_ok(b["source_url"]):
                    out["planned"] = (b.get("doc_title") or "the agency document", b["source_url"])
                    break
    fu = sorted((r for r in funds if r["operator_id"] == f["operator_id"] and (r["award_date"] or "") >= cutoff and source_ok(r.get("source_url"))),
                key=lambda r: (r["fleet_id"] != f["fleet_id"], -(int((r["award_date"] or "0")[:4] or 0))))
    if fu:
        out["funded"] = (fu[0].get("program") or "the award", fu[0]["source_url"])
    return out


def sig_source(code, fl):
    """(label, url) of the original document behind a pill, or None."""
    if not fl or code not in SOURCE_SIGS:
        return None
    return ((fl.get("sig_src") if hasattr(fl, "get") else None) or {}).get(code)


def sig_href(code, fl=None, op=None):
    """Link for a signal pill: the card behind it on a fleet page, or (operator header) the operator's fleets with that signal."""
    if fl:
        src = sig_source(code, fl)
        if src:
            return src[1]
        if code in SOURCE_SIGS:
            return None  # 1.8.16: no source document; the pill shows why on hover instead of linking elsewhere
        t = SIG_TARGETS.get(code, "timing")
        if t == "bids":
            return f"/app/bids?status=all&operator={fl['operator_id']}"
        if t.startswith("op:"):
            return f"/app/operators/{fl['operator_id']}#{t[3:]}"
        return f"/app/fleets/{fl['fleet_id']}#{t}"
    if op:
        return f"/app/fleets?operator={op}&signal={code}"
    return None


_cache = {}  # freight visible (True/False) -> {"key", "snap"}
_scoped = {}
_lock = threading.Lock()


def init():
    c = db.connect()
    try:
        c.executescript(SCHEMA)
        have = {r[1] for r in c.execute("PRAGMA table_info(fleet_contract)")}
        for col in ("mode TEXT", "scope TEXT", "options_end TEXT", "annual_usd REAL"):  # O&M contracts (om.py)
            if col.split()[0] not in have:
                c.execute(f"ALTER TABLE fleet_contract ADD COLUMN {col}")
        for ev, by_cls in DEFAULT_COSTS.items():
            for cls, usd in by_cls.items():
                c.execute("INSERT OR IGNORE INTO unit_cost (event, vehicle_class, usd_per_car, basis, updated) VALUES (?,?,?,?,?)",
                          (ev, cls, usd, COST_BASIS, db.now()))
        c.commit()
    finally:
        c.close()
    seed_intel()
    from . import om
    om.seed()


def seed_intel():
    """Researched intel shipped with the site (seed/intel_seed.json). Rows already present are left alone."""
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "seed", "intel_seed.json")
    if not os.path.exists(path):
        return
    with open(path, "rb") as fh:
        raw = fh.read()
    digest = hashlib.sha256(raw).hexdigest()[:16]
    if db.settings().get("intel_seed_hash") == digest:  # load each version once, so admin edits and deletes stick
        return
    seed = json.loads(raw)
    c = db.connect()
    try:
        for table, rows in seed.items():
            if table not in ("plan_event", "funding_award", "fleet_contract", "operator_cost_manual"):
                continue
            for r in rows:
                r = dict(r, created=r.get("created") or db.now())
                if table == "fleet_contract" and c.execute(
                        "SELECT 1 FROM fleet_contract WHERE operator_id = ? AND coalesce(fleet_id, 0) = ? AND kind = ? AND coalesce(vendor, '') = ?",
                        (r["operator_id"], r.get("fleet_id") or 0, r["kind"], r.get("vendor") or "")).fetchone():
                    continue
                cols = list(r)
                c.execute(f"INSERT OR IGNORE INTO {table} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", [r[k] for k in cols])
        c.commit()
    finally:
        c.close()
    db.set_setting("intel_seed_hash", digest)


def this_year():
    return datetime.date.today().year


# ---------------- unit costs and sizing ----------------

def unit_costs():
    out = {}
    for r in db.q("SELECT * FROM unit_cost"):
        out.setdefault(r["event"], {})[r["vehicle_class"]] = r["usd_per_car"]
    return out


def unit_cost(costs, event, cls):
    by = costs.get(event) or {}
    return by.get(cls or "*", by.get("*"))


# ---------------- the fleet snapshot ----------------

def _fleet_key():
    try:
        st = os.stat(config.FLEET_DB)
        b = os.stat(config.BIDS_DB) if os.path.exists(config.BIDS_DB) else None
        return (st.st_mtime, st.st_size, b.st_mtime if b else 0, _intel_version())
    except OSError:
        return None


def _intel_version():
    r = db.q("SELECT (SELECT count(*) || max(coalesce(id,0)) FROM plan_event) || '/' || (SELECT count(*) || max(coalesce(id,0)) FROM funding_award)"
             " || '/' || (SELECT count(*) || max(coalesce(id,0)) FROM fleet_contract) || '/' || (SELECT max(updated) FROM unit_cost) v", one=True)
    try:  # 1.8.14: data QA repairs are laid over the snapshot
        from . import dataqa
        qv = dataqa._version()
    except Exception:
        qv = ""
    return (r["v"] if r else "") + "/qa" + qv


def invalidate():
    _cache.clear()


def snapshot():
    """The fleets in the viewer's lens and region (see lens.py), keyed by fleet_id."""
    sc = lens.current()
    full = snapshot_all()
    if not sc.scoped:
        return full
    key = (id(full), sc.key)
    hit = _scoped.get(key)
    if hit is None:
        hit = {fid: fl for fid, fl in full.items() if sc.passes(fl["ntd_mode"], fl["country"], fl.get("operator_id"))}
        if len(_scoped) > 32:
            _scoped.clear()
        _scoped[key] = hit
    return hit


def snapshot_all():
    """{fleet_id: fleet dict} for every active fleet the viewer can see (freight only for admins while it is parked), with
    reliability, spares, energy, signals and sizing attached. One cache per freight visibility."""
    fk = _fleet_key()
    key = None if fk is None else (fk, lens.current().freight)
    cache = _cache.setdefault(key[1] if key else None, {"key": None, "snap": None})
    if key is not None and cache["key"] == key and cache["snap"] is not None:
        return cache["snap"]
    with _lock:
        if key is not None and cache["key"] == key and cache["snap"] is not None:
            return cache["snap"]
        snap = _build()
        cache.update(key=key, snap=snap)
        return snap


def _rows(sql, args=()):
    try:
        return [dict(r) for r in db.fq(sql, args)]
    except Exception:
        return []


def operator_mode_stats():
    """(operator_id, mode) -> reliability, spare ratio, contracting share, from NTD operator_mode_year."""
    rows = _rows("SELECT operator_id, ntd_mode, report_year, vehicle_revenue_miles vrm, mechanical_failures_total mf, vehicles_max_service voms, "
                 "opex_purchased_transportation pt, opex_total, opex_vehicle_maintenance vm FROM operator_mode_year ORDER BY report_year")
    by = {}
    for r in rows:
        by.setdefault((r["operator_id"], r["ntd_mode"]), []).append(r)
    out = {}
    for k, rs in by.items():
        withf = [r for r in rs if r["mf"] and r["vrm"]]
        d = {"years": [(r["report_year"], round(r["vrm"] / r["mf"])) for r in withf], "mdbf": None, "mdbf_change_pct": None,
             "mdbf_first": None, "mdbf_first_year": None, "failures": None, "mdbf_peer": None, "mdbf_vs_peer_pct": None, "spare_pct": None, "contracted_pct": None}
        latest = rs[-1]
        d["year"] = latest["report_year"]
        d["voms"] = latest["voms"]
        d["vrm"] = latest["vrm"]
        if withf:
            d["mdbf"] = round(withf[-1]["vrm"] / withf[-1]["mf"])
            d["failures"] = withf[-1]["mf"]
            first = withf[0]
            if len(withf) > 1:
                d["mdbf_first"] = round(first["vrm"] / first["mf"])
                d["mdbf_first_year"] = first["report_year"]
                d["mdbf_change_pct"] = round(100 * (d["mdbf"] - d["mdbf_first"]) / d["mdbf_first"]) if d["mdbf_first"] else None
        if latest["pt"] and latest["opex_total"]:
            d["contracted_pct"] = round(100 * latest["pt"] / latest["opex_total"])
        out[k] = d
    # peer medians per mode
    per_mode = {}
    for (oid, mode), d in out.items():
        if d.get("mdbf"):
            per_mode.setdefault(mode, []).append(d["mdbf"])
    for (oid, mode), d in out.items():
        vals = per_mode.get(mode) or []
        if d.get("mdbf") and len(vals) >= 3:
            d["mdbf_peer"] = round(statistics.median(vals))
            d["mdbf_vs_peer_pct"] = round(100 * (d["mdbf"] - d["mdbf_peer"]) / d["mdbf_peer"])
    return out


def _build():
    yr = this_year()
    costs = unit_costs()
    fleets = _rows(f"SELECT {data.FLEET_COLS}, f.qty_ada_accessible, f.qty_contingency, f.build_year_last, f.planned_retirement_year, "
                   "f.ownership, f.owner_entity, f.funding_source, f.seats_per_vehicle, f.status fleet_status "
                   "FROM v_fleet_profile p JOIN operator o USING (operator_id) JOIN fleet f USING (fleet_id) "
                   "WHERE coalesce(p.qty_active, p.qty_total_current, 0) > 0")
    try:  # 1.8.14: data QA repairs (Admin > Data QA flags)
        from . import dataqa
        dataqa.apply_fleet(fleets)
    except Exception:
        pass
    snap = {f["fleet_id"]: f for f in fleets}
    try:  # 1.7.92: today's owner of each builder's designs (db._lineage); "now Alstom" beside Bombardier
        now = {r[0]: r[1] for r in db.fq("SELECT fleet_id, manufacturer_now FROM v_fleet_profile")}
    except Exception:
        now = {}
    for f in fleets:
        f["manufacturer_now"] = now.get(f["fleet_id"]) or f["manufacturer"]
    oms = operator_mode_stats()

    # active cars per operator+mode, for the spare ratio
    active = {}
    for f in fleets:
        k = (f["operator_id"], f["ntd_mode"])
        active[k] = active.get(k, 0) + (f["qty_active"] or 0)

    # installed base: subsystem records linked to fleets
    subs = {}
    for r in _rows("SELECT fs.fleet_id, s.rowid sid, s.subsystem, s.supplier, s.product, s.confidence, s.source_url, ss.supplier_id "
                   "FROM fleet_subsystem fs JOIN seed_subsystem s ON s.rowid = fs.subsystem_rowid "
                   "LEFT JOIN subsystem_supplier ss ON ss.subsystem_rowid = s.rowid"):
        subs.setdefault(r["fleet_id"], []).append(r)

    energy = {r["fleet_id"]: r for r in _rows("SELECT * FROM loco_energy_fleet WHERE fleet_id IS NOT NULL")}
    util = {r["fleet_id"]: r for r in _rows("SELECT fleet_id, hdd65, cdd65, hvac_index, hvac_on_hours, door_operator_cycles_per_car, "
                                             "annual_stops_per_car FROM fleet_utilization")}
    planned_seed = _seed_planned()
    fleet_bids = _recent_fleet_bids(snap)
    plans = [dict(r) for r in db.q("SELECT * FROM plan_event")]
    funds = [dict(r) for r in db.q("SELECT * FROM funding_award")]
    contracts = [dict(r) for r in db.q("SELECT * FROM fleet_contract")]
    cutoff = (datetime.date.today() - datetime.timedelta(days=730)).isoformat()
    funded_ops = {r["operator_id"] for r in funds if (r["award_date"] or "") >= cutoff}
    budget_plans = _budget_plan_docs()
    _resolve_bid_sources(fleet_bids)

    for fid, f in snap.items():
        k = (f["operator_id"], f["ntd_mode"])
        st = oms.get(k, {})
        f["rel"] = st
        f["installed"] = subs.get(fid, [])
        f["energy"] = energy.get(fid)
        f["util"] = util.get(fid)
        voms = st.get("voms")
        act = active.get(k)
        f["spare_pct"] = round(100 * (act - voms) / voms) if voms and act else None
        f["spare_active"], f["spare_voms"] = act, voms
        f["contracted_pct"] = st.get("contracted_pct")
        tot = f["qty_total_current"] or f["qty_active"] or 0
        f["ada_pct"] = round(100 * (f["qty_ada_accessible"] or 0) / tot) if tot and f["qty_ada_accessible"] is not None else None
        f["planned_text"] = planned_seed.get(fid)
        f["plans"] = [p for p in plans if p["fleet_id"] == fid or (p["fleet_id"] is None and p["operator_id"] == f["operator_id"]
                                                                  and _plan_matches(p, f))]
        f["contracts"] = [c for c in contracts if c["fleet_id"] == fid]
        f["warranty_end_est"] = None
        if f.get("build_year_last") and f["build_year_last"] >= yr - 6 and not any(c["kind"] == "warranty" for c in f["contracts"]):
            f["warranty_end_est"] = f["build_year_last"] + 2
        f["diesel"] = (f["propulsion"] or "") in ("diesel", "diesel_electric", "dual_mode")
        f["repower_candidate"] = bool(f["diesel"] and f["vehicle_class"] in ("locomotive", "dmu") and (f["build_year"] or 9999) < 2015
                                      and (f["ulb_year"] or 0) > yr)
        f["signals"] = _signals(f, yr, fleet_bids, funded_ops)
        f["sig_src"] = _sig_sources(f, fleet_bids, funds, cutoff, budget_plans)
        f["sizing"] = _sizing(f, costs)
    return snap


def _plan_matches(p, f):
    t = (p.get("title") or "").lower() + " " + (p.get("notes") or "").lower()
    model = (f["model_name"] or "").lower()
    return bool(model and len(model) >= 3 and re.search(r"(?<![a-z0-9])" + re.escape(model) + r"(?![a-z0-9])", t))


def _seed_planned():
    """fleet_id -> the researched 'planned replacement' note on its seed_fleet row."""
    out = {}
    seeds = {r["rowid"]: r for r in _rows("SELECT rowid, planned_replacement FROM seed_fleet WHERE coalesce(planned_replacement,'') != ''")}
    if not seeds:
        return out
    for r in _rows("SELECT seed_rowid, ntd_fleet_ids FROM ntd_reconcile WHERE ntd_fleet_ids IS NOT NULL"):
        if r["seed_rowid"] in seeds:
            for x in str(r["ntd_fleet_ids"]).split(","):
                if x.strip().isdigit():
                    out[int(x)] = seeds[r["seed_rowid"]]["planned_replacement"]
    for r in _rows("SELECT fleet_id, seed_rowid FROM v_fleet_national WHERE seed_rowid IS NOT NULL"):
        if r["seed_rowid"] in seeds:
            out.setdefault(r["fleet_id"], seeds[r["seed_rowid"]]["planned_replacement"])
    return out


# Fleet work, for the "Recent bid" pill: a bid counts for a fleet only when it is about vehicles (not track, signals, stations or an
# agency's general RFPs) and, where the operator runs more than one kind of car, it names that fleet's model or kind of car.
FLEET_BID_CATS = {"overhaul_program", "component_repair", "parts_supply", "maintenance_services", "onboard_systems", "cleaning_interior",
                  "vehicle_procurement"}
CLASS_WORDS = {
    "lrv": r"light rail|\blrvs?\b|streetcars?|trolley", "streetcar": r"streetcars?|trolley|light rail|\blrvs?\b",
    "heritage_streetcar": r"streetcars?|trolley|heritage", "locomotive": r"locomotives?",
    "coach": r"coach(es)?|cab cars?|bi-?level|multi-?level|passenger cars?|gallery cars?", "cab_car": r"cab cars?|coach(es)?|bi-?level|multi-?level",
    "emu": r"\bemus?\b|electric multiple units?|multiple units?|railcars?|rail cars?", "dmu": r"\bdmus?\b|diesel multiple units?|multiple units?|railcars?",
    "metro_car": r"subway|\bmetro\b|heavy rail|rapid transit|railcars?|rail cars?|transit cars?",
    "agt_vehicle": r"people ?movers?|\bapm\b|automated guideway", "monorail_car": r"monorail", "cable_car": r"cable cars?",
    "incline_car": r"incline|funicular"}
_CLASS_RX = {k: re.compile(v, re.I) for k, v in CLASS_WORDS.items()}


def _vehicle_subsystems():
    try:
        from . import award_analyst
        return {k for k, (_, grp, _) in award_analyst.taxonomy()["subsystems"].items() if grp == "vehicle"}
    except Exception:
        return set(data.SUBSYSTEMS)


def _recent_fleet_bids(snap, days=90):
    """fleet_id -> (date, title) of the newest relevant bid in the last `days` that is about that fleet: vehicle work (replacement,
    overhaul, repair, parts, maintenance, onboard systems) by its operator that names the fleet's model or kind of car, or any vehicle
    work when the operator runs only one kind of car. General agency RFPs (track, signals, stations, consulting...) never count."""
    out = {}
    try:
        rows = db.bq("SELECT n.notice_id, n.url, n.agency_id, g.agency, n.operator_id, n.title, n.description, n.summary, n.category, n.subsystems, n.rail, "
                     "coalesce(n.published, date(n.first_seen)) d, g.fleet_operator_ids FROM notice n LEFT JOIN agency g USING (agency_id) "
                     "WHERE coalesce(n.published, date(n.first_seen)) >= date('now', ?) AND coalesce(n.relevance,0) >= 50 "
                     "AND coalesce(n.notice_type,'') NOT IN ('award', 'cancelled') ORDER BY d DESC", (f"-{days} days",))
    except Exception:
        return out
    veh = _vehicle_subsystems()
    by_op = {}
    for f in snap.values():
        by_op.setdefault(f["operator_id"], []).append(f)
    for r in rows:
        if r["rail"] == 0:
            continue
        subs = {x for x in (r["subsystems"] or "").split(";") if x}
        if r["category"] not in FLEET_BID_CATS and not (subs & veh):
            continue
        text = " ".join(str(r[k] or "") for k in ("title", "description", "summary"))
        low = text.lower()
        ops = [r["operator_id"]] if r["operator_id"] else [x for x in (r["fleet_operator_ids"] or "").split(";") if x]
        for op in ops:
            fls = by_op.get(op) or []
            named = [f for f in fls if (f["model_name"] or "") and len(f["model_name"]) >= 3
                     and re.search(r"(?<![a-z0-9])" + re.escape(f["model_name"].lower()) + r"(?![a-z0-9])", low)]
            if not named:
                named = [f for f in fls if f["vehicle_class"] in _CLASS_RX and _CLASS_RX[f["vehicle_class"]].search(text)]
            if not named and len({f["vehicle_class"] for f in fls}) == 1:
                named = fls
            for f in named:
                out.setdefault(f["fleet_id"], (r["d"], r["title"] or "", {k: r[k] for k in ("notice_id", "url", "agency_id", "agency")}))
    return out


def _signals(f, yr, fleet_bids, funded_ops):
    s = []
    rel = f["rel"]
    if f["ulb_year"] and f["ulb_year"] < yr:
        s.append(("past_ulb", f"Past useful life ({f['ulb_year']})"))
    elif f["ulb_year"] and f["ulb_year"] <= yr + 3:
        s.append(("ulb_soon", f"Useful life ends {f['ulb_year']}"))
    if f["midlife_due_year"] and yr - 3 <= f["midlife_due_year"] <= yr + 2 and not f["last_rebuild_year"]:
        s.append(("midlife_due", f"Midlife due {f['midlife_due_year']}"))
    if (f["delta_vs_benchmark_pct"] or 0) > 25:
        s.append(("cost_high", f"Maintenance cost {f['delta_vs_benchmark_pct']:+.0f}% vs peers"))
    if rel.get("mdbf_vs_peer_pct") is not None and rel["mdbf_vs_peer_pct"] <= -40:
        s.append(("reliability_low", f"Miles between failures {rel['mdbf_vs_peer_pct']:+d}% vs peers"))
    if rel.get("mdbf_change_pct") is not None and rel["mdbf_change_pct"] <= -25:
        s.append(("reliability_falling", f"Miles between failures {rel['mdbf_change_pct']:+d}% since {rel.get('mdbf_first_year')}"))
    if f["fleet_id"] in fleet_bids:
        d, t = fleet_bids[f["fleet_id"]][:2]
        s.append(("bid_recent", f"Bid {d or ''}: {t[:70]}".replace(" :", ":")))
    if f["operator_id"] in funded_ops:
        s.append(("funded", "Funding award in the last 2 years"))
    if f["plans"] or f["planned_text"] or f["planned_retirement_year"]:
        txt = f["plans"][0]["title"] if f["plans"] else (f["planned_text"] or f"Retirement planned {f['planned_retirement_year']}")
        s.append(("planned", txt))
    if f["spare_pct"] is not None and f["spare_pct"] < 10 and f["spare_voms"] and f["spare_voms"] >= 10:
        s.append(("spare_tight", f"Spare ratio {f['spare_pct']}% (operator {f['ntd_mode']})"))
    wend = next((int(c["end_date"][:4]) for c in f["contracts"] if c["kind"] == "warranty" and (c["end_date"] or "")[:4].isdigit()),
                f["warranty_end_est"])
    if wend and yr <= wend <= yr + 1:
        s.append(("warranty_ending", f"Warranty ends about {wend}"))
    if f["repower_candidate"]:
        s.append(("repower_candidate", f"Diesel built {f['build_year']}, before Tier 4"))
    return s


def _sizing(f, costs):
    """Dollar size of each event this fleet has coming, for the default offerings."""
    n = f["qty_active"] or 0
    cls = f["vehicle_class"]
    out = {}
    for ev in ("replace", "midlife", "engine", "repower"):
        c = unit_cost(costs, ev, cls)
        if c:
            out[ev] = n * c
    for comp in COMPONENTS:
        c = unit_cost(costs, comp, cls)
        if c:
            out[comp] = n * c
    if f["maint_cost_per_car_year"]:
        out["services"] = n * f["maint_cost_per_car_year"]
    return out


def signal_meta():
    return SIGNALS


# ---------------- opportunities ----------------

_REPL_RX = re.compile(r"replac\w*\s+(?:the\s+)?([^;.()]+)", re.I)


def replacement_orders():
    """1.7.39: fleet_id -> the vehicle order that replaces it, read from order notes like "replaces M3/M3A" (Data audit 11-12).
    kind 'ordered' (awarded, delivering, selected) or 'rfp' (out to bid or planned). Items are matched to the same agencies'
    fleets by model (squeezed, either name starting the other) or by a build year named in the note ("replace 1982 cars")."""
    snap = snapshot()
    by_op = {}
    for fl in snap.values():
        by_op.setdefault(fl["operator_id"], []).append(fl)
    out = {}
    for p in data.procurements():
        st = (p.get("status") or "").lower()
        if "cancel" in st or "complete" in st:
            continue
        m = _REPL_RX.search(p.get("notes") or "")
        if not m:
            continue
        kind = "rfp" if re.search(r"rfp|planned|announced", st) else "ordered"
        items, prefix = [], ""
        for x in [x.strip() for x in re.split(r"/|,|\band\b|&", m.group(1)) if x.strip()]:
            if prefix and re.fullmatch(r"[IVX]{1,4}|[A-Z]?\d{0,2}[A-Z]?", x) and " " not in x:
                x = prefix + " " + x  # "Comet II/IV/V" -> Comet IV, Comet V; "Superliner I/II" -> Superliner II
            items.append(x)
            prefix = x.rsplit(" ", 1)[0] if " " in x else ""
        years = {int(y) for y in re.findall(r"\b(19[5-9]\d|20[0-2]\d)\b", m.group(1))}
        keys = [_words(x) for x in items if len(data.norm(x)) >= 2 and re.search(r"[a-z]", data.norm(x))
                and not re.fullmatch(r"(19|20)\d\d(cars?|units?|fleet)?", data.norm(x))]
        info = {"order_id": p.get("order_id"), "model": p.get("model"), "builder": p.get("manufacturer"),
                "year": str(p.get("award_date") or "")[:4], "kind": kind, "status": p.get("status")}
        for op in [o for o in (p.get("operator_id") or "").split(";") if o in by_op]:
            for fl in by_op[op]:
                parts = [_words(x) for x in (fl["model_name"] or "").split("/")]
                hit = any(_words_match(k, pt) for k in keys for pt in parts) or (years and fl["build_year"] in years)
                if hit and (fl["fleet_id"] not in out or out[fl["fleet_id"]]["kind"] == "rfp"):
                    out[fl["fleet_id"]] = info
    return out


def _words(s):
    """Lower-case words of a model name, with a plural 's' dropped from a model code ("GP49s" -> gp49)."""
    w = [x for x in re.split(r"[^a-z0-9]+", str(s or "").lower()) if x]
    return [re.sub(r"(?<=\d)s$", "", x) for x in w]


def _words_match(item, fleet):
    """The item's words start the fleet's words: whole words, except the last item word may start a fleet word when it has a
    digit (M3 -> M3A, GP49 -> GP49H). So "Viewliner I" never matches "Viewliner II", and "Amfleet II" never "Amfleet I"."""
    if not item or len(item) > len(fleet):
        return False
    for i, w in enumerate(item):
        if w == fleet[i]:
            continue
        if i == len(item) - 1 and re.search(r"\d", w) and fleet[i].startswith(w):
            continue
        return False
    return True


def ordered_hidden(f=None):
    """How many fleets in view are left out of the buy ranking because their replacement is already ordered."""
    f = f or {}
    snap = snapshot()
    return sum(1 for fid, o in replacement_orders().items() if o["kind"] == "ordered" and fid in snap and _passes(snap[fid], f))


def opportunities(offering="vehicles", years=10, f=None):
    """Ranked list of (fleet, event) opportunities for one offering within the horizon."""
    f = f or {}
    yr = this_year()
    end = yr + years
    snap = snapshot()
    costs = unit_costs()
    rows = []
    comp = offering.split(":", 1)[1] if offering.startswith("component:") else None
    repl = replacement_orders() if offering == "vehicles" else {}
    for fl in snap.values():
        if not _passes(fl, f):
            continue
        n = fl["qty_active"] or 0
        if not n:
            continue
        cls = fl["vehicle_class"]
        cands = []
        if offering == "vehicles":
            ro = repl.get(fl["fleet_id"])
            if ro and ro["kind"] == "ordered" and f.get("ordered") != "1":
                continue  # its replacement is already on order: not an open opportunity (shown with ordered=1)
            when = fl["ulb_year"]
            young = bool(fl["build_year"]) and fl["build_year"] >= yr - 10
            for p in fl["plans"]:
                # An order/option/expansion plan matched to a young fleet is usually that fleet's own delivery, not its replacement
                if p["event_type"] in ("replace", "order", "option", "expansion") and p["year_planned"] and not (young and p["event_type"] != "replace"):
                    when = min(when or 9999, p["year_planned"])
            if when:
                cands.append(("replace", max(when, yr - 5), unit_cost(costs, "replace", cls)))
        elif offering == "overhaul":
            if fl["midlife_due_year"] and not fl["last_rebuild_year"]:
                cands.append(("midlife", fl["midlife_due_year"], unit_cost(costs, "midlife", cls)))
            if fl["engine_overhaul_due_year"]:
                cands.append(("engine", fl["engine_overhaul_due_year"], unit_cost(costs, "engine", cls)))
        elif offering == "repower":
            if fl["repower_candidate"]:
                cands.append(("repower", max(yr, fl["engine_overhaul_due_year"] or yr), unit_cost(costs, "repower", cls)))
        elif offering == "services":
            if fl["maint_cost_per_car_year"]:
                cands.append(("services", yr, fl["maint_cost_per_car_year"]))
        elif comp:
            if comp in ("propulsion_traction",) and not fl["midlife_due_year"]:
                continue
            when = fl["midlife_due_year"] if fl["midlife_due_year"] and not fl["last_rebuild_year"] else None
            if when:
                cands.append(("retrofit", when, unit_cost(costs, comp, cls)))
        for ev, when, uc in cands:
            if when is None or when > end:
                continue
            if when < yr - 5:
                when = yr - 5
            value = n * (uc or 0)
            inc = [s for s in fl["installed"] if comp and s["subsystem"] == comp]
            rows.append({"fleet": fl, "event": ev, "year": when, "value": value, "unit": uc, "cars": n, "replacement": repl.get(fl["fleet_id"]),
                         "incumbent": ", ".join(sorted({s["supplier"] for s in inc if s["supplier"]})) or None,
                         "score": _score(fl, when, value, yr)})
    rows.sort(key=lambda r: -r["score"])
    return rows


def _score(fl, when, value, yr):
    timing = max(0, 40 - 4 * max(0, when - yr))  # sooner is better; overdue counts as now
    size = min(35, 35 * (value / 50e6)) if value else 0
    sig = min(25, 5 * len(fl["signals"]))
    return round(timing + size + sig)


def _passes(fl, f):
    if f.get("mode") and data.MODE_ALIASES.get(fl["ntd_mode"], fl["ntd_mode"]) != f["mode"]:
        return False
    if f.get("cls") and data.cls_key(fl["vehicle_class"]) != data.cls_key(f["cls"]):
        return False
    if f.get("country") and fl["country"] != f["country"]:
        return False
    if f.get("operator") and f["operator"] not in (fl.get("operator_ids") or [fl["operator_id"]]):
        return False
    if f.get("oem") and fl["manufacturer"] != f["oem"]:
        return False
    if f.get("signal") and f["signal"] not in {s[0] for s in fl["signals"]}:
        return False
    if f.get("subsystem") and not any(s["subsystem"] == f["subsystem"] for s in fl["installed"]):
        return False
    if f.get("supplier") and not any(s["supplier_id"] == f["supplier"] for s in fl["installed"]):
        return False
    if f.get("q"):
        q = f["q"].lower()
        hay = " ".join(str(fl.get(k) or "") for k in ("model_name", "manufacturer", "operator_name", "service_name", "operator_id")).lower()
        if q not in hay and not (data.norm(q) and data.norm(q) in data.norm(hay)):
            return False
    return True


def fleet_ids_matching(f):
    """Fleet ids that pass the sales filters (signal, subsystem, supplier). None when no such filter is set."""
    if not any(f.get(k) for k in ("signal", "subsystem", "supplier")):
        return None
    sub = {k: f[k] for k in ("signal", "subsystem", "supplier") if f.get(k)}
    return [fid for fid, fl in snapshot().items() if _passes(fl, sub)]


# ---------------- upcoming work: one timeline ----------------

WORK_TYPES = {"buy": "Vehicle buy", "overhaul": "Overhaul", "rebuild": "Rebuild or modernization", "option": "Option exercise"}
_WORK_OFFERING = {"buy": "vehicles", "overhaul": "overhaul", "rebuild": "repower"}


def _year_in(text, default=None):
    ys = [int(y) for y in re.findall(r"(?<!\d)(20\d\d)(?!\d)", str(text or ""))]
    return max(ys) if ys else default


def work_timeline(types=None, years=10, f=None):
    """Replacements, overhauls, rebuilds and options left on vehicle orders as one list, soonest first."""
    types = [t for t in (types or WORK_TYPES) if t in WORK_TYPES]
    f = f or {}
    yr = this_year()
    out = []
    for t in types:
        if t in _WORK_OFFERING:
            for o in opportunities(_WORK_OFFERING[t], years, f):
                out.append(dict(o, type=t))
    if "option" in types:
        # 1.7.37 (Justin 11-12): an option row sits on a fleet only when that fleet is the ordered model. Otherwise it stands
        # for the order itself (cars not in service yet): no borrowed fleet age, cost or signals, score = timing + size, and
        # a joint order names every agency on it.
        snap = snapshot()
        by_op = {}
        for fl in snap.values():
            by_op.setdefault(fl["operator_id"], []).append(fl)
        for p in data.procurements():
            left = data.first_int(p["qty_options"])
            if not left or "complete" in (p["status"] or "").lower():
                continue
            all_ops = [o for o in (p["operator_id"] or "").split(";") if o]
            ops = [o for o in all_ops if o in by_op]
            if not ops:
                continue
            fls = [fl for o in ops for fl in by_op[o]]
            match = [fl for fl in fls if _plan_matches({"title": p["model"]}, fl)] or [fl for fl in fls if _model_token_match(p["model"], fl)]
            fl = match[0] if match else order_as_fleet(p, ops, by_op)
            if match and len(ops) > 1:  # a joint order on a fleet of that model: still list (and filter by) every agency
                fl = dict(fl, operator_ids=ops)
            if f and not _passes(fl, {k: v for k, v in f.items() if k in ("mode", "cls", "operator", "oem", "q")}):
                continue
            when = max(yr, _year_in(p["delivery"], yr + 2))
            if when > yr + years:
                continue
            unit = unit_cost(unit_costs(), "replace", fl["vehicle_class"]) if fl["vehicle_class"] else None
            base = data.first_int(p["qty_base"])
            aw = str(p["award_date"] or "")[:4]
            who = ", ".join(all_ops) if len(all_ops) > 1 else all_ops[0]
            mf = p["manufacturer"] if (p["manufacturer"] or "").strip().upper() not in ("", "TBD", "UNKNOWN", "N/A") else ""
            detail = (f"{who} can still buy {left:,} more on the {aw + ' ' if aw.isdigit() else ''}{mf} order"
                      + (f" ({base:,} ordered)" if base else "") + ("; options shared across the agencies" if len(all_ops) > 1 else ""))
            out.append({"fleet": fl, "event": "plan", "type": "option", "year": when, "cars": left, "value": left * (unit or 0), "unit": unit,
                        "incumbent": p["manufacturer"], "score": _score(fl, when, left * (unit or 0), yr), "order_id": p.get("order_id"),
                        "on_order": not match, "est_year": True, "joint": all_ops if len(all_ops) > 1 else None,
                        "value_basis": (f"{left:,} units × {unit / 1e6:.1f}M typical {data.CLASSES.get(fl['vehicle_class'], 'car').lower()} price" if unit else None),
                        "detail": " ".join(detail.split()), "source_url": p["source_url"]})
    out.sort(key=lambda r: (r["year"], -r["score"]))
    return out


_ORDER_CLS = [(r"\bcab\b|cab car|control car", "cab_car"), (r"locomotive|charger|\bsc-4\d|\balc-4\d|\bp4\d|\bf\d\dph", "locomotive"),
              (r"\bb?emu\b|\bm\d+a?\b|electric multiple", "emu"), (r"\bdmu\b|\bflirt\b|diesel multiple", "dmu"), (r"\blrv\b|light rail", "lrv"),
              (r"streetcar|tram", "streetcar"), (r"subway|metro|rapid transit|heavy rail", "metro_car"), (r"coach|bi-?level|single-level|multi-?level|trailer", "coach")]


def _model_token_match(model, fl):
    """'ALP-45 (dual-power)' on order vs 'ALP-45DP' in service: the order's first word, when it has a digit, starts the fleet's model."""
    t = (model or "").split()
    tok = re.sub(r"[^a-z0-9]", "", t[0].lower()) if t else ""
    fm = re.sub(r"[^a-z0-9]", "", (fl["model_name"] or "").lower())
    return len(tok) >= 4 and any(ch.isdigit() for ch in tok) and fm.startswith(tok)


def order_as_fleet(p, ops, by_op):
    """A stand-in fleet record for cars on order that are not in service yet (no build year, age, cost or signals)."""
    model = p.get("model") or "Vehicle order"
    t = model.lower()
    cls = next((c for rx, c in _ORDER_CLS if re.search(rx, t)), None)
    big = max((fl for o in ops for fl in by_op[o]), key=lambda x: x["qty_active"] or 0)
    names = [by_op[o][0]["operator_name"] for o in ops]
    aw = str(p.get("award_date") or "")[:4]
    new = (not aw.isdigit() or int(aw) >= this_year() - 4) and "complete" not in (p.get("status") or "").lower()
    return {"fleet_id": None, "order_id": p.get("order_id"), "on_order": True, "new_order": new, "operator_id": ops[0], "operator_name": ", ".join(names),
            "operator_ids": ops, "service_name": None, "manufacturer": p.get("manufacturer"), "model_name": model, "vehicle_class": cls,
            "ntd_mode": big.get("ntd_mode"), "country": big.get("country"), "build_year": None, "qty_active": 0, "signals": [], "installed": []}


def options_left():
    """(cars, contracts) still under option on vehicle orders in the current lens."""
    rows = [o for o in work_timeline(["option"], 15)]
    return sum(o["cars"] for o in rows), len(rows)


# ---------------- replacement forecast ----------------

def forecast(years=15, group="vehicle_class", f=None, items=None):
    """Units reaching end of life by year and group. Pass a list as items to also get one row per fleet."""
    yr = this_year()
    costs = unit_costs()
    by_year, totals = {}, {}
    overdue = {"cars": 0, "value": 0, "fleets": 0}
    for fl in snapshot().values():
        if not _passes(fl, f or {}):
            continue
        n = fl["qty_active"] or 0
        when = fl["ulb_year"]
        for p in fl["plans"]:
            if p["event_type"] in ("replace", "retire") and p["year_planned"]:
                when = p["year_planned"]
        if not when or not n:
            continue
        v = n * (unit_cost(costs, "replace", fl["vehicle_class"]) or 0)
        g = fl.get(group) or "other"
        if when < yr:
            overdue["cars"] += n
            overdue["value"] += v
            overdue["fleets"] += 1
            g_year = yr
        else:
            g_year = when
        if g_year > yr + years - 1:
            continue
        by_year.setdefault(g_year, {})
        by_year[g_year][g] = by_year[g_year].get(g, 0) + n
        if items is not None:
            items.append({"fleet": fl, "year": g_year, "due": when, "group": g, "cars": n, "value": v, "overdue": when < yr})
        t = totals.setdefault(g, {"cars": 0, "value": 0, "fleets": 0})
        t["cars"] += n
        t["value"] += v
        t["fleets"] += 1
    for y in range(yr, yr + years):
        by_year.setdefault(y, {})
    return by_year, totals, overdue


# ---------------- suppliers, builders, market share ----------------

def suppliers():
    reg = {r["supplier_id"]: dict(r) for r in _rows("SELECT * FROM supplier")}
    snap = snapshot()
    for s in reg.values():
        s.update(fleets=set(), cars=0, operators=set(), subsystems=set())
    for fid, fl in snap.items():
        seen = set()
        for x in fl["installed"]:
            sid = x["supplier_id"]
            if sid not in reg:
                continue
            s = reg[sid]
            s["fleets"].add(fid)
            s["operators"].add(fl["operator_id"])
            s["subsystems"].add(x["subsystem"])
            if sid not in seen:
                s["cars"] += fl["qty_active"] or 0
                seen.add(sid)
    out = []
    for s in reg.values():
        s["n_fleets"], s["n_operators"] = len(s["fleets"]), len(s["operators"])
        s["subsystems"] = sorted(s["subsystems"])
        out.append(s)
    return sorted(out, key=lambda s: -s["cars"])


def supplier(sid):
    r = db.fq("SELECT * FROM supplier WHERE supplier_id = ?", (sid,), one=True)
    if not r:
        return None
    d = dict(r)
    rows = []
    for fid, fl in snapshot().items():
        for x in fl["installed"]:
            if x["supplier_id"] == sid:
                rows.append({"fleet": fl, **x})
    d["rows"] = sorted(rows, key=lambda r: (r["subsystem"], -(r["fleet"]["qty_active"] or 0)))
    by_sub = {}
    for r in rows:
        b = by_sub.setdefault(r["subsystem"], {"fleets": 0, "cars": 0})
        b["fleets"] += 1
        b["cars"] += r["fleet"]["qty_active"] or 0
    d["by_sub"] = by_sub
    d["share"] = {k: share_for(k).get(sid) for k in by_sub}
    yr = this_year()
    d["upcoming"] = sorted([r for r in rows if r["fleet"]["midlife_due_year"] and yr <= r["fleet"]["midlife_due_year"] <= yr + 5],
                           key=lambda r: r["fleet"]["midlife_due_year"])
    return d


def share_for(subsystem):
    """supplier_id -> % of covered units for one subsystem."""
    cars, tot = {}, 0
    for fl in snapshot().values():
        ids = {x["supplier_id"] for x in fl["installed"] if x["subsystem"] == subsystem and x["supplier_id"]}
        if not ids:
            continue
        n = fl["qty_active"] or 0
        tot += n
        for i in ids:
            cars[i] = cars.get(i, 0) + n / len(ids)
    return {k: round(100 * v / tot) for k, v in cars.items()} if tot else {}


def _bkey(fl, own=False):
    """Builder a fleet counts under: the company that built it, or (own=True, 1.7.92) today's owner of the design."""
    return (fl.get("manufacturer_now") if own else None) or fl["manufacturer"] or "Unknown"


def market(cls=None, mode=None, own=False):
    snap = [fl for fl in snapshot().values() if (not cls or fl["vehicle_class"] == cls) and (not mode or data.MODE_ALIASES.get(fl["ntd_mode"], fl["ntd_mode"]) == mode)]
    total = sum(fl["qty_active"] or 0 for fl in snap)
    builders = {}
    for fl in snap:
        b = builders.setdefault(_bkey(fl, own), {"cars": 0, "fleets": 0, "operators": set()})
        b["cars"] += fl["qty_active"] or 0
        b["fleets"] += 1
        b["operators"].add(fl["operator_id"])
    names = {r["supplier_id"]: r["name"] for r in _rows("SELECT supplier_id, name FROM supplier")}
    subs = {}
    for k in list(COMPONENTS) + ["prime_mover", "hep", "signal_onboard"]:
        cars, cov = {}, 0
        for fl in snap:
            recs = [x for x in fl["installed"] if x["subsystem"] == k and (x["supplier_id"] or (x["supplier"] or "").strip())]
            if not recs:
                continue
            n = fl["qty_active"] or 0
            cov += n
            labels = {_parent(names.get(x["supplier_id"]) or x["supplier"]) for x in recs}
            for lab in labels:
                cars[lab] = cars.get(lab, 0) + n / len(labels)
        if cov:
            subs[k] = {"coverage": round(100 * cov / total) if total else 0, "cars": cov,
                       "suppliers": sorted(cars.items(), key=lambda kv: -kv[1])}
    return {"total": total, "builders": sorted(builders.items(), key=lambda kv: -kv[1]["cars"]), "subs": subs}


def market_sub(k, cls=None, mode=None):
    """One subsystem's supplier market (1.7.18, Market share drill-down): every supplier with its share of covered cars, fleets,
    operators and the car builders whose platforms it is on. Cars of a fleet with several suppliers for the subsystem are split."""
    snap = [fl for fl in snapshot().values() if (not cls or fl["vehicle_class"] == cls) and (not mode or data.MODE_ALIASES.get(fl["ntd_mode"], fl["ntd_mode"]) == mode)]
    total = sum(fl["qty_active"] or 0 for fl in snap)
    names = {r["supplier_id"]: r["name"] for r in _rows("SELECT supplier_id, name FROM supplier")}
    sup, cov, nfl = {}, 0, 0
    for fl in snap:
        recs = [x for x in fl["installed"] if x["subsystem"] == k and (x["supplier_id"] or (x["supplier"] or "").strip())]
        if not recs:
            continue
        n = fl["qty_active"] or 0
        cov += n
        nfl += 1
        labels = {_parent(names.get(x["supplier_id"]) or x["supplier"]) for x in recs}
        for lab in labels:
            d = sup.setdefault(lab, {"name": lab, "cars": 0.0, "fleets": 0, "operators": set(), "builders": {}, "products": set()})
            d["cars"] += n / len(labels)
            d["fleets"] += 1
            d["operators"].add(fl["operator_id"])
            b = fl["manufacturer"] or "Unknown"
            d["builders"][b] = d["builders"].get(b, 0) + n / len(labels)
            d["products"].update((x["product"] or "").strip() for x in recs if _parent(names.get(x["supplier_id"]) or x["supplier"]) == lab and (x["product"] or "").strip())
    rows = sorted(sup.values(), key=lambda d: -d["cars"])
    for d in rows:
        d["share"] = round(100 * d["cars"] / cov) if cov else 0
        d["operators"] = len(d["operators"])
        d["builders"] = sorted(d["builders"].items(), key=lambda kv: -kv[1])
        d["products"] = sorted(d["products"])
    return {"total": total, "covered": cov, "fleets": nfl, "coverage": round(100 * cov / total) if total else 0, "rows": rows}


def market_drill(kind, name, comp=None, cls=None, mode=None, own=False):
    """The fleets behind one Market share bar: a builder (kind 'builder') or a subsystem supplier (kind 'supplier', comp = subsystem),
    grouped by operator for the roster view."""
    snap = [fl for fl in snapshot().values() if (not cls or fl["vehicle_class"] == cls) and (not mode or data.MODE_ALIASES.get(fl["ntd_mode"], fl["ntd_mode"]) == mode)]
    names = {r["supplier_id"]: r["name"] for r in _rows("SELECT supplier_id, name FROM supplier")}
    total = sum(fl["qty_active"] or 0 for fl in snap)
    hits = []
    for fl in snap:
        if kind == "builder":
            if _bkey(fl, own) != name:
                continue
            share = 1.0
            prod = None
        else:
            recs = [x for x in fl["installed"] if x["subsystem"] == comp and (x["supplier_id"] or (x["supplier"] or "").strip())]
            labels = {_parent(names.get(x["supplier_id"]) or x["supplier"]) for x in recs}
            if name not in labels:
                continue
            share = 1 / len(labels)
            prod = "; ".join(sorted({x.get("product") or "" for x in recs if _parent(names.get(x["supplier_id"]) or x["supplier"]) == name} - {""})) or None
        hits.append({"fl": fl, "cars": (fl["qty_active"] or 0) * share, "split": share < 1, "product": prod})
    ops = {}
    for h in hits:
        fl = h["fl"]
        o = ops.setdefault(fl["operator_id"], {"operator_id": fl["operator_id"], "operator_name": fl.get("operator_name") or fl["operator_id"],
                                               "country": fl.get("country"), "cars": 0, "fleets": []})
        o["cars"] += h["cars"]
        o["fleets"].append(h)
    for o in ops.values():
        o["fleets"].sort(key=lambda h: (-(h["fl"]["build_year"] or 0)))
    cars = sum(h["cars"] for h in hits)
    years = [h["fl"]["build_year"] for h in hits if h["fl"]["build_year"]]
    models = {}
    for h in hits:
        m = h["fl"]["model_name"] or "Unknown model"
        models[m] = models.get(m, 0) + h["cars"]
    by_mode = {}
    for h in hits:
        md = data.MODE_ALIASES.get(h["fl"]["ntd_mode"], h["fl"]["ntd_mode"])
        by_mode[md] = by_mode.get(md, 0) + h["cars"]
    return {"kind": kind, "name": name, "comp": comp, "total": total, "cars": cars, "share": round(100 * cars / total, 1) if total else None,
            "n_fleets": len(hits), "operators": sorted(ops.values(), key=lambda o: -o["cars"]),
            "oldest": min(years) if years else None, "newest": max(years) if years else None,
            "models": sorted(models.items(), key=lambda kv: -kv[1]), "modes": sorted(by_mode.items(), key=lambda kv: -kv[1])}


def search_installed(q, limit=25):
    """Installed-base search: operators, fleets, builders and models, and subsystem suppliers/products matching every word of q."""
    words = [w for w in (q or "").lower().split() if w]
    if not words:
        return None

    def hit(*fields):
        return data.qhit(words, *fields)
    ops = [o for o in data.operators() if hit(o["operator_name"], o.get("service_name"), o["operator_id"], o.get("states"), o.get("country"))]
    snap = snapshot()
    fleets = [fl for fl in snap.values() if hit(fl["model_name"], fl["manufacturer"], fl.get("operator_name"), fl.get("service_name"), fl["operator_id"],
                                                fl.get("ntd_mode"), fl.get("build_year"))]
    fleets.sort(key=lambda fl: -(fl["qty_active"] or 0))
    bld = [b for b in builders() if hit(b["name"])]
    models = {}
    for fl in snap.values():
        if hit(fl["model_name"], fl["manufacturer"]):
            m = models.setdefault((fl["manufacturer"], fl["model_name"]), {"builder": fl["manufacturer"], "model": fl["model_name"], "cars": 0, "fleets": 0,
                                                                        "slug": data.slug(fl["manufacturer"] or "Unknown")})
            m["cars"] += fl["qty_active"] or 0
            m["fleets"] += 1
    sup_names = {r["supplier_id"]: r["name"] for r in _rows("SELECT supplier_id, name FROM supplier")}
    parts = {}
    for fl in snap.values():
        for x in fl["installed"]:
            name = sup_names.get(x["supplier_id"]) or x.get("supplier")
            if name and hit(name, x.get("product"), x["subsystem"], COMPONENTS.get(x["subsystem"], "")):
                k = (x.get("supplier_id") or name, x["subsystem"], x.get("product") or "")
                d = parts.setdefault(k, {"supplier_id": x.get("supplier_id"), "supplier": name, "subsystem": x["subsystem"], "product": x.get("product"),
                                         "fleets": 0, "cars": 0})
                d["fleets"] += 1
                d["cars"] += fl["qty_active"] or 0
    return {"q": q, "operators": ops[:limit], "n_operators": len(ops), "fleets": fleets[:limit], "n_fleets": len(fleets),
            "builders": bld[:limit], "models": sorted(models.values(), key=lambda m: -m["cars"])[:limit], "n_models": len(models),
            "parts": sorted(parts.values(), key=lambda d: -d["cars"])[:limit], "n_parts": len(parts)}


def builders():
    out = {}
    for fl in snapshot().values():
        m = fl["manufacturer"] or "Unknown"
        b = out.setdefault(m, {"name": m, "slug": data.slug(m), "cars": 0, "fleets": 0, "operators": set(), "models": set(), "years": [],
                               "now": db.builder_now(m, fl.get("manufacturer_now"))})
        b["cars"] += fl["qty_active"] or 0
        b["fleets"] += 1
        b["operators"].add(fl["operator_id"])
        b["models"].add(fl["model_name"])
        if fl["build_year"]:
            b["years"].append(fl["build_year"])
    for b in out.values():
        b["oldest"] = min(b["years"]) if b["years"] else None
        b["newest"] = max(b["years"]) if b["years"] else None
    return sorted(out.values(), key=lambda b: -b["cars"])


def builder(slug):
    fls = [fl for fl in snapshot().values() if data.slug(fl["manufacturer"] or "Unknown") == slug]
    if not fls:  # a link from search or another lens (e.g. a freight rebuilder while viewing transit): show it unscoped, not a 404
        fls = [fl for fl in snapshot_all().values() if data.slug(fl["manufacturer"] or "Unknown") == slug]
    if not fls:
        return None
    models = {}
    for fl in fls:
        m = models.setdefault(fl["model_name"], {"model": fl["model_name"], "cls": fl["vehicle_class"], "cars": 0, "fleets": [], "operators": set(),
                                                  "years": []})
        m["cars"] += fl["qty_active"] or 0
        m["fleets"].append(fl)
        m["operators"].add(fl["operator_name"])
        if fl["build_year"]:
            m["years"].append(fl["build_year"])
    yr = this_year()
    for m in models.values():
        m["avg_age"] = round(yr - sum(m["years"]) / len(m["years"])) if m["years"] else None
        m["first"] = min(m["years"]) if m["years"] else None
        m["last"] = max(m["years"]) if m["years"] else None
    return {"name": fls[0]["manufacturer"] or "Unknown", "slug": slug, "models": sorted(models.values(), key=lambda m: -m["cars"]),
            "cars": sum(m["cars"] for m in models.values()), "fleets": fls}


# ---------------- per-fleet extras ----------------

def sources(fid):
    """Every source behind a fleet's numbers: NTD citations, seed research links, subsystem sources and the cost method."""
    rows = _rows("SELECT c.field_name, c.confidence, s.title, s.publisher, s.url, s.published FROM citation c LEFT JOIN source s USING (source_id) "
                 "WHERE c.table_name = 'fleet' AND c.row_key = ? ORDER BY s.title, c.field_name", (str(fid),))
    by = {}
    for r in rows:
        k = (r["title"] or "Unknown source", r["url"])
        b = by.setdefault(k, {"title": k[0], "url": k[1], "publisher": r["publisher"], "fields": [], "grade": r["confidence"]})
        b["fields"].append(r["field_name"].replace("_", " "))
    out = list(by.values())
    for r in _rows("SELECT sf.source_urls, sf.confidence FROM ntd_reconcile n JOIN seed_fleet sf ON sf.rowid = n.seed_rowid "
                   "WHERE ',' || n.ntd_fleet_ids || ',' LIKE ?", (f"%,{fid},%",)):
        for u in (r["source_urls"] or "").split(";"):
            if u.strip():
                out.append({"title": "Fleet research record", "url": u.strip(), "fields": ["model", "counts", "plans"], "grade": r["confidence"]})
    return out


def roster(fid):
    return _rows("SELECT unit_number, position, build_year, status, disposition, car_role, number_basis, confidence, notes FROM vehicle "
                 "WHERE fleet_id = ? ORDER BY position, unit_number", (fid,))


def history(fid, operator_id, limit=30):
    events = [dict(r) for r in db.q("SELECT ts, kind, detail FROM fleet_event WHERE fleet_id = ? ORDER BY id DESC LIMIT ?", (fid, limit))]
    # research edits to this fleet's subsystem records and its seed row
    sids = [x["sid"] for x in snapshot_all().get(fid, {}).get("installed", [])]
    if sids:
        q = ",".join("?" * len(sids))
        for r in _rows(f"SELECT ts, actor, action, table_name, note FROM edit_log WHERE table_name = 'seed_subsystem' AND row_id IN ({q}) "
                       "AND undone_by IS NULL ORDER BY id DESC LIMIT 20", sids):
            events.append({"ts": r["ts"], "kind": f"subsystem record {r['action']}", "detail": (r["note"] or "")[:160]})
    for r in _rows("SELECT e.ts, e.action, e.note FROM edit_log e JOIN ntd_reconcile n ON n.seed_rowid = e.row_id "
                   "WHERE e.table_name = 'seed_fleet' AND ',' || n.ntd_fleet_ids || ',' LIKE ? AND e.undone_by IS NULL ORDER BY e.id DESC LIMIT 10",
                   (f"%,{fid},%",)):
        events.append({"ts": r["ts"], "kind": f"fleet record {r['action']}", "detail": (r["note"] or "")[:160]})
    return sorted(events, key=lambda e: e["ts"] or "", reverse=True)[:limit]


# ---------------- bid <-> fleet matching ----------------

CLASS_WORDS = {"locomotive": ["locomotive", "locomotives"], "coach": ["coach", "coaches", "bilevel", "bi-level", "passenger car", "railcar"],
               "cab_car": ["cab car", "cab cars", "cab control"], "emu": ["emu", "electric multiple unit", "multiple unit"],
               "dmu": ["dmu", "diesel multiple unit"], "lrv": ["lrv", "light rail vehicle", "light rail vehicles"],
               "metro_car": ["subway car", "rail car", "railcar", "heavy rail vehicle", "transit car"],
               "streetcar": ["streetcar", "streetcars", "tram"]}


def _tokens(model):
    out = set()
    m = (model or "").strip()
    if len(m) >= 3:
        out.add(m.lower())
    for t in re.split(r"[\s/,()]+", m):
        t = t.strip("-.").lower()
        if len(t) >= 3 and (re.search(r"\d", t) or t in ("comet", "silverliner", "multilevel", "superliner", "amfleet", "horizon", "viewliner",
                                                          "acela", "charger", "genesis", "bombardier", "nippon", "kinkisharyo", "breda")):
            out.add(t)
    return out


def match_bid(n, fleets):
    """[(fleet, reason)] for the fleets a bid most likely concerns."""
    text = " ".join([n.get("title") or "", n.get("description") or "", n.get("summary") or ""]).lower()
    out = []
    for fl in fleets:
        hit = next((t for t in _tokens(fl["model_name"]) if re.search(r"(?<![a-z0-9])" + re.escape(t) + r"(?![a-z0-9])", text)), None)
        if hit:
            out.append((fl, f"names \"{hit}\""))
            continue
        words = CLASS_WORDS.get(fl["vehicle_class"] or "", [])
        w = next((w for w in words if re.search(r"(?<![a-z])" + re.escape(w) + r"(?![a-z])", text)), None)
        if w:
            out.append((fl, f"mentions {w}"))
    strong = [x for x in out if x[1].startswith("names")]
    return strong or out[:6]


def bids_for_fleet(fl, limit=8):
    rows = data.notices_for_operator(fl["operator_id"], 40)
    if not rows:
        return []
    out = []
    for n in rows:
        full = data.notice(n["notice_id"]) or n
        m = match_bid(full, [fl])
        if m:
            out.append((n, m[0][1]))
    return out[:limit]


# ---------------- lists, notes, contacts (team-scoped) ----------------

def owner_id(u):
    """Lists, notes and contacts are shared across a team: they belong to the team owner."""
    return u["team_owner_id"] or u["id"]


def lists_for(u):
    return [dict(r) for r in db.q("SELECT l.*, (SELECT count(*) FROM fleet_list_item i WHERE i.list_id = l.id) n FROM fleet_list l "
                                  "WHERE owner_id = ? ORDER BY l.name", (owner_id(u),))]


def get_list(u, lid):
    r = db.q("SELECT * FROM fleet_list WHERE id = ? AND owner_id = ?", (lid, owner_id(u)), one=True)
    return dict(r) if r else None


def list_fleets(lid):
    snap = snapshot_all()
    out = []
    for r in db.q("SELECT * FROM fleet_list_item WHERE list_id = ? ORDER BY added", (lid,)):
        fl = snap.get(r["fleet_id"])
        if fl:
            out.append({"fleet": fl, "note": r["note"], "added": r["added"]})
    return out


def lists_with_fleet(u, fid):
    return {r["list_id"] for r in db.q("SELECT i.list_id FROM fleet_list_item i JOIN fleet_list l ON l.id = i.list_id "
                                       "WHERE l.owner_id = ? AND i.fleet_id = ?", (owner_id(u), fid))}


def notes_for(u, operator_id, fleet_id=None):
    sql = "SELECT * FROM account_note WHERE owner_id = ? AND operator_id = ?"
    args = [owner_id(u), operator_id]
    if fleet_id:
        sql += " AND (fleet_id = ? OR fleet_id IS NULL)"
        args.append(fleet_id)
    return [dict(r) for r in db.q(sql + " ORDER BY id DESC LIMIT 50", args)]


def contacts_for(u, operator_id):
    return [dict(r) for r in db.q("SELECT * FROM contact WHERE owner_id = ? AND operator_id = ? ORDER BY name", (owner_id(u), operator_id))]


def pref(u, key, default=None):
    r = db.q("SELECT value FROM user_pref WHERE user_id = ? AND key = ?", (u["id"], key), one=True)
    return r["value"] if r else default


PROFILE_FIELDS = [  # optional business contact and social fields on Account > Profile: (key, label, kind)
    ("title", "Title / position", "text"), ("phone", "Business phone", "tel"), ("website", "Company website", "url"),
    ("segment", "Industry segment", "segment"), ("linkedin", "LinkedIn", "url"), ("x", "X (Twitter)", "url"),
    ("facebook", "Facebook", "url"), ("instagram", "Instagram", "url"), ("youtube", "YouTube", "url"),
]
SEGMENTS = ["Rolling stock OEM", "Component or subsystem supplier", "Overhaul and MRO", "Signals, systems and infrastructure",
            "Engineering and consulting", "Transit agency or railroad", "Leasing or finance", "Other"]


def profile(u):
    rows = db.q("SELECT key, value FROM user_pref WHERE user_id = ? AND key LIKE 'p\\_%' ESCAPE '\\'", (u["id"],))
    return {r["key"][2:]: r["value"] for r in rows}


def save_profile(u, form):
    for key, _, kind in PROFILE_FIELDS:
        v = (form.get(key) or "").strip()[:300]
        if kind == "url" and v and not v.lower().startswith(("http://", "https://")):
            v = "https://" + v
        if kind == "segment" and v not in SEGMENTS:
            v = ""
        if v:
            set_pref(u, "p_" + key, v)
        else:
            db.x("DELETE FROM user_pref WHERE user_id = ? AND key = ?", (u["id"], "p_" + key))


def personas_for(u):
    """Every "what you sell" pick, primary first (older accounts have only the single persona pref)."""
    keys = [k for k in (pref(u, "personas") or "").split(",") if k in lens.personas()]
    p = pref(u, "persona")
    if p in lens.personas() and p not in keys:
        keys.insert(0, p)
    return keys


def set_personas(u, keys, regions):
    """Account page: save any/all personas. The first is the default dashboard; trades become the union of all picks. The default
    lens only changes when the picks change."""
    keys = [k for k in dict.fromkeys(keys) if k in lens.personas()]
    if keys == personas_for(u):
        set_pref(u, "regions", ",".join(r for r in regions if r in lens.REGIONS))
        return
    if not keys:
        for k in ("persona", "personas"):
            db.x("DELETE FROM user_pref WHERE user_id = ? AND key = ?", (u["id"], k))
        set_pref(u, "regions", ",".join(r for r in regions if r in lens.REGIONS))
        return
    apply_signup_choices(u, keys, regions, starter_alert=False)


def set_pref(u, key, value):
    db.x("INSERT INTO user_pref (user_id, key, value) VALUES (?,?,?) ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value",
         (u["id"], key, value))


# ---------------- operator extras ----------------

def operator_extras(oid):
    oms = operator_mode_stats()
    modes = {m: d for (o, m), d in oms.items() if o == oid}
    snap = snapshot_all()
    fls = [fl for fl in snap.values() if fl["operator_id"] == oid]
    for m, d in modes.items():
        act = sum(fl["qty_active"] or 0 for fl in fls if fl["ntd_mode"] == m)
        d["active"] = act
        d["spare_pct"] = round(100 * (act - d["voms"]) / d["voms"]) if d.get("voms") and act else None
    climate = db.fq("SELECT * FROM seed_climate WHERE operator_id = ?", (oid,), one=True)
    return {"modes": modes, "plans": [dict(r) for r in db.q("SELECT * FROM plan_event WHERE operator_id = ? ORDER BY year_planned", (oid,))],
            "funding": [dict(r) for r in db.q("SELECT * FROM funding_award WHERE operator_id = ? ORDER BY award_date DESC", (oid,))],
            "contracts": [dict(r) for r in db.q("SELECT * FROM fleet_contract WHERE operator_id = ? ORDER BY end_date", (oid,))],
            "costs_manual": [dict(r) for r in db.q("SELECT * FROM operator_cost_manual WHERE operator_id = ? ORDER BY report_year DESC", (oid,))],
            "climate": dict(climate) if climate else None,
            "fleets": sorted(fls, key=lambda f: -(f["qty_active"] or 0)),
            "signals": sorted({s for fl in fls for s in fl["signals"]}, key=lambda s: s[0]),
            "signal_summary": _signal_summary(fls)}


def _signal_summary(fls):
    """One (code, tooltip) per signal across an operator's fleets, so the header shows each kind once."""
    by = {}
    for fl in fls:
        for code, text in fl["signals"]:
            by.setdefault(code, [])
            if text not in by[code]:
                by[code].append(text)
    return [(code, "; ".join(t[:4]) + (f" (+{len(t) - 4} more)" if len(t) > 4 else "")) for code, t in sorted(by.items())]


def manual_cost_view(r):
    """A manually entered (Canadian) cost row turned into US$ per car-mile, so it compares with the NTD numbers."""
    fx = r.get("usd_per_unit") or 1
    miles = (r.get("car_km") or 0) * 0.621371
    out = dict(r)
    out["maint_usd_per_car_mile"] = round(r["vehicle_maint"] * fx / miles, 2) if r.get("vehicle_maint") and miles else None
    out["opex_usd_per_car_mile"] = round(r["opex_total"] * fx / miles, 2) if r.get("opex_total") and miles else None
    out["maint_usd_per_car_year"] = round(r["vehicle_maint"] * fx / r["active_cars"]) if r.get("vehicle_maint") and r.get("active_cars") else None
    return out


# ---------------- fleet change detection (feeds alerts) ----------------

WATCHED_FIELDS = ("qty_active", "qty_total_current", "midlife_due_year", "ulb_year", "engine_overhaul_due_year", "last_rebuild_year",
                  "maint_cost_per_car_mile", "n_subsystems", "planned")
FIELD_LABELS = {"qty_active": "Active units", "qty_total_current": "Total units", "midlife_due_year": "Midlife due", "ulb_year": "End of useful life",
                "engine_overhaul_due_year": "Engine overhaul due", "last_rebuild_year": "Last rebuild", "maint_cost_per_car_mile": "Maintenance $/car-mile",
                "n_subsystems": "Subsystem records", "planned": "Announced program", "new_fleet": "New fleet"}


def _vals(fl, est=frozenset()):
    """est: fleet ids whose cost is a model estimate (1.7.30); their cost is not watched, so loading estimates sends no alerts."""
    return {"qty_active": fl["qty_active"], "qty_total_current": fl["qty_total_current"], "midlife_due_year": fl["midlife_due_year"],
            "ulb_year": fl["ulb_year"], "engine_overhaul_due_year": fl["engine_overhaul_due_year"], "last_rebuild_year": fl["last_rebuild_year"],
            "maint_cost_per_car_mile": round(fl["maint_cost_per_car_mile"], 2) if fl["maint_cost_per_car_mile"] and fl.get("fleet_id") not in est else None,
            "n_subsystems": len(fl["installed"]), "planned": (fl["plans"][0]["title"] if fl["plans"] else fl["planned_text"]) or None}


def detect_changes():
    """Compare every active fleet with the last snapshot and record what changed. The first run only takes the baseline."""
    snap = snapshot_all()
    try:
        from .data import EST_SQL
        est = frozenset(r[0] for r in db.fq(EST_SQL))
    except Exception:
        est = frozenset()
    old = {r["fleet_id"]: json.loads(r["vals"]) for r in db.q("SELECT fleet_id, vals FROM fleet_snapshot")}
    first = not old
    now = db.now()
    events = 0
    c = db.connect()
    try:
        for fid, fl in snap.items():
            v = _vals(fl, est)
            prev = old.get(fid)
            if prev is None:
                if not first:
                    c.execute("INSERT INTO fleet_event (ts, fleet_id, operator_id, kind, detail) VALUES (?,?,?,?,?)",
                              (now, fid, fl["operator_id"], "new_fleet", f"New fleet: {fl['manufacturer'] or ''} {fl['model_name']}, {units.count(fl)}"))
                    events += 1
            else:
                for k in WATCHED_FIELDS:
                    a, b = prev.get(k), v.get(k)
                    if a == b:
                        continue
                    if k == "maint_cost_per_car_mile" and a and b and abs(b - a) / a < 0.10:
                        continue
                    c.execute("INSERT INTO fleet_event (ts, fleet_id, operator_id, kind, detail) VALUES (?,?,?,?,?)",
                              (now, fid, fl["operator_id"], k, f"{units.label(fl) if k == 'qty_active' else ('Total ' + units.word(fl)) if k == 'qty_total_current' else FIELD_LABELS[k]}: {a if a is not None else '—'} → {b if b is not None else '—'}"))
                    events += 1
            c.execute("INSERT INTO fleet_snapshot (fleet_id, vals, ts) VALUES (?,?,?) ON CONFLICT(fleet_id) DO UPDATE SET vals = excluded.vals, ts = excluded.ts",
                      (fid, json.dumps(v), now))
        c.commit()
    finally:
        c.close()
    return events


FLEET_FILTER_DEFAULT = {"scope": "followed", "kinds": [], "modes": [], "classes": [], "ops": [], "countries": [], "territory": False}


def fleet_filter(u):
    """1.7.74 (Justin 11-18, "there's no way to configure a fleet update"): what Fleet updates covers for this member.
    scope 'followed' = fleets and operators they follow or keep in a list; 'all' = every fleet. The other keys narrow either
    scope (empty = any): kinds of change (FIELD_LABELS keys), NTD modes, vehicle classes, operators, countries, and territory."""
    try:
        f = json.loads(pref(u, "fleet_filter") or "{}")
    except (TypeError, ValueError):
        f = {}
    out = dict(FLEET_FILTER_DEFAULT)
    out.update({k: v for k, v in f.items() if k in out})
    return out


def events_for_user(u, since=None, limit=50):
    """Fleet changes this member asked for (fleet_filter): fleets and operators they follow or keep in a list, or every fleet,
    narrowed by kind of change, mode, vehicle type, operator, country and territory."""
    ff = fleet_filter(u)
    fleets = {int(r["ref"]) for r in db.q("SELECT ref FROM watch WHERE user_id = ? AND kind = 'fleet'", (u["id"],)) if str(r["ref"]).isdigit()}
    fleets |= {r["fleet_id"] for r in db.q("SELECT i.fleet_id FROM fleet_list_item i JOIN fleet_list l ON l.id = i.list_id WHERE l.owner_id = ?",
                                            (owner_id(u),))}
    ops = {r["ref"] for r in db.q("SELECT ref FROM watch WHERE user_id = ? AND kind = 'operator'", (u["id"],))}
    every = ff["scope"] == "all"
    if not every and not fleets and not ops:
        return []
    ter_ops = None
    if ff.get("territory"):
        from . import territory
        t = territory.for_user(u)
        ter_ops = territory.resolve(t)[0] if territory.is_set(t) else None
    kinds, modes, classes, pick_ops, ctry = (set(ff[k] or []) for k in ("kinds", "modes", "classes", "ops", "countries"))
    rows = db.q("SELECT * FROM fleet_event WHERE ts > ? ORDER BY id DESC LIMIT 5000", (since or "",))
    snap = snapshot_all()
    out = []
    for r in rows:
        fl = snap.get(r["fleet_id"]) or {}
        if kinds and r["kind"] not in kinds:
            continue
        if modes and fl.get("ntd_mode") not in modes:
            continue
        if classes and fl.get("vehicle_class") not in classes:
            continue
        if pick_ops and r["operator_id"] not in pick_ops:
            continue
        if ctry and (fl.get("country") or "US") not in ctry:
            continue
        if ter_ops is not None and r["operator_id"] not in ter_ops:
            continue
        if every or r["fleet_id"] in fleets or r["operator_id"] in ops:
            d = dict(r)
            d["fleet"] = snap.get(r["fleet_id"])
            d["detail"] = units.fix_detail(d.get("detail"), d["fleet"])
            out.append(d)
            if len(out) >= limit:
                break
    return out


# ---------------- CRM export ----------------

def crm_rows(opps, fmt="salesforce"):
    """Opportunity rows shaped for a Salesforce or HubSpot import. Close date = expected award: two years before a
    replacement, one year before an overhaul or retrofit."""
    out = []
    for o in opps:
        fl = o["fleet"]
        lead = 2 if o["event"] in ("replace",) else 1
        close = f"{max(this_year(), o['year'] - lead)}-06-30"
        name = f"{fl['operator_name']} {fl['manufacturer'] or ''} {fl['model_name']} {EVENT_LABELS.get(o['event'], o['event'])}".replace("  ", " ")
        desc = (f"{o['cars']} active units, built {fl['build_year'] or '?'}; event year {o['year']}. "
                + "; ".join(s[1] for s in fl["signals"])
                + f". Consist fleet {fl['fleet_id']}: {config.SITE_URL}/app/fleets/{fl['fleet_id']}")
        if fmt == "hubspot":
            out.append({"Deal Name": name, "Associated Company": fl["operator_name"], "Amount": round(o["value"]), "Close Date": close,
                        "Deal Stage": "appointmentscheduled" if o["year"] <= this_year() + 1 else "qualifiedtobuy", "Pipeline": "default",
                        "Description": desc})
        else:
            out.append({"Opportunity Name": name, "Account Name": fl["operator_name"], "Amount": round(o["value"]), "Close Date": close,
                        "Stage": "Prospecting" if o["year"] > this_year() + 1 else "Qualification", "Type": EVENT_LABELS.get(o["event"], o["event"]),
                        "Lead Source": "Consist", "Description": desc})
    return out


# ---------------- subsystems: the installed base by component ----------------

def subsystem_view(subsystem=None, supplier=None, due_within=None):
    """Fleets with a subsystem record in the current lens: rows, supplier share and coverage for one subsystem (or all)."""
    yr = this_year()
    rows, share, covered, cars_cov = [], {}, set(), 0
    snap = snapshot()
    names = {r["supplier_id"]: r["name"] for r in _rows("SELECT supplier_id, name FROM supplier")}
    for fid, fl in snap.items():
        recs = [x for x in fl["installed"] if not subsystem or x["subsystem"] == subsystem]
        if not recs:
            continue
        n = fl["qty_active"] or 0
        if fid not in covered:
            covered.add(fid)
            cars_cov += n
        ids = {x["supplier_id"] or (x["supplier"] or "").strip() or None for x in recs} - {None}
        for i in ids:
            share[i] = share.get(i, 0) + n / len(ids)
        if supplier and supplier not in ids:
            continue
        nxt = fl["midlife_due_year"] if fl["midlife_due_year"] and not fl["last_rebuild_year"] else None
        if due_within and not (nxt and nxt <= yr + int(due_within)):
            continue
        for x in recs:
            rows.append({"fleet": fl, "rec": x, "supplier_name": names.get(x["supplier_id"]) or x["supplier"] or "Unknown",
                         "installed": fl["last_rebuild_year"] or fl["build_year"], "next": nxt})
    tot = sum(share.values()) or 1
    share_rows = sorted(((names.get(k, k), v, round(100 * v / tot)) for k, v in share.items()), key=lambda r: -r[1])
    rows.sort(key=lambda r: (r["next"] or 9999, -(r["fleet"]["qty_active"] or 0)))
    return {"rows": rows, "share": share_rows, "fleets": len(covered), "cars": cars_cov,
            "all_fleets": len(snap), "all_cars": sum(fl["qty_active"] or 0 for fl in snap.values())}


# ---------------- cost benchmarks: NTD (transit, passenger) and STB R-1 (freight) ----------------

def transit_costs():
    """Latest operating and maintenance cost per car revenue mile by operator and mode, plus median trends by mode."""
    sc = lens.current()
    w, a = sc.sql("t.ntd_mode", "o.country", territory=False)  # 1.7.45: benchmarks stay national (peer medians)
    rows = _rows("SELECT t.*, o.operator_name, o.country FROM operator_cost_trend t JOIN operator o USING (operator_id) "
                 f"WHERE {w} ORDER BY t.operator_id, t.ntd_mode, t.report_year", a)
    latest, trend = {}, {}
    for r in rows:
        latest[(r["operator_id"], r["ntd_mode"])] = r
        if r["vm_per_car_rev_mile"]:
            trend.setdefault(data.MODE_ALIASES.get(r["ntd_mode"], r["ntd_mode"]), {}).setdefault(r["report_year"], []).append(r["vm_per_car_rev_mile"])
    series = [(data.MODES.get(m, m), [(y, round(statistics.median(v), 2)) for y, v in sorted(ys.items())])
              for m, ys in sorted(trend.items(), key=lambda kv: -sum(len(v) for v in kv[1].values()))[:5]]
    cdy = rows[0]["constant_dollar_year"] if rows else None
    return sorted(latest.values(), key=lambda r: -(r["vm_per_car_rev_mile"] or 0)), series, cdy


def freight_costs():
    """STB R-1 locomotive cost and use per Class I railroad (US operations), latest year, plus trends. Empty before the R-1 import."""
    sc = lens.current()
    if sc.modes and "FR" not in sc.modes:
        return [], [], []
    rows = _rows("SELECT s.*, o.operator_name, o.country FROM seed_freight_loco_year s LEFT JOIN operator o USING (operator_id) "
                 "ORDER BY s.r1_entity, s.report_year")
    if sc.regions:
        rows = [r for r in rows if (r["country"] or "US") in sc.regions]
    latest = {}
    cost, miles = {}, {}
    for r in rows:
        latest[r["r1_entity"]] = r
        label = r["entity_name"] or r["operator_name"] or r["r1_entity"]
        cost.setdefault(label, []).append((r["report_year"], r["loco_cost_per_unit_mile_2025usd"]))
        miles.setdefault(label, []).append((r["report_year"], r["miles_per_unit"]))
    top = sorted(latest.values(), key=lambda r: -(r["units_end"] or 0))
    keep = {r["entity_name"] or r["operator_name"] or r["r1_entity"] for r in top[:5]}
    return top, [(k, v) for k, v in cost.items() if k in keep], [(k, v) for k, v in miles.items() if k in keep]


def freight_history(operator_id):
    """R-1 rows for one railroad, oldest first (several entities can map to one operator)."""
    return _rows("SELECT * FROM seed_freight_loco_year WHERE operator_id = ? ORDER BY report_year, r1_entity", (operator_id,))


def freight_roster(operator_id):
    """A railroad's locomotive roster by model and build year, from its fleets."""
    fls = [fl for fl in snapshot_all().values() if fl["operator_id"] == operator_id]
    by_model = {}
    for fl in fls:
        k = (fl["manufacturer"] or "", fl["model_name"] or "Other")
        m = by_model.setdefault(k, {"manufacturer": k[0], "model": k[1], "units": 0, "years": [], "fleets": [], "classes": set()})
        m["units"] += fl["qty_active"] or fl["qty_total_current"] or 0
        if fl["build_year"]:
            m["years"].append(fl["build_year"])
        m["fleets"].append(fl)
        m["classes"].add(fl["vehicle_class"])
    out = sorted(by_model.values(), key=lambda m: -m["units"])
    for m in out:
        m["built"] = f"{min(m['years'])}–{max(m['years'])}" if m["years"] and min(m["years"]) != max(m["years"]) else (str(m["years"][0]) if m["years"] else "—")
    return out


def funding_rows(segment=None):
    """Grant and funding awards for operators in the current lens and region, newest first; segment narrows to transit,
    passenger or freight operators by their modes."""
    from .award_analyst import SEGMENT_MODES
    ops = {o["operator_id"]: o for o in data.operators()}
    want = SEGMENT_MODES.get(segment)
    rows = [dict(r) for r in db.q("SELECT * FROM funding_award ORDER BY award_date DESC")]
    out = []
    for r in rows:
        if r["operator_id"] in ops and (not want or {data.MODE_ALIASES.get(m, m) for m in str(ops[r["operator_id"]].get("modes") or "").split(";")} & want):
            r["operator_name"] = ops[r["operator_id"]]["operator_name"]
            out.append(r)
    return out


def apply_signup_choices(u, personas, regions, starter_alert=True):
    """Sign-up with several "what do you sell" picks: the first drives the home dashboard and default lens (all rail when the picks
    span markets), and the starter alert covers the trades of every pick."""
    keys = [k for k in dict.fromkeys(personas) if k in lens.personas()]
    set_pref(u, "regions", ",".join(r for r in regions if r in lens.REGIONS))
    if not keys:
        return
    set_pref(u, "persona", keys[0])
    set_pref(u, "personas", ",".join(keys))
    ls = {lens.PERSONAS[k]["lens"] for k in keys}
    set_pref(u, "lens", ls.pop() if len(ls) == 1 else "all")
    trades = list(dict.fromkeys(t for k in keys for t in lens.PERSONA_TRADES.get(k, [])))
    if trades:
        set_pref(u, "trades", ",".join(trades))
    if starter_alert and trades and not db.q("SELECT 1 FROM saved_search WHERE user_id = ?", (u["id"],), one=True):
        q = {"trades": ",".join(trades)}
        if len(regions) == 1:
            q["country"] = regions[0]
        sid = db.x("INSERT INTO saved_search (user_id, name, query, frequency, created) VALUES (?,?,?,?,?)",
                   (u["id"], "My trades: " + " + ".join(lens.PERSONAS[k]["label"] for k in keys), json.dumps(q), "weekly", db.now()))
        from . import alerts
        alerts.baseline(sid)


def apply_persona(u, persona, regions=None, starter_alert=False):
    """Save what the member sells and set the defaults that follow from it: lens, trades and (at sign-up) a starter alert."""
    if persona not in lens.personas():  # the freight persona only while freight is visible
        return
    set_pref(u, "persona", persona)
    set_pref(u, "lens", lens.PERSONAS[persona]["lens"])
    if regions is not None:
        set_pref(u, "regions", ",".join(r for r in regions if r in lens.REGIONS))
    trades = lens.PERSONA_TRADES.get(persona, [])
    set_pref(u, "trades", ",".join(trades))
    if starter_alert and trades and not db.q("SELECT 1 FROM saved_search WHERE user_id = ?", (u["id"],), one=True):
        q = {"trades": ",".join(trades)}
        if regions and len(regions) == 1:
            q["country"] = regions[0]
        sid = db.x("INSERT INTO saved_search (user_id, name, query, frequency, created) VALUES (?,?,?,?,?)",
                   (u["id"], f"My trades: {lens.PERSONAS[persona]['label']}", json.dumps(q), "weekly", db.now()))
        from . import alerts
        alerts.baseline(sid)


# ---------------- vendor footprint (award winners matched to the installed base) ----------------

_STOP = {"inc", "incorporated", "corp", "corporation", "co", "company", "ltd", "limited", "llc", "lp", "llp", "sa", "ag", "gmbh", "plc",
         "the", "group", "holdings", "usa", "us", "canada", "of", "and", "na", "ulc", "ltee", "lt", "srl", "spa", "bv", "nv"}
_fp = {"key": None, "map": None}


def vendor_key(name):
    """A loose company key: lower case, punctuation and legal suffixes dropped ("Alstom Transport Inc." -> "alstom transport")."""
    words = re.sub(r"[^a-z0-9]+", " ", (name or "").lower()).split()
    return " ".join(w for w in words if w not in _STOP)


def vendor_footprint():
    """vendor_key -> {"cars", "fleets": set, "operators": set} over every fleet in service, as builder or as a subsystem supplier
    (cars split evenly when a fleet has several suppliers for one subsystem). Cached with the fleet snapshot."""
    snap = snapshot_all()
    if _fp["key"] is snap:
        return _fp["map"]
    names = {r["supplier_id"]: r["name"] for r in _rows("SELECT supplier_id, name FROM supplier")}
    out = {}

    def add(name, fl, cars):
        k = vendor_key(name)
        if not k:
            return
        d = out.setdefault(k, {"cars": 0.0, "fleets": set(), "operators": set()})
        d["cars"] += cars
        d["fleets"].add(fl["fleet_id"])
        d["operators"].add(fl["operator_id"])

    for fl in snap.values():
        cars = fl["qty_active"] or 0
        if (fl.get("manufacturer_now") or fl["manufacturer"]):
            add((fl.get("manufacturer_now") or fl["manufacturer"]), fl, cars)
        by_sub = {}
        for x in fl["installed"]:
            label = names.get(x["supplier_id"]) or (x["supplier"] or "").strip()
            if label:
                by_sub.setdefault(x["subsystem"], set()).add(label)
        for labels in by_sub.values():
            for label in labels:
                add(label, fl, cars / len(labels))
    _fp.update(key=snap, map=out)
    return out


def vendor_match(name, fp=None):
    """The installed-base footprint for an award vendor name: exact key, else a footprint key sharing its first word (5+ letters)."""
    fp = fp if fp is not None else vendor_footprint()
    k = vendor_key(name)
    if not k:
        return None
    if k in fp:
        return fp[k]
    first = k.split()[0]
    if len(first) < 5:
        return None
    hits = [v for key, v in fp.items() if key.split()[0] == first]
    if not hits:
        return None
    return {"cars": sum(h["cars"] for h in hits), "fleets": set().union(*(h["fleets"] for h in hits)),
            "operators": set().union(*(h["operators"] for h in hits))}
