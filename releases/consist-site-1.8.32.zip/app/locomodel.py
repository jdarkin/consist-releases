"""Locomotive model names (1.8.26, Justin 11-26: locomotives are not cars). No imports from the app, so db.py can use it
when it builds the v_fleet_profile shadow view: a fleet whose model is a known locomotive (MP40PH-3C, MP54AC, F40PH-3C, SC-44,
ALC-42, ...) is shown as a locomotive even when a source row typed it as a coach or car."""
import re

# Model names that are always locomotives, whatever the source row says.
LOCO_MODEL = re.compile(
    r"\b(MP\d{2}(?:[A-Z][A-Z0-9-]*)?|F40[A-Z]{1,3}(?:-[0-9A-Z]+)?|BL\d{2}[A-Z]*|DE30AC|HHP-?8|F59PH[A-Z0-9]*|F125|SC-?44|SC-?42|ALC-?42|ACS-?64|ALP-?4[456][A-Z0-9]*|"
    r"P4[02]DC|P32AC-?DM|P32-?8|HSP-?46|AEM-?7|DM-?30AC|GP\d{1,2}(?:[A-Z][A-Z0-9-]*)?|SD(?:40|45|60|70|75|80|90)(?:[A-Z][A-Z0-9-]*)?|MP36PH|MPXpress|"
    r"Charger|Genesis|Dash ?8|ES44[A-Z0-9]*|AC4400[A-Z]*|ET44[A-Z0-9]*|SW\d{3,4}|AC-?6000|PL42AC|E60|FL9|GE ?P30CH)\b",
    re.I)
# ...but not when the name says it is a cab car or coach paired with one ("MP36 cab car" does not occur, "Charger cab car" might)
NOT_LOCO = re.compile(r"\b(cab ?cars?|coach(es)?|bi-?level|multi-?level|trailer|control car|gallery)\b", re.I)


def fix(cls, model):
    """The vehicle class to show: 'locomotive' when the model is a known locomotive model and the row says otherwise."""
    c = (cls or "").strip().lower()
    if "locomotive" in c or c in ("switcher", "slug"):
        return cls
    if model and LOCO_MODEL.search(model) and not NOT_LOCO.search(model):
        return "locomotive"
    return cls
