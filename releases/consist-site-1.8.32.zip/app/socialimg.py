"""Chart images for LinkedIn posts and for "Embed this chart" on the public /data pages (awareness plan Phase 1, 1.7.36).

One renderer, three charts, all from the same public queries as the /data pages (seo.py), so a chart never shows more than
the free pages already do:
  midlife  - cars coming due for midlife overhaul, by year, next 6 years
  oldest   - the oldest passenger rail fleets still in service (age in years)
  bids     - rail-relevant bids posted in the last 30 days, by category
Images are 1200x627 PNG (LinkedIn's link and image size), drawn with Pillow and the site's IBM Plex fonts, cached in
DATA_DIR/social/<chart>-<YYYY-MM-DD>.png for a day. Every image carries the source line and site address, so a copy
that travels without its link still points back to the site."""
import datetime
import glob
import os

from . import config, db

W, H = 1200, 627
BG, INK, MUTED, LINE = "#f6f5f1", "#0f1b26", "#5a6772", "#e2e0d8"
BRAND, ACCENT = "#0b6b5d", "#e8a317"
FONTS = os.path.join(os.path.dirname(__file__), "static", "fonts")

CHARTS = {
    "midlife": {"title": "Rail cars coming due for midlife overhaul", "page": "/data/midlife-overhauls-due",
                "alt": "Bar chart of US and Canadian passenger rail cars reaching their midlife overhaul window each year"},
    "oldest": {"title": "Oldest passenger rail fleets still in service", "page": "/data/oldest-rail-fleets",
               "alt": "Bar chart of the oldest US and Canadian passenger rail fleets still in service, by age"},
    "bids": {"title": "Rail bids posted in the last 30 days", "page": "/data/rail-bids-this-month",
             "alt": "Bar chart of rail-relevant procurement notices posted by US and Canadian agencies in the last 30 days, by category"},
}


def _font(size, bold=False):
    from PIL import ImageFont
    return ImageFont.truetype(os.path.join(FONTS, "IBMPlexSans-SemiBold.ttf" if bold else "IBMPlexSans-Regular.ttf"), size)


def _fit(g, text, font, width):
    """Shorten a label with an ellipsis until it fits."""
    if g.textlength(text, font=font) <= width:
        return text
    while text and g.textlength(text + "…", font=font) > width:
        text = text[:-1]
    return text.rstrip() + "…"


def series(chart):
    """(subtitle, [(label, value, value_text)]) for a chart, or (None, []) when there is no data."""
    from . import seo
    y = datetime.date.today().year
    if chart == "midlife":
        by = {}
        for f in seo.midlife_due():
            by[f["midlife_due_year"]] = by.get(f["midlife_due_year"], 0) + (f["qty_active"] or 0)
        rows = [(str(k), v, f"{v:,}") for k, v in sorted(by.items()) if y <= k <= y + 5]
        total = sum(v for _, v, _ in rows)
        return (f"{total:,} units in US and Canadian passenger rail fleets, {y} to {y + 5}" if rows else None), rows
    if chart == "oldest":
        from .promo import _name
        rows, seen = [], set()
        for f in seo.oldest_fleets():
            k = (f["operator_id"], f["model_name"])
            if k in seen or not f["build_year"]:
                continue
            seen.add(k)
            rows.append((f"{_name(f)} {f['model_name'] or ''}".strip(), y - f["build_year"], f"{y - f['build_year']} yrs ({f['build_year']})"))
            if len(rows) == 8:
                break
        return ("Age of fleets of five or more cars, US and Canada" if rows else None), rows
    if chart == "bids":
        from . import data as d
        b = seo.bids_month()
        rows = [(d.CATEGORIES.get(c["category"], c["category"] or "Other")[:38], c["n"], f"{c['n']:,}") for c in b["cats"][:8]]
        return (f"{b['total']:,} rail-relevant notices from US and Canadian agencies" if rows else None), rows
    return None, []


def render(chart):
    """PNG bytes for a chart (drawn fresh)."""
    from io import BytesIO

    from PIL import Image, ImageDraw
    meta = CHARTS[chart]
    sub, rows = series(chart)
    site = db.settings().get("site_name", "Consist")
    img = Image.new("RGB", (W, H), BG)
    g = ImageDraw.Draw(img)
    g.rectangle([0, 0, W, 10], fill=BRAND)
    g.text((60, 44), meta["title"], font=_font(44, True), fill=INK)
    g.text((60, 104), sub or "No data this month", font=_font(26), fill=MUTED)
    top, bottom, left, right = 170, H - 92, 60, W - 60
    if rows:
        vmax = max(v for _, v, _ in rows) or 1
        vertical = chart == "midlife"
        if vertical:
            n = len(rows)
            slot = (right - left) / n
            bw = min(120, slot * 0.6)
            for i, (lab, v, vt) in enumerate(rows):
                cx = left + slot * (i + 0.5)
                h = (bottom - 46 - top) * v / vmax
                y0 = bottom - 40 - h
                g.rectangle([cx - bw / 2, y0, cx + bw / 2, bottom - 40], fill=BRAND if i else ACCENT)
                f = _font(26, True)
                g.text((cx, y0 - 8), vt, font=f, fill=INK, anchor="md")
                g.text((cx, bottom - 30), lab, font=_font(26), fill=MUTED, anchor="ma")
        else:
            n = len(rows)
            slot = (bottom - top) / n
            bh = min(40, slot * 0.68)
            lw = 430
            for i, (lab, v, vt) in enumerate(rows):
                cy = top + slot * (i + 0.5)
                g.text((left, cy), _fit(g, lab, _font(24), lw - 20), font=_font(24), fill=INK, anchor="lm")
                w = (right - left - lw - 190) * v / vmax
                g.rectangle([left + lw, cy - bh / 2, left + lw + max(w, 4), cy + bh / 2], fill=ACCENT if i == 0 else BRAND)
                g.text((left + lw + max(w, 4) + 12, cy), vt, font=_font(24, True), fill=INK, anchor="lm")
    g.line([60, H - 70, W - 60, H - 70], fill=LINE, width=2)
    src = "Source: FTA NTD, agency documents" if chart != "bids" else "Source: agency procurement portals"
    g.text((60, H - 38), f"{src} · {datetime.date.today():%b %Y}", font=_font(22), fill=MUTED, anchor="lm")
    host = config.SITE_URL.split("//")[-1]
    g.text((W - 60, H - 38), f"{site} · {host}", font=_font(24, True), fill=BRAND, anchor="rm")
    out = BytesIO()
    img.save(out, "PNG", optimize=True)
    return out.getvalue()


def png(chart):
    """Cached PNG bytes for today (a new file each day; older ones are cleared)."""
    if chart not in CHARTS:
        raise KeyError(chart)
    d = os.path.join(config.DATA_DIR, "social")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{chart}-{datetime.date.today().isoformat()}.png")
    if os.path.exists(path):
        with open(path, "rb") as fh:
            return fh.read()
    data = render(chart)
    for old in glob.glob(os.path.join(d, f"{chart}-*.png")):
        try:
            os.remove(old)
        except OSError:
            pass
    with open(path + ".tmp", "wb") as fh:
        fh.write(data)
    os.replace(path + ".tmp", path)
    return data


def url(chart, ref=""):
    return f"{config.SITE_URL}/img/chart/{chart}.png" + (f"?ref={ref}" if ref else "")


def embed_code(chart):
    """HTML snippet for 'Embed this chart': the image linked to its /data page, with a visible credit link (the backlink)."""
    import html
    meta = CHARTS[chart]
    site = db.settings().get("site_name", "Consist")
    page = f"{config.SITE_URL}{meta['page']}?ref=embed"
    return (f'<figure style="margin:0;max-width:720px"><a href="{page}"><img src="{url(chart, "embed")}" width="1200" height="627" '
            f'style="width:100%;height:auto" alt="{html.escape(meta["alt"])}" loading="lazy"></a>'
            f'<figcaption style="font:13px sans-serif">Data: <a href="{page}">{html.escape(site)}, {html.escape(meta["title"])}</a>'
            f'</figcaption></figure>')
