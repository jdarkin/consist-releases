"""NexGen pages: pursuits, watchlist, investors, my agency, data corrections (member side and Admin review)."""
import csv
import io
import statistics
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import Response, StreamingResponse

from . import auth, data, db, intel, nexgen
from .main import flash, redirect, render
from .routes_app import can_save, watched

app = APIRouter(prefix="/app")
admin = APIRouter(prefix="/admin")
U = Depends(auth.require_user)
A = Depends(auth.require_admin)


def _back(request, default):
    ref = request.headers.get("referer") or ""
    path = "/" + ref.split("://", 1)[-1].split("/", 1)[-1] if "://" in ref else ""
    return path if path.startswith("/app") else default


def _cell(v):
    """Spreadsheet formula injection guard: text that starts with = + - @ (or a tab / CR) is prefixed with ' so Excel shows it as text."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def _export(request, name, head, rows):
    """?export=csv or ?export=xlsx. Every export carries an About sheet (or footer line) with terms and sources."""
    fmt = request.query_params.get("export")
    if fmt == "xlsx":
        body = nexgen.xlsx([(name, head, rows), nexgen.about_sheet(name)])
        return Response(body, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f'attachment; filename="{name}.xlsx"'})
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(head)
    w.writerows([[_cell(v) for v in r] for r in rows])
    w.writerow([])
    w.writerow([f"Consist export {name}. Internal use only, not for resale. Sources: see the source column and /p/methodology."])
    return StreamingResponse(iter(["﻿" + buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})


def _can_export(u):
    return u.is_admin or u.can("export")


# ---------------- pursuits ----------------

@app.get("/pursuits")
def pursuits_page(request: Request, u=U):
    if nexgen.is_agency(u):
        raise HTTPException(404)
    stage = request.query_params.get("stage", "open")
    rows = nexgen.pursuits(u, stage)
    decision = request.query_params.get("decision") or None  # go/no-go pill filter (1.7.4)
    if decision:
        rows = [r for r in rows if (r["decision"] or "") == decision]
    f = {k: v for k, v in (("stage", stage if stage != "open" else None), ("decision", decision)) if v}
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-pursuits", ["Title", "Type", "Stage", "Decision", "Lead", "Value (USD)", "Due", "Notes", "Link", "Updated"],
                       [(r["title"], nexgen.KINDS.get(r["kind"], r["kind"]), nexgen.STAGE_LABELS.get(r["stage"]), nexgen.DECISIONS.get(r["decision"] or ""),
                         r["lead"], r["value_usd"], r["due"], r["note"], (request.base_url._url.rstrip("/") + r["href"]) if r["href"] else "", (r["updated"] or "")[:10])
                        for r in rows])
    summ = nexgen.pursuit_summary(nexgen.pursuits(u, "all"))
    return render(request, "app/nx_pursuits.html", user=u, f=f, rows=rows, stage=stage, summ=summ, STAGES=nexgen.STAGES,
                  STAGE_LABELS=nexgen.STAGE_LABELS, DECISIONS=nexgen.DECISIONS, KINDS=nexgen.KINDS, can_export=_can_export(u))


@app.post("/pursuits")
def pursuits_add(request: Request, csrf: str = Form(""), kind: str = Form("other"), ref: str = Form(""), title: str = Form(""),
                 operator_id: str = Form(""), value: str = Form(""), due: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if nexgen.is_agency(u):
        raise HTTPException(404)
    if not can_save(u):
        flash(request, "Tracking pursuits is on paid plans. Compare plans at /pricing.", "bad")
        return redirect(_back(request, "/app/pursuits"))
    if not title.strip():
        flash(request, "Give the pursuit a name.", "bad")
        return redirect(_back(request, "/app/pursuits"))
    try:
        v = float(value) if value.strip() else None
    except ValueError:
        v = None
    pid, new = nexgen.add_pursuit(u, kind, ref.strip(), title.strip(), operator_id or None, v, due or None)
    flash(request, "Added to your pursuits." if new else "That's already one of your pursuits.")
    return redirect(f"/app/pursuits?open={pid}#p{pid}")


@app.post("/pursuits/{pid}/save")
async def pursuits_save(request: Request, pid: int, u=U):
    form = dict(await request.form())
    auth.check_csrf(request, form.get("csrf", ""))
    if form.get("delete"):
        nexgen.delete_pursuit(u, pid)
        flash(request, "Pursuit removed.")
        return redirect("/app/pursuits")
    if not nexgen.update_pursuit(u, pid, form):
        raise HTTPException(404)
    flash(request, "Pursuit saved.")
    return redirect(f"/app/pursuits?stage={request.query_params.get('stage', 'open')}#p{pid}")


# ---------------- watchlist ----------------

@app.get("/watchlist")
def watchlist(request: Request, u=U):
    ops = [o for o in data.operators() if o["operator_id"] in watched(u, "operator")]
    snap = intel.snapshot_all()
    fleets = [snap[int(f)] for f in watched(u, "fleet") if f.isdigit() and int(f) in snap]
    notices = [n for n in (data.notice(int(i)) for i in watched(u, "notice") if i.isdigit()) if n]
    comps = sorted(watched(u, "company"))
    return render(request, "app/nx_watchlist.html", user=u, ops=ops, fleets=fleets, notices=notices, companies=comps,
                  keywords=nexgen.keyword_alerts(u), lists=intel.lists_for(u) if not nexgen.is_agency(u) else [])


@app.post("/watchlist/company")
def watch_company(request: Request, csrf: str = Form(""), name: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    name = name.strip()[:120]
    if name:
        if db.q("SELECT 1 FROM watch WHERE user_id = ? AND kind = 'company' AND ref = ?", (u["id"], name), one=True):
            db.x("DELETE FROM watch WHERE user_id = ? AND kind = 'company' AND ref = ?", (u["id"], name))
        elif can_save(u):
            db.x("INSERT INTO watch (user_id, kind, ref, created) VALUES (?,?,?,?)", (u["id"], "company", name, db.now()))
        else:
            flash(request, "Watchlists are on paid plans.", "bad")
    return redirect(_back(request, "/app/watchlist"))


# ---------------- corrections ----------------

@app.post("/corrections")
def correction_add(request: Request, csrf: str = Form(""), kind: str = Form(""), ref: str = Form(""), label: str = Form(""),
                   field: str = Form(""), current: str = Form(""), proposed: str = Form(""), source: str = Form(""), note: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if not proposed.strip() and not note.strip():
        flash(request, "Tell us what should change.", "bad")
    else:
        nexgen.add_correction(u, kind, ref, label, field, current, proposed, source, note)
        flash(request, "Thanks. We review every correction and update the record when it checks out.")
    return redirect(_back(request, "/app"))


@admin.get("/corrections")
def corrections_admin(request: Request, u=A):
    st = request.query_params.get("status", "new")
    return render(request, "admin/nx_corrections.html", user=u, rows=nexgen.corrections(st), cstatus=st, active="corrections")


@admin.post("/corrections/{cid}")
def corrections_review(request: Request, cid: int, csrf: str = Form(""), status: str = Form(""), note: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    nexgen.review_correction(cid, status, note)
    flash(request, f"Correction marked {status}.")
    return redirect("/admin/corrections")


# ---------------- procurement stages (admin) ----------------

@admin.get("/procurement-stages")
def proc_stages_admin(request: Request, u=A):
    st, q = request.query_params.get("stage", ""), request.query_params.get("q", "").strip()
    rows = nexgen.proc_stage_list(st or None, q or None)
    if request.query_params.get("export"):
        from .routes_app import csv_response
        return csv_response("consist-procurement-stages", list(nexgen.PS_FIELDS) + ["updated_by"], rows)
    edit = request.query_params.get("edit", "")
    cur = nexgen.proc_stages().get(int(edit)) if edit.isdigit() else None
    counts = {}
    for r in nexgen.proc_stages().values():
        counts[r.get("stage")] = counts.get(r.get("stage"), 0) + 1
    snap = intel.snapshot()
    efl = (snap.get(int(edit)) or snap.get(edit)) if edit.isdigit() else None
    return render(request, "admin/nx_proc_stages.html", user=u, rows=rows, pstage=st, q=q, edit=edit, cur=cur, efl=efl, counts=counts,
                  PROC_STAGES=nexgen.PROC_STAGES, total=len(nexgen.proc_stages()), active="proc_stages")


@admin.post("/procurement-stages")
async def proc_stages_save(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    fid = (form.get("fleet_id") or "").strip()
    if not fid.isdigit():
        flash(request, "Enter a fleet ID (the number in /app/fleets/<id>).")
        return redirect("/admin/procurement-stages")
    if form.get("action") == "delete":
        nexgen.delete_proc_stage(fid)
        flash(request, f"Removed the stage for fleet {fid}. Other fleets with the same operator and model lose it too. A researched row comes back on the next restart; to override it, set its stage instead.")
        return redirect("/admin/procurement-stages")
    try:
        nexgen.save_proc_stage(fid, form, str(u["email"]))
    except ValueError as e:
        flash(request, str(e))
        return redirect(f"/admin/procurement-stages?edit={fid}")
    flash(request, f"Saved the procurement stage for fleet {fid}.")
    return redirect(f"/admin/procurement-stages?q={form.get('operator_id') or ''}")


# ---------------- investors ----------------

@app.get("/investors")
def investors(request: Request, u=U):
    orders = nexgen.orders()
    yr = intel.this_year()
    years = list(range(yr - 9, yr + 1))
    builders = {}
    for o in orders:
        if o["year"] in years:
            b = builders.setdefault(o["builder"], {y: [0, 0] for y in years})
            b[o["year"]][0] += o["cars"]
            b[o["year"]][1] += o["value"] or 0
    grid = sorted(builders.items(), key=lambda kv: -sum(v[0] for v in kv[1].values()))
    top = [b for b, _ in grid[:5]]
    by_year = {y: {} for y in years}
    for b, ys in grid:
        k = b if b in top else "Other"
        for y, (c, _) in ys.items():
            if c:
                by_year[y][k] = by_year[y].get(k, 0) + c
    keys = top + (["Other"] if len(grid) > 5 else [])
    share5, tot5 = nexgen.share_new_orders(5)
    # 1.7.35: each share bar opens the builder's page when the builder has fleets on file, else its orders
    have = {data.slug(fl["manufacturer"] or "Unknown") for fl in intel.snapshot_all().values()}
    def _bslug(b):  # exact slug, else the one fleet builder whose name starts with it ("Stadler" -> "stadler-rail")
        sl = data.slug(b)
        if sl in have:
            return sl
        near = [h for h in have if sl and h.startswith(sl + "-")]
        return near[0] if len(near) == 1 else None
    share_href = {b: (f"/app/builders/{_bslug(b)}" if _bslug(b) else "/app/work?" + urlencode({"view": "orders", "builder": b}) + "#all")
                  for b, _, _ in share5}
    bl, bl_rows = nexgen.backlog()
    med = nexgen.median_price()
    fc_years, fc_tot, fc_over = intel.forecast(10)
    fc_keys = [k for k, _ in sorted(fc_tot.items(), key=lambda kv: -kv[1]["cars"])][:5]
    fc_cars = sum(t["cars"] for t in fc_tot.values())
    if request.query_params.get("export") in ("csv", "xlsx") and _can_export(u):
        return _export(request, "consist-vehicle-orders", ["Award year", "Operator", "Builder", "Model", "Base cars", "Options", "Value (USD)", "Per car (USD)", "Status", "Delivery", "In backlog", "Source"],
                       [(o["year"], o["operator_id"], o["builder"], o.get("model"), o["cars"], o.get("qty_options"), o["value"], round(o["per_car"]) if o["per_car"] else None,
                         o.get("status"), o.get("delivery"), o["backlog"], o.get("source_url")) for o in orders])
    from . import nexgen2
    q_by, q_keys, q_val, _q = nexgen2.orders_by_quarter(12)
    open_only = request.query_params.get("open") == "1"
    dr_rows, dr_tot = nexgen2.demand_range(10, open_only)
    if request.query_params.get("export") == "range" and _can_export(u):
        return _export(request, "consist-demand-range", ["Year", "Buys", "Cars", "Low (USD)", "Mid (USD)", "High (USD)"],
                       [(r["year"], r["n"], r["cars"], round(r["low"]), round(r["mid"]), round(r["high"])) for r in dr_rows])
    return render(request, "app/nx_investors.html", q_by=q_by, q_keys=q_keys, q_labels={k: k for k in q_keys}, q_val=q_val, dr_rows=dr_rows, dr_tot=dr_tot, open_only=open_only,
                  user=u, orders=orders, years=years, grid=grid, share5=share5, share_href=share_href, tot5=tot5, backlog=bl,
                  backlog_rows=bl_rows, med=med, by_year=by_year, keys=keys, fc_years=fc_years, fc_keys=fc_keys, fc_tot=fc_tot,
                  fc_over=fc_over, fc_cars=fc_cars, key_labels={k: k for k in keys}, fc_labels={k: data.CLASSES.get(k, k) for k in fc_keys}, can_export=_can_export(u), stamp=nexgen.data_stamp())


# ---------------- my agency ----------------

@app.get("/my-agency")
def my_agency(request: Request, u=U):
    me = nexgen.my_agency(u)
    ops = sorted(data.operators(), key=lambda o: o["operator_name"])
    if not me:
        return render(request, "app/nx_agency.html", user=u, me=None, ops=ops)
    oid = me["operator_id"]
    region = request.query_params.get("region") if request.query_params.get("region") in ("US", "CA") else "all"
    if region != "all":
        from . import nexgen2
        peers = nexgen2.peers_by_region(oid, region, 8)
    else:
        peers = nexgen.peer_ids(oid, 8)
    custom = [p for p in (intel.pref(u, "my_peers") or "").split(",") if p] if region == "all" else []
    if custom:
        peers = custom
    snap = intel.snapshot().values()
    names = {o["operator_id"]: o["operator_name"] for o in ops}
    costs, _, cdy = intel.transit_costs()
    stats = data.operator_stats(oid) if hasattr(data, "operator_stats") else None
    oms = intel.operator_mode_stats()

    def row(op):
        fl = [f for f in snap if f["operator_id"] == op]
        c = [r["vm_per_car_rev_mile"] for r in costs if r["operator_id"] == op and r["vm_per_car_rev_mile"]]
        miles = [f["est_annual_miles_per_car"] for f in fl if f.get("est_annual_miles_per_car")]
        rel = [v for (o, _m), v in oms.items() if o == op]
        spare = [v["spare_pct"] for v in rel if v.get("spare_pct") is not None]
        mdbf = [v["mdbf"] for v in rel if v.get("mdbf")]
        return {"id": op, "name": names.get(op, op), "cars": sum(f["qty_active"] or 0 for f in fl), "fleets": len(fl), "age": nexgen.avg_age(fl),
                "cost": statistics.median(c) if c else None, "miles": statistics.median(miles) if miles else None,
                "spare": statistics.median(spare) if spare else None, "mdbf": statistics.median(mdbf) if mdbf else None,
                "due5": sum(f["qty_active"] or 0 for f in fl if f.get("ulb_year") and f["ulb_year"] <= intel.this_year() + 5)}
    mine = row(oid)
    peer_rows = [row(p) for p in peers]

    def med(k):
        v = [r[k] for r in peer_rows if r[k] is not None]
        return statistics.median(v) if v else None
    medians = {k: med(k) for k in ("cars", "age", "cost", "miles", "spare", "mdbf", "due5")}
    fleets = sorted([f for f in snap if f["operator_id"] == oid], key=lambda f: -(f["qty_active"] or 0))
    if request.query_params.get("export") and _can_export(u):
        head = ["Operator", "Active units", "Fleets", "Avg age (yrs)", f"Maint. cost per car-mile ({cdy} $)", "Miles per car per year", "Spare ratio (%)", "Miles between failures", "Units at end of life within 5 yrs"]
        rows = [(r["name"], r["cars"], r["fleets"], r["age"], r["cost"], r["miles"], r["spare"], r["mdbf"], r["due5"]) for r in [mine] + peer_rows]
        rows.append(("Peer median", medians["cars"], None, medians["age"], medians["cost"], medians["miles"], medians["spare"], medians["mdbf"], medians["due5"]))
        return _export(request, "consist-peer-scorecard", head, rows)
    return render(request, "app/nx_agency.html", user=u, me=me, ops=ops, region=region, mine=mine, peer_rows=peer_rows, medians=medians, fleets=fleets,
                  custom=bool(custom), cdy=cdy, stats=stats, can_export=_can_export(u), stamp=nexgen.data_stamp())


@app.post("/my-agency")
def my_agency_set(request: Request, csrf: str = Form(""), operator_id: str = Form(""), peers: str = Form(None), u=U):
    auth.check_csrf(request, csrf)
    if operator_id:
        intel.set_pref(u, "my_agency", operator_id)
        intel.set_pref(u, "my_peers", "")
    if peers is not None:
        intel.set_pref(u, "my_peers", ",".join(p.strip() for p in peers.split(",") if p.strip())[:2000])
    return redirect("/app/my-agency")


@app.post("/my-agency/peers")
async def my_agency_peers(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    picks = [p for p in form.getlist("peer") if p][:15]
    intel.set_pref(u, "my_peers", ",".join(picks))
    flash(request, "Peer group saved." if picks else "Peer group reset to the suggested peers.")
    return redirect("/app/my-agency")


# ---------------- wave 2 ----------------

@app.get("/estimator")
def estimator(request: Request, u=U):
    from . import vehicle_awards
    counts = {}
    for o in vehicle_awards.orders():
        if o.get("unit_usd"):
            counts[o["type"]] = counts.get(o["type"], 0) + 1
    vtype = request.query_params.get("type") or (max(counts, key=counts.get) if counts else "lrv")
    vtype = vtype if vtype in vehicle_awards.TYPES else "lrv"
    try:
        qty = max(1, min(2000, int(request.query_params.get("qty", "20"))))
    except ValueError:
        qty = 20
    yr = intel.this_year()
    try:
        year = max(yr - 5, min(yr + 10, int(request.query_params.get("year", str(yr + 1)))))
    except ValueError:
        year = yr + 1
    est = nexgen.estimate(vtype, qty, year)
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-cost-estimate", ["Date", "Buyer", "Builder", "Order", "Units", "Price per unit (USD)", f"Escalated to {year} (USD)", "Source"],
                       [(r["date"], r["buyer"], r["builder"], r["title"], r["units"], round(r["unit_usd"]), round(r["esc"]) if r["esc"] else None, r.get("source_url")) for r in est["rows"]])
    return render(request, "app/nx_estimator.html", user=u, TYPES=vehicle_awards.TYPES, counts=counts, vtype=vtype, qty=qty, year=year, est=est,
                  years=list(range(yr - 1, yr + 11)), can_export=_can_export(u))


@app.get("/supplier-windows")
def supplier_windows(request: Request, u=U):
    sub = request.query_params.get("subsystem", "")
    sup = request.query_params.get("supplier", "").strip()
    try:
        years = max(1, min(15, int(request.query_params.get("years", "8"))))
    except ValueError:
        years = 8
    rows = nexgen.supplier_windows(years, sub or None, sup or None)
    cov, nfleets = nexgen.coverage()
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-supplier-windows", ["Year", "Why", "Operator", "Fleet", "Subsystem", "Current supplier", "Cars", "Source"],
                       [(r["year"], r["why"], r["fleet"]["operator_name"], f"{r['fleet']['manufacturer'] or ''} {r['fleet']['model_name']}".strip(),
                         data.SUBSYSTEMS.get(r["rec"]["subsystem"], r["rec"]["subsystem"]), r["supplier"], r["cars"], r["rec"].get("source_url")) for r in rows])
    import json as _json  # 1.7.91 window timeline (Justin 11-19): every row for the browser-side chart
    win = _json.dumps([[r["year"], r["why"], r["fleet"]["fleet_id"], f"{r['fleet']['manufacturer'] or ''} {r['fleet']['model_name'] or ''}".strip(),
                        r["fleet"]["operator_name"], r["fleet"]["operator_id"], r["rec"]["subsystem"], data.SUBSYSTEMS.get(r["rec"]["subsystem"], r["rec"]["subsystem"]),
                        r["supplier"] or "Not named", r["cars"]] for r in rows]).replace("</", "<\\/")
    return render(request, "app/nx_windows.html", user=u, win=win, rows=rows, cov=cov, nfleets=nfleets, sub=sub, sup=sup, years=years,
                  orders=nexgen.new_orders(24), can_export=_can_export(u))


@app.get("/coverage")
def coverage_page(request: Request, u=U):
    """1.7.48: which agencies Bid Catcher follows and how (bids-push27 agency_coverage). Gated like Bids, filtered by the territory."""
    from . import coverage, pages as _pages
    if not u.bids:
        return render(request, "app/locked.html", user=u, feature="bids_recent", title="Agency coverage")
    if not u.is_admin and _pages.access(u.plan, "/app/bids") == "none":
        return render(request, "app/locked.html", user=u, feature="bids_recent", title="Agency coverage")
    f = {k: request.query_params.get(k, "").strip() for k in ("status", "q") if request.query_params.get(k, "").strip()}
    rows, tiles, counts, updated = coverage.member_view(f)
    pts, nomap = coverage.map_points(rows)  # 1.7.51 coverage map (shown when the Coverage map pill is clicked)
    return render(request, "app/coverage.html", user=u, rows=rows, tiles=tiles, counts=counts, updated=updated, f=f, STATUS=coverage.STATUS,
                  pts=pts, nomap=nomap, MAP_COLORS=coverage.MAP_COLORS, QUIET_COLOR=coverage.QUIET_COLOR, show_map=request.query_params.get("map") == "1")


@app.get("/early-signals")
def early_signals(request: Request, u=U):
    return render(request, "app/nx_early.html", user=u, v=nexgen.early_view())
