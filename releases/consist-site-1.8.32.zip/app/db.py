"""app.db (users, plans, billing, content, alerts) plus read-only connections to the live fleet.db and bids.db."""
import datetime
import json
import os
import sqlite3
import threading

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS plan (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, blurb TEXT, price_month INTEGER DEFAULT 0, price_year INTEGER DEFAULT 0,
  stripe_price_month TEXT, stripe_price_year TEXT, seats INTEGER DEFAULT 1, ai_quota INTEGER DEFAULT 0,
  search_limit INTEGER DEFAULT 1, features TEXT DEFAULT '[]', bullets TEXT DEFAULT '[]', sort INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1, highlight INTEGER DEFAULT 0, contact_only INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS user (
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, company TEXT, pw_hash TEXT,
  role TEXT DEFAULT 'user', plan_id TEXT DEFAULT 'free', status TEXT DEFAULT 'active', team_owner_id INTEGER,
  stripe_customer_id TEXT, stripe_subscription_id TEXT, sub_status TEXT, interval TEXT, period_end TEXT,
  ai_month TEXT, ai_used INTEGER DEFAULT 0, created TEXT, last_login TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS saved_search (
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT, query TEXT, frequency TEXT DEFAULT 'daily',
  last_sent TEXT, last_notice_id INTEGER DEFAULT 0, created TEXT);
CREATE TABLE IF NOT EXISTS watch (user_id INTEGER, kind TEXT, ref TEXT, created TEXT, PRIMARY KEY (user_id, kind, ref));
CREATE TABLE IF NOT EXISTS email_log (id INTEGER PRIMARY KEY, ts TEXT, to_addr TEXT, kind TEXT, subject TEXT, sender TEXT, status TEXT, error TEXT);
CREATE INDEX IF NOT EXISTS email_log_ts ON email_log (ts);
CREATE TABLE IF NOT EXISTS page (
  slug TEXT PRIMARY KEY, title TEXT, description TEXT, body TEXT, kind TEXT DEFAULT 'page', published INTEGER DEFAULT 1,
  updated TEXT);
CREATE TABLE IF NOT EXISTS announcement (id INTEGER PRIMARY KEY, text TEXT, link TEXT, audience TEXT DEFAULT 'all', active INTEGER DEFAULT 1, created TEXT);
CREATE TABLE IF NOT EXISTS setting (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, ts TEXT, user_id INTEGER, actor TEXT, action TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS token (token TEXT PRIMARY KEY, kind TEXT, user_id INTEGER, email TEXT, expires TEXT, used INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS analyst_job (
  id TEXT PRIMARY KEY, user_id INTEGER, created TEXT, kind TEXT, question TEXT, status TEXT, steps TEXT DEFAULT '[]',
  result TEXT, error TEXT, cost_usd REAL DEFAULT 0, ref TEXT);
CREATE TABLE IF NOT EXISTS analyst_upload (
  id TEXT PRIMARY KEY, user_id INTEGER, created TEXT, filename TEXT, kind TEXT, size INTEGER, sha256 TEXT, pages INTEGER,
  chars INTEGER, text TEXT, shared INTEGER DEFAULT 0, deleted TEXT, last_job TEXT);
CREATE TABLE IF NOT EXISTS upload_notice (
  upload_id TEXT PRIMARY KEY, checked TEXT, status TEXT, notice_id INTEGER, agency_id TEXT, fields TEXT, sent TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS billing_event (id INTEGER PRIMARY KEY, ts TEXT, event_id TEXT UNIQUE, type TEXT, user_id INTEGER, amount INTEGER, detail TEXT);
CREATE TABLE IF NOT EXISTS source_request (id INTEGER PRIMARY KEY, ts TEXT, user_id INTEGER, agency TEXT, url TEXT, note TEXT, status TEXT DEFAULT 'new');
CREATE TABLE IF NOT EXISTS lead (id INTEGER PRIMARY KEY, ts TEXT, name TEXT, email TEXT, company TEXT, message TEXT, status TEXT DEFAULT 'new');
CREATE TABLE IF NOT EXISTS ambassador (id INTEGER PRIMARY KEY, email TEXT, name TEXT, note TEXT, plan_id TEXT, until TEXT, token TEXT,
  invited_by TEXT, created TEXT, sent TEXT, user_id INTEGER, accepted TEXT, revoked TEXT, note_html TEXT, subject TEXT,
  note_full INTEGER DEFAULT 0, linkedin TEXT, send_error TEXT);
CREATE TABLE IF NOT EXISTS signup_block (id INTEGER PRIMARY KEY, ts TEXT, ip TEXT, email TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS email_optout (email TEXT PRIMARY KEY, created TEXT, how TEXT);
CREATE TABLE IF NOT EXISTS feature_request (id INTEGER PRIMARY KEY, ts TEXT, user_id INTEGER, email TEXT, name TEXT, plan_id TEXT, page TEXT,
  request TEXT, status TEXT DEFAULT 'new', implemented TEXT, credited TEXT, credit_note TEXT, admin_note TEXT, credit_cents INTEGER, credit_txn TEXT);
"""

DEFAULT_PLANS = [
    dict(id="free", name="Starter", blurb="See what's moving in rail procurement.", price_month=0, price_year=0, seats=1,
         ai_quota=3, search_limit=1, sort=0,
         features=["bids_recent", "fleet_basic"],
         bullets=["Rail bid feed, last 30 days", "Fleet roster preview: the first 10 fleets",
                  "1 saved search, weekly digest", "3 analyst questions a month"]),
    dict(id="pro", name="Pro", blurb="For business developers who chase rail work.", price_month=24900, price_year=238800,
         seats=1, ai_quota=60, search_limit=10, sort=1, highlight=1,
         features=["bids_recent", "bids_full", "fleet_basic", "fleet_detail", "pipeline", "export", "alerts_instant", "bid_brief",
                   "opportunities", "market", "lists", "fleet_alerts"],
         bullets=["One market in full: transit or passenger rail", "Full bid history and closing calendar", "Instant and daily email alerts, 10 saved searches",
                  "Fleet duty cycle, cost per car-mile and overhaul timing", "Overhaul pipeline by year and subsystem",
                  "AI bid briefs and 60 analyst questions a month", "CSV export"]),
    dict(id="team", name="Team", blurb="Market intelligence for the whole capture team.", price_month=89900, price_year=862800,
         seats=5, ai_quota=250, search_limit=100, sort=2,
         features=["bids_recent", "bids_full", "fleet_basic", "fleet_detail", "pipeline", "export", "alerts_instant", "bid_brief", "awards",
                   "opportunities", "market", "lists", "fleet_alerts", "account_notes", "crm_export", "lens_all"],
         bullets=["Everything in Pro, for 5 seats", "Every market: transit and passenger rail", "Award analytics: who wins, at what price",
                  "Competitor win rates by category and agency", "250 analyst questions a month", "Priority support, invoice billing on annual"]),
    dict(id="enterprise", name="Enterprise", blurb="Custom coverage, data feeds and seats.", price_month=0, price_year=1800000, seats=25,
         ai_quota=1000, search_limit=1000, sort=3, contact_only=1,
         features=["bids_recent", "bids_full", "fleet_basic", "fleet_detail", "pipeline", "export", "alerts_instant", "bid_brief", "awards",
                   "opportunities", "market", "lists", "fleet_alerts", "account_notes", "crm_export", "lens_all"],
         bullets=["Up to 25 named seats", "Data feed (CSV or SQLite) of the full fleet database",
                  "Custom agency coverage", "Named analyst support"]),
]

FEATURE_LABELS = {
    "bids_recent": "Bid feed (last 30 days)", "bids_full": "Full bid history", "fleet_basic": "Fleet roster",
    "fleet_detail": "Fleet duty cycle, costs and overhaul timing", "pipeline": "Overhaul pipeline", "export": "CSV export",
    "alerts_instant": "Instant alerts", "bid_brief": "AI bid briefs", "awards": "Award analytics",
    "opportunities": "Opportunity finder and replacement forecast", "market": "Installed base and market share", "lists": "Fleet lists",
    "fleet_alerts": "Fleet change alerts", "account_notes": "Account notes and contacts", "crm_export": "CRM export (Salesforce, HubSpot)", "api": "API keys (read-only data API)",
    "lens_all": "Every market lens (transit and passenger rail)",
    "rail": "Freight Rail Analytics Portal: freight R-1, locomotives, FRA safety and grade crossings (/rail)",
    "rail_team": "Freight Team tools: fuel surcharges, cost escalation forecasts, rail-cost dollars, CSV export from /rail",
}
PASSENGER_ONLY_KEYS = ("rail", "rail_team")  # left out of the passenger compare table on /pricing

# Features added after launch, given to existing paid plans once (see init).
NEW_FEATURES = {"pro": ["opportunities", "market", "lists", "fleet_alerts"],
                "team": ["opportunities", "market", "lists", "fleet_alerts", "account_notes", "crm_export"],
                "enterprise": ["opportunities", "market", "lists", "fleet_alerts", "account_notes", "crm_export"]}

DEFAULT_SETTINGS = {
    "site_name": "Consist",
    "tagline": "Rail market intelligence",
    "analytics_id": "G-SCJWC2HBS3",
    "indexnow_on": "1",
    "linkedin_url": "https://www.linkedin.com/company/146914046/",  # footer icon + Organization sameAs; Admin > Settings > General
    "x_url": "", "youtube_url": "", "bluesky_url": "",
    "promo_on": "1",
    "promo_autopost": "1",  # send scheduled LinkedIn drafts on their own (Tue-Thu 9am ET, 2+ days apart, weekly spotlight)  # monthly rail fleet report + LinkedIn drafts (app/promo.py); Admin > Social posts
    "rail_open": "0",
    "railcars_on": "0",  # Freight cars by owner module (/rail/railcars): off since 2026-11-04 (Justin); Admin > Settings > General
    "twofa_mode": "optional",  # two-factor sign-in: off / optional / admins (required for admins) / all (see app/twofa.py)  # the /rail portal: off = admins only (404 for everyone else) and no links to it
    "hero_title": "The rail market, measured.",
    "hero_sub": "Rail intelligence for the people who build, supply and fund it. Passenger, transit and freight data for the US and "
                "Canada in one place: fleets, costs, service metrics, safety, funding programs and live procurements.",
    "hero_highlight": "measured.",
    "hero_cta": "Start free, no card",
    "features_title": "Fleet facts and live bids, in one place",
    "features_intro": "General bid services see the RFP when it lands. {site} starts from the fleet: who runs what, how hard it works, "
                      "what it costs and when it comes due.",
    "freight_on": "1",  # home page freight section; its text is in Admin > Settings > Home page (blank = built-in text)
    "freight_kicker": "", "freight_title": "", "freight_text": "", "freight_cta": "", "freight_cards": "",
    "cta_title": "See the whole rail market",
    "cta_sub": "Free plan. No card. Set up in two minutes.",
    "footer_note": "",
    "legal_entity": "Sand & Style, LLC",  # the company that owns the site; Consist is its registered fictitious name (Florida, 2026-11-04)
    "meta_description": "",
    # Coverage page (/coverage). Tokens {operators} {fleets} {cars} {agencies} {site} are filled with live counts.
    "coverage_title": "Coverage: every passenger rail fleet in the US and Canada",
    "coverage_intro": "{operators} operators, {fleets} active fleets and {cars} vehicles, from metro, light rail and streetcar to commuter "
                      "and intercity trains and airport people movers. {agencies} procurement sources watched daily.",
    "coverage_meta": "{operators} rail operators, {fleets} fleets and {cars} active units across transit and passenger rail in the US and "
                     "Canada, plus {agencies} procurement sources watched for rail bids.",
    "support_email": "support@example.com",
    "trial_days": "14",
    "referral_on": "1", "referral_percent": "50", "referral_hold_days": "30", "referral_cap": "12",  # referral program (app/referrals.py)
    "trial_on": "1",  # 14-day no-card free trial on self-serve paid plans; downloads/extracts/API off while trialing (app/trial.py)
    "trial_ai": "10",  # analyst questions during a trial
    "trial_views": "300",  # page views per day during a trial, against scraping
    "signup_open": "1",
    # 1.7.47 sign-up bot protection (app/signupguard.py)
    "signup_verify": "1", "signup_min_secs": "3", "signup_daily_ip": "10", "signup_block_disposable": "1", "turnstile_on": "0", "turnstile_site_key": "",
    "billing_demo": "1",
}

# Copy that changed with the 2026-10 market lenses: (key, old default, new default). Updated only where an admin hasn't edited it.
COPY_UPDATES = [
    ("hero_title", "Know every fleet. Catch every rail bid.", DEFAULT_SETTINGS["hero_title"]),
    ("hero_highlight", "Catch every rail bid.", DEFAULT_SETTINGS["hero_highlight"]),
    ("hero_sub", "Consist tracks every passenger rail fleet in the US and Canada and every rolling stock maintenance bid "
                 "their agencies publish, then tells you which ones matter to you.", DEFAULT_SETTINGS["hero_sub"]),
    ("hero_sub", "Consist tracks every rail fleet in the US, Canada and Mexico, from metro cars to freight locomotives, "
                 "and the bids, overhauls and orders that come out of them, then tells you which ones matter to you.", DEFAULT_SETTINGS["hero_sub"]),
    ("hero_sub", "Consist tracks every passenger rail fleet in the US, Canada and Mexico, from metro and light rail cars to commuter and "
                 "intercity trains, and the bids, overhauls and orders that come out of them, then tells you which ones matter to you.",
     DEFAULT_SETTINGS["hero_sub"]),
    # 2026-11-03 (Justin): headline broadened from bids to the whole rail market
    ("tagline", "Rail fleet and procurement intelligence", DEFAULT_SETTINGS["tagline"]),
    ("hero_title", "Every rail fleet in the US and Canada, and the work coming out of it.", DEFAULT_SETTINGS["hero_title"]),
    ("hero_highlight", "the work coming out of it.", DEFAULT_SETTINGS["hero_highlight"]),
    ("hero_sub", "Consist tracks every passenger rail fleet in the US and Canada, from metro and light rail cars to commuter and "
                 "intercity trains, and the bids, overhauls and orders that come out of them, then tells you which ones matter to you.", DEFAULT_SETTINGS["hero_sub"]),
    ("cta_title", "Catch the next rail bid first", DEFAULT_SETTINGS["cta_title"]),
]


def drop_mexico(text):
    """Mexico is parked (2026-10-30): coverage copy says the US and Canada. Used once on stored settings and pages."""
    t = text or ""
    for old, new in (("United States, Canada and Mexico", "United States and Canada"), ("US, Canada and Mexico", "US and Canada"),
                     ("U.S., Canada and Mexico", "U.S. and Canada"), ("US, Canada or Mexico", "US or Canada"),
                     ("US, Canada, and Mexico", "US and Canada"), ("United States, Canada, and Mexico", "United States and Canada"),
                     ("Canada and Mexico", "Canada"), ("Canada, and Mexico", "Canada")):
        t = t.replace(old, new)
    return t
# Freight parked (2026-10-28): plan bullets that promised it.
PASSENGER_BULLETS = {"One market in full: transit, passenger rail or freight": "One market in full: transit or passenger rail",
                     "Every market: transit, passenger rail and freight": "Every market: transit and passenger rail"}

_lock = threading.Lock()


def now():
    return datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat()


def connect():
    os.makedirs(config.DATA_DIR, exist_ok=True)
    c = sqlite3.connect(config.APP_DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init():
    with _lock:
        c = connect()
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript(SCHEMA)
        for p in DEFAULT_PLANS:
            p = dict(p)
            p["features"] = json.dumps(p["features"])
            p["bullets"] = json.dumps(p["bullets"])
            cols = list(p)
            c.execute(f"INSERT OR IGNORE INTO plan ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", [p[k] for k in cols])
        for k, v in DEFAULT_SETTINGS.items():
            c.execute("INSERT OR IGNORE INTO setting (key, value) VALUES (?, ?)", (k, v))
        if not c.execute("SELECT 1 FROM setting WHERE key = 'features_v2'").fetchone():
            for pid, feats in NEW_FEATURES.items():
                r = c.execute("SELECT features FROM plan WHERE id = ?", (pid,)).fetchone()
                if r:
                    have = json.loads(r["features"] or "[]")
                    c.execute("UPDATE plan SET features = ? WHERE id = ?", (json.dumps(have + [f for f in feats if f not in have]), pid))
            c.execute("INSERT INTO setting (key, value) VALUES ('features_v2', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'features_v3'").fetchone():
            # Market lenses (2026-10): Team and Enterprise get every lens; Pro and Team bullets say so.
            for pid, bullet in (("team", "Every market: transit, passenger rail and freight"), ("enterprise", None),
                                ("pro", "One market in full: transit, passenger rail or freight")):
                r = c.execute("SELECT features, bullets FROM plan WHERE id = ?", (pid,)).fetchone()
                if not r:
                    continue
                feats, bullets = json.loads(r["features"] or "[]"), json.loads(r["bullets"] or "[]")
                if pid != "pro" and "lens_all" not in feats:
                    feats.append("lens_all")
                if bullet and bullet not in bullets:
                    bullets.insert(1 if pid == "team" else 0, bullet)
                c.execute("UPDATE plan SET features = ?, bullets = ? WHERE id = ?", (json.dumps(feats), json.dumps(bullets), pid))
            c.execute("INSERT INTO setting (key, value) VALUES ('features_v3', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'pricing_2026_10'").fetchone():
            # Pricing review (2026-10-26): Pro $249, Team $899 for 5 seats, yearly 20% off; Enterprise from $18k a year, up to 25 seats.
            swap = {"Priority support": "Priority support, invoice billing on annual",
                    "Unlimited seats and saved searches": "Up to 25 named seats"}
            for p in DEFAULT_PLANS:
                if p["id"] not in ("pro", "team", "enterprise"):
                    continue
                r = c.execute("SELECT bullets FROM plan WHERE id = ?", (p["id"],)).fetchone()
                if r:
                    bullets = [swap.get(b, b) for b in json.loads(r["bullets"] or "[]")]
                    c.execute("UPDATE plan SET price_month = ?, price_year = ?, seats = ?, ai_quota = ?, bullets = ? WHERE id = ?",
                              (p["price_month"], p["price_year"], p["seats"], p["ai_quota"], json.dumps(bullets), p["id"]))
            c.execute("INSERT INTO setting (key, value) VALUES ('pricing_2026_10', '1')")
        u_cols = [r[1] for r in c.execute("PRAGMA table_info(user)")]
        for col, typ in (("totp_secret", "TEXT"), ("totp_on", "INTEGER DEFAULT 0"), ("totp_last", "INTEGER"), ("totp_recovery", "TEXT")):
            if col not in u_cols:  # two-factor sign-in (app/twofa.py)
                c.execute(f"ALTER TABLE user ADD COLUMN {col} {typ}")
        if "comp_until" not in [r[1] for r in c.execute("PRAGMA table_info(user)")]:
            c.execute("ALTER TABLE user ADD COLUMN comp_until TEXT")  # end date of a free Ambassador subscription (app/ambassadors.py)
        fr_cols = [r[1] for r in c.execute("PRAGMA table_info(feature_request)")]
        for col, typ in (("credit_cents", "INTEGER"), ("credit_txn", "TEXT")):
            if fr_cols and col not in fr_cols:
                c.execute(f"ALTER TABLE feature_request ADD COLUMN {col} {typ}")
        am_cols = [r[1] for r in c.execute("PRAGMA table_info(ambassador)")]
        for col, typ in (("note_html", "TEXT"), ("subject", "TEXT"), ("note_full", "INTEGER DEFAULT 0"), ("linkedin", "TEXT"),
                         ("send_error", "TEXT")):  # send_error: 1.7.46, why the last invite was not emailed
            if am_cols and col not in am_cols:  # rich-text note (app/richtext.py), custom subject, note-is-whole-letter, profile URL
                c.execute(f"ALTER TABLE ambassador ADD COLUMN {col} {typ}")
        if "trial_used" not in [r[1] for r in c.execute("PRAGMA table_info(user)")]:
            c.execute("ALTER TABLE user ADD COLUMN trial_used TEXT")  # date the member's one free trial started (app/trial.py)
        ld_cols = [r[1] for r in c.execute("PRAGMA table_info(lead)")]
        for col in ("ip", "spam_reason", "source"):  # 1.8.23 lead spam guard (app/leadguard.py)
            if ld_cols and col not in ld_cols:
                c.execute(f"ALTER TABLE lead ADD COLUMN {col} TEXT")
        if "prev_login" not in [r[1] for r in c.execute("PRAGMA table_info(user)")]:
            c.execute("ALTER TABLE user ADD COLUMN prev_login TEXT")  # the sign-in before this one, for "new since my last sign-in"
        if not c.execute("SELECT 1 FROM setting WHERE key = 'page_access_1108'").fetchone():
            # Justin's plan matrix (2026-11-08, approved in the pricing thread): page access tokens for the four live plans, plus the
            # features Freight Markets Analyst needs for the pages it now gets. Prices, seats and other plan fields are untouched.
            from . import pages as PG
            for pid, row in PG.MATRIX_1108.items():
                r = c.execute("SELECT features FROM plan WHERE id = ?", (pid,)).fetchone()
                if not r:
                    continue
                f = [x for x in json.loads(r["features"] or "[]") if not str(x).startswith(("pg:", "pv:"))]
                f += [x for x in PG.FEATURES_1108.get(pid, []) if x not in f]
                f = [x for x in f if x not in PG.ENTERPRISE_ONLY]  # CRM export and API keys: enterprise sales only (Justin, 2026-11-08)
                c.execute("UPDATE plan SET features = ? WHERE id = ?", (json.dumps(f + PG.tokens(row)), pid))
            c.execute("INSERT INTO setting (key, value) VALUES ('page_access_1108', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'plan_access_1108b'").fetchone():
            # Justin's answers to the plan audit (2026-11-08): Freight Markets Analyst loses the passenger and transit Find Work pages
            # and the features behind them; Free's roster bullet says it is a 10-fleet preview. Prices and other fields untouched.
            from . import pages as PG
            for pid, locks in PG.LOCK_1108B.items():
                r = c.execute("SELECT features FROM plan WHERE id = ?", (pid,)).fetchone()
                if not r:
                    continue
                f = json.loads(r["features"] or "[]")
                f = [x for x in f if x not in PG.DROP_1108B.get(pid, []) and str(x) not in
                     [t + p for p in locks for t in ("pg:", "pv:")]]
                c.execute("UPDATE plan SET features = ? WHERE id = ?", (json.dumps(f), pid))
            for pid, (old, new) in PG.BULLETS_1108B.items():
                r = c.execute("SELECT bullets FROM plan WHERE id = ?", (pid,)).fetchone()
                if r:
                    b = json.loads(r["bullets"] or "[]")
                    if old in b:
                        c.execute("UPDATE plan SET bullets = ? WHERE id = ?", (json.dumps([new if x == old else x for x in b]), pid))
            c.execute("INSERT INTO setting (key, value) VALUES ('plan_access_1108b', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'plan_access_1108c'").fetchone():
            # Justin, 2026-11-08: Early signals is a preview on Free. Only a page still set to Full is changed.
            from . import pages as PG
            for pid, paths in PG.PREVIEW_1108C.items():
                r = c.execute("SELECT features FROM plan WHERE id = ?", (pid,)).fetchone()
                if r:
                    f = json.loads(r["features"] or "[]")
                    f = ["pv:" + x[3:] if str(x).startswith("pg:") and x[3:] in paths else x for x in f]
                    c.execute("UPDATE plan SET features = ? WHERE id = ?", (json.dumps(f), pid))
            c.execute("INSERT INTO setting (key, value) VALUES ('plan_access_1108c', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'legal_uploads_1111'").fetchone():
            # 1.7.25, Justin approved 2026-11-11: append the uploads sections to the live Privacy and Terms pages once. The live text is
            # kept (edits are never replaced): the old body is saved as an unpublished <slug>-before-1111 page and the section is added at the end.
            from . import content as CT
            for slug, add, mark in (("privacy", CT.PRIVACY_UPLOADS, "Documents you upload"), ("terms", CT.TERMS_UPLOADS, "Uploaded documents.")):
                r = c.execute("SELECT * FROM page WHERE slug = ?", (slug,)).fetchone()
                if r and mark not in (r["body"] or ""):
                    c.execute("INSERT OR IGNORE INTO page (slug, title, description, body, kind, published, updated) VALUES (?,?,?,?,?,0,?)",
                              (slug + "-before-1111", (r["title"] or "") + " (before 1.7.25)", r["description"], r["body"], r["kind"], now()))
                    c.execute("UPDATE page SET body = ?, updated = ? WHERE slug = ?", ((r["body"] or "").rstrip() + "\n" + add, now(), slug))
            c.execute("INSERT INTO setting (key, value) VALUES ('legal_uploads_1111', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'legal_linkedin_1112'").fetchone():
            # 1.7.41 (Justin asked 2026-11-12): LinkedIn Insight Tag wording in the live Privacy page, once; old body kept as privacy-before-1112.
            from . import content as CT
            r = c.execute("SELECT * FROM page WHERE slug = 'privacy'").fetchone()
            if r:
                new = CT.privacy_with_linkedin(r["body"])
                if new != (r["body"] or ""):
                    c.execute("INSERT OR IGNORE INTO page (slug, title, description, body, kind, published, updated) VALUES (?,?,?,?,?,0,?)",
                              ("privacy-before-1112", (r["title"] or "") + " (before 1.7.41)", r["description"], r["body"], r["kind"], now()))
                    c.execute("UPDATE page SET body = ?, updated = ? WHERE slug = 'privacy'", (new, now()))
            c.execute("INSERT INTO setting (key, value) VALUES ('legal_linkedin_1112', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'passenger_only_v1'").fetchone():
            for r in c.execute("SELECT id, bullets FROM plan").fetchall():
                bullets = json.loads(r["bullets"] or "[]")
                if any(b in PASSENGER_BULLETS for b in bullets):
                    c.execute("UPDATE plan SET bullets = ? WHERE id = ?", (json.dumps([PASSENGER_BULLETS.get(b, b) for b in bullets]), r["id"]))
            c.execute("INSERT INTO setting (key, value) VALUES ('passenger_only_v1', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'free_no_ai_v1'").fetchone():  # AI is paid plans only
            r = c.execute("SELECT bullets FROM plan WHERE id = 'free'").fetchone()
            if r:
                bullets = [b for b in json.loads(r["bullets"] or "[]") if "analyst question" not in b.lower()]
                c.execute("UPDATE plan SET ai_quota = 0, bullets = ? WHERE id = 'free'", (json.dumps(bullets),))
            c.execute("INSERT INTO setting (key, value) VALUES ('free_no_ai_v1', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'no_mexico_v1'").fetchone():  # Mexico parked 2026-10-30
            for r in c.execute("SELECT key, value FROM setting").fetchall():
                v = drop_mexico(r["value"])
                if v != (r["value"] or ""):
                    c.execute("UPDATE setting SET value = ? WHERE key = ?", (v, r["key"]))
            c.execute("INSERT INTO setting (key, value) VALUES ('no_mexico_v1', '1')")
        if not c.execute("SELECT 1 FROM setting WHERE key = 'headline_1103_v1'").fetchone():  # Justin approved this copy 2026-11-03
            for k in ("tagline", "hero_title", "hero_highlight", "hero_sub", "cta_title"):
                c.execute("INSERT INTO setting (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (k, DEFAULT_SETTINGS[k]))
            c.execute("INSERT INTO setting (key, value) VALUES ('headline_1103_v1', '1')")
        for k, old, new in COPY_UPDATES:  # only replaces copy nobody has edited
            c.execute("UPDATE setting SET value = ? WHERE key = ? AND value = ?", (new, k, old))
        c.commit()
        c.close()


def q(sql, args=(), one=False):
    c = connect()
    try:
        rows = c.execute(sql, args).fetchall()
        return (rows[0] if rows else None) if one else rows
    finally:
        c.close()


def x(sql, args=()):
    with _lock:
        c = connect()
        try:
            cur = c.execute(sql, args)
            c.commit()
            return cur.lastrowid
        finally:
            c.close()


def settings():
    return {r["key"]: r["value"] for r in q("SELECT key, value FROM setting")}


def set_setting(key, value):
    x("INSERT INTO setting (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))


def audit(action, detail="", user_id=None, actor=None):
    x("INSERT INTO audit (ts, user_id, actor, action, detail) VALUES (?,?,?,?,?)", (now(), user_id, actor, action, detail))


def plans(active_only=True):
    rows = q("SELECT * FROM plan" + (" WHERE active = 1" if active_only else "") + " ORDER BY sort")
    return [plan_dict(r) for r in rows]


def is_freight_plan(p):
    """A freight plan carries the Freight Rail Analytics Portal ('rail') without the passenger fleet data. Plans that bundle both
    count as passenger plans."""
    f = p.get("features") or []
    return (p.get("id") or "").startswith("freight") or ("rail" in f and "fleet_basic" not in f)


def plan_line(p):
    """The product line a plan is sold under on /pricing: 'master' (Master Analyst, the all-features plan, id 'enterprise', or any
    plan with both the passenger fleet data and the freight portal), 'freight' (is_freight_plan) or 'passenger'. Derived from the
    plan's id and features, so plan ids never change."""
    f, pid = p.get("features") or [], p.get("id") or ""
    if pid == "enterprise":
        return "master"
    if pid.startswith("freight") or is_freight_plan(p):  # freight_analyst, freight_team, whatever else is ticked on them
        return "freight"
    if "rail" in f and "fleet_basic" in f and "bids_full" in f:
        return "master"
    return "passenger"


def offered_plans(rows=None):
    """Plans a member can pick: freight plans only once the portal is open (Admin > Settings > General)."""
    rail_open = settings().get("rail_open") == "1"
    return [p for p in (plans() if rows is None else rows) if rail_open or not is_freight_plan(p)]


def plan_dict(r):
    d = dict(r)
    d["features"] = json.loads(d.get("features") or "[]")
    d["bullets"] = json.loads(d.get("bullets") or "[]")
    return d


def get_plan(plan_id):
    r = q("SELECT * FROM plan WHERE id = ?", (plan_id,), one=True) or q("SELECT * FROM plan WHERE id = 'free'", one=True)
    return plan_dict(r)


# ---- the live fleet-db databases (read-only) ----

def _ro(path):
    if not os.path.exists(path):
        return None
    c = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=15, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


def hide_freight():
    """True while freight is parked for this viewer (see lens.py): queries then see passenger and transit rows only."""
    from . import lens
    return not lens.current().freight


def _in(ids):
    return ",".join("'" + str(i).replace("'", "''") + "'" for i in sorted(ids)) or "''"


_freight_ids = {"key": None, "ops": set(), "ags": set()}


def freight_ids():
    """(parked operator ids in fleet.db, Bid Catcher agencies that buy only for them). Parked means freight railroads, and since
    2026-10-30 everything in Mexico (Justin: "forget about them for now"). Cached per file version."""
    try:
        key = (os.stat(config.FLEET_DB).st_mtime, os.stat(config.BIDS_DB).st_mtime if os.path.exists(config.BIDS_DB) else 0)
    except OSError:
        key = None
    if key is not None and _freight_ids["key"] == key:
        return _freight_ids["ops"], _freight_ids["ags"]
    ops, ags = set(), set()
    c = _ro(config.FLEET_DB)
    if c is not None:
        try:
            ops = {r[0] for r in c.execute("SELECT operator_id FROM operator WHERE coalesce(category, '') LIKE 'freight%' "
                                            "OR replace(replace(coalesce(modes, ''), 'FR', ''), ';', '') = '' AND coalesce(modes, '') LIKE '%FR%' "
                                            "OR coalesce(country, '') = 'MX'")}
        finally:
            c.close()
    c = _ro(config.BIDS_DB)
    if c is not None:
        try:
            for r in c.execute("SELECT agency_id, country, rail_modes, fleet_operator_ids FROM agency"):
                modes = {m for m in (r["rail_modes"] or "").split(";") if m}
                linked = {o for o in (r["fleet_operator_ids"] or "").split(";") if o}
                if (modes and modes <= {"FR"}) or (not modes and linked and linked <= ops) or r["agency_id"] in ops \
                        or (r["country"] or "") == "MX":
                    ags.add(r["agency_id"])
        except sqlite3.Error:
            pass
        finally:
            c.close()
    _freight_ids.update(key=key, ops=ops, ags=ags)
    return ops, ags


# Tables and views the site reads, and the filter that drops freight rows from each (applied as TEMP views of the same name,
# which SQLite resolves before the main schema).
_FLEET_HIDE = {"operator": "operator_id NOT IN ({ops})", "fleet": "operator_id NOT IN ({ops})",
               "v_fleet_profile": "operator_id NOT IN ({ops}) AND coalesce(ntd_mode, '') != 'FR'",
               "v_fleet_national": "operator_id NOT IN ({ops})", "v_fleet_electrification": "operator_id NOT IN ({ops})",
               "seed_fleet": "operator_id NOT IN ({ops})", "vehicle": "operator_id NOT IN ({ops})", "v_vehicle": "operator_id NOT IN ({ops})",
               "seed_procurement": "coalesce(operator_id, '') NOT IN ({ops})", "seed_subsystem": "operator_id NOT IN ({ops})",
               "operator_mode_year": "coalesce(ntd_mode, '') != 'FR'", "operator_cost_trend": "coalesce(ntd_mode, '') != 'FR'",
               "loco_energy_operator": "operator_id NOT IN ({ops})", "fleet_consumable_estimate": "operator_id NOT IN ({ops})",
               "operator_consumable_estimate": "operator_id NOT IN ({ops})", "seed_freight_loco_year": "0", "v_freight_loco_latest": "0"}
_BIDS_HIDE = {"agency": "agency_id NOT IN ({ags})", "notice": "coalesce(agency_id, '') NOT IN ({ags})",
              "award": "coalesce(agency_id, '') NOT IN ({ags})", "budget_item": "coalesce(agency_id, '') NOT IN ({ags})",
              "funding_grant": "coalesce(agency_id, '') NOT IN ({ags})", "doc_source": "coalesce(agency_id, '') NOT IN ({ags})"}


def _shadow(c, hide, **ids):
    have = {r[0]: r[1] for r in c.execute("SELECT name, type FROM main.sqlite_master WHERE type IN ('table', 'view')")}
    for name, cond in hide.items():
        if name in have:
            # a view has no rowid of its own, so carry the table's rowid through (joins such as seed_subsystem.rowid rely on it)
            cols = "rowid AS rowid, *" if have[name] == "table" else "*"
            c.execute(f"CREATE TEMP VIEW {name} AS SELECT {cols} FROM main.{name} WHERE {cond.format(**ids)}")
    return c


# 1.7.92 (BD review 11-19): builder lineage. vehicle_model.manufacturer is today's owner of the design (Bombardier cars show as Alstom,
# Breda as Hitachi Rail, EMD as Progress Rail), which made Alstom look like 45% of the market. Every page now shows the company that
# BUILT the cars (manufacturer, from manufacturer_orig) and keeps today's owner in manufacturer_now ("now Alstom"; market share can
# switch to it). Names not listed here keep the current name: they are spelling variants, not different companies.
LINEAGE = {"ABB": "ABB", "ABB / Adtranz": "Adtranz", "Adtranz": "Adtranz", "Alstom / Kawasaki": "Alstom", "Bombardier": "Bombardier",
           "Bombardier/Alstom": "Bombardier", "Budd / Vickers Canada (rebuilt by Alstom)": "Budd", "Franco-Belge": "Franco-Belge",
           "Rohr / Alstom": "Rohr", "UTDC": "UTDC", "UTDC / Bombardier": "UTDC", "AnsaldoBreda": "AnsaldoBreda", "Breda": "Breda",
           "Hitachi": "Hitachi Rail", "Hitachi Rail Italy (AnsaldoBreda)": "AnsaldoBreda", "EMD": "EMD", "EMD (Progress Rail)": "EMD",
           "EMD / Morrison-Knudsen": "EMD", "EMD/Progress Rail (rebuild)": "EMD", "GMD": "EMD", "Morrison-Knudsen": "Morrison-Knudsen",
           "GE": "GE", "MotivePower": "MotivePower", "Colorado Railcar": "Colorado Railcar"}


def builder_now(built, now):
    """'Bombardier', 'Alstom' -> 'now Alstom'; '' when the builder still exists under its own name."""
    return f"now {now}" if now and built and now != built else ""


def _lineage(c, cond=None):
    """Shadow v_fleet_profile so manufacturer is the original builder and manufacturer_now is today's owner (TEMP view, read-only safe)."""
    try:
        cols = [r[1] for r in c.execute("PRAGMA main.table_info(v_fleet_profile)")]
        if not cols or "manufacturer" not in cols or \
                "manufacturer_orig" not in {r[1] for r in c.execute("PRAGMA main.table_info(vehicle_model)")}:
            return
        c.execute("CREATE TEMP TABLE IF NOT EXISTS builder_lineage (orig TEXT PRIMARY KEY, built TEXT)")
        c.executemany("INSERT OR REPLACE INTO temp.builder_lineage VALUES (?, ?)", LINEAGE.items())
        # 1.8.26: a known locomotive model typed as a coach or car in a source row shows as a locomotive (locomodel.fix)
        from . import locomodel
        c.create_function("loco_class", 2, locomodel.fix, deterministic=True)
        fix = "model_name" in cols and "vehicle_class" in cols
        sel = ", ".join("coalesce((SELECT bl.built FROM main.fleet f JOIN main.vehicle_model vm USING (model_id) "
                        "JOIN temp.builder_lineage bl ON bl.orig = vm.manufacturer_orig WHERE f.fleet_id = p.fleet_id), p.manufacturer) AS manufacturer"
                        if k == "manufacturer" else "loco_class(p.vehicle_class, p.model_name) AS vehicle_class" if k == "vehicle_class" and fix
                        else f"p.{k}" for k in cols)
        c.execute("DROP VIEW IF EXISTS temp.v_fleet_profile")
        c.execute(f"CREATE TEMP VIEW v_fleet_profile AS SELECT {sel}, p.manufacturer AS manufacturer_now FROM main.v_fleet_profile p"
                  + (f" WHERE {cond}" if cond else ""))
    except sqlite3.Error:
        pass


def fleet():
    c = _ro(config.FLEET_DB)
    if c is not None:
        cond = None
        if hide_freight():
            ops, _ = freight_ids()
            if ops:
                _shadow(c, _FLEET_HIDE, ops=_in(ops))
                cond = _FLEET_HIDE["v_fleet_profile"].format(ops=_in(ops))
        _lineage(c, cond)
    return c


_hyg = {"key": None, "on": False}


def _has_dup_col(c):
    """bids-push47 hygiene columns present (notice.dup_of, notice.hygiene_note)? Cached per bids.db version."""
    try:
        key = os.stat(config.BIDS_DB).st_mtime
    except OSError:
        return False
    if _hyg["key"] != key:
        try:
            cols = {r[1] for r in c.execute("PRAGMA main.table_info(notice)")}
        except sqlite3.Error:
            cols = set()
        _hyg.update(key=key, on="dup_of" in cols)
    return _hyg["on"]


def bids():
    c = _ro(config.BIDS_DB)
    if c is None:
        return c
    hide = dict(_BIDS_HIDE) if hide_freight() else {}
    ags = freight_ids()[1] if hide else set()
    if not ags:
        hide = {}
    if _has_dup_col(c):  # 1.7.92 (BD review): Bid Catcher marks repeats of the same bid; every list and count skips them
        hide["notice"] = (hide["notice"] + " AND " if "notice" in hide else "") + "dup_of IS NULL"
    if hide:
        _shadow(c, hide, ags=_in(ags))
    return c


def bids_rw():
    c = sqlite3.connect(config.BIDS_DB, timeout=30)
    c.row_factory = sqlite3.Row
    return c


def fq(sql, args=(), one=False, db="fleet"):
    c = fleet() if db == "fleet" else bids()
    if c is None:
        return None if one else []
    try:
        rows = c.execute(sql, args).fetchall()
        return (rows[0] if rows else None) if one else rows
    finally:
        c.close()


def bq(sql, args=(), one=False):
    return fq(sql, args, one, db="bids")
