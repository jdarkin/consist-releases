"""How fleet counts are worded (Justin 11-26): a locomotive is a locomotive, not a car.

Every place that says how many vehicles a fleet has goes through here, so the unit follows the vehicle type:
"90 locomotives", "1 cab car", "212 coaches", "64 EMU cars", "120 light rail vehicles". A mixed group lists each type
("57 locomotives and 900 coaches") instead of one combined count of "cars". Where a single total across types is
unavoidable (a table column, a map dot), the word is "units", never "cars".

kind() also corrects the vehicle type when the model name is a known locomotive model (MP40PH-3C, MP54AC, F40PH,
SC-44, ALC-42, ...) but the record says coach or car, so a bad source row can't turn locomotives into cars."""
from . import data
from .locomodel import LOCO_MODEL, NOT_LOCO

# (singular, plural) per vehicle type key from data.CLASSES
UNIT = {
    "locomotive": ("locomotive", "locomotives"), "switcher": ("switcher locomotive", "switcher locomotives"),
    "slug": ("slug unit", "slug units"), "coach": ("coach", "coaches"), "cab_car": ("cab car", "cab cars"),
    "emu": ("EMU car", "EMU cars"), "dmu": ("DMU car", "DMU cars"), "metro_car": ("metro car", "metro cars"),
    "lrv": ("light rail vehicle", "light rail vehicles"), "streetcar": ("streetcar", "streetcars"),
    "heritage_streetcar": ("heritage streetcar", "heritage streetcars"), "agt_vehicle": ("people mover vehicle", "people mover vehicles"),
    "monorail_car": ("monorail car", "monorail cars"), "cable_car": ("cable car", "cable cars"), "incline_car": ("incline car", "incline cars"),
    "trainset": ("trainset", "trainsets"), "freight_car": ("freight car", "freight cars"),
}
GENERIC = ("unit", "units")  # a total across vehicle types, or a type we can't tell

LOCO_TYPES = {"locomotive", "switcher", "slug"}



def kind(fl):
    """Vehicle type key for a fleet (dict or sqlite Row), corrected for known locomotive models."""
    g = (lambda k: fl[k] if k in fl.keys() else None) if hasattr(fl, "keys") and not isinstance(fl, dict) else (lambda k: fl.get(k))
    k = data.cls_key(g("vehicle_class") or g("cls") or "")
    model = " ".join(str(g(x) or "") for x in ("model_name", "model"))
    if k not in LOCO_TYPES and LOCO_MODEL.search(model) and not NOT_LOCO.search(model):
        return "locomotive"
    return k


def is_loco(fl):
    return kind(fl) in LOCO_TYPES


def word(k, n=2):
    """'locomotive' / 'locomotives' for a type key (or a fleet) and a count."""
    if not isinstance(k, str):
        k = kind(k)
    s, p = UNIT.get(data.cls_key(k), GENERIC)
    return s if n == 1 else p


def count(fl, n=None):
    """'90 locomotives' for one fleet (n defaults to its active quantity)."""
    if n is None:
        n = (fl.get("qty_active") if isinstance(fl, dict) else fl["qty_active"]) or 0
    return f"{n:,} {word(kind(fl), n)}"


def n_of(k, n):
    """'1 coach', '3,000 metro cars' for a type key."""
    return f"{n:,} {word(k, n)}"


def tally(fleets, qty="qty_active"):
    """{type key: total} over fleets, biggest first."""
    t = {}
    for fl in fleets:
        v = (fl.get(qty) if isinstance(fl, dict) else fl[qty]) or 0
        if v:
            k = kind(fl)
            t[k] = t.get(k, 0) + v
    return dict(sorted(t.items(), key=lambda kv: -kv[1]))


def mix(fleets, qty="qty_active", most=3):
    """'57 locomotives and 900 coaches' for a group of fleets: one count per vehicle type, never a combined 'cars'.
    More than `most` types: the biggest, then 'and N other units'. Locomotives are always named, never folded into 'other'."""
    return mix_dict(tally(fleets, qty), most)


def mix_dict(t, most=3):
    """Same as mix() from a ready {type key: n} tally."""
    t = sorted(((data.cls_key(k), n) for k, n in (t or {}).items() if n), key=lambda kv: -kv[1])
    if not t:
        return "0 units"
    keep = t[:most] + [kv for kv in t[most:] if kv[0] in LOCO_TYPES]
    rest = sum(n for kv in t if kv not in keep for n in [kv[1]])
    parts = [n_of(k, n) for k, n in keep]
    if rest:
        parts.append(f"{rest:,} other {word('', rest)}")
    return parts[0] if len(parts) == 1 else ", ".join(parts[:-1]) + " and " + parts[-1]


def label(fl, prefix="Active"):
    """Field label for one fleet's count: 'Active locomotives', 'Active coaches'."""
    w = word(kind(fl), 2)
    return f"{prefix} {w}" if prefix else w[:1].upper() + w[1:]


def order_word(model, n=2, cls=None):
    """Unit word for an order line where only the model text (and maybe a type) is known: 'locomotives' for a
    locomotive model, the type's word when given, else 'vehicles'."""
    if cls or LOCO_MODEL.search(model or ""):
        return word(kind({"model_name": model or "", "vehicle_class": cls or ""}), n)
    return "vehicle" if n == 1 else "vehicles"


def fix_detail(detail, fl):
    """Reword a stored fleet change line ('Active cars: 88 → 90', 'New fleet: X, 90 cars') for the fleet's type.
    Lines recorded before 1.8.26 said cars for every fleet."""
    import re as _re
    if not detail or not fl:
        return detail
    k = kind(fl)
    w = word(k, 2)
    d = _re.sub(r"^Active cars:", f"Active {w}:", detail)
    d = _re.sub(r"^Total cars:", f"Total {w}:", d)
    m = _re.search(r", (\d[\d,]*) cars$", d)
    if m:
        n = int(m.group(1).replace(",", ""))
        d = d[:m.start()] + f", {n:,} {word(k, n)}"
    return d
