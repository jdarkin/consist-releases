"""Getting started: the member guide at /app/start and the step-by-step tour over the app's menu (Justin, 2026-11-02).

Each section explains one part of the site: what it is for, how to use it in a few steps, and where it lives. Its text can be
replaced in Admin > Settings > Getting started (setting 'guide_<key>': the first line is the summary, every further line a step;
blank keeps the text below). Access is per plan: a section the member's plan doesn't include shows as a preview with the plan
that unlocks it, so the guide also explains what upgrading adds."""
from . import db

# key, title, icon, link, feature needed ('' = every plan; 'bids', 'rail', 'save', 'ai' are special), summary, steps
SECTIONS = [
    ("lens", "Pick your market and region", "target", "/app", "",
     "The bar at the top of every page sets the market you're looking at (all rail, transit or passenger rail) and the regions. "
     "Every list, chart and count follows it.",
     ["Choose All rail, Transit or Passenger rail at the top of any page.",
      "Use Region to narrow to the parts of the US and Canada you cover.",
      "Your choice is remembered until you change it."]),
    ("dashboard", "Your dashboard", "home", "/app", "",
     "The first page after you sign in: what's new since your last visit, bids closing soon, your saved searches and the fleets and "
     "operators you follow.",
     ["Check 'New since your last sign-in' for fresh bids and fleet changes.",
      "Pick what you sell under Account > Market to get a dashboard tuned to it.",
      "Click any number or chart to open the list behind it."]),
    ("bids", "Bids and RFPs (Bid Catcher)", "bids", "/app/bids", "bids",
     "Every public rail and transit procurement in the US and Canada, checked daily, scored 0 to 100 for rail vehicle relevance and "
     "tied to the fleet it is for.",
     ["Filter by trade, agency, status or relevance; sort by closing date.",
      "Open a bid for the summary, documents and the fleet it relates to.",
      "Save the search to get it by email (daily or instantly on paid plans).",
      "Star a bid to keep it on your dashboard."]),
    ("work", "Upcoming work and the replacement forecast", "target", "/app/work", "pipeline",
     "The work coming before it is bid: cars reaching end of life, mid-life overhauls due, and orders in the pipeline, year by year.",
     ["Switch views: timeline, ranked list, forecast, pipeline or orders.",
      "Click a bar in any chart to list the fleets behind it.",
      "Use the forecast to plan sales years ahead of the RFP."]),
    ("awards", "Funding and awards", "award", "/app/awards", "awards",
     "Who won rail work, at what price, and the federal and state grants that pay for the next round.",
     ["Search past awards by agency, supplier or trade.",
      "Use the Funding tab to see grants that lead to procurements.",
      "Compare winning prices before you bid."]),
    ("installed", "Operators, fleets and subsystems", "fleet", "/app/fleets", "",
     "Every passenger rail and transit fleet: builder, model, age, active units, duty cycle and overhaul timing, down to subsystem "
     "suppliers such as HVAC, doors, trucks and propulsion.",
     ["Use Search in the menu to find any operator, fleet, builder, model or part.",
      "Open an operator for its fleets, contacts, bids and costs.",
      "Open a fleet for its subsystems, suppliers and when its next overhaul is due."]),
    ("market", "Market share and suppliers", "pie", "/app/market", "market",
     "The installed base by builder and by subsystem supplier: who owns which share, where, and where it is turning over.",
     ["Pick a subsystem to see each supplier's installed base.",
      "Open Suppliers for every fleet a supplier is on.",
      "Find fleets whose current supplier is up for replacement."]),
    ("costs", "Cost benchmarks and escalation", "trend", "/app/costs", "fleet_detail",
     "Maintenance cost per car-mile against peers, cost trends since 2015, and escalation forecasts for pricing multi-year work.",
     ["Compare an operator's cost per car-mile with its peers.",
      "Use Cost escalation to price option years and long contracts."]),
    ("freight", "Freight Rail Analytics Portal", "chart", "/rail", "rail",
     "Class I, regional and short line railroads: STB R-1 financials, EP 724 weekly service metrics, freight flows to 2050, "
     "locomotives, freight cars, tank cars, crossings, safety and rail cost indexes.",
     ["Open it from the highlighted Freight rail tools button under My dashboard (plans with both markets).",
      "Use the Class I / Regional / Short line switch at the top to change segment.",
      "Hover any heading for its definition; Definitions lists them all.",
      "Every free account sees this week's headline numbers from each page."]),
    ("lists", "Saving, lists and accounts", "list", "/app/lists", "save",
     "Keep the bids, fleets and operators you care about, and build account lists for your sales territory.",
     ["Click the star on any bid, fleet or operator to save it.",
      "Build lists of operators or fleets in Accounts and lists.",
      "Add notes and contacts to an operator to share with your team."]),
    ("alerts", "Alerts", "bell", "/app/alerts", "save",
     "Email when a saved search finds a new bid, or when a fleet or operator you follow changes.",
     ["Save any bid search to make it an alert.",
      "Choose daily or instant delivery per search.",
      "Fleet change alerts cover the fleets and operators you starred."]),
    ("ai", "AI analyst", "ai", "/app/analyst", "ai",
     "Ask questions in plain English and get an answer drawn from the fleet, bid, award, cost and freight railroad data your plan "
     "includes, with the sources.",
     ["Ask things like 'Which light rail fleets need a mid-life overhaul by 2028?' or 'Which Class I has the lowest operating ratio?'",
      "Each question or AI bid brief uses one from your monthly allowance.",
      "Open the cited records to check the numbers."]),
    ("export", "Exports", "doc", "/app/fleets", "export",
     "Download what you see as CSV, or send account lists to Salesforce or HubSpot.",
     ["Use the Export button above a table.",
      "CRM export is under Accounts and lists."]),
]


def _ok(u, feat):
    if not feat or u.is_admin:
        return True
    p = u.plan or {}
    if feat == "bids":
        return bool(u.bids)
    if feat == "save":
        return bool(p.get("price_month") or p.get("contact_only") or u.get("sub_status") == "ambassador")
    if feat == "ai":
        return bool(p.get("ai_quota"))
    return u.can_plan(feat)


def sections(u):
    s = db.settings()
    out = []
    for key, title, ic, href, feat, summary, steps in SECTIONS:
        custom = [ln.strip() for ln in (s.get("guide_" + key) or "").splitlines() if ln.strip()]
        if custom:
            summary, steps = custom[0], custom[1:] or steps
        out.append(dict(key=key, title=title, icon=ic, href=href, feat=feat, summary=summary, steps=steps, ok=_ok(u, feat) if u else False))
    return out


# Extra tour stops (Justin, 2026-11-02): the market bar is explained button by button, the AI analyst with example questions,
# and the tour ends on the "Did we miss something?" link. Each stop's key matches a data-tour hook in app/shell.html.
LENS_STOPS = [
    ("lens-all", "All rail", "Every market at once: transit, commuter and intercity rail, with bids from every rail and transit agency."),
    ("lens-transit", "Transit", "Metro, light rail, streetcar, monorail and people movers only. Lists, charts, counts and bids follow it."),
    ("lens-passenger", "Passenger rail", "Commuter, intercity, Amtrak, VIA and state corridors only."),
    ("lens-region", "Region", "Narrow everything to the United States, Canada or both. Leave all unticked for every region."),
]
AI_EXAMPLES = [
    "Which light rail fleets need a midlife overhaul by 2028, and who built them?",
    "Which commuter railroads have the highest maintenance cost per car-mile against their peers?",
    "Who has won HVAC or door overhaul contracts in the last five years, and at what price?",
    "Which open bids involve trucks, wheelsets or traction motors, and which fleets do they concern?",
]
AI_EXAMPLES_FREIGHT = [
    "Which Class I railroad had the lowest operating ratio last year, and how has it changed over five years?",
    "How has terminal dwell changed for each Class I railroad over the last 12 weeks?",
    "Which short line holding companies run the most train-miles, and what are their accident rates?",
    "How much fuel surcharge revenue did each Class I collect against its fuel cost last year?",
]


def tour_steps(u, freight_ok=False):
    """The steps for the /app?tour=1 walk-through: [{t, s, k, ok, ex}]; k is the data-tour hook to highlight."""
    out = []
    for g in sections(u):
        if g["key"] == "export":
            continue
        if g["key"] == "lens":
            out.append(dict(t=g["title"], s=g["summary"], k="lens", ok=True, ex=[]))
            out += [dict(t="Market bar: " + t, s=s, k=k, ok=True, ex=[]) for k, t, s in LENS_STOPS]
            continue
        st = dict(t=g["title"], s=g["summary"], k=g["href"], ok=g["ok"], ex=[])
        if g["key"] == "ai":
            from . import analyst
            acc = analyst.access(u)
            what = {(True, False): "fleet, bid, award and cost data", (False, True): "freight railroad filings, service, safety and cost data",
                    (True, True): "fleet, bid, award, cost and freight railroad data"}.get(("fleet" in acc, "freight" in acc), "data")
            st["s"] = ("Open AI analyst from the menu, type a question in plain English or click an example under the box, and press Ask. "
                       f"It searches the {what} and shows the sources behind the answer. Each question uses one from your monthly allowance. Try:")
            st["ex"] = ((AI_EXAMPLES[:2] if "freight" in acc else AI_EXAMPLES) if "fleet" in acc else []) + \
                       ((AI_EXAMPLES_FREIGHT[:2] if "fleet" in acc else AI_EXAMPLES_FREIGHT) if "freight" in acc else [])
        out.append(st)
    out.append(dict(t="Did we miss something?", s="At the bottom of every page. If a number, chart or tool you need isn't here, tell us "
                    "and we'll build it.", k="request", ok=True, ex=[]))
    return out


def admin_rows():
    """For Admin > Settings > Getting started: each section's default text and its saved override."""
    s = db.settings()
    return [dict(key=k, title=t, default="\n".join([summ] + steps), value=s.get("guide_" + k) or "") for k, t, _i, _h, _f, summ, steps in SECTIONS]


def keys():
    return ["guide_intro"] + ["guide_" + k for k, *_ in SECTIONS]
