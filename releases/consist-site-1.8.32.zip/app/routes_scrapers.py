"""Admin > Scrapers (1.8.29): heavy anonymous visitors by truncated network, and the rate-limit settings (app/scrapeguard.py)."""
from fastapi import APIRouter, Depends, Form, Request

from . import auth, db, scrapeguard

admin = APIRouter(prefix="/admin")
A = Depends(auth.require_admin)


@admin.get("/scrapers")
def page(request: Request, days: int = 7, u=A):
    from .main import render
    days = days if days in (1, 7, 30) else 7
    rows, totals, flag = scrapeguard.report(days)
    return render(request, "admin/scrapers.html", user=u, rows=rows, totals=totals, flag=flag, days=days,
                  conf=scrapeguard.conf(), flagged=sum(1 for r in rows if r["flags"]))


@admin.post("/scrapers/settings")
def save(request: Request, csrf: str = Form(""), scrape_on: str = Form(""), scrape_per_min: str = Form("30"),
         scrape_per_hour: str = Form("600"), scrape_flag_day: str = Form("300"), u=A):
    from .main import flash, redirect
    auth.check_csrf(request, csrf)

    def clamp(v, lo, hi, d):
        try:
            return str(min(hi, max(lo, int(v))))
        except ValueError:
            return d
    vals = {"scrape_on": "1" if scrape_on else "0", "scrape_per_min": clamp(scrape_per_min, 5, 600, "30"),
            "scrape_per_hour": clamp(scrape_per_hour, 30, 20000, "600"), "scrape_flag_day": clamp(scrape_flag_day, 20, 100000, "300")}
    for k, v in vals.items():
        db.set_setting(k, v)
    db.audit("scrape_settings", ", ".join(f"{k}={v}" for k, v in vals.items()), actor=u.email)
    scrapeguard.reset()
    flash(request, "Scraper settings saved.")
    return redirect("/admin/scrapers")
