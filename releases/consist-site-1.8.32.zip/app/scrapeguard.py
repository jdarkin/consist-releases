"""Scraper guard (1.8.29): slows down anonymous visitors who pull pages faster than a person reads them.

- Counts page views (GET/HEAD) per visitor address over a sliding minute and hour. Over the limit, the visitor gets a
  friendly 429 page with Retry-After; nothing is blocked for good.
- Never limited: signed-in members and admins (any session with a uid), verified Googlebot and Bingbot (reverse DNS
  then forward DNS, cached a day), static files, health checks, robots.txt, sitemap, feeds, Stripe webhooks.
- The full address lives only in memory for the minute/hour window. What is stored (table scrape_day, Admin > Scrapers)
  is the truncated network (IPv4 /24, IPv6 /48), a short user agent and daily counts; rows go after 30 days.
- Settings in Admin > Scrapers: scrape_on, scrape_per_min (30), scrape_per_hour (600), scrape_flag_day (300).
Single uvicorn worker (Dockerfile), so in-memory windows are shared by every request.
"""
import asyncio
import collections
import ipaddress
import re
import socket
import time

from starlette.requests import Request

from . import db

DEFAULTS = {"scrape_on": "1", "scrape_per_min": "30", "scrape_per_hour": "600", "scrape_flag_day": "300"}
SKIP = ("/static", "/healthz", "/robots.txt", "/sitemap.xml", "/feed.xml", "/favicon", "/stripe/webhook", "/apple-touch-icon",
        "/manifest", "/.well-known/", "/unsubscribe", "/embed/", "/login", "/signup", "/logout", "/reset", "/verify")  # sign-in pages stay open so a slowed visitor can sign in
# Crawlers that train AI models; listed in robots.txt and labeled on the Admin page.
AI_BOTS = ("GPTBot", "ChatGPT-User", "OAI-SearchBot", "CCBot", "Bytespider", "ClaudeBot", "Claude-Web", "anthropic-ai",
           "Google-Extended", "Applebot-Extended", "PerplexityBot", "Perplexity-User", "cohere-ai", "cohere-training-data-crawler",
           "Diffbot", "Amazonbot", "meta-externalagent", "FacebookBot", "ImagesiftBot", "Omgilibot", "Timpibot", "YouBot",
           "AI2Bot", "PetalBot", "DuckAssistBot", "MistralAI-User")
SEARCH_BOTS = {"googlebot": (".googlebot.com", ".google.com", ".googleusercontent.com"), "bingbot": (".search.msn.com",)}
TOOL_RE = re.compile(r"python-requests|python-urllib|aiohttp|httpx|curl/|wget|scrapy|go-http-client|java/|okhttp|node-fetch|axios|"
                     r"headless|phantomjs|libwww|httpclient|colly|zgrab|masscan|nuclei|semrush|ahrefs|mj12bot|dotbot|dataforseo", re.I)
SCHEMA = """CREATE TABLE IF NOT EXISTS scrape_day (day TEXT, net TEXT, ua TEXT, pages INTEGER DEFAULT 0, limited INTEGER DEFAULT 0,
  paths INTEGER DEFAULT 0, first_seen TEXT, last_seen TEXT, sample TEXT, PRIMARY KEY (day, net, ua));"""

_win = {}            # full ip -> deque of monotonic times (memory only, last hour)
_day = {}            # (day, net, ua) -> [pages, limited, set(paths), first, last, sample]
_bots = {}           # ip -> (verified bool, checked monotonic)
_cfg = {"t": 0.0, "s": {}}
_flush = {"t": time.monotonic()}
_ready = {"ok": False}


def ensure():
    if _ready["ok"]:
        return
    c = db.connect()
    try:
        c.executescript(SCHEMA)
        c.commit()
    finally:
        c.close()
    _ready["ok"] = True


def conf():
    if time.monotonic() - _cfg["t"] > 10:
        try:
            s = db.settings()
            _cfg["s"] = {k: s.get(k) or v for k, v in DEFAULTS.items()}
        except Exception:
            _cfg["s"] = dict(DEFAULTS)
        _cfg["t"] = time.monotonic()
    return _cfg["s"]


def reset():
    _cfg["t"] = 0.0


def num(s, k):
    try:
        return max(1, int(s.get(k) or DEFAULTS[k]))
    except ValueError:
        return int(DEFAULTS[k])


def net_of(ip):
    """IPv4 /24 or IPv6 /48 — the only form of an address that is ever stored."""
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return "?"
    if a.version == 6 and a.ipv4_mapped:
        a = a.ipv4_mapped
    n = ipaddress.ip_network(f"{a}/{24 if a.version == 4 else 48}", strict=False)
    return str(n)


def short_ua(ua):
    ua = (ua or "").strip()
    if not ua:
        return "(none)"
    for b in AI_BOTS:
        if b.lower() in ua.lower():
            return b
    m = TOOL_RE.search(ua)
    if m:
        return m.group(0).rstrip("/")[:40]
    for name in ("Edg", "OPR", "Firefox", "Chrome", "Safari"):
        if name + "/" in ua:
            plat = next((p for p in ("Windows", "Mac OS X", "iPhone", "iPad", "Android", "Linux", "CrOS") if p in ua), "")
            return f"{ {'Edg': 'Edge', 'OPR': 'Opera'}.get(name, name)} {plat}".strip()[:60]
    return ua[:60]


def kind(ua):
    """Label for the Admin page: ai, search, tool, browser."""
    low = (ua or "").lower()
    if any(b.lower() in low for b in AI_BOTS):
        return "ai"
    if "googlebot" in low or "bingbot" in low:
        return "search"
    if not low or low == "(none)" or TOOL_RE.search(low):
        return "tool"
    return "browser"


def _verify_bot(ip, which):
    try:
        host = socket.gethostbyaddr(ip)[0].lower()
        if not host.endswith(SEARCH_BOTS[which]):
            return False
        return ip in socket.gethostbyname_ex(host)[2] or ip in {i[4][0] for i in socket.getaddrinfo(host, None)}
    except Exception:
        return False


async def is_search_bot(ip, ua):
    low = (ua or "").lower()
    which = "googlebot" if "googlebot" in low else "bingbot" if "bingbot" in low else None
    if not which:
        return False
    hit = _bots.get(ip)
    if hit and time.monotonic() - hit[1] < 86400:
        return hit[0]
    try:
        ok = await asyncio.wait_for(asyncio.to_thread(_verify_bot, ip, which), 3)
    except Exception:
        ok = False
    if len(_bots) > 5000:
        _bots.clear()
    _bots[ip] = (ok, time.monotonic())
    return ok


def check(ip, now=None):
    """Record one page view; return seconds to wait if over a limit, else 0."""
    now = time.monotonic() if now is None else now
    s = conf()
    per_min, per_hour = num(s, "scrape_per_min"), num(s, "scrape_per_hour")
    dq = _win.setdefault(ip, collections.deque())
    while dq and now - dq[0] > 3600:
        dq.popleft()
    if len(dq) >= per_min:
        recent = [t for t in dq if now - t <= 60]
        if len(recent) >= per_min:
            return max(1, int(60 - (now - recent[-per_min])) + 1)
    if len(dq) >= per_hour:
        return max(1, int(3600 - (now - dq[-per_hour])) + 1)
    dq.append(now)
    if len(_win) > 20000:  # prune quiet visitors
        for k in [k for k, v in _win.items() if not v or now - v[-1] > 3600]:
            _win.pop(k, None)
    return 0


def note(ip, ua, path, limited):
    day = time.strftime("%Y-%m-%d", time.gmtime())
    key = (day, net_of(ip), short_ua(ua))
    ts = db.now()
    r = _day.get(key)
    if not r:
        r = _day[key] = [0, 0, set(), ts, ts, (ua or "")[:200]]
    r[0 if not limited else 1] += 1
    if len(r[2]) < 2000:
        r[2].add(path[:200])
    r[4] = ts
    if time.monotonic() - _flush["t"] > 60:
        flush()


def flush():
    _flush["t"] = time.monotonic()
    rows, _day_copy = [], list(_day.items())
    _day.clear()
    for (day, net, ua), (pages, limited, paths, first, last, sample) in _day_copy:
        if pages + limited >= 10:  # one-off visits aren't worth a row
            rows.append((day, net, ua, pages, limited, len(paths), first, last, sample))
        elif day == time.strftime("%Y-%m-%d", time.gmtime()):
            _day[(day, net, ua)] = [pages, limited, paths, first, last, sample]  # keep counting today
    if not rows:
        return
    try:
        ensure()
        for r in rows:
            db.x("INSERT INTO scrape_day (day, net, ua, pages, limited, paths, first_seen, last_seen, sample) VALUES (?,?,?,?,?,?,?,?,?)"
                 " ON CONFLICT(day, net, ua) DO UPDATE SET pages = pages + excluded.pages, limited = limited + excluded.limited,"
                 " paths = max(paths, excluded.paths), last_seen = excluded.last_seen", r)
        db.x("DELETE FROM scrape_day WHERE day < ?", (time.strftime("%Y-%m-%d", time.gmtime(time.time() - 30 * 86400)),))
    except Exception:
        pass


def report(days=7):
    """Heavy anonymous pullers for Admin > Scrapers."""
    flush()
    ensure()
    s = conf()
    flag = num(s, "scrape_flag_day")
    since = time.strftime("%Y-%m-%d", time.gmtime(time.time() - (days - 1) * 86400))
    rows = [dict(r) for r in db.q(
        "SELECT net, ua, sum(pages) pages, sum(limited) limited, max(paths) paths, count(DISTINCT day) days, max(pages + limited) peak,"
        " min(first_seen) first_seen, max(last_seen) last_seen, max(sample) sample FROM scrape_day WHERE day >= ?"
        " GROUP BY net, ua ORDER BY sum(pages) + sum(limited) DESC LIMIT 100", (since,))]
    for r in rows:
        r["kind"] = kind(r["sample"] or r["ua"])
        why = []
        if r["peak"] >= flag:
            why.append(f"over {flag} pages in one day")
        if r["limited"]:
            why.append("hit the rate limit")
        if r["kind"] == "ai":
            why.append("AI training crawler")
        elif r["kind"] == "tool":
            why.append("script or scraping tool, not a browser")
        r["flags"] = why
    totals = db.q("SELECT coalesce(sum(pages),0) pages, coalesce(sum(limited),0) limited, count(DISTINCT net) nets FROM scrape_day WHERE day >= ?",
                  (since,), one=True)
    return rows, dict(totals), flag


class ScrapeGuardMiddleware:
    """Must sit inside SessionMiddleware so signed-in members are recognized."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] not in ("GET", "HEAD") or scope["path"].startswith(SKIP):
            return await self.app(scope, receive, send)
        if (scope.get("session") or {}).get("uid"):
            return await self.app(scope, receive, send)
        s = conf()
        if s.get("scrape_on") != "1":
            return await self.app(scope, receive, send)
        ip = scope["client"][0] if scope.get("client") else "?"
        ua = ""
        for k, v in scope.get("headers") or []:
            if k == b"user-agent":
                ua = v.decode("latin-1")[:400]
                break
        if await is_search_bot(ip, ua):
            return await self.app(scope, receive, send)
        wait = check(ip)
        try:
            note(ip, ua, scope["path"], bool(wait))
        except Exception:
            pass
        if not wait:
            return await self.app(scope, receive, send)
        from .main import render
        resp = render(Request(scope, receive), "public/too_many.html", status=429, user=None, wait=wait)
        resp.headers["Retry-After"] = str(wait)
        resp.headers["Cache-Control"] = "no-store"
        await resp(scope, receive, send)


def robots_ai():
    """robots.txt block that asks AI training crawlers to stay out; search engines keep the normal rules."""
    names = [b for b in AI_BOTS if b not in ("ChatGPT-User", "Perplexity-User", "MistralAI-User", "DuckAssistBot", "OAI-SearchBot")]
    return "".join(f"User-agent: {b}\n" for b in names) + "Disallow: /\n"
