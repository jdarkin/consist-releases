"""Awareness plan Phase 1 (Justin approved 2026-11-12, 1.7.36): the monthly member email, the trade press pitch and the
ambassador share kit. All three are written from the month's report numbers (promo._stats) with templates: no AI calls.

- Member email: the month's three headline numbers and a link to the report (?ref=email). Goes to every active member,
  free accounts included, as optional mail (one-click unsubscribe, opted-out addresses skipped). Off until the admin turns on
  "Send automatically" (setting newsletter_auto) or presses Send now in Admin > Social posts. Production only for the automatic
  send. Each address gets a month's email once (newsletter_sent), sent slowly in the background so the SMTP host isn't flooded.
- Ambassadors get the same email plus their share kit: a personal link (?ref=amb-<user id>, so Site usage > Sources counts it)
  and a ready-to-post LinkedIn blurb.
- Press pitch: a subject and short email with this month's newsworthy numbers, for Justin to send from his own mail. Nothing
  is sent to the press automatically."""
import logging
import threading
import time

from . import config, db, mailer

log = logging.getLogger("awareness")

SCHEMA = "CREATE TABLE IF NOT EXISTS newsletter_sent (month TEXT, email TEXT, sent TEXT, PRIMARY KEY (month, email))"
SEND_GAP_SECONDS = 3
_lock = threading.Lock()
_state = {"running": False, "month": "", "sent": 0, "total": 0}

# Trade outlets for the press pitch. Names and newsroom pages only: Justin picks the editor and address himself.
OUTLETS = [
    ("Railway Age", "https://www.railwayage.com/contact-us/"),
    ("Progressive Railroading", "https://www.progressiverailroading.com/contact/"),
    ("Mass Transit", "https://www.masstransitmag.com/contact"),
    ("Trains", "https://www.trains.com/contact-us/"),
    ("Railway Track & Structures", "https://www.rtands.com/contact-us/"),
    ("Metro Magazine", "https://www.metro-magazine.com/contact"),
]


def _init():
    db.x(SCHEMA)


def auto_on():
    return db.settings().get("newsletter_auto", "0") == "1"


def headlines(month):
    """Up to three (number, sentence) pairs from the month's report numbers."""
    from . import promo
    st = promo._stats()
    y = st["year"]
    out = []
    if st["due_next"]:
        out.append((f"{st['cars_next']:,}", f"passenger rail vehicles in {len(st['due_next'])} fleets ({st['mix_next']}) reach their midlife overhaul in {y + 1}."))
    b = st["bids"]
    if b["total"]:
        from . import data as d
        top = b["cats"][0] if b["cats"] else None
        out.append((f"{b['total']:,}", "rail-relevant bids posted by US and Canadian agencies in the last 30 days"
                    + (f", led by {d.CATEGORIES.get(top['category'], 'other').lower()} ({top['n']})." if top else ".")))
    if st["oldest"]:
        o = st["oldest"][0]
        out.append((str(o["build_year"]), f"is when {promo._fleet(o)}, the oldest passenger rail fleet still in service, was built."))
    return out


def _report_url(month, ref):
    from . import promo
    return f"{config.SITE_URL}/p/{promo.slug_for(month)}?ref={ref}"


def ambassador_kit(uid, month):
    """(personal link, LinkedIn blurb) for an ambassador's user id."""
    from . import promo
    link = _report_url(month, f"amb-{uid}")
    h = headlines(month)
    lead = f"{h[0][0]} {h[0][1]}" if h else f"The {promo._label(month)} rail fleet report is out."
    blurb = (f"{lead}\n\nI use Consist to track US and Canadian rail fleets, overhauls and bids. "
             f"Their {promo._label(month)} report is free to read:\n{link}\n\n#rail #transit")
    return link, blurb.replace("Consist", db.settings().get("site_name", "Consist"))


def active_ambassadors():
    from . import ambassadors
    return {a["user_id"]: a for a in ambassadors.rows() if a["state"] == "active" and a.get("user_id")}


def compose(month, user=None, amb=False):
    """(subject, text, html) for one member."""
    from . import ambassadors as am
    from . import promo
    site = db.settings().get("site_name", "Consist")
    label = promo._label(month)
    h = headlines(month)
    link = _report_url(month, "email")
    first = ((user or {}).get("name") or "").split()
    hi = f"Hi {first[0]}," if first else "Hello,"
    subj = f"{site} rail fleet report, {label}" + (f": {h[0][0]} {h[0][1].split(' reach')[0]}" if h and "reach" in h[0][1] else "")
    lines = [hi, "", f"Here are this month's numbers from {site}:", ""] + [f"- {n} {t}" for n, t in h]
    lines += ["", f"The full {label} report, with the fleets and links behind each number:", link]
    rows = "".join(f'<tr><td style="padding:6px 14px 6px 0;font-size:22px;font-weight:bold;color:#0b6b5d;white-space:nowrap;vertical-align:top">{am.esc(n)}</td>'
                   f'<td style="padding:8px 0;vertical-align:top">{am.esc(t)}</td></tr>' for n, t in h)
    inner = (f"<p>{am.esc(hi)}</p><p>Here are this month's numbers from {am.esc(site)}:</p>"
             f'<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 12px">{rows}</table>')
    if amb and user:
        klink, blurb = ambassador_kit(user["id"], month)
        lines += ["", "Your ambassador share kit", "Your personal link (visits through it are credited to you):", klink, "",
                  "A ready-to-post LinkedIn update, edit as you like:", "", blurb]
        inner += ('<div style="margin:16px 0;padding:14px 16px;background:#e1f0ec;border-radius:8px">'
                  '<p style="margin:0 0 6px;font-weight:bold">Your ambassador share kit</p>'
                  f'<p style="margin:0 0 8px">Your personal link (visits through it are credited to you):<br><a href="{am.esc(klink)}" style="color:#0b6b5d">{am.esc(klink)}</a></p>'
                  '<p style="margin:0 0 4px">A ready-to-post LinkedIn update, edit as you like:</p>'
                  f'<p style="margin:0;font-family:Georgia,serif">{am.esc(blurb).replace(chr(10), "<br>")}</p></div>')
    lines += ["", "You get this monthly email because you have a " + site + " account. One click on the unsubscribe link stops it.", "",
              site, config.SITE_URL]
    html = am.email_html(site, inner, link, f"Read the {label} report", "Monthly, from your " + site + " account. Unsubscribe any time.")
    return subj, "\n".join(lines), html


def recipients(month):
    """Active members (free included) who haven't had this month's email. Test, disabled and opted-out accounts are left out."""
    _init()
    from . import unsub
    done = {r["email"] for r in db.q("SELECT email FROM newsletter_sent WHERE month = ?", (month,))}
    out = []
    for r in db.q("SELECT id, email, name FROM user WHERE coalesce(status, 'active') = 'active' AND email NOT LIKE '%@example.com' ORDER BY id"):
        e = (r["email"] or "").lower()
        if e and e not in done and not unsub.is_out(e):
            out.append(dict(r))
    return out


def send_test(month, to_user):
    subj, text, html = compose(month, dict(to_user), amb=True)
    return mailer.send(to_user["email"], "[Test] " + subj, text, html, optional=True)


def _run(month):
    try:
        ambs = active_ambassadors()
        todo = recipients(month)
        _state.update(month=month, sent=0, total=len(todo))
        for u in todo:
            subj, text, html = compose(month, u, amb=u["id"] in ambs)
            try:
                if mailer.send(u["email"], subj, text, html, optional=True):
                    _state["sent"] += 1
                db.x("INSERT OR IGNORE INTO newsletter_sent (month, email, sent) VALUES (?, ?, ?)", (month, u["email"].lower(), db.now()))
            except Exception as e:
                log.warning("newsletter to %s failed: %s", u["email"], e)
            time.sleep(SEND_GAP_SECONDS)
        db.audit("newsletter_sent", f"{month}: {_state['sent']} of {_state['total']}", None, "system")
    finally:
        _state["running"] = False


def send_all(month):
    """Start sending the month's email in the background. Returns a status line."""
    if not mailer.configured():
        return "Email isn't set up (Admin > Settings > Email), so nothing was sent."
    with _lock:
        if _state["running"]:
            return f"Already sending the {_state['month']} email ({_state['sent']} of {_state['total']} so far)."
        n = len(recipients(month))
        if not n:
            return "Everyone has already had this month's email."
        _state["running"] = True
    threading.Thread(target=_run, args=(month,), daemon=True).start()
    return f"Sending to {n} member{'s' if n != 1 else ''}, a few seconds apart. Refresh to see progress."


def status(month):
    _init()
    sent = (db.q("SELECT count(*) n FROM newsletter_sent WHERE month = ?", (month,), one=True) or {"n": 0})["n"]
    return {"auto": auto_on(), "running": _state["running"], "progress": dict(_state), "sent": sent,
            "waiting": len(recipients(month)), "configured": mailer.configured()}


def after_report(month):
    """Called by promo.generate when the month's report is published: sends the email when automatic sending is on."""
    from . import promo
    if auto_on() and promo._production():
        log.info(send_all(month))


def newsletter_edition(month):
    """(title, body) of the month's report as a LinkedIn newsletter edition, for "Copy as LinkedIn newsletter" in Admin >
    Social posts. Plain text with headings on their own lines (LinkedIn's editor keeps line breaks; set headings with its
    style menu), links written out in full with ?ref=linkedin-newsletter so the visits count under LinkedIn."""
    import re

    from . import promo
    site = db.settings().get("site_name", "Consist")
    page = db.q("SELECT title, description, body FROM page WHERE slug = ?", (promo.slug_for(month),), one=True)
    if not page:
        return "", ""
    ref = "ref=linkedin-newsletter"

    def absolute(u):
        u = u if u.startswith("http") else config.SITE_URL + u
        return u + ("&" if "?" in u else "?") + ref

    out = []
    for line in (page["body"] or "").splitlines():
        line = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: f"{m.group(1)} ({absolute(m.group(2))})", line)
        line = re.sub(r"\*\*([^*]+)\*\*", r"\1", line)
        line = re.sub(r"^#{1,6}\s*", "", line)
        line = re.sub(r"^- ", "• ", line)
        out.append(line)
    report = absolute(f"/p/{promo.slug_for(month)}")
    body = "\n".join(out).strip() + (f"\n\nRead the report with every fleet linked: {report}\n\n"
                                     f"Get these numbers in your inbox each month with a free {site} account: {absolute('/signup')}")
    return page["title"], body


def pitch(month):
    """(subject, body) for the monthly trade press pitch."""
    from . import promo
    site = db.settings().get("site_name", "Consist")
    label = promo._label(month)
    h = headlines(month)
    link = _report_url(month, "press")
    subj = f"Data for a story: {h[0][0]} {h[0][1].rstrip('.')}" if h else f"{site} rail fleet report, {label}"
    body = ["Hello [first name],", "",
            f"{site} tracks every US and Canadian passenger rail fleet and the rail bids agencies post. "
            f"Our {label} numbers have a few figures your readers may find useful:", ""]
    body += [f"- {n} {t}" for n, t in h]
    body += ["", f"The report, with the fleets behind each number and our method, is here: {link}",
             "You're welcome to quote any of it with a link. I can pull a breakdown by agency, builder or region for a story, "
             "and our charts can be embedded free from the data pages.", "", "Best regards,", "[your name]", site, config.SITE_URL]
    return subj, "\n".join(body)
