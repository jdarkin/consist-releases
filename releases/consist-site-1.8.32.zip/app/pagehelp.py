"""Help for each page (1.8.30, Justin 11-28): the "Help with this page" button on every app page.

PAGES maps a menu link to (lesson slug, step number or 0, purpose, terms). The purpose is one or two short sentences in
Simplified Technical English (ASD-STE100 style: short sentences, active voice, simple words). The terms are glossary keys
(app/glossary.py). The button shows the purpose and the terms with their definitions, and links to the lesson step.
Every page on the app menu must have a row here: tests/test_page_help.py fails the build when one is missing."""
from . import glossary

PAGES = {
    "/app": ("start", 3, "This page shows what changed since your last visit. Click a number or a chart to see the list behind it.",
             ["Relevance", "Watchlist"]),
    "/app/learn": ("start", 1, "Short lessons for each part of the site. Start with Start here. Each lesson takes 3 to 5 minutes.",
                   []),
    "/app/my-agency": ("market", 0, "Compare your agency with peer agencies of the same size and mode.", ["Peer group", "NTD"]),
    "/app/bids": ("bids", 1, "Open bids and RFPs from public rail and transit buyers in the US and Canada. Each bid has a relevance score from 0 to 100. Use the filters to find bids for what you sell.",
                  ["RFP", "Relevance", "Saved search"]),
    "/app/early-signals": ("bids", 7, "Signs that a buyer will issue a bid soon, such as a board vote or a new budget line. Use them to start sales work before the RFP.",
                           ["Early signals", "Relevance"]),
    "/app/work": ("start", 2, "Work that comes before a bid: fleets near the end of their useful life, overhauls that are due, and orders in the pipeline.",
                  ["Upcoming work", "Useful life", "Mid-life overhaul"]),
    "/app/supplier-windows": ("market", 5, "The years when a fleet can change the supplier of a subsystem, for example at an overhaul or a contract end.",
                              ["Supplier change windows", "Subsystem", "Window timeline"]),
    "/app/projects": ("bd-toolkit", 1, "Large rail and transit capital programs, with owner, cost, funding and dates.",
                      ["Megaprojects", "Project timeline (Gantt)"]),
    "/app/awards": ("market", 0, "Contracts that buyers gave to suppliers, and the grants that pay for future work.", ["Award", "Award share"]),
    "/app/funding-programs": ("bids", 10, "Federal and state grant programs and the agencies that won money from them.", ["Grant"]),
    "/app/capital-pipeline": ("bids", 6, "Capital projects and on-call contracts. An on-call contract that ends soon is a chance to bid.", ["On-call contract"]),
    "/app/past-rfps": ("bids", 5, "Closed bids from past years. Use them to see what a buyer asked for and who won.", ["RFP"]),
    "/app/drivers": ("market", 0, "Funding programs and rules that cause buyers to spend money.", []),
    "/app/coverage": ("bids", 8, "The buyers that Consist checks for bids, and how often.", ["Agency coverage"]),
    "/app/operators": ("operators", 1, "Every passenger and transit operator. Open an operator to see its fleets, bids, awards and board meetings.",
                       ["Operator", "NTD"]),
    "/app/fleets": ("fleets", 1, "Every passenger and transit fleet: builder, build year, number of units, and when it is due for overhaul or replacement.",
                    ["Fleet", "Useful life", "Mid-life overhaul"]),
    "/app/subsystems": ("market", 6, "The main systems on each fleet (brakes, doors, HVAC, propulsion and more) and who supplies them.",
                        ["Subsystem"]),
    "/app/signal-profiles": ("market", 0, "Signal and train control systems for each operator.", ["PTC", "CBTC"]),
    "/app/builders": ("account", 9, "Car and locomotive builders and the models they make.", ["Built by"]),
    "/app/safety": ("market", 0, "Safety event rates for each operator, from public reports.", ["NTD"]),
    "/app/platforms": ("market", 6, "Which suppliers are on each vehicle platform.", ["Subsystem"]),
    "/app/reliability": ("market", 0, "How far fleets go between failures, compared with similar fleets.", ["MDBF"]),
    "/app/market-sizing": ("bd-toolkit", 3, "How much buyers spend each year in each market segment. Tick the segments you sell into.",
                           ["TAM", "SAM", "SOM"]),
    "/app/explorer": ("explorer", 1, "One map and one table of fleets or suppliers. Use the filters, then click a dot or a row.",
                      ["Market map"]),
    "/app/market": ("market", 1, "Each supplier's share of the fleet, by subsystem and by vehicle type.", ["Market share", "Parent company"]),
    "/app/investors": ("market", 7, "Vehicle orders, options and the backlog of each builder.", ["Backlog", "Option exercise"]),
    "/app/market-note": ("market", 0, "A short summary of the market each quarter.", []),
    "/app/option-map": ("market", 9, "Options on current orders and joint buys between agencies.", ["Option exercise"]),
    "/app/lessors": ("market", 0, "Who owns and leases the fleets.", []),
    "/app/costs": ("fleets", 5, "Maintenance and operating cost for each fleet. Some costs are reported and some are estimates.",
                   ["Cost per vehicle mile", "Operator average"]),
    "/app/estimator": ("market", 0, "An estimate of what a new vehicle order will cost.", []),
    "/app/escalation": ("market", 0, "How costs change over time, and forecasts of future cost.", ["Escalation"]),
    "/app/cost-indexes": ("market", 0, "Public price and fuel indexes that affect rail costs.", ["Escalation"]),
    "/app/my-agency/planner": ("market", 0, "Plan when to replace or overhaul your fleets, and what it will cost.", ["Useful life"]),
    "/app/agency-finance": ("market", 0, "Agency revenue, spend and funding, from public reports.", ["NTD"]),
    "/app/competitors": ("bd-toolkit", 4, "One page for each competitor: what they won, where, and their share.", ["Award share"]),
    "/app/supplier-intel": ("market", 11, "Supplier finances and a grade (A to D) that tells you how good each figure is.", ["Grade"]),
    "/app/suppliers": ("market", 6, "A directory of rail suppliers and what they make.", []),
    "/app/delivery-record": ("market", 0, "How builders delivered past orders: on time or late.", []),
    "/app/consultants": ("market", 0, "Engineering consultants that agencies use, and their contracts.", []),
    "/app/tier1": ("market", 6, "Large suppliers of subsystems to car builders.", ["Subsystem"]),
    "/app/watchlist": ("operators", 3, "The operators, fleets and bids you follow. Changes to them show on your dashboard.", ["Watchlist"]),
    "/app/pursuits": ("bd-toolkit", 6, "Your own list of deals, with stage and win chance.", ["Pursuit", "Weighted pipeline"]),
    "/app/lists": ("operators", 3, "Lists of accounts that you make and share.", []),
    "/app/alerts": ("account", 3, "Email alerts for new bids and fleet changes. Choose what to get and when.", ["Saved search", "Territory digest"]),
    "/app/analyst": ("analyst", 1, "Ask a question in plain words. The analyst answers from Consist data and shows its sources.", ["Confidence"]),
    "/app/start": ("start", 1, "A guide to each part of the site and what your plan includes.", []),
    "/app/account": ("account", 2, "Your plan, market, territory, time zone and email settings.", ["Territory"]),
    "/app/api-keys": ("account", 0, "Keys that let your own software read Consist data.", []),
}

# Basic words a new member may not know. They join the glossary (app/glossary.py) at import time unless already there.
PLAIN = {
    "NTD": "National Transit Database. The US government (FTA) collects data from transit agencies each year: fleets, miles, costs and safety. Consist uses it for most US transit figures.",
    "RFP": "Request for proposals. A buyer publishes it when it wants suppliers to offer a price and a plan for some work. Consist uses \"bid\" for RFPs, RFQs, IFBs and similar notices.",
    "Early signals": "Signs that a buyer will issue a bid soon, such as a board vote, a budget line or a grant award. They come before the RFP.",
    "Upcoming work": "Work that will come before it is bid: fleets near the end of their useful life, mid-life overhauls that are due, and orders in the pipeline.",
    "Mid-life overhaul": "A large repair program at about the middle of a fleet's life. Many subsystems are replaced. It is often a chance for a new supplier.",
    "Supplier change windows": "The years when a fleet can change the supplier of a subsystem, for example at an overhaul, a replacement or the end of a contract.",
    "Watchlist": "The operators, fleets and bids you follow. Changes to them show on your dashboard and in your emails.",
    "Pursuit": "A deal that you work on, with a stage (Identify to Submitted) and a win chance.",
    "Saved search": "A set of filters that you save. Consist emails you new matches daily, weekly or at once, as you choose.",
    "Peer group": "Agencies that are like yours in size and mode. Consist compares you with them.",
    "Agency coverage": "The buyers that Consist checks for bids, how often, and when it last found a notice.",
    "Grant": "Money from a government program to an agency for a project. A grant often comes before a bid.",
    "On-call contract": "A contract that lets an agency call a supplier for work as needed for some years. When it ends, the agency usually bids it again.",
    "PTC": "Positive train control. A system that stops a train automatically to prevent some accidents. US law requires it on many lines.",
    "CBTC": "Communications-based train control. A signal system that uses radio to find each train. Many metros use it.",
    "MDBF": "Mean distance between failures. The average miles a fleet goes before a failure. A higher number is better.",
    "Backlog": "Vehicles that are on order but not yet delivered.",
    "Option exercise": "When a buyer uses an option in a current contract to order more vehicles from the same builder, without a new bid.",
    "Escalation": "The increase in cost over time because prices for labor, materials and fuel go up.",
    "Cost per vehicle mile": "The cost to operate or maintain a fleet divided by the miles the vehicles go.",
    "Market share": "A supplier's part of all the vehicles or subsystems in the market you look at, as a percentage.",
    "Fleet": "A group of vehicles of the same model and build at one operator.",
    "Operator": "An agency or company that runs trains or transit service.",
    "Help with this page": "The button at the top of each app page. It tells you what the page is for, explains its terms and opens the lesson for it.",
    "Terms A to Z": "A list of all the terms on Consist with plain definitions. Open it from Training or from Help with this page.",
}

for _k, _v in PLAIN.items():
    glossary.TERMS.setdefault(_k, _v)
    glossary._LOWER.setdefault(_k.lower(), glossary.TERMS[_k])


def for_path(path):
    """The help row for a page: the longest menu link that the path starts with."""
    best = None
    for href in PAGES:
        if path == href or (href != "/app" and path.startswith(href + "/")):
            if best is None or len(href) > len(best):
                best = href
    if best is None:
        return None
    slug, step, purpose, terms = PAGES[best]
    defs = [(t, glossary._LOWER.get(t.lower(), "")) for t in terms]
    link = f"/app/learn/{slug}" + (f"#step-{step}" if step else "")
    return {"purpose": purpose, "terms": [d for d in defs if d[1]], "lesson": link, "href": best}


def all_terms():
    """Every glossary term, sorted A to Z, for /app/learn/terms."""
    return sorted(glossary.TERMS.items(), key=lambda kv: kv[0].lower())
