"""First-day checklist (1.8.31, Justin 11-28): one onboarding path for new members.

Five tasks, each checked from what the member already did (no extra clicks to tick). It shows on the dashboard and on
Training until all five are done or the member hides it (user_pref firstday_off). Text is Simplified Technical English."""
from . import db, intel, learn

TASKS = [
    ("market", "Choose your market and region", "Use the bar at the top of each page. All lists and charts follow it.", "/app/account#market"),
    ("follow", "Follow 3 operators", "Open an operator and click Follow. Changes to them show on your dashboard.", "/app/operators"),
    ("alert", "Save one bid alert", "Set filters on Bids, then save them. We email you new bids that match.", "/app/alerts"),
    ("territory", "Set your sales territory", "Choose the states, provinces and agencies you cover.", "/app/account#territory"),
    ("lesson", "Do the Start here lesson", "It takes 5 minutes and shows the main parts of the site.", "/app/learn/start"),
]


def status(u):
    """List of (key, title, text, link, done) and the number done."""
    done = {
        "market": bool(intel.pref(u, "lens") or intel.pref(u, "regions") or intel.pref(u, "trades")),
        "follow": (db.q("SELECT COUNT(*) n FROM watch WHERE user_id = ? AND kind IN ('operator','op','agency')", (u["id"],), one=True) or {"n": 0})["n"] >= 3,
        "alert": bool(db.q("SELECT 1 FROM saved_search WHERE user_id = ? LIMIT 1", (u["id"],), one=True)),
        "territory": bool(intel.pref(u, "ter_states") or intel.pref(u, "ter_ags") or intel.pref(u, "ter_ops")),
        "lesson": "start" in learn.done_set(u),
    }
    rows = [dict(key=k, title=t, text=x, href=h, done=done[k]) for k, t, x, h in TASKS]
    return rows, sum(r["done"] for r in rows)


def visible(u):
    if intel.pref(u, "firstday_off"):
        return None
    rows, n = status(u)
    if n == len(rows):
        return None
    return {"rows": rows, "n": n, "total": len(rows)}
