"""1.8.30: every page on the app menu has a Help row (app/pagehelp.py) with a real lesson step and real glossary terms.
Run: python tests/test_page_help.py. When you add a menu page, add a PAGES row and, if needed, a lesson step (learn.py)."""
import pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
def problems():
    from app import pagehelp, learn, glossary
    shell = (ROOT / "app/templates/app/shell.html").read_text()
    hrefs = set(re.findall(r"nav\('(/app[^']*)'", shell))
    bad = [f"menu page {h} has no row in app/pagehelp.py PAGES" for h in sorted(hrefs - set(pagehelp.PAGES))]
    for h, (slug, step, purpose, terms) in pagehelp.PAGES.items():
        m = learn.BY_SLUG.get(slug)
        if not m: bad.append(f"{h}: lesson '{slug}' does not exist"); continue
        if step > len(m["steps"]): bad.append(f"{h}: lesson '{slug}' has no step {step}")
        if not purpose.strip(): bad.append(f"{h}: no purpose text")
        for t in terms:
            if t.lower() not in glossary._LOWER: bad.append(f"{h}: term '{t}' is not in the glossary")
    return bad
def test_page_help():
    b = problems(); assert not b, "\n".join(b)
if __name__ == "__main__":
    b = problems(); print("\n".join(b) or "OK: every menu page has help"); sys.exit(1 if b else 0)
