"""Unit checks for app/scrapeguard.py: python3 tests/test_scrapeguard.py (needs no running site)."""
import os
import sys
import types

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.modules.setdefault("app.db", types.SimpleNamespace(settings=lambda: {}, now=lambda: "2026-11-28T00:00:00+00:00"))
import app  # noqa: E402,F401
from app import scrapeguard as g  # noqa: E402

assert g.net_of("203.0.113.77") == "203.0.113.0/24"
assert g.net_of("2001:db8:abcd:12::1") == "2001:db8:abcd::/48"
assert g.net_of("::ffff:198.51.100.9") == "198.51.100.0/24"
assert g.kind("Mozilla/5.0 (compatible; GPTBot/1.2)") == "ai"
assert g.kind("python-requests/2.31") == "tool"
assert g.kind("Mozilla/5.0 (Windows NT 10.0) Chrome/120 Safari/537") == "browser"
assert g.short_ua("Mozilla/5.0 (Windows NT 10.0) AppleWebKit Chrome/120.0 Safari/537.36") == "Chrome Windows"
g._cfg.update(t=1e18, s=dict(g.DEFAULTS))
t0 = 1000.0
assert all(g.check("1.2.3.4", t0 + i * 0.5) == 0 for i in range(30))
w = g.check("1.2.3.4", t0 + 15.5)
assert 40 <= w <= 61, w
assert g.check("1.2.3.4", t0 + 61) == 0  # window slid
assert g.check("5.6.7.8", t0) == 0  # other visitors unaffected
r = g.robots_ai()
assert "User-agent: GPTBot" in r and "User-agent: CCBot" in r and "Googlebot" not in r and "bingbot" not in r
print("scrapeguard ok")
