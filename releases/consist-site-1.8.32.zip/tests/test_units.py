"""1.8.26 (Justin 11-26): locomotives are counted as locomotives, never as cars."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import locomodel, units  # noqa: E402


def test_go_transit_mp_locos_are_locomotives():
    f = {"vehicle_class": "coach", "model_name": "MP40PH-3C / MP54AC", "qty_active": 90}
    assert units.count(f) == "90 locomotives"
    assert locomodel.fix("coach", "MP54AC") == "locomotive"


def test_singular_and_types():
    assert units.count({"vehicle_class": "locomotive", "model_name": "F59PHI", "qty_active": 1}) == "1 locomotive"
    assert units.count({"vehicle_class": "coach", "model_name": "BiLevel", "qty_active": 1}) == "1 coach"
    assert units.count({"vehicle_class": "emu", "model_name": "M8", "qty_active": 405}) == "405 EMU cars"
    assert units.count({"vehicle_class": "lrv", "model_name": "SD160", "qty_active": 2}) == "2 light rail vehicles"


def test_mixed_fleet():
    fl = [{"vehicle_class": "locomotive", "model_name": "MP40PH-3C", "qty_active": 57},
          {"vehicle_class": "coach", "model_name": "BiLevel", "qty_active": 900},
          {"vehicle_class": "cab_car", "model_name": "BiLevel cab car", "qty_active": 1}]
    assert units.mix(fl) == "900 coaches, 57 locomotives and 1 cab car"


def test_no_false_locomotives():
    for m in ("SD160", "SD100", "S70 (SD8/SD9/SD100)", "Charger cab car", "Kawasaki M8", "Siemens Venture", "Bi-Level coach"):
        assert locomodel.fix("lrv", m) == "lrv", m


def test_change_lines_reworded():
    f = {"vehicle_class": "locomotive", "model_name": "MP54AC"}
    assert units.fix_detail("Active cars: 88 → 90", f) == "Active locomotives: 88 → 90"
    assert units.fix_detail("New fleet: Wabtec MP54AC, 16 cars", f) == "New fleet: Wabtec MP54AC, 16 locomotives"
