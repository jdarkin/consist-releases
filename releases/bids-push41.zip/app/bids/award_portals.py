"""Where each agency posts its bids, awards and closed solicitations (Justin 11-18: "look on every procurement portal for
notice of award ... go back as far as the agency's portal will let you").

Table agency_link: one row per (agency, url) with kind bids | awards | closed | tabulations, where it came from
(portal = portals.csv, curated = award_pages.csv shipped with Bid Catcher, discovered = found by discover()), and
whether page watch reads it. The Consist site shows these links on operator and agency pages.

discover(): reads each agency's bidding page (and its other watched pages) with the normal robots.txt rules and keeps
the links whose words say award, notice of award, bid results, tabulation, closed / past / archived solicitations.
No Claude calls. Batches of agencies per daily run until every agency has been checked, then again every 60 days.

Award pages found this way are read by the daily page watch as kind 'awards' (sources.watch_urls). Their first read
is history (never alerted). backfill() then follows each award page's older pages (next-page links, earlier years,
yearly award PDFs) once, as far back as the portal shows, within its own daily dollar cap (config award_backfill_usd,
default 1.0), also as history.
"""
import csv
import datetime
import html
import os
import re
import time
import urllib.parse

import bidcore as bc
import sources

KINDS = ("awards", "closed", "tabulations")
HERE = os.path.dirname(os.path.abspath(__file__))

POS = re.compile(r"\b(notice of (intent to )?award|intent to award|(contract|bid|solicitation|procurement|rfp)s? awards?|awarded (contracts?|bids?|solicitations?)|"
                 r"awards?\b|bid results?|solicitation results?|bid tab(ulation)?s?|tabulations?|"
                 r"(closed|past|previous|expired|archived?|completed|historical|inactive) (bids?|solicitations?|opportunities|procurements?|rfps?|ifbs?|contracts?)|"
                 r"(bid|solicitation|procurement|contract)s? archives?)", re.I)
NEG = re.compile(r"employee|safety|ceremon|banquet|program award|grant|scholarship|recogni|honou?r|award[- ]winning|"
                 r"apta|media|press|news|dbe|small business|award fee|fta award|federal award|wins?\b|achievement|excellence|"
                 r"meeting|minutes|agenda|budget|annual report|careers?|jobs?|art\b|photo|video|accolade|archive cent|past projects?|hall of fame", re.I)
# hosts never crawled for award history: aggregators whose terms forbid scraping (BidNet: email alerts only, 11-16)
NO_CRAWL = ("bidnetdirect.com", "bidnet.com", "govspend.com", "bidprime.com", "findrfp.com", "rfpmart.com", "deltek.com")
HREF_POS = re.compile(r"award|closed|archive|past[-_]?(bid|solicit|opportun)|bid[-_]?result|tabulat|expired|completed[-_]?(bid|solicit)", re.I)
NEXT = re.compile(r"^\s*(next|next page|older|older entries|more|›|»|>|>>)\s*$", re.I)
YEARISH = re.compile(r"\b(19|20)\d\d\b")


def ensure(c):
    c.execute("""CREATE TABLE IF NOT EXISTS agency_link (
        agency_id TEXT NOT NULL, url TEXT NOT NULL, kind TEXT NOT NULL, label TEXT, source TEXT, watch INTEGER DEFAULT 1,
        score INTEGER, found TEXT, last_checked TEXT, backfilled TEXT, backfill_pages INTEGER, note TEXT,
        PRIMARY KEY (agency_id, url))""")
    c.execute("""CREATE TABLE IF NOT EXISTS agency_link_scan (agency_id TEXT PRIMARY KEY, checked TEXT, pages INTEGER,
        found INTEGER, error TEXT)""")


def kind_of(text, href=""):
    s = f"{text} {href}"
    if re.search(r"tabul|bid[-_ ]?results?|solicitation results?", s, re.I):
        return "tabulations"
    if re.search(r"award", s, re.I):
        return "awards"
    return "closed"


def is_pdf(u):
    return urllib.parse.urlparse(u).path.lower().endswith(".pdf")


def seed(c):
    """portals.csv bidding pages (kind bids) and the curated award pages shipped as award_pages.csv."""
    ensure(c)
    for r in c.execute("SELECT agency_id, portal_url, platform FROM agency WHERE portal_url LIKE 'http%'").fetchall():
        c.execute("INSERT INTO agency_link (agency_id, url, kind, label, source, watch, found) VALUES (?,?,?,?,?,0,?) "
                  "ON CONFLICT(agency_id, url) DO UPDATE SET kind=CASE WHEN agency_link.source='portal' THEN 'bids' ELSE agency_link.kind END",
                  (r["agency_id"], r["portal_url"], "bids", r["platform"] or "Bidding page", "portal", bc.now()))
    path = os.path.join(HERE, "award_pages.csv")
    if os.path.exists(path):
        for r in csv.DictReader(open(path, newline="", encoding="utf-8-sig")):
            aid, url = (r.get("agency_id") or "").strip(), (r.get("url") or "").strip()
            if not aid or not url.startswith("http"):
                continue
            kind = (r.get("kind") or "awards").strip()
            watch = 0 if is_pdf(url) or (r.get("watch") or "1").strip() == "0" else 1
            c.execute("INSERT INTO agency_link (agency_id, url, kind, label, source, watch, found, note) VALUES (?,?,?,?,?,?,?,?) "
                      "ON CONFLICT(agency_id, url) DO UPDATE SET kind=excluded.kind, label=excluded.label, source='curated', "
                      "watch=excluded.watch, note=excluded.note",
                      (aid, url, kind, (r.get("label") or "").strip() or None, "curated", watch, bc.now(), (r.get("note") or "").strip() or None))
    c.commit()


_A = re.compile(r"<a\b([^>]*)>(.*?)</a>", re.I | re.S)
_HREF = re.compile(r"""href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))""", re.I)


def links(raw_html, base):
    """(absolute url, link text, rel) for every <a href> on a page."""
    out = []
    for attrs, inner in _A.findall(raw_html):
        m = _HREF.search(attrs)
        if not m:
            continue
        href = html.unescape(next(g for g in m.groups() if g is not None)).strip()
        if not href or href.startswith(("#", "mailto:", "javascript:", "tel:")):
            continue
        text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", inner))).strip()
        if not text:
            t = re.search(r"""(?:title|aria-label)\s*=\s*["']([^"']+)""", attrs, re.I)
            text = t.group(1) if t else ""
        rel = (re.search(r"""rel\s*=\s*["']?([\w ]+)""", attrs, re.I) or [None, ""])[1]
        out.append((urllib.parse.urljoin(base, href).split("#")[0], text[:200], rel.lower()))
    return out


def _site(u):
    h = urllib.parse.urlparse(u).netloc.lower().split(":")[0]
    p = h.split(".")
    return ".".join(p[-3:]) if len(p) > 2 and len(p[-1]) == 2 and p[-2] in ("co", "gc", "on", "qc", "bc", "ab") else ".".join(p[-2:])


def score(text, href):
    if NEG.search(text):
        return 0
    s = 0
    if POS.search(text):
        s += 2
    if HREF_POS.search(href):
        s += 1
    if re.fullmatch(r"\s*awards?\s*", text or "", re.I) and not re.search(r"procure|purchas|bid|solicit|contract|vendor|supplier|business", href, re.I):
        return 0  # a bare "Awards" menu item outside procurement is usually the agency's honours page
    if len(text or "") > 60 and not re.search(r"closed|past|archiv|tabulat|results", text, re.I):
        return 0  # one notice, not a list of them
    return s


def _get(url):
    """Raw HTML (robots.txt honoured; JavaScript portals through the render service when configured)."""
    host = urllib.parse.urlparse(url).netloc.lower()
    if any(host == h or host.endswith("." + h) for h in sources.JS_HOSTS):
        if not bc.RENDER_URL:
            raise RuntimeError("JavaScript portal and no render service")
        h, final = bc.render(url)
        return h, final
    raw, cs, final = bc.fetch(url, timeout=40)
    return raw.decode(cs, "replace"), final


def discover(c, agencies=None, limit=40, days=60, pause=1.0, verbose=False):
    """Checks up to `limit` agencies not checked in `days` (or the given ones). Returns (agencies checked, links found)."""
    ensure(c)
    seed(c)
    cut = (datetime.datetime.utcnow() - datetime.timedelta(days=days)).isoformat()
    if agencies:
        todo = list(agencies)
    else:
        todo = [r[0] for r in c.execute(
            "SELECT a.agency_id FROM agency a LEFT JOIN agency_link_scan s ON s.agency_id=a.agency_id "
            "WHERE a.portal_url LIKE 'http%' AND (s.checked IS NULL OR s.checked < ?) ORDER BY s.checked IS NOT NULL, s.checked, a.agency_id LIMIT ?",
            (cut, limit))]
    total = 0
    for aid in todo:
        starts = [r[0] for r in c.execute("SELECT portal_url FROM agency WHERE agency_id=? AND portal_url LIKE 'http%'", (aid,))]
        starts += [r[0] for r in c.execute("SELECT url FROM page_watch WHERE agency_id=? AND kind='solicitations'", (aid,)) if r[0] not in starts]
        starts += [u for u, a, k in sources.EXTRA_PAGES if a == aid and u not in starts]
        seen, found, pages, err = set(starts), {}, 0, None
        queue = [(u, 0) for u in starts[:6] if not _blocked(u)]
        while queue and pages < 10:
            url, depth = queue.pop(0)
            try:
                page, final = _get(url)
            except Exception as e:
                err = f"{url}: {e}"[:300]
                continue
            pages += 1
            time.sleep(pause)
            more = []
            for u, text, rel in links(page, final):
                if _blocked(u):
                    continue
                if is_pdf(u) and not YEARISH.search(text + u):
                    continue
                if _site(u) != _site(final) and not any(h in u for h in sources.JS_HOSTS):
                    continue
                s = score(text, u)
                if s >= 2 and u not in found:
                    found[u] = (kind_of(text, u), text, s)
                elif depth == 0 and u not in seen and re.search(r"\b(procurements?|purchasing|bids?( and| &amp;| &) (rfps?|proposals|contracts)|bid opportunities|solicitations|doing business|contracting|vendors?|suppliers?)\b", text, re.I) \
                        and not NEG.search(text):
                    more.append(u)
            if depth == 0 and not found:
                for u in more[:3]:
                    seen.add(u)
                    queue.append((u, 1))
        for u, (kind, text, s) in found.items():
            c.execute("INSERT INTO agency_link (agency_id, url, kind, label, source, watch, score, found) VALUES (?,?,?,?,?,?,?,?) "
                      "ON CONFLICT(agency_id, url) DO UPDATE SET score=excluded.score",
                      (aid, u, kind, text or None, "discovered", 0 if is_pdf(u) else 1, s, bc.now()))
        c.execute("INSERT INTO agency_link_scan (agency_id, checked, pages, found, error) VALUES (?,?,?,?,?) "
                  "ON CONFLICT(agency_id) DO UPDATE SET checked=excluded.checked, pages=excluded.pages, found=excluded.found, error=excluded.error",
                  (aid, bc.now(), pages, len(found), err if not pages else None))
        c.commit()
        total += len(found)
        if verbose:
            print(f"{aid}: {pages} pages read, {len(found)} award links" + (f" ({err})" if err and not pages else ""))
            for u, (kind, text, s) in found.items():
                print(f"   {kind:12} {text[:50]!r:52} {u}")
    return len(todo), total


def watched(c):
    """(url, agency_id, country) of award pages for the daily page watch."""
    ensure(c)
    return [(r[0], r[1], r[2] or "US") for r in c.execute(
        "SELECT l.url, l.agency_id, a.country FROM agency_link l LEFT JOIN agency a ON a.agency_id=l.agency_id "
        "WHERE l.kind IN ('awards','closed','tabulations') AND l.watch=1 AND l.url LIKE 'http%'")]


def _older_pages(page, final, limit):
    """Next-page links and earlier-year pages or PDFs linked from an award page, oldest last, at most `limit`."""
    out = []
    for u, text, rel in links(page, final):
        if u == final or _site(u) != _site(final):
            continue
        if "next" in rel or NEXT.match(text) or (re.fullmatch(r"\d{1,3}", text) and re.search(r"[?&/](page|p|paged|pg|start|offset)[=/]?\d", u, re.I)):
            out.append(u)
        elif YEARISH.search(text) and (POS.search(text) or HREF_POS.search(u)) and not NEG.search(text):
            out.append(u)
    seen, res = set(), []
    for u in out:
        if u not in seen:
            seen.add(u)
            res.append(u)
    return res[:limit]


def _text(url):
    """(text, final url, how) of a page or PDF, read locally: pypdf for PDFs (no OCR in the image: a scanned PDF
    comes back with almost no text and is queued as 'scanned')."""
    if is_pdf(url):
        raw, cs, final = bc.fetch(url, timeout=90)
        try:
            import io, pypdf
            return "\n".join((p.extract_text() or "") for p in pypdf.PdfReader(io.BytesIO(raw)).pages[:200])[:400000], final, "pdf"
        except Exception as e:
            raise RuntimeError(f"PDF not readable: {e}")
    text, final = sources.read_page(url)
    return text, final, "html"


# ---- free reading: rules first, everything else waits in award_doc for review (Justin 11-18: no API spend) ----

MONEY = re.compile(r"(?:US\s?|CA|C)?\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?|\d{4,}(?:\.\d{2})?)")
COMPANY = re.compile(r"\b([A-Z0-9][A-Za-z0-9&.,'’\-/ ]{1,70}?\s(?:Inc|Incorporated|LLC|L\.L\.C|Corp|Corporation|Company|Co|Ltd|Limited|LP|LLP|PLLC|PC|"
                     r"JV|Joint Venture|Group|Associates|Services|Systems|Technologies|Constructors|Construction|Contractors|Engineering|"
                     r"Ltée|Ltee|Inc\.?|Enterprises|Industries|Solutions|Partners|Builders|Electric|Mobility|Transit|Rail)\b\.?)")
DATE = re.compile(r"\b(\d{1,2}/\d{1,2}/(?:19|20)?\d\d|(?:19|20)\d\d-\d{2}-\d{2}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2},?\s+(?:19|20)\d\d)\b")
REF = re.compile(r"\b((?:RFP|IFB|ITB|RFQ|RFB|BID|CONTRACT|SOLICITATION|NO\.?)\s*#?\s*[A-Z0-9][A-Z0-9\-./]{2,20}|[A-Z]{1,6}-?\d{2,}[-A-Z0-9]*)\b", re.I)
NOT_VENDOR = re.compile(r"^(total|amount|award|contract|vendor|contractor|description|title|date|project|estimate|budget|engineer)", re.I)


_SUFFIX = re.compile(r"^(Inc|Incorporated|LLC|L\.L\.C|Corp|Corporation|Co|Ltd|Limited|LP|LLP|PLLC|PC|JV|Ltée|Ltee)\.?$", re.I)


def _vendor_tail(s):
    """The company name at the end of a matched run: 'Q24-118 Escalator parts supply, Kone Inc.' -> 'Kone Inc'."""
    parts = [p.strip(" ,.;|") for p in re.split(r"\s[-–|]\s|,\s|;\s|\t|\s{2,}", s) if p.strip(" ,.;|")]
    if not parts:
        return s.strip(" ,.;|")
    v = parts[-1]
    if _SUFFIX.match(v) and len(parts) > 1:
        v = parts[-2] + ", " + v
    return v


def _iso(d):
    try:
        return sources.iso(d)
    except Exception:
        return None


def parse_awards(text):
    """Award rows a plain list or table shows: a line (or a table row split over a few lines) with a company name and a
    dollar amount. Title = the longest other text nearby. Returns dicts in store_items shape (kind 'award'). Conservative:
    anything ambiguous is left for review."""
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    out, used = [], set()
    for i, line in enumerate(lines):
        if i in used or not MONEY.search(line):
            continue
        lo = i
        while lo > 0 and i - lo < 4 and lo - 1 not in used and not MONEY.search(lines[lo - 1]):
            lo -= 1
        window = lines[lo:i + 1]
        blob = " | ".join(window)
        vend = None
        for w in window:
            m = COMPANY.search(w)
            if m and not NOT_VENDOR.match(m.group(1)):
                vend = _vendor_tail(m.group(1))
                break
        if not vend:
            continue
        amt = float(MONEY.search(line).group(1).replace(",", ""))
        if amt < 1000:
            continue
        others = [w for w in window if vend not in w and not MONEY.fullmatch(w.strip()) and not DATE.fullmatch(w.strip()) and len(w) > 8]
        title = max(others, key=len) if others else ""
        if not title:  # one-line row: what is left of it once vendor, amount, date and reference are taken out
            title = line.replace(vend, " ")
            r0 = REF.search(blob)
            if r0:
                title = title.replace(r0.group(1), " ")
        title = re.sub(r"\s+", " ", MONEY.sub("", DATE.sub("", title)))
        title = re.sub(r"(\s*[,.;:|]\s*)+$", "", re.sub(r"\s*([,;])(\s*[,.;])+", r"\1", title)).strip(" -|,;:")
        if len(title) < 6:
            continue
        d = DATE.search(blob)
        r = REF.search(blob)
        out.append({"kind": "award", "ref_no": (r.group(1).strip() if r else ""), "title": title[:300], "description": "",
                    "closing": "", "url": "", "vendor": vend[:200], "amount": amt, "award_date": (_iso(d.group(1)) if d else "") or "",
                    "bidders": []})
        used.update(range(lo, i + 1))
    return out


def ensure_queue(c):
    c.execute("""CREATE TABLE IF NOT EXISTS award_doc (id INTEGER PRIMARY KEY, agency_id TEXT, url TEXT UNIQUE, how TEXT,
        text TEXT, chars INTEGER, parsed INTEGER, stored INTEGER, status TEXT, added TEXT, reviewed TEXT, note TEXT)""")


# ---- the Pi reader (pi-reader thread, Justin 11-18): a local model on the Raspberry Pi reads documents the rules
# could not, for free. Jobs are files in /data/pi-jobs/inbox; results come back in /data/pi-jobs/outbox. Off until
# the folder exists (vps-pijobs-setup.sh makes it). Results are suggestions from a small model: stored as confidence D.

PIJOBS = os.environ.get("BIDS_PI_JOBS", os.path.join(getattr(bc, "DATA", "/data"), "pi-jobs"))
PI_CHUNK = 11000


def pi_on():
    return os.path.isdir(os.path.join(PIJOBS, "inbox"))


def pi_submit(c, doc_id, text, max_chunks=4):
    """Writes the document as Pi jobs (one per ~11k characters, at most max_chunks). Returns jobs written."""
    if not pi_on() or len(text.strip()) < 300:
        return 0
    lines, chunks, cur = text.split("\n"), [], ""
    for l in lines:
        if len(cur) + len(l) + 1 > PI_CHUNK and cur:
            chunks.append(cur)
            cur = ""
        cur += l + "\n"
    if cur.strip():
        chunks.append(cur)
    import json
    n = 0
    for i, ch in enumerate(chunks[:max_chunks]):
        jid = f"awdoc-{doc_id}-{i}"
        tmp = os.path.join(PIJOBS, "inbox", f".{jid}.tmp")
        with open(tmp, "w") as f:
            json.dump({"id": jid, "kind": "award", "text": ch}, f)
        os.chmod(tmp, 0o664)
        os.replace(tmp, os.path.join(PIJOBS, "inbox", f"{jid}.json"))
        n += 1
    c.execute("UPDATE award_doc SET status='pi', note=coalesce(note,'') || ? WHERE id=?", (f" pi jobs {n};", doc_id))
    c.commit()
    return n


def pi_consume(c, min_conf=0.6):
    """Reads Pi results: an awardee with an amount becomes an award (confidence D, source 'pi', history); everything is
    noted on the document. Returns (results read, awards added)."""
    import glob, json
    if not os.path.isdir(os.path.join(PIJOBS, "outbox")):
        return 0, 0
    ensure_queue(c)
    suppliers = sources.supplier_ids()
    read = added = 0
    old = sources.HISTORY
    sources.HISTORY = True
    try:
        for p in sorted(glob.glob(os.path.join(PIJOBS, "outbox", "*.json"))):
            try:
                res = json.load(open(p))
            except Exception:
                continue
            read += 1
            m = re.match(r"awdoc-(\d+)-(\d+)$", str(res.get("id") or ""))
            doc = c.execute("SELECT * FROM award_doc WHERE id=?", (int(m.group(1)),)).fetchone() if m else None
            f = res.get("fields") or {}
            note = (f" pi {m.group(2) if m else '?'}: " + (f"error {res.get('error')}" if not res.get("ok") else
                    f"{f.get('awardee')} {f.get('amount')} conf {f.get('confidence')}"))[:300] + ";"
            try:
                conf = float(f.get("confidence") or 0)
            except (TypeError, ValueError):
                conf = 0.0
            if doc and res.get("ok") and f.get("awardee") and f.get("amount") and conf >= min_conf:
                try:
                    amt = float(str(f["amount"]).replace(",", "").replace("$", ""))
                except ValueError:
                    amt = None
                item = {"kind": "award", "ref_no": str(f.get("solicitation") or "")[:60], "title": str(f.get("title") or f.get("solicitation") or "Award")[:300],
                        "description": "", "closing": "", "url": "", "vendor": str(f["awardee"])[:200], "amount": amt,
                        "award_date": _iso(str(f.get("award_date") or "")) or "",
                        "bidders": [{"name": str(b.get("name")), "amount": b.get("amount") or 0} for b in (f.get("bidders") or []) if isinstance(b, dict) and b.get("name")]}
                ctry = (c.execute("SELECT country FROM agency WHERE agency_id=?", (doc["agency_id"],)).fetchone() or ["US"])[0] or "US"
                n = sources.store_items(c, [item], doc["agency_id"], ctry, doc["url"], "pi", suppliers)
                c.execute("UPDATE award SET confidence='D' WHERE source='pi' AND confidence='A'")
                added += 1 if n else 0
            if doc:
                c.execute("UPDATE award_doc SET note=coalesce(note,'') || ? WHERE id=?", (note, doc["id"]))
            c.commit()
            os.remove(p)
    finally:
        sources.HISTORY = old
    return read, added


# ---- drill-down (Justin 11-18: "make sure the reader drills into the individual bid awards, or at least to a table
# level where the data can tie an award back to an RFP"). A listing page is never itself an award document: its tables
# give one award per row, and its links to single solicitations, award notices and tabulation PDFs are followed and
# read one by one. Only those single documents go to the review queue and, when the rules miss, to the Pi.

def _blocked(u):
    h = urllib.parse.urlparse(u).netloc.lower().split(":")[0]
    return any(h == b or h.endswith("." + b) for b in NO_CRAWL)


import html.parser as _hp


class _TableParser(_hp.HTMLParser):
    """Every <table> as rows of cells: (text, first href, is header cell)."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self._stack, self._cell, self._href, self._th, self._skip = [], [], None, None, False, 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1
        elif tag == "table":
            self._stack.append([])
        elif tag == "tr" and self._stack:
            self._stack[-1].append([])
        elif tag in ("td", "th") and self._stack:
            if not self._stack[-1]:
                self._stack[-1].append([])
            self._cell, self._href, self._th = [], None, tag == "th"
        elif tag == "a" and self._cell is not None and self._href is None:
            self._href = dict(attrs).get("href")
        elif tag == "br" and self._cell is not None:
            self._cell.append(" ")

    def _close_cell(self):
        if self._cell is not None and self._stack and self._stack[-1]:
            self._stack[-1][-1].append((re.sub(r"\s+", " ", "".join(self._cell)).strip(), self._href, self._th))
        self._cell = None

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._skip = max(0, self._skip - 1)
        elif tag in ("td", "th"):
            self._close_cell()
        elif tag == "table" and self._stack:
            self._close_cell()
            t = [r for r in self._stack.pop() if r]
            if t:
                self.tables.append(t)

    def handle_data(self, d):
        if self._cell is not None and not self._skip:
            self._cell.append(d)


COLS = [("vendor", r"award(ed)? to|awardee|successful|vendor|contractor|supplier|firm|company|recommended|selected|winning|award(ed)? (vendor|firm|bidder|contractor)"),
        ("amount", r"amount|value|price|total|award \$|\$|cost|sum"),
        ("date", r"award(ed)? date|date awarded|date of award|award$|^date|effective|executed|approved"),
        ("ref", r"(solicitation|bid|rfp|ifb|itb|rfq|contract|project|reference|tender|po|agreement|procurement)\s*(no\.?|number|#|id)|^no\.?$|^number$|^#$|^ref"),
        ("title", r"title|description|subject|scope|project|solicitation|name|commodity|service")]
NOT_NAME = re.compile(r"^(n/?a|none|tbd|tba|pending|cancel+ed|cancel+ation|no award|not awarded|rejected|re-?bid|withdrawn|under review|"
                      r"see (attached|document)|various|multiple|-+|—)$", re.I)


def _colmap(header):
    m = {}
    for i, (h, _, _) in enumerate(header):
        hl = h.lower().strip()
        if not hl:
            continue
        for key, pat in COLS:
            if key not in m and re.search(pat, hl):
                if key == "vendor" and re.search(r"amount|value|date|\$", hl):
                    continue
                if key == "title" and re.search(r"number|no\.?$|#", hl):
                    continue
                m[key] = i
                break
    return m


def table_awards(raw_html, base):
    """Award rows from HTML tables whose header names an awardee column. Each row: kind 'award' (vendor known) with
    the row's own link as url."""
    p = _TableParser()
    try:
        p.feed(raw_html)
    except Exception:
        return []
    out = []
    for t in p.tables:
        if len(t) < 2:
            continue
        hi = next((i for i, r in enumerate(t[:3]) if sum(1 for c in r if c[2]) >= 2 or "vendor" in _colmap(r)), 0)
        cm = _colmap(t[hi])
        if "vendor" not in cm or not ({"title", "ref"} & set(cm)):
            continue
        for r in t[hi + 1:]:
            cell = lambda k: (r[cm[k]][0] if k in cm and cm[k] < len(r) else "").strip()
            vend = cell("vendor")
            if not vend or NOT_NAME.match(vend) or len(vend) > 200 or MONEY.fullmatch(vend):
                continue
            title, ref = cell("title"), cell("ref")
            if not title and not ref:
                continue
            m = MONEY.search(cell("amount")) or MONEY.search(" ".join(c[0] for c in r))
            d = DATE.search(cell("date")) or DATE.search(" ".join(c[0] for c in r))
            href = next((c[1] for c in r if c[1] and not c[1].startswith(("#", "mailto:", "javascript:"))), None)
            out.append({"kind": "award", "ref_no": (ref if 3 <= len(ref) <= 40 and re.search(r"\d", ref) else _ref(ref, title))[:60], "title": (title or ref)[:300],
                        "description": "", "closing": "", "url": urllib.parse.urljoin(base, href) if href else "",
                        "vendor": re.sub(r"\s+", " ", vend)[:200], "amount": float(m.group(1).replace(",", "")) if m else None,
                        "award_date": (_iso(d.group(1)) if d else "") or "", "bidders": []})
    return out


DETAIL_HREF = re.compile(r"/solicitations?/[^?#]*\d{4,}|[?&](bid|solicitation|rfp|project|award|contract|doc|document|item|notice)_?(id|no|num|number)=\w+|"
                         r"(bid|solicitation|rfp|ifb|itb|rfq|award|contract)[-_]?(detail|info|view|summary)|/(bids?|rfps?|ifbs?|itbs?|rfqs?|solicitations?|awards?|contracts?|procurements?|tenders?)/[\w-]*\d{2,}", re.I)
DOC_WORDS = re.compile(r"award|intent|notice|tabulat|bid[-_ ]?tab|results?|recommend|selection|abstract|executed|contract", re.I)
AWARD_DOC = re.compile(r"notice of (intent to )?award|intent to award|awarded to|award(ed)? (is )?(made )?to|award recommendation|recommend(ation|ed)? (of|for)? ?award|"
                       r"bid tabulation|tabulation of bids|bid results|successful (bidder|proposer|offeror|respondent)|contract award|lowest responsive|"
                       r"apparent low bidder|selected (firm|proposer)|recommended (firm|vendor|contractor|bidder)", re.I)


def _row_context(raw_html, base):
    """url -> the whole table row's text, for links that are only a number."""
    p = _TableParser()
    try:
        p.feed(raw_html)
    except Exception:
        return {}
    out = {}
    for t in p.tables:
        for r in t:
            txt = " | ".join(c[0] for c in r if c[0])
            for c in r:
                if c[1]:
                    out.setdefault(urllib.parse.urljoin(base, c[1]).split("#")[0], txt[:300])
    return out


def detail_links(raw_html, base, listing, limit=80):
    """Links from a listing page to single solicitations, award notices and tabulation documents on the same site."""
    out, seen = [], {listing, base}
    path0 = urllib.parse.urlparse(base).path.rstrip("/")
    for u, text, rel in links(raw_html, base):
        if u in seen or _blocked(u) or _site(u) != _site(base) or NEG.search(text):
            continue
        p = urllib.parse.urlparse(u)
        if p.path.rstrip("/") == path0 and not p.query:
            continue
        ok = False
        if is_pdf(u) or re.search(r"\.(docx?|xlsx?)$", p.path, re.I):
            ok = bool(DOC_WORDS.search(text + " " + p.path) or _ref(text))
        elif DETAIL_HREF.search(u):
            ok = True
        elif _ref(text) and len(text) >= 6:
            ok = p.path.rstrip("/").startswith(path0) or bool(re.search(r"bid|solicit|rfp|award|procure|contract|tender|purchas", p.path, re.I))
        if ok:
            seen.add(u)
            out.append((u, text))
    return out[:limit]


VEND_LBL = re.compile(r"(?:awarded to|award(?:ed)? (?:is )?(?:made )?to|successful (?:bidder|proposer|offeror|respondent)|awardee|"
                      r"recommended (?:firm|vendor|contractor|bidder|proposer)|selected (?:firm|proposer|vendor|contractor)|"
                      r"(?:name of )?(?:contractor|vendor|supplier|consultant)(?: name)?)\s*(?:is|was|:|-|–)?\s*\n?\s*([^\n]{3,120})", re.I)
AMT_LBL = re.compile(r"(?:award|contract|total|not[- ]to[- ]exceed|nte|bid|proposal|price|value)[^\n$]{0,40}\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?|\d{4,}(?:\.\d{2})?)", re.I)
DATE_LBL = re.compile(r"(?:award(?:ed)?(?: date)?|date of award|dated?|board approv\w*|executed)\s*(?:on|:)?\s*" + DATE.pattern[2:-2], re.I)


def parse_detail(text, url="", title_hint=""):
    """One award from a single award notice, award page or tabulation: awardee from its label, amount and date near
    their labels, reference and title from the heading or link. None when no awardee is named plainly."""
    m = VEND_LBL.search(text)
    if not m:
        return None
    v = re.split(r"\s{2,}|\t| for (?:the )?(?:amount|sum|total)| in the (?:amount|sum)| at (?:a|the) | with (?:a|an|the) |[;(]|\$", m.group(1))[0].strip(" .,:-–")
    if len(v.split()) > 8:
        cm = COMPANY.search(v)
        if cm and not NOT_VENDOR.match(cm.group(1)):
            v = _vendor_tail(cm.group(1))
    if len(v) < 3 or NOT_NAME.match(v) or NOT_VENDOR.match(v) or not re.search(r"[A-Z]", v) or len(v.split()) > 12:
        return None
    a = AMT_LBL.search(text) or MONEY.search(text[m.start():m.start() + 600])
    d = DATE_LBL.search(text)
    d = d.group(1) if d else (DATE.search(text).group(1) if DATE.search(text) else "")
    head = "\n".join(text.split("\n")[:12])
    ref = _ref(title_hint, head, urllib.parse.unquote(urllib.parse.urlparse(url).path).replace("-", " "))
    title = title_hint.strip() if title_hint and len(title_hint.strip()) > 8 else ""
    if not title:
        t = re.search(r"(?:project|title|solicitation|subject|re|for)\s*[:\-]\s*([^\n]{8,200})", head, re.I)
        title = t.group(1).strip() if t else next((l for l in head.split("\n") if 12 <= len(l) <= 200 and not VEND_LBL.search(l)), "")
    if not title:
        return None
    return {"kind": "award", "ref_no": ref, "title": title[:300], "description": "", "closing": "",
            "url": url, "vendor": v[:200], "amount": float(a.group(1).replace(",", "")) if a else None,
            "award_date": _iso(d) or "" if d else "", "bidders": []}


REF2 = re.compile(r"\b((?:RFP|IFB|ITB|RFQ|RFB|RFT|RFI|BID|CONTRACT|SOLICITATION|TENDER|PROJECT)\s*(?:NO\.?|NUMBER|#)?\s*[:#]?\s*[A-Z0-9][A-Z0-9\-./]*\d[A-Z0-9\-./]*"
                  r"|[A-Z]{1,6}-?\d{2,}[-A-Z0-9]*|\d{2,}-\d{2,}[-A-Z0-9]*)\b", re.I)


def _ref(*texts):
    for t in texts:
        m = REF2.search(t or "")
        if m and not YEARISH.fullmatch(m.group(1)):
            return m.group(1).strip(" .-/")[:60]
    return ""


def _rail_ok(aid, text):
    """Agencies that buy nothing but rail keep everything; others keep what the rail keyword score allows (a city's
    snow removal and uniforms are not rail awards)."""
    import relevance
    return aid in relevance.RAIL_ONLY or relevance.kw_score(text, False) >= 20


def ensure_seen(c):
    c.execute("CREATE TABLE IF NOT EXISTS award_seen (url TEXT PRIMARY KEY, agency_id TEXT, checked TEXT, result TEXT)")


def _store(c, items, aid, country, url, suppliers):
    for it in items:
        if it.get("award_date") and not it.get("published"):
            it["published"] = it["award_date"]
    old = sources.HISTORY
    sources.HISTORY = True
    try:
        n = sources.store_items(c, items, aid, country, url, "rules", suppliers) if items else 0
    finally:
        sources.HISTORY = old
    c.execute("UPDATE award SET confidence='C' WHERE source='rules' AND confidence='A' AND agency_id IS ?", (aid,))
    return n


def _queue(c, aid, url, how, text, parsed, stored, status):
    ensure_queue(c)
    c.execute("INSERT INTO award_doc (agency_id, url, how, text, chars, parsed, stored, status, added) VALUES (?,?,?,?,?,?,?,?,?) "
              "ON CONFLICT(url) DO UPDATE SET text=excluded.text, chars=excluded.chars, parsed=excluded.parsed, "
              "stored=award_doc.stored+excluded.stored, status=CASE WHEN award_doc.status='reviewed' THEN 'changed' ELSE excluded.status END, added=excluded.added",
              (aid, url, how, text, len(text), parsed, stored, status, bc.now()))
    return c.execute("SELECT id FROM award_doc WHERE url=?", (url,)).fetchone()[0]


def read_detail(c, aid, country, url, title_hint="", suppliers=None):
    """Reads one award notice, award page or tabulation. Returns (rows, new, result)."""
    ensure_seen(c)
    try:
        text, final, how = _text(url)
    except Exception as e:
        c.execute("INSERT OR REPLACE INTO award_seen VALUES (?,?,?,?)", (url, aid, bc.now(), f"error {e}"[:200]))
        return 0, 0, "error"
    result, rows, new = "not an award", 0, 0
    if how == "pdf" and len(text.strip()) < 300:
        if DOC_WORDS.search(title_hint + " " + url):
            _queue(c, aid, final, how, text, 0, 0, "scanned")
            result = "scanned pdf"
    else:
        it = parse_detail(text, final, title_hint)
        if it and _rail_ok(aid, f"{it['title']} {title_hint}"):
            rows, new = 1, _store(c, [it], aid, country, final, suppliers)
            _queue(c, aid, final, how, text, 1, new, "queued")
            result = f"award {it['vendor']}"
        elif it:
            result = "award, not rail"
        elif AWARD_DOC.search(text) and _rail_ok(aid, f"{title_hint} {text[:3000]}"):
            # a tabulation or notice that does not name the awardee plainly: the Pi reads it (a low bid is not always the award)
            did = _queue(c, aid, final, how, text, 0, 0, "queued")
            result = "award document, to the Pi" if pi_submit(c, did, text) else "award document, for review"
        elif title_hint and _ref(title_hint) and DATE.search(text[:4000]) and _rail_ok(aid, title_hint):
            # a closed solicitation with no awardee shown: kept as the RFP so a later award can be tied to it
            d = DATE.search(text[:4000]).group(1)
            new = _store(c, [{"kind": "solicitation", "ref_no": _ref(title_hint), "title": title_hint[:300],
                              "description": "", "closing": "", "published": _iso(d) or "", "url": final}], aid, country, final, suppliers)
            result = "solicitation, no awardee shown"
    c.execute("INSERT OR REPLACE INTO award_seen VALUES (?,?,?,?)", (url, aid, bc.now(), result[:200]))
    c.commit()
    return rows, new, result


def read_listing(c, aid, country, url, suppliers=None, max_details=60, verbose=False, budget=None):
    """A listing (award, closed or results page): its table rows, then each new single award it links to.
    Returns (pages read, rows, new). budget: a one-item list with the pages still allowed this run."""
    ensure_seen(c)
    suppliers = suppliers if suppliers is not None else sources.supplier_ids()
    if _blocked(url):
        return 0, 0, 0
    raw, final = _get(url)
    pages, rows, new = 1, 0, 0
    items = [i for i in table_awards(raw, final) if _rail_ok(aid, f"{i['title']} {i['ref_no']}")]
    if items:
        n = _store(c, items, aid, country, final, suppliers)
        tbl = "\n".join(f"{i['ref_no']} | {i['title']} | {i['vendor']} | {i['amount'] or ''} | {i['award_date']}" for i in items)
        _queue(c, aid, final, "table", tbl, len(items), n, "queued")
        rows, new = rows + len(items), new + n
    else:  # a plain list or text table: the line rules, rail rows only; never sent to the Pi as a whole page
        text = sources.page_text(raw.encode("utf-8"), "utf-8")
        li = [i for i in parse_awards(text) if _rail_ok(aid, i["title"])]
        if li:
            n = _store(c, li, aid, country, final, suppliers)
            _queue(c, aid, final, "table", "\n".join(f"{i['ref_no']} | {i['title']} | {i['vendor']} | {i['amount'] or ''} | {i['award_date']}" for i in li),
                   len(li), n, "queued")
            rows, new = rows + len(li), new + n
    c.commit()
    done = 0
    rail_only = aid in __import__("relevance").RAIL_ONLY
    ctx = _row_context(raw, final)
    have = {urllib.parse.urljoin(final, i["url"]) for i in items if i.get("url")}  # rows already read off the table
    for u, text in detail_links(raw, final, url):
        if u in have:
            continue
        row = ctx.get(u, text)
        if done >= max_details or (budget and budget[0] <= 0):
            break
        if c.execute("SELECT 1 FROM award_seen WHERE url=?", (u,)).fetchone() or c.execute("SELECT 1 FROM award_doc WHERE url=?", (u,)).fetchone():
            continue
        if not rail_only and not is_pdf(u) and not _rail_ok(aid, row):
            c.execute("INSERT OR REPLACE INTO award_seen VALUES (?,?,?,?)", (u, aid, bc.now(), "skipped, not rail"))
            continue
        time.sleep(1.0)
        r, n, res = read_detail(c, aid, country, u, text if len(text) >= 8 else row, suppliers)
        pages, rows, new, done = pages + 1, rows + r, new + n, done + 1
        if budget:
            budget[0] -= 1
        if verbose:
            print(f"   {u[:110]} -> {res}")
    c.execute("INSERT OR REPLACE INTO award_seen VALUES (?,?,?,?)", (url, aid, bc.now(), f"listing: {rows} rows, {done} documents followed"))
    c.commit()
    return pages, rows, new


def read_free(c, aid, country, url, text, how="html", suppliers=None):
    """Daily page watch of an award page: the listing reader (tables and new single awards). Returns (rows, new)."""
    p, r, n = read_listing(c, aid, country, url, suppliers, max_details=30)
    return r, n


def backfill(c, max_usd=None, per_link=40, verbose=False, max_pages=None):
    """One pass over award links not yet backfilled: each listing page and its older pages (next pages, earlier years),
    with their table rows and every single award they link to, read locally (rules; the Pi for award documents the
    rules miss). No Claude calls (max_usd kept for the command line; ignored). Returns (pages read, rows, new, 0.0)."""
    ensure(c)
    ensure_queue(c)
    ensure_seen(c)
    max_pages = max_pages or int(bc.settings().get("award_backfill_pages", 300))  # per run, so the daemon is not held up
    budget = [max_pages]
    suppliers = sources.supplier_ids()
    pages = found = new = 0
    rows = c.execute("SELECT l.agency_id, l.url, a.country FROM agency_link l LEFT JOIN agency a ON a.agency_id=l.agency_id "
                     "WHERE l.kind IN ('awards','closed','tabulations') AND l.backfilled IS NULL ORDER BY l.source='curated' DESC, l.score DESC").fetchall()
    for r in rows:
        if budget[0] <= 0:
            break
        aid, ctry = r["agency_id"], r["country"] or "US"
        if _blocked(r["url"]):
            c.execute("UPDATE agency_link SET backfilled=?, backfill_pages=0, watch=0, note='aggregator, not crawled' WHERE agency_id=? AND url=?",
                      (bc.now(), aid, r["url"]))
            c.commit()
            continue
        if verbose:
            print(f"{aid}: {r['url']}")
        if is_pdf(r["url"]):
            if not c.execute("SELECT 1 FROM award_seen WHERE url=?", (r["url"],)).fetchone():
                f, n, res = read_detail(c, aid, ctry, r["url"], "", suppliers)
                pages, found, new = pages + 1, found + f, new + n
                budget[0] -= 1
            c.execute("UPDATE agency_link SET backfilled=?, backfill_pages=1 WHERE agency_id=? AND url=?", (bc.now(), aid, r["url"]))
            c.commit()
            continue
        try:
            raw, final = _get(r["url"])
        except Exception as e:
            c.execute("UPDATE agency_link SET note=? WHERE agency_id=? AND url=?", (f"backfill: unreadable {bc.now()[:10]}: {e}"[:300], aid, r["url"]))
            c.commit()
            continue
        listings = [r["url"]] + [u for u in _older_pages(raw, final, per_link) if u != r["url"] and not _blocked(u)]
        done = 0
        for u in listings:
            if budget[0] <= 0:
                break
            if u != r["url"] and c.execute("SELECT 1 FROM award_seen WHERE url=? AND result LIKE 'listing:%'", (u,)).fetchone():
                continue
            if is_pdf(u):
                if c.execute("SELECT 1 FROM award_seen WHERE url=?", (u,)).fetchone():
                    continue
                f, n, res = read_detail(c, aid, ctry, u, "", suppliers)
                p = 1
                budget[0] -= 1
            else:
                try:
                    budget[0] -= 1
                    p, f, n = read_listing(c, aid, ctry, u, suppliers, max_details=per_link * 2, verbose=verbose, budget=budget)
                except Exception as e:
                    bc.log(f"award backfill: {u}: {e}")
                    continue
                time.sleep(1.0)
            pages, found, new, done = pages + p, found + f, new + n, done + p
        if budget[0] <= 0:
            c.commit()  # page cap reached: this link is finished next run (pages already read are skipped)
            break
        c.execute("UPDATE agency_link SET backfilled=?, backfill_pages=coalesce(backfill_pages,0)+? WHERE agency_id=? AND url=?",
                  (bc.now(), done, aid, r["url"]))
        c.commit()
    link_refs(c)
    return pages, found, new, 0.0


def _nref(s):
    s = re.sub(r"^(rfp|ifb|itb|rfq|rfb|rft|bid|contract|solicitation|tender|project|no)\b\.?\s*(no\.?|number|#)?\s*", "", (s or "").strip(), flags=re.I)
    return re.sub(r"[^A-Z0-9]", "", s.upper())


def link_refs(c):
    """Ties awards with no notice to the agency's RFP or bid with the same reference, ignoring spacing, dashes and
    'RFP No.' style prefixes. Awards with no matching RFP stay on their own. Returns awards linked."""
    by = {}
    for r in c.execute("SELECT notice_id, agency_id, ref_no FROM notice WHERE ref_no IS NOT NULL AND coalesce(notice_type,'') != 'award'"):
        k = _nref(r["ref_no"])
        if len(k) >= 4:
            by.setdefault((r["agency_id"], k), r["notice_id"])
    n = 0
    for a in c.execute("SELECT award_id, agency_id, ref_no FROM award WHERE notice_id IS NULL AND ref_no IS NOT NULL").fetchall():
        nid = by.get((a["agency_id"], _nref(a["ref_no"])))
        if nid:
            c.execute("UPDATE award SET notice_id=? WHERE award_id=?", (nid, a["award_id"]))
            n += 1
    c.commit()
    return n


def reset(c):
    """Clears the first award history load (landing-page text, rows read off whole pages, the BidNet detour) so the
    drill-down reader starts clean: rules/pi awards and their award notices, the review queue, Pi jobs not yet read,
    links on aggregator hosts or that no longer score as award pages; every award link is read again.
    Returns a summary dict."""
    import glob
    ensure(c)
    ensure_queue(c)
    ensure_seen(c)
    out = {}
    ids = [r[0] for r in c.execute("SELECT award_id FROM award WHERE source IN ('rules','pi')")]
    for i in range(0, len(ids), 500):
        ch = ids[i:i + 500]
        c.execute(f"DELETE FROM bid_tab WHERE award_id IN ({','.join('?' * len(ch))})", ch)
    out["awards"] = c.execute("DELETE FROM award WHERE source IN ('rules','pi')").rowcount
    out["notices"] = c.execute("DELETE FROM notice WHERE source IN ('rules','pi')").rowcount
    out["documents"] = c.execute("DELETE FROM award_doc").rowcount
    c.execute("DELETE FROM award_seen")
    gone = 0
    for r in c.execute("SELECT agency_id, url, label, source FROM agency_link WHERE kind != 'bids'").fetchall():
        if _blocked(r["url"]) or (r["source"] == "discovered" and score(r["label"] or "", r["url"]) < 2):
            c.execute("DELETE FROM agency_link WHERE agency_id=? AND url=?", (r["agency_id"], r["url"]))
            c.execute("DELETE FROM page_watch WHERE url=?", (r["url"],))
            gone += 1
    out["links dropped"] = gone
    c.execute("UPDATE agency_link SET backfilled=NULL, backfill_pages=NULL, note=NULL WHERE kind != 'bids'")
    c.execute("UPDATE page_watch SET last_hash=NULL WHERE kind='awards'")  # read again by the new reader
    c.commit()
    pj = 0
    for d in ("inbox", "outbox"):
        for p in glob.glob(os.path.join(PIJOBS, d, "awdoc-*.json")):
            try:
                os.remove(p)
                pj += 1
            except OSError:
                pass
    out["pi jobs cleared"] = pj
    return out


def load_review(c, path):
    """Award rows read by hand (in a Claude thread, no API) from queued award_doc texts: same CSV as load-past-rfps
    plus optional doc_url; marks those documents reviewed."""
    import contract_pages
    res = contract_pages.load_past_rfps(c, path, tag="awdoc")
    ensure_queue(c)
    for r in csv.DictReader(open(path, newline="", encoding="utf-8-sig")):
        if (r.get("doc_url") or "").strip():
            c.execute("UPDATE award_doc SET status='reviewed', reviewed=? WHERE url=?", (bc.now(), r["doc_url"].strip()))
    c.commit()
    return res


def tick(c, limit=40):
    """Daily: discover links for the next batch of agencies, then spend the backfill allowance. Logged in run_log."""
    started = bc.now()
    pr, pa = pi_consume(c)
    checked, links_found = discover(c, limit=limit)
    p, f, n, k = backfill(c)
    n += pa
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (started, bc.now(), "award portals", "done", links_found + f, n, k,
               f"discover: {checked} agencies checked, {links_found} award links; backfill: {p} pages read free, {f} rows by rules, {n} new; pi: {pr} results, {pa} awards"))
    c.commit()
    return checked, links_found, p, n, k


def report(c):
    ensure(c)
    rows = c.execute("SELECT a.agency_id, a.agency, s.checked, s.pages, s.error, "
                     "(SELECT group_concat(kind || ' ' || url, ' | ') FROM agency_link l WHERE l.agency_id=a.agency_id AND l.kind!='bids') links "
                     "FROM agency a LEFT JOIN agency_link_scan s ON s.agency_id=a.agency_id ORDER BY a.agency_id").fetchall()
    have = sum(1 for r in rows if r["links"])
    print(f"{have} of {len(rows)} agencies have an award or closed-solicitations link; "
          f"{sum(1 for r in rows if r['checked'])} checked")
    for r in rows:
        print(f"{r['agency_id']:14} {(r['checked'] or 'not checked')[:10]} {r['links'] or ('-- ' + (r['error'] or 'none found'))}"[:400])
