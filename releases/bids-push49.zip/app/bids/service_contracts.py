"""Service contracts from board records (service contracts thread, 11-19): maintenance, overhaul, operations and
maintenance, signal / radio / IT system support and elevator / facility service awards, from the Legistar Web API's
matters (public, no robots.txt), as awards with category maintenance_services or rail_operations so the O&M modules
and the Service contracts market map (relevance >= 50) read them.

Titles do the work where they carry vendor, contract number and amount (LA Metro). Where the title names the vendor
but no amount (BART's Executive Decision Documents), the award is stored without one and its attachment goes to the
Pi reader; the Pi's amount then fills that award (award_portals.pi_consume, note 'award_id=N'). No Claude calls.

fleet_contract (hand-loaded contracts) lives in the site's own database, so the site dedupes on operator + vendor +
start month when it reads these.
"""
import json
import re
import time
import urllib.parse

import bidcore as bc
import sources

# Legistar client -> Bid Catcher agency, and whether every item is rail (else the title must not be bus-only)
CLIENTS = {"metro": ("LAMETRO", False), "bart": ("BART", True), "dart": ("DART", False), "dcta": ("DCTA", False),
           "rideuta": ("UTA", False), "miamidade": ("MDTPW", False)}
COUNTY = {"miamidade": re.compile(r"transit|transportation and public works|dtpw|metrorail|metromover", re.I)}

SERVICE = re.compile(r"\b(maintenance|maintain|repair|overhaul|rebuild|refurbish|o&m|operations? (and|&) maintenance|operat(e|ion|ions|ing) services|"
                     r"support services|inspection services|servicing|janitorial|custodial|cleaning services|landscap\w*|herbicide|"
                     r"vegetation|pest control|elevator|escalator|hvac|fire (alarm|protection|suppression)|security services|"
                     r"software (support|maintenance)|licen[cs]e|hosting|managed services)\b", re.I)
AWARD = re.compile(r"\b(award|execute|enter into|approv\w* .{0,40}(contract|agreement)|modification|change order|exercise|option|amend|increase|extend)\b", re.I)
NOT_SERVICE = re.compile(r"\b(motion by|resolution of (appreciation|recognition)|budget|continuing resolution|legislative|state of good repair grant|"
                         r"public hearing|joint development|lease of (space|property)|construction management|program management|design services|"
                         r"engineering (design )?services|architect\w*|consult\w*|audit\w*|financial advis\w*|legal services|outside counsel|"
                         r"environmental (review|clearance|services)|planning (study|services)|cooperative agreement|funding agreement|"
                         r"memorandum of understanding|mou\b|grant agreement|insurance|bond)\b", re.I)
# service contracts thread, 11-20 (first live run): budget text, engineering, planning, security, toll, bikeshare and fare
# systems are not service contracts for the O&M modules
NOT_SERVICE_DOC = re.compile(r"\b((operating|capital|annual|proposed|adopted|amended) budget|budget (includes|amendment|adoption|revision|transfer)|"
                             r"fiscal year \d{4} (budget|program)|capital (improvement )?program|program of projects|allocat\w+ of|grant (application|agreement|funds|award)|"
                             r"funding (agreement|allocation|plan|request|strategy)|"
                             r"engineering (services|design|support)|design services|planning|security (guard|officer|services|patrol)|guard services|private security|"
                             r"toll\w*|bike ?share|bicycle|scooter|fare (collection|system|media|payment|card)|ticket vending|parking (management|operations|services)|"
                             r"idiq|indefinite delivery|advertising|marketing|legal services|real estate|right[- ]of[- ]way acquisition)\b", re.I)
VEHICLES = re.compile(r"\b(purchase|procure\w*|acquisition|acquire|manufactur\w*|base order|option order)\b.{0,80}\b(trainsets?|rail ?cars?|light rail vehicles?|"
                      r"lrvs?|locomotives?|subway cars?|streetcars?|multiple units?|emus?|dmus?|coaches)\b", re.I)
STRONG_AWARD = re.compile(r"\baward(ed|ing|s)?\b.{0,80}\b(contract|agreement|purchase order)|authoriz\w+ .{0,120}\b(award|execute|enter into)\b|"
                          r"recommend\w* .{0,40}\baward|enter into .{0,80}\b(contract|agreement)|execute .{0,60}\b(contract|agreement)\b|"
                          r"\b(modification|amendment|change order|option)\b.{0,80}\b(contract|agreement)\b.{0,120}\b(with|to)\s+[A-Z]", re.I)


def qualifies(text):
    """(ok, category or None): a service contract the O&M modules should count, or a vehicle purchase (its own category)."""
    t = text[:1500]
    if VEHICLES.search(t) and not re.search(r"\b(maintenance|overhaul|repair) of\b", t[:300], re.I):
        return True, "vehicle_procurement"
    if NOT_SERVICE.search(t[:600]) or NOT_SERVICE_DOC.search(t):
        return False, None
    return True, None
BUS = re.compile(r"\b(bus(es)?|paratransit|cng|compressed natural gas|vanpool|microtransit|access services|zero[- ]emission bus|bus division)\b", re.I)
RAILISH = re.compile(r"\b(rail|train|subway|metro ?rail|light rail|heavy rail|lrv|hrv|railcar|track|signal|traction|catenary|ocs|"
                     r"station|platform|elevator|escalator|tunnel|scada|cbtc|ptc|wayside|yard|people mover|streetcar|trax|frontrunner|a-train)\b", re.I)
OPS = re.compile(r"\b(operations? (and|&) maintenance|o&m|operat(e|ion|ions|ing) (services|of the)|contract operat\w*|purchased transportation|"
                 r"commuter rail (service|operations)|rail operations|streetcar operations)\b", re.I)
REF = re.compile(r"\b(?:Contract|Agreement|Purchase Order|Task Order|PO)\s+No\.?\s*([A-Z0-9][A-Z0-9\-./]{3,30})", re.I)
TOTAL = re.compile(r"total (?:not[- ]to[- ]exceed |nte )?(?:\(nte\) )?(?:contract )?(?:amount|value|price|cost)? ?(?:of |to )?\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?)", re.I)
AMT = re.compile(r"\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?)")
VENDOR = [re.compile(r"\b(?:to|with|from)\s+([A-Z][\w&.,'’\- ]{2,80}?(?:Inc|LLC|L\.L\.C|Corp|Corporation|Company|Co|Ltd|LP|LLP|JV|Joint Venture|Group|"
                     r"USA|America|Associates|Services|Systems|Technologies|Communications|Solutions|Engineering|Partners)\.?)(?=[,;(]|\s+(?:to|for|in|dba|d/b/a)\b|\.\s|\s*$)"),
          re.compile(r"\b(?:to|with|from)\s+([A-Z][A-Za-z0-9&.'’\-]+(?: [A-Z][A-Za-z0-9&.'’\-]+){0,5})(?=,|\s+(?:to provide|for)\b)")]
PASSED = re.compile(r"pass|adopt|approv|carried|ratif", re.I)


def category(title):
    return "rail_operations" if OPS.search(title) and not re.search(r"fueling|cng", title, re.I) else "maintenance_services"


def vendor(title):
    for rx in VENDOR:
        m = rx.search(title)
        if m:
            v = m.group(1).strip(" ,.-")
            if re.match(r"(contract|agreement|purchase order|task order|modification)\b", v, re.I):
                w = re.split(r"\b(?:with|to)\s+", v)
                v = w[-1].strip(" ,.-") if len(w) > 1 else ""
                v = re.sub(r",?\s+(?:dba|d/b/a)\b.*$", "", v)
            v = re.split(r"\s+for\s+|\s+to\s+provide\b|\s+\(", v)[0].strip(" ,.-")
            if not v or re.match(r"(exercise|provide|continue|increase|extend|incorporate|the)\b", v, re.I):
                continue
            if not re.match(r"(the|a|an|this|staff|board|authority|agency|metro|county|city|district|chief|general)\b", v, re.I) and len(v.split()) <= 12:
                return v
    return None


def _json(url):
    raw, cs, _ = bc.fetch(url, timeout=60)
    return json.loads(raw.decode(cs or "utf-8", "replace"))


def matters(client, since, words=("maintenance", "repair", "overhaul", "services", "operation", "support", "elevator", "escalator")):
    """Matters introduced since `since` whose titles carry a service word (one query per word; Legistar's OData has no OR
    on substringof in every version). Deduped by MatterId."""
    base = f"https://webapi.legistar.com/v1/{client}/matters"
    seen = {}
    for w in words:
        skip = 0
        while True:
            q = urllib.parse.urlencode({"$filter": f"substringof('{w}',MatterTitle) and MatterIntroDate ge datetime'{since}'",
                                        "$orderby": "MatterIntroDate desc", "$top": 1000, "$skip": skip})
            rows = _json(f"{base}?{q}")
            for m in rows:
                seen.setdefault(m["MatterId"], m)
            if len(rows) < 1000:
                break
            skip += 1000
            time.sleep(1.0)
        time.sleep(1.0)
    return list(seen.values())


def _attachment_text(client, mid):
    import award_portals
    for a in _json(f"https://webapi.legistar.com/v1/{client}/matters/{mid}/attachments"):
        u = a.get("MatterAttachmentHyperlink")
        if u and (".pdf" in u.lower() or (a.get("MatterAttachmentName") or "").lower().endswith(".pdf")):
            try:
                text, final, how = award_portals._text(u)
                return text, final
            except Exception as e:
                bc.log(f"service contracts: {u}: {e}")
    return "", None


def ensure(c):
    c.execute("CREATE TABLE IF NOT EXISTS service_matter (client TEXT, matter_id INTEGER, checked TEXT, result TEXT, award_id INTEGER, "
              "PRIMARY KEY (client, matter_id))")


def run(c, clients=None, years=5, pi=True, verbose=False):
    """Reads each client's service-contract matters since `years` ago. Returns {client: (matters, awards added, sent to the Pi)}."""
    import award_portals
    ensure(c)
    award_portals.ensure_queue(c)
    suppliers = sources.supplier_ids()
    since = f"{int(bc.now()[:4]) - years}{bc.now()[4:10]}"
    out = {}
    for client in clients or CLIENTS:
        aid, rail_only = CLIENTS[client]
        try:
            rows = matters(client, since)
        except Exception as e:
            bc.log(f"service contracts {client}: {e}")
            out[client] = (0, 0, 0)
            continue
        added = to_pi = 0
        country = "US"
        for m in rows:
            mid, title = m["MatterId"], re.sub(r"\s+", " ", m.get("MatterTitle") or "").strip()
            if c.execute("SELECT 1 FROM service_matter WHERE client=? AND matter_id=?", (client, mid)).fetchone():
                continue
            res, award_id = "skipped", None
            if re.match(r"\s*withdrawn\b", title, re.I) or re.search(r"withdrawn|failed|tabled", m.get("MatterStatusName") or "", re.I):
                res = "withdrawn"
            elif not ((SERVICE.search(title) or VEHICLES.search(title)) and AWARD.search(title)) or not qualifies(title)[0]:
                res = "not a service contract"
            elif client in COUNTY and not COUNTY[client].search(title):
                res = "not transit"
            elif not rail_only and BUS.search(title) and not RAILISH.search(title):
                res = "bus only"
            else:
                v = vendor(title)
                if not v:
                    res = "no vendor named"
                else:
                    amend = bool(re.search(r"\b(modification|change order|amend|increase|exercise|option|extend)\b", title, re.I)) and not re.search(r"\baward\b", title, re.I)
                    t = TOTAL.search(title)
                    amt = None if amend else float((t or AMT.search(title)).group(1).replace(",", "")) if (t or AMT.search(title)) else None
                    rm = REF.search(title)
                    date = (m.get("MatterPassedDate") or m.get("MatterAgendaDate") or m.get("MatterIntroDate") or "")[:10]
                    passed = bool(PASSED.search(m.get("MatterStatusName") or ""))
                    url = f"https://{client}.legistar.com/LegislationDetail.aspx?ID={mid}&GUID={m.get('MatterGuid')}"
                    a = {"source_key": f"legistar-svc:{client}:{mid}", "source": "board_matter", "agency_id": aid, "country": country,
                         "ref_no": (rm.group(1) if rm else m.get("MatterFile")) or None, "title": title[:500], "vendor": v[:200], "amount": amt,
                         "currency": "USD", "award_date": date or None, "category": qualifies(title)[1] or category(title),
                         "relevance": 60 if (rail_only or RAILISH.search(title)) else 50, "source_url": url,
                         "confidence": "B" if passed else "C",
                         "notes": ("Modification or option on an existing contract; amount left out so totals are not counted twice. " if amend else "")
                                  + f"Board record {m.get('MatterFile') or mid} ({m.get('MatterStatusName') or 'status unknown'}): {title[:600]}"}
                    if sources.add_award(c, a, suppliers):
                        award_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                        added += 1
                        res = "award"
                        if amt is None and not amend and pi and award_portals.pi_on():
                            text, final = _attachment_text(client, mid)
                            if len(text.strip()) >= 300:
                                did = award_portals._queue(c, aid, final, "pdf", text, 0, 0, "queued")
                                c.execute("UPDATE award_doc SET note=coalesce(note,'') || ? WHERE id=?", (f" award_id={award_id};", did))
                                if award_portals.pi_submit(c, did, text):
                                    to_pi += 1
                                    res = "award, amount from the Pi"
                            time.sleep(1.0)
                    else:
                        res = "already stored"
            c.execute("INSERT OR REPLACE INTO service_matter VALUES (?,?,?,?,?)", (client, mid, bc.now(), res, award_id))
            if verbose and res.startswith("award"):
                print(f"{client} {mid}: {res}: {title[:140]}")
        c.commit()
        out[client] = (len(rows), added, to_pi)
    try:
        import award_portals as ap
        ap.link_refs(c)
    except Exception:
        pass
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (bc.now(), bc.now(), "service contracts", "done", sum(v[0] for v in out.values()), sum(v[1] for v in out.values()), 0.0,
               "; ".join(f"{k}: {v[0]} matters, {v[1]} awards, {v[2]} to the Pi" for k, v in out.items())))
    c.commit()
    return out


# ---- board documents of agencies not on Legistar (service contracts thread, 11-19: WMATA, MTA, SEPTA, MBTA, NJ Transit,
# Metra, CTA, TriMet, Sound Transit, SFMTA, MARTA, Metrolinx, STM, exo, TransLink, TTC, OC Transpo and every other
# agency whose agendas, packets and minutes the meetings reader collects). The documents already listed in meeting_doc
# are read again (robots.txt honoured, as always) with the service-contract filter: an item naming its vendor is stored
# directly; an award item that does not is sent to the Pi reader, whose answer is stored the same way (board_matter).

def ensure_docs(c):
    c.execute("CREATE TABLE IF NOT EXISTS service_doc (url TEXT PRIMARY KEY, agency_id TEXT, checked TEXT, items INTEGER, to_pi INTEGER, error TEXT)")


def _item_title(block, flat):
    t = next((re.sub(r"\s+", " ", l).strip() for l in block.splitlines()
              if re.search(r"approv|award|contract|agreement|authoriz|amend|maintenance|services", l, re.I) and len(l.strip()) > 15), flat[:160])
    return re.sub(r"^\s*(?:SUBJECT|RE|TITLE)\s*:\s*", "", t, flags=re.I)[:300]


def store_doc_award(c, aid, country, title, vend, amt, date, url, cat, rel, notes, conf="C", suppliers=None, ref=None):
    if amt:  # the same award in the agenda, the packet and the minutes: one row
        key = f"mtgdoc-svc:{aid}:{int(amt)}:{sources.norm_vendor(vend)}"
        if c.execute("SELECT 1 FROM award WHERE source='board_matter' AND agency_id=? AND amount=? AND vendor_norm=?",
                     (aid, amt, sources.norm_vendor(vend))).fetchone():
            return False
    else:
        key = f"mtgdoc-svc:{aid}:{re.sub(r'[^a-z0-9]+', '', title.lower())[:80]}:{sources.norm_vendor(vend)}"
    return sources.add_award(c, {"source_key": key, "source": "board_matter", "agency_id": aid, "country": country, "ref_no": ref,
                                 "title": title[:500], "vendor": vend[:200], "amount": amt, "currency": "CAD" if country == "CA" else "USD",
                                 "award_date": date or None, "category": cat, "relevance": rel, "source_url": url, "confidence": conf,
                                 "notes": notes[:900]}, suppliers)


def docs_pass(c, years=5, max_docs=60, max_pi=40, agencies=None, verbose=False):
    """Reads up to max_docs board documents not yet read for service contracts. Returns (docs, awards, sent to the Pi)."""
    import award_portals, meetings
    ensure_docs(c)
    award_portals.ensure_queue(c)
    suppliers = sources.supplier_ids()
    since = f"{int(bc.now()[:4]) - years}{bc.now()[4:10]}"
    legistar = {v[0] for v in CLIENTS.values()}
    q = ("SELECT d.url, d.doc_type, d.title, m.agency_id, m.meeting_date, m.body, a.country FROM meeting_doc d JOIN meeting m USING (meeting_id) "
         "LEFT JOIN agency a ON a.agency_id=m.agency_id LEFT JOIN service_doc s ON s.url=d.url "
         "WHERE s.url IS NULL AND m.meeting_date >= ? AND d.error IS NULL ORDER BY m.meeting_date DESC")
    docs = [r for r in c.execute(q, (since,)).fetchall() if r["agency_id"] not in legistar and (not agencies or r["agency_id"] in agencies)][:max_docs]
    nd = na = npi = 0
    for d in docs:
        aid, country, date = d["agency_id"], d["country"] or "US", d["meeting_date"]
        import relevance
        rail_only = aid in relevance.RAIL_ONLY
        items = to_pi = 0
        err = None
        try:
            raw, cs, final = bc.fetch(d["url"], timeout=180)
            if len(raw) > meetings.MAX_MB * 1e6:
                raise RuntimeError("too large")
            pages = meetings._pdf_pages(raw)[0] if raw[:5] == b"%PDF-" else [sources.page_text(raw, cs)]
        except PermissionError as e:
            c.execute("INSERT OR REPLACE INTO service_doc VALUES (?,?,?,?,?,?)", (d["url"], aid, bc.now(), 0, 0, f"robots: {e}"[:200]))
            continue
        except Exception as e:
            err, pages = str(e)[:200], []
        seen = set()
        blocks = meetings._blocks(pages)
        for bi, (pno, block) in enumerate(blocks):
            flat = re.sub(r"\s+", " ", block).strip()
            if len(flat) < 60 or not (SERVICE.search(flat[:1500]) or VEHICLES.search(flat[:1500])) or not STRONG_AWARD.search(flat[:1500]):
                continue
            ok, vcat = qualifies(flat)
            if not ok:
                continue
            if not rail_only and BUS.search(flat[:800]) and not RAILISH.search(flat[:800]):
                continue
            title = _item_title(block, flat)
            k = re.sub(r"\W+", "", title.lower())[:100]
            if k in seen:
                continue
            seen.add(k)
            cat, rel = vcat or category(flat[:800]), 60 if (rail_only or RAILISH.search(flat[:1500])) else 50
            amend = bool(re.search(r"\b(modification|change order|amend|increase|exercise|option|extend)\w*", title, re.I)) and not re.search(r"\baward", title, re.I)
            am = STRONG_AWARD.search(flat[:1500])
            vend = vendor(flat[am.start():am.start() + 600])  # the firm named in the award sentence, not anywhere on the page
            if vend and re.match(r"(contract|agreement|modification)\b", vend, re.I):
                vend = vendor("with " + re.split(r"\b(?:with|to)\s+", vend)[-1] + ",")
            url = f"{d['url']}#page={pno}"
            rm = REF.search(flat)
            if vend:
                t = TOTAL.search(flat[:3000])
                amt = None if amend else (float(t.group(1).replace(",", "")) if t else meetings._amount(flat[:3000]))
                if store_doc_award(c, aid, country, title, vend, amt, date, url, cat, rel,
                                   ("Modification or option; amount left out so totals are not counted twice. " if amend else "")
                                   + f"{d['body'] or 'Board'} {d['doc_type'] or 'document'} {date}, page {pno}: {flat[:500]}",
                                   "B" if (d["doc_type"] or "") == "minutes" else "C", suppliers, rm.group(1) if rm else None):
                    items += 1
            elif not amend and npi < max_pi and award_portals.pi_on():
                ctx = flat + "\n" + "\n".join(re.sub(r"\s+", " ", b).strip() for _, b in blocks[bi + 1:bi + 4])  # the attachment or table that follows
                ctx = f"{d['body'] or 'Board'} {d['doc_type'] or 'document'} {date}\n{ctx}"[:11000]
                did = award_portals._queue(c, aid, url, "pdf", ctx, 0, 0, "queued")
                c.execute("UPDATE award_doc SET note=coalesce(note,'') || ? WHERE id=?", (f" svc={cat}|{rel}|{date};", did))
                if award_portals.pi_submit(c, did, ctx, max_chunks=1):
                    to_pi += 1
                    npi += 1
        c.execute("INSERT OR REPLACE INTO service_doc VALUES (?,?,?,?,?,?)", (d["url"], aid, bc.now(), items, to_pi, err))
        c.commit()
        nd, na = nd + 1, na + items
        if verbose:
            print(f"{aid} {date} {d['doc_type']}: {items} awards, {to_pi} to the Pi{' (' + err + ')' if err else ''}")
        time.sleep(1.0)
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (bc.now(), bc.now(), "service contracts (documents)", "done", nd, na, 0.0,
               f"board documents: {nd} read, {na} service awards, {npi} items to the Pi; "
               f"{len([1 for r in c.execute(q, (since,)).fetchall() if r['agency_id'] not in legistar])} documents left"))
    c.commit()
    return nd, na, npi


def requalify(c):
    """Applies the 11-20 rules to board_matter rows already stored: rows that fail drop to relevance 40 (off the O&M
    modules and the market map, kept for review); vehicle purchases move to vehicle_procurement; the same award stored
    from several packets keeps one row at full relevance; board-document rows take their meeting date. Returns counts."""
    import award_portals
    out = {"lowered": 0, "vehicles": 0, "duplicates": 0, "dates": 0}
    rows = c.execute("SELECT award_id, agency_id, title, notes, vendor_norm, amount, source_key, source_url, award_date, category, relevance "
                     "FROM award WHERE source='board_matter' ORDER BY award_id").fetchall()
    seen = {}
    for r in rows:
        text = f"{r['title'] or ''} {(r['notes'] or '')[:1200]}"
        doc = (r["source_key"] or "").startswith("mtgdoc-svc:")
        ok, vcat = qualifies(r["title"] or "") if not doc else qualifies(text)
        if doc and not STRONG_AWARD.search(text[:1500]):
            ok = False
        if vcat and r["category"] != vcat:
            c.execute("UPDATE award SET category=? WHERE award_id=?", (vcat, r["award_id"]))
            out["vehicles"] += 1
        if not ok and (r["relevance"] or 0) >= 50:
            c.execute("UPDATE award SET relevance=40, notes=coalesce(notes,'') || ' [11-20: not counted as a service contract]' WHERE award_id=?", (r["award_id"],))
            out["lowered"] += 1
            continue
        if r["amount"]:
            k = (r["agency_id"], round(r["amount"]), r["vendor_norm"] if not doc else "")
            if k in seen and (r["relevance"] or 0) >= 50:
                c.execute("UPDATE award SET relevance=40, notes=coalesce(notes,'') || ? WHERE award_id=?", (f" [11-20: same award as #{seen[k]}]", r["award_id"]))
                out["duplicates"] += 1
                continue
            seen.setdefault(k, r["award_id"])
        if doc and r["source_url"]:
            m = c.execute("SELECT m.meeting_date FROM meeting_doc d JOIN meeting m USING (meeting_id) WHERE d.url=?",
                          (r["source_url"].split("#")[0],)).fetchone()
            if m and m[0] and r["award_date"] != m[0][:10]:
                c.execute("UPDATE award SET award_date=? WHERE award_id=?", (m[0][:10], r["award_id"]))
                out["dates"] += 1
    c.commit()
    return out
