"""Notice hygiene (BD persona review of 1.7.91, P0-3; Justin 11-20 "work the list ASAP"):

1. clean_text: SentencePiece "▁" (U+2581) and control / zero-width characters out of titles and descriptions
   (STM's French feed), on ingest (sources.add_notice / add_award) and in stored rows.
2. Duplicates: the same agency's open notice stored twice (two sources or an amended closing date) is marked
   dup_of = the first notice; the first keeps the later closing date. Rows are never deleted, so members' saved
   bids keep working; the site and the alerts skip dup_of rows.
3. Notices already closed when first seen are never "new": no alert (notified set), and stage 'closed_on_arrival'
   in hygiene_note so the site can keep them out of "Just posted".
4. Heritage, tourist and steam work is capped below 50 (Genesee County steam locomotive 496 scored 88).
5. Amtrak notices with no published text (Amtrak does not allow redistribution) carry the rail-agency default
   score; their summary says so.
"""
import datetime
import re

import bidcore as bc

_JUNK = re.compile(r"[▁​-‏  ‪-‮⁠-⁤﻿\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")
HERITAGE = re.compile(r"\bsteam (locomotive|engine)s?\b|\bheritage (railway|railroad|fleet|trolley|streetcar|equipment|locomotive)s?\b|"
                      r"\btourist (railroad|railway|train)s?\b|\bexcursion (train|railroad|railway)s?\b|\brail(road|way)? museum\b|\bmuseum\b|"
                      r"\bscenic (railway|railroad)\b|\bdinner train\b|\bvintage (trolley|streetcar|railcar|car|locomotive)s?\b|"
                      r"\bhistoric(al)? (trolley|streetcar|locomotive|railcar|railroad|railway|car)s?\b|\b(4-4-0|4-6-0|2-6-0|2-8-0|4-6-2|2-8-2|4-8-4|4-6-4)\b", re.I)
CAP = 45


def clean_text(s):
    if not s or not isinstance(s, str):
        return s
    t = _JUNK.sub(" ", s)
    return re.sub(r"[ \t]{2,}", " ", t).strip()


def ensure(c):
    have = {r[1] for r in c.execute("PRAGMA table_info(notice)")}
    if "dup_of" not in have:
        c.execute("ALTER TABLE notice ADD COLUMN dup_of INTEGER")
    if "hygiene_note" not in have:
        c.execute("ALTER TABLE notice ADD COLUMN hygiene_note TEXT")
    c.execute("CREATE INDEX IF NOT EXISTS notice_dup ON notice(dup_of)")


def norm_ref(s):
    s = re.sub(r"^(rfp|ifb|itb|rfq|rfb|rft|bid|contract|solicitation|tender|project|appel d'offres|ao|no)\b\.?\s*(no\.?|number|#|n[o°º])?\s*", "",
               (s or "").strip(), flags=re.I)
    return re.sub(r"[^A-Z0-9]", "", s.upper())


def norm_title(s):
    return re.sub(r"[^a-z0-9]+", "", clean_text(s or "").lower())[:120]


def capped(text, score):
    """Score capped below 50 for heritage, tourist and steam work."""
    if score is not None and score >= 50 and HERITAGE.search(text or ""):
        return CAP
    return score


def find_dup(c, agency_id, ref_no, title, notice_type):
    """The open notice this one repeats: same agency and normalized reference (or normalized title when there is no
    reference), not an award, not closed more than 60 days ago. Returns its notice_id or None."""
    if not agency_id or notice_type in ("award", "cancelled"):
        return None
    cut = (datetime.date.today() - datetime.timedelta(days=60)).isoformat()
    nr, nt = norm_ref(ref_no), norm_title(title)
    if len(nr) < 4 and len(nt) < 20:
        return None
    for r in c.execute("SELECT notice_id, ref_no, title FROM notice WHERE agency_id=? AND coalesce(notice_type,'') NOT IN ('award','cancelled') "
                       "AND dup_of IS NULL AND (closing IS NULL OR closing >= ?) AND first_seen >= ? ORDER BY notice_id",
                       (agency_id, cut, (datetime.date.today() - datetime.timedelta(days=365)).isoformat())):
        orf = norm_ref(r["ref_no"])
        if (len(nr) >= 4 and orf == nr) or (len(nt) >= 20 and norm_title(r["title"]) == nt and (len(nr) < 4 or len(orf) < 4 or orf == nr)):
            return r["notice_id"]
    return None


def run(c):
    """All five fixes over stored rows. Returns a dict of counts."""
    ensure(c)
    out = {"titles cleaned": 0, "duplicates marked": 0, "closed on arrival": 0, "heritage capped": 0, "amtrak noted": 0}
    for tbl, key, cols in (("notice", "notice_id", ("title", "description", "title_en", "summary")), ("award", "award_id", ("title", "vendor"))):
        have = {r[1] for r in c.execute(f"PRAGMA table_info({tbl})")}
        cols = [k for k in cols if k in have]
        for r in c.execute(f"SELECT {key}, {', '.join(cols)} FROM {tbl}").fetchall():
            if not any(isinstance(r[k], str) and _JUNK.search(r[k]) for k in cols):
                continue
            c.execute(f"UPDATE {tbl} SET {', '.join(f'{k}=?' for k in cols)} WHERE {key}=?", [clean_text(r[k]) for k in cols] + [r[key]])
            out["titles cleaned"] += 1
    # duplicates among open notices: group by agency + normalized reference, else normalized title
    cut = (datetime.date.today() - datetime.timedelta(days=60)).isoformat()
    rows = c.execute("SELECT notice_id, agency_id, ref_no, title, closing FROM notice WHERE agency_id IS NOT NULL AND dup_of IS NULL "
                     "AND coalesce(notice_type,'') NOT IN ('award','cancelled') AND (closing IS NULL OR closing >= ?) AND first_seen >= ? ORDER BY notice_id",
                     (cut, (datetime.date.today() - datetime.timedelta(days=365)).isoformat())).fetchall()
    parent = {}

    def root(i):
        while parent.get(i, i) != i:
            i = parent[i]
        return i
    byref, bytitle = {}, {}
    for r in rows:
        nr, nt = norm_ref(r["ref_no"]), norm_title(r["title"])
        for k, idx in (((r["agency_id"], nr), byref) if len(nr) >= 4 else (None, None),):
            if k:
                if k in idx:
                    parent[root(r["notice_id"])] = root(idx[k]["notice_id"])
                else:
                    idx[k] = r
        if len(nt) >= 20:
            k = (r["agency_id"], nt)
            o = bytitle.get(k)
            if o is None:
                bytitle[k] = r
            elif len(nr) < 4 or len(norm_ref(o["ref_no"])) < 4 or norm_ref(o["ref_no"]) == nr:
                parent[root(r["notice_id"])] = root(o["notice_id"])
    groups = {}
    for r in rows:
        groups.setdefault(root(r["notice_id"]), []).append(r)
    for rows_ in groups.values():
        if len(rows_) < 2:
            continue
        rows_.sort(key=lambda r: r["notice_id"])
        keep = rows_[0]
        last = max((r["closing"] or "" for r in rows_), default="") or None
        if last and (keep["closing"] or "") < last:
            c.execute("UPDATE notice SET closing=? WHERE notice_id=?", (last, keep["notice_id"]))
        for r in rows_[1:]:
            c.execute("UPDATE notice SET dup_of=?, notified=coalesce(notified, ?) WHERE notice_id=?", (keep["notice_id"], bc.now(), r["notice_id"]))
            out["duplicates marked"] += 1
    out["closed on arrival"] = c.execute(
        "UPDATE notice SET hygiene_note='closed_on_arrival', notified=coalesce(notified, first_seen) "
        "WHERE closing IS NOT NULL AND substr(closing,1,10) < substr(first_seen,1,10) AND hygiene_note IS NULL "
        "AND coalesce(notice_type,'') NOT IN ('award','cancelled')").rowcount
    for r in c.execute("SELECT notice_id, title, description, relevance FROM notice WHERE relevance >= 50").fetchall():
        if HERITAGE.search(f"{r['title'] or ''} {(r['description'] or '')[:600]}"):
            c.execute("UPDATE notice SET relevance=? WHERE notice_id=?", (CAP, r["notice_id"]))
            out["heritage capped"] += 1
    out["amtrak noted"] = c.execute(
        "UPDATE notice SET summary='Amtrak does not allow its notice text to be redistributed, so this score is the rail-agency default, not a reading of the notice.' "
        "WHERE agency_id='AMTRAK' AND (description IS NULL OR length(trim(description)) < 40) AND (summary IS NULL OR summary='')").rowcount
    c.commit()
    return out
