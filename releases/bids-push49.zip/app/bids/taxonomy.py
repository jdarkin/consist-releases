"""Subsystems: the one list Bid Catcher tags notices and awards with, and that the Consist site reads from bids.db.

Each subsystem has a label, a group (vehicle, wayside, facilities) and a keyword pattern. tag() applies the patterns, so
every notice and award gets subsystems even when no Claude review ran; Claude's own picks are kept and added to, never
removed. sync() writes the list to the subsystem_def table, which is how the site learns about a new subsystem without a
code change: add a row here (or straight into subsystem_def), run `bidmon retag`, and the analyst's filters pick it up.
"""
import re

# key: (label, group, pattern). Patterns are case-insensitive; word boundaries matter.
DEFS = {
    # -- vehicle
    "vehicle_control": ("Vehicle control / TCMS", "vehicle", r"\btcms\b|vehicle control|train control and management|event recorders?|\bmvb\b|"
                                                             r"monitoring and diagnostic|diagnostic system"),
    "propulsion_traction": ("Propulsion and traction", "vehicle", r"propulsion|traction motors?|inverters?|\bigbt\b|chopper|gear ?box(es)?|"
                                                                   r"gear units?|moteurs? de traction|armature"),
    "prime_mover": ("Prime mover / engine", "vehicle", r"prime movers?|diesel engines?|engine overhaul|re-?power|\bqsk\d*|\bmtu\b|\bemd\b|"
                                                       r"cummins|caterpillar c\d+|turbocharger"),
    "brakes": ("Brakes and air supply", "vehicle", r"brakes?|freins?|calipers?|[ée]triers?|brake shoes?|brake pads?|disc brakes?|"
                                                   r"air compressors?|compressors?|air dryers?|tread brake"),
    "trucks": ("Trucks / bogies", "vehicle", r"(?<!knuckleboom )(?<!dump )(?<!pickup )(?<!fire )(?<!utility )(?<!bucket )\btrucks?\b(?! (rental|driver|lease|chassis|mounted))|bogies?|truck frames?|suspension|"
                                             r"primary springs?|secondary springs?|air springs?|dampers?"),
    "wheels_axles": ("Wheels and axles", "vehicle", r"wheel ?sets?|\bwheels?\b|axles?|tire kits?|roues?\b|wheel truing|reprofil|"
                                                     r"journal bearings?|axle bearings?"),
    "doors": ("Doors", "vehicle", r"door (operators?|systems?|controllers?|parts|motors?)|side doors?|portes?\b|vapor\b"),
    "hvac": ("HVAC", "vehicle", r"\bhvac\b|air[- ]condition|climatis|heating and ventilat|blower motors?|evaporators?|condensers?"),
    "coupler": ("Couplers and draft gear", "vehicle", r"couplers?|drawbars?|draft gears?|attelage"),
    "current_collection": ("Pantographs and collector shoes", "vehicle", r"pantographs?|collector shoes?|current collectors?|carbon "
                                                                       r"(strips?|contacts?)|third rail shoes?"),
    "aux_power": ("Auxiliary power and batteries", "vehicle", r"auxiliary power|\bapu\b|static converters?|motor alternators?|"
                                                              r"batter(y|ies)|low voltage power supply|\blvps\b"),
    "hep": ("Head-end power", "vehicle", r"head[- ]end power|\bhep\b"),
    "pis_passenger_info": ("Passenger information", "vehicle", r"passenger information|\bpis\b|destination signs?|public address|"
                                                               r"announcement system|next stop"),
    "cctv": ("CCTV and video", "vehicle", r"\bcctv\b|camera|video (surveillance|recorders?)|\bdvr\b|\bnvr\b"),
    "signal_onboard": ("Onboard signaling (ATC/PTC)", "vehicle", r"onboard (ptc|signal|atc|cbtc)|cab signal|carborne|\bobc\b|"
                                                                 r"\bptc\b.{0,30}(locomotive|onboard|cab car|vehicle)"),
    "interiors": ("Interiors, seating and windows", "vehicle", r"seats?\b|seating|upholster|flooring|interior (refurb|panels?)|"
                                                              r"windows?\b|glazing|windshields?|lighting|graffiti film"),
    "coupler_electrical": ("Jumpers and electrical couplers", "vehicle", r"jumper cables?|electrical couplers?|intercar"),
    "tilt": ("Tilt", "vehicle", r"\btilt"),
    "passenger_experience": ("Passenger experience", "vehicle", r"wi-?fi|passenger counting|\bapc\b|bike racks?|accessib"),
    # -- wayside and infrastructure
    "wayside_train_control": ("Wayside train control and signals", "wayside",
                              r"wayside|interlocking|\bcbtc\b|automatic train (control|protection|supervision)|\batc\b|\batp\b|\bats\b|"
                              r"signal(s|ing|ling)? (system|upgrade|replacement|modernization|maintenance)|positive train control|"
                              r"\bptc\b|track circuits?|axle counters?|switch machines?|signal houses?|train control"),
    "grade_crossings": ("Grade crossings", "wayside", r"grade crossings?|highway[- ]rail crossings?|railroad crossings?|crossing "
                                                      r"(gates?|signals?|equipment|warning|surfaces?)|level crossings?|gate arms?"),
    "track": ("Track, rail and ties", "wayside", r"\btrack (renewal|rehab|replacement|work|maintenance|construction)|\brail "
                                                 r"(replacement|renewal|grinding|welding)|crossties?|\bties\b|ballast|fasteners?|"
                                                 r"rail grinding|track geometry|tamping|surfacing"),
    "special_trackwork": ("Switches and special trackwork", "wayside", r"special trackwork|turnouts?|switch(es)? (replacement|panels?|"
                                                                      r"points?)|frogs?\b|crossovers?|diamonds?\b"),
    "structures": ("Bridges, tunnels and structures", "wayside", r"bridges?|tunnels?|viaducts?|retaining walls?|trestles?|culverts?|"
                                                                 r"aerial structures?"),
    "ocs_catenary": ("Overhead contact system / catenary", "wayside", r"catenary|overhead contact|\bocs\b|overhead (line|wire)|"
                                                                     r"contact wire|messenger wire"),
    "third_rail": ("Third rail / contact rail", "wayside", r"third rail|contact rail|cover boards? (for|on|over) (the )?(third|contact) rail"),
    "substations": ("Traction power substations", "wayside", r"substations?|traction power|rectifiers?|switchgear|\btpss\b"),
    "communications": ("Radio and communications", "wayside", r"radio|communications? (system|network|backbone)|fiber optic|"
                                                              r"\bscada\b|\bcad/avl\b|\bavl\b|telecom"),
    "fare_collection": ("Fare collection", "wayside", r"fare (collection|system|gates?|vending)|ticket vending|validators?"),
    # -- facilities and shop
    "shop_equipment": ("Shop equipment", "facilities", r"wheel truing|underfloor lathe|drop tables?|car hoists?|lifting jacks?|"
                                                       r"car ?wash|train wash|test benches?|turntables?|sanding (system|towers?)|"
                                                       r"pit lifts?|bogie wash"),
    "stations": ("Stations and platforms", "facilities", r"\bstations?\b(?! wagon)|platforms?|elevators?|escalators?|canop(y|ies)"),
    "yards_facilities": ("Yards and maintenance facilities", "facilities", r"\byards?\b|maintenance facilit|shop buildings?|"
                                                                           r"car barns?|depots?|storage tracks?|inspection pits?"),
}
GROUPS = {"vehicle": "Vehicle", "wayside": "Wayside and infrastructure", "facilities": "Facilities and shop"}
KEYS = list(DEFS)
_RX = {k: re.compile(p, re.I) for k, (_, _, p) in DEFS.items()}

# what kind of work an award or notice is, for like-for-like comparisons
WORK_TYPES = {
    "new_vehicles": ("New vehicles", r"(purchase|procure|acquisition|order|base order|option) of (\d+ )?(new )?(rail ?cars?|lrvs?|light rail vehicles?|"
                                     r"locomotives?|coaches|multiple units|emus?|dmus?|vehicles)|new (rail ?cars?|lrvs?|locomotives?)"),
    "overhaul": ("Overhaul / rebuild", r"overhaul|mid-?life|rebuild|re-?manufactur|refurbish|recondition|remise [àa] neuf|r[ée]vision|"
                                       r"rewind|reprofil"),
    "repair": ("Repair", r"repair|r[ée]paration|restoration|retrofit"),
    "parts": ("Parts supply", r"parts|kits?\b|supply of|acquisition (de|d')|achat|purchase of|spares?|pi[èe]ces|inventory"),
    "maintenance": ("Maintenance services", r"maintenance|operations and maintenance|o&m|inspection services|cleaning|entretien"),
    "construction": ("Construction / installation", r"construction|install|replacement|renewal|rehabilitation|upgrade|"
                                                     r"modernization|improvements?"),
    "engineering": ("Engineering / design", r"engineering|design|consult|construction management|program management|study|"
                                            r"inspection and testing"),
}
_WT = {k: re.compile(p, re.I) for k, (_, p) in WORK_TYPES.items()}


def tag(text):
    """Subsystem keys whose pattern appears in text."""
    t = text or ""
    return {k for k, rx in _RX.items() if rx.search(t)}


def work_type(text):
    """The first matching work type (order above is most specific first), or None."""
    t = text or ""
    return next((k for k, rx in _WT.items() if rx.search(t)), None)


def merge(existing, text):
    """existing ';'-joined subsystems plus the ones tag(text) finds, ';'-joined, in DEFS order."""
    have = {s for s in (existing or "").split(";") if s} | tag(text)
    return ";".join([k for k in KEYS if k in have] + sorted(have - set(KEYS)))


def sync(c):
    """Writes DEFS and WORK_TYPES to bids.db, where the site reads labels, groups and patterns. Rows added there by hand
    (keys not in DEFS) are kept."""
    c.executescript("""CREATE TABLE IF NOT EXISTS subsystem_def (key TEXT PRIMARY KEY, label TEXT, grp TEXT, pattern TEXT, kind TEXT DEFAULT 'subsystem');""")
    c.executemany("INSERT INTO subsystem_def (key, label, grp, pattern, kind) VALUES (?,?,?,?, 'subsystem') ON CONFLICT(key) DO UPDATE "
                  "SET label=excluded.label, grp=excluded.grp, pattern=excluded.pattern, kind='subsystem'",
                  [(k, l, g, p) for k, (l, g, p) in DEFS.items()])
    c.executemany("INSERT INTO subsystem_def (key, label, grp, pattern, kind) VALUES (?,?,?,?, 'work_type') ON CONFLICT(key) DO UPDATE "
                  "SET label=excluded.label, pattern=excluded.pattern, kind='work_type'",
                  [(k, l, None, p) for k, (l, p) in WORK_TYPES.items()])
    c.commit()


def retag(c):
    """Adds pattern subsystems to every notice and award (never removes any). Returns (notices changed, awards changed)."""
    sync(c)
    extra = {r[0]: re.compile(r[1], re.I) for r in c.execute("SELECT key, pattern FROM subsystem_def WHERE kind='subsystem' "
                                                              "AND pattern IS NOT NULL AND pattern != ''") if r[0] not in DEFS}
    out = []
    for table, key, text_cols in (("notice", "notice_id", "title, description, summary"), ("award", "award_id", "title, notes")):
        n = 0
        for r in c.execute(f"SELECT {key}, subsystems, {text_cols} FROM {table}").fetchall():
            text = " ".join(str(r[i] or "") for i in range(2, len(r.keys())))
            new = merge(r["subsystems"], text)
            more = [k for k, rx in extra.items() if rx.search(text) and k not in new.split(";")]
            if more:
                new = ";".join([s for s in new.split(";") if s] + more)
            if new != (r["subsystems"] or ""):
                c.execute(f"UPDATE {table} SET subsystems=? WHERE {key}=?", (new or None, r[0]))
                n += 1
        c.commit()
        out.append(n)
    return tuple(out)
