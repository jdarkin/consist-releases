"""Rule classifier (push49, Justin 11-20 "take a closer look at current scoring and categorization for accuracy and backcheck/
correct the database"). Free: rules only, no paid review.

Why: the Claude review is the only step that set a category, and it only sees notices whose keyword score reaches 20. So 9,959
keyword-only and historical notices had no category, and mixed bus-and-rail agencies (SEPTA ePS, DART) that post terse part
line items ("SHUNT GE 12B115984G1 CABLE ASSEMBLY", "RELAY,2/HSCBCP") sat at 0 to 18 however clearly rail they were.

decide(title, description, agency_id) returns (rail, category, relevance, why) or None when the rules have nothing to say:
  rail 1  rail evidence (rail vehicle, part, maker or system words; a rail-only agency; a rail-capable agency plus track /
          station / signal words). Category from CATS (English and French), relevance at least the category's floor.
  rail 0  bus, road, office or corporate work. Relevance capped at 15, category and subsystems cleared.
  rail None  a bus-and-rail agency's part line item that names neither: parts_supply (or component_repair) at 30, below the
          50 line the site and alerts use.
run(c) applies it to every notice the Claude review has not judged, and cleans subsystem tags off notices that are not rail.
Claude's own scores and categories are kept: the 11-20 sample found them right. Every change is noted in notice.class_note
(old values kept) and newly visible notices are marked notified so no burst of old alerts goes out.
"""
import re

import bidcore as bc


def rx(p):
    return re.compile(p, re.I)


RAIL_ONLY = {"AMTRAK", "METRA", "NICTD", "VRE", "VPRA", "METROLINK", "LOSSAN", "CALTRAIN", "SFRTA", "SUNRAIL", "PATCO", "SMART", "ACE",
             "SJJPA", "CCJPA", "VALLEYLINK", "VIA", "BRIGHTLINE", "ARRC", "NNEPRA", "RIOMETRO", "CHSRA", "ONTC"}
# agencies that run rail as well as buses, whose agency_id really is that agency (statewide or city portals such as UTA, CATS,
# DTC_QLINE and EMBARK_OKC carry every city purchase, so they are not here)
RAIL_CAPABLE = {"SEPTA", "DART", "MBTA", "NJT", "LAMETRO", "WMATA", "MARTA", "RTD", "TRIMET", "SOUNDTRANSIT", "CTA", "GCRTA", "PAAC",
                "MDT", "MDTPW", "VTA", "SFMTA", "STM", "EXO", "TTC", "TRANSLINK", "OCTRANSPO", "METROLINX", "MTA", "NFTA", "MATA",
                "HRT", "METRO_MN", "NOLA_RTA", "METRO_HOU", "KCSC", "SDMTS", "MTS", "SACRT", "BSTA", "TPT", "PRT", "MUNI", "RTC_QC_TRAM"}

# rail evidence that holds whoever the buyer is
RAIL_STRONG = rx(
    r"\brail ?cars?\b|\brailcars?\b|\blrvs?\b|light rail|\bstreetcars?\b|\btrolley ?(cars?|wire|poles?)\b|\blocomotives?\b|\bloco\b|"
    r"\bcab cars?\b|\bbi-?level|multi-?level (car|coach)|commuter (rail|car|coach)|passenger (rail ?)?cars?\b|\bcoach(es)? (car|fleet)|"
    r"\b(emu|dmu)s?\b|rolling stock|\btrainsets?\b|\bsubway\b|\bmetro (car|station|line|system)s?|\bmonorail(?! (crane|hoist|beam|track system|system for))|people mover|"
    r"\brailroad|\brailway|\bamtrak\b|regional rail|\bmarket[- ]frankford|broad street line|norristown high speed|"
    r"\bsilverliners?\b|\bsl ?iv\b|\bsliv\b|\bsilv\b|\bbiv\b|\bn-?5\b|\bf59|\balp-?45|\bmp36|\bgp-?\d\d\b|\bsc-?44|\bals-?42|\bp42\b|"
    r"\bacs-?64|\bemd\b|\bkawasaki\b|\bmelco\b|\bsepsa\b|\bfaiveley\b|\bknorr\b|\bwabtec\b|\bwestcode\b|\bvapor\b|\bdellner\b|"
    r"\bschaltbau\b|\bnyab\b|new york air brake|\bkinki sharyo\b|\bnippon sharyo\b|\bhyundai rotem\b|\bansaldo|\bbreda\b|"
    r"\bbrookville\b|\bstadler\b|\bnissho-?iwai\b|\bhscb|\bpantograph|collector shoes?|third rail|contact rail|\bbolsters?\b|"
    r"\bbogies?\b|\bwheel ?sets?\b|journal (bearing|box)|draft gear|\btread brake|brake pipe|head[- ]end power|traction motors?|"
    r"motopropulsion|buffer sill|brush ?holders?|\bcatenary|overhead contact|"
    r"messenger (wire|cable)|splice,? ?messenger|contact wire|traction power|\btpss\b|\bcbtc\b|positive train control|"
    r"\bptc\b|interlocking|grade crossings?|crossing (gates?|arms?)|track circuits?|switch machines?|cab signal|passages? [àa] niveau|"
    r"rail (grinding|welding|anchors?|joints?|bonds?|fasteners?|ties?|replacement|renewal|corridor|bridges?|yard|station|line|"
    r"extension|project|infrastructure|systems?)\b|crossties|turnouts?|special trackwork|bridge timbers?|"
    r"\bvarious rail\b|\b(115|119|132|136|140|141) ?(lb|re)\b|"
    # French
    r"\bm[ée]tro\b|ferroviaires?|\btramways?\b|\btrains?\b|locomotives?|voitures? (de m[ée]tro|de train|de passagers|multiniveaux)|"
    r"\brames?\b|\bmr-?(63|73)\b|\bazur\b|\bvlr\b|cat[ée]naire|moteurs? de traction|ensembles? de roues|bogies?|"
    r"(?<!service du )mat[ée]riel roulant|centre de maintenance (lachine|pointe|sainte|st)|\bgares?\b(?! (d.autobus|routi|maritime|fluviale))")
# GE / Westinghouse transit part numbers, SEPTA drawings and the like: rail evidence only at a rail-capable agency
RAIL_PART_NO = rx(r"\b(600|650|750) ?(v|volts?|vdc)\b|\b(12|25) ?kv\b|\bge (drwg |dwg )?\d{1,2}[a-z][0-9a-z]{4,}|\bferraz\b|\bge n\d{3}|\bge \d{7}p\d|\bwe \d{3,4}a\d|\bwab(co)? \d{4,}|\bwgs \d{4,}")
# rail context words that only count at a rail-only or rail-capable agency
RAIL_WEAK = rx(r"\btrack\b(?!ing)|\bties\b|\bsignal(s|ing|ling)?\b|\bstations?\b(?! wagon)|platforms?|\byards?\b|switch(es)? (heater|point)|"
               r"\btunnels?\b|\bswitches\b|\brails?\b|\bvoies? (?!r[ée]serv)|\bquais?\b|\bedicules?\b|signalisation(?! routi)|\bposte de district\b|"
               r"centre d'entretien|\bateliers?\b|garages? (de|du) m[ée]tro|\broues\b")
BUS = rx(r"\bbus(es)?\b|\bautobus\b|\bminibus|\bmini[- ]?trains?\b|petits? trains?|balade|\bgillig\b|new flyer|\bnova ?bus\b|\bproterra\b|\bel ?dorado\b|\barboc\b|\ballison\b|"
         r"\bcummins\b|\bexhaust\b|\bparatransit\b|\bwheelchair (ramp|lift)|\bkneel|\bfarebox|\bmotor ?coach|\bvans?\b|\bsedans?\b|"
         r"\bpickups?\b|\bpolice\b|\bf-?150\b|\bdriver seat|si[èe]ges? (de )?chauffeurs?|v[ée]hicules? de service|\bcamions?\b|"
         r"\btracteurs?\b|souffleuse|chassis cabs?|ch[âa]ssis|\bknuckle ?boom|\bdump trucks?|\bfire (truck|apparatus)|\btransmissions?\b(?! line)|"
         r"\bv[ée]los?\b|bicycles?|\bpiste cyclable|\bcyclable")
NOT_RAIL = rx(r"janitorial|landscap|legal services|\baudit(ing|or)?\b|insurance|banking|advertising|marketing|uniforms?|security guard|"
              r"pest control|snow removal|parking (lot|garage|enforcement)|office supplies|furniture|printing|catering|"
              r"\bcomputers?\b|laptops?|software|licen[cs]es?\b|microsoft|\boracle\b|\bibm\b|toner|copier|staffing|recruit|"
              r"employee assistance|medical|hospital|drug (and|&) alcohol|courier|\bhighway\b|\broadway\b|interstate|pavement|paving|"
              r"sidewalk|bike lane|traffic signal|airport|runway|taxiway|watershed|wastewater|storm ?water|sewer|school|"
              r"\bvoip\b|cloud|cyber|training (services|courses?|simulator)|vocational|electron microscope|\bmri\b|"
              r"informatique|logiciel|bureautique|applicati(ve|on)s?\b|juridique|recrutement|\bformation\b|entretien m[ée]nager|d[ée]neigement|sel de d[ée]gla[çc]age|"
              r"aqueduc|[ée]gouts?|\bparcs?\b|chauss[ée]e|m[ée]dias?|t[ée]l[ée]phonie|papier hygi[ée]nique|plomberie|"
              r"\bnaics (334|335|541[56]|5112|5182|6|7|8112)")
GENERIC = rx(r"elevated highways|highways, roads|roads, railways|subways and railroads")
CORPORATE = rx(r"\baudit(ing|or)?\b|advertising|marketing|m[ée]dias?\b|affichage|insurance|assurances?\b|legal services|juridique|"
               r"software|logiciel|licen[cs]es?\b|informatique|recrutement|recruit|financiers|financial services|banking|"
               r"police|policiers|paramedic|param[ée]dic|catering|traiteur|armou?red car|mobile offices?|r[ée]mun[ée]ration")
PART_LINE = rx(r"\bparts?\b|\bpi[èe]ces?\b|\bassy\b|\bassembly\b|\basm\b|\bkit\b|\bbushings?\b|\bbearings?\b|\bgaskets?\b|\bseals?\b|"
               r"\bvalves?\b|\bshunts?\b|\bcapacitors?\b|\bresistors?\b|r[ée]sistances?\b|\bcontactors?\b|\brelays?\b|\bswitch\b|\bbrackets?\b|"
               r"\bsprings?\b|\bhoses?\b|\bfilters?\b|\bsensors?\b|\bcables?\b|\bconnectors?\b|\bsplices?\b|\bclamps?\b|\bbolts?\b|"
               r"\bnuts?\b|\bscrews?\b|\bwashers?\b|\bshims?\b|\bshoes?\b|\bpads?\b|\bmotors?\b|\bmodules?\b|\bfuses?\b|"
               r"\binsulators?\b|\bhangers?\b|\bpins?\b|\blatch(es)?\b|\bcovers?\b|\bbreakers?\b|\bterminals?\b|\bigbt\b|"
               r"\bsleeves?\b|\bshafts?\b|\btubes?\b|\bgates?\b|\bshields?\b|\bthresholds?\b|\bhoods?\b|\bcoils?\b|\bactuators?\b|\bplugs?\b|"
               r"\blevers?\b|\bhorns?\b|\bpanels?\b|\bseats?\b|\bdevices?\b|\bspec s-\d")
REPAIR = rx(r"\brepair|\boverhaul|\brebuild|\bre-?manufactur|\brecondition|\bunit exchange|\bexchange program|\brefurbish|"
            r"r[ée]paration|remise [àa] neu|reconditionnement|\br[ée]vision\b")

# (category, pattern, relevance floor); first match wins
CATS = [
    ("vehicle_procurement", rx(r"(purchase|procure\w*|acquisition|acquire|manufacture|base order|option|lease) (of |for )?(\d+ |new |used |"
                               r"additional |design and production of )*(flat )?(rail ?cars?|railcars|lrvs?|light rail vehicles?|locomotives?|"
                               r"coaches|cab cars?|multiple units?|emus?|dmus?|streetcars?|passenger cars?|trainsets?|rolling stock)|"
                               r"\bnew (rail ?cars?|lrvs?|locomotives?|streetcars?|trainsets?)\b|"
                               r"acquisition de (\d+ )?(nouvelles? )?(voitures|trains|locomotives|rames|v[ée]hicules l[ée]gers sur rail)"), 75),
    ("overhaul_program", rx(r"(overhaul|mid-?life|rebuild|remanufactur\w*|refurbish\w*|recondition\w*|re-?power\w*) (of |program |for )?"
                            r"(the )?(\d+ )?(rail ?cars?|railcars|lrvs?|light rail vehicles?|locomotives?|coaches|cab cars?|streetcars?|"
                            r"silverliners?)|(rail ?car|railcar|lrv|locomotive|coach) (overhaul|rebuild|refurbishment|mid-?life)|"
                            r"(r[ée]vision|remise [àa] neuf|r[ée]fection|reconditionnement) (de |des )(voitures|locomotives|rames|trains)"), 75),
    ("onboard_systems", rx(r"passenger information|\bpis\b|destination signs?|onboard (camera|cctv|video|ptc|signal)|event recorders?|"
                           r"audio/video|\bapc\b|automatic passenger count|\btcms\b|cab signal|carborne|information (aux )?voyageurs"), 70),
    ("shop_equipment", rx(r"wheel truing|underfloor lathe|drop tables?|car hoists?|lifting jacks?|(car|train|rail) wash|test benches?|"
                          r"turntables?|sanding (system|tower)|pit lifts?|bogie wash|tour en fosse|v[ée]rins?"), 65),
    ("cleaning_interior", rx(r"(car|railcar|train|coach) (cleaning|interior)|upholster|toilet pumping|graffiti|nettoyage des voitures"), 60),
    ("traction_power", rx(r"catenary|cat[ée]naire|overhead contact|\bocs\b|messenger|contact wire|trolley wire|third rail|contact rail|"
                          r"traction power|\btpss\b|substations?|sous-stations?|rectifiers?|electrification|[ée]lectrification|"
                          r"negative return|cover boards?|poste de district|postes? de redressement|\b(12|25) ?kv\b"), 70),
    ("signals_communications", rx(r"\bsignal(s|ing|ling)?\b(?! mast)|signalisation(?! routi)|interlocking|enclenchements?|\bcbtc\b|positive train control|"
                                  r"\bptc\b|grade crossings?|crossing (gates?|arms?|signals?)|track circuits?|axle counters?|"
                                  r"switch machines?|wayside|\bscada\b|train control|passages? [àa] niveau|contr[ôo]le des trains|impedance bonds?"), 70),
    ("track_infrastructure", rx(r"\btrack\b(?!ing)|crossties?|\bties\b|(?<!sans )ballast\b|turnouts?|special trackwork|\bfrogs?\b|"
                                r"rail (anchors?|clips?|joints?|bonds?|grinding|welding|replacement|renewal|fasteners?|sale)|"
                                r"\bscrap rail|joint bars?|tie plates?|thermite|bridge timbers?|ponts? ferroviaires?|rail(road|way)? bridges?|"
                                r"right[- ]of[- ]way|corridor ferroviaire|\bvoies?\b(?! r[ée]serv)|aiguillages?|fourniture de rails|traverses|\bvarious rail\b|"
                                r"\b(115|119|132|136|140|141) ?(lb|re)\b"), 70),
    ("stations_facilities", rx(r"\bstations?\b(?! wagon)|platforms?|\bquais?\b|\bgares?\b(?! (d.autobus|routi))|\byards?\b|maintenance (facilit|center|centre)|"
                               r"centre (de maintenance|d'entretien)|car barns?|\bdepots?\b|elevators?|escalators?|ascenseurs?|"
                               r"escaliers m[ée]caniques|canop(y|ies)|[ée]dicules?|garages? (de|du) m[ée]tro|\bateliers?\b|maintenance shops?"), 60),
    ("rail_operations", rx(r"operations? and maintenance|\bo&m\b|operat(e|ion|ing) (of )?(the )?(rail|train|streetcar|light rail|commuter|"
                           r"regional rail)|contract operat|exploitation (du|des) (train|tramway|m[ée]tro)"), 65),
    ("maintenance_services", rx(r"(fleet|vehicle|railcar|rail car|locomotive|lrv) maintenance|maintenance (of|and supply of|services)|"
                                r"entretien (pr[ée]ventif|correctif)? ?(des|de) (voitures|locomotives|rames|trains)|services de maintenance"), 65),
    ("component_repair", REPAIR, 70),
    ("engineering_support", rx(r"(fleet|vehicle|railcar|rolling stock|bogie|truck) (engineering|inspection|condition|technical support|"
                               r"reliability)|[ée]valuation de l'[ée]tat"), 60),
    ("rail_engineering", rx(r"engineering|design services|design-build|construction management|program management|inspection services|"
                            r"consult(ing|ant)|feasibility|environmental (review|assessment)|on-?call|architect\w*|\bae\b|\ba&e\b|"
                            r"services professionnels|ing[ée]nierie|\bg[ée]nie\b|plans et devis|surveillance des travaux"), 60),
]
VEHICLE_CATS = {"vehicle_procurement", "overhaul_program", "component_repair", "parts_supply", "maintenance_services", "onboard_systems",
                "shop_equipment", "cleaning_interior", "engineering_support"}


def text_of(title, description):
    return f"{title or ''} {(description or '')[:400]}"


def decide(title, description, agency_id, notice_type=None):
    """(rail, category, relevance, why) or None. See the module docstring."""
    t = " ".join(text_of(title, description).split())
    ag = (agency_id or "").upper()
    capable = ag in RAIL_CAPABLE or ag in RAIL_ONLY
    strong = RAIL_STRONG.search(t if capable else " ".join((title or "").split()))
    partno = RAIL_PART_NO.search(t) if capable else None
    weak = RAIL_WEAK.search(t) if capable else None
    busw = BUS.search(t)
    if not strong and not partno:
        no = NOT_RAIL.search(t)
        if no:
            return (0, None, 10, f"not rail: {no.group(0)}")
        if busw:
            return (0, None, 10, f"bus/road vehicle: {busw.group(0)}")
    elif busw and not partno and strong and strong.group(0).lower() in ("train", "trains") and ag not in RAIL_ONLY:
        return (0, None, 10, f"bus/road vehicle: {busw.group(0)}")  # "formation des chauffeurs d'autobus ... train"
    ev = strong or partno or weak
    if GENERIC.search(t):
        return None  # federal commodity headings ("Bridges, Elevated Highways, Tunnels, Subways and Railroads")
    corp = CORPORATE.search(t)
    if (ev or ag in RAIL_ONLY) and corp:
        return (1, "other", 40, f"rail {'evidence ' + ev.group(0) if ev else 'agency ' + ag} but corporate service: {corp.group(0)}")
    if ev or ag in RAIL_ONLY:
        why = f"rail evidence: {ev.group(0)}" if ev else f"rail-only agency {ag}"
        partish = bool(PART_LINE.search(t))
        for cat, p, floor in CATS:
            m = p.search(t)
            if not m:
                continue
            if cat == "component_repair" and not (partish or strong or partno):
                continue
            return (1, cat, floor, f"{why}; {cat}: {m.group(0)}")
        if partish or partno:
            return (1, "parts_supply", 65, f"{why}; parts")
        return (1, "other", 50, why)
    if ag in RAIL_CAPABLE and PART_LINE.search(t) and len((title or "")) <= 160:
        return (None, "component_repair" if REPAIR.search(t) else "parts_supply", 30, f"{ag} part line item, bus or rail not stated")
    return None


def ensure(c):
    have = {r[1] for r in c.execute("PRAGMA table_info(notice)")}
    if "class_note" not in have:
        c.execute("ALTER TABLE notice ADD COLUMN class_note TEXT")


def plan(c):
    """[(notice_id, rail, category, relevance, subsystems, why, old_relevance)] for every notice whose stored values the rules would
    change. Does not write."""
    ensure(c)
    out = []
    try:
        import hygiene
        cap = hygiene.capped
    except Exception:
        cap = lambda text, score: score
    for r in c.execute("SELECT notice_id, agency_id, title, description, notice_type, reviewed, relevance, rail, category, subsystems, "
                       "class_note FROM notice WHERE coalesce(reviewed,'') != 'manual'").fetchall():
        old = (r["rail"], r["category"], r["relevance"], r["subsystems"])
        if r["reviewed"] == "claude" or (r["reviewed"] or "") == "research":
            # the review stands; only rail subsystem tags on notices it called not rail and below 30 are cleared
            if r["rail"] == 0 and (r["relevance"] or 0) < 50 and r["subsystems"]:
                out.append((r["notice_id"], r["rail"], r["category"], r["relevance"], None, "not rail: subsystem tags cleared", r["relevance"]))
            continue
        if r["relevance"] is None and not r["reviewed"]:
            continue  # not keyword-scored yet: review() scores it first, then calls run()
        d = decide(r["title"], r["description"], r["agency_id"], r["notice_type"])
        rel0 = r["relevance"] or 0
        if d is None:
            if rel0 < 50 and r["subsystems"] and not r["rail"]:
                out.append((r["notice_id"], r["rail"], r["category"], r["relevance"], None, "no rail evidence: subsystem tags cleared", r["relevance"]))
            continue
        rail, cat, floor, why = d
        if rail == 1:
            new = (1, cat, cap(f"{r['title'] or ''} {(r['description'] or '')[:600]}", max(rel0, floor)), r["subsystems"])
        elif rail == 0:
            new = (0, None, min(rel0, floor) if r["relevance"] is not None else floor, None)
        else:
            new = (None, cat, min(max(rel0, floor), 45), None if rel0 < 30 else r["subsystems"])
        if new != old:
            out.append((r["notice_id"],) + new + (why, r["relevance"]))
    return out


def run(c, dry=False):
    """Applies plan(). Returns counts."""
    p = plan(c)
    out = {"categorized": 0, "raised to 50+": 0, "lowered (not rail)": 0, "subsystem tags cleared": 0, "changed": len(p)}
    now = bc.now()
    for nid, rail, cat, rel, subs, why, old in p:
        if "subsystem tags cleared" in why:
            out["subsystem tags cleared"] += 1
        elif rail == 0:
            out["lowered (not rail)"] += 1
        else:
            out["categorized"] += 1
            if (old or 0) < 50 <= (rel or 0):
                out["raised to 50+"] += 1
        if dry:
            continue
        c.execute("UPDATE notice SET rail=?, category=?, relevance=?, subsystems=?, "
                  "class_note=? || ' (was rel ' || coalesce(relevance,'-') || ', cat ' || coalesce(category,'-') || ', rail ' || "
                  "coalesce(rail,'-') || ', subs ' || coalesce(subsystems,'-') || ')', "
                  "notified=CASE WHEN ? >= 50 AND coalesce(relevance,0) < 50 AND coalesce(first_seen,'') < datetime('now','-2 days') "
                  "THEN coalesce(notified, ?) ELSE notified END WHERE notice_id=?",
                  (rail, cat, rel, subs, f"rules {now[:10]}: {why}"[:300], rel or 0, now, nid))
    if not dry and p:
        bc_log = getattr(bc, "log", None)
        c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
                  (now, bc.now(), "classify", "done", len(p), out["raised to 50+"], 0, "; ".join(f"{k} {v}" for k, v in out.items())))
        c.commit()
        if bc_log:
            bc_log("classify: " + "; ".join(f"{k} {v}" for k, v in out.items()))
    return out


def undo(c):
    """Restores the values noted in class_note (rel, cat, rail, subs) for every rules change."""
    n = 0
    for r in c.execute("SELECT notice_id, class_note FROM notice WHERE class_note LIKE 'rules %'").fetchall():
        m = re.search(r"\(was rel (.*?), cat (.*?), rail (.*?), subs (.*)\)$", r["class_note"] or "")
        if not m:
            continue
        v = [None if x == "-" else x for x in m.groups()]
        c.execute("UPDATE notice SET relevance=?, category=?, rail=?, subsystems=?, class_note=NULL WHERE notice_id=?",
                  (int(float(v[0])) if v[0] else None, v[1], int(v[2]) if v[2] else None, v[3], r["notice_id"]))
        n += 1
    c.commit()
    return n


def audit(c):
    """Population measures for `bidmon classify --audit` (before / after a run)."""
    q = lambda s: c.execute(s).fetchone()[0]
    return {
        "notices": q("SELECT count(*) FROM notice"),
        "no category, relevance 50+": q("SELECT count(*) FROM notice WHERE category IS NULL AND relevance >= 50"),
        "no category, any": q("SELECT count(*) FROM notice WHERE category IS NULL"),
        "open, no category": q("SELECT count(*) FROM notice WHERE category IS NULL AND (closing >= date('now') OR closing IS NULL) "
                               "AND coalesce(notice_type,'') NOT IN ('award','cancelled')"),
        "visible (50+)": q("SELECT count(*) FROM notice WHERE relevance >= 50"),
        "rail=1 below 50": q("SELECT count(*) FROM notice WHERE rail = 1 AND relevance < 50"),
        "not rail with subsystem tags": q("SELECT count(*) FROM notice WHERE coalesce(rail,0) = 0 AND relevance < 50 AND subsystems IS NOT NULL"),
        "SEPTA/DART open, no category": q("SELECT count(*) FROM notice WHERE agency_id IN ('SEPTA','DART') AND category IS NULL "
                                          "AND (closing >= date('now') OR closing IS NULL)"),
    }
