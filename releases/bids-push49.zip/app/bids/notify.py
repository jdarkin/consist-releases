"""Email alerts. Each subscriber in config.json has rules:
  mode: immediate | daily | weekly | off      min_score: 0-100      countries: ["US", "CA"]
  agencies: [agency_id...] (empty = all)      categories: [category...] (empty = all)
  keywords: [words...] (any must appear; empty = no keyword filter)      include_bus: false
  awards: true (also send award notices)      admin: true (gets system notices: verifications to finish by hand, errors)
"""
import datetime, html, json, smtplib, ssl
from email.message import EmailMessage

import bidcore as bc


def send(to, subject, html_body, text_body):
    s = bc.sender()
    password = open(s["password_file"]).read().strip()
    msg = EmailMessage()
    msg["From"] = f"{s['from_name']} <{s['address']}>"
    msg["To"] = to
    if s.get("reply_to"):
        msg["Reply-To"] = s["reply_to"]
    msg["Subject"] = subject
    msg.set_content(text_body)
    msg.add_alternative(html_body, subtype="html")
    ctx = ssl.create_default_context()
    if int(s["smtp_port"]) == 465:
        with smtplib.SMTP_SSL(s["smtp_host"], 465, context=ctx, timeout=60) as smtp:
            smtp.login(s["address"], password)
            smtp.send_message(msg)
        return
    with smtplib.SMTP(s["smtp_host"], int(s["smtp_port"]), timeout=60) as smtp:
        smtp.starttls(context=ctx)
        smtp.login(s["address"], password)
        smtp.send_message(msg)


def matches(sub, n):
    if n["notice_type"] == "award" and not sub.get("awards", True):
        return False
    if (n["relevance"] or 0) < int(sub.get("min_score", 60)):
        return False
    if n["rail"] == 0 and not sub.get("include_bus"):
        return False
    if sub.get("countries") and n["country"] and n["country"] not in sub["countries"]:
        return False
    if sub.get("agencies") and n["agency_id"] not in sub["agencies"]:
        return False
    if sub.get("categories") and n["category"] not in sub["categories"]:
        return False
    if sub.get("keywords"):
        t = f"{n['title']} {n['description'] or ''} {n['summary'] or ''}".lower()
        if not any(k.lower() in t for k in sub["keywords"]):
            return False
    return True


def render(rows, heading):
    def esc(x):
        return html.escape(str(x or ""))
    trs = []
    lines = [heading, ""]
    for n in rows:
        when = f"closes {n['closing']}" if n["closing"] else ""
        kind = {"award": "Award", "planned": "Upcoming", "addendum": "Addendum", "cancelled": "Cancelled"}.get(n["notice_type"], "Bid")
        link = f'<a href="{esc(n["url"])}">{esc(n["title"])}</a>' if n["url"] else esc(n["title"])
        trs.append(f"<tr><td style='padding:6px 8px;vertical-align:top'><b>{esc(n['agency'])}</b><br>"
                   f"<span style='color:#666'>{kind} {esc(n['ref_no'])}</span></td>"
                   f"<td style='padding:6px 8px;vertical-align:top'>{link}<br><span style='color:#444'>{esc(n['summary'])}</span></td>"
                   f"<td style='padding:6px 8px;vertical-align:top;white-space:nowrap'>{esc(when)}<br>score {n['relevance']}</td></tr>")
        lines.append(f"- [{kind}] {n['agency']}: {n['title']} {('(' + when + ')') if when else ''}\n  {n['summary'] or ''}\n  {n['url'] or ''}")
    body = (f"<div style='font-family:Arial,sans-serif;font-size:14px'><h2 style='font-size:17px'>{esc(heading)}</h2>"
            f"<table style='border-collapse:collapse' border='1' bordercolor='#ddd'>{''.join(trs)}</table>"
            f"<p style='color:#888;font-size:12px'>Consist bid alerts (consist-na.com). Change what you receive in Consist Admin › Bid Catcher.</p></div>")
    return body, "\n".join(lines)


def pending(c, since=None):
    q = ("SELECT n.*, coalesce(a.agency, n.buyer) AS agency FROM notice n LEFT JOIN agency a USING (agency_id) "
         "WHERE n.relevance IS NOT NULL")
    try:  # repeated notices (hygiene.dup_of) and notices already closed when first seen never go out as new
        import hygiene
        hygiene.ensure(c)
        q += " AND n.dup_of IS NULL AND coalesce(n.hygiene_note,'') != 'closed_on_arrival'"
    except Exception:
        pass
    if since:
        return c.execute(q + " AND n.first_seen >= ? ORDER BY n.relevance DESC", (since,)).fetchall()
    return c.execute(q + " AND n.notified IS NULL ORDER BY n.relevance DESC").fetchall()


def logsend(c, sub, kind, ids, err=None):
    c.execute("INSERT INTO notify_log (ts, subscriber, kind, notice_ids, ok, error) VALUES (?,?,?,?,?,?)",
              (bc.now(), sub.get("email"), kind, ",".join(map(str, ids)), int(err is None), err))


def immediate(c):
    """Sends new matching notices to every immediate subscriber; marks them notified."""
    rows = pending(c)
    if not rows:
        return 0
    sent = 0
    for sub in bc.settings()["subscribers"]:
        if not sub.get("active", True) or sub.get("mode") != "immediate" or not sub.get("email"):
            continue
        mine = [n for n in rows if matches(sub, n)]
        if not mine:
            continue
        heading = f"{len(mine)} new rail maintenance bid{'s' if len(mine) > 1 else ''}" if len(mine) > 1 else f"New: {mine[0]['agency']}: {mine[0]['title']}"
        try:
            send(sub["email"], heading[:150], *render(mine, heading))
            logsend(c, sub, "immediate", [n["notice_id"] for n in mine])
            sent += 1
        except Exception as e:
            logsend(c, sub, "immediate", [n["notice_id"] for n in mine], str(e)[:300])
            bc.log(f"notify: sending to {sub['email']} failed: {e}")
    c.executemany("UPDATE notice SET notified=? WHERE notice_id=?", [(bc.now(), n["notice_id"]) for n in rows])
    c.commit()
    return sent


def digest(c, mode):
    days = 1 if mode == "daily" else 7
    since = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
    rows = pending(c, since)
    sent = 0
    for sub in bc.settings()["subscribers"]:
        if not sub.get("active", True) or sub.get("mode") != mode or not sub.get("email"):
            continue
        mine = [n for n in rows if matches(sub, n)]
        if not mine:
            continue
        heading = f"Rail maintenance bids: {len(mine)} new in the last {'day' if days == 1 else 'week'}"
        try:
            send(sub["email"], heading, *render(mine, heading))
            logsend(c, sub, "digest", [n["notice_id"] for n in mine])
            sent += 1
        except Exception as e:
            logsend(c, sub, "digest", [n["notice_id"] for n in mine], str(e)[:300])
    c.commit()
    return sent


def system(c, subject, text):
    """A notice for admin subscribers (e.g. a verification that needs a human)."""
    for sub in bc.settings()["subscribers"]:
        if sub.get("admin") and sub.get("email") and sub.get("active", True):
            try:
                send(sub["email"], f"[Bid Catcher] {subject}", f"<pre style='font-family:Arial,sans-serif'>{html.escape(text)}</pre>", text)
                logsend(c, sub, "system", [])
            except Exception as e:
                logsend(c, sub, "system", [], str(e)[:300])
    c.commit()


def test(c, to=None):
    to = to or next((s["email"] for s in bc.settings()["subscribers"] if s.get("email")), None)
    if not to:
        raise SystemExit("No subscriber email set: add one on the Bids settings page or in data/bids/config.json")
    rows = c.execute("SELECT n.*, coalesce(a.agency, n.buyer) AS agency FROM notice n LEFT JOIN agency a USING (agency_id) "
                     "ORDER BY relevance DESC LIMIT 5").fetchall()
    send(to, "Consist bid alerts: test message", *render(rows, "Test message: mail settings work. Top notices in the database right now:"))
    logsend(c, {"email": to}, "test", [n["notice_id"] for n in rows])
    c.commit()
    return to
