"""Agency contract and award pages (board agendas, "contracts awarded" lists, contract registers), and researched awards.

No Claude calls here. Pages are fetched politely (robots.txt honoured by bidcore.fetch), hashed, and a changed page is
listed in the Monday checklist email so the change can be reviewed in the Claude app, not by the API.

  bidmon contract-pages --load FILE.csv     add pages (agency_id,url,kind,format,notes)
  bidmon contract-pages                     check every page once; prints changed ones
  bidmon load-research FILE.csv             add researched awards (agency_id,award_date,title,vendor,amount,currency,category,
                                            n_bidders,source_url,notes), skipping ones already in the awards table
"""
import csv
import datetime as dt
import os

import bidcore as bc
import sources

KIND = "contracts"  # page_watch.kind for these rows; never pruned with the bid pages, never sent to Claude
VEHICLE_CATS = {"vehicle_procurement", "overhaul_program", "component_repair", "parts_supply", "maintenance_services",
                "onboard_systems", "shop_equipment"}


def _resolve(path):
    """A data file shipped in a package sits next to this code (/app/bids); accept its bare name or an old /data path."""
    if os.path.exists(path):
        return path
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), os.path.basename(path))
    if os.path.exists(here):
        return here
    raise FileNotFoundError(path)


def ensure_retired(c):
    c.execute("CREATE TABLE IF NOT EXISTS page_retired (url TEXT PRIMARY KEY, agency_id TEXT, reason TEXT, retired TEXT)")


def retire(c, path):
    """Stops watching pages that refuse automated reading when the agency is already covered another way (alert emails
    from a portal account, an RSS feed) or the row is a stale single document or a wrong host. CSV: url,agency_id,reason.
    The page_watch row is removed and the url is remembered so loads and platform lists do not add it back.
    Returns pages retired."""
    ensure_retired(c)
    n = 0
    for r in csv.DictReader(open(_resolve(path), newline="", encoding="utf-8-sig")):
        url = (r.get("url") or "").strip()
        if not url.startswith("http"):
            continue
        c.execute("INSERT INTO page_retired (url, agency_id, reason, retired) VALUES (?,?,?,?) ON CONFLICT(url) DO UPDATE SET reason=excluded.reason",
                  (url, (r.get("agency_id") or "").strip() or None, (r.get("reason") or "").strip() or None, bc.now()))
        if url.endswith("*"):  # a prefix: every watched page under it
            n += c.execute("DELETE FROM page_watch WHERE url LIKE ? ESCAPE '\\' AND kind != 'backfill'", (url[:-1].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%",)).rowcount
        else:
            n += c.execute("DELETE FROM page_watch WHERE url=?", (url,)).rowcount
    c.commit()
    return n


def is_retired(url, gone):
    return url in gone or any(g.endswith("*") and url.startswith(g[:-1]) for g in gone)


def retired_urls(c):
    try:
        return {r[0] for r in c.execute("SELECT url FROM page_retired")}
    except Exception:
        return set()


def load_pages(c, path):
    n = 0
    gone = retired_urls(c)
    for r in csv.DictReader(open(_resolve(path), newline="", encoding="utf-8-sig")):
        url = (r.get("url") or "").strip()
        if not url.startswith("http") or is_retired(url, gone):
            continue
        cur = c.execute("INSERT OR IGNORE INTO page_watch (url, agency_id, kind) VALUES (?,?,?)", (url, r.get("agency_id") or None, KIND))
        n += cur.rowcount
    c.commit()
    return n


def watch(c, limit=None):
    """Fetches each contract page, records a change. Returns (checked, changed, blocked)."""
    rows = c.execute("SELECT url, agency_id, last_hash FROM page_watch WHERE kind=? ORDER BY coalesce(last_checked,'')", (KIND,)).fetchall()
    checked = changed = blocked = 0
    for r in rows[:limit] if limit else rows:
        checked += 1
        try:
            text, _ = sources.read_page(r["url"]) if not r["url"].lower().endswith(".pdf") else (None, None)
            if text is None:  # PDFs: hash the bytes
                raw, _, _ = bc.fetch(r["url"], timeout=90)
                text = bc.sha(raw.decode("latin-1"))
        except Exception as e:
            blocked += 1
            c.execute("UPDATE page_watch SET last_checked=?, last_error=? WHERE url=?", (bc.now(), str(e)[:300], r["url"]))
            continue
        h = bc.sha(text)
        is_new = r["last_hash"] is not None and r["last_hash"] != h
        changed += is_new
        c.execute("UPDATE page_watch SET last_hash=?, last_checked=?, last_error=NULL" + (", last_changed=?" if is_new else "") +
                  " WHERE url=?", (h, bc.now(), bc.now(), r["url"]) if is_new else (h, bc.now(), r["url"]))
        c.commit()
    return checked, changed, blocked


def prune_dead(c):
    """Drops contract-page rows that point at one document (a PDF or a dated file) and answer 404/410: a single past meeting's
    file never changes, and the meetings scanner now follows each agency's agenda listing instead."""
    rows = c.execute("SELECT url FROM page_watch WHERE kind=? AND (last_error LIKE '%404%' OR last_error LIKE '%410%')", (KIND,)).fetchall()
    n = 0
    for r in rows:
        if r["url"].lower().split("?")[0].endswith((".pdf", ".doc", ".docx")):
            n += c.execute("DELETE FROM page_watch WHERE url=? AND kind=?", (r["url"], KIND)).rowcount
    c.commit()
    return n


def changed_text(c, days=7):
    since = (dt.datetime.utcnow() - dt.timedelta(days=days)).isoformat(timespec="seconds")
    rows = c.execute("SELECT p.url, p.agency_id, p.last_changed FROM page_watch p WHERE p.kind=? AND p.last_changed >= ? "
                     "ORDER BY p.agency_id", (KIND, since)).fetchall()
    if not rows:
        return ""
    lines = [f"{len(rows)} agency contract/award pages changed in the last {days} days. Ask Claude (in the app) to read them "
             "for new awards:"]
    lines += [f"- {r['agency_id'] or '?'}: {r['url']}" for r in rows]
    return "\n".join(lines)


def load_research(c, path, tag="research"):
    """Researched awards into the awards table. Skips an award already there: same agency, the vendor's first word matching,
    amount within 3% (or both blank) and award date within 120 days. Returns (rows, added, skipped)."""
    suppliers = sources.supplier_ids()
    rows = added = skipped = 0
    for r in csv.DictReader(open(_resolve(path), newline="", encoding="utf-8-sig")):
        rows += 1
        aid, vendor, title = (r.get("agency_id") or "").strip() or None, (r.get("vendor") or "").strip(), (r.get("title") or "").strip()
        if not title or not vendor:
            skipped += 1
            continue
        try:
            amt = float(r["amount"]) if (r.get("amount") or "").strip() else None
        except ValueError:
            amt = None
        cur = (r.get("currency") or "USD").strip() or "USD"
        date = (r.get("award_date") or "").strip()[:10] or None
        usd = bc.to_usd(amt, cur) if amt else None
        vn = (sources.norm_vendor(vendor) or vendor).lower().split()[:1]
        dup = False
        for a in c.execute("SELECT vendor_norm, vendor, amount_usd, award_date FROM award WHERE agency_id IS ?", (aid,)):
            av = ((a["vendor_norm"] or a["vendor"] or "").lower().split() or [""])[:1]
            if vn and av != vn:
                continue
            same_amt = (usd is None and a["amount_usd"] is None) or (usd and a["amount_usd"] and abs(a["amount_usd"] - usd) <= 0.03 * usd)
            try:
                near = not date or not a["award_date"] or abs((dt.date.fromisoformat(a["award_date"][:10]) - dt.date.fromisoformat(date)).days) <= 120
            except ValueError:
                near = True
            if same_amt and near:
                dup = True
                break
        if dup:
            skipped += 1
            continue
        cat = (r.get("category") or "").strip() or None
        try:
            nb = int(r["n_bidders"]) if (r.get("n_bidders") or "").strip() else None
        except ValueError:
            nb = None
        added += sources.add_award(c, {
            "source_key": f"{tag}:{bc.sha('|'.join([aid or '', date or '', vendor.lower(), str(amt), title.lower()]))}",
            "agency_id": aid, "country": "CA" if cur == "CAD" else "US", "title": title[:500], "vendor": vendor, "amount": amt,
            "currency": cur, "award_date": date, "category": cat, "n_bidders": nb, "relevance": 90 if cat in VEHICLE_CATS else 75,
            "source": "research", "confidence": (r.get("confidence") or "").strip().upper()[:1] or "B",
            "operator_id": (r.get("operator_id") or "").strip() or None, "source_url": (r.get("source_url") or "").strip() or None,
            "notes": ((r.get("notes") or "").strip() + f" [{tag}]").strip()}, suppliers)
    c.commit()
    return rows, added, skipped


def load_past_rfps(c, path, tag="pastrfp"):
    """Researched past solicitations, each with the award that followed when known, into notice (+ award, + bid_tab).
    CSV: agency_id, ref_no, title, solicitation_type, published, closing, category, value_est, currency, url,
         vendor, amount, award_date, n_bidders, bidders ("Name: amount; Name: amount"), award_url, confidence, notes.
    A solicitation already present (same agency and reference, or same agency, title and closing month) is not added again,
    but its award is still attached. Never alerted, never sent to the Claude review. Returns (rows, notices added, awards added)."""
    sources.HISTORY = True
    suppliers = sources.supplier_ids()
    rows = nadd = aadd = 0
    for r in csv.DictReader(open(_resolve(path), newline="", encoding="utf-8-sig")):
        g = lambda k: (r.get(k) or "").strip()
        title, aid = g("title"), g("agency_id") or None
        if not title or not (g("closing") or g("vendor")):
            continue  # an award alone (no closing date known) is kept as an award without a solicitation
        rows += 1
        ref, closing, cur = g("ref_no") or None, g("closing")[:10], g("currency") or "USD"
        cat = g("category") or None
        rel = 90 if cat in VEHICLE_CATS else 75
        key = f"{tag}:{aid}:{(ref or bc.sha(title.lower() + closing[:7]))}"
        row = None
        if not g("closing"):
            row = (ref and c.execute("SELECT notice_id FROM notice WHERE agency_id IS ? AND ref_no=? AND coalesce(notice_type,'')!='award'",
                                     (aid, ref)).fetchone()) or (None,)
        elif ref:
            row = c.execute("SELECT notice_id FROM notice WHERE agency_id IS ? AND ref_no=? AND coalesce(notice_type,'')!='award'", (aid, ref)).fetchone()
        if not row:
            row = c.execute("SELECT notice_id FROM notice WHERE source_key=?", (key,)).fetchone()
        if not row:
            try:
                val = float(g("value_est")) if g("value_est") else None
            except ValueError:
                val = None
            if sources.add_notice(c, {"source": "research", "source_key": key, "agency_id": aid, "country": "CA" if cur == "CAD" else "US",
                                      "ref_no": ref, "title": title[:500], "description": (g("solicitation_type") + " " + g("notes")).strip() or None,
                                      "notice_type": "tender", "published": g("published")[:10] or None, "closing": closing, "url": g("url") or None,
                                      "value_est": val, "currency": cur}):
                nadd += 1
            row = c.execute("SELECT notice_id FROM notice WHERE source_key=?", (key,)).fetchone()
            c.execute("UPDATE notice SET relevance=?, kw_score=coalesce(kw_score, ?), category=coalesce(category, ?), reviewed='research' WHERE notice_id=?",
                      (rel, rel, cat, row[0]))
        nid = row[0]
        if g("vendor"):
            try:
                amt = float(g("amount")) if g("amount") else None
            except ValueError:
                amt = None
            bids = []
            for part in [p for p in g("bidders").split(";") if p.strip()]:
                name, _, a = part.partition(":")
                try:
                    bids.append((name.strip(), float(a.replace(",", "").replace("$", "").strip()) if a.strip() else None))
                except ValueError:
                    bids.append((name.strip(), None))
            amounts = [b[1] for b in bids if b[1]]
            try:
                nb = int(g("n_bidders")) if g("n_bidders") else (len(bids) or None)
            except ValueError:
                nb = len(bids) or None
            ok = sources.add_award(c, {
                "source_key": f"{tag}-award:{aid}:{ref or bc.sha(title.lower())}:{g('vendor').lower()}", "notice_id": nid,
                "source": "research", "agency_id": aid, "country": "CA" if cur == "CAD" else "US", "ref_no": ref, "title": title[:500],
                "vendor": g("vendor"), "amount": amt, "currency": cur, "award_date": g("award_date")[:10] or None, "category": cat,
                "n_bidders": nb, "low_bid": min(amounts) if amounts else None, "high_bid": max(amounts) if amounts else None,
                "relevance": rel, "source_url": g("award_url") or g("url") or None, "confidence": (g("confidence") or "B")[:1].upper(),
                "notes": g("notes") or None}, suppliers)
            if ok:
                aadd += 1
                awid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                for rank, (name, a) in enumerate(sorted(bids, key=lambda b: b[1] if b[1] is not None else 9e18), 1):
                    c.execute("INSERT INTO bid_tab (award_id, notice_id, bidder, bidder_norm, amount, rank, winner, source_url) VALUES (?,?,?,?,?,?,?,?)",
                              (awid, nid, name, sources.norm_vendor(name), a, rank, int(sources.norm_vendor(name) == sources.norm_vendor(g("vendor"))),
                               g("award_url") or g("url") or None))
    c.commit()
    sources.HISTORY = False
    return rows, nadd, aadd
