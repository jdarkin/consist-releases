"""1.8.1 (BD review 11-19, Justin: "do everything on your list"): the pages a rail BD leader asked for.

- Megaprojects: North American capital programs with owner, value, funding, delivery model and packages, linked to the bids,
  awards and early signals Bid Catcher has for them (seed/megaprojects.json, researched; grade C).
- Market sizing: TAM / SAM / SOM by segment from data already on the site (replacement forecast, consumables and overhaul
  estimates, O&M contracts, five years of awards), with a share slider.
- Competitor profiles: one parent company's installed base, awards, share by category and the change windows on its equipment.
- Likely competitors for a bid: who won similar work at this agency and in this category.
- Data QA flags for Admin: patterns that usually mean a data error.
- Territory digest: one weekly email per opted-in member with new bids, windows opening and awards in their territory.
"""
import datetime
import json
import os
import re

from . import config, data, db, intel, lens
from .parents import parent

SEED = os.path.join(os.path.dirname(os.path.dirname(__file__)), "seed", "megaprojects.json")
_mp = {"mtime": None, "d": None}


# ---------------- megaprojects ----------------

def projects_seed():
    try:
        mt = os.path.getmtime(SEED)
    except OSError:
        return {"as_of": None, "note": "", "projects": []}
    if _mp["mtime"] != mt:
        with open(SEED, encoding="utf-8") as fh:
            _mp.update(mtime=mt, d=json.load(fh))
    return _mp["d"]


def _kw_sql(col, kws):
    return "(" + " OR ".join(f"lower({col}) LIKE ?" for _ in kws) + ")", [f"%{k.lower()}%" for k in kws]


def project_links(p, limit=8):
    """Bids, early signals and awards whose title mentions one of the project's keywords."""
    kws = [k for k in p.get("keywords") or [] if len(k.strip()) >= 4]
    if not kws:
        return {"bids": [], "awards": []}
    w, a = _kw_sql("n.title", kws)
    bids = data._bq_safe(f"SELECT n.notice_id, n.title, n.closing, n.published, n.notice_type, coalesce(n.relevance, n.kw_score, 0) rel, "
                         f"n.agency_id FROM notice n WHERE {w} ORDER BY coalesce(n.published, n.first_seen) DESC LIMIT {int(limit)}", a)
    w2, a2 = _kw_sql("a.title", kws)
    aw = data._bq_safe(f"SELECT a.award_id, a.title, a.vendor, a.amount_usd, a.award_date FROM award a WHERE {w2} "
                       f"ORDER BY a.award_date DESC LIMIT {int(limit)}", a2)
    return {"bids": bids, "awards": aw}


def projects(country=None, q=None):
    d = projects_seed()
    out = []
    for p in d.get("projects", []):
        if country and p.get("country") != country:
            continue
        if q and q.lower() not in json.dumps(p).lower():
            continue
        out.append(p)
    return sorted(out, key=lambda p: -(p.get("value") or 0) * (0.73 if p.get("currency") == "CAD" else 1))


def project(pid):
    return next((p for p in projects_seed().get("projects", []) if p["id"] == pid), None)


def search_projects(q, limit=10):
    ql = (q or "").strip().lower()
    if len(ql) < 3:
        return []
    return [p for p in projects_seed().get("projects", [])
            if ql in p["name"].lower() or ql in p["owner"].lower() or any(ql in k.lower() or k.lower().strip() in ql for k in p.get("keywords") or [])][:limit]


# ---------------- market sizing ----------------

AWARD_SEGMENTS = {  # award categories -> sizing segments (awards are a floor: only what Bid Catcher has seen)
    "signals_communications": "Signalling, train control and communications", "track_infrastructure": "Track and right of way",
    "traction_power": "Traction power and catenary", "stations_facilities": "Stations, yards and facilities",
    "rail_engineering": "Engineering and consulting", "rail_operations": "Operations and O&M services",
    "component_repair": "Component repair and overhaul", "overhaul_rebuild": "Vehicle overhaul and rebuild",
    "parts_supply": "Parts and materials", "shop_equipment": "Shop equipment", "onboard_systems": "Onboard systems",
    "cleaning_interiors": "Cleaning and interiors", "maintenance_services": "Maintenance services",
}


def sizing(years=5):
    """Annual market by segment in the viewer's market view (lens, region, territory). Each segment says how it is measured."""
    segs = []
    # 1. new rolling stock: replacement demand over 10 years at recorded unit costs, per year
    try:
        _, totals, overdue = intel.forecast(10)[:3]
        v10 = sum(t["value"] for t in totals.values()) + (overdue.get("value") or 0)
        segs.append({"k": "rolling_stock", "label": "New rolling stock", "usd": v10 / 10, "how": "Replacement demand over the next 10 years "
                     "at recorded unit costs, divided by 10. Cars past useful life count in year one.", "grade": "B"})
    except Exception:
        pass
    # 2. maintenance materials and component overhauls, and 3. O&M contracts, from the operator rows the Explorer uses
    try:
        from . import explorer
        rows = explorer.rows()
        cs = sum(r.get("cs") or 0 for r in rows)
        segs.append({"k": "fleet_mro", "label": "Fleet consumables and component overhauls", "usd": cs, "how": "Consist estimate per fleet: "
                     "duty cycle x cited replacement intervals x award prices (mid case), parts and service contracts only, no in-house labor.",
                     "grade": "C"})
    except Exception:
        rows = []
    try:
        from . import om
        sc = lens.current()
        oc = [c for c in om.contracts() if c.get("annual_usd") and (not sc.territory or c.get("operator_id") in (sc.ter_ops or ()))]
        segs.append({"k": "om", "label": "Contracted operations and maintenance", "usd": sum(c["annual_usd"] for c in oc),
                     "how": f"Annual value of {len(oc)} known O&M, operations and maintenance contracts (NTD contractual relationships, "
                            "board awards, research).", "grade": "B"})
    except Exception:
        pass
    # 4. everything else: awards seen in the last N years, per year (a floor)
    sc = lens.current()
    w, a = "1=1", []
    if sc.territory:
        w, a = sc.ter_sql("operator_id", "agency_id")
    for r in data._bq_safe(f"SELECT category, sum(amount_usd) usd, count(*) n FROM award WHERE relevance >= 50 AND amount_usd > 0 "
                           f"AND award_date >= date('now', ?) AND {w} GROUP BY 1", [f"-{int(years)} years"] + a):
        cat = r["category"] or "other"
        if cat in ("vehicle_procurement", "rolling_stock") or cat not in AWARD_SEGMENTS:
            continue
        segs.append({"k": "aw_" + cat, "label": AWARD_SEGMENTS[cat], "usd": (r["usd"] or 0) / years,
                     "how": f"Awards Bid Catcher has seen in the last {years} years ({r['n']} contracts), per year. A floor: "
                            "awards we have not seen are missing.", "grade": "C"})
    segs.sort(key=lambda s: -s["usd"])
    return segs


def company_share(name, years=5):
    """A parent company's share of awards (by value, last N years) and of the installed base (cars as builder or supplier)."""
    p = parent(name)
    sc = lens.current()
    w, a = "1=1", []
    if sc.territory:
        w, a = sc.ter_sql("operator_id", "agency_id")
    rows = data._bq_safe(f"SELECT vendor, sum(amount_usd) usd FROM award WHERE relevance >= 50 AND amount_usd > 0 "
                         f"AND award_date >= date('now', ?) AND {w} GROUP BY 1", [f"-{int(years)} years"] + a)
    tot = sum(r["usd"] or 0 for r in rows)
    mine = sum(r["usd"] or 0 for r in rows if parent(r["vendor"]) == p)
    snap = intel.snapshot()
    cars = sum(fl["qty_active"] or 0 for fl in snap.values())
    base = sum(fl["qty_active"] or 0 for fl in snap.values() if parent(fl.get("manufacturer_now") or fl["manufacturer"] or "") == p)
    return {"name": p, "award_pct": round(100 * mine / tot, 1) if tot else 0, "base_pct": round(100 * base / cars, 1) if cars else 0}


def top_companies(n=40):
    rows = data._bq_safe("SELECT vendor, sum(amount_usd) usd FROM award WHERE relevance >= 50 AND amount_usd > 0 "
                         "AND award_date >= date('now', '-5 years') GROUP BY 1")
    agg = {}
    for r in rows:
        k = parent(r["vendor"] or "")
        if k:
            agg[k] = agg.get(k, 0) + (r["usd"] or 0)
    for fl in intel.snapshot_all().values():
        k = parent(fl.get("manufacturer_now") or fl["manufacturer"] or "")
        if k and k != "Unknown":
            agg.setdefault(k, 0)
    return [k for k, _ in sorted(agg.items(), key=lambda kv: -kv[1])][:n]


# ---------------- competitor profiles ----------------

def competitor(name, years=5):
    p = parent(name)
    snap = intel.snapshot()
    names = {r["supplier_id"]: r["name"] for r in intel._rows("SELECT supplier_id, name FROM supplier")}
    built, subs = [], {}
    for fl in snap.values():
        n = fl["qty_active"] or 0
        if parent(fl.get("manufacturer_now") or fl["manufacturer"] or "") == p:
            built.append(fl)
        for x in fl.get("installed") or []:
            lab = names.get(x.get("supplier_id")) or (x.get("supplier") or "")
            if lab and parent(lab) == p:
                s = subs.setdefault(x["subsystem"], {"cars": 0, "fleets": 0, "ops": set()})
                s["cars"] += n
                s["fleets"] += 1
                s["ops"].add(fl["operator_id"])
    rows = data._bq_safe("SELECT a.award_id, a.title, a.vendor, a.amount_usd, a.award_date, a.category, a.agency_id, a.n_bidders, "
                         "coalesce(g.agency, a.buyer) agency FROM award a LEFT JOIN agency g USING (agency_id) WHERE a.relevance >= 50 "
                         "AND a.award_date >= date('now', ?) ORDER BY a.award_date DESC", (f"-{int(years)} years",))
    wins = [r for r in rows if parent(r["vendor"] or "") == p]
    cats = {}
    for r in rows:
        c = cats.setdefault(r["category"] or "other", [0, 0])
        c[0] += r["amount_usd"] or 0
        if parent(r["vendor"] or "") == p:
            c[1] += r["amount_usd"] or 0
    by_cat = sorted(((data.CATEGORIES.get(k, k), t, m, round(100 * m / t, 1) if t else 0) for k, (t, m) in cats.items() if m), key=lambda x: -x[2])
    agencies = {}
    for r in wins:
        g = agencies.setdefault(r["agency"] or r["agency_id"] or "?", [0, 0])
        g[0] += 1
        g[1] += r["amount_usd"] or 0
    try:
        from . import nexgen
        wins_open = [dict(w, sub=data.SUBSYSTEMS.get(w["rec"]["subsystem"], w["rec"]["subsystem"]))
                     for w in nexgen.supplier_windows(8) if parent(w["supplier"] or "") == p]
    except Exception:
        wins_open = []
    entities = sorted({r["vendor"] for r in wins if r["vendor"]})
    return {"name": p, "built": sorted(built, key=lambda f: -(f["qty_active"] or 0)), "built_cars": sum(f["qty_active"] or 0 for f in built),
            "subs": sorted(((data.SUBSYSTEMS.get(k, k), v["cars"], v["fleets"], len(v["ops"])) for k, v in subs.items()), key=lambda x: -x[1]),
            "wins": wins[:40], "win_usd": sum(r["amount_usd"] or 0 for r in wins), "n_wins": len(wins), "by_cat": by_cat,
            "agencies": sorted(agencies.items(), key=lambda kv: -kv[1][1])[:15], "windows": wins_open[:40], "n_windows": len(wins_open),
            "entities": entities, "share": company_share(p, years)}


# ---------------- likely competitors on a bid ----------------

def likely_competitors(n, limit=6):
    """Who won similar work: same category at this agency first, then the same category anywhere, last 7 years (awards seen)."""
    if not n:
        return []
    cat, ag = n.get("category"), n.get("agency_id")
    if not cat:
        return []
    rows = data._bq_safe("SELECT vendor, agency_id, amount_usd, n_bidders FROM award WHERE relevance >= 50 AND category = ? "
                         "AND coalesce(vendor, '') != '' AND award_date >= date('now', '-7 years')", (cat,))
    agg = {}
    for r in rows:
        k = parent(r["vendor"])
        d = agg.setdefault(k, {"name": k, "here": 0, "anywhere": 0, "usd": 0.0})
        d["anywhere"] += 1
        d["usd"] += r["amount_usd"] or 0
        if ag and r["agency_id"] == ag:
            d["here"] += 1
    return sorted(agg.values(), key=lambda d: (-d["here"], -d["anywhere"], -d["usd"]))[:limit]


# ---------------- data QA flags (Admin) ----------------

def qa_flags():
    """Patterns that usually mean a data error, newest data first. Each flag says why and links to the record."""
    out = []
    yr = intel.this_year()
    snap = intel.snapshot_all()
    modern = {"metro_car", "lrv", "emu", "dmu", "agt_vehicle", "monorail_car"}
    by_op = {}
    for fl in snap.values():
        by_op.setdefault((fl["operator_id"], fl.get("model_name"), fl.get("manufacturer")), []).append(fl)
        if fl.get("vehicle_class") in modern and fl.get("build_year") and fl["build_year"] < 1960:
            out.append(("Build year", f"{fl['operator_name']} {fl['model_name']}", f"{fl['vehicle_class']} built {fl['build_year']}: before 1960 is unlikely "
                        "for this vehicle type", f"/app/fleets/{fl['fleet_id']}"))
        if fl.get("build_year") and fl["build_year"] > yr + 1:
            out.append(("Build year", f"{fl['operator_name']} {fl['model_name']}", f"built {fl['build_year']}, in the future", f"/app/fleets/{fl['fleet_id']}"))
        if fl.get("ulb_year") and fl.get("build_year") and fl["ulb_year"] < fl["build_year"]:
            out.append(("Useful life", f"{fl['operator_name']} {fl['model_name']}", "useful life ends before the build year", f"/app/fleets/{fl['fleet_id']}"))
    for (oid, model, mfr), fls in by_op.items():
        if len(fls) >= 4:
            out.append(("Fleet split", f"{fls[0]['operator_name']} {mfr or ''} {model}", f"{len(fls)} fleet rows for one model (split by build "
                        "year?); lists and opportunities show it several times", f"/app/operators/{oid}"))
    ops = {}
    for fl in snap.values():
        ops.setdefault(fl["operator_id"], []).append(fl)
    for oid, fls in ops.items():
        cpm = {round(f["maint_cost_per_car_mile"], 2) for f in fls if f.get("maint_cost_per_car_mile")}
        if len(fls) >= 5 and len(cpm) == 1:
            out.append(("Cost", fls[0]["operator_name"], f"every fleet shows the same maintenance cost per car-mile (${cpm.pop()}): a mode "
                        "average, not per fleet", f"/app/operators/{oid}"))
    for r in data._bq_safe("SELECT notice_id, title FROM notice WHERE title GLOB '*[" + "▁​" + "]*' LIMIT 50"):
        out.append(("Bid text", r["title"][:80], "junk characters in the title", f"/app/bids/{r['notice_id']}"))
    for r in data._bq_safe("SELECT notice_id, title, closing, first_seen FROM notice WHERE closing IS NOT NULL AND closing < date(first_seen) "
                           "AND first_seen >= date('now', '-30 days') LIMIT 50"):
        out.append(("Bid dates", r["title"][:80], f"closed {r['closing']} but first seen {str(r['first_seen'])[:10]}", f"/app/bids/{r['notice_id']}"))
    return out


# ---------------- territory digest ----------------

def digest_for(u, days=7):
    """What changed in this member's territory in the last week: new bids (rel >= 60), awards and change windows opening this year."""
    prefs = {r["key"]: r["value"] for r in db.q("SELECT key, value FROM user_pref WHERE user_id = ?", (u["id"],))}
    tok = lens.set_current(lens.scope_for(u, prefs, {}))
    try:
        bids, _ = data.notices({"status": "open", "sort": "new", "days": days, "min_rel": 60}, per=10)
        aw = [a for a in data.awards({"since": (datetime.date.today() - datetime.timedelta(days=days)).isoformat()}, 10)]
        try:
            from . import nexgen
            wins = [w for w in nexgen.supplier_windows(1)][:10]
        except Exception:
            wins = []
    finally:
        lens.reset(tok)
    return {"bids": bids, "awards": aw, "windows": wins}


def digest_text(d):
    lines = []
    if d["bids"]:
        lines.append("New rail bids")
        lines += [f"- {b['title']} ({b.get('agency') or b.get('agency_id') or ''}), closes {b.get('closing') or 'n/a'}: "
                  f"{config.SITE_URL}/app/bids/{b['notice_id']}" for b in d["bids"]]
    if d["awards"]:
        lines.append("\nContract awards")
        lines += [f"- {a['title']} to {a.get('vendor') or 'n/a'}" + (f", ${a['amount_usd']:,.0f}" if a.get("amount_usd") else "") for a in d["awards"]]
    if d["windows"]:
        lines.append("\nSupplier change windows opening this year")
        lines += [f"- {w['fleet']['operator_name']} {w['fleet']['model_name']}: {w['why']}, {w['supplier'] or 'supplier unknown'} now"
                  for w in d["windows"]]
    return "\n".join(lines)


def run_digests(now=None):
    """Monday 11:00 UTC or later, once a week: members with the territory_digest pref get their digest (empty weeks are skipped)."""
    from . import auth, mailer
    now = now or datetime.datetime.utcnow()
    if now.weekday() != 0 or now.hour < 11:
        return 0
    today = now.date().isoformat()
    sent = 0
    for r in db.q("SELECT user_id FROM user_pref WHERE key = 'territory_digest' AND value = '1'"):
        last = db.q("SELECT value FROM user_pref WHERE user_id = ? AND key = 'territory_digest_last'", (r["user_id"],), one=True)
        if last and (last["value"] or "")[:10] >= today:
            continue
        u = auth.load_user(r["user_id"])
        if not u or not u.can("alerts"):
            continue
        db.x("INSERT OR REPLACE INTO user_pref (user_id, key, value) VALUES (?, 'territory_digest_last', ?)", (r["user_id"], today))
        d = digest_for(u)
        body = digest_text(d)
        if not body:
            continue
        send_digest(u, body)
        sent += 1
    return sent


def send_digest(u, body):
    from . import mailer
    mailer.send(u["email"], "Your week in rail: bids, awards and change windows",
                f"{body}\n\nChange or stop this email: {config.SITE_URL}/app/alerts#digest", alerts=True)


# ---------------- procurement contacts from public solicitations ----------------

_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_SKIP = ("noreply", "no-reply", "donotreply", "support@", "help@", "info@bidnet", "bonfirehub", "opengov", "planetbids", "periscope",
         "bidexpress", "merx", "webmaster")


def agency_contacts(oid, limit=12):
    """Procurement contact addresses that agencies print on their own public solicitations (business contacts for bidders),
    with how many recent rail bids named each and the latest one. Personal data is not inferred or combined from elsewhere."""
    try:
        ags = data._agencies_for_operator(oid)
    except Exception:
        ags = []
    if not ags:
        return []
    rows = data._bq_safe(f"SELECT notice_id, title, description, coalesce(published, date(first_seen)) d FROM notice "
                         f"WHERE agency_id IN ({','.join('?' * len(ags))}) AND coalesce(relevance, kw_score, 0) >= 50 "
                         "AND coalesce(published, date(first_seen)) >= date('now', '-2 years') ORDER BY d DESC LIMIT 400", ags)
    out = {}
    for r in rows:
        for e in set(_EMAIL.findall(r.get("description") or "")):
            el = e.lower().rstrip(".")
            if any(s in el for s in _SKIP):
                continue
            c = out.setdefault(el, {"email": el, "n": 0, "latest": r["d"], "nid": r["notice_id"], "title": r["title"]})
            c["n"] += 1
    return sorted(out.values(), key=lambda c: (-c["n"], c["email"]))[:limit]


# ---------------- signalling by route-mile and by award dollars ----------------

def signal_share(mapped):
    """OEM share of mapped agencies' route miles (NTD directional route miles / 2, latest year, split evenly between an agency's
    OEMs) and of signalling and train control award value (5 years). Route miles stand in for the wayside base the cars don't show."""
    drm = {}
    for r in intel._rows("SELECT operator_id, ntd_mode, directional_route_miles d, report_year y FROM operator_mode_year "
                         "WHERE directional_route_miles > 0 ORDER BY report_year"):
        drm.setdefault(r["operator_id"], {})[r["ntd_mode"]] = r["d"]  # later years overwrite earlier
    miles, tot = {}, 0.0
    for o in mapped:
        m = sum((drm.get(o["operator_id"]) or {}).values()) / 2
        oems = sorted({parent(x) for x in (o.get("sum") or {}).get("oems") or [] if x})
        if not m or not oems:
            continue
        tot += m
        for x in oems:
            miles[x] = miles.get(x, 0) + m / len(oems)
    aw, atot = {}, 0.0
    for r in data._bq_safe("SELECT vendor, sum(amount_usd) usd FROM award WHERE relevance >= 50 AND category = 'signals_communications' "
                           "AND amount_usd > 0 AND award_date >= date('now', '-5 years') GROUP BY 1"):
        k = parent(r["vendor"] or "")
        aw[k] = aw.get(k, 0) + (r["usd"] or 0)
        atot += r["usd"] or 0
    return {"miles": sorted(((k, v, round(100 * v / tot) if tot else 0) for k, v in miles.items()), key=lambda x: -x[1]), "miles_total": tot,
            "awards": sorted(((k, v, round(100 * v / atot) if atot else 0) for k, v in aw.items()), key=lambda x: -x[1])[:12], "awards_total": atot}
