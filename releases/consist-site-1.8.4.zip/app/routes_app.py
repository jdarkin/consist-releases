"""The member app under /app: dashboard, bids, awards, fleets, operators, pipeline, AI analyst, alerts, account."""
import csv
import datetime
import io
import json
import logging
import os
import re
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, Response, StreamingResponse
from starlette.concurrency import run_in_threadpool

from . import award_analyst, alerts, consumables, analyst, auth, billing, config, data, db, intel, lens, mailer, personas, territory, vehicle_awards
from .main import flash, redirect, render

router = APIRouter(prefix="/app")
U = Depends(auth.require_user)

BID_KEYS = ("q", "category", "country", "agency", "operator", "subsystem", "status", "sort", "min_rel", "trade", "new", "days", "tag")
FLEET_KEYS = ("q", "mode", "cls", "oem", "country", "operator", "propulsion", "built_from", "built_to", "sort", "dir", "midlife_by", "active", "signal", "subsystem", "supplier", "own")


# The Sort menu on the fleet explorer: (sort value, label). Column headers cover the rest.
FLEET_SORT_MENU = [("cars", "Most cars"), ("age", "Oldest"), ("newest", "Newest"), ("fleet", "Fleet name"), ("operator", "Operator"),
                   ("midlife", "Midlife soonest"), ("miles", "Highest miles/car"), ("cost", "Highest maint. cost"), ("delta", "Most over peers")]


def params(request, keys):
    return {k: request.query_params.get(k, "").strip() for k in keys if request.query_params.get(k, "").strip()}


def bar_pick(request):
    """The chart bar a list is narrowed to: (year, key) from ?y= and ?k=, key None for the whole year."""
    y, k = request.query_params.get("y", ""), request.query_params.get("k", "")
    return (int(y), k or None) if y.isdigit() else None


def bar_links(path, base):
    """href(year, key) for chart bars: the same page narrowed to that bar, scrolled to the list."""
    def href(y, k):
        return f"{path}?" + urlencode({**base, "y": y, **({"k": k} if k else {})}) + "#list"
    return href


def bar_rows(rows, sel, year_of, key_of):
    if not sel:
        return rows
    return [r for r in rows if year_of(r) == sel[0] and (sel[1] is None or key_of(r) == sel[1])]


def page_no(request):
    try:
        return max(1, int(request.query_params.get("page", "1")))
    except ValueError:
        return 1


def csv_response(name, cols, rows):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(cols)
    for r in rows:
        w.writerow([r.get(c) for c in cols])
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})


def watched(u, kind):
    return {r["ref"] for r in db.q("SELECT ref FROM watch WHERE user_id = ? AND kind = ?", (u["id"], kind))}


# My dashboard modules (Justin, 2026-11-03): each user picks which summaries show; saved in user_pref "dash_modules".
DASH_MODULES = [  # key, label, on by default. The role's own block ("market") is three cards since 1.4.
    ("summary", "Headline numbers", True),
    ("market_kpis", "Role: key figures", True), ("market_table", "Role: main table", True), ("market_side", "Role: chart or list", True),
    ("bids", "Bids: closing soon and just posted", True), ("watch_bids", "Bids from operators you follow", True),
    ("pursuits", "My pursuits", True), ("early", "Early signals: RFIs and industry days", False),
    ("oncall", "On-call contracts ending soon", False),
    ("opps", "Top replacement opportunities", True),
    ("fleet_updates", "Fleet updates", True), ("alerts", "Your alerts", True), ("categories", "Bids by category", True),
    ("pipeline", "Overhaul pipeline", True), ("following", "Operators you follow", True), ("analyst", "Recent analyst work", True),
    ("funding", "Funding deadlines", True), ("freight", "Freight rail snapshot", True), ("costs", "Cost and fuel indexes", False),
]
_MARKET = {"market_kpis", "market_table", "market_side"}


def _expand(keys):
    """Layouts saved before 1.4 hold 'market' for the whole role block, and nothing for cards added since."""
    keys = set(keys)
    if "market" in keys:
        keys |= _MARKET
    if "bids" in keys:
        keys.add("watch_bids")
    return keys


# Each role pill keeps its own layout (Justin, 2026-11-07): pref "dash_modules:<persona>", then the old single layout, then the
# role's standard set.
DASH_ROLE_DEFAULTS = {
    "freight": {"summary", "market", "bids", "opps", "fleet_updates", "alerts", "following", "analyst", "freight", "costs"},
    "investor": {"summary", "market", "opps", "fleet_updates", "following", "analyst", "costs"},
    "agency": {"summary", "market", "opps", "fleet_updates", "pipeline", "following", "analyst", "funding"},
    "consult": {"summary", "market", "bids", "pursuits", "early", "oncall", "alerts", "categories", "following", "analyst", "funding"},
    "lessor": {"summary", "market", "opps", "fleet_updates", "following", "analyst", "costs"},
    "systems": {"summary", "market", "bids", "pursuits", "early", "alerts", "categories", "following", "analyst", "funding"},
}


def _role_default(persona):
    if persona in DASH_ROLE_DEFAULTS:
        return {k for k, _l, _d in DASH_MODULES if k in _expand(DASH_ROLE_DEFAULTS[persona])}
    return {k for k, _l, d in DASH_MODULES if d}


def dash_modules(u, persona=None):
    for key in ([f"dash_modules:{persona}"] if persona else []) + ["dash_modules"]:
        raw = intel.pref(u, key)
        if raw:
            try:
                keep = _expand(json.loads(raw))
                return {k for k, _l, _d in DASH_MODULES if k in keep}
            except ValueError:
                pass
    return _role_default(persona)


def dash_custom(u, persona):
    """True when this pill has its own saved layout."""
    return bool(persona and intel.pref(u, f"dash_modules:{persona}"))


@router.post("/dashboard/modules")
async def dashboard_modules(request: Request, u=U):
    """One Save for every role (1.4): the form carries m:<role> checkboxes for each role pill, plus 'roles' listing them.
    A role whose boxes match its standard layout keeps no saved copy, so later changes to the standard reach it."""
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    view = form.get("view") or ""
    roles = [r for r in form.getlist("roles") if r in lens.PERSONAS]
    if form.get("reset"):
        for r in roles:
            db.x("DELETE FROM user_pref WHERE user_id = ? AND key = ?", (u["id"], f"dash_modules:{r}"))
        db.x("DELETE FROM user_pref WHERE user_id = ? AND key = 'dash_modules'", (u["id"],))
        flash(request, "Every role's dashboard is back to its standard layout.", "ok")
    else:
        changed = 0
        for r in roles:
            picked = {k for k, _l, _d in DASH_MODULES if k in set(form.getlist(f"m:{r}"))}
            if picked == _role_default(r):
                db.x("DELETE FROM user_pref WHERE user_id = ? AND key = ?", (u["id"], f"dash_modules:{r}"))
            else:
                intel.set_pref(u, f"dash_modules:{r}", json.dumps(sorted(picked)))
                changed += 1
        db.x("DELETE FROM user_pref WHERE user_id = ? AND key = 'dash_modules'", (u["id"],))  # the old single layout is now per role
        flash(request, f"Dashboards saved for {len(roles)} roles{f' ({changed} customized)' if changed else ''}.", "ok")
    return redirect("/app" + (f"?view={view}" if view in lens.PERSONAS else ""))


@router.get("")
def dashboard(request: Request, u=U):
    searches = db.q("SELECT * FROM saved_search WHERE user_id = ? ORDER BY id", (u["id"],))
    mine = intel.personas_for(u)
    # every role has a pill: the user's own picks first, then the other roles (1.2)
    avail = lens.personas()
    roles = [k for k in mine if k in avail] + [k for k in avail if k not in mine]
    view = request.query_params.get("view")
    if view in roles:
        intel.set_pref(u, "dash_view", view)  # the pill picked last stays picked
    else:
        view = intel.pref(u, "dash_view")
    persona = view if view in roles else (mine[0] if mine else None)
    show = dash_modules(u, persona)
    # When the user sells more than one thing, or looks at another role, the pill also narrows the bid cards to that role's trades.
    view_trades = ",".join(lens.PERSONA_TRADES.get(persona, [])) if persona and (len(mine) > 1 or persona not in mine) else ""
    bf = {"trades": view_trades} if view_trades else {}
    fh = u.can("bids_full")
    # "Just posted" means the last 30 days. When the role's trades have nothing open or new, the card says so and shows all
    # rail bids instead, so the cards agree with the tiles above them.
    from . import pages as _pages  # 1.7.9: no bid cards on the dashboard when the plan's Bids page is Locked (they could not be opened)
    bids_ok = u.bids and (u.is_admin or _pages.access(u.plan, "/app/bids") != "none")
    closing, _ = data.notices(dict(bf, status="open", sort="closing"), per=6, full_history=fh) if bids_ok else ([], 0)
    latest, _ = data.notices(dict(bf, status="all", sort="new", days=30), per=6, full_history=fh) if bids_ok else ([], 0)
    closing_all = latest_all = False
    if bids_ok and view_trades and not closing:
        closing, _ = data.notices({"status": "open", "sort": "closing"}, per=6, full_history=fh)
        closing_all = bool(closing)
    if bids_ok and view_trades and not latest:
        latest, _ = data.notices({"status": "all", "sort": "new", "days": 30}, per=6, full_history=fh)
        latest_all = bool(latest)
    watch_ops = list(watched(u, "operator"))
    watch_bids = []
    for oid in watch_ops[:6] if bids_ok else []:
        watch_bids += data.notices_for_operator(oid, 3)
    watch_bids = sorted({n["notice_id"]: n for n in watch_bids}.values(), key=lambda n: n["published"] or "", reverse=True)[:8]
    ops = {o["operator_id"]: o for o in data.operators()} if watch_ops else {}
    by_year, _ = data.pipeline(years=5)
    years = {}
    for r in by_year:
        years.setdefault(r["yr"], {})[r["subsystem"]] = r["cars"]
    jobs = db.q("SELECT id, question, status, created, kind FROM analyst_job WHERE user_id = ? ORDER BY created DESC LIMIT 5", (u["id"],))
    opps = intel.opportunities("vehicles", 5)[:5] if u.can("opportunities") else []
    updates = intel.events_for_user(u, limit=6) if u.can("fleet_alerts") else []
    panel = None
    if persona:
        try:
            panel = personas.home(persona, u)
        except Exception:
            logging.getLogger("consist").exception("persona dashboard %s", persona)
    extra = {}
    if "funding" in show:
        try:
            from . import fundprog
            extra["deadlines"] = fundprog.calendar()[0][:5]
        except Exception:
            logging.getLogger("consist").exception("dashboard funding")
    if "freight" in show:
        try:
            from . import teasers
            extra["freight_cards"] = teasers.cards()[:3]
        except Exception:
            logging.getLogger("consist").exception("dashboard freight")
    if "costs" in show:
        try:
            from . import costidx
            rq = costidx.rcaf()
            fa = costidx.fuel_annual()
            extra["idx"] = dict(rcaf=rq[-1] if rq else None, fuel=(max(fa), fa[max(fa)]) if fa else None)
        except Exception:
            logging.getLogger("consist").exception("dashboard indexes")
    if "pursuits" in show:
        try:
            from . import nexgen
            pr = nexgen.pursuits(u, "open")
            extra["pursuits"], extra["pursuit_sum"] = pr[:6], nexgen.pursuit_summary(nexgen.pursuits(u))
        except Exception:
            logging.getLogger("consist").exception("dashboard pursuits")
    if "early" in show and bids_ok:
        try:
            from . import nexgen
            extra["early"] = nexgen.early_signals(6)
        except Exception:
            logging.getLogger("consist").exception("dashboard early signals")
    if "oncall" in show:
        try:
            from . import nexgen2
            import datetime as _dt
            today = _dt.date.today().isoformat()[:7]
            extra["oncall"] = [r for r in nexgen2.oncall_expiry()[0] if r.get("ends") and r["ends"] >= today][:6]
        except Exception:
            logging.getLogger("consist").exception("dashboard on-call")
    layouts = {r: sorted(dash_modules(u, r)) for r in roles}
    return render(request, "app/dashboard.html", bids_ok=bids_ok, user=u, show=show, DASH_MODULES=DASH_MODULES, **extra, layouts=layouts,
                  custom_roles=[r for r in roles if dash_custom(u, r)],
                  bs=data.bid_stats(), fs=data.fleet_stats(), searches=searches, closing=closing, closing_all=closing_all, latest_all=latest_all,
                  welcome=not intel.pref(u, "tour_done") and not request.session.get("tour_later"),
                  latest=latest, watch_bids=watch_bids, watch_ops=[ops[o] for o in watch_ops if o in ops], years=years,
                  cats=data.by_category(90), jobs=jobs, ai_left=auth.ai_left(u),
                  opps=opps, updates=updates, panel=panel, persona=persona, my_personas=mine, roles=roles, view_trades=view_trades,
                  dash_custom=dash_custom(u, persona))


# ---------- bids ----------

@router.get("/bids")
def bids(request: Request, u=U):
    if not u.bids:
        return render(request, "app/locked.html", user=u, feature="bids_recent", title="Bids and RFPs")
    f = params(request, BID_KEYS)
    if not f.get("days", "").isdigit():
        f.pop("days", None)
    f.setdefault("status", "open")
    full = u.can("bids_full")
    my_trades = [t for t in (intel.pref(u, "trades") or "").split(",") if t in data.CATEGORIES]
    trade = f.get("trade") or ("mine" if my_trades else "all")
    qf = dict(f, trades=",".join(my_trades)) if trade == "mine" and my_trades else dict(f)
    since = {"login": u.get("prev_login"), "update": data.last_update()}
    if f.get("new") in since:
        qf["new_since"] = since[f["new"]] or "9999"  # never signed in before / no update yet: nothing is "new"
    if request.query_params.get("export"):
        if not u.can("export"):
            raise HTTPException(403, "CSV export is on paid plans.")
        tag = qf.pop("tag", None)
        rows, _ = data.notices(qf, per=None, full_history=full)
        if tag and config.NX_FEATURES:
            from . import nexgen
            rows = [r for r in rows if any(lab == tag for _g, lab in nexgen.bid_tags(r))]
        return csv_response("rail-bids", ["notice_id", "agency", "title", "category", "relevance", "published", "closing", "value_est",
                                          "currency", "ref_no", "url", "summary", "lang", "title_en"], rows)
    page = page_no(request)
    tag = qf.pop("tag", None)
    if tag and config.NX_FEATURES:  # procurement-method / contract-type tags are read from the notice text, so filter in Python
        from . import nexgen
        allrows, _ = data.notices(qf, per=None, full_history=full)
        allrows = [r for r in allrows if any(lab == tag for _g, lab in nexgen.bid_tags(r))]
        total = len(allrows)
        rows = allrows[(page - 1) * 25: page * 25]
    else:
        rows, total = data.notices(qf, page=page, per=25, full_history=full)
    hidden = 0
    if not full and not tag:  # the upgrade nudge counts what the full history would add to this search
        try:
            hidden = max(0, data.notices(qf, page=1, per=1, full_history=True)[1] - total)
        except Exception:
            hidden = 0
    return render(request, "app/bids.html", user=u, f=f, rows=rows, total=total, page=page, pages=(total + 24) // 25, hidden=hidden,
                  agencies=data.agencies(), cats=data.by_category(365), full=full, starred=watched(u, "notice"),
                  qs=urlencode(f), trade=trade, my_trades=my_trades, since=since,
                  qs_all=urlencode({k: v for k, v in f.items() if k != "trade"}), qs_new=urlencode({k: v for k, v in f.items() if k != "new"}), qs_nodays=urlencode({k: v for k, v in f.items() if k != "days"}))


@router.get("/bids/{nid}")
def bid(request: Request, nid: int, u=U):
    n = data.notice(nid)
    if not n:
        raise HTTPException(404)
    if not u.bids:
        return render(request, "app/locked.html", user=u, feature="bids_recent", title=n["title"])
    if not u.can("bids_full") and (n["published"] or "") < data.db.bq("SELECT date('now','-30 days') d", one=True)["d"]:
        return render(request, "app/locked.html", user=u, feature="bids_full", title=n["title"])
    ops = data.notice_operators(n)
    fleets = []
    for oid in ops[:3]:
        rows, _, _ = data.fleets({"operator": oid, "sort": "cars", "_noscope": 1}, per=10)
        fleets += rows
    snap = intel.snapshot_all()
    likely = intel.match_bid(n, [snap[r["fleet_id"]] for r in fleets if r["fleet_id"] in snap])
    awards = []
    if u.can("awards"):
        for oid in ops[:2]:
            awards += data.awards_for_operator(oid, 6)
    briefs = db.q("SELECT * FROM analyst_job WHERE kind = 'brief' AND ref = ? AND user_id = ? ORDER BY created DESC LIMIT 1", (str(nid), u["id"]))
    related, _ = data.notices({"category": n["category"], "status": "open", "sort": "closing"}, per=6, full_history=u.can("bids_full"))
    bench = award_analyst.analyze(award_analyst.ref_from({}, n), limit=30) if u.can("awards") else None
    getdocs = None
    if n.get("source") == "agency_document":  # 1.7.64: no public posting; say how to get the documents
        from . import uploads
        up = uploads.get(data.notice_upload_id(n), u)  # None unless this member uploaded it, or an admin
        getdocs = {"contacts": data.doc_contacts(n.get("description")), "upload": up["id"] if up else None,
                   "upload_name": up["filename"] if up else None, "mine": bool(up and up["user_id"] == u["id"])}
    return render(request, "app/bid.html", user=u, n=n, getdocs=getdocs, bench_stats=bench["stats"] if bench else None,
                  bench_top=bench["winners"][:3] if bench else [], recon=award_analyst.reconcile(n) if bench is not None else None, fleets=fleets, awards=awards, likely=likely, brief=briefs[0] if briefs else None,
                  related=[r for r in related if r["notice_id"] != nid][:5], starred=str(nid) in watched(u, "notice"),
                  ai_on=analyst.available(), ai_left=auth.ai_left(u), rivals=_rivals(u, n))


def _rivals(u, n):
    """1.8.1: likely competitors (who won this category of work here and elsewhere); awards-plan members only."""
    if not u.can("awards"):
        return []
    try:
        from . import bd18
        return bd18.likely_competitors(n)
    except Exception:
        return []


@router.post("/bids/{nid}/brief")
def bid_brief(request: Request, nid: int, csrf: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if not u.can("bid_brief"):
        raise HTTPException(403, "AI bid briefs are on paid plans.")
    if not analyst.available():
        raise HTTPException(503, "The AI analyst is not configured yet.")
    if auth.ai_left(u) <= 0:
        raise HTTPException(429, "You've used this month's analyst questions.")
    n = data.notice(nid)
    if not n:
        raise HTTPException(404)
    auth.ai_charge(u)
    job = analyst.start(u, "brief", analyst.BRIEF_Q, ref=str(nid), context=analyst.brief_context(n))
    return redirect(f"/app/bids/{nid}?job={job}#brief")


# ---------- awards ----------

AWARD_RANKS = [("usd", "Award value ($)"), ("qty", "Quantity sold"), ("fleets", "Fleets"), ("customers", "Customers")]


def funding_links(sl, keep):
    """Drill-down links for the Funding chart: a bar narrows to its value and regroups by the split (or the next unused dimension);
    a segment narrows to both values."""
    dims = [d for d, _ in award_analyst.FUNDING_DIMS]

    def url(filters, by, split=""):
        q = {k: v for k, v in keep.items() if v}
        q.update(filters)
        q["by"] = by
        if split:
            q["split"] = split
        return "/app/awards?tab=funding&" + urlencode(q) + "#mix"

    f, by, split = sl["filters"], sl["by"], sl["split"]
    nxt = lambda used: next((d for d in dims if d not in used), by)  # noqa: E731
    for b in sl["bars"]:
        fb = {**f, by: b["label"]}
        b["href"] = url(fb, split or nxt(set(fb)), "")
        b["sub"] = f"{b['n']} item{'s' if b['n'] != 1 else ''}"
        b["segs"] = [(k, v, url({**fb, split: k}, nxt(set(fb) | {split})) if i < len(sl["skeys"]) else None) for i, (k, v) in enumerate(b["segs"])]
    sl["clear"] = {d: url({k: v for k, v in f.items() if k != d}, by, split) for d in f}
    sl["clear_all"] = url({}, by, split)
    sl["form_keep"] = {k: v for k, v in keep.items() if v}


@router.get("/awards")
def awards(request: Request, u=U):
    tab = request.query_params.get("tab")
    if tab == "funding" or (not tab and not u.can("awards")):
        seg = request.query_params.get("segment")
        seg = seg if seg in award_analyst.segments() else None
        ags = award_analyst.segment_agencies(seg)
        rows = intel.funding_rows(seg)
        stage = request.query_params.get("stage")
        stage = stage if stage in award_analyst.STAGES else None
        sl = award_analyst.funding_slice(award_analyst.funding_records(rows, ags), request.query_params.get("by") or "program",
                                         request.query_params.get("split") or "",
                                         params(request, [d for d, _ in award_analyst.FUNDING_DIMS]))
        funding_links(sl, {"segment": seg, "stage": stage})
        return render(request, "app/funding.html", user=u, rows=rows, total=sum(r["amount_usd"] or 0 for r in rows), sl=sl,
                      budget_rows=award_analyst.budget_items(ags, stage=stage, limit=200), budget_sum=award_analyst.budget_summary(ags),
                      grants=award_analyst.grants(ags, limit=150), stage=stage, segment=seg, SEGMENTS=award_analyst.segments())
    if not u.can("awards"):
        return render(request, "app/locked.html", user=u, feature="awards", title="Award analytics")
    if tab == "analyst" and request.query_params.get("kind") == "vehicles":
        f = params(request, ("type", "builder", "propulsion", "order", "segment", "country", "since", "q"))
        allrows = vehicle_awards.orders()
        rows = vehicle_awards.filtered(allrows, f)
        if request.query_params.get("export") and u.can("export"):
            return csv_response("vehicle-orders", ["date", "buyer", "title", "builder", "type", "propulsion", "kind", "units", "usd", "unit_usd",
                                                   "mixed", "source", "source_url"], rows)
        return render(request, "app/vehicle_analyst.html", user=u, f=f, res=vehicle_awards.analyze(rows), opts=vehicle_awards.options(allrows),
                      unpriced=vehicle_awards.filtered(vehicle_awards.orders(unpriced=True), f),
                      n_all=len(allrows), TYPES=vehicle_awards.TYPES, KINDS=vehicle_awards.KINDS, PROP=vehicle_awards.PROP_LABEL,
                      tcol=vehicle_awards.type_colors(), SEGMENTS=award_analyst.segments(), qs=urlencode({**f, "kind": "vehicles"}))
    if tab == "analyst":
        f = params(request, ("category", "subsystem", "work", "q", "agency", "country", "since", "notice", "model"))
        n = data.notice(int(f["notice"])) if (f.get("notice") or "").isdigit() else None
        ref = award_analyst.ref_from(f, n)
        res = award_analyst.analyze(ref, limit=int(request.query_params.get("n") or 40), since=f.get("since"))
        if request.query_params.get("export") and u.can("export"):
            return csv_response("similar-awards", ["score", "award_date", "agency", "title", "vendor", "amount_usd", "n_bidders", "low_bid",
                                                   "high_bid", "term_months", "category", "work_label", "qty", "unit", "unit_usd", "today_usd",
                                                   "source_url"], res["rows"])
        models = sorted({fl["model_name"] for fl in intel.snapshot_all().values() if fl["model_name"]}, key=str.lower)
        return render(request, "app/award_analyst.html", user=u, f=f, n=n, ref=ref, res=res, agencies=data.agencies(), models=models,
                      recon=award_analyst.reconcile(n) if n else None, qs=urlencode(f), facets=award_analyst.facets())
    f = params(request, ("category", "subsystem", "agency", "country", "vendor", "q", "since"))
    if request.query_params.get("export") and u.can("export"):
        return csv_response("rail-awards", ["award_date", "agency", "title", "vendor", "amount_usd", "n_bidders", "category", "source_url"],
                            data.awards(f, limit=5000))
    vendors, total, n = data.award_vendors(f, limit=None)
    rank = request.query_params.get("rank")
    rank = rank if rank in dict(AWARD_RANKS) else "usd"
    fp = intel.vendor_footprint()
    for v in vendors:
        m = intel.vendor_match(v["label"] or v["vendor"], fp) or intel.vendor_match(v["vendor"], fp)
        v["cars"] = round(m["cars"]) if m else 0
        v["fleets"] = len(m["fleets"]) if m else 0
        v["fleet_ops"] = len(m["operators"]) if m else 0
    vendors = sorted(vendors, key=lambda v: (-(v[{"usd": "usd", "qty": "cars", "fleets": "fleets", "customers": "agencies"}[rank]] or 0), -(v["usd"] or 0)))[:15]
    return render(request, "app/awards.html", user=u, f=f, vendors=vendors, total=total, n=n, rank=rank, ranks=AWARD_RANKS,
                  rank_qs=urlencode(f), cats=data.award_categories(f),
                  years=data.award_years(f), rows=data.awards(f, 60), agencies=data.agencies())


@router.get("/awards/{aid}")
def award(request: Request, aid: int, u=U):
    if not u.can("awards"):
        return render(request, "app/locked.html", user=u, feature="awards", title="Award analytics")
    a = data.award(aid)
    if not a:
        raise HTTPException(404)
    ref = {"title": a["title"] or "", "category": a.get("category"), "subsystems": a.get("subsystems") or "", "agency_id": a.get("agency_id"),
           "country": a.get("country"), "q": a["title"] or ""}
    like = [r for r in award_analyst.similar(ref, 9) if r["award_id"] != aid][:8]
    return render(request, "app/award.html", user=u, a=a, like=like,
                  analyst_qs=urlencode({k: v for k, v in (("q", a["title"]), ("category", a.get("category")), ("agency", a.get("agency_id"))) if v}))


# ---------- fleets ----------

@router.get("/fleets")
def fleets(request: Request, u=U):
    f = params(request, FLEET_KEYS)
    sc = lens.current()
    if f.get("operator") and sc.modes and not request.query_params.get("export"):
        # A drill-down from an operator (signal pill, operator page) names one agency. If none of its fleets are in the current
        # market lens (for example a commuter railroad while the Transit lens is on), widen to all rail instead of showing nothing.
        q = dict(f)
        restrict = intel.fleet_ids_matching(f)
        if restrict is not None:
            q["_ids"] = restrict
        if not data.fleets(q, page=1, per=1)[1]:
            token = lens.set_current(lens.Scope("all", sc.regions, freight=sc.freight))
            try:
                return _fleets(request, u, f, widened=sc.label)
            finally:
                lens.reset(token)
    return _fleets(request, u, f)


def _fleets(request, u, f, widened=None):
    q = dict(f)
    restrict = intel.fleet_ids_matching(f)
    if restrict is not None:
        q["_ids"] = restrict
    if request.query_params.get("export"):
        if not u.can("export"):
            raise HTTPException(403, "CSV export is on paid plans.")
        rows, _, _ = data.fleets(q, per=None)
        for r in rows:  # 1.7.30: flatten the estimate into plain columns
            e = r.pop("cost_est", None)
            r.update(cost_basis="estimate (" + e["label"] + ")" if e else "reported (NTD)",
                     estimate_grade=e["grade"] if e else "", est_opex_low_per_car_year=round(e["low"]) if e and e["low"] else "",
                     est_opex_high_per_car_year=round(e["high"]) if e and e["high"] else "")
        return csv_response("rail-fleets", list(rows[0].keys()) if rows else ["fleet_id"], rows)
    from . import pages as _pages
    teaser = not u.is_admin and _pages.access(u.plan, "/app/fleets") == "preview"  # 1.7.11: a preview plan sees the first 10 fleets
    page = 1 if teaser else page_no(request)
    rows, total, cars = data.fleets(q, page=page, per=_pages.FLEET_PREVIEW_ROWS if teaser else 50)
    sort, sdir = data.fleet_sort(f)
    snap = intel.snapshot_all()
    for r in rows:
        r["signals"] = (snap.get(r["fleet_id"]) or {}).get("signals", [])
    from . import marketmap  # 1.7.87 market map on Fleet explorer (Justin 11-19)
    try:
        mm = marketmap.for_page(u, f.get("cls"), f.get("mode")) if page == 1 else None
    except Exception:
        mm = None
    return render(request, "app/fleets.html", user=u, mm=mm, f=f, rows=rows, total=total, cars=cars, page=page, pages=1 if teaser else (total + 49) // 50, teaser=teaser,
                  facets=data.fleet_facets(), qs=urlencode(f), sort=sort, sdir=sdir, sort_menu=FLEET_SORT_MENU, signals=intel.SIGNALS,
                  suppliers=[(x["supplier_id"], x["name"]) for x in intel.suppliers() if x["n_fleets"]], filter_json=json.dumps(f),
                  lists=intel.lists_for(u) if u.can("lists") else [],
                  sort_base="/app/fleets?" + urlencode({k: v for k, v in f.items() if k not in ("sort", "dir")}),
                  op_base="/app/fleets?" + urlencode({k: v for k, v in f.items() if k not in ("operator", "q")}), widened=widened)


@router.get("/fleets/{fid}")
def fleet(request: Request, fid: int, u=U):
    d = data.fleet(fid)
    if not d:
        raise HTTPException(404)
    bids_ = data.notices_for_operator(d["operator_id"], 6)
    fl = intel.snapshot_all().get(fid)
    matched = intel.bids_for_fleet(fl) if fl else []
    return render(request, "app/fleet.html", user=u, d=d, bids=bids_, trend=[t for t in data.operator(d["operator_id"])["trend"]
                                                                             if t["ntd_mode"] == d["ntd_mode"]],
                  fl=fl, matched=matched, sources=intel.sources(fid), history=intel.history(fid, d["operator_id"]),
                  costs=intel.unit_costs(), starred=str(fid) in watched(u, "fleet"), lists=intel.lists_for(u) if u.can("lists") else [],
                  in_lists=intel.lists_with_fleet(u, fid) if u.can("lists") else set(),
                  notes=intel.notes_for(u, d["operator_id"], fid) if u.can("account_notes") else [], signals=intel.SIGNALS,
                  **_cons(consumables.for_fleet(fid)))


@router.get("/operators")
def operators(request: Request, u=U):
    country = request.query_params.get("country") or None
    category = request.query_params.get("category") or None
    sc = lens.current()
    if category and category.startswith("freight") and not sc.freight:  # freight is parked
        return redirect("/app/operators")
    if category and category.startswith("freight") and sc.modes and "FR" not in sc.modes:
        return redirect(f"/app/operators?category={category}&lens=freight")
    ops = data.operators(country, category=category)
    mode = request.query_params.get("mode") or None
    if mode:  # a mode pill was clicked: only operators that run that mode
        ops = [o for o in ops if mode in (o.get("modes") or "").split(";")]
    starred = watched(u, "operator")
    n_following = sum(1 for o in ops if o["operator_id"] in starred)  # 1.7.53 Following pill (Justin 11-16)
    following = request.query_params.get("following") == "1"
    if following:
        ops = [o for o in ops if o["operator_id"] in starred]
    from . import explorer  # 1.7.87 landing map + synced list (Justin 11-19)
    return render(request, "app/operators.html", user=u, ops=ops, country=country, category=category, mode=mode,
                  starred=starred, following=following, n_following=n_following, n_starred=len(starred), oppts=explorer.locate(ops))


def news_page(request, u, key, name, alts, back, rail=False, oid=None):
    """Recent <name> in the news (GDELT via supplier_news.fetch; free, cached 6 hours). Shared by operator and short line pages."""
    from . import supplier_news as N
    w = request.query_params.get("w", "30d")
    q = N.operator_query(name, alts, oid)
    meta = {}
    try:
        items, err = N.fetch(key, q, w, meta=meta), None
    except Exception:
        items, err = [], "busy"
    return render(request, "operator_news.html", user=u, who=name, back=back, items=items, err=err, stale=meta.get("stale"), src=meta.get("source"), q=q,
                  w=w if w in N.WINDOWS else "30d", N=N, rail=rail)


@router.get("/operators/{oid}/news")
def operator_news(request: Request, oid: str, u=U):
    d = data.operator(oid)
    if not d:
        raise HTTPException(404)
    return news_page(request, u, "op:" + oid, d["operator_name"], [d.get("service_name") or "", d.get("acronym") or ""],
                     f"/app/operators/{oid}", oid=oid)


@router.get("/operators/{oid}")
def operator(request: Request, oid: str, u=U):
    ctx = operator_ctx(u, oid)
    from . import brief as _brief  # 1.7.52 Account brief module menu
    rail_ = bool(ctx["rail"])
    return render(request, "app/operator.html", user=u, **ctx, brief_groups=_brief.offered(u, rail_), brief_ticks=_brief.remembered(u, rail_),
                  portals=data.portal_cards(oid), proc_contacts=_proc_contacts(u, oid))


def _proc_contacts(u, oid):
    if not u.can("bids_full") and not u.is_admin:
        return []
    try:
        from . import bd18
        return bd18.agency_contacts(oid)
    except Exception:
        return []


def operator_ctx(u, oid, n_bids=10, n_awards=10):
    """Everything the operator page shows (1.7.52: shared with the account brief so it can include any card)."""
    d = data.operator(oid)
    if not d:
        raise HTTPException(404)
    series = {}
    for t in d["trend"]:
        series.setdefault(t["ntd_mode"], []).append((t["report_year"], t["opex_per_car_rev_mile"]))
    vm = {}
    for t in d["trend"]:
        vm.setdefault(t["ntd_mode"], []).append((t["report_year"], t["vm_per_car_rev_mile"]))
    rail = None
    if (d.get("category") or "").startswith("freight"):
        hist = intel.freight_history(oid)
        ents = {}
        for h in hist:
            ents.setdefault(h["entity_name"] or h["r1_entity"], []).append(h)
        line = lambda k: [(n, [(h["report_year"], h[k]) for h in rows]) for n, rows in ents.items()]
        roster = intel.freight_roster(oid)
        rail = {"roster": roster, "units": sum(m["units"] for m in roster), "hist": hist, "latest": hist[-len(ents):] if hist else [],
                "cost": line("loco_cost_per_unit_mile_2025usd"), "repairs": line("repairs_per_unit_mile_2025usd"),
                "miles": line("miles_per_unit"), "size": line("units_end")}
    from . import pages as _pages
    meet_acc = "full" if u.is_admin else ("none" if not u.bids else _pages.access(u.plan, "/app/bids"))  # board meetings follow Bids
    meet = data.meetings_for_operator(oid) if meet_acc != "none" else {"upcoming": [], "agenda": [], "docs": []}
    return dict(d=d, rail=rail, meet=meet, meet_acc=meet_acc, op_stats=None if rail else data.operator_stats(oid), series=[(data.MODES.get(k, k), v) for k, v in series.items()],
                  vm=[(data.MODES.get(k, k), v) for k, v in vm.items()], bids=data.notices_for_operator(oid, n_bids),
                  awards=data.awards_for_operator(oid, n_awards) if u.can("awards") else [], starred=oid in watched(u, "operator"),
                  x=intel.operator_extras(oid), signals=intel.SIGNALS,
                  notes=intel.notes_for(u, oid) if u.can("account_notes") else [],
                  contacts=intel.contacts_for(u, oid) if u.can("account_notes") else [], manual_cost=intel.manual_cost_view,
                  **_cons(consumables.for_operator(oid, [f["fleet_id"] for f in d.get("fleets") or []])))


def _cons(c):
    return {"cons": c, "cons_src": consumables.sources(c["rows"]) if c else []}


@router.get("/pipeline")
def pipeline_old(request: Request, u=U):
    if request.query_params.get("export"):
        return pipeline(request, u)
    return redirect("/app/work?" + urlencode({"view": "pipeline", **request.query_params}))


def pipeline(request: Request, u):
    if not u.can("pipeline"):
        return render(request, "app/locked.html", user=u, feature="pipeline", title="Overhaul pipeline")
    kind = request.query_params.get("kind") or None
    try:
        years = min(15, max(3, int(request.query_params.get("years", "10"))))
    except ValueError:
        years = 10
    by_year, rows = data.pipeline(years=years, kind=kind)
    sel = bar_pick(request)
    sort = request.query_params.get("sort", "due")
    sort = sort if sort in data.PIPELINE_SORTS else "due"
    sdir = request.query_params.get("dir") if request.query_params.get("dir") in ("asc", "desc") else data.PIPELINE_SORTS[sort][1]
    if (sort, sdir) != ("due", "asc"):
        rows = data.sort_rows(rows, data.PIPELINE_SORTS, sort, sdir)
    if request.query_params.get("export") and u.can("export"):
        return csv_response("overhaul-pipeline", ["projected_due_year", "subsystem", "operator_name", "model_name", "manufacturer",
                                                  "vehicle_class", "build_year", "qty_active", "pct_of_interval_used"], rows)
    yrs = {}
    for r in by_year:
        yrs.setdefault(r["yr"], {})[r["subsystem"]] = r["cars"]
    base = {"view": "pipeline", "years": years, **({"kind": kind} if kind else {}),
            **({"sort": sort, "dir": sdir} if (sort, sdir) != ("due", "asc") else {})}
    n_all = len(rows)
    rows = bar_rows(rows, sel, lambda r: r["projected_due_year"], lambda r: r["subsystem"])
    return render(request, "app/pipeline.html", user=u, years=yrs, rows=rows[:300], n=len(rows), n_all=n_all, kind=kind, span=years, sort=sort, sdir=sdir,
                  sel=sel, bar_href=bar_links("/app/work", base),
                  sort_base="/app/work?" + urlencode({"view": "pipeline", "years": years, **({"kind": kind} if kind else {})}))


@router.get("/procurements")
def procurements_old(request: Request, u=U):
    return redirect("/app/work?view=orders")


ORDER_KEYS = {"planned": "Planned or out to bid", "delivering": "Awarded, still to deliver", "options": "Unexercised options"}


def order_outlook(rows, yr):
    """Future vehicle-order opportunity by year (Justin, 2026-11-03): cars in orders not yet awarded (by expected award or
    delivery year), cars still to deliver on awarded orders (by first delivery year from now) and unexercised options (by the
    end of the delivery run). Order text is free-form, so years and quantities are read from it and marked as estimates."""
    import re
    out = []
    for p in rows:
        st = (p["status"] or "").lower()
        if any(w in st for w in ("complete", "acquired", "cancel")):
            continue
        aw = [int(y) for y in re.findall(r"\b(20\d\d)\b", p["award_date"] or "")]
        dl = [int(y) for y in re.findall(r"\b(20\d\d)\b", p["delivery"] or "")]
        base, opt = data.first_int(p["qty_base"]), data.first_int(p["qty_options"])
        if any(w in st for w in ("planned", "rfp", "selected", "announced")) and "option" not in st:
            y = next((x for x in aw + dl if x >= yr), yr)
            if base:
                out.append(dict(p=p, year=y, key="planned", cars=base))
        elif "option" in st:
            if base or opt:
                out.append(dict(p=p, year=max([yr] + dl[-1:]), key="options", cars=opt or base))
            continue
        else:
            future = [x for x in dl if x >= yr]
            if base and future:
                out.append(dict(p=p, year=future[0], key="delivering", cars=base))
        if opt:
            out.append(dict(p=p, year=max([yr] + dl[-1:]), key="options", cars=opt))
    out.sort(key=lambda o: (o["year"], o["key"]))
    return out


def procurements(request: Request, u):
    rows = data.procurements()
    yr = intel.this_year()
    opp = order_outlook(rows, yr)
    by_year = {y: {} for y in range(yr, yr + 6)}
    for o in opp:
        by_year.setdefault(o["year"], {}).setdefault(o["key"], 0)
        by_year[o["year"]][o["key"]] += o["cars"]
    sel = bar_pick(request)
    n_all = len(opp)
    opp = bar_rows(opp, sel, lambda o: o["year"], lambda o: o["key"])
    kind = request.query_params.get("kind")  # Opportunity pill filter (1.7.4)
    kind = kind if kind in ORDER_KEYS else None
    if kind:
        opp = [o for o in opp if o["key"] == kind]
    status = (request.query_params.get("status") or "").strip()[:40] or None  # 1.7.34: status pill filter on All orders
    if status:
        rows = [p for p in rows if (p["status"] or "") == status]
    from .nexgen import _builder  # 1.7.35: builder / award-year filters, the drill from Orders and backlog charts
    builder = (request.query_params.get("builder") or "").strip()[:80] or None
    award = (request.query_params.get("award") or "").strip()[:4]
    award = award if award.isdigit() else None
    if builder:
        rows = [p for p in rows if _builder(p["manufacturer"]) == builder]
        opp = [o for o in opp if _builder(o["p"]["manufacturer"]) == builder]
    if award:
        rows = [p for p in rows if str(p["award_date"] or "")[:4] == award]
    f = {k: v for k, v in (("view", "orders"), ("y", request.query_params.get("y")), ("k", request.query_params.get("k")), ("kind", kind), ("status", status),
                           ("builder", builder), ("award", award)) if v}
    return render(request, "app/procurements.html", user=u, f=f, rows=rows, opp=opp, by_year=by_year, sel=sel, n=len(opp), n_all=n_all,
                  ORDER_KEYS=ORDER_KEYS, bar_href=bar_links("/app/work", {k: v for k, v in f.items() if k in ("view", "builder")}))


@router.get("/work/orders/{oid}")
def order_detail(request: Request, oid: int, u=U):
    """1.7.33: a vehicle order's details (Justin 11-11: clicking an order opens it). Under /app/work so it follows that page's access."""
    d = data.procurement(oid)
    if not d:
        raise HTTPException(404)
    yr = intel.this_year()
    outlook = order_outlook([d], yr)
    q = f"Tell me about the {d.get('manufacturer') or ''} {d.get('model') or ''} order for {d.get('operator_id') or ''}: scope, schedule, options and suppliers.".replace("  ", " ")
    return render(request, "app/order.html", user=u, d=d, outlook=outlook, ORDER_KEYS=ORDER_KEYS, analyst_q=q)


# ---------- analyst ----------

@router.get("/analyst")
def analyst_page(request: Request, u=U):
    jobs = db.q("SELECT * FROM analyst_job WHERE user_id = ? AND kind = 'ask' ORDER BY created DESC LIMIT 20", (u["id"],))
    return render(request, "app/analyst.html", user=u, jobs=jobs, ai_on=analyst.available(), ai_left=auth.ai_left(u), ai_paid=auth.ai_allowed(u), ai_access=analyst.access(u),
                  job=request.query_params.get("job"), q=request.query_params.get("q", ""), about=_about_fleet(request.query_params.get("fleet")),
                  docs=__import__("app.uploads", fromlist=["mine"]).mine(u), doc_accept=__import__("app.uploads", fromlist=["ACCEPT"]).ACCEPT)


def _about_fleet(fid):
    """The fleet an "Ask about this fleet" question is about (1.7.24), or None."""
    fid = (fid or "").strip()[:40]
    if not fid:
        return None
    try:
        d = data.fleet(int(fid) if fid.isdigit() else fid)
    except Exception:
        d = None
    return d


@router.post("/analyst")
async def analyst_ask(request: Request, csrf: str = Form(""), question: str = Form(""), fleet: str = Form(""), doc_id: str = Form(""),
                      consent: str = Form(""), doc: UploadFile | None = File(None), u=U):
    auth.check_csrf(request, csrf)
    question = question.strip()[:1200]
    back = "/app/analyst?" + urlencode({k: v for k, v in (("q", question), ("fleet", fleet)) if v})
    if not question:
        return redirect("/app/analyst")
    if not auth.ai_allowed(u):
        flash(request, "The AI analyst is on paid plans. Upgrade to Pro to ask questions.", "bad")
        return redirect("/app/analyst")
    if not analyst.available():
        flash(request, "The AI analyst isn't configured yet. An admin needs to add the API key.", "bad")
        return redirect(back)
    if auth.ai_left(u) <= 0:
        flash(request, "You've used this month's analyst questions. Upgrade for more.", "bad")
        return redirect(back)
    from . import uploads
    up = None
    if doc is not None and (doc.filename or "").strip():  # 1.7.25: a document sent with the question, kept in Consist's repository
        if not consent:
            flash(request, "Tick the box to confirm you may share the document with Consist, then ask again.", "bad")
            return redirect(back)
        raw = await doc.read(uploads.MAX_BYTES + 1)
        try:
            up = uploads.save(u, doc.filename, raw)
        except uploads.UploadError as e:
            flash(request, str(e), "bad")
            return redirect(back)
        db.audit("analyst_upload", f"{up['id']} {up['filename']} {up['size']} bytes", u["id"], u["email"])
        from . import uploadrec
        uploadrec.check_async(up["id"])  # public agency solicitation? reconcile against bids.db, queue for Bid Catcher if new
    elif doc_id:
        up = uploads.get(doc_id, u)
    if not up and re.search(r"\battach(ed|ment)\b|\buploaded\b", question, re.I):  # 1.7.26: the question names a document but none came with it
        flash(request, "No document came with your question. Open \"Attach a document\", choose the file, tick the box, and ask again. "
                       "This didn't use a question.", "bad")
        return redirect(back + ("&" if "?" in back else "?") + "doc=1")
    auth.ai_charge(u)
    about = _about_fleet(fleet)  # "Ask about this fleet": the fleet's record goes in with the question (Justin 2026-11-11)
    ctx = [analyst.fleet_context(about)] if about else []
    if up:
        ctx.append(uploads.context(up))
    ref = "|".join(x for x in ((f"fleet:{about['fleet_id']}" if about else ""), (f"doc:{up['id']}" if up else "")) if x) or None
    job = await run_in_threadpool(analyst.start, u, "ask", question, ref, "\n\n".join(ctx))
    if up:
        uploads.mark_used(up["id"], job)
    return redirect(f"/app/analyst?job={job}" + (f"&fleet={about['fleet_id']}" if about else ""))


@router.get("/analyst/doc/{uid}")
def analyst_doc(request: Request, uid: str, u=U):
    """A member's own uploaded document (admins: any), as a download."""
    from . import uploads
    r = uploads.get(uid, u)
    if not r or not os.path.exists(uploads.path(r)):
        raise HTTPException(404)
    ctype = {"pdf": "application/pdf", "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}.get(r["kind"], "text/plain; charset=utf-8")
    with open(uploads.path(r), "rb") as fh:
        body = fh.read()
    return Response(body, media_type=ctype, headers={"Content-Disposition": f'attachment; filename="{r["filename"]}"', "X-Content-Type-Options": "nosniff"})


@router.post("/analyst/doc/{uid}/delete")
def analyst_doc_delete(request: Request, uid: str, csrf: str = Form(""), u=U):
    from . import uploads
    auth.check_csrf(request, csrf)
    if uploads.delete(uid, u):
        db.audit("analyst_upload_delete", uid, u["id"], u["email"])
        flash(request, "Document deleted.", "ok")
    return redirect("/app/analyst#docs")


@router.get("/analyst/job/{job_id}")
def analyst_job(request: Request, job_id: str, u=U):
    j = db.q("SELECT * FROM analyst_job WHERE id = ? AND user_id = ?", (job_id, u["id"]), one=True)
    if not j:
        raise HTTPException(404, "not found")
    out = {"status": j["status"], "steps": json.loads(j["steps"] or "[]"), "question": j["question"], "error": j["error"]}
    if j["status"] == "done":
        doc = None
        m = re.search(r"doc:([0-9a-f]{8,32})", j["ref"] or "")
        if m:
            d = db.q("SELECT filename FROM analyst_upload WHERE id = ?", (m.group(1),), one=True)
            doc = d["filename"] if d else "a document (since deleted)"
        out["html"] = render(request, "partials/answer.html", user=u, r=json.loads(j["result"]), job=j, doc_name=doc).body.decode()
    return JSONResponse(out)


@router.get("/analyst/job/{job_id}/{fmt}")
def analyst_job_export(request: Request, job_id: str, fmt: str, u=U):
    """A finished AI brief or analyst answer as a branded PDF, an RTF (Word, Pages, Google Docs) or plain text (1.7.15, 1.7.20).
    Any member who can see the brief can save it: it is their own document, not a data export (Justin, 2026-11-09)."""
    from . import pdfbrief
    if fmt not in pdfbrief.FORMATS:
        raise HTTPException(404)
    j = db.q("SELECT * FROM analyst_job WHERE id = ? AND user_id = ?", (job_id, u["id"]), one=True)
    if not j or j["status"] != "done":
        raise HTTPException(404, "That brief isn't ready.")
    title, url, meta = "", "", {}
    if j["kind"] == "brief" and j["ref"]:
        n = data.notice(int(j["ref"])) if str(j["ref"]).isdigit() else None
        if n:
            title = n.get("title") or ""
            meta = {"agency": n.get("agency") or n.get("buyer"), "ref_no": n.get("ref_no"), "published": n.get("published"),
                    "closing": n.get("closing")}
        url = f"{config.SITE_URL.rstrip('/')}/app/bids/{j['ref']}"
    elif str(j["ref"] or "").startswith("fleet:"):  # an "Ask about this fleet" answer (1.7.24): title it with the fleet
        fd = _about_fleet(str(j["ref"]).split("|")[0][6:])
        if fd:
            title = f"{fd.get('operator_name')}: {((fd.get('manufacturer') or '') + ' ' + (fd.get('model_name') or '')).strip()} fleet"
            meta = {"agency": None}
            url = f"{config.SITE_URL.rstrip('/')}/app/fleets/{fd['fleet_id']}"
    site = db.settings().get("site_name", "Consist")
    when = datetime.datetime.fromisoformat(j["created"].replace("Z", "+00:00")) if j["created"] else None
    ctype, fn_build = pdfbrief.FORMATS[fmt]
    body = fn_build(json.loads(j["result"] or "{}"), j["kind"], title, j["question"], site, url, when, meta)
    fn = pdfbrief.filename(j["kind"], j["ref"], j["id"], fmt)
    # inline + the link's download attribute: browsers save it, and the trial download guard (attachments) doesn't apply
    return Response(body, media_type=ctype, headers={"Content-Disposition": f'inline; filename="{fn}"'})


# ---------- alerts and watchlist ----------

@router.get("/alerts")
def alerts_page(request: Request, u=U):
    if request.query_params.get("tab") == "fleet":
        from .routes_intel import updates
        return updates(request, u)
    if not u.bids:
        if u.can("fleet_alerts"):
            return redirect("/app/alerts?tab=fleet")
        return render(request, "app/locked.html", user=u, feature="bids_recent", title="Bid alerts")
    searches = db.q("SELECT * FROM saved_search WHERE user_id = ? ORDER BY id", (u["id"],))
    prefill = params(request, BID_KEYS)
    prefill.pop("status", None)
    prefill.pop("sort", None)
    t = territory.for_user(u)
    digest_on = bool(db.q("SELECT 1 FROM user_pref WHERE user_id = ? AND key = 'territory_digest' AND value = '1'", (u["id"],), one=True))
    return render(request, "app/alerts.html", user=u, digest_on=digest_on, searches=searches, REL_LEVELS=REL_LEVELS, prefill=prefill, agencies=data.agencies(),
                  mail_on=mailer.configured(), ter_label=territory.label(t) if territory.is_set(t) else "")


REL_LEVELS = {"0": "All scores", "25": "25+ (wider net)", "50": "50+ (default)", "75": "75+ (strong matches)", "90": "90+ (best only)"}


@router.post("/alerts")
async def alerts_create(request: Request, u=U):
    form = await request.form()
    csrf, name, q = form.get("csrf", ""), form.get("name", ""), form.get("q", "")
    frequency, territory_only = form.get("frequency", "daily"), form.get("territory_only", "")
    min_rel = form.get("min_rel", "")
    min_rel = min_rel if min_rel in REL_LEVELS and min_rel != "50" else ""  # 1.7.82: relevance floor; 50 is the default, not stored
    # 1.7.74 (Justin 11-18): several categories, subsystems, agencies and countries per alert, stored comma-separated
    pick = lambda k, ok: ",".join(dict.fromkeys(v for v in form.getlist(k) if v and v in ok))  # noqa: E731
    category = pick("category", data.CATEGORIES)
    subsystem = pick("subsystem", data.SUBSYSTEMS)
    country = pick("country", lens.REGIONS)
    agency = ",".join(dict.fromkeys(v for v in form.getlist("agency") if v and "," not in v and len(v) <= 40))
    auth.check_csrf(request, csrf)
    if not u.bids:
        flash(request, "Bid alerts aren't included in your plan.", "bad")
        return redirect("/app/upgrade")
    n = db.q("SELECT count(*) n FROM saved_search WHERE user_id = ?", (u["id"],), one=True)["n"]
    if n >= u.plan["search_limit"]:
        flash(request, f"Your plan allows {u.plan['search_limit']} saved search{'es' if u.plan['search_limit'] != 1 else ''}. Upgrade for more.", "bad")
        return redirect("/app/alerts")
    if frequency == "instant" and not u.can("alerts_instant"):
        frequency = "weekly"
    if frequency == "daily" and not u.can("alerts_instant"):
        frequency = "weekly"
    query = {k: v for k, v in dict(q=q, category=category, country=country, agency=agency, subsystem=subsystem, min_rel=min_rel).items() if v.strip()}
    if territory_only and territory.is_set(territory.for_user(u)):  # 1.7.47: only bids in the member's saved territory
        query["territory"] = "1"
    cats = [data.CATEGORIES[c] for c in category.split(",") if c]
    label = name.strip() or q or (cats[0] + (f" and {len(cats) - 1} more" if len(cats) > 1 else "") if cats else "All rail bids")
    sid = db.x("INSERT INTO saved_search (user_id, name, query, frequency, created) VALUES (?,?,?,?,?)",
               (u["id"], label[:80], json.dumps(query), frequency, db.now()))
    alerts.baseline(sid)
    flash(request, f"Saved. You'll get {frequency} emails for \"{label}\".")
    return redirect("/app/alerts")


@router.post("/alerts/{sid}/test")
def alerts_test(request: Request, sid: int, csrf: str = Form(""), u=U):
    """1.7.79 (Justin 11-19): email this saved search to the member now, as configured, marked as a test."""
    auth.check_csrf(request, csrf)
    if not u.bids:
        flash(request, "Bid alerts aren't included in your plan.", "bad")
        return redirect("/app/alerts")
    ok, msg = alerts.send_test_bid(u, sid)
    flash(request, msg, "ok" if ok else "bad")
    return redirect("/app/alerts")


@router.post("/alerts/{sid}")
def alerts_update(request: Request, sid: int, csrf: str = Form(""), frequency: str = Form(""), delete: str = Form(""),
                  set_territory: str = Form(""), min_rel: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if min_rel in REL_LEVELS and not delete:  # 1.7.82 (Justin 11-19): change an alert's relevance floor
        r = db.q("SELECT query FROM saved_search WHERE id = ? AND user_id = ?", (sid, u["id"]), one=True)
        if r:
            qd = json.loads(r["query"] or "{}")
            if qd.get("min_rel", "50") != min_rel:
                if min_rel == "50":
                    qd.pop("min_rel", None)
                else:
                    qd["min_rel"] = min_rel
                db.x("UPDATE saved_search SET query = ? WHERE id = ? AND user_id = ?", (json.dumps(qd), sid, u["id"]))
                flash(request, f"Relevance for this alert: {REL_LEVELS[min_rel]}.")
    if set_territory in ("0", "1"):  # 1.7.47: turn "only my territory" on or off for this alert
        r = db.q("SELECT query FROM saved_search WHERE id = ? AND user_id = ?", (sid, u["id"]), one=True)
        if r:
            qd = json.loads(r["query"] or "{}")
            if set_territory == "1" and territory.is_set(territory.for_user(u)):
                qd["territory"] = "1"
            else:
                qd.pop("territory", None)
            db.x("UPDATE saved_search SET query = ? WHERE id = ? AND user_id = ?", (json.dumps(qd), sid, u["id"]))
        return redirect("/app/alerts")
    if delete:
        db.x("DELETE FROM saved_search WHERE id = ? AND user_id = ?", (sid, u["id"]))
        flash(request, "Saved search deleted.")
    elif frequency in ("instant", "daily", "weekly", "off"):
        if frequency in ("instant", "daily") and not u.can("alerts_instant"):
            flash(request, "Instant and daily alerts are on paid plans.", "bad")
            return redirect("/app/alerts")
        db.x("UPDATE saved_search SET frequency = ? WHERE id = ? AND user_id = ?", (frequency, sid, u["id"]))
    return redirect("/app/alerts")


def can_save(u):
    """The free plan samples everything but saves nothing (Justin, 2026-11-02): watching needs a paid or contact plan."""
    p = u.plan or {}
    return bool(u.is_admin or p.get("price_month") or p.get("contact_only"))


@router.get("/start")
def start(request: Request, u=U):
    from . import guide
    return render(request, "app/start.html", user=u, sections=guide.sections(u))


@router.get("/learn")
def learn_home(request: Request, u=U):
    """Training portal (Justin, 2026-11-11): Start here plus one module per feature, each with animated walkthroughs."""
    from . import learn
    mods, done = learn.modules_for(u)
    return render(request, "app/learn.html", user=u, mods=mods, ndone=len(done & set(learn.BY_SLUG)))


@router.get("/learn/{slug}")
def learn_module(request: Request, slug: str, u=U):
    from . import learn
    m = learn.BY_SLUG.get(slug)
    if not m:
        raise HTTPException(404)
    i = learn.MODULES.index(m)
    steps = [dict(title=t, text=x, href=h, svg=learn.scene(sc, f"ls-{slug}-{k}", t), clip=learn.clip_for(slug, k))
             for k, (t, x, sc, h) in enumerate(m["steps"])]
    nxt = learn.MODULES[i + 1] if i + 1 < len(learn.MODULES) else None
    prev = learn.MODULES[i - 1] if i else None
    return render(request, "app/learn_module.html", user=u, m=m, steps=steps, nxt=nxt, prev=prev,
                  done=slug in learn.done_set(u), mods=learn.MODULES)


@router.post("/learn/{slug}/done")
def learn_done(request: Request, slug: str, csrf: str = Form(""), undo: str = Form(""), u=U):
    from . import learn
    auth.check_csrf(request, csrf)
    learn.mark_done(u, slug, on=not undo)
    i = [m["slug"] for m in learn.MODULES].index(slug) if slug in learn.BY_SLUG else -1
    nxt = learn.MODULES[i + 1]["slug"] if 0 <= i < len(learn.MODULES) - 1 and not undo else None
    return redirect(f"/app/learn/{nxt}" if nxt else (f"/app/learn/{slug}" if undo else "/app/learn"))


@router.post("/tour")
def tour_done(request: Request, csrf: str = Form(""), later: str = Form(""), u=U):
    """The first-visit welcome card and tour. 'Not now' (later=1) hides the card until the next sign-in; "Don't show again" or
    finishing the tour turns it off for good (saved per user). The tour stays available from Getting started."""
    auth.check_csrf(request, csrf)
    if later:
        request.session["tour_later"] = 1
    else:
        intel.set_pref(u, "tour_done", "1")
    return redirect("/app")


@router.post("/watch")
def watch(request: Request, csrf: str = Form(""), kind: str = Form(""), ref: str = Form(""), back: str = Form("/app"), u=U):
    auth.check_csrf(request, csrf)
    if kind not in ("operator", "notice", "fleet"):
        raise HTTPException(400)
    if db.q("SELECT 1 FROM watch WHERE user_id = ? AND kind = ? AND ref = ?", (u["id"], kind, ref), one=True):
        db.x("DELETE FROM watch WHERE user_id = ? AND kind = ? AND ref = ?", (u["id"], kind, ref))
    elif not can_save(u):
        flash(request, "Saving bids, fleets and operators is on paid plans. Compare plans at /pricing.", "bad")
    else:
        db.x("INSERT INTO watch (user_id, kind, ref, created) VALUES (?,?,?,?)", (u["id"], kind, ref, db.now()))
    return redirect(back if back.startswith("/app") else "/app")


@router.get("/saved")
def saved(request: Request, u=U):
    ids = [int(x) for x in watched(u, "notice") if x.isdigit()]
    rows = [data.notice(i) for i in ids]
    return render(request, "app/saved.html", user=u, rows=[r for r in rows if r], ops=[o for o in data.operators() if o["operator_id"] in watched(u, "operator")])


@router.post("/sources/suggest")
def suggest_source(request: Request, csrf: str = Form(""), agency: str = Form(""), url: str = Form(""), note: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if agency.strip():
        db.x("INSERT INTO source_request (ts, user_id, agency, url, note) VALUES (?,?,?,?,?)", (db.now(), u["id"], agency[:200], url[:500], note[:1000]))
        flash(request, "Thanks. We'll review that source and add it if it publishes rail vehicle work.")
    return redirect(request.headers.get("referer", "/app/bids") if (request.headers.get("referer") or "").startswith(config.SITE_URL) else "/app/bids")


# ---------- account and billing ----------

@router.get("/account")
def account(request: Request, u=U):
    sid = request.query_params.get("session_id")
    if config.STRIPE_ENABLED and (sid or u.get("stripe_customer_id")) and not u.team_owner_id \
            and (u.get("sub_status") or "") not in ("manual", "demo"):  # comped and demo plans are set by hand, not by Stripe
        try:  # take the subscription from Stripe now (back from Checkout or the portal) rather than wait for the webhook
            if billing.sync_checkout(u, sid) if sid else billing.refresh(u):
                u = auth.load_user(u["id"])
        except Exception:
            logging.getLogger("consist").exception("stripe sync for user %s", u["id"])
    team = db.q("SELECT id, email, name, last_login FROM user WHERE team_owner_id = ?", (u["id"],)) if not u.team_owner_id else []
    invites = db.q("SELECT * FROM token WHERE kind = 'invite' AND user_id = ? AND used = 0 AND expires > ?", (u["id"], db.now())) if not u.team_owner_id else []
    return render(request, "app/account.html", user=u, plans=db.offered_plans(), team=team, invites=invites, stripe_on=config.STRIPE_ENABLED,
                  demo=billing.demo_mode(), upgraded=request.query_params.get("upgraded"), ai_left=auth.ai_left(u),
                  persona=intel.pref(u, "persona"), my_personas=intel.personas_for(u), prof=intel.profile(u),
                  profile_fields=intel.PROFILE_FIELDS, segments=intel.SEGMENTS,
                  ter=territory.for_user(u), ter_choices=territory.choices(territory.for_user(u)["ags"]), ter_groups=territory.GROUPS,
                  ter_us=territory.US_STATES, ter_ca=territory.CA_PROVS)


@router.post("/account/profile")
async def account_profile(request: Request, u=U):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    db.x("UPDATE user SET name = ?, company = ? WHERE id = ?", ((form.get("name") or "")[:120], (form.get("company") or "")[:120], u["id"]))
    intel.save_profile(u, form)
    flash(request, "Profile saved.")
    return redirect("/app/account#profile")


@router.post("/account/timezone")
async def account_timezone(request: Request, u=U):
    """1.7.71: the member's time zone for every time on the site and in emails; blank = follow the browser."""
    from . import tz
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    z = (form.get("tz") or "").strip()
    if z and not tz.valid(z):
        flash(request, "That time zone isn't recognized.", "bad")
        return redirect("/app/account#timezone")
    db.x("DELETE FROM user_pref WHERE user_id = ? AND key = 'tz'", (u["id"],)) if not z else intel.set_pref(u, "tz", z)
    tz.forget(u["id"])
    flash(request, f"Times now show in {tz.zone_label(z)}." if z else "Times now follow your browser's time zone.")
    return redirect("/app/account#timezone")


@router.post("/account/delete")
def account_delete(request: Request, csrf: str = Form(""), password: str = Form(""), confirm: str = Form(""), u=U):
    """Cancel any subscription and remove the member's account and data. Needs the password and the word DELETE."""
    auth.check_csrf(request, csrf)
    if u.is_admin:
        flash(request, "Admin accounts can't be removed here. Ask another admin to remove it from Admin > Users.", "bad")
        return redirect("/app/account#delete")
    if confirm.strip().upper() != "DELETE" or not auth.check_pw(password, u["pw_hash"]):
        flash(request, "To remove your account, enter your password and type DELETE.", "bad")
        return redirect("/app/account#delete")
    email = u.email
    st = auth.delete_account(u["id"])
    db.audit("self_delete_account", f"{email} stripe={st}", None, email)
    request.session.clear()
    if st == "failed" and config.ADMIN_EMAIL:  # make sure a person follows up so the member is not billed again
        try:
            mailer.send(config.ADMIN_EMAIL, "Account deleted: cancel Stripe subscription",
                        f"{email} deleted their account but the Stripe subscription could not be cancelled automatically. Cancel it in Stripe.")
        except Exception:
            pass
    flash(request, "Your account and its data have been removed" + (" and your subscription cancelled." if st == "cancelled" else ".")
          + " Sorry to see you go.")
    return redirect("/")


@router.post("/account/password")
def account_password(request: Request, csrf: str = Form(""), current: str = Form(""), new: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if not auth.check_pw(current, u["pw_hash"]):
        flash(request, "Your current password is not right.", "bad")
    elif len(new) < 10:
        flash(request, "Use at least 10 characters.", "bad")
    else:
        db.x("UPDATE user SET pw_hash = ? WHERE id = ?", (auth.hash_pw(new), u["id"]))
        auth.login(request, u)  # keeps this session; every other session is signed out
        flash(request, "Password changed. Other devices have been signed out.")
    return redirect("/app/account")


@router.get("/upgrade")
def upgrade(request: Request, u=U):
    """Every paid plan side by side; ?plan= only marks the one the member came for."""
    plans = [p for p in db.offered_plans() if p["id"] != "free" and (p["price_month"] or p["price_year"] or p["contact_only"])]
    want = request.query_params.get("plan", "")
    return render(request, "app/upgrade.html", user=u, trial_days=(__import__("app.trial", fromlist=["x"]).days_for(u, {"id": "x"}) if config.STRIPE_ENABLED else 0), plans=plans, want=want if any(p["id"] == want for p in plans) else "",
                  interval="year" if request.query_params.get("interval") == "year" else "month",
                  stripe_on=config.STRIPE_ENABLED, demo=billing.demo_mode())


@router.post("/upgrade")
def upgrade_post(request: Request, csrf: str = Form(""), plan: str = Form(""), interval: str = Form("month"), u=U):
    auth.check_csrf(request, csrf)
    if u.real_admin:  # an admin previewing a plan never starts a real checkout
        flash(request, "You're previewing a plan as an admin, so checkout is off. Use the bar at the top to switch plans.", "bad")
        return redirect("/app/upgrade")
    if u.team_owner_id:
        flash(request, "Your team owner manages billing.", "bad")
        return redirect("/app/account")
    p = db.get_plan(plan)
    if not db.offered_plans([p]):
        return redirect("/rail")
    if p["contact_only"]:
        return redirect("/contact?topic=enterprise")
    if p["id"] == "free":
        return redirect("/app/account")
    if config.STRIPE_ENABLED:
        try:
            url = billing.checkout_url(u, p, interval)
        except Exception as e:
            from . import syslog
            syslog.record("error", "stripe", f"Checkout could not start: {type(e).__name__}: {e}"[:400], "checkout_start", "/app/upgrade", "POST",
                          {"plan": p["id"], "interval": interval}, u["id"])
            flash(request, f"Checkout could not start ({type(e).__name__}). Please try again or contact support.", "bad")
            return redirect("/app/account")
        if url:
            return redirect(url)
        flash(request, "That plan isn't set up for online checkout yet. Contact us and we'll get you started.", "bad")
        return redirect("/app/account")
    if billing.demo_mode():
        db.x("UPDATE user SET plan_id = ?, sub_status = 'demo', interval = ? WHERE id = ?", (p["id"], interval, u["id"]))
        db.audit("demo_upgrade", p["id"], u["id"])
        flash(request, f"You're on {p['name']} (demo billing: no card was charged).")
        return redirect("/app/account")
    flash(request, "Online checkout isn't available yet. Contact us to subscribe.", "bad")
    return redirect("/contact")


@router.post("/billing/portal")
def billing_portal(request: Request, csrf: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if not config.STRIPE_ENABLED:
        if u.get("sub_status") == "demo":
            db.x("UPDATE user SET plan_id = 'free', sub_status = NULL WHERE id = ?", (u["id"],))
            flash(request, "Demo subscription cancelled. You're back on the free plan.")
        return redirect("/app/account")
    try:
        return redirect(billing.portal_url(u))
    except Exception as e:
        from . import syslog
        syslog.record("error", "stripe", f"Billing portal could not open: {type(e).__name__}: {e}"[:400], "portal", "/app/billing/portal", "POST", None, u["id"])
        flash(request, f"Billing portal unavailable ({type(e).__name__}).", "bad")
        return redirect("/app/account")


@router.post("/team/invite")
def team_invite(request: Request, csrf: str = Form(""), email: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    email = email.strip().lower()
    seats = u.plan["seats"]
    used = 1 + db.q("SELECT count(*) n FROM user WHERE team_owner_id = ?", (u["id"],), one=True)["n"] + \
        db.q("SELECT count(*) n FROM token WHERE kind = 'invite' AND user_id = ? AND used = 0 AND expires > ?", (u["id"], db.now()), one=True)["n"]
    if u.team_owner_id or used >= seats:
        flash(request, f"Your plan has {seats} seat{'s' if seats != 1 else ''}. Upgrade to Team to add people.", "bad")
        return redirect("/app/account")
    if "@" not in email:
        flash(request, "Enter an email address.", "bad")
        return redirect("/app/account")
    tok = auth.make_token("invite", u["id"], email, hours=24 * 7)
    link = f"{config.SITE_URL}/invite/{tok}"
    site = db.settings().get("site_name")
    sent = False
    try:
        sent = mailer.send(email, f"{u.name or u.email} invited you to {site}", f"Join your team on {site}: {link}\n\nThis link works for 7 days.")
    except Exception:
        pass
    flash(request, f"Invitation sent to {email}." if sent else f"Invitation created. Send this link to {email}: {link}")
    return redirect("/app/account")


@router.post("/team/remove")
def team_remove(request: Request, csrf: str = Form(""), member_id: int = Form(0), token: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if member_id:
        db.x("UPDATE user SET team_owner_id = NULL WHERE id = ? AND team_owner_id = ?", (member_id, u["id"]))
    if token:
        db.x("UPDATE token SET used = 1 WHERE token = ? AND user_id = ?", (token, u["id"]))
    flash(request, "Team updated.")
    return redirect("/app/account")
