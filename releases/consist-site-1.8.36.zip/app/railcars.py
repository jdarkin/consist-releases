"""Freight cars by owner type (private X-mark vs railroad vs TTX): STB waybill sample, FRA accidents by reporting mark,
lessor 10-K fleets and BTS tank car figures. Tables in fra.db, built by tools/freightcars (see fleet-db/freightcars/README.md)."""
from . import fra

OWN = {"P": "Private (X mark)", "R": "Railroad", "T": "TTX"}
INTERMODAL = (46, 47)  # STB car types whose ownership coding is comparable only from 2021
CREDIT = ("Source: STB Public Use Waybill Sample (expanded values); FRA Office of Safety Analysis (Form 54 rail equipment accidents); "
          "BTS Progress Toward Safer Rail Tank Cars; GATX, Trinity and Greenbrier 10-K filings.")
DEF = {
    "ownership": ("Owner type", "Private = reporting mark ends in X (lessors and shippers), excluding TTX. Railroad = a railroad's own mark. TTX = the railroad-owned car pool, counted on its own by the STB."),
    "carloads": ("Carloads", "Carloads in the STB waybill sample, expanded to the full year. A sample estimate, not a census."),
    "tons": ("Tons", "Tons carried, expanded waybill sample."),
    "revenue_usd": ("Revenue", "Freight revenue on the waybill, expanded. Includes revenue on cars the railroad does not own."),
    "car_miles": ("Car-miles", "Loaded car-miles (short-line miles), expanded."),
    "ton_miles": ("Ton-miles", "Expanded tons x short-line miles."),
    "private_share": ("Private share", "The share of private (X-mark) cars in this measure for this car type or year. It shows how much traffic moves in private cars. It does not show how many private cars there are. Only Railinc UMLER has the fleet count by mark, and it is licensed."),
    "avg_capacity_cuft": ("Average capacity", "Average cubic capacity of the cars, carload weighted, cubic feet."),
    "avg_tare_tons": ("Average tare", "Average empty weight of the cars, tons."),
    "aar_equipment_type": ("AAR equipment code", "AAR mechanical designation of the car, for example T106 (tank car) or C214 (covered hopper)."),
    "commodity": ("Commodity", "STCC two-digit commodity group on the waybill."),
    "mark": ("Reporting mark", "The car's reporting mark from FRA accident reports."),
    "reports": ("Accident reports", "FRA Form 54 rail equipment accident reports where the car was the first car involved (or the car that caused it). A joint accident filed by two railroads counts twice."),
    "causing": ("Caused by the car", "Reports where the car itself was identified as causing the accident."),
    "hazmat_release_reports": ("Hazmat releases", "Accident reports involving this mark with a hazardous materials release."),
    "total_damage_usd": ("Damage", "Total reported equipment and track damage, US dollars as filed with FRA."),
    "owner": ("Owner", "Owner of the reporting mark. We show it as fact only when it has a source or high confidence. 'Believed' means medium confidence. Mark owners can change. For example, the Wells Fargo Rail marks moved to the GATX-Brookfield venture on 2026-01-01."),
    "railcars": ("Railcars", "Cars owned at fiscal year end as stated in the company's 10-K. GATX is worldwide; Greenbrier figures are approximate as stated."),
    "utilization_pct": ("Utilization", "Share of the lease fleet on lease at year end (GATX: Rail North America)."),
}


def available():
    try:
        return bool(fra.q("SELECT 1 FROM wb_car_year LIMIT 1"))
    except Exception:
        return False


def years():
    return fra.cached("rc_years", lambda: [r["year"] for r in fra.q("SELECT DISTINCT year FROM wb_car_year ORDER BY year")])


def comparable(y):
    r = fra.q("SELECT intermodal_comparable FROM wb_meta WHERE year = ?", (y,))
    return bool(r and r[0]["intermodal_comparable"])


def share_trend():
    out = {}
    for r in fra.q("SELECT year, ownership, sum(carloads) c, sum(revenue_usd) v, sum(ton_miles) tm FROM wb_car_year "
                   "WHERE year >= 2021 OR stb_car_type NOT IN (46, 47) GROUP BY 1, 2"):
        out.setdefault(r["year"], {})[r["ownership"]] = r
    rows = []
    for y, g in sorted(out.items()):
        tot = {k: sum((x[k] or 0) for x in g.values()) for k in ("c", "v", "tm")}
        p = g.get("P", {})
        rows.append(dict(year=y, carloads=tot["c"], private_carloads=_pct(p.get("c"), tot["c"]), private_revenue=_pct(p.get("v"), tot["v"]),
                         private_ton_miles=_pct(p.get("tm"), tot["tm"]), **{o: _pct((g.get(o) or {}).get("c"), tot["c"]) for o in OWN}))
    return rows


def _pct(a, b):
    return 100 * a / b if a and b else None


def by_car_type(y):
    g = {}
    for r in fra.q("SELECT stb_car_type, car_type, ownership, carloads, revenue_usd, ton_miles, avg_capacity_cuft, avg_tare_tons FROM wb_car_year WHERE year = ?", (y,)):
        d = g.setdefault(r["stb_car_type"], dict(code=r["stb_car_type"], car_type=r["car_type"], tot=0, P=0, R=0, T=0, cap=None, tare=None))
        d["tot"] += r["carloads"] or 0
        d[r["ownership"]] = (d.get(r["ownership"]) or 0) + (r["carloads"] or 0)
        if r["ownership"] == "P":
            d["cap"], d["tare"] = r["avg_capacity_cuft"], r["avg_tare_tons"]
    rows = sorted(g.values(), key=lambda d: -d["tot"])
    for d in rows:
        d["share"] = {o: _pct(d[o], d["tot"]) for o in OWN}
        d["flag"] = d["code"] in INTERMODAL and not comparable(y)
    return rows


def commodities(y, own="P", n=15):
    return fra.q("SELECT commodity, sum(carloads) carloads, sum(tons) tons, sum(revenue_usd) revenue_usd FROM wb_car_commodity "
                 "WHERE year = ? AND ownership = ? GROUP BY commodity ORDER BY carloads DESC LIMIT ?", (y, own, n))


def equipment(y, n=25):
    rows = fra.q("SELECT aar_equipment_type, ownership, carloads, avg_capacity_cuft, avg_tare_tons FROM wb_equipment WHERE year = ?", (y,))
    g = {}
    for r in rows:
        d = g.setdefault(r["aar_equipment_type"], dict(code=r["aar_equipment_type"], tot=0, P=0, cap=r["avg_capacity_cuft"], tare=r["avg_tare_tons"]))
        d["tot"] += r["carloads"] or 0
        if r["ownership"] == "P":
            d["P"] += r["carloads"] or 0
    out = sorted(g.values(), key=lambda d: -d["tot"])[:n]
    for d in out:
        d["share"] = _pct(d["P"], d["tot"])
    return out


def marks(q="", since=2016, n=40):
    q = (q or "").strip().upper()
    args = [since]
    where = "y.year >= ?"
    if q:
        where += " AND (y.mark LIKE ? OR upper(coalesce(o.owner, '')) LIKE ? OR upper(coalesce(o.parent, '')) LIKE ?)"
        args += [q + "%", "%" + q + "%", "%" + q + "%"]
    rows = fra.q(f"""SELECT y.mark, coalesce(o.category, CASE WHEN y.mark LIKE '%X' THEN 'Private' END) category, o.owner, o.parent, o.confidence,
                     sum(CASE WHEN y.role = 'first' THEN y.reports END) reports, sum(CASE WHEN y.role <> 'first' THEN y.reports END) causing,
                     sum(CASE WHEN y.role = 'first' THEN y.hazmat_release_reports END) hazmat_release_reports,
                     sum(CASE WHEN y.role = 'first' THEN y.total_damage_usd END) total_damage_usd
                     FROM fra_car_mark_year y LEFT JOIN fra_car_mark_owner o ON o.mark = y.mark WHERE {where}
                     GROUP BY y.mark ORDER BY reports DESC LIMIT {int(n)}""", args)
    for r in rows:
        c = (r["confidence"] or "").lower()
        r["owner_show"] = r["owner"] if c in ("sourced", "high") else (f"{r['owner']} (believed)" if c == "medium" and r["owner"] else "")
    return rows


def mark_categories(since=2016):
    return fra.q("""SELECT coalesce(o.category, CASE WHEN y.mark LIKE '%X' THEN 'Private' ELSE 'Other' END) category,
                    sum(y.reports) reports, sum(y.hazmat_release_reports) hazmat FROM fra_car_mark_year y LEFT JOIN fra_car_mark_owner o ON o.mark = y.mark
                    WHERE y.year >= ? AND y.role = 'first' GROUP BY 1 ORDER BY 2 DESC""", (since,))


def lessors():
    return fra.q("SELECT company, ticker, fiscal_year_end, railcars, utilization_pct, scope, source FROM freight_lessor_fleet ORDER BY company, fiscal_year_end")


def tank_cars():
    return fra.q("SELECT year, metric, value, unit, source FROM bts_tank_car_fl ORDER BY year, metric")


# ---- Fleet coverage: how much of the North American freight car fleet Consist can name, from public sources ----
FLEET_SEED = __import__("os").path.join(__import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))),
                                        "seed", "freight_fleet_counts.csv")
NA_FLEET = 1_600_000          # industry-cited North American fleet, about 1.6 to 1.67 million cars (AAR / Railway Age 2025)
NON_RAILROAD_SHARE = 0.60     # "more than 60%" of cars are owned or leased by non-railroads (industry commentary); TTX counts as railroad
CLASS1_LEASED_SHARE = 0.29    # CPKC's leased share at 2025 year end, used to estimate lessor cars also inside Class I counts
GAPS = [
    ("CN in Canada", "Only CN's US lines (Grand Trunk Corp., R-1) are counted; CN does not publish a total car count in its annual report."),
    ("Shipper-owned fleets", "Chemical, grain, energy, plastics and utility companies that own their own cars (X marks) rarely publish counts."),
    ("Smaller lessors", "Chicago Freight Car Leasing, Modern Rail Capital (ex Mitsui), Midwest Railcar, Infinity Rail, Andersons-era and private-equity fleets: no public counts."),
    ("Regional and short line railroads", "About 620 Class II and III railroads; few publish car counts (Genesee & Wyoming and Watco are private)."),
    ("Mexico", "Ferromex and other Mexican fleets are outside the US and Canada scope."),
]
LICENSED = [
    ("Railinc UMLER", "The industry's car-by-car registry: every car, owner, type and status. Licensed through Railinc; redistribution limited, so we would show derived totals only."),
    ("AAR Railroad Facts / Equipment reports", "Fleet by owner type (railroad, TTX, lessor, shipper) and car type each year. Copyrighted; derived figures with credit."),
    ("Official Railway Equipment Register", "Reporting marks and car series by owner. Licensed."),
]


def fleet_counts():
    import csv, os
    if not os.path.exists(FLEET_SEED):
        return []
    with open(FLEET_SEED, newline="") as f:
        rows = [dict(r, cars=int(r["cars"])) for r in csv.DictReader(f) if r.get("counted", "1") == "1"]
    return rows


def coverage():
    rows = fleet_counts()
    by = {}
    for r in rows:
        by.setdefault("Railroads (Class I and TTX)" if r["owner_type"] in ("Class I railroad", "Railroad pool") else "Lessors and shippers", []).append(r)
    rr = sum(r["cars"] for r in by.get("Railroads (Class I and TTX)", []))
    ls = sum(r["cars"] for r in by.get("Lessors and shippers", []))
    c1 = sum(r["cars"] for r in rows if r["owner_type"] == "Class I railroad")
    overlap = round(c1 * CLASS1_LEASED_SHARE, -3)
    tot_rr, tot_ls = NA_FLEET * (1 - NON_RAILROAD_SHARE), NA_FLEET * NON_RAILROAD_SHARE
    named = rr + ls
    dedup = named - overlap
    return dict(rows=rows, groups=[("Railroads (Class I and TTX)", rr, tot_rr), ("Lessors and shippers", ls, tot_ls)],
                named=named, overlap=overlap, dedup=dedup, total=NA_FLEET, pct=100 * dedup / NA_FLEET, pct_hi=100 * min(named, NA_FLEET) / NA_FLEET)


DEF.update({
    "coverage": ("Fleet coverage", "Freight cars Consist can name from public filings and company statements, against the roughly 1.6 million car North American fleet. Counts come from different dates and definitions (owned vs managed, North America vs worldwide), so coverage is an estimate."),
    "overlap": ("Overlap", "Class I car counts include cars the railroads lease, many of them from the lessors also listed. Estimated at 29% of Class I cars (CPKC's leased share) and taken off the total."),
})
