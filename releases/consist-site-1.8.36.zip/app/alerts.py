"""Saved-search email alerts. A background thread checks every 10 minutes: instant searches send whenever new notices match,
daily ones once a day, weekly ones on Mondays. Each search remembers the highest notice id it has already sent.
The same loop compares fleet records once a day (intel.detect_changes) and emails each user the changes on fleets they follow."""
import datetime
import html
import json
import logging
import threading
import time

from . import auth, config, data, db, intel, mailer

log = logging.getLogger("consist.alerts")


# ---------- 1.8.7 (Justin 11-20): each member picks when daily and weekly emails go out ----------
SEND_DEFAULT = {"hour": 7, "day": 0}  # 7 AM on Monday in the member's own time zone
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def send_time(u):
    """{'hour': 0-23, 'day': 0-6 (Monday = 0)} in the member's own zone, from user_pref alert_time."""
    try:
        v = json.loads(intel.pref(u, "alert_time") or "{}")
        h, d = int(v.get("hour", SEND_DEFAULT["hour"])), int(v.get("day", SEND_DEFAULT["day"]))
        return {"hour": h if 0 <= h <= 23 else SEND_DEFAULT["hour"], "day": d if 0 <= d <= 6 else SEND_DEFAULT["day"]}
    except Exception:
        return dict(SEND_DEFAULT)


def set_send_time(u, hour, day):
    intel.set_pref(u, "alert_time", json.dumps({"hour": int(hour), "day": int(day)}))


def time_options(u):
    """The picker: each hour labeled in the member's zone with the UTC hour beside it (Justin asked for both), at today's offset."""
    import zoneinfo
    from . import tz
    zn = tz.for_user(u)
    try:
        z = zoneinfo.ZoneInfo(zn)
    except Exception:
        z = zoneinfo.ZoneInfo(tz.DEFAULT)
    today = datetime.datetime.now(z).date()
    out = []
    for h in range(24):
        loc = datetime.datetime(today.year, today.month, today.day, h, tzinfo=z)
        utc = loc.astimezone(datetime.timezone.utc)
        lab = loc.strftime("%-I:%M %p")
        out.append((h, f"{lab} {loc.tzname()} · {utc.strftime('%H:%M')} UTC" + (" (next day)" if utc.date() > loc.date() else " (day before)" if utc.date() < loc.date() else "")))
    return {"hours": out, "days": list(enumerate(DAYS)), "zone": tz.zone_label(zn), "sel": send_time(u)}


def _local(u, now):
    import zoneinfo
    from . import tz
    try:
        z = zoneinfo.ZoneInfo(tz.for_user(u))
    except Exception:
        z = zoneinfo.ZoneInfo(tz.DEFAULT)
    return now.astimezone(z), z


def scheduled_due(freq, last, now, u):
    """Daily: once a local day, at or after the member's hour. Weekly: on their day, at or after their hour. last = UTC ISO."""
    if freq not in ("daily", "weekly"):
        return False
    st = send_time(u)
    loc, z = _local(u, now)
    if loc.hour < st["hour"] or (freq == "weekly" and loc.weekday() != st["day"]):
        return False
    if not last:
        return True
    try:
        ld = datetime.datetime.fromisoformat(str(last).replace("Z", "+00:00"))
        ld = (ld if ld.tzinfo else ld.replace(tzinfo=datetime.timezone.utc)).astimezone(z).date()
    except ValueError:
        return True
    return ld < loc.date()


def due(s, now, u=None):
    if s["frequency"] == "instant":
        return True
    return scheduled_due(s["frequency"], s["last_sent"] or "", now, u or {"id": s["user_id"]})


# ---------- 1.8.8 (Justin 11-20): an item goes out once per alert ----------
# alert_sent remembers every bid (and fleet change) each alert has emailed, under several keys, so the same bid posted again
# (a new notice id from another source, a duplicate, an amended re-post with the same reference number) is not sent twice.
# Send test ignores it. Rows older than 400 days are pruned.
_SENT_DDL = "CREATE TABLE IF NOT EXISTS alert_sent (scope TEXT, item TEXT, sent TEXT, PRIMARY KEY (scope, item))"
_sent_ok = []


def _sent_table():
    if not _sent_ok:
        db.x(_SENT_DDL)
        _sent_ok.append(1)


def _norm(v):
    import re
    return re.sub(r"[^a-z0-9]", "", (v or "").lower())


def notice_keys(n):
    ks = [f"n:{n['notice_id']}"]
    if n.get("dup_of"):
        ks.append(f"n:{n['dup_of']}")
    ag = n.get("agency_id") or _norm(n.get("agency"))
    if n.get("ref_no") and len(_norm(n["ref_no"])) >= 4:
        ks.append(f"r:{ag}|{_norm(n['ref_no'])}")
    t = _norm(n.get("title"))
    if len(t) >= 12:
        ks.append(f"t:{ag}|{t[:120]}")
    return ks


def event_keys(e):
    return [f"e:{e['id']}", f"c:{e['fleet_id']}|{e.get('kind')}|{_norm(e.get('detail'))[:160]}"] if e.get("id") is not None else \
        [f"c:{e['fleet_id']}|{e.get('kind')}|{_norm(e.get('detail'))[:160]}"]


def unsent(scope, items, keyf):
    """Items whose keys this alert has never sent; also drops repeats within the batch (newest kept)."""
    if not items:
        return items
    _sent_table()
    seen = {r["item"] for r in db.q("SELECT item FROM alert_sent WHERE scope = ?", (scope,))}
    out = []
    for it in items:
        ks = keyf(it)
        if any(k in seen for k in ks):
            continue
        seen.update(ks)
        out.append(it)
    return out


def mark_sent(scope, items, keyf):
    _sent_table()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    for it in items:
        for k in keyf(it):
            db.x("INSERT OR IGNORE INTO alert_sent (scope, item, sent) VALUES (?, ?, ?)", (scope, k, now))
    if datetime.datetime.now().minute < 10:  # now and then: keep about a year
        db.x("DELETE FROM alert_sent WHERE sent < ?", ((datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=400)).isoformat(),))


# ---------- 1.8.8 (Justin 11-20): what each email includes, per alert ----------
SEND_MODES = {"new": "Only new items since the last email", "all": "All current matches, every time"}


def send_mode(s):
    """'new' (default): an item goes out once per alert. 'all': every current match each time. Stored in saved_search.query 'send'
    only when it is 'all'."""
    try:
        return "all" if json.loads(s["query"] or "{}").get("send") == "all" else "new"
    except (TypeError, ValueError):
        return "new"


def fleet_send_mode(u):
    from . import intel
    return "all" if intel.pref(u, "fleet_send") == "all" else "new"


def matches(s, test=False):
    """test=True (1.7.79 Send test): the newest 10 matches whatever was already sent, so a test always shows real bids."""
    f = json.loads(s["query"] or "{}")
    f = {k: v for k, v in f.items() if k in ("q", "category", "country", "agency", "operator", "subsystem", "min_rel")}
    mode = send_mode(s)
    f["status"] = "open" if (mode == "all" and not test) else "all"  # 1.8.8: "All current matches" = every bid still open
    f["after_id"] = 0 if (test or mode == "all") else (s["last_notice_id"] or 0)
    tok = None
    if json.loads(s["query"] or "{}").get("territory") == "1":  # 1.7.47: "only my territory", using the member's saved territory
        from . import lens, territory
        t = territory.for_user({"id": s["user_id"]})
        if territory.is_set(t):
            ops, ags = territory.resolve(t)
            tok = lens.set_current(lens.Scope(territory=(ops, ags, territory.label(t))))
    try:
        rows, _ = data.notices(f, per=10 if test else 50)
    finally:
        if tok is not None:
            from . import lens
            lens.reset(tok)
    return rows


# ---------- 1.8.9 (Justin 11-20): what each bid in an alert email shows, and a fixed line automations can read ----------
CONTENT = {"cats": "Category and subsystem pills", "tags": "Machine-readable tag line (CONSIST-TAGS)", "agency": "Agency and location",
           "closing": "Closing date", "relevance": "Relevance score", "summary": "Summary", "link": "Link to the agency posting"}
TAGS_HELP = ("Each bid has one line that starts with CONSIST-TAGS v1. Then come fields, separated by \" | \". "
             "The fields are: notice (Consist bid id), category (one slug), subsystems (slugs separated by ;), agency_id, country, "
             "ref (the agency's reference number), relevance (0 to 100), closing (YYYY-MM-DD) and posted (YYYY-MM-DD). "
             "A field with no value is not shown. Slugs do not change, but we can add new slugs. "
             "The email also has an X-Consist-Categories header with each category slug in it.")


def content(s):
    """The CONTENT keys this alert shows. Stored in saved_search.query 'hide' (comma list) only when something is switched off."""
    try:
        hide = set(str(json.loads(s["query"] or "{}").get("hide") or "").split(","))
    except (TypeError, ValueError):
        hide = set()
    return [k for k in CONTENT if k not in hide]


def _subs(n):
    return [x for x in str(n.get("subsystems") or "").replace(",", ";").split(";") if x.strip()]


def tag_line(n):
    """CONSIST-TAGS v1 | notice=123 | category=vehicle_procurement | subsystems=hvac;brakes | agency_id=TTC | ... (see TAGS_HELP)."""
    import re
    clean = lambda v: re.sub(r"[|\r\n]+", " ", str(v)).strip()  # noqa: E731
    f = [("notice", n.get("notice_id")), ("category", n.get("category")), ("subsystems", ";".join(_subs(n))),
         ("agency_id", n.get("agency_id")), ("country", n.get("country")), ("ref", n.get("ref_no")),
         ("relevance", n.get("relevance")), ("closing", (n.get("closing") or "")[:10]), ("posted", (n.get("published") or "")[:10])]
    return "CONSIST-TAGS v1 | " + " | ".join(f"{k}={clean(v)}" for k, v in f if v not in (None, ""))


def tag_headers(rows):
    cats = sorted({n.get("category") for n in rows if n.get("category")})
    return {"X-Consist-Categories": ";".join(cats)} if cats else {}


def render(site, s, rows, test=False):
    lines = [f"{len(rows)} new rail bid{'s' if len(rows) != 1 else ''} match your search \"{s['name']}\".", ""]
    if send_mode(s) == "all":  # 1.8.8
        lines = [f"{len(rows)} open rail bid{'s' if len(rows) != 1 else ''} match your search \"{s['name']}\" (all current matches).", ""]
    if test:
        lines = [TEST_NOTE_BID.format(n=len(rows), name=s["name"]), ""]
    items = []
    srcs = sources(rows)
    show = set(content(s))
    pill = ("display:inline-block;border:1px solid #b9d9d2;background:#eef7f5;color:#0b4f45;border-radius:10px;"
            "padding:1px 8px;margin:2px 4px 0 0;font-size:12px")
    for n in rows:
        src_label, src_url = srcs.get(n["notice_id"], (None, None))
        if "link" not in show:
            src_label, src_url = None, None
        # 1.7.33: a French or Spanish notice leads with its English machine translation (bids-push22), original title below;
        # the original alone until the translation lands.
        main, orig = (n.get("title_en"), n["title"]) if n.get("title_en") else (n["title"], None)
        cat_labels = ([data.CATEGORIES.get(n.get("category"), n.get("category"))] if n.get("category") else []) + \
                     [data.SUBSYSTEMS.get(x, x) for x in _subs(n)]
        meta = " · ".join(x for x in ((n.get("agency") or "") if "agency" in show else "",
                                      f"closes {n['closing']}" if n.get("closing") and "closing" in show else "",
                                      f"relevance {n['relevance']}" if "relevance" in show and n.get("relevance") is not None else "") if x)
        lines.append(f"- {main}" + (f" ({meta})" if meta else "") + (f"\n  Original: {orig}" if orig else "")
                     + (f"\n  Categories: {', '.join(cat_labels)}" if "cats" in show and cat_labels else "")
                     + (f"\n  {tag_line(n)}" if "tags" in show else "")
                     + (f"\n  {src_label}: {src_url}" if src_url else ""))  # 1.7.81 (Justin 11-19): agency link only, no Consist link
        head = (f"<a href='{html.escape(src_url)}' style='color:#0b6b5d;font-weight:600'>{html.escape(main or '')}</a>" if src_url
                else f"<b>{html.escape(main or '')}</b>")
        items.append(f"<li style='margin:0 0 14px'>{head}"
                     + (f"<br><span style='color:#5c6670;font-size:12px'>{html.escape(orig)} (original; English is a machine translation)</span>" if orig else "")
                     + (f"<br><span style='color:#5c6670;font-size:13px'>{html.escape(meta)}</span>" if meta else "")
                     + ("<br>" + "".join(f"<span style='{pill}'>{html.escape(c or '')}</span>" for c in cat_labels) if "cats" in show and cat_labels else "")
                     + (f"<br><span style='font-size:13px'>{html.escape(n.get('restricted_note') or n.get('summary') or '')}</span>" if "summary" in show else "")
                     + (f"<br><a href='{html.escape(src_url)}' style='color:#0b6b5d;font-size:13px'>{html.escape(src_label)} ↗</a>" if src_url else "")
                     + (f"<br><code style='font-family:Consolas,Menlo,monospace;font-size:11px;color:#5c6670'>{html.escape(tag_line(n))}</code>" if "tags" in show else "")
                     + "</li>")
    lines += ["", f"Manage alerts: {config.SITE_URL}/app/alerts"]
    body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} bid alert: "
            f"{html.escape(s['name'])}</h2>{_test_banner(lines[0]) if test else ''}<ul style='padding-left:18px'>{''.join(items)}</ul><p style='font-size:12px;color:#5c6670'>"
            f"<a href='{config.SITE_URL}/app/alerts'>Manage alerts</a></p></div>")
    return "\n".join(lines), body


def sources(rows):
    """1.7.80 (Justin 11-19): {notice_id: (label, url)} linking each bid to its original source at the agency: the posting itself
    when we have its page, else the agency's bidding portal (agency_link / agency.portal_url). Only http(s) links."""
    import re
    ok = lambda u: (u or "").strip() if re.match(r"(?i)^https?://", (u or "").strip()) else ""  # noqa: E731
    out, need = {}, []
    for n in rows:
        u = ok(n.get("url"))
        if u:
            out[n["notice_id"]] = ("Original posting on the agency site", u)
        elif n.get("agency_id"):
            need.append(n)
    if need:
        try:
            links = data.agency_links([n["agency_id"] for n in need])
        except Exception as e:
            log.warning("agency links for alert failed: %s", e)
            links = {}
        for n in need:
            bids = [x for x in links.get(n["agency_id"], []) if x["kind"] == "bids" and ok(x["url"])]
            if bids:
                out[n["notice_id"]] = (f"{n.get('agency') or 'Agency'} bidding portal", ok(bids[0]["url"]))
    return out


def run_once():
    now = datetime.datetime.now(datetime.timezone.utc)
    site = db.settings().get("site_name", "Consist")
    sent = 0
    for s in db.q("SELECT s.*, u.email FROM saved_search s JOIN user u ON u.id = s.user_id WHERE s.frequency != 'off' AND u.status = 'active'"):
        u = auth.load_user(s["user_id"])
        if not u:
            continue
        if not u.bids:  # a fleet-only plan has no bid monitoring
            continue
        if s["frequency"] == "instant" and not u.can("alerts_instant"):
            continue
        if not due(s, now, u):
            continue
        rows = matches(s)
        top = max([n["notice_id"] for n in rows], default=s["last_notice_id"] or 0)
        if send_mode(s) == "new":
            rows = unsent(f"s:{s['id']}", rows, notice_keys)  # 1.8.8: a bid goes out once per alert, even if it is posted again
        if rows:
            text, body = render(site, s, rows)
            try:
                ok = mailer.send(s["email"], (f"{site}: {len(rows)} new rail bid{'s' if len(rows) != 1 else ''} for \"{s['name']}\"" if send_mode(s) == "new"
                                   else f"{site}: {len(rows)} open rail bid{'s' if len(rows) != 1 else ''} for \"{s['name']}\""), text, body, alerts=True, optional=True, headers=tag_headers(rows))
                if ok:
                    mark_sent(f"s:{s['id']}", rows, notice_keys)
                sent += 1
            except Exception as e:
                log.error("alert to %s failed: %s", s["email"], e)
                continue
        if rows or s["frequency"] != "instant":
            db.x("UPDATE saved_search SET last_sent = ?, last_notice_id = ? WHERE id = ?", (now.isoformat(), top, s["id"]))
    return sent


def fleet_due(freq, last, now, u=None):
    return scheduled_due(freq, last, now, u) if u else False


def render_fleet(site, events, test=False):
    lines = [f"{len(events)} change{'s' if len(events) != 1 else ''} to fleets you follow.", ""]
    if test:
        lines = [TEST_NOTE_FLEET.format(n=len(events)), ""]
    items = []
    for e in events:
        fl = e.get("fleet") or {}
        name = f"{fl.get('operator_name', e['operator_id'])}: {fl.get('manufacturer') or ''} {fl.get('model_name', '')}".strip()
        url = f"{config.SITE_URL}/app/fleets/{e['fleet_id']}"
        lines.append(f"- {name}\n  {e['detail']}\n  {url}")
        items.append(f"<li style='margin:0 0 12px'><a href='{url}' style='color:#0b6b5d;font-weight:600'>{html.escape(name)}</a><br>"
                     f"<span style='font-size:13px'>{html.escape(e['detail'] or '')}</span></li>")
    lines += ["", f"Change how often you get these: {config.SITE_URL}/app/updates"]
    body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} fleet updates</h2>"
            f"{_test_banner(lines[0]) if test else ''}<ul style='padding-left:18px'>{''.join(items)}</ul><p style='font-size:12px;color:#5c6670'>"
            f"<a href='{config.SITE_URL}/app/updates'>Fleet update settings</a></p></div>")
    return "\n".join(lines), body


def run_fleet_changes():
    """Once a day: record fleet changes, then send each user's digest when it is due."""
    now = datetime.datetime.now(datetime.timezone.utc)
    st = db.settings()
    if (st.get("fleet_detect_last") or "")[:10] < now.date().isoformat():
        n = intel.detect_changes()
        db.set_setting("fleet_detect_last", now.isoformat())
        log.info("fleet change scan: %s events", n)
    site = st.get("site_name", "Consist")
    sent = 0
    for r in db.q("SELECT id, email FROM user WHERE status = 'active'"):
        u = auth.load_user(r["id"])
        if not u or not u.can("fleet_alerts"):
            continue
        freq = intel.pref(u, "fleet_email", "weekly")
        last = intel.pref(u, "fleet_email_last")
        if last is None:  # start from now so the first digest is not every change on record
            intel.set_pref(u, "fleet_email_last", now.isoformat())
            continue
        if not fleet_due(freq, last, now, u):
            continue
        if fleet_send_mode(u) == "all":  # 1.8.8: every change in the last 30 days, each time
            since = (now - datetime.timedelta(days=30)).isoformat()
            events = intel.events_for_user(u, since=since, limit=60)
        else:
            events = unsent(f"f:{r['id']}", intel.events_for_user(u, since=last, limit=60), event_keys)  # 1.8.8: each change once
        if events:
            text, body = render_fleet(site, events)
            try:
                ok = mailer.send(r["email"], f"{site}: {len(events)} fleet update{'s' if len(events) != 1 else ''}", text, body, optional=True)
                if ok:
                    mark_sent(f"f:{r['id']}", events, event_keys)
                sent += 1
            except Exception as e:
                log.error("fleet digest to %s failed: %s", r["email"], e)
                continue
        intel.set_pref(u, "fleet_email_last", now.isoformat())
    return sent


# ---------- 1.7.79: Send test (Justin 11-19) ----------
TEST_NOTE_BID = ("This is a test of your alert \"{name}\". It shows the {n} newest bids that match it today, including ones you "
                 "may have seen. Real alerts follow the alert's setting: only bids not emailed before, or all current matches.")
TEST_NOTE_FLEET = ("This is a test of your fleet updates. It shows the {n} most recent changes (last 30 days) that fit your settings. "
                   "Real emails follow your setting: only changes not emailed before, or every change in the last 30 days.")
_last_test = {}


def _test_banner(note):
    return (f"<p style='background:#fff6dd;border:1px solid #e8d48a;padding:8px 10px;font-size:13px;color:#5c4a00'>"
            f"{html.escape(note)}</p>")


def test_wait(key):
    """Seconds before this member may send another test of this alert (one a minute, so the button can't flood an inbox)."""
    return max(0, int(60 - (time.time() - _last_test.get(key, 0))))


def _test_mark(key):
    _last_test[key] = time.time()


def send_test_bid(u, sid):
    """Emails the member what this saved search would send, right now. Returns (ok, message for the page)."""
    s = db.q("SELECT * FROM saved_search WHERE id = ? AND user_id = ?", (sid, u["id"]), one=True)
    if not s:
        return False, "That saved search wasn't found."
    if not mailer.configured():
        return False, "Email sending isn't configured on this server yet, so the test couldn't be sent."
    key = (u["id"], "bid", sid)
    if test_wait(key):
        return False, f"Please wait {test_wait(key)} seconds before sending another test of this alert."
    from . import unsub
    if unsub.is_out(u["email"]):
        return False, f"{u['email']} has unsubscribed from alert emails, so nothing can be sent. Use the unsubscribe link in any earlier alert email and press Resubscribe."
    site = db.settings().get("site_name", "Consist")
    rows = matches(s, test=True)
    _test_mark(key)
    if rows:
        text, body = render(site, s, rows, test=True)
        subj = f"[Test] {site}: {len(rows)} rail bid{'s' if len(rows) != 1 else ''} for \"{s['name']}\""
    else:
        text = (f"This is a test of your alert \"{s['name']}\". No bids on record match it right now, so a real alert would not "
                f"send anything yet. Widen the search if you expected matches.\n\nManage alerts: {config.SITE_URL}/app/alerts")
        body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} bid alert: "
                f"{html.escape(s['name'])}</h2>{_test_banner(text.split(chr(10))[0])}<p style='font-size:12px'>"
                f"<a href='{config.SITE_URL}/app/alerts'>Manage alerts</a></p></div>")
        subj = f"[Test] {site}: no current matches for \"{s['name']}\""
    try:
        ok = mailer.send(u["email"], subj, text, body, alerts=True, optional=True, headers=tag_headers(rows))
    except Exception as e:
        log.error("test alert to %s failed: %s", u["email"], e)
        return False, "The test email couldn't be sent. The mail server refused it; please try again later."
    if ok is False:
        return False, "The test email couldn't be sent."
    return True, (f"Test sent to {u['email']} with the {len(rows)} newest matching bid{'s' if len(rows) != 1 else ''}." if rows
                  else f"Test sent to {u['email']}. No bids match this search right now, so the email says so.")


def send_test_fleet(u):
    """Emails the member a fleet update digest built from their current settings, using the last 30 days of changes."""
    if not mailer.configured():
        return False, "Email sending isn't configured on this server yet, so the test couldn't be sent."
    key = (u["id"], "fleet")
    if test_wait(key):
        return False, f"Please wait {test_wait(key)} seconds before sending another test."
    from . import unsub
    if unsub.is_out(u["email"]):
        return False, f"{u['email']} has unsubscribed from alert emails, so nothing can be sent. Use the unsubscribe link in any earlier alert email and press Resubscribe."
    site = db.settings().get("site_name", "Consist")
    since = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=30)).isoformat()
    events = intel.events_for_user(u, since=since, limit=25)
    _test_mark(key)
    if events:
        text, body = render_fleet(site, events, test=True)
        subj = f"[Test] {site}: {len(events)} fleet update{'s' if len(events) != 1 else ''}"
    else:
        text = ("This is a test of your fleet updates. No fleet changes in the last 30 days fit your settings, so a real email "
                f"would not send anything yet. Follow more fleets or widen your settings.\n\nFleet update settings: {config.SITE_URL}/app/updates")
        body = (f"<div style='font-family:Arial,sans-serif;max-width:620px'><h2 style='font-size:18px'>{html.escape(site)} fleet updates</h2>"
                f"{_test_banner(text.split(chr(10))[0])}<p style='font-size:12px'><a href='{config.SITE_URL}/app/updates'>Fleet update settings</a></p></div>")
        subj = f"[Test] {site}: no recent fleet updates"
    try:
        ok = mailer.send(u["email"], subj, text, body, optional=True)
    except Exception as e:
        log.error("test fleet digest to %s failed: %s", u["email"], e)
        return False, "The test email couldn't be sent. The mail server refused it; please try again later."
    if ok is False:
        return False, "The test email couldn't be sent."
    return True, (f"Test sent to {u['email']} with {len(events)} recent fleet change{'s' if len(events) != 1 else ''}." if events
                  else f"Test sent to {u['email']}. No fleet changes in the last 30 days fit your settings, so the email says so.")


def start():
    if not config.ALERTS_ENABLED:
        return

    def loop():
        time.sleep(30)
        while True:
            try:
                run_once()
            except Exception as e:
                log.error("alert run failed: %s", e)
            try:
                run_fleet_changes()
            except Exception as e:
                log.error("fleet change run failed: %s", e)
            try:
                from . import bd18
                bd18.run_digests()  # 1.8.1 weekly territory digest
            except Exception as e:
                log.error("territory digest run failed: %s", e)
            try:
                from . import dataqa
                dataqa.daily()  # 1.8.14: safe data QA repairs, once a day
            except Exception as e:
                log.error("data QA repairs failed: %s", e)
            try:
                from . import ep724
                ep724.refresh()  # 1.7.63: STB EP 724 weekly freight service data, checked once a day
            except Exception as e:
                log.error("EP 724 refresh failed: %s", e)
            try:
                from . import supplierdir
                if supplierdir.monthly_due():
                    supplierdir.reconcile_rssi()  # monthly RSSI member-list reconciliation (Admin > Supplier directory)
            except Exception as e:
                log.error("supplier directory RSSI check failed: %s", e)
            time.sleep(600)
    threading.Thread(target=loop, daemon=True).start()


def baseline(search_id):
    """New searches start from the newest notice so the first email is not a flood of old bids."""
    r = db.bq("SELECT max(notice_id) m FROM notice", one=True)
    db.x("UPDATE saved_search SET last_notice_id = ? WHERE id = ?", ((r["m"] if r else 0) or 0, search_id))


# ---------- 1.8.12 (Justin 11-20): Send update now ----------
_last_now = {}


def send_now(u, sid):
    """Run this alert now with its current terms and email only the open matching bids it hasn't emailed before (alert_sent),
    then record them as sent: a real send, unlike Send test. After an edit this picks up older open bids that only match the
    new terms. One run per alert every 2 minutes. Returns (ok, message for the page)."""
    s = db.q("SELECT * FROM saved_search WHERE id = ? AND user_id = ?", (sid, u["id"]), one=True)
    if not s:
        return False, "That alert wasn't found."
    if not mailer.configured():
        return False, "Email sending isn't configured on this server yet, so nothing could be sent."
    key = (u["id"], sid)
    wait = max(0, int(120 - (time.time() - _last_now.get(key, 0))))
    if wait:
        return False, f"Please wait {wait} seconds before running this alert again."
    from . import unsub
    if unsub.is_out(u["email"]):
        return False, f"{u['email']} has unsubscribed from alert emails, so nothing can be sent. Use the unsubscribe link in any earlier alert email and press Resubscribe."
    _last_now[key] = time.time()
    s = dict(s)
    qd = json.loads(s["query"] or "{}")
    every = dict(s, query=json.dumps(dict(qd, send="all")))  # every open bid that fits the current terms
    cur = matches(every)
    rows = unsent(f"s:{sid}", cur, notice_keys)
    now = datetime.datetime.now(datetime.timezone.utc)
    top = max([n["notice_id"] for n in cur] + [s["last_notice_id"] or 0])
    if not rows:
        return True, (f"Nothing new to send: all {len(cur)} open bid{'s' if len(cur) != 1 else ''} matching \"{s['name']}\" were already emailed."
                      if cur else f"No open bids match \"{s['name']}\" right now, so nothing was sent.")
    site = db.settings().get("site_name", "Consist")
    s_new = dict(s, query=json.dumps({k: v for k, v in qd.items() if k != "send"}))  # wording: "new rail bids"
    text, body = render(site, s_new, rows)
    try:
        ok = mailer.send(u["email"], f"{site}: {len(rows)} new rail bid{'s' if len(rows) != 1 else ''} for \"{s['name']}\"", text, body,
                         alerts=True, optional=True, headers=tag_headers(rows))
    except Exception as e:
        log.error("update now to %s failed: %s", u["email"], e)
        return False, "The email couldn't be sent. The mail server refused it; please try again later."
    if not ok:
        return False, "The email couldn't be sent."
    mark_sent(f"s:{sid}", rows, notice_keys)
    db.x("UPDATE saved_search SET last_sent = ?, last_notice_id = ? WHERE id = ?", (now.isoformat(), top, sid))
    return True, f"Sent {len(rows)} bid{'s' if len(rows) != 1 else ''} to {u['email']} that \"{s['name']}\" hadn't emailed before. They won't be sent again."
