"""Plain English (ASD-STE100 style) for text the site generates (1.8.36, Justin 11-28).

clean() is a safety net applied to generated text before members see it (AI analyst answers and briefs, digests): it writes
short forms in full and swaps not-approved words for approved ones where the swap is always safe. The main control is in the
generators themselves (analyst.SYSTEM writing standard, report and email templates); tests/test_plain_english.py checks those."""
import re

SAFE = [  # (pattern, replacement); only swaps that keep the meaning in every context
    (r"\be\.g\.,?\s", "for example "), (r"\bi\.e\.,?\s", "that is, "), (r",?\s+etc\.(?=\))", " and more"), (r",?\s+etc\.", " and more."),
    (r"\butiliz(e|es|ed|ing)\b", lambda m: {"e": "use", "es": "uses", "ed": "used", "ing": "using"}[m.group(1)]),
    (r"\bprior to\b", "before"), (r"\bin order to\b", "to"), (r"\bcommenc(e|es|ed)\b", lambda m: {"e": "start", "es": "starts", "ed": "started"}[m.group(1)]),
    (r"\bsubsequently\b", "then"), (r"\bnumerous\b", "many"), (r"\bfacilitat(e|es)\b", lambda m: "help" + ("s" if m.group(1) == "es" else "")),
]


def _keep_case(rep):
    def f(m):
        r = rep(m) if callable(rep) else m.expand(rep)
        return r[:1].upper() + r[1:] if m.group(0)[:1].isupper() and r else r
    return f


def clean(text):
    if not isinstance(text, str) or not text:
        return text
    for pat, rep in SAFE:
        text = re.sub(pat, _keep_case(rep), text, flags=re.I)
    return text


def clean_obj(o):
    """clean() on every string inside a JSON-like answer (dicts, lists)."""
    if isinstance(o, str):
        return clean(o)
    if isinstance(o, list):
        return [clean_obj(x) for x in o]
    if isinstance(o, dict):
        return {k: clean_obj(v) for k, v in o.items()}
    return o
