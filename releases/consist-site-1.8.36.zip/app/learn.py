"""Training portal at /app/learn (Justin, 2026-11-11): a 'Start here' module for new members, then one module per feature.

Each module has a short 'why', 3 to 5 steps, and each step an animation of the screen: a small scripted SVG mock of the app
(sidebar, header search, page body) with a cursor that moves, clicks and types. The SVGs are drawn here from a tiny spec so they
stay in step with the UI and weigh a few KB; they loop and hold still for visitors who ask for reduced motion. A step may also
name a short recorded clip (static/learn/<file>.mp4); when the file exists it plays instead of the SVG (recorded later on staging).
Progress (which modules a member has finished) is kept per user in user_pref 'learn_done'."""
import html
import os

from . import db

STATIC = os.path.join(os.path.dirname(__file__), "static", "learn")

SIDE = ["My dashboard", "Bids and RFPs", "Past RFPs", "Operators", "Fleets", "Subsystems", "Market share", "AI analyst",
        "Alerts", "Account"]

# Each step: (title, text, scene, try-it link). A scene: side = highlighted sidebar item; body = page mock kind;
# act = list of actions: ("move", x, y), ("click",), ("type", where, text), ("show", what); cap = caption under the mock.
MODULES = [
    {"slug": "start", "title": "Start here", "icon": "target", "min": 5,
     "why": "What the site covers, how the menu is organized, and the first ten minutes that pay off most.",
     "steps": [
         ("Set your market and region", "The bar at the top of every page picks All rail, Transit or Passenger rail and the "
          "regions you cover. Every list, chart and count follows it.",
          {"side": 0, "body": "dash", "act": [("move", 470, 52), ("click",), ("show", "lens")]}, "/app"),
         ("Read the menu by job", "The menu at the left has groups for each job: Opportunities (bids and work to come), "
          "Accounts (operators and fleets), Market, Competitors and suppliers, and My workspace. In your first 14 days, "
          "the menu shows only the main pages. Click Show all pages at the bottom of the menu to see all of them.",
          {"side": 1, "body": "dash", "act": [("move", 70, 120), ("move", 70, 200), ("move", 70, 290)]}, "/app"),
         ("Tune your dashboard", "Choose what you sell under Account. Your dashboard then shows the bids, fleets and signals for that trade. "
          "Click a number to open the list behind it. To choose the summaries on the dashboard, click Customize dashboard"
          " at the top of the page. You can set the summaries for each role. One Save keeps all roles.",
          {"side": 9, "body": "dash", "act": [("move", 70, 334), ("click",), ("move", 330, 150), ("click",)]}, "/app/account#market"),
         ("Save a search, get alerts", "On a paid plan, you can save a filtered list of bids as an alert. We email it to you daily or at once. In New "
          "saved search, each box (categories, subsystems, agencies, countries) takes many picks. A bid matches when it "
          "fits one pick in each box that you set. Minimum relevance sets how strong a rail match must be. Set it to 75 "
          "or 90 to get fewer and better emails. Click Send test to get the email now and check it. Under When daily and "
          "weekly emails arrive, choose the hour and the weekday. This applies to bid alerts, fleet updates and the "
          "territory digest. Each email includes has two options. Only new bids sends each bid one time per alert. This "
          "is the default. All open matches sends all open bids that match, each time. To change an alert, click Edit. "
          "Change the form at the right, then click Save changes. The alert keeps its history, so it does not send a bid "
          "again. Send update now runs the alert at once and sends only the bids that it did not send before. Use it "
          "after an edit. You can use it one time in 2 minutes for each alert. You can also type what you want in "
          "Describe an alert, for example: SEPTA and NJ Transit brake parts over 50 relevance, daily at 7am. Click Fill "
          "in the form. The site fills in New saved search and tells you what it understood and what it did not use. "
          "Check the form, then save it. Open Email contents on an alert to choose what each bid shows: pills, agency, "
          "closing date, relevance, summary, link and a tag line. The tag line (CONSIST-TAGS v1) is for mail rules and "
          "other software. Each email also has an X-Consist-Categories header. Each bid in the email links to the posting"
          " on the agency's site, or to the agency's bid portal.",
          {"side": 8, "body": "table", "act": [("move", 560, 110), ("click",), ("show", "toast")]}, "/app/alerts"),
         ("Set up fleet updates", "Alerts > Fleet updates emails changes to fleets: new fleets, unit counts, overhaul and end-of-life years, cost"
          " jumps and announced programs. Open Fleet update settings. Choose the fleets you follow or all fleets. Then "
          "narrow by kind of change, mode, vehicle type, operator, country or territory. Choose daily, weekly or no "
          "email. Each email includes has two options: only changes not sent before (the default), or all changes from "
          "the last 30 days. Click Save, then Send test to get a sample email.",
          {"side": 8, "body": "table", "act": [("move", 300, 120), ("click",), ("show", "toast")]}, "/app/alerts?tab=fleet"),
         ("Your first-day list", "The dashboard shows five tasks for your first day: choose your market, follow 3 operators, "
          "save one bid alert, set your territory and do this lesson. Each task gets a check mark when you do it. "
          "When all five are done, the list goes away. You can hide it and show it again from Training.",
          {"side": 0, "body": "dash", "act": [("move", 300, 140), ("show", "hl")]}, "/app"),
     ]},
    {"slug": "how", "title": "How every page works", "icon": "target", "min": 3,
     "why": "Every list, table and chart on the site behaves the same way. Learn these moves once and use them everywhere.",
     "steps": [
         ("Click a row to open it", "Click anywhere on a table row to open the fleet, operator, bid, award, order, builder or "
          "supplier it lists. A row that names a company opens that company (its profile, or its awards). A row that sums up a "
          "group (a year, a mode, a lessor) opens the list behind it. A record kept on another site, such as a federal grant, "
          "opens there in a new tab. Ctrl-click (Cmd-click on a Mac) opens any row in a new tab. Tables of yearly figures "
          "or calculations have nothing further to open.",
          {"side": 4, "body": "table", "act": [("move", 420, 190), ("click",), ("show", "page")]}, "/app/fleets"),
         ("Click a number tile", "The number tiles at the top of a page count fleets, units, bids, orders, awards and more. Click a tile to open"
          " the list that it counts. A tile with › after its number is a link.",
          {"side": 4, "body": "dash", "act": [("move", 200, 120), ("click",), ("show", "page")]}, "/app/supplier-intel"),
         ("Click a pill to filter", "A pill that names a value (a builder, a status, a kind of work) filters the list to that value. The filter "
          "shows as a chip under Filtered by. Click the pill again, or the ✕ on the chip, to remove the filter. Three "
          "signal pills are different: Announced program, Recent bid and Recent funding. They open the source document in"
          " a new tab. This can be the agency posting, a board or budget document, or a grant notice. When there is no "
          "source, the pill is not a link. Point to it to see why.",
          {"side": 4, "body": "table", "act": [("move", 400, 160), ("click",), ("show", "chip")]}, "/app/fleets"),
         ("Click a chart bar to drill in", "Bars in charts open the records behind them: a year, a builder, a subsystem or an owner. "
          "On Orders and backlog a builder's bar opens its orders that year; on the capital planner a bar narrows the table "
          "to that year. Click the same bar again, or Show all, to see everything. Trend lines are for reading, not clicking.",
          {"side": 6, "body": "bars", "act": [("move", 330, 180), ("click",), ("show", "filter")]}, "/app/market"),
         ("Hover for what it means", "A dotted line under a word, a column name or a label means it has a definition. "
          "Point to it to see the definition. Point to a pill or a badge to see what it means or what a click does. "
          "All terms are on Terms A to Z.",
          {"side": 4, "body": "table", "act": [("move", 300, 112), ("show", "hl")]}, "/app/learn/terms"),
         ("Help with this page", "Each page has a Help button at the top. Click it to see what the page is for, the terms "
          "on the page, and a link to the lesson for that page.",
          {"side": 4, "body": "table", "act": [("move", 590, 52), ("click",), ("show", "hl")]}, "/app/fleets"),
         ("Sort, search and export", "Click a column heading to sort. Type in the header search to narrow the page you're "
          "on, or press Enter to search the whole site. Export CSV and Export Excel sit at the top right of a list on "
          "plans with export.",
          {"side": 4, "body": "table", "act": [("move", 300, 52), ("click",), ("type", "search", "Siemens"), ("show", "filter")]}, "/app/fleets"),
         ("How fleets are counted", "Each fleet is counted in its own vehicle type: locomotives, coaches, cab cars, EMU or DMU "
          "cars, metro cars, light rail vehicles or streetcars. A locomotive is never called a car. An operator with several "
          "types reads as, for example, 57 locomotives and 900 coaches. Where one total covers several types (a table column, "
          "a map dot, a market share), it says units: one unit is one locomotive, coach or car.",
          {"side": 4, "body": "table", "act": [("move", 420, 112), ("show", "hl")]}, "/app/fleets"),
     ]},
    {"slug": "search", "title": "Finding anything", "icon": "search", "min": 3,
     "why": "One search box covers the whole site, and every pill you see is a filter.",
     "steps": [
         ("Filter the page you're on", "Start typing in the header search and the lists on the current page narrow as you type.",
          {"side": 4, "body": "table", "act": [("move", 300, 52), ("click",), ("type", "search", "Siemens"), ("show", "filter")]}, "/app/fleets"),
         ("Search the whole site", "Press Enter to search everything: pages, operators, fleets, builders and models, "
          "subsystem suppliers, bids, vehicle orders, awards and the supplier directory, grouped by type. Hyphens, "
          "spaces and dots don't matter: M9A finds M-9A, and SC44 finds SC-44.",
          {"side": -1, "body": "results", "act": [("move", 300, 52), ("click",), ("type", "search", "Charger"), ("show", "results")]}, "/app/search"),
         ("Click a pill to filter", "Any pill that names a value (a builder, a status, a trade) filters its list. Click it "
          "again, or the ✕ on the 'Filtered by' chip, to clear it.",
          {"side": 4, "body": "table", "act": [("move", 400, 160), ("click",), ("show", "chip")]}, "/app/fleets"),
     ]},
    {"slug": "fleets", "title": "Fleet Explorer", "icon": "fleet", "min": 4,
     "why": "Every passenger and transit fleet in the US and Canada: who built it, when, how many cars, and when it is due "
            "for overhaul or replacement.",
     "steps": [
         ("Market map on Fleet explorer", "Fleet explorer starts with the same Market map as Market share: columns for each "
          "subsystem, car builders by vehicle type, service contracts and rail awards, each as wide as its total with supplier "
          "shares stacked inside. It follows the vehicle type and mode filters. Click a column name to zoom in, a block for details.",
          {"side": 5, "body": "bars", "act": [("move", 300, 140), ("click",), ("show", "chip")]}, "/app/fleets"),
         ("Filter the fleet list", "Use the filters and pills to narrow by operator, builder, mode or age. Sort any column.",
          {"side": 4, "body": "table", "act": [("move", 260, 110), ("click",), ("move", 420, 160), ("click",), ("show", "chip")]}, "/app/fleets"),
         ("Open an operator from a fleet", "Click an operator's name to open their page at the Fleets card. Use the small "
          "'only these' link to keep the list filtered to that operator instead.",
          {"side": 4, "body": "table", "act": [("move", 240, 190), ("click",), ("show", "page")]}, "/app/fleets"),
         ("Open a fleet record", "A fleet page shows the build, rebuilds, subsystems and suppliers, and the replacement window.",
          {"side": 4, "body": "detail", "act": [("move", 450, 150), ("show", "hl")]}, "/app/fleets"),
         ("Reported or estimated cost", "Most US transit costs come from NTD. Where a fleet reports nothing (Canada, Mexico, "
          "Amtrak, airports, freight), we estimate from the closest comparable fleets, or from STB R-1 for freight locomotives. "
          "Estimates carry a badge, a range and the fleets they came from.",
          {"side": 4, "body": "detail", "act": [("move", 450, 230), ("show", "hl2")]}, "/app/fleets"),
         ("Export (Investor plan and up)", "Plans with export can download the filtered list as CSV or Excel.",
          {"side": 4, "body": "table", "act": [("move", 590, 110), ("click",), ("show", "toast")]}, "/app/fleets"),
         ("Checked and corrected data", "Consist checks the data every day. It corrects values that cannot be correct, for example a useful life that "
          "ends before the build year, or bad characters in a bid title. Sometimes the operator reports one maintenance "
          "cost for all fleets of a mode. Then the fleet page shows operator average next to the cost.",
          {"side": 4, "body": "detail", "act": [("move", 450, 230), ("show", "hl2")]}, "/app/fleets"),
     ]},
    {"slug": "operators", "title": "Operator pages", "icon": "ops", "min": 4,
     "why": "Everything about one agency on one page: its fleets, subsystems, bids, awards, board meetings and news.",
     "steps": [
         ("Operators map", "Operators opens on a map of every operator in your lens, territory and filters, with a list on the "
          "left. The list shows only the operators on the map, so pan or zoom to a region, or type in the search box, to narrow "
          "it. Hover a name to find its dot (or a dot to find its name), and click either to open the agency page. The full "
          "table with fleets, cars and costs is under the map.",
          {"side": 5, "body": "dash", "act": [("move", 330, 180), ("click",), ("show", "page")]}, "/app/operators"),
         ("Find an operator", "Use the Operators list (with category chips) or just type the name in the header search.",
          {"side": 3, "body": "table", "act": [("move", 300, 52), ("click",), ("type", "search", "SEPTA"), ("move", 260, 130), ("click",)]}, "/app/operators"),
         ("Follow operators and filter to them", "Click the ★ next to any operator (or Follow on its page) to follow it. The "
          "★ Following pill at the top of the Operators list then shows only the operators you follow, with the count; click it "
          "again to see everyone. Followed operators also feed your dashboard and alerts.",
          {"side": 3, "body": "table", "act": [("move", 60, 130), ("click",), ("move", 120, 52), ("click",), ("show", "hl")]}, "/app/operators?following=1"),
         ("Find an agency's bid and award pages", "The Procurement and award portals card on an operator page links to each of its "
          "buying agencies' own pages: the bidding portal, plus where the agency posts awards, closed solicitations and bid tabulations "
          "(a PDF tag marks a document). Bid Catcher reads these pages, so the bids and awards on them reach the bid feed and Recent awards. "
          "The same links show under each agency on Agency coverage.",
          {"side": 1, "body": "detail", "act": [("move", 300, 220), ("show", "hl")]}, "/app/operators"),
         ("Read the fleet and subsystem cards", "See every fleet, its age and status, and who supplies brakes, HVAC, doors, "
          "propulsion and train control.",
          {"side": 3, "body": "detail", "act": [("move", 330, 160), ("show", "hl")]}, "/app/operators"),
         ("Board meetings and documents", "Upcoming board meetings, the rail items on their agendas, and recent documents: "
          "often the first sign of a procurement.",
          {"side": 3, "body": "detail", "act": [("move", 330, 270), ("show", "hl2")]}, "/app/operators"),
         ("Build an account brief", "Click Account brief at the top of an operator page. Tick the parts to include. You can include each card on "
          "the page, and also the agency's federal grants, budget items, capital projects and on-call contracts. Click "
          "Generate brief, then Print or save as PDF. The brief ends with a Key to terms that explains its pills, mode "
          "codes and short forms. The site keeps your choices. To change them, click Change what is included.",
          {"side": 3, "body": "detail", "act": [("move", 520, 60), ("click",), ("move", 520, 140), ("show", "hl")]}, "/app/operators"),
     ]},
    {"slug": "bids", "title": "Bid Catcher: bids and RFPs", "icon": "bids", "min": 5,
     "why": "Every public rail and transit procurement in the US and Canada, checked daily and scored for relevance.",
     "steps": [
         ("Filter by relevance", "Each bid is scored 0 to 100 for rail vehicle relevance. The Relevance filter defaults to "
          "50+; pick 75+ for only the closest matches or All to see everything.",
          {"side": 1, "body": "table", "act": [("move", 520, 110), ("click",), ("show", "chip")]}, "/app/bids"),
         ("Open a bid", "A bid page has the summary, dates, documents, the fleet it relates to, and an AI fit brief. "
          "A bid we found in an agency document rather than on a bid portal shows How to get the documents instead: the contact the solicitation names and the agency website.",
          {"side": 1, "body": "detail", "act": [("move", 300, 150), ("show", "hl")]}, "/app/bids"),
         ("French and Spanish notices", "French and Spanish notices (Québec's SEAO, federal Canada, Spanish-language agencies) "
          "show an English machine translation with the original, on the site and in alert emails. The original is the official text; check it before bidding.",
          {"side": 1, "body": "detail", "act": [("move", 300, 170), ("show", "hl2")]}, "/app/bids"),
         ("Save it as an alert", "Save your filtered search and choose daily or instant email.",
          {"side": 1, "body": "table", "act": [("move", 560, 110), ("click",), ("show", "toast")]}, "/app/bids"),
         ("Learn from past RFPs", "Past RFPs show who bid, at what price, and who won. Click the bidders count to see them all.",
          {"side": 2, "body": "table", "act": [("move", 470, 190), ("click",), ("show", "page")]}, "/app/past-rfps"),
         ("On-call expiry", "On-call contracts shows every on-call, IDIQ and standing-offer bench we know of, one row per bench "
          "with all the firms on it. Ends is the base term. With options is the latest the agency can extend it. Rebid due is a "
          "year before that. A green Next round posted pill means the agency has already put out the next solicitation, so click "
          "it to see the RFQ. Values are the bench's shared ceiling, not money spent, unless a Spent figure is shown.",
          {"side": 2, "body": "table", "act": [("move", 300, 200), ("show", "hl2"), ("move", 330, 230), ("click",), ("show", "page")]}, "/app/capital-pipeline#oncall"),
         ("Early signals", "Early signals shows the steps that come before an RFP. These include RFIs, sources-sought notices and industry"
          " days. We show all of these because their relevance scores are low. It also shows agency procurement "
          "forecasts, board votes for a purchase, on-call contracts that end within a year, and vehicle orders in "
          "planning. Reply to RFIs and go to industry days to get on the shortlist.",
          {"side": 3, "body": "table", "act": [("move", 330, 180), ("show", "hl")]}, "/app/early-signals"),
         ("Agency coverage", "The Coverage page shows each agency that Bid Catcher follows, and how. We read its procurement page, board "
          "meetings and documents, alert emails from its bid portal, or open-data feeds. Live means we read it "
          "automatically and found postings or awards in the last 180 days. Read, nothing found means we read its pages "
          "but found nothing in 180 days. Usually the page is a landing or login page, and we are looking for the correct"
          " page. Email alerts means that notices come from the agency's portal by email. Limited means the agency's site"
          " blocks automatic readers. We are asking for alerts or permission. A quiet note means that an agency that "
          "usually posts often has not posted recently. Usually this is a pause. We check the feed. Your territory "
          "applies here too.",
          {"side": 3, "body": "table", "act": [("move", 330, 180), ("show", "hl")]}, "/app/coverage"),
         ("Coverage map", "Click the Coverage map pill at the top of Agency coverage to see each agency on a map. The dot color shows how"
          " we follow its bids: green is Live, blue is Email alerts, orange is Limited, purple is Pending, sand is Read, "
          "nothing found, and gray is Not yet covered. A dashed red ring shows a quiet agency. Click a dot to see its bid"
          " portal, how we follow it, its last posting and open bids. The map follows your territory and the status "
          "pills. Click the same pill to hide the map.",
          {"side": 3, "body": "dash", "act": [("move", 470, 52), ("click",), ("show", "page")]}, "/app/coverage?map=1"),
         ("Federal grants an agency has won", "Open Funding and rule drivers > Federal grants an agency has won. Choose an agency. You see each federal grant"
          " that it got since 2015 (from USAspending.gov), and the total. Each grant has a kind of work, for example "
          "rolling stock, locomotives, signals, track, bridges, crossings or planning. The site finds the kind of work "
          "from the words in the grant description. Click a kind of work to see only those grants. Open a description to "
          "see the full text and award number. Then use Next step to see the agency's open bids. A grant for cars or "
          "signals usually means that a bid for that work will come.",
          {"side": 1, "body": "table", "act": [("move", 300, 120), ("click",), ("show", "hl")]}, "/app/drivers#grants"),
     ]},
    {"slug": "analyst", "title": "AI analyst and briefs", "icon": "ai", "min": 5,
     "why": "Ask questions in plain English and get answers grounded in the site's data, with sources. Turn any bid into a "
            "fit brief you can share.",
     "steps": [
         ("Ask a question", "Type a question about fleets, bids, suppliers or markets. Answers cite the records they use.",
          {"side": 7, "body": "chat", "act": [("move", 330, 330), ("click",), ("type", "chat", "Which fleets need HVAC overhaul by 2028?"), ("show", "answer")]}, "/app/analyst"),
         ("Ask about one fleet", "On a fleet page, 'Ask about this fleet' sends that fleet's record along with your question.",
          {"side": 4, "body": "detail", "act": [("move", 560, 90), ("click",), ("show", "page")]}, "/app/fleets"),
         ("Brief a bid, then update it", "On a bid page, the AI brief gives a fit verdict and key figures. 'Update the brief' "
          "re-runs it with the latest information (one question).",
          {"side": 1, "body": "detail", "act": [("move", 450, 240), ("click",), ("show", "hl2")]}, "/app/bids"),
         ("Download PDF, RTF or TXT", "You can download each brief and answer as a PDF, an RTF file for Word, or plain text. Each one ends with a Key"
          " to terms. It explains the verdict and confidence pills and the short forms (NTD, IDIQ, CBTC and more). A "
          "colleague who does not use the site can read it.",
          {"side": 7, "body": "chat", "act": [("move", 540, 200), ("click",), ("show", "toast")]}, "/app/analyst"),
         ("Answers in plain English", "The analyst writes in Simplified Technical English (ASD-STE100). Sentences are short, "
          "and the words are simple. The same word always means the same thing. Reports, briefs and emails from the site use the "
          "same standard.",
          {"side": 7, "body": "chat", "act": [("move", 400, 160), ("show", "answer")]}, "/app/analyst"),
     ]},
    {"slug": "uploads", "title": "Uploading your documents", "icon": "doc", "min": 3,
     "why": "Give the analyst a document (an RFP, a spec, a report) and ask about it alongside the site's data.",
     "steps": [
         ("Attach a file", "PDF, Word, text or CSV up to 10 MB. Tick the consent box, then ask your question.",
          {"side": 7, "body": "chat", "act": [("move", 120, 330), ("click",), ("show", "file"), ("type", "chat", "Summarize the car spec")]}, "/app/analyst"),
         ("Reuse or delete it", "Your uploads stay private to you. Reuse one with a new question or delete it any time.",
          {"side": 7, "body": "chat", "act": [("move", 540, 120), ("show", "hl")]}, "/app/analyst"),
         ("What we keep", "Uploads are never shared. If one is a public agency solicitation, the bid itself may be added to "
          "Bid Catcher, with nothing about you. See the Privacy page for details.",
          {"side": 7, "body": "chat", "act": [("show", "lock")]}, "/privacy"),
     ]},
    {"slug": "bd-toolkit", "title": "BD toolkit: projects, sizing and competitors", "icon": "target", "min": 4,
     "why": "The pages a BD leader uses to plan the year: where the big money is, how big the market is, who you are up against.",
     "steps": [
         ("Megaprojects", "Megaprojects shows the largest rail and transit capital programs in the US and Canada. For each program, it "
          "shows the owner, cost, funding, delivery model, and the status and winner of each package. Open a program to "
          "see its bids, early signals and awards. You can track it as a pursuit.", {"side": 6, "body": "table", "act": [("move", 300, 160), ("click",)]}, "/app/projects"),
         ("Project timelines", "The Gantt chart at the top of Megaprojects shows all programs. Gold is planning, blue is construction, red "
          "diamonds are milestones and the purple line is today. Sort and filter the chart. Click a row to see the "
          "timeline for that project, with its milestones and the bids and awards that Consist found for it.", {"side": 6, "body": "bars", "act": [("move", 300, 140), ("click",)]}, "/app/projects"),
         ("Market sizing", "Market sizing gives TAM, SAM and SOM a year by segment for your market view. Tick the segments you sell "
          "into for SAM, then pick your company (its award share fills in) or type a target share for SOM. Each segment says how "
          "it is measured and how good the number is. Signaling is modeled from route miles, and award categories a modeled segment covers are left out so nothing counts twice.", {"side": 6, "body": "bars", "act": [("move", 320, 200), ("show", "hl")]}, "/app/market-sizing"),
         ("Competitor profiles", "A competitor profile shows a company together with its parent company. It shows the installed base, wins and "
          "share by category, where the company wins, and its equipment that can change supplier soon. Bid pages also "
          "show likely competitors for the same kind of work.", {"side": 6, "body": "table", "act": [("move", 280, 180), ("click",)]}, "/app/competitors"),
         ("Drill into any share", "Every share figure is a link. On Supplier intelligence, click an award share or award count for "
          "that supplier's awards over five years, or an installed-base share for its fleets. On a competitor profile, click a category "
          "for every award in it, or the amount or share for just that company's wins.", {"side": 6, "body": "table", "act": [("move", 300, 180), ("click",)]}, "/app/supplier-intel"),
         ("Pipeline and digest", "Pursuits have a win probability. The page shows open pipeline value by quarter, multiplied by the win "
          "probability. To get one email each week with new bids, awards and change windows in your territory, turn on "
          "the territory digest under Alerts. It comes on Monday morning unless you choose a different day.",
          {"side": 6, "body": "table", "act": [("move", 260, 150), ("show", "chip")]}, "/app/pursuits"),
     ]},
    {"slug": "market", "title": "Market intelligence", "icon": "pie", "min": 4,
     "why": "Who supplies what across the installed base, and where share is changing.",
     "steps": [
         ("Market share", "See builder and supplier share by cars and fleets for your market and region. Builders are the companies "
          "that built the cars; switch to Supported today to count them under today's owner of the design (Bombardier cars under Alstom). "
          "Suppliers roll up to their parent company, so Thales and Ansaldo STS count as Hitachi Rail.",
          {"side": 6, "body": "bars", "act": [("move", 330, 180), ("show", "hl")]}, "/app/market"),
         ("Market map", "The Market map at the top of Market share shows a whole market at a glance. Each column is a segment "
          "(a subsystem such as brakes or doors) and is as wide as the cars we have supplier records for; the "
          "colored blocks stacked in it are each supplier's share, the same company keeping one color across columns. Car builders by "
          "vehicle type shows one column per vehicle type with each builder's share. Switch to "
          "Rail awards, 5 years to see award categories sized by dollars and who won them. The six largest columns show by default "
          "(change it with Columns); the rest are grouped into one Other column. Click a column name, or the Other column, to "
          "zoom in, and use the links above the chart to go back. Click any block for its value, share "
          "and a link to the fleets or awards behind it.",
          {"side": 6, "body": "bars", "act": [("move", 300, 140), ("click",), ("show", "chip")]}, "/app/market#mmap"),
         ("Service contracts", "Choose Service contracts ($/yr) on the Market map. It shows who operates and maintains rail service for "
          "agencies under contract: operations and maintenance, train operations, vehicle maintenance, track and signal "
          "maintenance and fleet overhauls. Each column width shows its value per year. Most values are what the agency "
          "reported to the National Transit Database. Other values come from board awards, published reports and awards "
          "that Bid Catcher found. We spread these values over the contract term. Contract holders show under their "
          "parent company. For example, Keolis Commuter Services and Keolis Rail Services America show as Keolis. Click a"
          " block to see the agencies. Then follow the link to Operations and maintenance for end dates and the next bid.",
          {"side": 6, "body": "bars", "act": [("move", 300, 140), ("click",), ("show", "chip")]}, "/app/market#mmap"),
         ("Zoom into a subsystem", "Click a subsystem to see every supplier in it, their share, and which car builders they supply.",
          {"side": 6, "body": "bars", "act": [("move", 250, 120), ("click",), ("show", "chip")]}, "/app/market"),
         ("Supplier change windows timeline", "Supplier change windows starts with a Window timeline. Each bar is one year. It shows the cars whose subsystem"
          " can change supplier that year, at a midlife overhaul, warranty end, retirement or end of useful life. Color "
          "the bars by current supplier, subsystem, reason or operator. Click a block (for example 2028 and Knorr-Bremse)"
          " or a name in the legend to list those fleets below. Click again or click Clear to reset. The subsystem, "
          "supplier and year filters above the timeline apply to all of the page.",
          {"side": 5, "body": "bars", "act": [("move", 300, 160), ("click",), ("show", "page")]}, "/app/supplier-windows"),
         ("Subsystems and suppliers", "Subsystems lists the supplier on each fleet; the supplier directory and supplier "
          "intelligence pages profile each company.",
          {"side": 5, "body": "table", "act": [("move", 330, 190), ("click",), ("show", "page")]}, "/app/subsystems"),
         ("Vehicle orders", "Upcoming work > Vehicle orders lists recent and active rolling stock orders and the cars still to "
          "come by year. Click any order to open its details: quantities, options, value, delivery, the operator's fleets "
          "and the builder's other orders.",
          {"side": 2, "body": "table", "act": [("move", 330, 180), ("click",), ("show", "page")]}, "/app/work?view=orders"),
         ("Replacement ordered", "Sometimes an agency has already ordered the replacement for a fleet, for example the Alstom M9A for the LIRR "
          "M3. Then that fleet is not in the buy ranking. It shows a Replacement ordered pill that opens the order. Click"
          " Show already ordered to see those fleets again. A Replacement RFP out pill means that the replacement is out "
          "to bid or in planning, so the purchase is still open.",
          {"side": 2, "body": "table", "act": [("move", 330, 180), ("show", "hl")]}, "/app/work?view=ranked"),
         ("Option exercises", "An Option exercise row in Upcoming work means that an agency can buy more cars on an order that it already "
          "signed. For example: CTDOT can still buy 313 more on the 2023 Alstom order (60 ordered). If those cars are not"
          " in service yet, the row shows the order. It has the text on order, not in service yet, and a New cars on "
          "order pill. If we cannot connect an older order to a fleet, the row shows No fleet match. The year and value "
          "are estimates. Point to the value to see how we calculated it. Click the row to open the order.",
          {"side": 2, "body": "table", "act": [("move", 330, 180), ("show", "hl"), ("click",), ("show", "page")]}, "/app/work?type=option"),
         ("Weekly freight service", "Freight > Weekly service metrics shows how each Class I network operates: train speed, terminal dwell, cars "
          "online, stalled cars and carloads. Each value is a 4-week average, compared with one year before. The site "
          "checks the STB every day and loads each new week when the railroads publish their reports. This is usually "
          "about one week after the week ends. Latest week at the top shows how current the data is.",
          {"side": 5, "body": "bars", "act": [("move", 330, 180), ("show", "hl")]}, "/rail/service"),
         ("Supplier financials and grades", "Supplier intelligence shows the revenue, growth, margin and backlog of each supplier. For listed companies, "
          "the figures come from SEC 10-K filings and annual reports. For private companies, we show the best public "
          "figure that we found. The letter after each figure is its grade. A is a company filing or audited report. B is"
          " a statement from the company or its owner. C is independent press. D is a data provider or Consist estimate, "
          "which is only approximate. Open a supplier and expand Sources to see each source.",
          {"side": 6, "body": "table", "act": [("move", 420, 190), ("show", "hl")]}, "/app/supplier-intel"),
     ]},
    {"slug": "explorer", "title": "Market Explorer and supplier market map", "icon": "pie", "min": 3,
     "why": "See each operator in your market on one map. The map shows its fleets, overhauls due, open bids, recent awards"
            " and estimated consumables spend. Make a target list in a few clicks.",
     "steps": [
         ("One map, one table", "Market Explorer shows each operator in your market view and territory on a map, at its head office or main "
          "city. The table under the map and the In view tiles count only what is on the map. Move and zoom the map to a "
          "region, and the totals change. To see everything, untick Table and totals follow the map.",
          {"side": 6, "body": "dash", "act": [("move", 330, 180), ("show", "hl")]}, "/app/explorer"),
         ("Filters and what the dots mean", "Use the filters to narrow the map. You can filter by country, state or province, mode and average fleet age. You can also filter by overhauls due in the next five years, open bids, and awards in the last two years. The dot size can show cars, consumables spend or award value. "
          "The dot color can show fleet age, overhauls due or open bids. A blue ring shows an operator with open bids. "
          "The legend under the filters explains the colors.",
          {"side": 6, "body": "dash", "act": [("move", 120, 160), ("click",), ("show", "chip")]}, "/app/explorer"),
         ("Linking rows and dots", "Click a table row to fly the map to that operator and open its card; click a dot to "
          "highlight its row. The card links to the operator page, its fleets and its bids. Click a column heading to sort. "
          "Plans with exports can download what is in view with Export CSV.",
          {"side": 6, "body": "table", "act": [("move", 330, 200), ("click",), ("show", "page")]}, "/app/explorer"),
         ("Supplier market map", "Click the Supplier market map pill, or Market map in the top menu, to see who supplies each operator. Choose a"
          " segment: car builders, a subsystem such as brakes, doors or propulsion, or rail awards over five years. The "
          "dot color shows the leading supplier there. The dot size shows cars or award value. Choose a supplier, or "
          "click it in the league table, to see only its operators. The color then shows its share at each operator. The "
          "league table and tiles follow the map. Zoom to a region to see the share in that region.",
          {"side": 6, "body": "dash", "act": [("move", 120, 160), ("click",), ("show", "chip")]}, "/app/explorer?view=suppliers"),
     ]},
    {"slug": "account", "title": "Account, plans and alerts", "icon": "user", "min": 3,
     "why": "What your plan includes, how to change it, and how to manage email alerts.",
     "steps": [
         ("Confirm your email", "New accounts open when you click the link we email after sign-up (it works for 48 hours). "
          "Nothing there? Check spam or promotions, or sign in and press Send a new link. Colleagues you invite to your team skip this step.",
          {"side": 9, "body": "dash", "act": [("move", 330, 150), ("click",), ("show", "toast")]}, "/app/account"),
         ("See what your plan includes", "Pages your plan doesn't include show a preview or a lock with the plan that adds them.",
          {"side": 9, "body": "dash", "act": [("move", 70, 334), ("click",), ("show", "lock")]}, "/app/account"),
         ("Manage alerts", "Change how often each saved search emails you, or turn it off. With a sales territory saved, one "
          "click limits an alert to bids from the agencies you cover.",
          {"side": 8, "body": "table", "act": [("move", 520, 160), ("click",), ("show", "chip")]}, "/app/alerts"),
         ("Your sales territory", "Cover a region or a set of accounts? In Account > Your territory, tick the states and provinces "
          "you cover (region buttons tick a group at once; Select all ticks every state and province), add agencies by name, and choose whether national buyers such as Amtrak "
          "count. Save, and the Territory switch at the top of every page turns it on or off. While it is on, bids, early signals, "
          "awards, board items, vehicle orders, fleets, operators, upcoming work, opportunities, dashboards and search show only "
          "your territory. A link to one named agency still opens it, and cost benchmarks and price comparisons stay national. "
          "In Alerts, tick Only bids in my territory on any saved search and its emails follow your territory too.",
          {"side": 9, "body": "dash", "act": [("move", 470, 52), ("click",), ("show", "lens")]}, "/app/account#territory"),
         ("Times in your time zone", "Each time on the site shows in your own time zone, with its short form (EST, PST and more). Examples are when "
          "we found a bid, when someone wrote a note, or when we last checked the data. The site uses the time zone of "
          "your browser. To set a different zone, go to Account > Time zone. Bid closing dates are the agency's own "
          "dates. They do not change.",
          {"side": 9, "body": "dash", "act": [("move", 330, 150), ("show", "hl")]}, "/app/account#timezone"),
         ("Upgrade or change plan", "Upgrade from Account; annual billing saves 20%.",
          {"side": 9, "body": "dash", "act": [("move", 330, 150), ("click",), ("show", "toast")]}, "/app/upgrade"),
         ("Follow us anywhere", "Our LinkedIn page and Bluesky account post important new rail bids, contract awards, fleet facts and charts. "
          "On Friday they post a summary of the week. They post a few times each week, and only when there is news. The "
          "links are at the bottom of each page.",
          {"side": 9, "body": "dash", "act": [("move", 330, 380), ("click",), ("show", "toast")]}, "/"),
         ("Monthly report and free charts", "Each month we email members the rail fleet report's headline numbers; the unsubscribe "
          "link in that email stops it. The public data pages have an Embed this chart box: paste the code into your own site, "
          "report or slides and the chart stays current, with a credit link back to us.",
          {"side": 9, "body": "bars", "act": [("move", 330, 180), ("click",), ("show", "toast")]}, "/data/midlife-overhauls-due#embed"),
         ("Public builder and model pages", "Anyone can look up a rail car builder or model at /builders without signing in. For example: who operates the "
          "Kawasaki M8 or the Alstom Citadis, how many are in service, and when they were built. Each page links to the "
          "public fleet list of each operator. You can share these pages with a colleague. The member pages also show "
          "costs, overhaul timing and suppliers.",
          {"side": 9, "body": "bars", "act": [("move", 330, 180), ("click",), ("show", "toast")]}, "/builders"),
         ("If a page asks you to wait", "Visitors who aren't signed in can open about 30 pages a minute; past that a short page asks "
          "them to wait a minute, which keeps automated copying from slowing the site down. Signed-in members are never limited, so "
          "signing in makes the message go away.",
          {"side": 9, "body": "dash", "act": [("show", "toast")]}, "/login"),
         ("Cookie choices", "Our public pages may ask once whether you accept LinkedIn advertising cookies, which help us measure our "
          "LinkedIn ads. They are off unless you click Accept, never run inside the app, and you can change your mind with Cookie "
          "choices in the site footer. The Privacy page explains what LinkedIn receives.",
          {"side": 9, "body": "dash", "act": [("show", "lock")]}, "/privacy"),
     ]},
]
BY_SLUG = {m["slug"]: m for m in MODULES}


def done_set(u):
    try:
        r = db.q("SELECT value FROM user_pref WHERE user_id = ? AND key = 'learn_done'", (u["id"],), one=True)
    except Exception:
        return set()
    return set(filter(None, ((r[0] if r else "") or "").split(",")))


def mark_done(u, slug, on=True):
    if slug not in BY_SLUG:
        return
    s = done_set(u)
    (s.add if on else s.discard)(slug)
    v = ",".join(m["slug"] for m in MODULES if m["slug"] in s)
    db.x("INSERT INTO user_pref (user_id, key, value) VALUES (?, 'learn_done', ?) "
         "ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value", (u["id"], v))


def clip_for(slug, i):
    f = f"{slug}-{i + 1}.mp4"
    return f"/static/learn/{f}" if os.path.exists(os.path.join(STATIC, f)) else None


# ---------- SVG scene ----------
W, H = 640, 380
BODY_X, BODY_Y = 150, 80


def _e(s):
    return html.escape(str(s), quote=True)


def _body(kind):
    o = []
    x0, y0 = BODY_X + 16, BODY_Y + 16
    if kind in ("table", "results"):
        o.append(f'<rect x="{x0}" y="{y0}" width="200" height="14" rx="3" class="l-ink"/>')
        o.append(f'<rect x="{W-140}" y="{y0-4}" width="64" height="22" rx="11" class="l-pill"/>'
                 f'<rect x="{W-68}" y="{y0-4}" width="52" height="22" rx="6" class="l-btn"/>')
        for i in range(7):
            y = y0 + 40 + i * 30
            cls = "l-row l-hit" if kind == "results" and i in (0, 3) else "l-row"
            o.append(f'<g class="{cls}"><rect x="{x0}" y="{y}" width="{W-x0-16}" height="24" rx="4" class="l-rowbg"/>'
                     f'<rect x="{x0+8}" y="{y+8}" width="{90+(i*23)%60}" height="8" rx="2" class="l-ln"/>'
                     f'<rect x="{x0+180}" y="{y+6}" width="46" height="12" rx="6" class="l-pill"/>'
                     f'<rect x="{x0+260}" y="{y+8}" width="{40+(i*17)%50}" height="8" rx="2" class="l-ln"/></g>')
    elif kind == "detail":
        o.append(f'<rect x="{x0}" y="{y0}" width="240" height="16" rx="3" class="l-ink"/>'
                 f'<rect x="{W-110}" y="{y0-4}" width="94" height="22" rx="6" class="l-btn"/>')
        for j, (yy, hh) in enumerate([(50, 90), (155, 70), (240, 60)]):
            o.append(f'<rect x="{x0}" y="{y0+yy}" width="{W-x0-16}" height="{hh}" rx="8" class="l-card"/>')
            for k in range(hh // 22):
                o.append(f'<rect x="{x0+14}" y="{y0+yy+14+k*20}" width="{160+(k*41)%140}" height="8" rx="2" class="l-ln"/>')
    elif kind == "chat":
        o.append(f'<rect x="{x0}" y="{y0}" width="160" height="14" rx="3" class="l-ink"/>')
        o.append(f'<rect x="{x0+180}" y="{y0+30}" width="{W-x0-196}" height="34" rx="10" class="l-bubble l-me"/>')
        o.append(f'<g class="l-answer"><rect x="{x0}" y="{y0+80}" width="{W-x0-60}" height="120" rx="10" class="l-card"/>'
                 + "".join(f'<rect x="{x0+14}" y="{y0+96+k*20}" width="{220+(k*53)%160}" height="8" rx="2" class="l-ln"/>' for k in range(5))
                 + f'<rect x="{W-110}" y="{y0+110}" width="60" height="20" rx="6" class="l-btn"/></g>')
        o.append(f'<rect x="{x0}" y="{H-58}" width="{W-x0-16}" height="36" rx="8" class="l-input"/>'
                 f'<rect x="{x0+8}" y="{H-50}" width="20" height="20" rx="4" class="l-pill"/>')
    elif kind == "bars":
        o.append(f'<rect x="{x0}" y="{y0}" width="180" height="14" rx="3" class="l-ink"/>')
        for i, w in enumerate([300, 230, 170, 120, 80, 50]):
            y = y0 + 40 + i * 36
            o.append(f'<rect x="{x0}" y="{y}" width="70" height="8" rx="2" class="l-ln"/>'
                     f'<rect x="{x0+90}" y="{y-6}" width="{w}" height="20" rx="4" class="l-bar l-b{i%3}"/>')
    else:  # dash
        for i in range(3):
            o.append(f'<rect x="{x0+i*150}" y="{y0}" width="136" height="64" rx="8" class="l-card"/>'
                     f'<rect x="{x0+i*150+12}" y="{y0+14}" width="50" height="16" rx="3" class="l-ink"/>'
                     f'<rect x="{x0+i*150+12}" y="{y0+40}" width="90" height="8" rx="2" class="l-ln"/>')
        o.append(f'<rect x="{x0}" y="{y0+80}" width="{W-x0-16}" height="170" rx="8" class="l-card"/>')
        for k in range(6):
            o.append(f'<rect x="{x0+14}" y="{y0+98+k*24}" width="{200+(k*61)%180}" height="8" rx="2" class="l-ln"/>')
    return "".join(o)


def scene(spec, uid, label):
    """Return an inline SVG for one step. The cursor walks through the 'move' points; 'click' pulses; 'type' types text into
    the header search or the chat box; 'show' reveals an overlay (filter chip, toast, highlight, answer). Loops every 7s."""
    acts = spec.get("act", [])
    pts = [(560, 340)] + [(a[1], a[2]) for a in acts if a[0] == "move"]
    n = max(1, len(acts))
    T = 7.0
    # cursor keyframes: one segment per action, then hold, then fade back
    kf, t, cur, clicks, typed, shows = [], 0.0, pts[0], [], [], []
    step = 0.7 / n
    kf.append((0, cur))
    mi = 1
    for i, a in enumerate(acts):
        t = round(0.08 + i * step, 3)
        if a[0] == "move":
            cur = pts[mi]; mi += 1
            kf.append((t + step * 0.8, cur))
        elif a[0] == "click":
            clicks.append((t, cur))
        elif a[0] == "type":
            typed.append((t, a[1], a[2]))
        elif a[0] == "show":
            shows.append((t, a[1]))
    kf.append((0.92, cur))
    kf.append((1.0, cur))
    css_kf = " ".join(f"{p*100:.1f}%{{transform:translate({x}px,{y}px)}}" for p, (x, y) in kf)
    s = [f'<svg class="lscene" viewBox="0 0 {W} {H}" role="img" aria-label="{_e(label)}" id="{uid}" xmlns="http://www.w3.org/2000/svg">',
         f'<style>#{uid} .cur{{animation:{uid}m {T}s infinite ease-in-out}} @keyframes {uid}m{{{css_kf}}}']
    for j, (p, (x, y)) in enumerate(clicks):
        a, b = p * 100, min(100, p * 100 + 6)
        s.append(f'#{uid} .ck{j}{{transform-origin:{x}px {y}px;animation:{uid}c{j} {T}s infinite}}'
                 f'@keyframes {uid}c{j}{{0%,{a:.1f}%{{opacity:0;transform:scale(.3)}}{a+1:.1f}%{{opacity:.9}}{b:.1f}%,100%{{opacity:0;transform:scale(1.6)}}}}')
    for j, (p, _w, txt) in enumerate(typed):
        a, b = p * 100, min(95, p * 100 + 14)
        s.append(f'#{uid} .ty{j}{{animation:{uid}t{j} {T}s infinite steps({max(1, len(txt))})}}'
                 f'@keyframes {uid}t{j}{{0%,{a:.1f}%{{width:0}}{b:.1f}%,96%{{width:{len(txt)*7.2+4:.0f}px}}100%{{width:0}}}}')
    for j, (p, _w) in enumerate(shows):
        a = p * 100 + 6
        s.append(f'#{uid} .sh{j}{{animation:{uid}s{j} {T}s infinite}}'
                 f'@keyframes {uid}s{j}{{0%,{a:.1f}%{{opacity:0}}{a+3:.1f}%,94%{{opacity:1}}100%{{opacity:0}}}}')
    s.append(f'@media (prefers-reduced-motion:reduce){{#{uid} *{{animation:none!important}} #{uid} .cur{{transform:translate({cur[0]}px,{cur[1]}px)}} '
             f'#{uid} [class^=sh]{{opacity:1}}}}</style>')
    # frame
    s.append(f'<rect width="{W}" height="{H}" rx="12" class="l-frame"/><rect width="{W}" height="26" rx="12" class="l-chrome"/>'
             f'<rect y="14" width="{W}" height="12" class="l-chrome"/>'
             + "".join(f'<circle cx="{16+i*14}" cy="13" r="4" class="l-dot"/>' for i in range(3)))
    # sidebar
    s.append(f'<rect x="0" y="26" width="{BODY_X-10}" height="{H-26}" class="l-side"/>'
             f'<text x="16" y="52" class="l-logo">Consist</text>')
    for i, lab in enumerate(SIDE):
        y = 76 + i * 29
        on = i == spec.get("side")
        s.append(f'<g class="l-nav{" l-on" if on else ""}"><rect x="6" y="{y-14}" width="{BODY_X-22}" height="22" rx="5" class="l-navbg"/>'
                 f'<text x="16" y="{y+1}">{_e(lab)}</text></g>')
    # header: search + lens
    s.append(f'<rect x="{BODY_X}" y="38" width="250" height="28" rx="14" class="l-input l-search"/>'
             f'<circle cx="{BODY_X+18}" cy="51" r="5" class="l-ic"/><text x="{BODY_X+30}" y="56" class="l-ph">Search fleets, operators…</text>'
             f'<g class="l-lens"><rect x="{W-200}" y="38" width="184" height="28" rx="8" class="l-seg"/>'
             f'<rect x="{W-198}" y="40" width="60" height="24" rx="6" class="l-segon"/>'
             f'<text x="{W-188}" y="56">All rail</text><text x="{W-128}" y="56">Transit</text><text x="{W-72}" y="56">Passenger</text></g>')
    s.append(_body(spec.get("body", "dash")))
    # overlays
    for j, (p, what) in enumerate(shows):
        g = f'<g class="sh{j}">'
        if what == "chip":
            g += f'<rect x="{BODY_X+16}" y="{BODY_Y+38}" width="150" height="22" rx="11" class="l-chip"/><text x="{BODY_X+28}" y="{BODY_Y+53}" class="l-chipt">Filtered by ✕</text>'
        elif what == "toast":
            g += f'<rect x="{W-230}" y="{H-60}" width="210" height="40" rx="8" class="l-toast"/><text x="{W-216}" y="{H-35}" class="l-toastt">Done ✓</text>'
        elif what in ("hl", "hl2"):
            y = BODY_Y + (66 if what == "hl" else 250)
            g += f'<rect x="{BODY_X+10}" y="{y}" width="{W-BODY_X-20}" height="{100 if what == "hl" else 74}" rx="10" class="l-ring"/>'
        elif what == "lens":
            g += f'<rect x="{W-204}" y="34" width="192" height="36" rx="10" class="l-ring"/>'
        elif what in ("filter", "results"):
            g += f'<rect x="{BODY_X+16}" y="{BODY_Y+56}" width="{W-BODY_X-32}" height="24" rx="4" class="l-ring"/>'
            if what == "results":
                g += f'<rect x="{BODY_X+16}" y="{BODY_Y+146}" width="{W-BODY_X-32}" height="24" rx="4" class="l-ring"/>'
        elif what == "page":
            g += f'<rect x="{BODY_X}" y="{BODY_Y}" width="{W-BODY_X}" height="{H-BODY_Y}" class="l-veil"/>' \
                 f'<rect x="{BODY_X+40}" y="{BODY_Y+40}" width="{W-BODY_X-80}" height="200" rx="10" class="l-card l-pop"/>' \
                 + "".join(f'<rect x="{BODY_X+56}" y="{BODY_Y+60+k*22}" width="{180+(k*37)%140}" height="8" rx="2" class="l-ln"/>' for k in range(7))
        elif what == "answer":
            g += f'<rect x="{BODY_X+12}" y="{BODY_Y+92}" width="{W-BODY_X-80}" height="128" rx="12" class="l-ring"/>'
        elif what == "file":
            g += f'<rect x="{BODY_X+16}" y="{H-96}" width="170" height="28" rx="6" class="l-chip"/><text x="{BODY_X+28}" y="{H-77}" class="l-chipt">spec.pdf  ☑ consent</text>'
        elif what == "lock":
            g += f'<rect x="{W/2-20}" y="{H/2-30}" width="190" height="56" rx="10" class="l-toast"/><text x="{W/2-6}" y="{H/2+3}" class="l-toastt">🔒 Private to you</text>'
        s.append(g + "</g>")
    for j, (p, where, txt) in enumerate(typed):
        x, y = (BODY_X + 30, 56) if where == "search" else (BODY_X + 50, H - 35)
        s.append(f'<rect x="{x-2}" y="{y-14}" width="{"200" if where == "search" else "400"}" height="20" class="l-inbg"/>'
                 f'<svg x="{x}" y="{y-14}" height="20" class="ty{j}" style="overflow:hidden"><text x="0" y="14" class="l-typed">{_e(txt)}</text></svg>')
    for j, (p, (x, y)) in enumerate(clicks):
        s.append(f'<circle cx="{x}" cy="{y}" r="14" class="l-click ck{j}"/>')
    s.append('<g class="cur"><path d="M0 0 L0 17 L5 13 L8 20 L11 19 L8 12 L14 12 Z" class="l-arrow"/></g></svg>')
    return "".join(s)


def modules_for(u):
    done = done_set(u)
    return [dict(m, done=m["slug"] in done) for m in MODULES], done
