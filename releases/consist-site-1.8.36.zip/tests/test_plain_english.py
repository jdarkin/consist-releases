"""Simplified Technical English check (1.8.33, Justin 11-28: ASD-STE100 style for app pages, help, lessons, glossary and
emails; not legal or public marketing pages). Run: python tests/test_plain_english.py [--all]

STE rules checked here, in a simple form:
  - a sentence in a lesson step, Help text or first-day task has no more than 25 words (STE: 20 for steps, 25 for
    descriptions; we use 25 for both);
  - no words from the STE "not approved" list below, where a simpler approved word exists.
Lessons (app/learn.py), Help (app/pagehelp.py), the first-day list (app/firstday.py) and the glossary (app/glossary.py)
must pass, and so must the text on member and admin app pages: paragraphs, tooltips, buttons (1.8.34, 1.8.35). Legal pages (terms, privacy) and public marketing pages are out of scope (Justin 11-28)."""
import pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
MAX = 25
# not approved -> approved (ASD-STE100 style)
AVOID = {"utilize": "use", "utilise": "use", "leverage": "use", "facilitate": "help", "commence": "start",
         "prior to": "before", "in order to": "to", "subsequently": "then", "approximately": "about",
         "additional": "more", "numerous": "many", "obtain": "get", "require": "need", "requires": "needs",
         "assist": "help", "ensure": "make sure", "terminate": "stop", "initiate": "start", "via": "through",
         "e.g.": "for example", "i.e.": "that is", "etc.": "and more", "whilst": "while", "in the event that": "if",
         "a number of": "some", "at this point in time": "now", "is able to": "can", "are able to": "can"}
RX = re.compile(r"\b(" + "|".join(re.escape(k) for k in sorted(AVOID, key=len, reverse=True)) + r")(?=\W|$)")  # lower case only: "VIA Rail" is a name

def sentences(t):
    t = re.sub(r"\b(e\.g|i\.e|etc|vs|St|No)\.", lambda m: m.group(0).replace(".", ""), t)
    return [s.strip() for s in re.split(r"(?<=[.!?:;])\s+|\s·\s", t) if s.strip()]

def check(label, text):
    bad = []
    for s in sentences(text):
        n = len(re.findall(r"[A-Za-z0-9][\w'’/-]*", s))
        if n > MAX: bad.append(f"{label}: {n} words: {s[:90]}…")
    for m in RX.finditer(text):
        bad.append(f"{label}: use '{AVOID[m.group(1)]}' not '{m.group(1)}'")
    return bad

def texts(all_=False):
    from app import learn, pagehelp, firstday
    for m in learn.MODULES:
        yield f"lesson {m['slug']} why", m["why"]
        for i, st in enumerate(m["steps"], 1):
            yield f"lesson {m['slug']} step {i} title", st[0]
            yield f"lesson {m['slug']} step {i}", st[1]
    for h, row in pagehelp.PAGES.items():
        yield f"help {h}", row[2]
    for k, v in pagehelp.PLAIN.items():
        yield f"plain term {k}", v
    for k, t, x, h in firstday.TASKS:
        yield f"first day {k}", t + ". " + x
    if True:  # glossary passes since 1.8.33
        from app import glossary
        for k, v in glossary.TERMS.items():
            yield f"glossary {k}", v

def page_paragraphs():
    """1.8.34: the text in <p> blocks of member app pages. 1.8.35: also admin pages and partials, tooltips (title, aria-label,
    placeholder, data-tip), button and summary labels, and other long text runs. Template code is removed first."""
    for p in sorted(list((ROOT / "app/templates/app").glob("*.html")) + list((ROOT / "app/templates/admin").glob("*.html"))
                    + list((ROOT / "app/templates/partials").glob("*.html"))):
        s = p.read_text()
        s = re.sub(r"\{#.*?#\}", "", s, flags=re.S)
        s = re.sub(r"<(script|style)\b.*?</\1>", "", s, flags=re.S)
        s = re.sub(r"\{%.*?%\}", " ", s, flags=re.S)
        s = re.sub(r"\{\{.*?\}\}", "X", s, flags=re.S)
        for m in re.finditer(r"<p\b[^>]*>(.*?)</p>", s, flags=re.S):
            x = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m.group(1))).strip()
            if len(x) > 40:
                yield f"page {p.name}", x
        for m in re.finditer(r'\b(?:title|aria-label|placeholder|data-tip)="([^"]{30,})"', s):
            yield f"tooltip {p.name}", m.group(1)
        for m in re.finditer(r"<(button|summary)\b[^>]*>(.*?)</\1>", s, flags=re.S):
            x = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m.group(2))).strip()
            if len(x) > 20:
                yield f"button {p.name}", x
        for m in re.finditer(r"<(?:li|td|span|div|label|dd)\b[^>]*>([^<]{60,})", s):
            yield f"text {p.name}", re.sub(r"\s+", " ", m.group(1)).strip()

def problems(all_=False):
    out = []
    for label, t in generator_strings():
        out += check(label, t)
    for label, t in page_paragraphs():
        out += check(label, t)
    for label, t in texts(all_):
        out += check(label, t)
    return out

# 1.8.36: text that the site generates. These modules write member-facing reports, emails, briefs and keys from templates;
# their template strings must pass too. Docstrings, SQL and code-like strings are skipped.
GENERATORS = ["promo.py", "alerts.py", "bd18.py", "awareness.py", "reportkey.py", "pdfbrief.py", "referrals.py", "ambassadors.py",
              "escalation.py", "guide.py", "pagehelp.py", "firstday.py", "ste.py"]
GEN_ALLOW = ["The fields are: notice (Consist bid id)"]  # a field list, not a sentence

def generator_strings():
    import ast
    for name in GENERATORS:
        tree = ast.parse((ROOT / "app" / name).read_text())
        docs = {id(n.body[0].value) for n in ast.walk(tree)
                if isinstance(n, (ast.Module, ast.FunctionDef, ast.ClassDef)) and n.body and isinstance(n.body[0], ast.Expr)
                and isinstance(n.body[0].value, ast.Constant)}
        for n in ast.walk(tree):
            if id(n) in docs: continue
            if isinstance(n, ast.JoinedStr):
                x = "".join(v.value if isinstance(v, ast.Constant) else "X" for v in n.values)
            elif isinstance(n, ast.Constant) and isinstance(n.value, str):
                x = n.value
            else: continue
            x = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", x)).strip()
            if len(x.split()) < 8 or re.search(r"SELECT|INSERT|CREATE|UPDATE |\bdef |https?://|\(\?|\\b", x): continue
            for a in GEN_ALLOW: x = x.split(a)[0]
            yield f"generated {name}:{n.lineno}", x

def test_ste_clean():
    sys.path.insert(0, str(ROOT))
    from app import ste
    assert ste.clean("We utilize parts, e.g. brakes, prior to the overhaul, etc.") == "We use parts, for example brakes, before the overhaul and more."
    assert ste.clean_obj({"headline": "In order to bid", "n": 3}) == {"headline": "To bid", "n": 3}

def test_plain_english():
    b = problems(); assert not b, "\n".join(b)

if __name__ == "__main__":
    b = problems("--all" in sys.argv); print("\n".join(b) or "OK: plain English"); print(len(b), "items"); sys.exit(1 if b else 0)
