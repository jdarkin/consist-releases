"""Relevance of a notice to the rail market (vehicles first, then infrastructure, systems, operations and engineering):
a keyword score first, then a Claude review of the candidates."""
import json, re

import bidcore as bc
import taxonomy

CATEGORIES = {
    "overhaul_program": "midlife or heavy overhaul / rebuild / remanufacture of rail cars or locomotives",
    "component_repair": "repair, rebuild or exchange of vehicle components (trucks, wheelsets, traction motors, HVAC units, door operators, brakes, couplers, compressors)",
    "parts_supply": "supply of rail vehicle spare parts or consumables",
    "maintenance_services": "contract maintenance of equipment / fleet maintenance or O&M that includes vehicle maintenance",
    "onboard_systems": "supply, retrofit or upgrade of onboard systems (PIS, CCTV, PTC onboard, event recorders, APC, TCMS, propulsion upgrade)",
    "shop_equipment": "maintenance shop equipment (wheel truing lathes, lifts, car washes, test benches) and shop facilities",
    "cleaning_interior": "vehicle cleaning, upholstery, flooring, interior refurbishment, graffiti/film",
    "vehicle_procurement": "purchase or lease of new or used rail cars / locomotives (incl. options)",
    "engineering_support": "engineering, inspection, reliability or technical support services for the fleet",
    "track_infrastructure": "track construction, renewal or maintenance (rail, ties, ballast, switches, grinding, track geometry), rail bridges, tunnels and right of way",
    "signals_communications": "train control and signaling (CBTC, PTC wayside, interlockings, grade crossings), rail communications and SCADA",
    "traction_power": "traction power: catenary / overhead contact system, third rail, substations, rail electrification",
    "stations_facilities": "rail stations, platforms, rail yards and rail maintenance facilities (design, construction, repair, equipment)",
    "rail_operations": "rail operations or operations-and-maintenance contracts for a rail system (excluding fleet-only maintenance)",
    "rail_engineering": "engineering, design, construction management, inspection or consulting services for rail projects",
    "other": "rail-related but none of the above",
}
SUBSYSTEMS = taxonomy.KEYS  # vehicle, wayside and facility subsystems; see taxonomy.py

# (pattern, weight). Word boundaries matter: "door" alone is too broad, "door operator" is not.
RAIL = [(r"rail ?cars?", 30), (r"light rail vehicles?|\blrvs?\b", 30), (r"rolling stock", 35), (r"locomotives?", 30),
        (r"\b(emu|dmu|mu)s?\b", 15), (r"bi-?level|multi-?level|commuter (rail )?(car|coach)", 30), (r"streetcars?|tram(way)?s?\b", 20),
        (r"subway cars?|metro cars?|transit cars?|passenger cars?|coach(es)?\b", 20), (r"\b(trains?|rail|railroad|railway)\b", 8),
        (r"mat[ée]riel roulant|voitures? de m[ée]tro|locomotives?|tramways?|trains?\b|ferroviaire|m[ée]tro\b", 25),
        (r"voitures? (de passagers|ferroviaires?|de train|multiniveaux|[àa] [ée]tage)|wagons?\b|rames?\b|\bmr-?(63|73)\b|\bazur\b|"
         r"\bmpm-?10\b|v[ée]hicules? (ferroviaires?|l[ée]gers? sur rail)|\bvlr\b|train de banlieue|trains? l[ée]gers?", 25)]
MAINT = [(r"overhaul|mid-?life|rebuild|re-?manufactur|refurbish|recondition|re-?power", 30),
         (r"repair|maintenance|r[ée]vision|r[ée]paration|entretien|remise [àa] neuf", 15),
         (r"(spare )?parts?\b|pi[èe]ces", 10),
         (r"trucks?\b|bogies?|wheel ?sets?|wheels?\b|axles?|bearings?", 18), (r"traction motors?|propulsion|inverters?|gear ?box", 20),
         (r"hvac|air condition|climatisation", 15), (r"door (operator|system|controller)s?|portes?\b", 15),
         (r"brakes?|freins?|compressors?", 12), (r"couplers?|attelage|draft gear|pantograph", 15),
         (r"passenger information|\bpis\b|destination sign|event recorder|\bptc\b|tcms|vehicle control", 12),
         (r"wheel truing|underfloor lathe|car ?wash|drop table|hoist|lifting jacks?", 15),
         (r"head end power|\bhep\b|prime mover|engine overhaul|cummins|qsk|mtu|emd|caterpillar", 15),
         # French (SEAO / Quebec): parts and systems of rail cars
         (r"bogies?|essieux?|roues?\b|roulements?|pneus?\b|roues? de guidage|moteurs? de traction|onduleurs?|hacheurs?|r[ée]ducteurs?", 18),
         (r"compresseurs?|[ée]triers?|semelles? de frein|plaquettes? de frein|garnitures? de frein|frotteurs?|pantographes?|balais", 15),
         (r"r[ée]fection|r[ée]habilitation|r[ée]novation|reconditionnement|remise en [ée]tat", 15),
         (r"syst[èe]me (de portes|de freinage|de propulsion|de ventilation|de climatisation|d'information voyageurs)|"
         r"[ée]clairage|si[èe]ges?|vitrages?|pare-brise|attelages?", 10)]
OEM = [(r"wabtec|knorr|faiveley|siemens|alstom|bombardier|stadler|hitachi|kawasaki|\bcaf\b|nippon sharyo|hyundai rotem|"
        r"progress rail|motivepower|brookville|kinki sharyo|ansaldo|thales|mitsubishi electric|toshiba|vapor|sepsa|liebherr|"
        r"merak|dellner|voith|schaltbau|new york air brake|nyab|amsted|standard steel|lucchini|bonatrans|gmi|luminator|"
        r"r2p|portec|harsco", 12)]
NEG = [(r"\bbus(es)?\b|motor ?coach|paratransit|van\b|non-revenue vehicle|police vehicle|trucks? \(vehicle\)|autobus|transport adapt[ée]|"
        r"minibus|v[ée]hicules? de service|camions?\b", -25),
       (r"janitorial|landscap|legal services|audit|insurance|banking|advertising|marketing|uniforms?|security guard|"
        r"pest control|snow removal|vegetation|parking|fare (media|collection)|office|furniture|printing|catering|"
        r"entretien m[ée]nager|bureaux|d[ée]neigement|am[ée]nagement paysager|gardiennage|assurances?|imprim", -40),
       (r"highway|roadway|interstate|pavement|paving|culvert|sidewalk|bike lane|traffic signal|airport runway|taxiway", -15)]
# rail infrastructure, systems, operations and engineering. Rail-specific words also count as rail context.
INFRA_RAIL = [(r"track ?(work|rehab|renewal|replacement|maintenance|geometry)|rail (grinding|replacement|renewal)|crossties?|concrete ties|"
               r"ballast|turnouts?|special trackwork|switch(es)? and crossings?|frogs?\b|rail welding|thermite", 35),
              (r"catenary|overhead contact (system|wire)|\bocs\b|third rail|traction power|tpss|rectifiers?|electrification|pantograph", 35),
              (r"cbtc|positive train control|\bptc\b|interlockings?|wayside signal|train control|signal(l)?ing|grade crossings?|"
               r"track circuits?|axle counters?|rail scada|radio system for (rail|train)", 35),
              (r"rail (yard|station|platform|maintenance facility|shop|corridor|line|extension|project|bridge|tunnel|right[- ]of[- ]way|engineering|design|infrastructure|systems?)|"
               r"light rail|commuter rail|metro(rail|link)?\b|subway|streetcar|monorail|people mover|\bapm\b|automated guideway|"
               r"railroad|railway|amtrak|transit rail", 35),
              (r"voie ferr[ée]e|caténaire|signalisation ferroviaire|gare\b|ferroviaire|\breseau express metropolitain\b|\brem\b", 35),
              (r"appareils? de voie|aiguillages?|traverses? de (bois|b[ée]ton)|longs rails|rails? (de|du)\b|voies? (de m[ée]tro|principales?|de garage|d'essai)|"
               r"signalisation|enclenchements?|contr[ôo]le des trains|sous-stations?|postes? de redressement|alimentation [ée]lectrique|"
               r"stations? de m[ée]tro|centre d'entretien|atelier (de|d')|garage (de|du) m[ée]tro|tunnels? du m[ée]tro", 30)]
INFRA_WORK = [(r"station (construction|improvement|rehab|renovation|design)|platforms?|canopy|elevators?|escalators?|tunnels?|viaducts?|"
               r"bridges?|retaining wall|drainage|fencing|right[- ]of[- ]way|vegetation control", 10),
              (r"operations? and maintenance|o&m\b|operat(e|ion|ing) (the )?(rail|train|streetcar|light rail|commuter)|contract operat", 25),
              (r"engineering|design services|construction management|program management|inspection|consult(ing|ant)|feasibility|"
               r"environmental (review|assessment)|on-?call", 12),
              (r"construction|installation|rehab(ilitation)?|replacement|remplacement|upgrade|modernization|extension|state of good repair|travaux", 15)]


FRENCH = re.compile(r"\b(de|des|du|la|le|les|pour|et|d'|l')\b", re.I)


def kw_score(text, rail_agency=False):
    """Keyword score 0-100. rail_agency: the buyer is a known rail operator and the text is in French; Quebec agencies rarely say
    "rail" or "metro" in a parts or repair title, so the buyer supplies the rail context and the notice reaches the Claude review."""
    t = (text or "").lower()
    def hit(rules):
        return sum(w for p, w in rules if re.search(p, t))
    rail, maint, oem, neg = hit(RAIL) + hit(INFRA_RAIL), hit(MAINT) + hit(INFRA_WORK), hit(OEM), hit(NEG)
    if rail_agency and len(FRENCH.findall(t)) >= 2:
        rail += 15
    score = min(rail, 45) + min(maint, 45) + min(oem, 15) + neg
    if rail == 0:
        score = min(score, 25)  # work words alone are not enough without rail context
    return max(0, min(100, score))


REVIEW_SYSTEM = f"""You screen public procurement notices for a rail market intelligence service in the US and Canada. The service tracks every bid in the rail market: passenger rail vehicles first (commuter, intercity, subway/metro, light rail, streetcar, people movers), and also rail infrastructure and services: track, signals and train control, traction power and catenary, stations, yards and shops, rail operations and O&M contracts, and rail engineering, design and consulting. Freight railroad work counts too, a little lower.

For each notice, decide:
- relevance 0-100: 90+ rail vehicles, rolling stock or their maintenance, parts and onboard systems; 70-89 other clearly rail work (track, signals, traction power, rail stations or facilities, rail operations, rail engineering or construction); 50-69 rail-adjacent or partly rail (multimodal transit agency work that includes rail assets, freight railroad work, general transit facilities that serve rail); 30-49 possibly related (vague titles from a rail agency); below 30 unrelated (bus-only, highway or road work, airports apart from their people movers, office and corporate services, IT unrelated to rail).
- rail: true when the work concerns rail vehicles or rail systems; false for bus-only or non-rail work.
- category: one of {json.dumps(list(CATEGORIES))}. Vehicle categories come first when they fit.
- subsystems: any of {json.dumps(SUBSYSTEMS)} the notice concerns (empty if none). Infrastructure work has subsystems too: wayside_train_control, grade_crossings, track, special_trackwork, structures, ocs_catenary, third_rail, substations, communications, stations, yards_facilities.
- operator_id: the fleet database operator code from the list given, if the buyer runs one of those rail systems, else "".
- summary: one plain English sentence a busy reader can scan (what, for which system, key quantity or term if stated), whatever the notice's language.
- title_en: when the title is in French or Spanish, a faithful English translation of it (keep reference numbers, names and place names as written); "" when the title is already English.
Judge only from the text given. Notices in French are common (Québec)."""

REVIEW_SCHEMA = {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "object", "properties": {
    "id": {"type": "integer"}, "relevance": {"type": "integer"}, "rail": {"type": "boolean"},
    "category": {"type": "string", "enum": list(CATEGORIES)}, "subsystems": {"type": "array", "items": {"type": "string"}},
    "operator_id": {"type": "string"}, "summary": {"type": "string"}, "title_en": {"type": "string"}},
    "required": ["id", "relevance", "rail", "category", "subsystems", "operator_id", "summary", "title_en"], "additionalProperties": False}}},
    "required": ["items"], "additionalProperties": False}


def operator_list(c):
    ops = {}
    for r in c.execute("SELECT agency_id, agency, fleet_operator_ids FROM agency"):
        for o in (r["fleet_operator_ids"] or "").split(";"):
            if o:
                ops[o] = r["agency"]
    return "\n".join(f"{k}: {v}" for k, v in sorted(ops.items()))


# agencies that buy nothing but rail: every purchase is rail work even when the title never says so ("Wire-2KV", "Static
# Frequency Converter"), so their notices get rail context and go to the Claude review
RAIL_ONLY = {"AMTRAK", "METRA", "NICTD", "VRE", "VPRA", "METROLINK", "LOSSAN", "CALTRAIN", "SFRTA", "SUNRAIL", "PATCO", "SMART", "ACE",
             "SJJPA", "CCJPA", "VALLEYLINK", "VIA", "BRIGHTLINE", "ARRC", "NNEPRA", "RIOMETRO"}


def review(c, min_kw=20, batch=25, budget=None):
    """Scores new notices by keyword, then asks Claude about every candidate at or above min_kw.
    Returns the cost in USD. Without an API key, the keyword score stands."""
    french_rekw(c)
    rail_only_rekw(c)
    import translate  # title_en / lang columns on notice
    translate.ensure(c)
    import early
    for r in c.execute("SELECT notice_id, title, description, subsystems, agency_id, source, notice_type FROM notice WHERE kw_score IS NULL").fetchall():
        s = kw_score(f"{r['title']} {r['description'] or ''}", rail_agency=bool(r["agency_id"]))
        if r["agency_id"] in RAIL_ONLY:
            s = max(s, 30)  # rail work by definition: the Claude review decides how relevant
        elif (r["source"] == "sam_gov" or r["agency_id"]) and early.is_early(r["title"], r["description"], r["notice_type"]):
            s = max(s, 30)  # an RFI / sources sought from a rail NAICS code or a rail agency rarely names the rail work: let the review judge
        c.execute("UPDATE notice SET kw_score=?, relevance=?, reviewed=CASE WHEN reviewed='history' THEN 'history' ELSE 'keywords' END, "
                  "subsystems=nullif(?, '') WHERE notice_id=?",
                  (s, s, taxonomy.merge(r["subsystems"], f"{r['title']} {r['description'] or ''}"), r["notice_id"]))
    c.commit()
    import sources
    sources.closing_backfill(c)
    todo = c.execute("SELECT notice_id, buyer, agency_id, title, description, notice_type FROM notice "
                     "WHERE reviewed='keywords' AND kw_score >= ? ORDER BY notice_id", (min_kw,)).fetchall()
    if not todo or not bc.api_key():
        link_awards(c)
        _hygiene(c)
        return 0.0
    cost, ops = 0.0, operator_list(c)
    for i in range(0, len(todo), batch):
        if budget is not None and cost >= budget:
            bc.log(f"review: daily budget reached, {len(todo) - i} notices keep their keyword score")
            break
        chunk = todo[i:i + batch]
        lines = [json.dumps({"id": r["notice_id"], "buyer": r["buyer"] or r["agency_id"], "type": r["notice_type"],
                             "title": r["title"], "description": (r["description"] or "")[:1500]}, ensure_ascii=False) for r in chunk]
        prompt = f"Fleet operators (operator_id: agency):\n{ops}\n\nNotices, one JSON object per line:\n" + "\n".join(lines)
        try:
            out, k = bc.claude_json(REVIEW_SYSTEM, prompt, REVIEW_SCHEMA)
        except Exception as e:
            bc.log(f"review: Claude call failed ({e}); keyword scores stand for this batch")
            continue
        cost += k
        text = {r["notice_id"]: f"{r['title']} {r['description'] or ''}" for r in chunk}
        for it in out["items"]:
            subs = taxonomy.merge(";".join(s for s in it["subsystems"] if s in SUBSYSTEMS), text.get(it["id"], "")) or None
            c.execute("UPDATE notice SET relevance=?, rail=?, category=?, subsystems=?, operator_id=nullif(?, ''), summary=?, "
                      "reviewed='claude' WHERE notice_id=?",
                      (max(0, min(100, it["relevance"])), int(it["rail"]), it["category"], subs, it["operator_id"],
                       it["summary"], it["id"]))
            if (it.get("title_en") or "").strip():  # French / Spanish title: Claude's translation, unless one is already stored
                c.execute("UPDATE notice SET title_en=?, translated_by=coalesce(translated_by, 'claude'), translated=coalesce(translated, ?) "
                          "WHERE notice_id=? AND title_en IS NULL", (it["title_en"].strip()[:500], bc.now(), it["id"]))
        c.commit()
    sources.closing_backfill(c)  # the review summary often states the due date when the portal field is blank
    link_awards(c)
    _hygiene(c)
    return cost


def _hygiene(c):
    try:
        import hygiene
        hygiene.run(c)
    except Exception as e:
        bc.log(f"hygiene: {e}")


def rail_only_rekw(c):
    """Once: open notices of rail-only agencies (RAIL_ONLY) that keywords left below 50 are re-scored with rail context, so they
    reach the Claude review in the normal daily runs (within the daily cap). Already-seen notices are not alerted again."""
    if c.execute("SELECT 1 FROM run_log WHERE task='rail-only keywords'").fetchone():
        return 0
    ids = ",".join("?" * len(RAIL_ONLY))
    rows = c.execute(f"SELECT notice_id FROM notice WHERE agency_id IN ({ids}) AND coalesce(relevance,0) < 50 AND reviewed='keywords' "
                     "AND coalesce(notice_type,'') != 'award' AND (closing >= date('now') OR (closing IS NULL AND first_seen >= date('now','-45 days')))",
                     sorted(RAIL_ONLY)).fetchall()
    for r in rows:
        c.execute("UPDATE notice SET kw_score=NULL, reviewed=NULL, notified=coalesce(notified, ?) WHERE notice_id=?", (bc.now(), r["notice_id"]))
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (bc.now(), bc.now(), "rail-only keywords", "done", len(rows), 0, 0, f"{len(rows)} open rail-only agency notices queued for re-scoring"))
    c.commit()
    return len(rows)


def french_rekw(c):
    """Once: re-score French-language notices of known agencies that the English-only keywords left below 50 (921 SEAO awards
    were hidden at 0-15). Notices that now reach 20 go to the Claude review in the normal daily runs, within the daily cap."""
    if c.execute("SELECT 1 FROM run_log WHERE task='french keywords'").fetchone():
        return 0
    rows = c.execute("SELECT notice_id, title, description FROM notice WHERE agency_id IS NOT NULL AND coalesce(relevance,0) < 50 "
                     "AND coalesce(reviewed,'') != 'manual'").fetchall()
    n = 0
    for r in rows:
        text = f"{r['title']} {r['description'] or ''}"
        if len(FRENCH.findall(text.lower())) >= 2:
            c.execute("UPDATE notice SET kw_score=NULL, reviewed=NULL, notified=coalesce(notified, ?) WHERE notice_id=?", (bc.now(), r["notice_id"]))
            n += 1
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (bc.now(), bc.now(), "french keywords", "done", n, 0, 0, f"{n} French notices queued for re-scoring"))
    c.commit()
    return n


def link_awards(c):
    """Awards take relevance, category and subsystems from their award notice (same source, agency and reference)."""
    c.execute("""UPDATE award SET (relevance, category, subsystems, operator_id) = (
                   SELECT n.relevance, coalesce(award.category, n.category), coalesce(award.subsystems, n.subsystems), coalesce(award.operator_id, n.operator_id)
                   FROM notice n WHERE n.notice_type = 'award' AND n.source = award.source AND n.agency_id IS award.agency_id
                     AND n.ref_no IS award.ref_no AND n.title IS award.title AND n.relevance IS NOT NULL ORDER BY n.notice_id LIMIT 1)
                 WHERE EXISTS (SELECT 1 FROM notice n WHERE n.notice_type = 'award' AND n.source = award.source AND n.agency_id IS award.agency_id
                     AND n.ref_no IS award.ref_no AND n.title IS award.title AND n.relevance IS NOT NULL
                     AND (award.relevance IS NOT n.relevance OR award.category IS NULL))""")
    c.commit()
