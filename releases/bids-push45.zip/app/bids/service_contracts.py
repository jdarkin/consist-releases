"""Service contracts from board records (service contracts thread, 11-19): maintenance, overhaul, operations and
maintenance, signal / radio / IT system support and elevator / facility service awards, from the Legistar Web API's
matters (public, no robots.txt), as awards with category maintenance_services or rail_operations so the O&M modules
and the Service contracts market map (relevance >= 50) read them.

Titles do the work where they carry vendor, contract number and amount (LA Metro). Where the title names the vendor
but no amount (BART's Executive Decision Documents), the award is stored without one and its attachment goes to the
Pi reader; the Pi's amount then fills that award (award_portals.pi_consume, note 'award_id=N'). No Claude calls.

fleet_contract (hand-loaded contracts) lives in the site's own database, so the site dedupes on operator + vendor +
start month when it reads these.
"""
import json
import re
import time
import urllib.parse

import bidcore as bc
import sources

# Legistar client -> Bid Catcher agency, and whether every item is rail (else the title must not be bus-only)
CLIENTS = {"metro": ("LAMETRO", False), "bart": ("BART", True), "dart": ("DART", False), "dcta": ("DCTA", False),
           "rideuta": ("UTA", False), "miamidade": ("MDTPW", False)}
COUNTY = {"miamidade": re.compile(r"transit|transportation and public works|dtpw|metrorail|metromover", re.I)}

SERVICE = re.compile(r"\b(maintenance|maintain|repair|overhaul|rebuild|refurbish|o&m|operations? (and|&) maintenance|operat(e|ion|ions|ing) services|"
                     r"support services|inspection services|servicing|janitorial|custodial|cleaning services|landscap\w*|herbicide|"
                     r"vegetation|pest control|elevator|escalator|hvac|fire (alarm|protection|suppression)|security services|"
                     r"software (support|maintenance)|licen[cs]e|hosting|managed services)\b", re.I)
AWARD = re.compile(r"\b(award|execute|enter into|approv\w* .{0,40}(contract|agreement)|modification|change order|exercise|option|amend|increase|extend)\b", re.I)
NOT_SERVICE = re.compile(r"\b(motion by|resolution of (appreciation|recognition)|budget|continuing resolution|legislative|state of good repair grant|"
                         r"public hearing|joint development|lease of (space|property)|construction management|program management|design services|"
                         r"engineering (design )?services|architect\w*|consult\w*|audit\w*|financial advis\w*|legal services|outside counsel|"
                         r"environmental (review|clearance|services)|planning (study|services)|cooperative agreement|funding agreement|"
                         r"memorandum of understanding|mou\b|grant agreement|insurance|bond)\b", re.I)
BUS = re.compile(r"\b(bus(es)?|paratransit|cng|compressed natural gas|vanpool|microtransit|access services|zero[- ]emission bus|bus division)\b", re.I)
RAILISH = re.compile(r"\b(rail|train|subway|metro ?rail|light rail|heavy rail|lrv|hrv|railcar|track|signal|traction|catenary|ocs|"
                     r"station|platform|elevator|escalator|tunnel|scada|cbtc|ptc|wayside|yard|people mover|streetcar|trax|frontrunner|a-train)\b", re.I)
OPS = re.compile(r"\b(operations? (and|&) maintenance|o&m|operat(e|ion|ions|ing) (services|of the)|contract operat\w*|purchased transportation|"
                 r"commuter rail (service|operations)|rail operations|streetcar operations)\b", re.I)
REF = re.compile(r"\b(?:Contract|Agreement|Purchase Order|Task Order|PO)\s+No\.?\s*([A-Z0-9][A-Z0-9\-./]{3,30})", re.I)
TOTAL = re.compile(r"total (?:not[- ]to[- ]exceed |nte )?(?:\(nte\) )?(?:contract )?(?:amount|value|price|cost)? ?(?:of |to )?\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?)", re.I)
AMT = re.compile(r"\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?)")
VENDOR = [re.compile(r"\b(?:to|with|from)\s+([A-Z][\w&.,'’\- ]{2,80}?(?:Inc|LLC|L\.L\.C|Corp|Corporation|Company|Co|Ltd|LP|LLP|JV|Joint Venture|Group|"
                     r"USA|America|Associates|Services|Systems|Technologies|Communications|Solutions|Engineering|Partners)\.?)(?=[,;(]|\s+(?:to|for|in|dba|d/b/a)\b|\.\s|\s*$)"),
          re.compile(r"\b(?:to|with|from)\s+([A-Z][A-Za-z0-9&.'’\-]+(?: [A-Z][A-Za-z0-9&.'’\-]+){0,5})(?=,|\s+(?:to provide|for)\b)")]
PASSED = re.compile(r"pass|adopt|approv|carried|ratif", re.I)


def category(title):
    return "rail_operations" if OPS.search(title) and not re.search(r"fueling|cng", title, re.I) else "maintenance_services"


def vendor(title):
    for rx in VENDOR:
        m = rx.search(title)
        if m:
            v = m.group(1).strip(" ,.-")
            if re.match(r"(contract|agreement|purchase order|task order|modification)\b", v, re.I):
                w = re.split(r"\b(?:with|to)\s+", v)
                v = w[-1].strip(" ,.-") if len(w) > 1 else ""
                v = re.sub(r",?\s+(?:dba|d/b/a)\b.*$", "", v)
            v = re.split(r"\s+for\s+|\s+to\s+provide\b|\s+\(", v)[0].strip(" ,.-")
            if not v or re.match(r"(exercise|provide|continue|increase|extend|incorporate|the)\b", v, re.I):
                continue
            if not re.match(r"(the|a|an|this|staff|board|authority|agency|metro|county|city|district|chief|general)\b", v, re.I) and len(v.split()) <= 12:
                return v
    return None


def _json(url):
    raw, cs, _ = bc.fetch(url, timeout=60)
    return json.loads(raw.decode(cs or "utf-8", "replace"))


def matters(client, since, words=("maintenance", "repair", "overhaul", "services", "operation", "support", "elevator", "escalator")):
    """Matters introduced since `since` whose titles carry a service word (one query per word; Legistar's OData has no OR
    on substringof in every version). Deduped by MatterId."""
    base = f"https://webapi.legistar.com/v1/{client}/matters"
    seen = {}
    for w in words:
        skip = 0
        while True:
            q = urllib.parse.urlencode({"$filter": f"substringof('{w}',MatterTitle) and MatterIntroDate ge datetime'{since}'",
                                        "$orderby": "MatterIntroDate desc", "$top": 1000, "$skip": skip})
            rows = _json(f"{base}?{q}")
            for m in rows:
                seen.setdefault(m["MatterId"], m)
            if len(rows) < 1000:
                break
            skip += 1000
            time.sleep(1.0)
        time.sleep(1.0)
    return list(seen.values())


def _attachment_text(client, mid):
    import award_portals
    for a in _json(f"https://webapi.legistar.com/v1/{client}/matters/{mid}/attachments"):
        u = a.get("MatterAttachmentHyperlink")
        if u and (".pdf" in u.lower() or (a.get("MatterAttachmentName") or "").lower().endswith(".pdf")):
            try:
                text, final, how = award_portals._text(u)
                return text, final
            except Exception as e:
                bc.log(f"service contracts: {u}: {e}")
    return "", None


def ensure(c):
    c.execute("CREATE TABLE IF NOT EXISTS service_matter (client TEXT, matter_id INTEGER, checked TEXT, result TEXT, award_id INTEGER, "
              "PRIMARY KEY (client, matter_id))")


def run(c, clients=None, years=5, pi=True, verbose=False):
    """Reads each client's service-contract matters since `years` ago. Returns {client: (matters, awards added, sent to the Pi)}."""
    import award_portals
    ensure(c)
    award_portals.ensure_queue(c)
    suppliers = sources.supplier_ids()
    since = f"{int(bc.now()[:4]) - years}{bc.now()[4:10]}"
    out = {}
    for client in clients or CLIENTS:
        aid, rail_only = CLIENTS[client]
        try:
            rows = matters(client, since)
        except Exception as e:
            bc.log(f"service contracts {client}: {e}")
            out[client] = (0, 0, 0)
            continue
        added = to_pi = 0
        country = "US"
        for m in rows:
            mid, title = m["MatterId"], re.sub(r"\s+", " ", m.get("MatterTitle") or "").strip()
            if c.execute("SELECT 1 FROM service_matter WHERE client=? AND matter_id=?", (client, mid)).fetchone():
                continue
            res, award_id = "skipped", None
            if re.match(r"\s*withdrawn\b", title, re.I) or re.search(r"withdrawn|failed|tabled", m.get("MatterStatusName") or "", re.I):
                res = "withdrawn"
            elif not (SERVICE.search(title) and AWARD.search(title)) or NOT_SERVICE.search(title):
                res = "not a service contract"
            elif client in COUNTY and not COUNTY[client].search(title):
                res = "not transit"
            elif not rail_only and BUS.search(title) and not RAILISH.search(title):
                res = "bus only"
            else:
                v = vendor(title)
                if not v:
                    res = "no vendor named"
                else:
                    amend = bool(re.search(r"\b(modification|change order|amend|increase|exercise|option|extend)\b", title, re.I)) and not re.search(r"\baward\b", title, re.I)
                    t = TOTAL.search(title)
                    amt = None if amend else float((t or AMT.search(title)).group(1).replace(",", "")) if (t or AMT.search(title)) else None
                    rm = REF.search(title)
                    date = (m.get("MatterPassedDate") or m.get("MatterAgendaDate") or m.get("MatterIntroDate") or "")[:10]
                    passed = bool(PASSED.search(m.get("MatterStatusName") or ""))
                    url = f"https://{client}.legistar.com/LegislationDetail.aspx?ID={mid}&GUID={m.get('MatterGuid')}"
                    a = {"source_key": f"legistar-svc:{client}:{mid}", "source": "board_matter", "agency_id": aid, "country": country,
                         "ref_no": (rm.group(1) if rm else m.get("MatterFile")) or None, "title": title[:500], "vendor": v[:200], "amount": amt,
                         "currency": "USD", "award_date": date or None, "category": category(title),
                         "relevance": 60 if (rail_only or RAILISH.search(title)) else 50, "source_url": url,
                         "confidence": "B" if passed else "C",
                         "notes": ("Modification or option on an existing contract; amount left out so totals are not counted twice. " if amend else "")
                                  + f"Board record {m.get('MatterFile') or mid} ({m.get('MatterStatusName') or 'status unknown'}): {title[:600]}"}
                    if sources.add_award(c, a, suppliers):
                        award_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                        added += 1
                        res = "award"
                        if amt is None and not amend and pi and award_portals.pi_on():
                            text, final = _attachment_text(client, mid)
                            if len(text.strip()) >= 300:
                                did = award_portals._queue(c, aid, final, "pdf", text, 0, 0, "queued")
                                c.execute("UPDATE award_doc SET note=coalesce(note,'') || ? WHERE id=?", (f" award_id={award_id};", did))
                                if award_portals.pi_submit(c, did, text):
                                    to_pi += 1
                                    res = "award, amount from the Pi"
                            time.sleep(1.0)
                    else:
                        res = "already stored"
            c.execute("INSERT OR REPLACE INTO service_matter VALUES (?,?,?,?,?)", (client, mid, bc.now(), res, award_id))
            if verbose and res.startswith("award"):
                print(f"{client} {mid}: {res}: {title[:140]}")
        c.commit()
        out[client] = (len(rows), added, to_pi)
    try:
        import award_portals as ap
        ap.link_refs(c)
    except Exception:
        pass
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (bc.now(), bc.now(), "service contracts", "done", sum(v[0] for v in out.values()), sum(v[1] for v in out.values()), 0.0,
               "; ".join(f"{k}: {v[0]} matters, {v[1]} awards, {v[2]} to the Pi" for k, v in out.items())))
    c.commit()
    return out
