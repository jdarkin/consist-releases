"""Freight locomotive analytics portal: Class I locomotive fleet statistics from STB Form R-1 (fleet.db seed_freight_loco_year) and
operating / financial KPIs from 10-K and annual reports (seed/freight_kpi_year.csv). Every number has a metric definition,
its inputs and a source, so each card and cell on the portal can drill down to the calculation behind it."""
import csv
import functools
import html
import json
import os
import statistics

from . import lens
from .intel import _rows

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "freight_kpi_year.csv")
R1_URL = "https://www.stb.gov/reports-data/economic-data/annual-report-financial-data/"

# Class I railroads in display order: operator_id -> (short label, R-1 coverage note, home country)
RAILROADS = {
    "BNSF": ("BNSF", "BNSF Railway", "US"),
    "UNION_PACIFIC": ("UP", "Union Pacific Railroad", "US"),
    "CSX": ("CSX", "CSX Transportation", "US"),
    "NORFOLK_SOUTHERN": ("NS", "Norfolk Southern Railway", "US"),
    "CN_RAIL": ("CN", "CN US lines (Grand Trunk Corp.)", "CA"),
    "CPKC": ("CPKC", "CPKC US lines (Soo Line, plus KCSR)", "CA"),
}
COLORS = ["var(--c1)", "var(--c2)", "var(--c3)", "var(--c4)", "var(--c5)", "var(--c6, #7d5ba6)"]

# R-1 columns that add across reporting entities (CPKC files Soo Line and KCSR separately until 2023)
ADD = ["units_begin", "units_end", "units_owned", "units_leased", "units_new", "units_rebuilt_in", "units_retired", "freight_units",
       "multipurpose_units", "switching_units", "units_aux", "total_hp", "loco_unit_miles", "loco_unit_miles_road",
       "loco_unit_miles_train_switch", "loco_unit_miles_yard", "train_miles", "train_hours_road", "yard_switching_hours",
       "gross_ton_miles_k", "revenue_ton_miles_k", "miles_of_road", "fuel_gal", "fuel_cost_usd", "loco_repairs_usd",
       "loco_depreciation_usd", "loco_lease_rent_usd", "loco_investment_usd", "loco_accum_dep_usd", "new_units_710S",
       "new_cost_usd_710S", "rebuilt_units_710S", "rebuilt_cost_usd_710S"]

# Raw inputs: label and where they come from
INPUTS = {
    "units_end": ("Locomotives in service, year end", "R-1 Sched. 710, diesel units in service"),
    "units_begin": ("Locomotives in service, start of year", "R-1 Sched. 710"),
    "units_owned": ("Owned units", "R-1 Sched. 710"), "units_leased": ("Leased units", "R-1 Sched. 710"),
    "units_new": ("New units added", "R-1 Sched. 710 (new owned + new leased)"),
    "units_rebuilt_in": ("Rebuilt units returned to service", "R-1 Sched. 710"),
    "units_retired": ("Units retired", "R-1 Sched. 710"),
    "switching_units": ("Switching units", "R-1 Sched. 710"),
    "total_hp": ("Total horsepower", "R-1 Sched. 710"),
    "avg_age_est": ("Average age (estimated from build-year bins)", "R-1 Sched. 710 build-year columns"),
    "loco_unit_miles": ("Locomotive unit-miles", "R-1 Sched. 755"),
    "loco_unit_miles_road": ("Road locomotive unit-miles", "R-1 Sched. 755"),
    "train_miles": ("Train-miles", "R-1 Sched. 755"),
    "train_hours_road": ("Road train-hours", "R-1 Sched. 755"),
    "gross_ton_miles_k": ("Gross ton-miles (thousands)", "R-1 Sched. 755"),
    "fuel_gal": ("Diesel fuel, gallons", "R-1 Sched. 750"),
    "fuel_cost_usd": ("Diesel fuel cost", "R-1 Sched. 750"),
    "loco_repairs_usd": ("Locomotive repairs", "R-1 Sched. 410/415, locomotives"),
    "loco_depreciation_usd": ("Locomotive depreciation", "R-1 Sched. 415, locomotives"),
    "loco_lease_rent_usd": ("Locomotive lease rentals", "R-1 Sched. 415, locomotives"),
    "loco_investment_usd": ("Gross investment in locomotives", "R-1 Sched. 415"),
    "loco_accum_dep_usd": ("Accumulated depreciation, locomotives", "R-1 Sched. 415"),
    "new_units_710S": ("New units acquired", "R-1 Sched. 710S"), "new_cost_usd_710S": ("Cost of new units", "R-1 Sched. 710S"),
    "rebuilt_units_710S": ("Units rebuilt", "R-1 Sched. 710S"), "rebuilt_cost_usd_710S": ("Cost of rebuilt units", "R-1 Sched. 710S"),
    "cpi_to_2025": ("CPI-U factor to 2025 dollars", "BLS CPI-U annual average"),
    "avg_units": ("Average units in service", "(start + end of year) / 2, R-1 Sched. 710"),
    "opex_m": ("Operating expenses, company (millions)", "10-K / annual report"),
    "loco_cost_nominal": ("Locomotive repairs + depreciation + lease + fuel", "R-1 Sched. 415 and 750"),
}


def _f(v):
    try:
        return float(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _div(a, b):
    return a / b if a is not None and b else None


def _avg_units(r):
    b, e = r.get("units_begin"), r.get("units_end")
    return (b + e) / 2 if b and e else e


def _real(r, v):
    """2025 dollars: CPI-U by default, or railroad input prices (RCAF) when the rail portal's dollar switch is on rail-cost dollars."""
    if v is None:
        return v
    from . import costidx
    y = r.get("report_year") or r.get("year")
    if costidx.basis() == "rcaf" and y:
        f = costidx.deflator(int(y))
        if f:
            return v * f
    return v * r["cpi_to_2025"] if r.get("cpi_to_2025") else v


def _loco_cost(r):
    parts = [r.get(k) for k in ("loco_repairs_usd", "loco_depreciation_usd", "loco_lease_rent_usd", "fuel_cost_usd")]
    return sum(p for p in parts if p) if parts[0] else None


# ---------- metric registry ----------
# key: label, unit, format, group, better (low/high/None), source (r1/kpi), definition, inputs, fn(r1 row, kpi dict)
M = {}


def metric(key, label, unit, fmt, group, better, src, definition, inputs=(), fn=None, kpi=None):
    M[key] = dict(key=key, label=label, unit=unit, fmt=fmt, group=group, better=better, src=src, definition=definition,
                  inputs=list(inputs), fn=fn, kpi=kpi)


G_FLEET, G_USE, G_FUEL, G_COST, G_RENEW, G_OPS, G_FIN = ("Fleet", "Utilization", "Fuel", "Locomotive cost", "Renewal",
                                                         "Network operations", "Financial")
metric("units", "Locomotives in service", "units", "int", G_FLEET, None, "r1", "Diesel locomotive units in service at year end.",
       ["units_end"], lambda r, k: r.get("units_end"))
metric("avg_age", "Average age", "years", "1", G_FLEET, "low", "r1",
       "Unit-weighted average age, estimated from the Sched. 710 build-year columns (the oldest bin is open ended, so this is an estimate).",
       ["avg_age_est"], lambda r, k: r.get("avg_age_est"))
metric("hp_per_unit", "Horsepower per unit", "hp", "int", G_FLEET, None, "r1", "Total horsepower / units in service.",
       ["total_hp", "units_end"], lambda r, k: _div(r.get("total_hp"), r.get("units_end")))
metric("share_leased", "Share leased", "%", "pct1", G_FLEET, None, "r1", "Leased units / (owned + leased units).",
       ["units_leased", "units_owned"], lambda r, k: _div(100 * (r.get("units_leased") or 0), (r.get("units_owned") or 0) + (r.get("units_leased") or 0)))
metric("share_switching", "Share switchers", "%", "pct1", G_FLEET, None, "r1", "Switching units / units in service.",
       ["switching_units", "units_end"], lambda r, k: _div(100 * (r.get("switching_units") or 0), r.get("units_end")))
metric("miles_per_unit", "Miles per locomotive", "mi/yr", "int", G_USE, "high", "r1",
       "Locomotive unit-miles / average units in service. The basic duty-cycle measure.",
       ["loco_unit_miles", "avg_units"], lambda r, k: _div(r.get("loco_unit_miles"), _avg_units(r)))
metric("miles_per_unit_day", "Miles per locomotive-day", "mi/day", "int", G_USE, "high", "r1", "Miles per locomotive / 365.",
       ["loco_unit_miles", "avg_units"], lambda r, k: _div(_div(r.get("loco_unit_miles"), _avg_units(r)), 365))
metric("gtm_per_hp_day", "GTMs per horsepower-day", "GTM/hp-day", "int", G_USE, "high", "r1",
       "Gross ton-miles / total horsepower / 365, the industry's locomotive productivity measure computed the same way for every railroad.",
       ["gross_ton_miles_k", "total_hp"], lambda r, k: _div(_div((r.get("gross_ton_miles_k") or 0) * 1000, r.get("total_hp")), 365))
metric("mgtm_per_unit", "Million GTMs per locomotive", "m GTM", "1", G_USE, "high", "r1", "Gross ton-miles / average units in service.",
       ["gross_ton_miles_k", "avg_units"], lambda r, k: _div((r.get("gross_ton_miles_k") or 0) / 1000, _avg_units(r)))
metric("locos_per_train", "Locomotives per train", "units", "2", G_USE, None, "r1", "Road locomotive unit-miles / train-miles.",
       ["loco_unit_miles_road", "train_miles"], lambda r, k: _div(r.get("loco_unit_miles_road"), r.get("train_miles")))
metric("r1_train_speed", "Road train speed (R-1)", "mph", "1", G_USE, "high", "r1",
       "Train-miles / road train-hours: an average road speed computed the same way for every railroad (includes time stopped en route).",
       ["train_miles", "train_hours_road"], lambda r, k: _div(r.get("train_miles"), r.get("train_hours_road")))
metric("fuel_gal_per_kgtm", "Fuel per 1,000 GTMs", "gal", "3", G_FUEL, "low", "r1", "Diesel gallons / thousand gross ton-miles.",
       ["fuel_gal", "gross_ton_miles_k"], lambda r, k: _div(r.get("fuel_gal"), r.get("gross_ton_miles_k")))
metric("fuel_gal_per_unit_mile", "Fuel per unit-mile", "gal", "2", G_FUEL, "low", "r1", "Diesel gallons / locomotive unit-miles.",
       ["fuel_gal", "loco_unit_miles"], lambda r, k: _div(r.get("fuel_gal"), r.get("loco_unit_miles")))
metric("fuel_price", "Fuel price paid", "$/gal", "usd2", G_FUEL, None, "r1", "Fuel cost / gallons, nominal dollars.",
       ["fuel_cost_usd", "fuel_gal"], lambda r, k: _div(r.get("fuel_cost_usd"), r.get("fuel_gal")))
metric("repairs_per_unit_mile", "Repairs per unit-mile", "2025 $", "usd2", G_COST, "low", "r1",
       "Locomotive repairs / unit-miles, restated to 2025 dollars.",
       ["loco_repairs_usd", "loco_unit_miles", "cpi_to_2025"], lambda r, k: _real(r, _div(r.get("loco_repairs_usd"), r.get("loco_unit_miles"))))
metric("repairs_per_unit_year", "Repairs per locomotive-year", "2025 $", "usd", G_COST, "low", "r1",
       "Locomotive repairs / average units in service, 2025 dollars.",
       ["loco_repairs_usd", "avg_units", "cpi_to_2025"], lambda r, k: _real(r, _div(r.get("loco_repairs_usd"), _avg_units(r))))
metric("ownership_per_unit_mile", "Ownership per unit-mile", "2025 $", "usd2", G_COST, "low", "r1",
       "(Depreciation + lease rentals) / unit-miles, 2025 dollars.",
       ["loco_depreciation_usd", "loco_lease_rent_usd", "loco_unit_miles", "cpi_to_2025"],
       lambda r, k: _real(r, _div((r.get("loco_depreciation_usd") or 0) + (r.get("loco_lease_rent_usd") or 0), r.get("loco_unit_miles"))))
metric("fuel_per_unit_mile", "Fuel cost per unit-mile", "2025 $", "usd2", G_COST, "low", "r1", "Fuel cost / unit-miles, 2025 dollars.",
       ["fuel_cost_usd", "loco_unit_miles", "cpi_to_2025"], lambda r, k: _real(r, _div(r.get("fuel_cost_usd"), r.get("loco_unit_miles"))))
metric("cost_per_unit_mile", "All-in cost per unit-mile", "2025 $", "usd2", G_COST, "low", "r1",
       "(Repairs + depreciation + lease rentals + fuel) / unit-miles, 2025 dollars.",
       ["loco_repairs_usd", "loco_depreciation_usd", "loco_lease_rent_usd", "fuel_cost_usd", "loco_cost_nominal", "loco_unit_miles", "cpi_to_2025"], lambda r, k: _real(r, _div(_loco_cost(r), r.get("loco_unit_miles"))))
metric("cost_per_kgtm", "Locomotive cost per 1,000 GTMs", "2025 $", "usd2", G_COST, "low", "r1",
       "(Repairs + depreciation + lease rentals + fuel) / thousand gross ton-miles, 2025 dollars.",
       ["loco_repairs_usd", "loco_depreciation_usd", "loco_lease_rent_usd", "fuel_cost_usd", "loco_cost_nominal", "gross_ton_miles_k", "cpi_to_2025"], lambda r, k: _real(r, _div(_loco_cost(r), r.get("gross_ton_miles_k"))))
metric("repairs_per_kgtm", "Repairs per 1,000 GTMs", "2025 $", "usd3", G_COST, "low", "r1", "Locomotive repairs / thousand GTMs, 2025 dollars.",
       ["loco_repairs_usd", "gross_ton_miles_k", "cpi_to_2025"], lambda r, k: _real(r, _div(r.get("loco_repairs_usd"), r.get("gross_ton_miles_k"))))
metric("loco_share_opex", "Locomotive cost share of opex", "%", "pct1", G_COST, "low", "r1",
       "R-1 locomotive repairs + depreciation + lease + fuel / company operating expenses (10-K). US-only railroads.",
       ["loco_repairs_usd", "loco_depreciation_usd", "loco_lease_rent_usd", "fuel_cost_usd", "loco_cost_nominal", "opex_m"],
       lambda r, k: _div(100 * (_loco_cost(r) or 0), (k.get("opex_m") or 0) * 1e6) if r.get("operator_id") in ("BNSF", "UNION_PACIFIC", "CSX", "NORFOLK_SOUTHERN") and _loco_cost(r) else None)
metric("pct_depreciated", "Fleet book value used up", "%", "pct1", G_COST, None, "r1",
       "Accumulated depreciation / gross investment in locomotives: how far through its book life the fleet is.",
       ["loco_accum_dep_usd", "loco_investment_usd"], lambda r, k: _div(100 * (r.get("loco_accum_dep_usd") or 0), r.get("loco_investment_usd")))
metric("retired_units", "Locomotives retired", "units", "int", G_RENEW, None, "r1",
       "Units retired during the year (Sched. 710). Includes units sold, scrapped or traded in; stored units still on the books are not retired.",
       ["units_retired"], lambda r, k: r.get("units_retired"))
metric("rebuilt_units", "Locomotives rebuilt or overhauled", "units", "int", G_RENEW, None, "r1",
       "Units capitalized as rebuilt during the year (Sched. 710S): heavy overhauls, modernizations and DC-to-AC conversions. "
       "Running repairs and routine overhauls charged to expense are not counted here; they sit in locomotive repairs.",
       ["rebuilt_units_710S"], lambda r, k: r.get("rebuilt_units_710S"))
metric("new_units", "New locomotives acquired", "units", "int", G_RENEW, None, "r1", "New units acquired during the year (Sched. 710S, falling back to Sched. 710).",
       ["new_units_710S", "units_new"], lambda r, k: r.get("new_units_710S") if r.get("new_units_710S") is not None else r.get("units_new"))
metric("net_change", "Net fleet change", "units", "int", G_RENEW, None, "r1", "Units in service at year end minus at start of year (Sched. 710).",
       ["units_end", "units_begin"], lambda r, k: (r.get("units_end") - r.get("units_begin")) if r.get("units_end") is not None and r.get("units_begin") is not None else None)
metric("rebuild_spend", "Spending on rebuilds", "2025 $", "usd", G_RENEW, None, "r1", "Sched. 710S cost of rebuilt units, 2025 dollars.",
       ["rebuilt_cost_usd_710S", "cpi_to_2025"], lambda r, k: _real(r, r.get("rebuilt_cost_usd_710S")))
metric("new_rate", "New units, % of fleet", "%/yr", "pct1", G_RENEW, None, "r1", "New units added / average units in service.",
       ["units_new", "avg_units"], lambda r, k: _div(100 * (r.get("units_new") or 0), _avg_units(r)))
metric("rebuild_rate", "Rebuilt units, % of fleet", "%/yr", "pct1", G_RENEW, None, "r1", "Units rebuilt (Sched. 710S) / average units in service.",
       ["rebuilt_units_710S", "avg_units"], lambda r, k: _div(100 * (r.get("rebuilt_units_710S") or 0), _avg_units(r)))
metric("retire_rate", "Retirements, % of fleet", "%/yr", "pct1", G_RENEW, None, "r1", "Units retired / average units in service.",
       ["units_retired", "avg_units"], lambda r, k: _div(100 * (r.get("units_retired") or 0), _avg_units(r)))
metric("renewal_cycle", "Implied renewal cycle", "years", "int", G_RENEW, None, "r1",
       "Average units / (new + rebuilt units in the year): years it would take to renew the whole fleet at this year's pace.",
       ["avg_units", "new_units_710S", "rebuilt_units_710S"],
       lambda r, k: _div(_avg_units(r), (r.get("new_units_710S") or 0) + (r.get("rebuilt_units_710S") or 0)))
metric("new_cost_per_unit", "Cost per new locomotive", "2025 $", "usd", G_RENEW, None, "r1", "Sched. 710S cost of new units / new units, 2025 dollars.",
       ["new_cost_usd_710S", "new_units_710S", "cpi_to_2025"], lambda r, k: _real(r, _div(r.get("new_cost_usd_710S"), r.get("new_units_710S"))))
metric("rebuild_cost_per_unit", "Cost per rebuilt locomotive", "2025 $", "usd", G_RENEW, None, "r1",
       "Sched. 710S cost of rebuilt units / rebuilt units, 2025 dollars.",
       ["rebuilt_cost_usd_710S", "rebuilt_units_710S", "cpi_to_2025"], lambda r, k: _real(r, _div(r.get("rebuilt_cost_usd_710S"), r.get("rebuilt_units_710S"))))
metric("rebuild_to_new", "Rebuild cost as % of new", "%", "pct1", G_RENEW, None, "r1", "Cost per rebuilt unit / cost per new unit, same railroad and year.",
       ["rebuilt_cost_usd_710S", "rebuilt_units_710S", "new_cost_usd_710S", "new_units_710S"],
       lambda r, k: _div(100 * (_div(r.get("rebuilt_cost_usd_710S"), r.get("rebuilt_units_710S")) or 0), _div(r.get("new_cost_usd_710S"), r.get("new_units_710S"))) if r.get("rebuilt_units_710S") else None)

KPI_DEFS = [
    ("operating_ratio_pct", "Operating ratio", "%", "1", G_FIN, "low", "Operating expenses / operating revenue, as reported (derived from the statements where a filing doesn't print it)."),
    ("revenue_m", "Operating revenue", "m", "cur", G_FIN, None, "Total operating revenues, company-wide, reporting currency."),
    ("op_income_m", "Operating income", "m", "cur", G_FIN, "high", "Operating income, company-wide, reporting currency."),
    ("fuel_expense_m", "Fuel expense", "m", "cur", G_FIN, None, "Fuel expense on the income statement, reporting currency."),
    ("capex_total_m", "Capital spending", "m", "cur", G_FIN, None, "Cash capital investment / property additions."),
    ("capex_loco_m", "Locomotive capital spending", "m", "cur", G_FIN, None, "Locomotive line of the capital program (CSX reports it separately)."),
    ("capex_loco_and_cars_m", "Locomotive and freight car capital", "m", "cur", G_FIN, None, "UP reports locomotives and freight cars as one capital line."),
    ("capex_equipment_bnsf_m", "Equipment acquisitions", "m", "cur", G_FIN, None, "BNSF cash flow line 'acquisition of equipment' (locomotives, cars and other)."),
    ("train_speed_mph", "Train speed (reported)", "mph", "1", G_OPS, "high", "Railroad's own train speed / velocity measure; definitions differ by railroad (CN: through network train speed)."),
    ("terminal_dwell_hrs", "Terminal dwell", "hours", "1", G_OPS, "low", "Average hours a car spends in terminals (CN: through dwell). Definitions differ by railroad."),
    ("car_velocity_mpd", "Car velocity", "mi/car/day", "int", G_OPS, "high", "Average daily miles per car."),
    ("cars_online", "Cars online", "cars", "int", G_OPS, "low", "Average cars on the network (CSX)."),
    ("train_length_ft", "Train length", "feet", "int", G_OPS, "high", "Average train length."),
    ("train_weight_tons", "Train weight", "tons", "int", G_OPS, "high", "Average train weight (CN)."),
    ("loco_productivity_rep", "Locomotive productivity (reported)", "as reported", "int", G_OPS, "high",
     "As each railroad defines it: UP GTMs per horsepower-day; CN trailing GTMs per total horsepower; CP GTMs per operating horsepower. Not comparable across railroads; use GTMs per horsepower-day (R-1) to compare."),
    ("fuel_eff_gal_per_kgtm", "Fuel efficiency (reported)", "gal/1,000 GTM", "3", G_OPS, "low", "Railroad-reported gallons per 1,000 GTMs, whole network."),
    ("gtm_bn", "Gross ton-miles (reported)", "billions", "1", G_OPS, None, "Company-wide gross ton-miles."),
    ("rtm_bn", "Revenue ton-miles (reported)", "billions", "1", G_OPS, None, "Company-wide revenue ton-miles."),
    ("employees_avg", "Employees, average", "people", "int", G_OPS, None, "Average employees for the year."),
    ("on_time_originations_pct", "On-time originations", "%", "int", G_OPS, "high", "Share of trains departing on time (CSX)."),
    ("on_time_arrivals_pct", "On-time arrivals", "%", "int", G_OPS, "high", "Share of trains arriving on time (CSX)."),
]
for key, label, unit, fmt, group, better, definition in KPI_DEFS:
    metric(key, label, unit, fmt, group, better, "kpi", definition, kpi=key, fn=lambda r, k, _key=key: k.get(_key))

GROUPS = [G_FLEET, G_USE, G_FUEL, G_COST, G_RENEW, G_OPS, G_FIN]
SCORE = ["units", "avg_age", "hp_per_unit", "miles_per_unit", "gtm_per_hp_day", "fuel_gal_per_kgtm", "repairs_per_unit_mile",
         "cost_per_unit_mile", "cost_per_kgtm", "renewal_cycle", "operating_ratio_pct", "train_speed_mph", "terminal_dwell_hrs"]


def fmt(key, v, cur="USD"):
    if v is None:
        return "—"
    f = M[key]["fmt"] if key in M else "1"
    sym = "C$" if cur == "CAD" else "$"
    if f == "int":
        return f"{v:,.0f}"
    if f in ("1", "2", "3"):
        return f"{v:,.{int(f)}f}"
    if f == "pct1":
        return f"{v:.1f}%"
    if f == "usd":
        return f"${v / 1e6:.2f}M" if abs(v) >= 1e6 else f"${v:,.0f}"
    if f == "usd2":
        return f"${v:,.2f}"
    if f == "usd3":
        return f"${v:,.3f}"
    if f == "cur":
        return f"{sym}{v / 1000:,.1f}B" if abs(v) >= 1000 else f"{sym}{v:,.0f}M"
    return f"{v}"


# ---------- data ----------

@functools.lru_cache(maxsize=1)
def _kpi_file(mtime):
    out = {}
    try:
        for r in csv.DictReader(open(SEED)):
            out.setdefault((r["operator_id"], int(r["report_year"])), {})[r["metric"]] = _f(r["value"])
            out[(r["operator_id"], int(r["report_year"]))].setdefault("_src", {})[r["metric"]] = (r["source_doc"], r["source_url"], r["currency"], r["unit"])
    except OSError:
        pass
    return out


def kpis():
    """(operator_id, year) -> {metric: value, '_src': {metric: (doc, url, currency, unit)}}. Includes R-1 build-year bins (r1_built_*)."""
    try:
        m = os.path.getmtime(SEED)
    except OSError:
        return {}
    return _kpi_file(m)


def _r1_rows():
    return _rows("SELECT * FROM seed_freight_loco_year ORDER BY operator_id, report_year, r1_entity")


def railroad_years():
    """(operator_id, year) -> R-1 row summed across reporting entities, with 'entities' and 'sources' kept for drill-down."""
    out = {}
    for raw in _r1_rows():
        k = (raw["operator_id"], raw["report_year"])
        r = out.get(k)
        if r is None:
            r = out[k] = {"operator_id": raw["operator_id"], "report_year": raw["report_year"], "entities": [], "sources": [],
                          "cpi_to_2025": _f(raw.get("cpi_to_2025")), "_age_w": 0.0, "_age_n": 0.0, "rebuild_detail": []}
            for c in ADD:
                r[c] = None
        r["entities"].append(raw.get("entity_name") or raw.get("r1_entity"))
        if raw.get("source_files"):
            r["sources"].append((raw.get("r1_entity"), raw.get("source_files"), raw.get("source_url") or R1_URL))
        for c in ADD:
            v = _f(raw.get(c))
            if v is not None:
                r[c] = (r[c] or 0) + v
        a, u = _f(raw.get("avg_age_est")), _f(raw.get("units_end"))
        if a and u:
            r["_age_w"] += a * u
            r["_age_n"] += u
        try:
            r["rebuild_detail"] += [dict(entity=raw.get("r1_entity"), kind=d[0], line=d[1], desc=d[2], units=d[3], cost_k=d[4])
                                    for d in json.loads(raw.get("rebuild_detail_710S") or "[]")]
        except (ValueError, TypeError, IndexError):
            pass
    for r in out.values():
        r["avg_age_est"] = r["_age_w"] / r["_age_n"] if r["_age_n"] else None
        r["avg_units"] = _avg_units(r)
        r["loco_cost_nominal"] = _loco_cost(r)
    return out


def scope_ids():
    """Class I railroads in the viewer's lens and region. Empty when the lens excludes freight."""
    sc = lens.current()
    if sc.modes and "FR" not in sc.modes:
        return []
    ids = list(RAILROADS)
    if sc.regions:
        # R-1 figures are US operations, so CN and CPKC US lines show under US as well as Canada
        ids = [o for o in ids if RAILROADS[o][2] in sc.regions or "US" in sc.regions]
    return ids


class Cube:
    """All metric values: v(metric, operator_id, year). Built once per request."""

    def __init__(self):
        self.r1 = railroad_years()
        self.k = kpis()
        self.ids = scope_ids()
        ys = {y for (_, y) in self.r1} | {y for (_, y) in self.k}
        self.years = sorted(ys)
        self.r1_years = sorted({y for (_, y) in self.r1})
        self.latest = max(self.r1_years) if self.r1_years else (max(self.years) if self.years else None)
        self._c = {}

    def v(self, key, op, y):
        ck = (key, op, y)
        if ck not in self._c:
            m = M[key]
            r = self.r1.get((op, y))
            k = self.k.get((op, y), {})
            if m["src"] == "r1" and r is None:
                val = None
            else:
                try:
                    val = m["fn"](r or {"operator_id": op}, {**k, "operator_id": op})
                except (TypeError, ZeroDivisionError):
                    val = None
            self._c[ck] = val
        return self._c[ck]

    def currency(self, key, op, y):
        src = self.k.get((op, y), {}).get("_src", {}).get(key)
        return (src[2] if src and src[2] else "USD") if M[key]["src"] == "kpi" else "USD"

    def show(self, key, op, y):
        return fmt(key, self.v(key, op, y), self.currency(key, op, y))

    def series(self, key, ops=None):
        return [(RAILROADS[o][0], [(y, self.v(key, o, y)) for y in self.years]) for o in (ops or self.ids)]

    def has(self, key):
        return any(self.v(key, o, y) is not None for o in self.ids for y in self.years)

    def peer_median(self, key, y):
        vals = [self.v(key, o, y) for o in self.ids]
        vals = [x for x in vals if x is not None]
        return statistics.median(vals) if vals else None

    def rank(self, key, op, y):
        """1 = best (per the metric's 'better' direction), else by size. Returns (rank, n)."""
        vals = [(o, self.v(key, o, y)) for o in self.ids]
        vals = [(o, x) for o, x in vals if x is not None]
        if not any(o == op for o, _ in vals):
            return None, len(vals)
        rev = M[key]["better"] != "low"
        order = [o for o, _ in sorted(vals, key=lambda t: t[1], reverse=rev)]
        return order.index(op) + 1, len(vals)

    def last_year(self, key, op):
        for y in reversed(self.years):
            if self.v(key, op, y) is not None:
                return y
        return None

    def change(self, key, op, y0, y1):
        a, b = self.v(key, op, y0), self.v(key, op, y1)
        return 100 * (b - a) / abs(a) if a and b is not None else None

    def cagr(self, key, op):
        ys = [y for y in self.years if self.v(key, op, y) not in (None, 0)]
        if len(ys) < 2:
            return None
        a, b = self.v(key, op, ys[0]), self.v(key, op, ys[-1])
        if a <= 0 or b <= 0:
            return None
        return 100 * ((b / a) ** (1 / (ys[-1] - ys[0])) - 1), ys[0], ys[-1]

    def inputs(self, key, op, y):
        """The raw inputs behind one value, for the drill-down: [(label, value, source)]."""
        m = M[key]
        if m["src"] == "kpi":
            src = self.k.get((op, y), {}).get("_src", {}).get(key)
            return [(m["label"], self.v(key, op, y), src[0] if src else "", src[1] if src else "")]
        r = self.r1.get((op, y)) or {}
        out = []
        for inp in m["inputs"]:
            if inp == "opex_m":
                src = self.k.get((op, y), {}).get("_src", {}).get("opex_m")
                out.append((INPUTS[inp][0], self.k.get((op, y), {}).get("opex_m"), src[0] if src else "10-K", src[1] if src else ""))
            else:
                out.append((INPUTS.get(inp, (inp, ""))[0], r.get(inp), INPUTS.get(inp, ("", "R-1"))[1], R1_URL))
        return out

    def build_mix(self, op, y):
        """[(label, units)] from the R-1 Sched. 710 build-year bins, oldest first."""
        k = self.k.get((op, y), {})
        bins = []
        for key, v in k.items():
            if key.startswith("r1_built_") and v is not None:
                lo, hi = key[9:].split("_")
                bins.append(((0 if lo == "pre" else int(lo)), f"before {int(hi) + 1}" if lo == "pre" else (lo if lo == hi else f"{lo}–{hi}"), v))
        bins.sort()
        # single build years after the 5-year bins get folded into one 'recent' bar
        out, recent = [], 0
        for lo, label, v in bins:
            if "–" in label or label.startswith("before"):
                out.append((label, v))
            else:
                recent += v
        if recent or any(lo and "–" not in lab and not lab.startswith("before") for lo, lab, _ in bins):
            singles = [lab for lo, lab, _ in bins if lo and "–" not in lab and not lab.startswith("before")]
            out.append((f"{singles[0]}–{singles[-1]}" if len(singles) > 1 else singles[0], recent))
        return out


# ---------- views ----------

def link(key, op=None, y=None):
    q = [f"rr={op}"] if op else []
    if y:
        q.append(f"y={y}")
    return f"{base()}/metric/{key}" + ("?" + "&".join(q) if q else "")


def base():
    """/rail/locomotives inside the rail portal, else /app/freight (parked, admins only)."""
    from . import lens
    return "/rail/locomotives" if lens.in_rail() else "/app/freight"


def scoreboard(c, y):
    rows = []
    for o in c.ids:
        cells = []
        for key in SCORE:
            yy = y if c.v(key, o, y) is not None else c.last_year(key, o)
            val = c.v(key, o, yy) if yy else None
            rk, n = c.rank(key, o, yy) if yy else (None, 0)
            cells.append(dict(key=key, v=val, show=c.show(key, o, yy) if yy else "—", y=yy, stale=yy != y, rank=rk, n=n, href=link(key, o, yy)))
        rows.append(dict(op=o, label=RAILROADS[o][0], name=RAILROADS[o][1], cells=cells))
    med = [dict(key=k, show=fmt(k, c.peer_median(k, y)), href=link(k, y=y)) for k in SCORE]
    return rows, med


def tiles(c, y, op=None):
    """Headline tiles for the portal home (op None: all Class I) or one railroad. Each tile links to its drill-down."""
    ids = [op] if op else c.ids
    out = []

    def tot(key):
        vals = [c.v(key, o, y) for o in ids]
        vals = [v for v in vals if v is not None]
        return sum(vals) if vals else None
    if op:
        for key in ("units", "avg_age", "miles_per_unit", "gtm_per_hp_day", "cost_per_unit_mile", "operating_ratio_pct"):
            yy = y if c.v(key, op, y) is not None else c.last_year(key, op)
            rk, n = c.rank(key, op, yy) if yy else (None, 0)
            med = c.peer_median(key, yy) if yy else None
            out.append(dict(label=M[key]["label"], show=c.show(key, op, yy) if yy else "—",
                            sub=(f"#{rk} of {n} · peer median {fmt(key, med, c.currency(key, op, yy))}" if rk else "") + (f" · {yy}" if yy and yy != y else ""),
                            href=link(key, op, yy)))
        return out
    units = tot("units")
    out.append(dict(label="Class I locomotives (US, R-1)", show=f"{units:,.0f}" if units else "—", sub=f"{len(ids)} railroads, {y}", href=link("units", y=y)))
    for key in ("avg_age", "miles_per_unit", "gtm_per_hp_day", "fuel_gal_per_kgtm", "cost_per_unit_mile"):
        med = c.peer_median(key, y)
        lo = min(((c.v(key, o, y), o) for o in ids if c.v(key, o, y) is not None), default=(None, None))
        hi = max(((c.v(key, o, y), o) for o in ids if c.v(key, o, y) is not None), default=(None, None))
        out.append(dict(label=M[key]["label"] + " (median)", show=fmt(key, med),
                        sub=f"range {fmt(key, lo[0])} {RAILROADS[lo[1]][0] if lo[1] else ''} to {fmt(key, hi[0])} {RAILROADS[hi[1]][0] if hi[1] else ''}",
                        href=link(key, y=y)))
    return out


def profile(c, op, y):
    """Sections of metrics for one railroad: [(group, [cell])], each cell with latest value, peer median, rank, trend and link."""
    first = c.r1_years[0] if c.r1_years else None
    groups = []
    for g in GROUPS:
        cells = []
        for key, m in M.items():
            if m["group"] != g:
                continue
            yy = y if c.v(key, op, y) is not None else c.last_year(key, op)
            if yy is None:
                continue
            rk, n = c.rank(key, op, yy)
            med = c.peer_median(key, yy)
            v = c.v(key, op, yy)
            vs = 100 * (v - med) / abs(med) if med and v is not None and n > 1 else None
            ys = [yr for yr in c.years if c.v(key, op, yr) is not None]
            y0 = first if first in ys else (ys[0] if ys else None)
            cells.append(dict(key=key, label=m["label"], unit=m["unit"], show=c.show(key, op, yy), y=yy, rank=rk, n=n,
                              med=fmt(key, med, c.currency(key, op, yy)) if n > 1 else "—", vs=vs, better=m["better"],
                              chg=c.change(key, op, y0, yy) if y0 and y0 != yy else None, y0=y0,
                              spark=[(yr, c.v(key, op, yr)) for yr in ys], href=link(key, op, yy)))
        if cells:
            groups.append((g, cells))
    return groups


def renewal(c, op):
    """Per-year fleet churn: new, rebuilt, retired units for stacked bars, and the 710S detail lines."""
    years = {}
    for y in c.r1_years:
        r = c.r1.get((op, y))
        if r:
            years[y] = {"new": r.get("new_units_710S") or r.get("units_new") or 0, "rebuilt": r.get("rebuilt_units_710S") or 0, "retired": r.get("units_retired") or 0}
    return years


RENEW_KEYS = ["units", "new_units", "rebuilt_units", "retired_units", "net_change", "retire_rate", "rebuild_rate", "rebuild_cost_per_unit", "avg_age"]
SUM_KEYS = {"units", "new_units", "rebuilt_units", "retired_units", "net_change", "rebuild_spend"}


def class1_totals(c):
    """All Class I railroads in scope, by year: unit counts summed, rates recomputed from the sums (not averaged)."""
    out = []
    for y in c.r1_years:
        rs = [c.r1.get((o, y)) for o in c.ids]
        rs = [r for r in rs if r]
        if not rs:
            continue
        tot = {k: sum((c.v(k, o, y) or 0) for o in c.ids if c.r1.get((o, y))) for k in SUM_KEYS}
        avg = sum((_avg_units(r) or 0) for r in rs)
        reb_cost = sum((r.get("rebuilt_cost_usd_710S") or 0) for r in rs)
        reb_n = sum((r.get("rebuilt_units_710S") or 0) for r in rs)
        cpi = _real(rs[0], 1.0) or 1
        tot.update(y=y, n_rr=len(rs), retire_rate=_div(100 * tot["retired_units"], avg), rebuild_rate=_div(100 * tot["rebuilt_units"], avg),
                   new_rate=_div(100 * tot["new_units"], avg), rebuild_cost_per_unit=_div(reb_cost, reb_n) * cpi if reb_n else None)
        out.append(tot)
    return out


def rebuild_lines(c, y):
    """Sched. 710S detail lines for one year across railroads: what was bought or rebuilt and what it cost."""
    out = []
    for o in c.ids:
        r = c.r1.get((o, y)) or {}
        for d in r.get("rebuild_detail") or []:
            if not d.get("units"):
                continue
            out.append(dict(op=o, label=RAILROADS[o][0], kind=d.get("kind"), desc=d.get("desc"), units=d.get("units"),
                            cost=_real(r, (d.get("cost_k") or 0) * 1000) if d.get("cost_k") else None))
    return sorted(out, key=lambda d: (d["kind"] != "rebuilt", d["label"], -(d["units"] or 0)))


def rebuild_economics(c, repair_saving=30.0, fuel_saving=10.0, ops=None):
    """Rebuild vs new by railroad-year from Sched. 710S, with a simple payback estimate for buying new instead of rebuilding:
    (new cost - rebuild cost) / (repairs per unit-year x repair saving + fuel per unit-year x fuel saving)."""
    rows = []
    for o in (ops or c.ids):
        for y in c.r1_years:
            r = c.r1.get((o, y))
            if not r:
                continue
            new, reb = c.v("new_cost_per_unit", o, y), c.v("rebuild_cost_per_unit", o, y)
            rep_yr = c.v("repairs_per_unit_year", o, y)
            fuel_yr = _real(r, _div(r.get("fuel_cost_usd"), r.get("avg_units")))
            saving = (rep_yr or 0) * repair_saving / 100 + (fuel_yr or 0) * fuel_saving / 100
            payback = (new - reb) / saving if new and reb and saving else None
            if not (new or reb):
                continue
            rows.append(dict(op=o, label=RAILROADS[o][0], y=y, new_units=r.get("new_units_710S"), new=new, reb_units=r.get("rebuilt_units_710S"),
                             reb=reb, ratio=c.v("rebuild_to_new", o, y), rep_yr=rep_yr, fuel_yr=fuel_yr, saving=saving, payback=payback,
                             detail=r.get("rebuild_detail") or []))
    return rows


def line_linked(c, key, ops=None, sel_op=None, sel_y=None, w=680, h=240):
    """Line chart, one series per railroad, where every point links to that railroad-year's drill-down and each legend entry to the
    railroad's page. Server-rendered SVG, colors from the site's CSS variables."""
    ops = ops or c.ids
    series = [(o, [(y, c.v(key, o, y)) for y in c.years if c.v(key, o, y) is not None]) for o in ops]
    from .charts import year_range, in_range, range_wrap
    rr = year_range([y for _, s in series for y, _ in s])
    series = [(o, [(y, v) for y, v in s if in_range(y, rr)]) for o, s in series]
    pts = [v for _, s in series for _, v in s]
    if not pts:
        return '<div class="empty">No data for this metric in this view.</div>'
    xs = [y for _, s in series for y, _ in s]
    x0, x1 = min(xs), max(xs)
    lo, hi = min(pts), max(pts)
    from .charts import autorange
    y0, y1 = autorange(lo, hi)
    L, R, T, B = 56, 12, 12, 26

    def sx(x):
        return L + (x - x0) / ((x1 - x0) or 1) * (w - L - R)

    def sy(v):
        return T + (1 - (v - y0) / ((y1 - y0) or 1)) * (h - T - B)
    out = [f'<svg viewBox="0 0 {w} {h}" class="chart linked" role="img" aria-label="{html.escape(M[key]["label"])}">']
    for i in range(5):
        v = y0 + (y1 - y0) * i / 4
        out.append(f'<line x1="{L}" x2="{w - R}" y1="{sy(v):.1f}" y2="{sy(v):.1f}" class="grid"/>'
                   f'<text x="{L - 6}" y="{sy(v) + 4:.1f}" class="ax" text-anchor="end">{html.escape(_axis(key, v))}</text>')
    step = max(1, round((x1 - x0) / 8))
    for x in range(x0, x1 + 1, step):
        out.append(f'<text x="{sx(x):.1f}" y="{h - 8}" class="ax" text-anchor="middle">{x}</text>')
    for o, s in series:
        if not s:
            continue
        i = list(RAILROADS).index(o)
        col = COLORS[i % len(COLORS)]
        dim = sel_op and o != sel_op
        d = " ".join(f"{'M' if j == 0 else 'L'}{sx(x):.1f},{sy(v):.1f}" for j, (x, v) in enumerate(s))
        out.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{1.5 if dim else 2.5}" stroke-linejoin="round" opacity="{0.35 if dim else 1}"/>')
        for x, v in s:
            on = o == sel_op and x == sel_y
            ring = ' stroke="var(--ink)" stroke-width="2"' if on else ""
            out.append(f'<a href="{html.escape(link(key, o, x))}"><circle cx="{sx(x):.1f}" cy="{sy(v):.1f}" r="{6 if on else 3.5}" fill="{col}" '
                       f'opacity="{0.45 if dim else 1}"{ring}>'
                       f'<title>{RAILROADS[o][0]} {x}: {html.escape(c.show(key, o, x))} · click for the calculation</title></circle></a>')
    out.append("</svg>")
    legend = "".join(f'<a href="{base()}/rr/{o}"><i style="background:{COLORS[list(RAILROADS).index(o) % len(COLORS)]}"></i>{RAILROADS[o][0]}</a>'
                     for o, s in series if s)
    return range_wrap("".join(out) + f'<div class="legend">{legend}</div>', rr)


def _axis(key, v):
    f = M[key]["fmt"]
    if f in ("usd", "cur") and abs(v) >= 1e6:
        return f"${v / 1e6:.1f}M"
    if f in ("usd", "usd2", "usd3"):
        return f"${v:,.2f}" if abs(v) < 100 else f"${v / 1000:,.0f}k"
    if f == "cur":
        return f"{v / 1000:,.1f}B" if abs(v) >= 1000 else f"{v:,.0f}M"
    if abs(v) >= 10000:
        return f"{v / 1000:,.0f}k"
    return f"{v:,.2f}".rstrip("0").rstrip(".") if abs(v) < 10 else f"{v:,.0f}"


def spark(points, w=110, h=28):
    pts = [(x, v) for x, v in points if v is not None]
    if len(pts) < 2:
        return ""
    xs, vs = [p[0] for p in pts], [p[1] for p in pts]
    lo, hi = min(vs), max(vs)

    def sx(x):
        return 2 + (x - xs[0]) / ((xs[-1] - xs[0]) or 1) * (w - 4)

    def sy(v):
        return h - 3 - (v - lo) / ((hi - lo) or 1) * (h - 6)
    d = " ".join(f"{'M' if i == 0 else 'L'}{sx(x):.1f},{sy(v):.1f}" for i, (x, v) in enumerate(pts))
    return f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" class="spark" aria-hidden="true"><path d="{d}" fill="none" stroke="var(--c1)" stroke-width="1.6"/></svg>'


def metric_table(c, key):
    """Year x railroad grid for a metric drill-down page."""
    ys = [y for y in c.years if any(c.v(key, o, y) is not None for o in c.ids)]
    return ys, [dict(op=o, label=RAILROADS[o][0], cells=[dict(y=y, show=c.show(key, o, y), v=c.v(key, o, y), href=link(key, o, y)) for y in ys]) for o in c.ids]


def export_rows(c, keys=None):
    out = []
    for key in (keys or list(M)):
        for o in c.ids:
            for y in c.years:
                v = c.v(key, o, y)
                if v is None:
                    continue
                src = c.k.get((o, y), {}).get("_src", {}).get(key) if M[key]["src"] == "kpi" else None
                out.append(dict(operator_id=o, railroad=RAILROADS[o][0], year=y, metric=key, label=M[key]["label"], value=round(v, 4),
                                unit=M[key]["unit"], currency=c.currency(key, o, y) if M[key]["fmt"] == "cur" else "",
                                source=(src[0] if src else ("STB R-1" if M[key]["src"] == "r1" else "")), source_url=(src[1] if src else R1_URL)))
    return out
