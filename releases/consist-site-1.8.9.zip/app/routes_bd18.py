"""1.8.1 routes: megaprojects, market sizing, competitor profiles, data QA flags (Admin) and the weekly territory digest switch."""
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, HTTPException, Request

from . import auth, bd18, intel
from .main import flash, redirect, render
from .parents import parent

app = APIRouter(prefix="/app")
admin = APIRouter(prefix="/admin")
U = Depends(auth.require_user)
A = Depends(auth.require_admin)


def _locked(request, u, feature, title):
    return render(request, "app/locked.html", user=u, feature=feature, title=title)


@app.get("/projects")
def projects(request: Request, u=U):
    if not (u.is_admin or u.can("fleet_detail")):
        return _locked(request, u, "fleet_detail", "Megaprojects")
    country = request.query_params.get("country") or None
    q = (request.query_params.get("q") or "").strip()[:80] or None
    d = bd18.projects_seed()
    rows = bd18.projects(country if country in ("US", "CA") else None, q)
    g = bd18.gantt_ctx(rows)
    return render(request, "app/projects.html", user=u, rows=rows, d=d, country=country, q=q or "", **g)


@app.get("/projects/{pid}")
def project(request: Request, pid: str, u=U):
    if not (u.is_admin or u.can("fleet_detail")):
        return _locked(request, u, "fleet_detail", "Megaprojects")
    p = bd18.project(pid)
    if not p:
        raise HTTPException(404)
    ops = {o["operator_id"]: o for o in intel._rows("SELECT operator_id, operator_name FROM operator")}
    p = dict(p)
    g = bd18.gantt_ctx([p], events=True)
    return render(request, "app/project.html", user=u, p=p, links=bd18.project_links(p, 12), tl=bd18.timeline(p), **g, ops=[ops[o] for o in p.get("operators") or [] if o in ops],
                  d=bd18.projects_seed())


@app.get("/market-sizing")
def sizing(request: Request, u=U):
    if not (u.is_admin or u.can("market")):
        return _locked(request, u, "market", "Market sizing")
    segs = bd18.sizing()
    pick = request.query_params.getlist("seg")
    chosen = [s for s in segs if s["k"] in pick] if pick else segs
    comp = (request.query_params.get("company") or "").strip()[:80]
    sh = bd18.company_share(comp) if comp else None
    try:
        pct = float(request.query_params.get("share")) if request.query_params.get("share") else ((sh["award_pct"] or sh["base_pct"] or 10.0) if sh else 10.0)
    except ValueError:
        pct = 10.0
    pct = max(0.0, min(100.0, pct))
    tam = sum(s["usd"] for s in segs)
    sam = sum(s["usd"] for s in chosen)
    return render(request, "app/market_sizing.html", user=u, segs=segs, pick=pick or [s["k"] for s in segs], tam=tam, sam=sam,
                  som=sam * pct / 100, pct=pct, comp=comp, sh=sh, companies=bd18.top_companies())


@app.get("/competitors")
def competitors(request: Request, u=U):
    if not (u.is_admin or u.can("market")):
        return _locked(request, u, "market", "Competitor profiles")
    name = (request.query_params.get("name") or "").strip()
    if name:
        return redirect("/app/competitors/" + quote(parent(name)))
    return render(request, "app/competitors.html", user=u, companies=bd18.top_companies(60))


@app.get("/competitors/{name}")
def competitor(request: Request, name: str, u=U):
    if not (u.is_admin or u.can("market")):
        return _locked(request, u, "market", "Competitor profiles")
    return render(request, "app/competitor.html", user=u, c=bd18.competitor(name, all_awards=request.query_params.get("all") == "1"))


@app.post("/alerts/digest")
def digest_toggle(request: Request, csrf: str = Form(""), on: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    intel.set_pref(u, "territory_digest", "1" if on else "0")
    flash(request, "Weekly territory digest is on: it comes on Monday mornings." if on else "Weekly territory digest is off.")
    return redirect("/app/alerts#digest")


@app.post("/alerts/digest/test")
def digest_test(request: Request, csrf: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    body = bd18.digest_text(bd18.digest_for(u))
    if not body:
        flash(request, "Nothing new in your territory in the last 7 days, so there is nothing to send.", "bad")
    else:
        bd18.send_digest(u, "[Test]\n\n" + body)
        flash(request, "Test digest sent to " + u["email"] + ".")
    return redirect("/app/alerts#digest")


@admin.get("/data-qa")
def data_qa(request: Request, u=A):
    flags = bd18.qa_flags()
    kinds = {}
    for f in flags:
        kinds[f[0]] = kinds.get(f[0], 0) + 1
    return render(request, "admin/data_qa.html", user=u, flags=flags, kinds=kinds)
