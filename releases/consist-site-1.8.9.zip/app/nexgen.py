"""NexGen features (2026-11-07, from the five persona reviews): pursuit tracker, watchlist keywords, data corrections,
investor and agency helpers, and Excel export. Team-shared records belong to the team owner (intel.owner_id)."""
import datetime
import io
import re
import statistics
import zipfile
from xml.sax.saxutils import escape

from . import config, data, db, intel, lens

SCHEMA = """
CREATE TABLE IF NOT EXISTS pursuit (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, kind TEXT, ref TEXT, title TEXT NOT NULL,
  operator_id TEXT, stage TEXT DEFAULT 'identify', decision TEXT DEFAULT '', lead TEXT, value_usd REAL, due TEXT, note TEXT,
  created TEXT, updated TEXT, created_by INTEGER);
CREATE TABLE IF NOT EXISTS correction (id INTEGER PRIMARY KEY, ts TEXT, user_id INTEGER, email TEXT, kind TEXT, ref TEXT, label TEXT,
  field TEXT, current TEXT, proposed TEXT, source TEXT, note TEXT, status TEXT DEFAULT 'new', reviewed TEXT, review_note TEXT);
CREATE TABLE IF NOT EXISTS proc_stage (fleet_id INTEGER PRIMARY KEY, operator_id TEXT, fleet TEXT, stage TEXT, expected_rfp TEXT,
  expected_award TEXT, replacement TEXT, awarded_to TEXT, note TEXT, source_url TEXT, confidence TEXT, checked TEXT, updated_by TEXT);
"""

STAGES = [("identify", "Identify"), ("qualify", "Qualify"), ("capture", "Capture"), ("proposal", "Proposal"),
          ("submitted", "Submitted"), ("won", "Won"), ("lost", "Lost"), ("no_bid", "No bid")]
STAGE_LABELS = dict(STAGES)
OPEN_STAGES = ("identify", "qualify", "capture", "proposal", "submitted")
DECISIONS = {"": "Undecided", "go": "Go", "no_go": "No go"}
KINDS = {"notice": "Bid", "fleet": "Fleet", "operator": "Agency", "work": "Upcoming buy", "project": "Project", "other": "Other"}


def ensure():
    with db._lock:
        c = db.connect()
        try:
            c.executescript(SCHEMA)
            if "win_prob" not in {r[1] for r in c.execute("PRAGMA table_info(pursuit)")}:  # 1.8.1 pursuit pipeline
                c.execute("ALTER TABLE pursuit ADD COLUMN win_prob INTEGER")
            _seed_proc_stage(c)  # adds new researched rows from the seed CSV; never overwrites admin edits
            c.commit()
        finally:
            c.close()


def is_agency(u):
    """Agency accounts (persona 'agency' is their only pick) never see seller-only records about agencies."""
    p = intel.personas_for(u)
    return bool(p) and set(p) == {"agency"}


# ---------------- pursuits ----------------

def pursuits(u, stage=None):
    sql, args = "SELECT * FROM pursuit WHERE owner_id = ?", [intel.owner_id(u)]
    if stage == "open":
        sql += f" AND stage IN ({','.join('?' * len(OPEN_STAGES))})"
        args += list(OPEN_STAGES)
    elif stage in STAGE_LABELS:
        sql += " AND stage = ?"
        args.append(stage)
    rows = [dict(r) for r in db.q(sql + " ORDER BY (due IS NULL OR due = ''), due, updated DESC", args)]
    for r in rows:
        r["href"] = href(r["kind"], r["ref"])
    return rows


def pursuit(u, pid):
    r = db.q("SELECT * FROM pursuit WHERE id = ? AND owner_id = ?", (pid, intel.owner_id(u)), one=True)
    return dict(r) if r else None


def pursuit_for(u, kind, ref):
    r = db.q("SELECT * FROM pursuit WHERE owner_id = ? AND kind = ? AND ref = ?", (intel.owner_id(u), kind, str(ref)), one=True)
    return dict(r) if r else None


def href(kind, ref):
    return {"notice": f"/app/bids/{ref}", "fleet": f"/app/fleets/{ref}", "operator": f"/app/operators/{ref}"}.get(kind) if ref else None


def add_pursuit(u, kind, ref, title, operator_id=None, value=None, due=None):
    kind = kind if kind in KINDS else "other"
    old = pursuit_for(u, kind, ref) if ref else None
    if old:
        return old["id"], False
    now = db.now()
    pid = db.x("INSERT INTO pursuit (owner_id, kind, ref, title, operator_id, value_usd, due, created, updated, created_by, lead) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
               (intel.owner_id(u), kind, str(ref or ""), title[:300], operator_id, value, due, now, now, u["id"], u["name"] or u["email"]))
    return pid, True


def update_pursuit(u, pid, form):
    p = pursuit(u, pid)
    if not p:
        return False
    vals = {"stage": form.get("stage") if form.get("stage") in STAGE_LABELS else p["stage"],
            "decision": form.get("decision") if form.get("decision") in DECISIONS else p["decision"],
            "lead": (form.get("lead") or "")[:120], "note": (form.get("note") or "")[:4000],
            "due": form.get("due") if re.fullmatch(r"\d{4}-\d{2}-\d{2}", form.get("due") or "") else None,
            "title": (form.get("title") or p["title"])[:300]}
    try:
        vals["value_usd"] = float(re.sub(r"[^\d.]", "", form.get("value") or "")) if (form.get("value") or "").strip() else None
    except ValueError:
        vals["value_usd"] = p["value_usd"]
    try:
        vals["win_prob"] = max(0, min(100, int(form.get("win_prob")))) if (form.get("win_prob") or "").strip() else None
    except ValueError:
        vals["win_prob"] = p.get("win_prob")
    db.x("UPDATE pursuit SET stage=?, decision=?, lead=?, note=?, due=?, title=?, value_usd=?, win_prob=?, updated=? WHERE id=?",
         (vals["stage"], vals["decision"], vals["lead"], vals["note"], vals["due"], vals["title"], vals["value_usd"], vals["win_prob"],
          db.now(), pid))
    return True


def delete_pursuit(u, pid):
    db.x("DELETE FROM pursuit WHERE id = ? AND owner_id = ?", (pid, intel.owner_id(u)))


# 1.8.1: default win probability by stage when the owner has not entered one (a common capture-management rule of thumb)
STAGE_PROB = {"identify": 10, "qualify": 20, "capture": 35, "proposal": 50, "submitted": 60, "won": 100, "lost": 0, "no_bid": 0}


def prob(r):
    return r.get("win_prob") if r.get("win_prob") is not None else STAGE_PROB.get(r["stage"], 0)


def pipeline_quarters(rows):
    """Open pursuits by the quarter they are due: count, total value, probability-weighted value and owners (1.8.1)."""
    out = {}
    for r in rows:
        if r["stage"] not in OPEN_STAGES:
            continue
        d = r.get("due") or ""
        q = f"{d[:4]}-Q{(int(d[5:7]) - 1) // 3 + 1}" if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d) else "No date"
        b = out.setdefault(q, {"q": q, "n": 0, "value": 0.0, "weighted": 0.0, "owners": set()})
        b["n"] += 1
        b["value"] += r["value_usd"] or 0
        b["weighted"] += (r["value_usd"] or 0) * prob(r) / 100
        if r.get("lead"):
            b["owners"].add(r["lead"])
    rows_ = sorted(out.values(), key=lambda b: (b["q"] == "No date", b["q"]))
    for b in rows_:
        b["owners"] = sorted(b["owners"])
    return rows_


def pursuit_summary(rows):
    open_ = [r for r in rows if r["stage"] in OPEN_STAGES]
    return {"open": len(open_), "value": sum(r["value_usd"] or 0 for r in open_),
            "weighted": sum((r["value_usd"] or 0) * prob(r) / 100 for r in open_), "quarters": pipeline_quarters(rows),
            "go": sum(1 for r in open_ if r["decision"] == "go"),
            "won": sum(1 for r in rows if r["stage"] == "won"), "lost": sum(1 for r in rows if r["stage"] == "lost"),
            "by_stage": [(k, v, sum(1 for r in rows if r["stage"] == k)) for k, v in STAGES]}


# ---------------- corrections ----------------

def add_correction(u, kind, ref, label, field, current, proposed, source, note):
    return db.x("INSERT INTO correction (ts, user_id, email, kind, ref, label, field, current, proposed, source, note) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (db.now(), u["id"], u["email"], kind[:20], str(ref)[:60], label[:200], field[:80], current[:500], proposed[:1000], source[:500], note[:2000]))


def corrections(status="new"):
    sql = "SELECT * FROM correction" + (" WHERE status = ?" if status != "all" else "") + " ORDER BY id DESC LIMIT 500"
    return [dict(r) for r in db.q(sql, (status,) if status != "all" else ())]


def review_correction(cid, status, note):
    if status in ("accepted", "rejected", "new"):
        db.x("UPDATE correction SET status = ?, review_note = ?, reviewed = ? WHERE id = ?", (status, note[:1000], db.now(), cid))


def data_stamp():
    """When the fleet and bid data were last refreshed, for the 'data as of' line on each page."""
    out = {}
    for key, path in (("fleet", config.FLEET_DB), ("bids", config.BIDS_DB)):
        try:
            import os
            out[key] = datetime.datetime.utcfromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d")
        except (OSError, TypeError):
            out[key] = None
    return out


# ---------------- watchlist keywords ----------------

def keyword_alerts(u):
    """Bid keyword watches are saved searches with a q (they already drive email alerts)."""
    rows = []
    for r in db.q("SELECT * FROM saved_search WHERE user_id = ? ORDER BY id DESC", (u["id"],)):
        d = dict(r)
        try:
            import json
            d["params"] = json.loads(d.get("query") or "{}")
        except (ValueError, TypeError):
            d["params"] = {}
        rows.append(d)
    return rows


# ---------------- investor ----------------

def orders(years=None):
    """Vehicle orders with numbers parsed: cars, value, year, per-car price, status bucket."""
    yr = intel.this_year()
    out = []
    for p in data.procurements():
        y = str(p.get("award_date") or "")[:4]
        if not y.isdigit():
            continue
        y = int(y)
        if years and y < yr - years + 1:
            continue
        cars = data.first_int(p.get("qty_base"))
        val = data.first_int(p.get("value_usd"))
        st = (p.get("status") or "").lower()
        delivered = "complete" in st or "delivered" in st
        last = intel._year_in(p.get("delivery"), y + 4) if hasattr(intel, "_year_in") else y + 4
        out.append(dict(p, year=y, cars=cars, value=val or None, per_car=(val / cars) if cars and val else None,
                        builder=_builder(p.get("manufacturer")), delivered=delivered,
                        backlog=(not delivered) and (last >= yr)))
    return out


def _builder(m):
    m = (m or "").strip()
    return "Builder not yet named" if not m or m.upper() in ("TBD", "UNKNOWN", "N/A") else m


def share_new_orders(years=5):
    """Share of new-order cars by builder over the last N award years."""
    rows = orders(years)
    tot = sum(r["cars"] for r in rows) or 0
    by = {}
    for r in rows:
        by[r["builder"]] = by.get(r["builder"], 0) + r["cars"]
    return [(b, round(100 * c / tot) if tot else 0, c) for b, c in sorted(by.items(), key=lambda kv: -kv[1])], tot


def backlog():
    rows = [r for r in orders() if r["backlog"]]
    by = {}
    for r in rows:
        b = by.setdefault(r["builder"], {"builder": r["builder"], "cars": 0, "value": 0, "orders": 0})
        b["cars"] += r["cars"]
        b["value"] += r["value"] or 0
        b["orders"] += 1
    return sorted(by.values(), key=lambda b: -b["cars"]), rows


def median_price():
    v = [r["per_car"] for r in orders(10) if r["per_car"]]
    return statistics.median(v) if v else None


# ---------------- agency ----------------

def my_agency(u):
    oid = intel.pref(u, "my_agency")
    if not oid:
        return None
    o = db.fq("SELECT * FROM operator WHERE operator_id = ?", (oid,), one=True)
    return dict(o) if o else None


def agency_fleets(oid):
    return [fl for fl in intel.snapshot().values() if fl["operator_id"] == oid]


def peer_ids(oid, n=8):
    """Peers: operators that run the same modes, closest in active cars."""
    snap = intel.snapshot().values()
    mine = [fl for fl in snap if fl["operator_id"] == oid]
    modes = {fl["ntd_mode"] for fl in mine}
    size = sum(fl["qty_active"] or 0 for fl in mine) or 1
    by = {}
    for fl in snap:
        if fl["operator_id"] != oid and fl["ntd_mode"] in modes:
            by[fl["operator_id"]] = by.get(fl["operator_id"], 0) + (fl["qty_active"] or 0)
    return [k for k, _ in sorted(by.items(), key=lambda kv: abs(kv[1] - size) / size)[:n] if _ > 0]


def avg_age(fleets):
    yr = intel.this_year()
    w = [(yr - fl["build_year"], fl["qty_active"] or 0) for fl in fleets if fl["build_year"] and (fl["qty_active"] or 0) > 0]
    n = sum(c for _, c in w)
    return round(sum(a * c for a, c in w) / n, 1) if n else None


# ---------------- Excel export ----------------

def _col(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _cell(ref, v):
    if v is None or v == "":
        return ""
    if isinstance(v, bool):
        v = "Yes" if v else "No"
    if isinstance(v, (int, float)):
        return f'<c r="{ref}"><v>{v}</v></c>'
    return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{escape(str(v))[:32000]}</t></is></c>'


def _sheet(rows):
    xml = []
    for ri, row in enumerate(rows):
        xml.append(f'<row r="{ri + 1}">' + "".join(_cell(f"{_col(ci)}{ri + 1}", v) for ci, v in enumerate(row)) + "</row>")
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            f'<sheetData>{"".join(xml)}</sheetData></worksheet>')


def xlsx(sheets):
    """sheets: [(name, header, rows)] -> bytes of a minimal .xlsx workbook (no dependencies)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(sheets)))
                   + "</Types>")
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                   'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join(f'<sheet name="{escape(re.sub(r"[^A-Za-z0-9 _-]", "", n)[:31] or f"Sheet{i + 1}")}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, (n, _, _) in enumerate(sheets))
                   + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(len(sheets)))
                   + "</Relationships>")
        for i, (_, head, rows) in enumerate(sheets):
            z.writestr(f"xl/worksheets/sheet{i + 1}.xml", _sheet([head] + [list(r) for r in rows]))
    return buf.getvalue()


def about_sheet(title):
    return ("About", ["Item", "Value"], [("Export", title), ("Exported", datetime.date.today().isoformat()), ("Publisher", f"Consist ({config.SITE_URL})"),
                                          ("Terms", "Internal use by the subscribing organization. Not for resale or redistribution."),
                                          ("Sources", "Each row's source is in its source column where one is recorded. Methodology: " + config.SITE_URL + "/p/methodology")])


# ---------------- wave 2: procurement cost estimator ----------------

def _ppi_factor(from_year, to_year):
    """Escalation from mid-year from_year to mid-year to_year on the BLS rolling stock PPI (forecast past the data)."""
    from . import escalation
    try:
        a, _ = escalation.value_at("PPI_RS", escalation._mi(int(from_year), 6))
        b, fc = escalation.value_at("PPI_RS", escalation._mi(int(to_year), 6))
        return (b / a, fc) if a and b else (None, False)
    except Exception:
        return None, False


def estimate(vtype, qty, year):
    """Peer price per car for a vehicle type, each order escalated to the target year, and the range for qty cars."""
    from . import vehicle_awards
    rows = []
    for o in vehicle_awards.orders():
        if o["type"] != vtype or not o.get("unit_usd") or not o.get("year"):
            continue
        f, fc = _ppi_factor(o["year"], year)
        rows.append(dict(o, factor=f, esc=o["unit_usd"] * f if f else None, fc=fc))
    vals = sorted(r["esc"] for r in rows if r["esc"])

    def q(p):
        if not vals:
            return None
        k = (len(vals) - 1) * p
        lo, hi = int(k), min(int(k) + 1, len(vals) - 1)
        return vals[lo] + (vals[hi] - vals[lo]) * (k - lo)
    lo, mid, hi = q(0.25), q(0.5), q(0.75)
    return {"rows": sorted(rows, key=lambda r: r["date"], reverse=True), "n": len(vals), "low": lo, "mid": mid, "high": hi,
            "tot": {k: v * qty for k, v in (("low", lo), ("mid", mid), ("high", hi)) if v}, "forecast": any(r["fc"] for r in rows)}


# ---------------- wave 2: change-of-supplier windows, coverage ----------------

WINDOW_LABELS = {"midlife": "Midlife overhaul", "warranty": "Warranty ends", "retire": "Planned retirement", "eol": "End of useful life"}


def supplier_windows(years=8, subsystem=None, supplier=None):
    """Each mapped fleet x subsystem with the next moment the supplier could change, soonest first."""
    yr = intel.this_year()
    v = intel.subsystem_view(subsystem or None)
    out = []
    for r in v["rows"]:
        fl = r["fleet"]
        if supplier and supplier.lower() not in (r["supplier_name"] or "").lower():
            continue
        cands = []
        if fl.get("midlife_due_year") and not fl.get("last_rebuild_year"):
            cands.append((fl["midlife_due_year"], "midlife"))
        w = str(fl.get("warranty_end_est") or "")[:4]
        if w.isdigit():
            cands.append((int(w), "warranty"))
        if fl.get("planned_retirement_year"):
            cands.append((fl["planned_retirement_year"], "retire"))
        elif fl.get("ulb_year"):
            cands.append((fl["ulb_year"], "eol"))
        cands = [(max(y, yr), k) for y, k in cands if y and y <= yr + years]
        if not cands:
            continue
        y, k = min(cands)
        out.append({"fleet": fl, "rec": r["rec"], "supplier": r["supplier_name"], "year": y, "why": WINDOW_LABELS[k], "cars": fl["qty_active"] or 0})
    out.sort(key=lambda x: (x["year"], -x["cars"]))
    return out


def coverage():
    """Share of active fleets and cars with a supplier record, per subsystem."""
    snap = [fl for fl in intel.snapshot().values() if (fl["qty_active"] or 0) > 0]
    tf, tc = len(snap) or 1, sum(fl["qty_active"] for fl in snap) or 1
    out = []
    for k, label in data.SUBSYSTEMS.items():
        f = [fl for fl in snap if any(x["subsystem"] == k for x in fl["installed"])]
        out.append({"key": k, "label": label, "fleets": len(f), "fleet_pct": round(100 * len(f) / tf), "cars_pct": round(100 * sum(fl["qty_active"] for fl in f) / tc)})
    return sorted(out, key=lambda r: -r["cars_pct"]), tf


def new_orders(months=24):
    """Recent vehicle orders: the window when car builders pick subsystem suppliers."""
    from . import vehicle_awards
    cut = (datetime.date.today() - datetime.timedelta(days=months * 30)).isoformat()
    rows = [o for o in vehicle_awards.orders() + vehicle_awards.orders(unpriced=True) if (o.get("date") or "") >= cut]
    seen, out = set(), []
    for o in sorted(rows, key=lambda o: o["date"], reverse=True):
        key = (o.get("buyer"), o.get("builder"), (o.get("date") or "")[:7])
        if key not in seen:
            seen.add(key)
            out.append(o)
    return out


# ---------------- wave 2: consultant and early-signal bid tags ----------------

TAG_RX = [
    ("method", "RFQ / qualifications", r"\brfq\b|request for qualifications|statement of qualifications|\bsoq\b|qualifications[- ]based|\bqbs\b|brooks act"),
    ("method", "RFP", r"\brfp\b|request for proposals?"),
    ("method", "Low bid (IFB)", r"\bifb\b|invitation (for|to) bids?|\bitb\b|sealed bid"),
    ("contract", "On-call / IDIQ", r"on[- ]call|\bidiq\b|indefinite delivery|task order contract|as[- ]needed|bench contract|master (services )?agreement"),
    ("service", "Design", r"\bdesign\b|engineering services|\bpe services|preliminary engineering|final design"),
    ("service", "PM / CM", r"construction management|program management|project management|\bcm services|\bpmc\b|\bcm/?gc\b|resident engineer|inspection services"),
    ("service", "Design-build", r"design[- ]build|\bdb\b contract|progressive design"),
    ("early", "RFI / market sounding", r"\brfi\b|request for information|market sounding|sources sought|expression of interest|\beoi\b|letter of interest"),
    ("early", "Industry day", r"industry (day|forum|outreach)|pre[- ]solicitation|vendor outreach|one[- ]on[- ]one meetings?"),
]


def bid_tags(n):
    t = " ".join(str(n.get(k) or "") for k in ("title", "summary", "notice_type")).lower()
    ct = n.get("contract_type")  # 1.7.31: Bid Catcher's on-call classifier (bids-push21) when present; the text rule otherwise
    return [(g, label) for g, label, rx in TAG_RX if (ct == "oncall" if (g == "contract" and ct) else re.search(rx, t))]


def early_signals(limit=12):
    """Open or recent RFIs, sources-sought notices and industry days: the earliest public sign of a procurement.
    1.7.44 (Justin 11-12, "doesn't show much"): no relevance floor here. RFIs are short, so 85 of 88 in the last year scored
    under 25 and the Bids default of 50 hid all but one; Bid Catcher only keeps them when they match rail NAICS codes or rail
    words. Bid Catcher's notice.stage = 'early' (when present) counts too."""
    rows = []
    base = {"status": "all", "sort": "new", "days": 365, "min_rel": "0"}
    for q in ("request for information", "RFI", "sources sought", "industry day", "market sounding", "expression of interest",
              "letter of interest", "pre-solicitation", "presolicitation"):
        rows += data.notices(dict(base, q=q), per=80)[0]
    staged = {r["notice_id"] for r in data.notices(dict(base, stage="early"), per=200)[0]} if "stage" in data.bcols("notice") else set()
    if staged:
        rows += data.notices(dict(base, stage="early"), per=200)[0]
    seen, out = set(), []
    for r in rows:
        r = dict(r)
        if r["notice_id"] in seen or not (r["notice_id"] in staged or any(g == "early" for g, _ in bid_tags(r))):
            continue
        seen.add(r["notice_id"])
        out.append(r)
    return sorted(out, key=lambda r: r.get("published") or "", reverse=True)[:limit]



def early_view():
    """Everything that comes before an RFP, for the Early signals page (1.7.44): RFIs and industry days, agency procurement
    forecasts (notice_type 'planned'), board agenda items that authorize a solicitation or budget a rail buy, on-call
    contracts whose next round is due within a year, and vehicle orders that are planned or out to bid."""
    from . import nexgen2
    out = {"rfis": early_signals(80)}
    out["forecasts"] = data.notices({"status": "all", "sort": "new", "days": 365, "min_rel": "25", "ntype": "planned"}, per=40)[0]
    tw, ta = lens.current().ter_sql(agency_col="i.agency_id")  # 1.7.45 sales territory
    items = data._bq_safe("SELECT i.*, m.meeting_date, m.body, coalesce(g.agency, i.agency_id) agency FROM meeting_item i JOIN meeting m USING (meeting_id) "
                          "LEFT JOIN agency g ON g.agency_id = i.agency_id WHERE i.action IN ('solicitation', 'budget') AND coalesce(i.relevance, 0) >= 45 "
                          f"AND m.meeting_date >= date('now', '-365 days') AND {tw} ORDER BY m.meeting_date DESC LIMIT 40", tuple(ta))
    for it in items:
        url = it.get("doc_url") or ""
        it["href"] = url + (f"#page={it['page']}" if it.get("page") and ".pdf" in url.lower() and "#" not in url else "")
    out["board"] = items
    try:
        oc, _ = nexgen2.oncall_expiry({"ends": "next24"})
        today = data.today()[:7]
        out["rebids"] = sorted([r for r in oc if r.get("rebid") and r["rebid"] <= nexgen2._ym_add(today, 12)], key=lambda r: r["rebid"])[:30]
    except Exception:
        out["rebids"] = []
    out["orders"] = [p for p in data.procurements() if re.search(r"rfp|planned|announced|rfi", p.get("status") or "", re.I)]
    out["n"] = sum(len(v) for v in out.values())
    return out

# ---------------- procurement stage (wave 3 research seed) ----------------

PROC_STAGES = {"planning": ("Planning", ""), "funded": ("Funded", "accent"), "rfi": ("RFI out", "accent"), "rfp_out": ("RFP out", "warn"),
               "evaluation": ("In evaluation", "warn"), "awarded": ("Awarded", "ok"), "delivering": ("Delivering", "ok"), "none": ("No buy planned", "")}
OPEN_PROC = ("planning", "funded", "rfi", "rfp_out", "evaluation")
PS_FIELDS = ("fleet_id", "operator_id", "fleet", "stage", "expected_rfp", "expected_award", "replacement", "awarded_to", "note",
             "source_url", "confidence", "checked")
_PS = {"mt": None, "rows": {}, "ver": 0}


def _ps_path():
    import pathlib
    return pathlib.Path(__file__).resolve().parent.parent / "seed" / "procurement_stage.csv"


def _seed_proc_stage(c):
    """Load researched rows from the seed CSV that are not in the table yet. Rows edited in Admin are kept as edited."""
    import csv
    try:
        with open(_ps_path(), newline="", encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                try:
                    fid = int(r["fleet_id"])
                except (TypeError, ValueError):
                    continue
                c.execute(f"INSERT OR IGNORE INTO proc_stage ({','.join(PS_FIELDS)}, updated_by) VALUES ({','.join('?' * len(PS_FIELDS))}, 'seed')",
                          [fid] + [r.get(k) or "" for k in PS_FIELDS[1:]])
    except OSError:
        pass


def proc_stages():
    """fleet_id -> researched procurement stage row (Admin > Procurement stages edits these)."""
    if _PS["mt"] != _PS["ver"]:
        c = db.connect()
        try:
            rows = {r["fleet_id"]: dict(r) for r in c.execute("SELECT * FROM proc_stage")}
        except Exception:
            rows = {}
        finally:
            c.close()
        _PS.update(mt=_PS["ver"], rows=rows)
    return _PS["rows"]


def save_proc_stage(fid, form, who):
    fid = int(fid)
    vals = {k: (form.get(k) or "").strip()[:2000] for k in PS_FIELDS[1:]}
    if vals["stage"] not in PROC_STAGES:
        raise ValueError("Pick a stage")
    snap = intel.snapshot()
    fl = snap.get(fid) or snap.get(str(fid))
    if not fl:
        raise ValueError(f"No fleet {fid}")
    vals["operator_id"] = vals["operator_id"] or fl.get("operator_id") or ""
    vals["fleet"] = vals["fleet"] or fl.get("model_name") or ""
    vals["checked"] = vals["checked"] or datetime.date.today().isoformat()
    with db._lock:
        c = db.connect()
        try:
            c.execute(f"INSERT OR REPLACE INTO proc_stage ({','.join(PS_FIELDS)}, updated_by) VALUES ({','.join('?' * len(PS_FIELDS))}, ?)",
                      [fid] + [vals[k] for k in PS_FIELDS[1:]] + [who])
            c.commit()
        finally:
            c.close()
    _PS["ver"] += 1


def delete_proc_stage(fid):
    with db._lock:
        c = db.connect()
        try:
            c.execute("DELETE FROM proc_stage WHERE fleet_id=?", (int(fid),))
            c.commit()
        finally:
            c.close()
    _PS["ver"] += 1


def proc_stage_list(stage=None, q=None):
    rows = sorted(proc_stages().values(), key=lambda r: ((r.get("operator_id") or ""), (r.get("fleet") or "")))
    if stage:
        rows = [r for r in rows if r.get("stage") == stage]
    if q:
        ql = q.lower()
        rows = [r for r in rows if ql in " ".join(str(r.get(k) or "") for k in ("operator_id", "fleet", "replacement", "awarded_to", "note")).lower()]
    return rows


_PSK = {"mt": None, "by_key": {}}


def _ps_by_key():
    """(operator_id, model_name) -> researched row, so sibling fleets (same operator and model, other build batches) share it."""
    rows = proc_stages()
    if _PSK["mt"] != _PS["mt"]:
        snap = intel.snapshot()
        by_key = {}
        for fid, r in rows.items():
            fl = snap.get(fid) or snap.get(str(fid))
            if fl:
                by_key.setdefault((fl.get("operator_id"), fl.get("model_name")), r)
        _PSK.update(mt=_PS["mt"], by_key=by_key)
    return _PSK["by_key"]


def proc_stage(fid):
    try:
        fid = int(fid)
    except (TypeError, ValueError):
        return None
    r = proc_stages().get(fid)
    if r:
        return r
    snap = intel.snapshot()
    fl = snap.get(fid) or snap.get(str(fid))
    return _ps_by_key().get((fl.get("operator_id"), fl.get("model_name"))) if fl else None


def stage_pill(fid, full=False):
    """Small HTML pill for a fleet's researched procurement stage, or '' when not researched."""
    from markupsafe import Markup, escape as h
    r = proc_stage(fid)
    if not r or r.get("stage") not in PROC_STAGES:
        return ""
    label, cls = PROC_STAGES[r["stage"]]
    bits = []
    if r.get("awarded_to"):
        bits.append(str(r["awarded_to"]))
    if r.get("expected_rfp"):
        bits.append("RFP exp. " + str(r["expected_rfp"]))
    elif r.get("expected_award") and r["stage"] in OPEN_PROC:
        bits.append("award exp. " + str(r["expected_award"]))
    tip = f"{r.get('note') or ''} (checked {r.get('checked') or '?'}, {r.get('confidence') or '?'} confidence)"
    out = f'<span class="pill {cls}" title="{h(tip)}">{h(label)}{(" · " + h(", ".join(bits))) if bits else ""}</span>'
    if full:
        rep = f"<b>Replacement:</b> {h(r['replacement'])}<br>" if r.get("replacement") else ""
        src = f' <a href="{h(r["source_url"])}" target="_blank" rel="noopener">Source</a>' if r.get("source_url") else ""
        out += f'<p class="small mt">{rep}{h(r.get("note") or "")}{src}<br><span class="muted">Researched {h(r.get("checked") or "")} · {h(r.get("confidence") or "")} confidence</span></p>'
    return Markup(out)


def stage_open(fid):
    """True unless research shows the buy is already awarded, delivering, or not planned."""
    r = proc_stage(fid)
    return not r or r.get("stage") in OPEN_PROC
