"""Page access by plan (Justin's plan matrix, 2026-11-08). Each plan row can carry page tokens in its features list:
'pg:<path>' = the page in full, 'pv:<path>' = a preview. A plan with no page tokens at all keeps the old behavior (every page
open, features decide). Admin > Plans shows a Full / Preview / Locked choice per page. PageGateMiddleware enforces it:
locked pages redirect to the upgrade page; previews show the first PREVIEW_ROWS rows of every table plus an upgrade banner,
except pages whose own feature checks already make a preview (NATURAL_PREVIEW). Admins and admin previews of a plan follow
the plan they are viewing as."""
import re

from starlette.responses import RedirectResponse

from . import auth, db

PREVIEW_ROWS = 5
FLEET_PREVIEW_ROWS = 10  # Fleets preview (Justin, 2026-11-08): the first 10 fleets, paid columns blurred
PAGES = [
 ("Opportunities", "/app/projects", "Megaprojects"),  # 1.8.1
 ("Market", "/app/market-sizing", "Market sizing (TAM, SAM, SOM)"),  # 1.8.1
 ("Competitors and suppliers", "/app/competitors", "Competitor profiles"),  # 1.8.1
 ("Find Work",
  "/app/bids",
  "Bids and RFPs"),
 ("Find Work",
  "/app/early-signals",
  "Early signals (RFIs, industry days)"),
 ("Find Work",
  "/app/work",
  "Upcoming work"),
 ("Find Work",
  "/app/awards",
  "Funding and awards"),
 ("Find Work",
  "/app/funding-programs",
  "Funding programs"),
 ("Find Work",
  "/app/capital-pipeline",
  "Capital projects and on-call"),
 ("Find Work",
  "/app/past-rfps",
  "Past RFPs"),
 ("Find Work",
  "/app/drivers",
  "Funding and rule drivers"),
 ("Installed Base",
  "/app/search",
  "Search"),
 ("Installed Base",
  "/app/operators",
  "Operators"),
 ("Installed Base",
  "/app/fleets",
  "Fleets"),
 ("Installed Base",
  "/app/subsystems",
  "Subsystems"),
 ("Installed Base",
  "/app/supplier-windows",
  "Supplier change windows"),
 ("Installed Base",
  "/app/builders",
  "Builders and models"),
 ("Installed Base",
  "/app/safety",
  "Safety rates"),
 ("Installed Base",
  "/app/platforms",
  "Platform supplier map"),
 ("Installed Base",
  "/app/signal-profiles",
  "Signal and train control"),
 ("Installed Base",
  "/app/reliability",
  "Reliability benchmarks"),
 ("Market",
  "/app/market",
  "Market share"),
 ("Market",
  "/app/investors",
  "Orders and backlog"),
 ("Market",
  "/app/market-note",
  "Quarterly market note"),
 ("Market",
  "/app/option-map",
  "Options and joint buys"),
 ("Market",
  "/app/delivery-record",
  "Builder delivery record"),
 ("Market",
  "/app/lessors",
  "Leasing and ownership"),
 ("Market",
  "/app/my-agency",
  "Peer benchmarks"),
 ("Market",
  "/app/my-agency/planner",
  "Fleet capital planner"),
 ("Market",
  "/app/agency-finance",
  "Agency finance"),
 ("Market",
  "/app/costs",
  "Cost benchmarks"),
 ("Market",
  "/app/estimator",
  "Procurement cost estimator"),
 ("Market",
  "/app/escalation",
  "Cost escalation and forecasts"),
 ("Market",
  "/app/cost-indexes",
  "Cost and fuel indexes"),
 ("Suppliers",
  "/app/suppliers",
  "Supplier directory"),
 ("Suppliers",
  "/app/supplier-intel",
  "Supplier intelligence"),
 ("Suppliers",
  "/app/consultants",
  "Engineering consultants"),
 ("Suppliers",
  "/app/tier1",
  "Tier-1 suppliers"),
 ("Workspace",
  "/app/watchlist",
  "Watchlist"),
 ("Workspace",
  "/app/pursuits",
  "Pursuits"),
 ("Workspace",
  "/app/lists",
  "Accounts and lists"),
 ("Workspace",
  "/app/alerts",
  "Alerts"),
 ("Workspace",
  "/app/analyst",
  "AI analyst"),
 ("Workspace",
  "/app/api-keys",
  "API keys")
]
NATURAL_PREVIEW = ("/app/bids", "/app/fleets", "/app/alerts")  # 1.7.9: awards (funding tab) and suppliers had no natural limit, so they are trimmed too
LABELS = {p: l for _, p, l in PAGES}
_ORDER = sorted((p for _, p, _ in PAGES), key=len, reverse=True)

# The one-time setup from Justin's matrix (applied by db.init under flag page_access_1108). Pages not listed are full.
MATRIX_1108 = {  # API keys locked on self-serve plans (enterprise only)
 "free": {
  "/app/bids": "preview",
  "/app/work": "none",
  "/app/awards": "preview",
  "/app/funding-programs": "none",
  "/app/capital-pipeline": "preview",
  "/app/past-rfps": "preview",
  "/app/fleets": "preview",
  "/app/subsystems": "preview",
  "/app/supplier-windows": "preview",
  "/app/builders": "preview",
  "/app/safety": "none",
  "/app/platforms": "preview",
  "/app/signal-profiles": "preview",
  "/app/reliability": "preview",
  "/app/market": "none",
  "/app/option-map": "preview",
  "/app/delivery-record": "preview",
  "/app/lessors": "preview",
  "/app/my-agency": "none",
  "/app/my-agency/planner": "none",
  "/app/costs": "none",
  "/app/estimator": "preview",
  "/app/escalation": "none",
  "/app/cost-indexes": "none",
  "/app/suppliers": "preview",
  "/app/supplier-intel": "none",
  "/app/consultants": "none",
  "/app/tier1": "none",
  "/app/lists": "none",
  "/app/alerts": "preview",
  "/app/analyst": "none",
  "/app/api-keys": "none"
 },
 "pro": {},
 "freight_analyst": {
  "/app/bids": "none",
  "/app/search": "none",
  "/app/operators": "none",
  "/app/fleets": "none",
  "/app/subsystems": "none",
  "/app/supplier-windows": "none",
  "/app/builders": "none",
  "/app/safety": "none",
  "/app/platforms": "none",
  "/app/signal-profiles": "none",
  "/app/reliability": "none",
  "/app/market": "none",
  "/app/investors": "none",
  "/app/market-note": "none",
  "/app/option-map": "none",
  "/app/delivery-record": "none",
  "/app/lessors": "none",
  "/app/my-agency": "none",
  "/app/my-agency/planner": "none",
  "/app/agency-finance": "none",
  "/app/costs": "none",
  "/app/estimator": "none",
  "/app/escalation": "none",
  "/app/cost-indexes": "none",
  "/app/lists": "none",
  "/app/alerts": "preview",
  "/app/api-keys": "none"
 },
 "enterprise": {}
}
for _row in MATRIX_1108.values():  # API keys: enterprise only, so locked on every self-serve plan
    _row["/app/api-keys"] = "none"

# Sold only through an enterprise engagement (Justin, 2026-11-08): taken off every self-serve plan by the one-time setup.
# Give them to an enterprise customer by ticking them on a contact-only plan in Admin > Plans.
ENTERPRISE_ONLY = ("crm_export", "api")
# Features a plan needs so the pages it is given actually work (added once, with the matrix).
FEATURES_1108 = {"freight_analyst": ["fleet_basic", "fleet_detail", "bids_recent", "bids_full", "pipeline", "awards", "export"]}


# Justin's answers to the plan audit (2026-11-08, applied once by db.init under flag plan_access_1108b):
# Freight Markets Analyst keeps only Find Work pages about freight market activity. Upcoming work, Early signals, Past RFPs,
# Capital projects, Funding and awards and Funding and rule drivers are transit and passenger procurement, so they are locked and
# the bid, pipeline and award features that only served them come off. Funding programs stays (CRISI and the crossing and short
# line grants are freight work).
LOCK_1108B = {"freight_analyst": ["/app/work", "/app/early-signals", "/app/past-rfps", "/app/capital-pipeline", "/app/awards", "/app/drivers"]}
DROP_1108B = {"freight_analyst": ["bids_recent", "bids_full", "pipeline", "awards", "opportunities"]}
# Plan bullets rewritten to match, only while they still read exactly as they did on 2026-11-08 (an admin edit is never overwritten).
BULLETS_1108B = {"free": ("Recent rail bids (last 30 days) and the fleet roster",
                          "Recent rail bids (last 30 days) and the first 10 fleets of the roster")}

# Justin, 2026-11-08 (flag plan_access_1108c): Early signals is the same RFI data as the bid feed, so Free gets it as a preview.
PREVIEW_1108C = {"free": ["/app/early-signals"]}

# The page each plan feature lives on, so the pricing table only ticks a feature a plan can actually open (Sample = preview).
FEATURE_PAGE = {"bids_recent": "/app/bids", "bids_full": "/app/bids", "alerts_instant": "/app/alerts", "bid_brief": "/app/bids",
                "fleet_basic": "/app/fleets", "fleet_detail": "/app/fleets", "pipeline": "/app/work", "opportunities": "/app/work",
                "awards": "/app/awards", "market": "/app/market", "lists": "/app/lists", "fleet_alerts": "/app/alerts",
                "api": "/app/api-keys"}


def feature_access(plan, feat):
    """'full', 'preview' or 'none' for a plan feature, taking the page it lives on into account."""
    if feat not in ((plan or {}).get("features") or []):
        return "none"
    page = FEATURE_PAGE.get(feat)
    return access(plan, page) if page else "full"


def page_for(path):
    for p in _ORDER:
        if path == p or path.startswith(p + "/") or path.startswith(p + "?"):
            return p
    return None


def gated(plan):
    return any(str(f).startswith(("pg:", "pv:")) for f in (plan or {}).get("features") or [])


def access(plan, path):
    """'full', 'preview' or 'none' for this plan on the page at path."""
    page = page_for(path)
    if not page or not gated(plan):
        return "full"
    f = plan.get("features") or []
    return "full" if "pg:" + page in f else "preview" if "pv:" + page in f else "none"


def tokens(matrix_row):
    out = []
    for _, p, _ in PAGES:
        v = matrix_row.get(p, "full")
        if v == "full":
            out.append("pg:" + p)
        elif v == "preview":
            out.append("pv:" + p)
    return out


_TAG = re.compile(rb"<(/?)(table|tbody|tr)\b[^>]*>", re.I)
_ITEM = re.compile(rb"<(\w+)\b[^>]*\bdata-pv-item\b[^>]*>", re.I)
BANNER = (b'<div class="flash" style="margin:12px 0;padding:12px 16px;border-radius:10px;background:var(--brand-soft,#eef3fb)">'
          b'<b>Preview.</b> Your plan shows the first rows of this page. <a href="/app/upgrade">Upgrade or start a free trial</a> to see it all.</div>')



def _lock_row(more):
    return (b'<tr><td colspan="20" class="muted" style="text-align:center;padding:14px">' + str(more).encode() +
            b' more rows on paid plans. <a href="/app/upgrade">Upgrade</a></td></tr>')


def _trim_tables(html):
    """Keep the first PREVIEW_ROWS rows of every outermost table body. Depth-aware (1.7.9): a table nested inside a row (the
    bidder list on Past RFPs) goes with its row instead of ending the outer body early, which let most rows through."""
    out, pos, depth = [], 0, 0
    body = None  # [table depth, rows start..end spans]
    row_start, row_depth = None, None
    for m in _TAG.finditer(html):
        close, tag = m.group(1) == b"/", m.group(2).lower()
        if tag == b"table":
            depth += -1 if close else 1
            continue
        if tag == b"tbody" and depth == 1:
            if not close:
                body = []
            elif body is not None:
                if len(body) > PREVIEW_ROWS:
                    out.append(html[pos:body[PREVIEW_ROWS][0]])
                    out.append(_lock_row(len(body) - PREVIEW_ROWS))
                    pos = body[-1][1]
                body = None
            continue
        if tag == b"tr" and body is not None and depth == 1:
            if not close:
                row_start = m.start()
            elif row_start is not None:
                body.append((row_start, m.end()))
                row_start = None
    out.append(html[pos:])
    return b"".join(out)


def _trim_items(html):
    """Lists that are not tables (cards, collapsible rows) mark each entry with data-pv-item; keep the first PREVIEW_ROWS."""
    out, pos, n, cut = [], 0, 0, 0
    i = 0
    while True:
        m = _ITEM.search(html, i)
        if not m:
            break
        tag = m.group(1).lower()
        # find the matching close tag of the same name
        rx = re.compile(rb"<(/?)" + re.escape(tag) + rb"\b[^>]*>", re.I)
        d, end = 0, None
        for t in rx.finditer(html, m.start()):
            d += -1 if t.group(1) else 1
            if d == 0:
                end = t.end()
                break
        if end is None:
            break
        n += 1
        if n > PREVIEW_ROWS:
            out.append(html[pos:m.start()])
            pos = end
            cut += 1
        i = end
    if cut:
        out.append(b'<p class="muted small" style="text-align:center;padding:12px">' + str(cut).encode() +
                   b' more on paid plans. <a href="/app/upgrade">Upgrade</a></p>')
    out.append(html[pos:])
    return b"".join(out) if cut else html


def trim(html, cols_hint=8):
    html = _trim_items(_trim_tables(html))
    i = html.find(b'</h1>')
    if i >= 0:
        html = html[:i + 5] + BANNER + html[i + 5:]
    return html


class PageGateMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        path = scope.get("path", "") if scope["type"] == "http" else ""
        page = page_for(path) if path.startswith("/app/") else None
        uid = (scope.get("session") or {}).get("uid") if page else None
        if not uid:
            return await self.app(scope, receive, send)
        u = auth.load_user(uid)
        u = auth.view_as(u, scope.get("session"), path) if u else None
        if not u or u.is_admin:
            return await self.app(scope, receive, send)
        a = access(u.plan, path)
        if a == "none":
            return await RedirectResponse(f"/app/upgrade?locked={page}", status_code=303)(scope, receive, send)
        if a == "full" or page in NATURAL_PREVIEW or scope.get("method") != "GET":
            return await self.app(scope, receive, send)
        start, chunks = {}, []

        async def buf(msg):
            if msg["type"] == "http.response.start":
                start.update(msg)
                return
            if msg["type"] != "http.response.body":
                return await send(msg)
            chunks.append(msg.get("body", b""))
            if msg.get("more_body"):
                return
            body = b"".join(chunks)
            hdrs = [(k, v) for k, v in start.get("headers", []) if k.lower() != b"content-length"]
            ctype = dict(hdrs).get(b"content-type", b"")
            if b"text/html" in ctype and start.get("status") == 200:
                body = trim(body)
            elif start.get("status") == 200 and not b"text/html" in ctype:
                body, start["status"] = b"Downloads are on paid plans.", 403
                hdrs = [(b"content-type", b"text/plain")]
            hdrs.append((b"content-length", str(len(body)).encode()))
            await send({"type": "http.response.start", "status": start.get("status", 200), "headers": hdrs})
            await send({"type": "http.response.body", "body": body})
        await self.app(scope, receive, buf)
