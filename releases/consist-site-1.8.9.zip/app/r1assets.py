"""Freight Analytics Portal: every Class I railroad's STB Form R-1, CY2020 onward, organized by major asset class (locomotives,
freight cars, track and structures, signals and communications, facilities and work equipment) plus an overall cost and operating
summary. Admin-only while freight is parked (see lens.Scope.freight).

Data: seed/r1_cells.csv.gz holds every cell of R-1 Schedules 210, 330, 335, 410, 412, 415, 700, 710, 720 and 755 as filed (built by
fleet-db/tools/stb/r1_all/cells.py). It is loaded into the r1_cell table in app.db on first use, and reloaded when the seed changes.
A railroad is an operator_id summed over its R-1 entities (CPKC = Soo Line + KCSR, CN = Grand Trunk Corp.). R-1 dollars are
thousands; every metric below is a formula over (schedule, line, column) cells, so each number drills down to the cells behind it."""
import csv
import gzip
import hashlib
import html
import os
import threading

from . import db

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "r1_cells.csv.gz")
R1_URL = "https://www.stb.gov/reports-data/economic-data/annual-report-financial-data/"
IR = {  # investor relations sites and SEC filing indexes
    "BNSF": ("https://www.bnsf.com/about-bnsf/financial-information/", "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000934612&type=10-K"),
    "UNION_PACIFIC": ("https://investor.unionpacific.com/", "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000100885&type=10-K"),
    "CSX": ("https://investors.csx.com/", "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000277948&type=10-K"),
    "NORFOLK_SOUTHERN": ("https://norfolksouthern.investorroom.com/", "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000702165&type=10-K"),
    "CN_RAIL": ("https://www.cn.ca/en/investors/", "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000016868&type=40-F"),
    "CPKC": ("https://investor.cpkcr.com/", "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000016875&type=10-K"),
}
CURRENCY = {"CN_RAIL": "CAD", "CPKC": "CAD"}
RAILROADS = {
    "BNSF": ("BNSF", "BNSF Railway"),
    "UNION_PACIFIC": ("UP", "Union Pacific Railroad"),
    "CSX": ("CSX", "CSX Transportation"),
    "NORFOLK_SOUTHERN": ("NS", "Norfolk Southern Railway"),
    "CN_RAIL": ("CN", "CN US lines (Grand Trunk Corp.)"),
    "CPKC": ("CPKC", "CPKC US lines (Soo Line, KCSR)"),
}
COLORS = ["var(--c1)", "var(--c2)", "var(--c3)", "var(--c4)", "var(--c5)", "var(--c6, #7d5ba6)"]
SCHED = {"SEC": "SEC EDGAR XBRL, parent company annual report (10-K; CN files a 6-K)", "200": "Comparative statement of financial position (balance sheet)", "240": "Statement of cash flows", "EMP": "STB monthly employment report (annual average of mid-month headcount)", "210": "Results of operations", "330": "Road property and equipment (investment)", "335": "Accumulated depreciation",
         "410": "Railway operating expenses", "412": "Way and structures (depreciation by account)", "415": "Supporting schedule, equipment",
         "700": "Mileage operated", "710": "Inventory of equipment", "720": "Track and traffic conditions", "755": "Railroad operating statistics"}
COLS_410 = {"b": "salaries and wages", "c": "material, tools, supplies, fuel", "d": "purchased services", "e": "general", "f": "total freight"}
COLS_330 = {"b": "balance at start of year", "c": "new lines and extensions", "d": "existing lines acquired", "e": "additions and betterments",
            "f": "property retired", "g": "net change", "h": "balance at close of year"}

_lock = threading.Lock()
_mem = {}


# ---------- storage: r1_cell in app.db ----------
DDL = """CREATE TABLE IF NOT EXISTS r1_cell (
  operator_id TEXT, r1_entity TEXT, report_year INTEGER, sched TEXT, line INTEGER, col TEXT, value REAL, label TEXT,
  src_file TEXT, source_url TEXT, PRIMARY KEY (r1_entity, report_year, sched, line, col));
CREATE INDEX IF NOT EXISTS r1_cell_op ON r1_cell (operator_id, report_year, sched);"""


def _seed_sha():
    if not os.path.exists(SEED):
        return ""
    with open(SEED, "rb") as f:
        return hashlib.sha1(f.read()).hexdigest()[:12]


def ensure_loaded():
    """Create r1_cell and (re)load it from the seed when the seed file has changed. Returns the seed hash."""
    sha = _seed_sha()
    if _mem.get("sha") == sha:
        return sha
    with _lock:
        c = db.connect()
        c.executescript(DDL)
        have = c.execute("SELECT value FROM setting WHERE key = 'r1_seed_sha'").fetchone() if _has_setting(c) else None
        if sha and (not have or have[0] != sha):
            with gzip.open(SEED, "rt", newline="") as f:
                rows = [(r["operator_id"], r["r1_entity"], int(r["report_year"]), r["sched"], int(r["line"]), r["col"], float(r["value"]),
                         r["label"], r["src_file"], r["source_url"]) for r in csv.DictReader(f)]
            c.execute("DELETE FROM r1_cell")
            c.executemany("INSERT OR REPLACE INTO r1_cell VALUES (?,?,?,?,?,?,?,?,?,?)", rows)
            if _has_setting(c):
                c.execute("INSERT OR REPLACE INTO setting (key, value) VALUES ('r1_seed_sha', ?)", (sha,))
            c.commit()
        c.close()
        _mem.clear()
        _mem["sha"] = sha
    return sha


def _has_setting(c):
    return bool(c.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'setting'").fetchone())


def _cells():
    """{(op, year): {(sched, line, col): value}} summed over entities, plus labels and sources."""
    ensure_loaded()
    if "cells" in _mem:
        return _mem
    data, labels, src = {}, {}, {}
    for r in db.q("SELECT operator_id, r1_entity, report_year, sched, line, col, value, label, src_file, source_url FROM r1_cell"):
        k = (r["sched"], r["line"], r["col"])
        d = data.setdefault((r["operator_id"], r["report_year"]), {})
        d[k] = d.get(k, 0) + r["value"]
        if r["label"]:
            labels.setdefault((r["sched"], r["line"]), r["label"])
        src.setdefault((r["operator_id"], r["report_year"]), {})[r["r1_entity"]] = (r["src_file"], r["source_url"])
    _mem.update(cells=data, labels=labels, src=src,
                years=sorted({y for _, y in data}), ids=[o for o in RAILROADS if any(op == o for op, _ in data)])
    return _mem


# ---------- formulas ----------
def T(sched, lines, col, sign=1):
    """Terms for a list of lines (ints or ranges) in one column."""
    out = []
    for ln in (lines if isinstance(lines, (list, tuple)) else [lines]):
        out += [(sched, x, col, sign) for x in (ln if isinstance(ln, range) else [ln])]
    return out


def CAPEX(lines):  # Sched. 330 spending in the year: new lines (c) + acquired lines (d) + additions and betterments (e)
    return T("330", lines, "c") + T("330", lines, "d") + T("330", lines, "e")


def total(op, y, terms):
    d = _cells()["cells"].get((op, y))
    if not d:
        return None
    vals = [(d.get((s, ln, c)), sg) for s, ln, c, sg in terms]
    if all(v is None for v, _ in vals) or any(v is None and t[0] == "SEC" for (v, _), t in zip(vals, terms)):
        return None  # company-reported formulas need every input (e.g. BNSF reports no capex tag)
    return sum((v or 0) * sg for v, sg in vals)


M = {}


def metric(key, label, fmt, num, den=None, scale=1.0, definition="", better=None):
    """fmt: musd ($ thousands shown as $M), usd (whole dollars), int, pct, 1 (one decimal). scale multiplies num/den."""
    if isinstance(den, str):  # metric(key, label, fmt, num, "definition")
        den, definition = None, den
    M[key] = dict(key=key, label=label, fmt=fmt, num=num, den=den, scale=scale, definition=definition, better=better)


def value(key, op, y):
    m = M[key]
    n = total(op, y, m["num"])
    if m["den"] is None:
        return _rail_dollars(m, n, y)
    d = total(op, y, m["den"])
    return _rail_dollars(m, n * m["scale"] / d, y) if n is not None and d else None


def _rail_dollars(m, v, y):
    """In rail-cost dollars mode (rail portal dollar switch) restate money amounts in 2025 railroad input prices (RCAF).
    Money ratios (pct, 1, 2) are unitless and not touched. 10-K amounts of CAD reporters are left as filed."""
    if v is None or m["fmt"] not in ("musd", "usd") or m.get("currency_mixed"):
        return v
    from . import costidx
    if costidx.basis() != "rcaf":
        return v
    f = costidx.deflator(y)
    return v * f if f else v


def fmt(key, v):
    if v is None:
        return "–"
    f = M[key]["fmt"]
    if f == "musd":
        return f"${v / 1e6:,.2f}B" if abs(v) >= 1e6 else f"${v / 1000:,.1f}M"
    if f == "usd":
        return f"${v:,.0f}" if abs(v) >= 10 else f"${v:,.2f}"
    if f == "pct":
        return f"{v:.1f}%"
    if f == "1":
        return f"{v:,.1f}"
    if f == "2":
        return f"{v:,.2f}"
    return f"{v:,.0f}"


# Shared building blocks (Sched. 410 col f = freight total, $000)
OPEX = T("410", 620, "f")
REV = T("210", [14, 15], "b")     # operating expenses + net revenue from operations (Soo Line leaves line 13 unnumbered)
GTM_K = T("755", 104, "b")          # gross ton-miles, thousands
ROUTE_MI = T("755", 1, "b")         # miles of road operated
TRACK_MI = T("720", 6, "b")         # track miles (Sched. 720 total)
LOCOS = T("710", 5, "j")            # diesel locomotives in service, year end
CARS = T("710", 55, "k")            # freight train cars in service, year end
CAR_MI_K = T("755", 88, "b")        # freight car-miles, thousands
LUM = T("755", 14, "b")             # locomotive unit-miles

W_TRACK = T("410", [range(6, 8), range(12, 18)], "f")                      # roadway, ties, rail, ballast
W_STRUCT = T("410", [range(8, 12)], "f")                                     # tunnels, bridges, culverts
W_XING = T("410", [25, 26], "f")
W_SIG = T("410", [3, 21, 22], "f")
W_COMM = T("410", [4, 23, 24], "f")
W_FAC = T("410", [27, 28, 29, 30, range(101, 109)], "f")
W_TOOLS = T("410", [109, 110, 111], "f")
LOCO_OPEX = T("410", 219, "f")
FUEL = T("410", [409, 425], "f")
CAR_OPEX = T("410", 238, "f")
OTHER_EQ = T("410", 323, "f")

# ----- overview -----
metric("revenue", "Operating revenue", "musd", REV, definition="Total railway operating revenues: Sched. 210 line 14 (operating expenses) + line 15 (net revenue from railway operations), which equals line 13.")
metric("opex", "Operating expense (freight)", "musd", OPEX, definition="Total carrier operating expense, freight, Sched. 410 line 620 col (f).", better="low")
metric("op_ratio", "Operating ratio (R-1)", "pct", T("210", 14, "b"), REV, 100,
       "Railway operating expenses / operating revenues, Sched. 210 line 14 / (lines 14 + 15). US operations as filed, so it differs from the company-wide figure.", "low")
metric("net_income", "Net income", "musd", T("210", 61, "b"), definition="Net income, Sched. 210 line 61.", better="high")
metric("opex_ws", "Way and structures", "musd", T("410", 151, "f"), definition="Total way and structures expense, Sched. 410 line 151.")
metric("opex_eq", "Equipment", "musd", T("410", 324, "f"), definition="Total equipment expense, Sched. 410 line 324.")
metric("opex_tr", "Transportation", "musd", T("410", 528, "f"), definition="Total transportation expense, Sched. 410 line 528.")
metric("opex_ga", "General and administrative", "musd", T("410", 619, "f"), definition="Total general and administrative, Sched. 410 line 619.")
metric("opex_labor", "Salaries and wages", "musd", T("410", 620, "b"), definition="Sched. 410 line 620 col (b).")
metric("opex_material", "Material, tools, supplies, fuel", "musd", T("410", 620, "c"), definition="Sched. 410 line 620 col (c).")
metric("opex_services", "Purchased services", "musd", T("410", 620, "d"), definition="Sched. 410 line 620 col (d).")
metric("opex_general", "General (incl. depreciation, rents)", "musd", T("410", 620, "e"), definition="Sched. 410 line 620 col (e).")
metric("capex", "Capital spending", "musd", CAPEX([43]),
       "Sched. 330 grand total (line 43): new lines (c) + lines acquired (d) + additions and betterments (e).")
metric("capex_road", "Capital spending, road", "musd", CAPEX([30]), definition="Sched. 330 line 30, cols (c)+(d)+(e).")
metric("capex_eq", "Capital spending, equipment", "musd", CAPEX([39]), definition="Sched. 330 line 39, cols (c)+(d)+(e).")
metric("capex_to_rev", "Capital spending / revenue", "pct", CAPEX([43]), REV, 100, "Sched. 330 line 43 (c+d+e) / Sched. 210 line 13.")
metric("gross_invest", "Gross investment, road and equipment", "musd", T("330", 43, "h"), definition="Sched. 330 line 43, balance at close (h).")
metric("net_book_ratio", "Accumulated depreciation / gross investment", "pct", T("335", 41, "g"), T("330", 43, "h"), 100,
       "Sched. 335 line 41 col (g) / Sched. 330 line 43 col (h). Higher means an older, more depreciated asset base.")
metric("opex_per_kgtm", "Operating expense per 1,000 GTM", "usd", OPEX, GTM_K, 1000,
       "Sched. 410 line 620 ($000) x 1,000 / Sched. 755 line 104 gross ton-miles (thousands).", "low")
metric("route_miles", "Miles of road operated", "int", ROUTE_MI, definition="Sched. 755 line 1.")
metric("opex_per_route_mile", "Operating expense per mile of road", "usd", OPEX, ROUTE_MI, 1000, "Sched. 410 line 620 / Sched. 755 line 1.", "low")

# ----- locomotives -----
metric("loco_units", "Locomotives in service", "int", LOCOS, definition="Diesel units in service at year end, Sched. 710 line 5 col (j).")
metric("loco_opex", "Locomotive expense", "musd", LOCO_OPEX, definition="Total locomotives, Sched. 410 line 219 (repairs, depreciation, rents, other).")
metric("loco_repair", "Locomotive repair and maintenance", "musd", T("410", [202, 203], "f"), definition="Sched. 410 lines 202-203.")
metric("loco_dep", "Locomotive depreciation", "musd", T("410", 213, "f"), definition="Sched. 410 line 213.")
metric("loco_lease", "Locomotive lease rentals (net)", "musd", T("410", 207, "f") + T("410", 208, "f"), definition="Sched. 410 lines 207-208.")
metric("fuel", "Locomotive fuel", "musd", FUEL, definition="Train and yard locomotive fuel, Sched. 410 lines 409 and 425.")
metric("loco_opex_per_unit", "Locomotive expense per unit", "usd", LOCO_OPEX, LOCOS, 1000, "Sched. 410 line 219 / Sched. 710 line 5 (j).", "low")
metric("loco_repair_per_unit", "Repairs per locomotive", "usd", T("410", [202, 203], "f"), LOCOS, 1000, "Sched. 410 lines 202-203 / units in service.", "low")
metric("loco_cost_per_lum", "Locomotive cost per unit-mile", "2", LOCO_OPEX + FUEL, LUM, 1000,
       "(Sched. 410 line 219 + fuel lines 409, 425) / locomotive unit-miles, Sched. 755 line 14.", "low")
metric("loco_miles_per_unit", "Miles per locomotive", "int", LUM, LOCOS, 1, "Sched. 755 line 14 / Sched. 710 line 5 (j).", "high")
metric("loco_capex", "Locomotive capital spending", "musd", CAPEX([31]), definition="Sched. 330 line 31, cols (c)+(d)+(e).")
metric("loco_invest", "Gross investment, locomotives", "musd", T("330", 31, "h"), definition="Sched. 330 line 31 balance at close.")
metric("loco_depr_ratio", "Locomotives: accumulated depreciation / investment", "pct", T("335", 31, "g"), T("330", 31, "h"), 100,
       "Sched. 335 line 31 (g) / Sched. 330 line 31 (h).")
metric("fuel_per_kgtm", "Fuel cost per 1,000 GTM", "usd", FUEL, GTM_K, 1000, "Fuel lines 409, 425 / gross ton-miles.", "low")

# ----- freight cars -----
metric("car_units", "Freight cars in service", "int", CARS, definition="Freight train cars in service at year end, Sched. 710 line 55 col (k).")
metric("car_owned", "Cars owned", "int", T("710", 55, "i"), definition="Sched. 710 line 55 col (i).")
metric("car_leased", "Cars leased", "int", T("710", 55, "j"), definition="Sched. 710 line 55 col (j).")
metric("car_opex", "Freight car expense", "musd", CAR_OPEX, definition="Total freight cars, Sched. 410 line 238 (repairs, depreciation, car hire and lease, other).")
metric("car_repair", "Car repair and maintenance", "musd", T("410", [221, 222], "f"), definition="Sched. 410 lines 221-222.")
metric("car_dep", "Car depreciation", "musd", T("410", 232, "f"), definition="Sched. 410 line 232.")
metric("car_rents", "Car hire, leases and rents (net)", "musd", T("410", range(226, 232), "f"), definition="Sched. 410 lines 226-231.")
metric("car_opex_per_car", "Freight car expense per car", "usd", CAR_OPEX, CARS, 1000, "Sched. 410 line 238 / Sched. 710 line 55 (k).", "low")
metric("car_repair_per_car", "Repairs per car", "usd", T("410", [221, 222], "f"), CARS, 1000, "Sched. 410 lines 221-222 / cars in service.", "low")
metric("car_cost_per_carmile", "Car expense per car-mile", "2", CAR_OPEX, CAR_MI_K, 1, "Sched. 410 line 238 ($000) / car-miles (thousands), Sched. 755 line 88.", "low")
metric("car_miles_per_car", "Miles per car", "int", CAR_MI_K, CARS, 1000, "Car-miles (Sched. 755 line 88) / cars in service.", "high")
metric("car_capex", "Freight car capital spending", "musd", CAPEX([32]), definition="Sched. 330 line 32, cols (c)+(d)+(e).")
metric("car_invest", "Gross investment, freight cars", "musd", T("330", 32, "h"), definition="Sched. 330 line 32 balance at close.")
metric("car_depr_ratio", "Cars: accumulated depreciation / investment", "pct", T("335", 32, "g"), T("330", 32, "h"), 100, "Sched. 335 line 32 / Sched. 330 line 32.")

# ----- track and structures -----
metric("track_miles", "Track miles", "int", TRACK_MI, definition="Total track miles, Sched. 720 line 6.")
metric("ws_opex", "Way and structures expense", "musd", T("410", 151, "f"), definition="Total way and structures, Sched. 410 line 151 (includes signals, communications and facilities).")
metric("track_opex", "Track maintenance (roadway, ties, rail, ballast)", "musd", W_TRACK, definition="Sched. 410 lines 6-7 and 12-17.")
metric("struct_opex", "Bridges, tunnels and culverts", "musd", W_STRUCT, definition="Sched. 410 lines 8-11.")
metric("xing_opex", "Highway grade crossings", "musd", W_XING, definition="Sched. 410 lines 25-26.")
metric("ws_dep", "Road depreciation", "musd", T("410", range(136, 139), "f"), definition="Sched. 410 lines 136-138.")
metric("track_opex_per_tm", "Track maintenance per track mile", "usd", W_TRACK, TRACK_MI, 1000, "Sched. 410 lines 6-7, 12-17 / Sched. 720 track miles.", "low")
metric("ws_per_kgtm", "Way and structures per 1,000 GTM", "usd", T("410", 151, "f"), GTM_K, 1000, "Sched. 410 line 151 / gross ton-miles.", "low")
metric("track_capex", "Track capital (ties, rail, ballast)", "musd", CAPEX([7, 8, 9]), definition="Sched. 330 lines 7-9, cols (c)+(d)+(e).")
metric("ties_capex", "Ties capital", "musd", CAPEX([7]), definition="Sched. 330 line 7.")
metric("rail_capex", "Rail and track material capital", "musd", CAPEX([8]), definition="Sched. 330 line 8.")
metric("ballast_capex", "Ballast capital", "musd", CAPEX([9]), definition="Sched. 330 line 9.")
metric("struct_capex", "Bridges, tunnels, grading capital", "musd", CAPEX([2, 3, 4, 5, 6]), definition="Sched. 330 lines 2-6.")
metric("track_capex_per_tm", "Track capital per track mile", "usd", CAPEX([7, 8, 9]), TRACK_MI, 1000, "Sched. 330 lines 7-9 / track miles.")
metric("track_depr_ratio", "Track: accumulated depreciation / investment", "pct", T("335", [6, 7, 8], "g"), T("330", [7, 8, 9], "h"), 100,
       "Sched. 335 lines 6-8 / Sched. 330 lines 7-9 (ties, rail, ballast).")
metric("track_invest", "Gross investment, ties, rail and ballast", "musd", T("330", [7, 8, 9], "h"), definition="Sched. 330 lines 7-9 balance at close.")

# ----- signals and communications -----
metric("sig_opex", "Signals and interlockers maintenance", "musd", W_SIG, definition="Sched. 410 lines 3, 21-22.")
metric("comm_opex", "Communications and power systems", "musd", W_COMM, definition="Sched. 410 lines 4, 23-24.")
metric("sig_ops", "Operating signals, interlockers, crossings", "musd", T("410", [405, 407, 424], "f"),
       definition="Transportation: operating signals and interlockers (405), highway crossing protection (407), yard switches and retarders (424).")
metric("sc_opex_per_rm", "Signal and comms maintenance per mile of road", "usd", W_SIG + W_COMM, ROUTE_MI, 1000, "Sched. 410 lines 3-4, 21-24 / miles of road.", "low")
metric("sig_capex", "Signals and interlockers capital", "musd", CAPEX([21]), definition="Sched. 330 line 21.")
metric("comm_capex", "Communications capital", "musd", CAPEX([20, 23]), definition="Sched. 330 lines 20 and 23.")
metric("sc_capex_per_rm", "Signal and comms capital per mile of road", "usd", CAPEX([20, 21, 23]), ROUTE_MI, 1000, "Sched. 330 lines 20, 21, 23 / miles of road.")
metric("sc_invest", "Gross investment, signals and communications", "musd", T("330", [20, 21, 23], "h"), definition="Sched. 330 lines 20, 21, 23 balance at close.")
metric("sc_depr_ratio", "Signals and comms: accumulated depreciation / investment", "pct", T("335", [19, 20, 22], "g"), T("330", [20, 21, 23], "h"), 100,
       "Sched. 335 lines 19, 20, 22 / Sched. 330 lines 20, 21, 23.")

# ----- facilities and work equipment -----
metric("fac_opex", "Buildings, shops and terminals", "musd", W_FAC,
       definition="Sched. 410 lines 27-30 (stations, offices, shops) and 101-108 (servicing facilities, misc. structures, coal, ore, marine, intermodal, auto and other terminals).")
metric("tools_opex", "Roadway machines, tools, snow removal", "musd", W_TOOLS, definition="Sched. 410 lines 109-111.")
metric("other_eq_opex", "Other equipment (work, highway, computers, machinery)", "musd", OTHER_EQ, definition="Total other equipment, Sched. 410 line 323.")
metric("shops_opex", "Shop buildings", "musd", T("410", [28, 29, 30, 101], "f"), definition="Sched. 410 lines 28-30 and 101 (shops and locomotive servicing).")
metric("terminal_opex", "Terminals (coal, ore, marine, intermodal, auto)", "musd", T("410", range(103, 109), "f"), definition="Sched. 410 lines 103-108.")
metric("fac_capex", "Facilities capital", "musd", CAPEX([11, 12, 13, 14, 15, 16, 17, 18, 19, 22, 24]),
       definition="Sched. 330 lines 11-19, 22, 24 (buildings, fuel and water stations, shops, warehouses, docks, terminals, power plants).")
metric("machines_capex", "Roadway and shop machinery capital", "musd", CAPEX([25, 27, 28]), definition="Sched. 330 lines 25, 27, 28.")
metric("work_eq_capex", "Work, misc. and computer equipment capital", "musd", CAPEX([36, 37, 38]), definition="Sched. 330 lines 36-38.")
metric("tofc_capex", "Intermodal (TOFC/COFC) terminal capital", "musd", CAPEX([19]), definition="Sched. 330 line 19.")
metric("fac_invest", "Gross investment, facilities", "musd", T("330", [11, 12, 13, 14, 15, 16, 17, 18, 19, 22, 24], "h"), definition="Sched. 330 lines 11-19, 22, 24 balance at close.")

# ----- labor (STB employment reports + Sched. 410 wages) -----
EMP = T("EMP", [100, 200, 300, 400, 500, 600], "a")
EMP_MW, EMP_ME, EMP_TE = T("EMP", 300, "a"), T("EMP", 400, "a"), T("EMP", 600, "a")
EMP_TR = T("EMP", [500, 600], "a")
EMP_MGT = T("EMP", [100, 200], "a")
WAGES = T("410", 620, "b")
FRINGE = T("410", [112, 113, 114, 205, 224, 309, 414, 430, 505, 512, 522, 611], "f")
TRAIN_MI = T("755", 5, "b")
metric("employees", "Employees (annual average)", "int", EMP, definition="Average of mid-month headcount, all six STB employee groups (100-600).")
metric("emp_te", "Train and engine employees", "int", EMP_TE, definition="STB employee group 600.")
metric("emp_mw", "Maintenance of way employees", "int", EMP_MW, definition="STB employee group 300.")
metric("emp_me", "Maintenance of equipment employees", "int", EMP_ME, definition="STB employee group 400.")
metric("emp_mgt", "Executives, professional and admin", "int", EMP_MGT, definition="STB employee groups 100 and 200.")
metric("emp_ops_other", "Transportation, other than T&E", "int", T("EMP", 500, "a"), definition="STB employee group 500 (dispatchers, yardmasters, clerks).")
metric("wages", "Salaries and wages", "musd", WAGES, definition="Sched. 410 line 620 col (b).")
metric("fringe", "Fringe benefits", "musd", FRINGE, definition="Fringe benefit lines of Sched. 410 (112-114, 205, 224, 309, 414, 430, 505, 512, 522, 611), col (f).")
metric("comp_share", "Wages and benefits / operating expense", "pct", T("410", 620, "b") + FRINGE, OPEX, 100, "(Sched. 410 line 620 col b + fringe lines) / line 620 col f.", "low")
metric("wage_per_emp", "Wages per employee", "usd", WAGES, EMP, 1000, "Sched. 410 line 620 (b) / average employees.")
metric("comp_per_emp", "Wages and benefits per employee", "usd", T("410", 620, "b") + FRINGE, EMP, 1000, "(Wages + fringe benefits) / average employees.")
metric("rev_per_emp", "Revenue per employee", "usd", REV, EMP, 1000, "Sched. 210 revenue / average employees.", "high")
metric("mgtm_per_emp", "Gross ton-miles per employee (millions)", "1", GTM_K, EMP, 0.001, "Sched. 755 line 104 / average employees.", "high")
metric("te_per_mtm", "T&E employees per million train-miles", "1", EMP_TE, TRAIN_MI, 1e6, "STB group 600 / Sched. 755 line 5 train-miles.", "low")
metric("mw_per_100tm", "MofW employees per 100 track miles", "2", EMP_MW, TRACK_MI, 100, "STB group 300 / Sched. 720 track miles x 100.", "low")
metric("ws_wage_per_mw", "Way and structures wages per MofW employee", "usd", T("410", 151, "b"), EMP_MW, 1000,
       "Sched. 410 line 151 (b) / STB group 300. Approximate: some W&S wages are paid to other crafts.")
metric("me_per_100_units", "MofE employees per 100 locomotives and 1,000 cars", "2", EMP_ME, LOCOS + [(s, l, c, 0.1) for s, l, c, _ in CARS], 100,
       "STB group 400 / (locomotives + cars / 10) x 100. A rough maintenance-intensity index.", "low")
metric("tr_wage_per_tr", "Transportation wages per transportation employee", "usd", T("410", 528, "b"), EMP_TR, 1000, "Sched. 410 line 528 (b) / STB groups 500 + 600.")
metric("mgt_share", "Executives, professional and admin share", "pct", EMP_MGT, EMP, 100, "STB groups 100 + 200 / all employees.", "low")
metric("wages_ws", "Way and structures wages", "musd", T("410", 151, "b"), definition="Sched. 410 line 151 (b).")
metric("wages_eq", "Equipment wages", "musd", T("410", 324, "b"), definition="Sched. 410 line 324 (b).")
metric("wages_tr", "Transportation wages", "musd", T("410", 528, "b"), definition="Sched. 410 line 528 (b).")
metric("wages_ga", "G&A wages", "musd", T("410", 619, "b"), definition="Sched. 410 line 619 (b).")

# ----- financial statements (GAAP-style, Sched. 200 balance sheet, 210 income statement, 240 cash flows) -----
B = lambda lines: T("200", lines, "b")  # balance at close of year
OPINC = T("210", 15, "b")
NI = T("210", 61, "b")
DA = T("240", 12, "b")
DEBT = B([38, 40, 41, 42])
EQUITY = B(62)
ASSETS = B(28)
CFO = T("240", [range(10, 19), 20], "b")  # components of line 21 (some filings leave the subtotal blank)
CAPEX_CF = T("240", 23, "b")
metric("is_revenue", "Operating revenues", "musd", REV, definition="Sched. 210 lines 14 + 15 (equals line 13).")
metric("is_freight_rev", "Freight revenue", "musd", T("210", 1, "b"), definition="Sched. 210 line 1 (account 101).")
metric("is_opex", "Operating expenses", "musd", T("210", 14, "b"), definition="Sched. 210 line 14 (account 531).", better="low")
metric("is_opinc", "Operating income", "musd", OPINC, definition="Net revenue from railway operations, Sched. 210 line 15.", better="high")
metric("is_other_inc", "Other income", "musd", T("210", 27, "b"), definition="Total other income, Sched. 210 line 27.")
metric("is_fixed", "Interest and fixed charges", "musd", T("210", 42, "b"), definition="Total fixed charges, Sched. 210 line 42.", better="low")
metric("is_pretax", "Income before income taxes", "musd", T("210", 46, "b"), definition="Income from continuing operations before taxes, Sched. 210 line 46.")
metric("is_tax", "Income taxes", "musd", T("210", 51, "b"), definition="Total provision for income taxes, Sched. 210 line 51.")
metric("is_ni", "Net income", "musd", NI, definition="Sched. 210 line 61.", better="high")
metric("is_ebitda", "EBITDA", "musd", OPINC + DA, definition="Operating income (210 line 15) + depreciation and amortization (240 line 12).", better="high")
metric("is_op_margin", "Operating margin", "pct", OPINC, REV, 100, "Operating income / operating revenues.", "high")
metric("is_net_margin", "Net margin", "pct", NI, REV, 100, "Net income / operating revenues.", "high")
metric("is_ebitda_margin", "EBITDA margin", "pct", OPINC + DA, REV, 100, "EBITDA / operating revenues.", "high")
metric("is_tax_rate", "Effective tax rate", "pct", T("210", 51, "b"), T("210", 46, "b"), 100, "Sched. 210 line 51 / line 46.")
metric("bs_cash", "Cash and temporary investments", "musd", B([1, 2]), definition="Sched. 200 lines 1-2.")
metric("bs_cur_assets", "Total current assets", "musd", B(14), definition="Sched. 200 line 14.")
metric("bs_net_pp", "Net road and equipment (PP&E)", "musd", B(27), definition="Sched. 200 line 27 (investment less accumulated depreciation).")
metric("bs_other_assets", "Investments and other assets", "musd", B(22), definition="Sched. 200 line 22.")
metric("bs_assets", "Total assets", "musd", ASSETS, definition="Sched. 200 line 28.")
metric("bs_cur_liab", "Total current liabilities", "musd", B(39), definition="Sched. 200 line 39.")
metric("bs_debt", "Debt (incl. current portion and leases)", "musd", DEBT, definition="Sched. 200 lines 38, 40-42: current portion, funded debt, equipment obligations, capital leases. Excludes payables to affiliates (line 44).")
metric("bs_affil", "Payables to affiliates, non-current", "musd", B(44), definition="Sched. 200 line 44. Large for subsidiaries of holding companies.")
metric("bs_deferred_tax", "Deferred income taxes", "musd", B(48), definition="Sched. 200 line 48.")
metric("bs_noncur_liab", "Total non-current liabilities", "musd", B(50), definition="Sched. 200 line 50.")
metric("bs_equity", "Total equity", "musd", EQUITY, definition="Sched. 200 line 62.")
metric("bs_retained", "Retained earnings", "musd", B([56, 57]), definition="Sched. 200 lines 56-57.")
metric("cf_cfo", "Cash from operations", "musd", CFO, definition="Sched. 240 lines 10-18 and 20 (= line 21).", better="high")
metric("cf_capex", "Capital expenditures (cash)", "musd", [(a, b, c, -1) for a, b, c, _ in CAPEX_CF], definition="Sched. 240 line 23, shown as a positive number.")
metric("cf_fcf", "Free cash flow", "musd", CFO + CAPEX_CF + T("240", 22, "b"), definition="Cash from operations + capex (negative) + property sale proceeds, Sched. 240 lines 21, 23, 22.", better="high")
metric("cf_invest", "Cash used in investing", "musd", T("240", 29, "b"), definition="Sched. 240 line 29.")
metric("cf_financing", "Cash from (used in) financing", "musd", T("240", 36, "b"), definition="Sched. 240 line 36.")
metric("cf_dividends", "Dividends paid", "musd", [(a, b, c, -1) for a, b, c, _ in T("240", 34, "b")], definition="Sched. 240 line 34, as a positive number (paid to the parent for subsidiaries).")
metric("r_roa", "Return on assets", "pct", NI, ASSETS, 100, "Net income / year-end total assets.", "high")
metric("r_roe", "Return on equity", "pct", NI, EQUITY, 100, "Net income / year-end total equity.", "high")
metric("r_current", "Current ratio", "2", B(14), B(39), 1, "Current assets / current liabilities.", "high")
metric("r_debt_equity", "Debt / equity", "2", DEBT, EQUITY, 1, "Debt (Sched. 200 lines 38, 40-42) / total equity.", "low")
metric("r_debt_ebitda", "Debt / EBITDA", "2", DEBT, OPINC + DA, 1, "Debt / EBITDA.", "low")
metric("r_asset_turn", "Asset turnover", "2", REV, ASSETS, 1, "Operating revenues / total assets.", "high")
metric("r_cfo_margin", "Cash from operations / revenue", "pct", CFO, REV, 100, "Sched. 240 line 21 / revenues.", "high")
metric("r_fcf_conv", "Free cash flow / net income", "pct", CFO + CAPEX_CF + T("240", 22, "b"), NI, 100, "Free cash flow / net income.", "high")

# ----- investor reporting (parent-company 10-K figures from SEC XBRL; CN and CPKC report in CAD) -----
X = lambda n: T("SEC", n, "a")
XREV, XOPINC, XNI, XDA, XEQ, XCFO, XCAPEX = X(1), X(3), X(7), X(9), X(16), X(17), X(18)
XDEBT = X([14, 15])
def inv(key, label, fmt, num, den=None, scale=1.0, definition="", better=None):
    metric(key, label, fmt, num, den, scale, definition, better)
    M[key]["currency_mixed"] = den is None and fmt == "musd"
inv("x_revenue", "Revenue", "musd", XREV, definition="Total revenues, parent-company annual report.")
inv("x_opex", "Operating expenses", "musd", [(a, b, c, 1) for a, b, c, _ in XREV] + [(a, b, c, -1) for a, b, c, _ in XOPINC], definition="Revenue less operating income.")
inv("x_opinc", "Operating income", "musd", XOPINC, definition="Operating income, annual report.")
inv("x_ni", "Net income", "musd", XNI, definition="Net income attributable to the company, annual report.")
inv("x_eps", "Diluted EPS", "2", X(8), definition="Diluted earnings per share (BNSF is privately held by Berkshire Hathaway, so no EPS).")
inv("x_ebitda", "EBITDA", "musd", XOPINC + XDA, definition="Operating income + depreciation and amortization.")
inv("x_assets", "Total assets", "musd", X(11), definition="Year end.")
inv("x_debt", "Total debt", "musd", XDEBT, definition="Long-term debt plus debt due within one year, year end.")
inv("x_equity", "Shareholders' equity", "musd", XEQ, definition="Year end.")
inv("x_cfo", "Cash from operations", "musd", XCFO, definition="Annual report cash flow statement.")
inv("x_capex", "Capital expenditures", "musd", XCAPEX, definition="Cash paid for property and equipment.")
inv("x_fcf", "Free cash flow", "musd", XCFO + [(a, b, c, -1) for a, b, c, _ in XCAPEX], definition="Cash from operations less capital expenditures.")
inv("x_dividends", "Dividends paid", "musd", X(19), definition="Cash dividends to shareholders.")
inv("x_buybacks", "Share repurchases", "musd", X(20), definition="Cash paid to repurchase shares.")
inv("x_or", "Operating ratio", "pct", [(a, b, c, 1) for a, b, c, _ in XREV] + [(a, b, c, -1) for a, b, c, _ in XOPINC], XREV, 100, "(Revenue - operating income) / revenue, company-wide.", "low")
inv("x_op_margin", "Operating margin", "pct", XOPINC, XREV, 100, "Operating income / revenue.", "high")
inv("x_net_margin", "Net margin", "pct", XNI, XREV, 100, "Net income / revenue.", "high")
inv("x_roe", "Return on equity", "pct", XNI, XEQ, 100, "Net income / year-end equity.", "high")
inv("x_debt_ebitda", "Debt / EBITDA", "2", XDEBT, XOPINC + XDA, 1, "Total debt / EBITDA.", "low")
inv("x_capex_rev", "Capex / revenue", "pct", XCAPEX, XREV, 100, "Capital expenditures / revenue.")
inv("x_payout", "Shareholder returns / net income", "pct", X([19, 20]), XNI, 100, "(Dividends + buybacks) / net income.")
inv("x_r1_share", "R-1 US railroad share of company revenue", "pct", REV, XREV, 100,
    "R-1 operating revenue / parent revenue. Only meaningful in the same currency, so CN and CPKC are shown but compare USD R-1 to CAD totals.")

MODULES = {
    "overview": dict(title="Cost and operating summary", short="Summary",
                     blurb="Revenue, operating expense by function and by type, capital spending and the asset base, for each Class I railroad's US operations.",
                     tiles=["revenue", "opex", "op_ratio", "capex", "opex_per_kgtm", "net_book_ratio"],
                     table=["revenue", "opex", "op_ratio", "net_income", "capex", "capex_to_rev", "opex_per_kgtm", "opex_per_route_mile", "route_miles"],
                     mix=("Where operating expense goes", ["opex_ws", "opex_eq", "opex_tr", "opex_ga"]),
                     mix2=("Operating expense by type", ["opex_labor", "opex_material", "opex_services", "opex_general"]),
                     chart="op_ratio"),
    "investor": dict(title="Investor reporting (10-K)", short="Investor reporting",
                     blurb="What each parent company reports to investors in its annual report: income statement, balance sheet, cash flow and shareholder returns, from SEC XBRL filings. Unlike R-1 these are whole-company figures, including debt held at the parent. CN and CPKC report in Canadian dollars, so their money amounts are CAD and no Class I total is shown for money amounts.",
                     tiles=["x_or", "x_op_margin", "x_roe", "x_debt_ebitda", "x_capex_rev", "x_payout"],
                     table=["x_or", "x_op_margin", "x_net_margin", "x_roe", "x_debt_ebitda", "x_capex_rev", "x_payout", "x_eps"],
                     statements=[("Income statement (company reported)", ["x_revenue", "x_opex", "x_opinc", "x_ebitda", "x_ni", "x_eps"]),
                                 ("Balance sheet and cash flow (company reported)", ["x_assets", "x_debt", "x_equity", "x_cfo", "x_capex", "x_fcf", "x_dividends", "x_buybacks"])],
                     ir=True, chart="x_or"),
    "financials": dict(title="Financial statements", short="Financials",
                       blurb="Income statement, balance sheet and cash flows on GAAP lines as each railroad files them in R-1 (Schedules 210, 200 and 240), with margin, return, leverage and cash ratios. R-1 is the US railroad subsidiary, not the listed parent, so debt and equity differ from the 10-K.",
                       tiles=["is_revenue", "is_opinc", "is_ni", "cf_fcf", "r_roe", "r_debt_ebitda"],
                       table=["is_op_margin", "is_ebitda_margin", "is_net_margin", "r_roa", "r_roe", "r_debt_equity", "r_debt_ebitda", "r_current", "r_cfo_margin", "r_fcf_conv"],
                       statements=[("Income statement", ["is_revenue", "is_freight_rev", "is_opex", "is_opinc", "is_other_inc", "is_fixed", "is_pretax", "is_tax", "is_ni", "is_ebitda", "is_tax_rate"]),
                                   ("Balance sheet (year end)", ["bs_cash", "bs_cur_assets", "bs_other_assets", "bs_net_pp", "bs_assets", "bs_cur_liab", "bs_debt", "bs_affil", "bs_deferred_tax", "bs_noncur_liab", "bs_equity", "bs_retained"]),
                                   ("Cash flows", ["cf_cfo", "cf_capex", "cf_fcf", "cf_invest", "cf_financing", "cf_dividends"])],
                       mix=("Balance sheet: how assets are funded", ["bs_cur_liab", "bs_debt", "bs_affil", "bs_deferred_tax", "bs_equity"]), chart="is_op_margin"),
    "locomotives": dict(title="Locomotives", short="Locomotives",
                        blurb="Locomotive expense, fuel, fleet size, use and capital. The locomotive duty-cycle and rebuild analysis is in the locomotive portal.",
                        tiles=["loco_units", "loco_opex", "fuel", "loco_cost_per_lum", "loco_capex", "loco_depr_ratio"],
                        table=["loco_units", "loco_miles_per_unit", "loco_opex", "loco_opex_per_unit", "loco_repair_per_unit", "fuel", "fuel_per_kgtm", "loco_cost_per_lum", "loco_capex"],
                        mix=("Locomotive expense", ["loco_repair", "loco_dep", "loco_lease"]), chart="loco_cost_per_lum"),
    "freight-cars": dict(title="Freight cars", short="Freight cars",
                         blurb="Railroad-controlled car fleets, car repair, depreciation and car hire, use and capital. Private (shipper and lessor) cars are outside these numbers except through car hire.",
                         tiles=["car_units", "car_opex", "car_opex_per_car", "car_cost_per_carmile", "car_capex", "car_depr_ratio"],
                         table=["car_units", "car_owned", "car_leased", "car_opex", "car_opex_per_car", "car_repair_per_car", "car_miles_per_car", "car_cost_per_carmile", "car_capex"],
                         mix=("Freight car expense", ["car_repair", "car_dep", "car_rents"]), chart="car_opex_per_car"),
    "track": dict(title="Track and structures", short="Track and structures",
                  blurb="Roadway, ties, rail, ballast, bridges and tunnels: maintenance expense, capital programs and how depreciated the base is.",
                  tiles=["track_miles", "track_opex", "track_capex", "track_opex_per_tm", "track_capex_per_tm", "track_depr_ratio"],
                  table=["track_miles", "ws_opex", "track_opex", "struct_opex", "track_opex_per_tm", "ws_per_kgtm", "track_capex", "track_capex_per_tm", "struct_capex"],
                  mix=("Track capital program", ["ties_capex", "rail_capex", "ballast_capex", "struct_capex"]),
                  mix2=("Way and structures maintenance", ["track_opex", "struct_opex", "xing_opex", "ws_dep"]), chart="track_capex_per_tm"),
    "signals": dict(title="Signals and communications", short="Signals and comms",
                    blurb="Signal, interlocker, communications and power systems: maintenance, operation and capital, per mile of road. PTC supplement schedules are excluded.",
                    tiles=["sig_opex", "comm_opex", "sig_capex", "comm_capex", "sc_opex_per_rm", "sc_depr_ratio"],
                    table=["sig_opex", "comm_opex", "sig_ops", "sc_opex_per_rm", "sig_capex", "comm_capex", "sc_capex_per_rm", "sc_invest"],
                    mix=("Signal and comms capital", ["sig_capex", "comm_capex"]), chart="sc_opex_per_rm"),
    "labor": dict(title="Labor", short="Labor",
                  blurb="Headcount by craft from the STB monthly employment reports, paired with R-1 wages and benefits: cost per employee, productivity and staffing intensity by asset class. CPKC headcount starts in 2024 (Soo Line and KCSR monthly files for 2021-2023 aren't published in a usable form).",
                  tiles=["employees", "comp_per_emp", "comp_share", "mgtm_per_emp", "te_per_mtm", "mw_per_100tm"],
                  table=["employees", "wage_per_emp", "comp_per_emp", "rev_per_emp", "mgtm_per_emp", "te_per_mtm", "mw_per_100tm", "me_per_100_units", "mgt_share"],
                  mix=("Headcount by craft", ["emp_mgt", "emp_mw", "emp_me", "emp_ops_other", "emp_te"]),
                  mix2=("Wages by function", ["wages_ws", "wages_eq", "wages_tr", "wages_ga"]), chart="mgtm_per_emp"),
    "facilities": dict(title="Facilities and work equipment", short="Facilities and equipment",
                       blurb="Shops, servicing facilities, terminals, buildings, roadway machines and other (non-revenue) equipment.",
                       tiles=["fac_opex", "shops_opex", "other_eq_opex", "fac_capex", "machines_capex", "work_eq_capex"],
                       table=["fac_opex", "shops_opex", "terminal_opex", "tools_opex", "other_eq_opex", "fac_capex", "tofc_capex", "machines_capex", "work_eq_capex"],
                       mix=("Facilities and equipment capital", ["fac_capex", "machines_capex", "work_eq_capex"]), chart="fac_capex"),
}
for _k, _m in MODULES.items():
    for _x in _m["tiles"] + _m["table"] + _m.get("mix", ("", []))[1] + _m.get("mix2", ("", []))[1] + [k for _, ks in _m.get("statements", []) for k in ks]:
        M[_x].setdefault("module", _k)


# ---------- views ----------
def years():
    return _cells()["years"]


def ids():
    return _cells()["ids"]


def link(key, op=None, y=None):
    q = [f"rr={op}" if op else "", f"y={y}" if y else ""]
    q = "&".join(x for x in q if x)
    return f"{base()}/metric/{key}" + (f"?{q}" if q else "")


def base():
    """Where the portal lives for this request: /rail/r1 inside the rail portal, else the admin copy at /admin/freight."""
    from . import lens
    return "/rail/r1" if lens.in_rail() else "/admin/freight"


def class1(key, y):
    """Sum across railroads for additive metrics; None for ratios."""
    if M[key].get("currency_mixed") or key == "x_eps":
        return None
    if M[key]["den"] is not None:
        pairs = [(total(o, y, M[key]["num"]), total(o, y, M[key]["den"])) for o in ids()]
        pairs = [(a, b) for a, b in pairs if a is not None and b]  # only railroads that report both sides
        n, d = sum(a for a, _ in pairs), sum(b for _, b in pairs)
        return n * M[key]["scale"] / d if d else None
    vs = [value(key, o, y) for o in ids()]
    return sum(v for v in vs if v is not None) if any(v is not None for v in vs) else None


def tiles(mod, y):
    out = []
    for k in MODULES[mod]["tiles"]:
        v, p = class1(k, y), class1(k, y - 1) if y - 1 in years() else None
        chg = (v - p) / abs(p) * 100 if v is not None and p else None
        out.append(dict(key=k, label=M[k]["label"], show=fmt(k, v), href=link(k, y=y),
                        sub=f"Class I, {y}" + (f" · {chg:+.1f}% vs {y - 1}" if chg is not None else "")))
    return out


def grid(keys, y):
    ops = ids()
    rows = []
    for o in ops:
        cells = []
        for k in keys:
            v = value(k, o, y)
            vs = sorted([x for x in (value(k, p, y) for p in ops) if x is not None], reverse=M[k]["better"] == "high")
            rank = vs.index(v) + 1 if v is not None and M[k]["better"] else None
            cells.append(dict(v=v, show=fmt(k, v), href=link(k, o, y), rank=rank, n=len(vs)))
        rows.append(dict(op=o, label=RAILROADS[o][0], name=RAILROADS[o][1], cells=cells))
    tot = [dict(show=fmt(k, class1(k, y)), href=link(k, y=y)) for k in keys]
    return rows, tot


def mix(keys, y):
    """Composition table: each component's share of the sum of the components, per railroad."""
    out = []
    for o in ids():
        vs = [value(k, o, y) for k in keys]
        t = sum(v for v in vs if v) or 0
        out.append(dict(op=o, label=RAILROADS[o][0], total=t,
                        parts=[dict(key=k, show=fmt(k, v), share=(100 * v / t if v and t else 0), href=link(k, o, y)) for k, v in zip(keys, vs)]))
    return out


def series(key, op):
    return [(y, value(key, op, y)) for y in years()]


def cagr(key, op):
    s = [(y, v) for y, v in series(key, op) if v]
    if len(s) < 2 or s[0][1] <= 0 or s[-1][1] <= 0:
        return None
    return ((s[-1][1] / s[0][1]) ** (1 / (s[-1][0] - s[0][0])) - 1) * 100


def inputs(key, op, y):
    """The cells behind a metric for one railroad-year, with labels and the filings they came from."""
    m, mem = M[key], _cells()
    d = mem["cells"].get((op, y), {})
    out = []
    for part, terms in (("numerator", m["num"]), ("denominator", m["den"] or [])):
        for s, ln, c, sg in terms:
            out.append(dict(part=part, sched=s, sched_name=SCHED.get(s, ""), line=ln, col=c, label=mem["labels"].get((s, ln), ""),
                            value=d.get((s, ln, c)), sign=sg))
    return out


def sources(op, y):
    return sorted(_cells()["src"].get((op, y), {}).items())


def line_chart(key, sel_op=None, sel_y=None, w=680, h=240):
    """One series per railroad; every point links to the railroad-year drill-down (same style as the locomotive portal)."""
    ser = [(o, [(y, v) for y, v in series(key, o) if v is not None]) for o in ids()]
    from .charts import year_range, in_range, range_wrap
    rr = year_range([y for _, s in ser for y, _ in s])
    ser = [(o, [(y, v) for y, v in s if in_range(y, rr)]) for o, s in ser]
    pts = [v for _, s in ser for _, v in s]
    if not pts:
        return '<div class="empty">No data for this metric.</div>'
    xs = [y for _, s in ser for y, _ in s]
    x0, x1 = min(xs), max(xs)
    lo, hi = min(pts), max(pts)
    from .charts import autorange
    y0, y1 = autorange(lo, hi)
    L, R, Tp, B = 64, 12, 12, 26

    def sx(x):
        return L + (x - x0) / ((x1 - x0) or 1) * (w - L - R)

    def sy(v):
        return Tp + (1 - (v - y0) / ((y1 - y0) or 1)) * (h - Tp - B)
    out = [f'<svg viewBox="0 0 {w} {h}" class="chart linked" role="img" aria-label="{html.escape(M[key]["label"])}">']
    for i in range(5):
        v = y0 + (y1 - y0) * i / 4
        out.append(f'<line x1="{L}" x2="{w - R}" y1="{sy(v):.1f}" y2="{sy(v):.1f}" class="grid"/>'
                   f'<text x="{L - 6}" y="{sy(v) + 4:.1f}" class="ax" text-anchor="end">{html.escape(fmt(key, v))}</text>')
    for x in range(x0, x1 + 1):
        out.append(f'<text x="{sx(x):.1f}" y="{h - 8}" class="ax" text-anchor="middle">{x}</text>')
    for o, s in ser:
        if not s:
            continue
        col = COLORS[list(RAILROADS).index(o) % len(COLORS)]
        dim = sel_op and o != sel_op
        d = " ".join(f"{'M' if j == 0 else 'L'}{sx(x):.1f},{sy(v):.1f}" for j, (x, v) in enumerate(s))
        out.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{1.5 if dim else 2.5}" stroke-linejoin="round" opacity="{0.35 if dim else 1}"/>')
        for x, v in s:
            on = o == sel_op and x == sel_y
            ring = ' stroke="var(--ink)" stroke-width="2"' if on else ""
            out.append(f'<a href="{html.escape(link(key, o, x))}"><circle cx="{sx(x):.1f}" cy="{sy(v):.1f}" r="{6 if on else 3.5}" fill="{col}" '
                       f'opacity="{0.45 if dim else 1}"{ring}><title>{RAILROADS[o][0]} {x}: {html.escape(fmt(key, v))}</title></circle></a>')
    out.append("</svg>")
    legend = "".join(f'<a href="{link(key, o)}"><i style="background:{COLORS[list(RAILROADS).index(o) % len(COLORS)]}"></i>{RAILROADS[o][0]}</a>'
                     for o, s in ser if s)
    return range_wrap("".join(out) + f'<div class="legend">{legend}</div>', rr)


def export_rows():
    out = []
    for k, m in M.items():
        for o in ids():
            for y in years():
                v = value(k, o, y)
                if v is not None:
                    out.append(dict(module=m.get("module", ""), metric=k, label=m["label"], operator_id=o, railroad=RAILROADS[o][0], year=y,
                                    value=round(v, 4), unit={"musd": "USD thousands"}.get(m["fmt"], m["fmt"]), definition=m["definition"]))
    return out
