"""Key to terms for exported reports (1.7.54, Justin 11-16: "the report output should include definitions for confidence pill, and
other pills or abbreviations that may be ambiguous to a reader outside of the website"). Reports read away from the site have no
hover cards, so each one ends with a short key that defines only what that report actually shows: its pills (confidence, verdict,
source grade, bid stage), labels and abbreviations. Definitions come from glossary.TERMS where the site already has one, so the
report and the hover cards say the same thing; the rest are here.

Used by the account brief (/app/operators/<id>/brief) and the AI analyst and bid fit brief exports (pdfbrief: PDF, RTF, TXT)."""
import re

from . import glossary

# Report-only definitions (pills and abbreviations with no glossary heading of their own).
OWN = {
    "High confidence": "The analyst's answer rests on records we hold directly (filed figures, agency documents, posted notices) that agree with each other.",
    "Medium confidence": "The answer rests on our records but some figures are estimated, partial or from secondary sources; check the caveats.",
    "Low confidence": "Little direct evidence: the answer leans on estimates, comparable agencies or general market knowledge. Treat it as a lead to confirm.",
    "Strong fit": "Bid fit verdict: the scope and timing line up well for a typical specialist supplier in this category.",
    "Possible fit": "Bid fit verdict: part of the scope suits a typical specialist supplier in this category; read the risks before deciding to bid.",
    "Weak fit": "Bid fit verdict: little of the scope suits a typical specialist supplier in this category.",
    "Grade A": "Confidence grade A: an official record (regulatory filing, signed contract, government database).",
    "Grade B": "Confidence grade B: an agency document (board item, budget, capital plan, annual report, press release).",
    "Grade C": "Confidence grade C: a secondary source (trade press, supplier announcement, third-party report).",
    "Grade D": "Confidence grade D: a model estimate from comparable fleets or agencies.",
    "Open": "The solicitation is still taking responses: its closing date is today or later (or it was posted in the last 45 days with no closing date).",
    "Ceiling": "The most the agency may spend across the whole on-call bench, shared by every firm on it (not each firm's own value).",
    "With options": "The end date if the agency uses every option year in the contract.",
    "Expect re-bid": "Twelve months before the contract ends: when the agency usually starts the next procurement.",
    "Stage": "Where a funding item sits: Capital plan, Budgeted, Board authorized, Out for bid, Intent to award, Awarded, or Change order / option.",
    "Est. value": "Estimated value in US dollars, from the notice, the agency's budget or our model.",
    "Rail item": "A rail-related item on a board meeting agenda (a contract, change order, budget or procurement action).",
    "Why now": "Signals on our data that make this account a current opportunity, such as fleets nearing midlife or end of life, recent bids or funding.",
    "Constant dollars": "Dollars adjusted for inflation to one base year, so years compare fairly.",
    "NTD": "FTA National Transit Database: the annual filings US transit agencies make on service, fleets, costs and reliability.",
    "FTA": "Federal Transit Administration, the US agency that funds transit capital projects and runs the National Transit Database.",
    "FRA": "Federal Railroad Administration, the US agency for railroad safety and intercity and freight rail grants.",
    "STB R-1": "The annual report Class I freight railroads file with the Surface Transportation Board: locomotive counts, miles, repairs and costs.",
    "Unit-mile": "One locomotive moving one mile.",
    "USAspending": "The US government's public database of federal grants and contracts.",
    "On-call contract": "A standing contract (also IDIQ, task order or standing offer) where firms are pre-qualified and the agency issues work as needed.",
    "IDIQ": "Indefinite delivery, indefinite quantity: a contract with a ceiling but no fixed amount of work; tasks are ordered as needed.",
    "RFP": "Request for proposals: a solicitation scored on more than price.",
    "RFQ": "Request for qualifications or quotations, depending on the agency.",
    "RFI": "Request for information: an agency asking the market before it writes a solicitation.",
    "IFB": "Invitation for bids: a sealed, lowest-price solicitation.",
    "OEM": "Original equipment manufacturer: the company that built the vehicle or system.",
    "MDBF": "Mean distance between failures: revenue miles per major mechanical failure.",
    "ULB": "Useful-life benchmark: the age FTA expects a vehicle type to be replaced at.",
    "SGR": "State of good repair: FTA's term (and grant program) for keeping assets within their useful life.",
    "CIG": "FTA Capital Investment Grants: the discretionary program for new and expanded rail lines (New Starts, Small Starts, Core Capacity).",
    "CRISI": "FRA Consolidated Rail Infrastructure and Safety Improvements grants.",
    "PTC": "Positive train control: the US-mandated system that stops a train before certain accidents.",
    "CBTC": "Communications-based train control: radio-based signaling that lets trains run closer together.",
    "LRV": "Light rail vehicle.",
    "EMU": "Electric multiple unit: a self-propelled electric passenger car or trainset.",
    "DMU": "Diesel multiple unit: a self-propelled diesel passenger car or trainset.",
    "HVAC": "Heating, ventilation and air conditioning.",
    "O&M": "Operations and maintenance.",
    "Buy America": "The rule that FTA-funded rolling stock has at least 70% US content and final assembly in the US.",
    "$/car-mi": "Dollars per car revenue mile: cost divided by the miles cars run in passenger service.",
    "Car-year": "One car in service for one year.",
    "YoY": "Year over year.",
    "FY": "Fiscal year.",
    "vs peers": "Difference from the national median for the same mode, in percent. For miles between failures, a positive figure means more reliable than peers.",
    "Spare ratio": "Spare vehicles as a share of vehicles needed at peak: (active - peak) / peak.",
}

# Abbreviations spotted in free text (AI answers): term -> pattern.
SPOT = [("NTD", r"\bNTD\b"), ("FTA", r"\bFTA\b"), ("FRA", r"\bFRA\b"), ("STB R-1", r"\bR-1\b|\bSTB\b"), ("USAspending", r"USAspending"),
        ("IDIQ", r"\bIDIQ\b"), ("RFP", r"\bRFPs?\b"), ("RFQ", r"\bRFQs?\b"), ("RFI", r"\bRFIs?\b"), ("IFB", r"\bIFBs?\b"),
        ("OEM", r"\bOEMs?\b"), ("MDBF", r"\bMDBF\b"), ("ULB", r"\bULB\b"), ("SGR", r"\bSGR\b"), ("CIG", r"\bCIG\b"),
        ("CRISI", r"\bCRISI\b"), ("PTC", r"\bPTC\b"), ("CBTC", r"\bCBTC\b"), ("LRV", r"\bLRVs?\b"), ("EMU", r"\bEMUs?\b"),
        ("DMU", r"\bDMUs?\b"), ("HVAC", r"\bHVAC\b"), ("O&M", r"\bO&M\b"), ("Buy America", r"Buy America"),
        ("$/car-mi", r"/car-mi|per car[- ]mile"), ("Car-year", r"car-years?"), ("YoY", r"\bYoY\b"), ("FY", r"\bFY ?\d{2}"),
        ("Unit-mile", r"unit-miles?"), ("Constant dollars", r"constant[- ]dollars?|\b20\d\d dollars\b"),
        ("Spare ratio", r"spare ratio"), ("Midlife", r"\bmid-?life\b"), ("Miles between failures", r"miles between (major )?failures")]

# Account brief: terms each module puts on the page.
MODULE_TERMS = {
    "stats": ["NTD", "Miles between failures", "Spare ratio", "Farebox recovery"],
    "signals": ["Why now"],
    "fleets": ["Midlife", "End of life", "$/car-mi"],
    "costs": ["$/car-mi", "Constant dollars", "NTD"],
    "reliability": ["Miles between failures", "vs peers", "Spare ratio", "Contracted"],
    "reported": ["$/car-mi"],
    "r1": ["STB R-1", "Unit-mile", "Repairs $/mi", "Cost $/mi", "Miles/unit"],
    "meetings": ["Rail item"],
    "orders": ["Base", "Options"],
    "programs": ["Grade A", "Grade B", "Grade C", "Grade D"],
    "grants": ["FTA", "USAspending"],
    "budget": ["Stage"],
    "capital": ["Open", "Est. value"],
    "oncall": ["On-call contract", "Ceiling", "With options", "Expect re-bid"],
}


def define(term):
    """The definition for a term: this module's own wording first (report-specific), else the site glossary."""
    return OWN.get(term) or glossary._LOWER.get(term.lower())


def _pairs(terms):
    out, seen = [], set()
    for t in terms:
        if t in seen:
            continue
        d = define(t)
        if d:
            out.append((t, d))
            seen.add(t)
    return out


def spot(text):
    """Abbreviations and labels in free text that a reader outside the site may not know."""
    text = text or ""
    return [t for t, rx in SPOT if re.search(rx, text, re.I if not t.isupper() else 0)]


def for_ai(result):
    """Key for an AI analyst answer or bid fit brief: its verdict and confidence pills, then what its text uses."""
    r = result or {}
    terms = []
    v = {"strong_fit": "Strong fit", "possible_fit": "Possible fit", "weak_fit": "Weak fit"}.get(r.get("verdict"))
    if v:
        terms.append(v)
    terms.append(f"{(r.get('confidence') or 'medium').capitalize()} confidence")
    tb = r.get("table") or {}
    blob = " ".join([str(r.get(k) or "") for k in ("headline", "answer_markdown")]
                    + [str(c) for c in (r.get("caveats") or [])]
                    + [f"{k.get('value', '')} {k.get('label', '')} {k.get('note', '')}" for k in (r.get("key_figures") or []) if isinstance(k, dict)]
                    + [str(c) for c in (tb.get("columns") or [])] + [str(c) for rr in (tb.get("rows") or [])[:200] for c in rr])
    return _pairs(terms + spot(blob))


def for_brief(sel, modes=(), mode_names=None, grades=()):
    """Key for an account brief: the terms of each module shown, the mode codes in its tiles, and the grades it shows."""
    terms = []
    for k in sel:
        for t in MODULE_TERMS.get(k, []):
            if t.startswith("Grade ") and grades and t[-1] not in grades:
                continue
            terms.append(t)
    out = _pairs(terms)
    if modes and mode_names and ("stats" in sel or "reliability" in sel):
        codes = [m for m in modes if m in mode_names]
        if codes:
            out.append(("Mode codes", "; ".join(f"{m} = {mode_names[m]}" for m in codes) + " (FTA National Transit Database modes)."))
    return out
