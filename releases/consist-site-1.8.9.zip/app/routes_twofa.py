"""Two-factor sign-in pages: the code step after the password, enrollment during sign-in when 2FA is required, and the member's
own settings at /account/2fa (admins use the same page). The TOTP and recovery-code logic is in app/twofa.py."""
import time

from fastapi import APIRouter, Depends, Form, HTTPException, Request

from . import auth, db, twofa
from .main import flash, redirect, render

router = APIRouter()
U = Depends(auth.require_user)


def _safe(n):
    return n if n and n.startswith("/") and not n.startswith("//") else "/app"


def begin(request: Request, u, nxt=""):
    """Call after the password (or a reset link, invite or sign-up) checks out. Signs in, or sends the member to the code step,
    or to set up 2FA first when it is required for them and they don't have it yet."""
    u = dict(db.q("SELECT * FROM user WHERE id = ?", (u["id"],), one=True) or u)
    if twofa.available():
        if twofa.enabled(u):
            if twofa.remembered(request, u):
                auth.login(request, u)
                return redirect(_safe(nxt))
            return _pending(request, u, nxt, "/login/2fa")
        if twofa.required(u):
            return _pending(request, u, nxt, "/login/2fa/setup", enrol=True)
    auth.login(request, u)
    return redirect(_safe(nxt))


def _pending(request, u, nxt, to, enrol=False):
    request.session.clear()
    request.session["p2"] = {"u": u["id"], "n": _safe(nxt), "t": int(time.time()), "e": enrol, "pv": auth.pw_mark(u)}
    return redirect(to)


def _pending_user(request, enrol=False):
    p = request.session.get("p2") or {}
    if not p or time.time() - p.get("t", 0) > twofa.PENDING_MINUTES * 60 or bool(p.get("e")) != enrol:
        return None, p
    r = db.q("SELECT * FROM user WHERE id = ?", (p["u"],), one=True)
    if not r or r["status"] != "active" or auth.pw_mark(dict(r)) != p.get("pv"):
        return None, p
    return dict(r), p


# ---------- sign-in: the code step ----------

@router.get("/login/2fa")
def code_step(request: Request):
    u, _ = _pending_user(request)
    if not u:
        return redirect("/login")
    return render(request, "public/twofa.html", email=u["email"])


@router.post("/login/2fa")
def code_step_post(request: Request, csrf: str = Form(""), code: str = Form(""), remember: str = Form("")):
    auth.check_csrf(request, csrf)
    u, p = _pending_user(request)
    if not u:
        flash(request, "That took too long. Sign in again.", "bad")
        return redirect("/login")
    ip = "2fa:" + auth.client_ip(request)
    if auth.throttled(ip, 8):
        return render(request, "public/twofa.html", email=u["email"], error="Too many tries. Wait ten minutes and try again.")
    if not twofa.verify(u, code):
        auth.note_failure(ip)
        db.audit("2fa_failed", "", u["id"])
        return render(request, "public/twofa.html", email=u["email"], error="That code didn't work. Codes change every 30 seconds.")
    auth.login(request, u)
    db.audit("2fa_login", "remembered device" if remember else "", u["id"])
    resp = redirect(p.get("n") or "/app")
    if remember:
        twofa.set_remember(resp, dict(db.q("SELECT * FROM user WHERE id = ?", (u["id"],), one=True)))
    return resp


# ---------- sign-in: required, not set up yet ----------

@router.get("/login/2fa/setup")
def enrol_step(request: Request):
    u, p = _pending_user(request, enrol=True)
    if not u:
        return redirect("/login")
    if not p.get("s"):
        p["s"] = twofa.new_secret()
        request.session["p2"] = p
    return render(request, "public/twofa_setup.html", **_setup_ctx(u, p["s"]), action="/login/2fa/setup", forced=True)


@router.post("/login/2fa/setup")
def enrol_step_post(request: Request, csrf: str = Form(""), code: str = Form("")):
    auth.check_csrf(request, csrf)
    u, p = _pending_user(request, enrol=True)
    if not u or not p.get("s"):
        return redirect("/login")
    step = twofa.check_code(p["s"], code)
    if step is None:
        return render(request, "public/twofa_setup.html", **_setup_ctx(u, p["s"]), action="/login/2fa/setup", forced=True,
                      error="That code didn't match. Check the time on your phone and try the newest code.")
    codes = twofa.enable(u["id"], p["s"], step)
    db.audit("2fa_on", "during sign-in", u["id"])
    auth.login(request, u)
    return render(request, "public/twofa_codes.html", codes=codes, next=p.get("n") or "/app")


def _setup_ctx(u, secret):
    uri = twofa.otpauth_uri(secret, u["email"])
    return {"qr": twofa.qr_svg(uri), "secret": twofa.pretty_secret(secret), "uri": uri}


# ---------- the member's own settings ----------

def _back(u):
    return "/admin/account" if u.is_admin else "/app/account"


@router.get("/account/2fa")
def manage(request: Request, u=U):
    if not twofa.available() and not twofa.enabled(u):
        raise HTTPException(404)
    ctx = {"on": twofa.enabled(u), "required": twofa.required(u), "left": twofa.recovery_left(u), "back": _back(u)}
    if not ctx["on"]:
        s = request.session.get("s2") or twofa.new_secret()
        request.session["s2"] = s
        ctx.update(_setup_ctx(u, s))
    return render(request, "public/twofa_manage.html", user=u, **ctx)


@router.post("/account/2fa/on")
def manage_on(request: Request, csrf: str = Form(""), code: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    s = request.session.get("s2")
    step = twofa.check_code(s, code) if s else None
    if step is None:
        flash(request, "That code didn't match. Check the time on your phone and try the newest code.", "bad")
        return redirect("/account/2fa")
    request.session.pop("s2", None)
    codes = twofa.enable(u["id"], s, step)
    db.audit("2fa_on", "", u["id"], u["email"])
    return render(request, "public/twofa_codes.html", codes=codes, next="/account/2fa")


@router.post("/account/2fa/recovery")
def manage_codes(request: Request, csrf: str = Form(""), password: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if not twofa.enabled(u) or not auth.check_pw(password, u["pw_hash"]):
        flash(request, "Your password is not right.", "bad")
        return redirect("/account/2fa")
    codes = twofa.new_recovery_codes(u["id"])
    db.audit("2fa_recovery_codes", "", u["id"], u["email"])
    return render(request, "public/twofa_codes.html", codes=codes, next="/account/2fa")


@router.post("/account/2fa/off")
def manage_off(request: Request, csrf: str = Form(""), password: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if twofa.required(u):
        flash(request, "Two-factor sign-in is required for your account, so it can't be turned off.", "bad")
    elif not auth.check_pw(password, u["pw_hash"]):
        flash(request, "Your password is not right.", "bad")
    else:
        twofa.disable(u["id"])
        db.audit("2fa_off", "", u["id"], u["email"])
        flash(request, "Two-factor sign-in is off.")
    return redirect("/account/2fa")
