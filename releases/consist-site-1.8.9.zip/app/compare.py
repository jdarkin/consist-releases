"""Comparison pages (/compare and /compare/<slug>). Facts about other products come from public listings and third-party reviews,
checked October 2026; each page says so. Keep these honest: where a competitor is stronger, the table says so."""

import json

from . import claims

CHECKED = "October 2026"  # competitor facts (railmarket, rail-market-research, global-mass-transit, ftr: checked 2026-11-03); Consist rows re-checked against the site on 2026-11-02

US = "{site}"

COMPETITORS = {
    "bidprime": {
        "name": "BidPrime",
        "category": "Government bid alert service",
        "one_liner": "A broad government bid-finding service that crawls a very large number of public procurement sources.",
        "blurb": "BidPrime finds bids across every public sector category. {site} covers only rail: public rail and transit "
                 "procurement with the fleet data behind each bid, plus freight rail market data.",
        "pricing": "Quote-based annual plans (Enhanced, Expert, Enterprise per third-party listings); prices not published",
        "free": "Free trial reported by third-party listings (30 days); no free plan",
        "summary": "BidPrime is built for companies that sell to government in general. It monitors a very large number of sources "
                   "(it cites 120,000+), matches bids by keyword profile and can fetch bid documents for you. If you sell across "
                   "many public sector categories, that breadth is hard to beat.",
        "rows": [
            ("What it covers", "Rail and transit bids (vehicles, components, signals, track, power, stations, operations) at {agencies} US and Canadian rail agencies and airport people movers",
             "All public sector categories across federal, state and local government", "them"),
            ("Rail relevance scoring", "Every notice scored 0-100 for rail vehicle relevance, with category and subsystem tags",
             "Keyword and category matching for your profile", "us"),
            ("Fleet context on each bid", "Fleets the agency runs: builder, age, size, duty cycle, cost per car-mile, overhaul timing",
             "Not offered", "us"),
            ("Award and competitor analytics", "Who won rail awards, at what price and with how many bidders (paid plans)",
             "Bid results available on some plans; not rail-specific", "us"),
            ("Bid document retrieval", "Links to the agency portal; documents stay on the portal", "Document download and Docs on Demand retrieval", "them"),
            ("AI features", "AI analyst over fleet, bid, award and freight railroad data; AI bid fit briefs (paid plans)", "AI assistant for qualification and proposals (announced 2024-25)", "tie"),
            ("Rail market data", "Every passenger fleet, plus the Freight Rail Analytics Portal (R-1, EP 724, short lines, freight flows)", "Not offered", "us"),
            ("Pricing", "Published: {price_line}; 20% off yearly", "Quote-based", "us"),
            ("Free option", "Free plan, no card, samples every part of the site", "Free trial", "us"),
            ("Alert speed", "Instant, daily or weekly email per saved search", "Daily and real-time alerts", "tie"),
        ],
        "us_pros": ["Built only for rail rolling stock and fleet maintenance work", "Each bid is tied to the fleets it concerns",
                    "Transparent pricing with a free plan", "Award analytics show who wins rail work and at what price"],
        "us_cons": ["Covers rail only, not other public sector categories", "Fewer total sources than a general bid service",
                    "Does not retrieve bid documents for you"],
        "them_pros": ["Very broad source coverage across all categories", "Document retrieval service", "Strong user reviews for support"],
        "them_cons": ["Not specialized for rail; you tune keywords yourself", "No fleet or asset context", "Pricing not published"],
        "verdict": "Choose BidPrime if you sell to many kinds of public agencies and want one feed for all of it. Choose {site} if your "
                   "business is rail vehicles, components or fleet maintenance: you get fewer, better-targeted bids and the fleet facts "
                   "you need to decide whether to bid. Some rail suppliers use both.",
        "sources": [("G2: BidPrime reviews", "https://www.g2.com/products/bidprime/reviews"),
                    ("ColdIQ: BidPrime listing", "https://coldiq.com/tools/bidprime")],
    },
    "govspend": {
        "name": "GovSpend",
        "category": "Government spending and procurement intelligence",
        "one_liner": "A state and local government (SLED) market intelligence platform built on purchase order data.",
        "blurb": "GovSpend shows what state and local governments buy, down to purchase orders. {site} goes deep on rail: every "
                 "fleet, its condition and the bids that follow.",
        "pricing": "Annual subscriptions by quote; third-party estimates put typical contracts around $11,000-$15,000 a year",
        "free": "No free plan; demo first",
        "summary": "GovSpend is a mature SLED intelligence platform. Its purchase order database, meeting intelligence (transcribed and "
                   "searchable public meetings), contacts and bid feed give a broad view of government spending. For rail suppliers "
                   "it is wide but not deep: it does not model fleets, ages or overhaul cycles.",
        "rows": [
            ("What it covers", "Rail fleets, rail bids and awards, and freight rail market data in the US and Canada",
             "State and local government spending, bids, contacts and meetings across all categories", "them"),
            ("Spending data", "Rail contract awards with vendor, amount and bidder counts", "Line-item purchase order history across agencies", "them"),
            ("Fleet and asset data", "{fleets} fleets with builder, age, duty cycle, costs and overhaul timing", "Not offered", "us"),
            ("Early signals", "Overhaul pipeline forecasts which fleets come due for midlife and engine overhauls",
             "Meeting intelligence surfaces plans discussed in public meetings", "tie"),
            ("Rail relevance scoring", "Every notice scored for rail vehicle relevance", "General category and keyword filters", "us"),
            ("AI features", "AI analyst over fleet, bid, award and freight railroad data; AI bid fit briefs (paid plans)", "GovSpend AI and AI meeting summaries", "tie"),
            ("Contacts and CRM", "Not offered", "Buyer contacts and CRM integrations", "them"),
            ("Pricing", "Published, from free to {top_price}/mo for all rail; 20% off yearly", "Quote-based, typically five figures a year", "us"),
            ("Free option", "Free plan, no card, samples every part of the site", "Demo only", "us"),
        ],
        "us_pros": ["Fleet-level depth no general platform has", "Overhaul pipeline shows work years before the RFP",
                    "Much lower cost for a rail-focused team", "Self-serve sign-up and free plan"],
        "us_cons": ["No purchase order database or buyer contacts", "Rail only", "No meeting transcripts"],
        "them_pros": ["Deep purchase order history across SLED agencies", "Meeting intelligence and contacts", "CRM integrations"],
        "them_cons": ["Priced for broad SLED sales teams", "No fleet or rolling stock model", "Demo required before you can try it"],
        "verdict": "GovSpend is the better tool for a sales team that sells many products to state and local government and needs "
                   "purchase order history and contacts. For rail suppliers and fleet consultants, {site} answers the questions "
                   "GovSpend cannot (which fleets need work, when, and who supplies them today) at a fraction of the price.",
        "sources": [("GovSpend platform overview", "https://govspend.com/govspend-platform/"),
                    ("Vendr: GovSpend buyer guide (pricing estimates)", "https://www.vendr.com/buyer-guides/gov-spend"),
                    ("G2: GovSpend vs GovWin IQ", "https://www.g2.com/compare/govspend-vs-govwin-iq")],
    },
    "bidnet-direct": {
        "name": "BidNet Direct",
        "category": "Bid notification network",
        "one_liner": "A bid notification network where many agencies post solicitations, with free and paid supplier plans.",
        "blurb": "BidNet Direct is where many agencies post bids. {site} watches BidNet and the other portals of {agencies} rail "
                 "agencies and keeps only the rail work.",
        "pricing": "Free Basic plan for member-agency bids; paid plans reported at $599/yr (one state), $1,199/yr (three states), $1,999/yr (national)",
        "free": "Yes, free Basic plan for member-agency bids",
        "summary": "BidNet Direct is both a posting platform for agencies and an alert service for suppliers. Its free plan is useful "
                   "for the agencies that post on it, and paid plans add bids it aggregates from other sources by state or nationally.",
        "rows": [
            ("What it covers", "Rail agencies across all their portals (Bonfire, OpenGov, PlanetBids, BidNet, agency sites, Canadian open data)",
             "Bids posted by member agencies plus aggregated bids by state", "tie"),
            ("Rail relevance scoring", "Every notice scored for rail vehicle relevance", "Category codes and keywords", "us"),
            ("Fleet context", "Fleet data on every bid", "Not offered", "us"),
            ("Award analytics", "Rail award winners and prices (paid plans)", "Bid results where agencies publish them", "us"),
            ("Submit bids online", "No; you bid on the agency portal", "Yes, for agencies that use it for e-bidding", "them"),
            ("Canada coverage", "CanadaBuys and Quebec SEAO open data plus Canadian transit agencies", "Limited outside its member agencies", "us"),
            ("Pricing", "{price_line}; from {low_year} a year billed yearly", "Free, then $599-$1,999 a year", "tie"),
            ("Free option", "Free plan, no card, samples every part of the site", "Free Basic plan", "tie"),
        ],
        "us_pros": ["One rail-only feed across many platforms, including BidNet", "Fleet and award context", "US and Canada"],
        "us_cons": ["No low-cost single-state plan like BidNet's $599 a year", "No online bid submission", "Free plan shows only the last 30 days of bids"],
        "them_pros": ["Free plan for member agencies", "Online bid submission", "Low-cost state plans"],
        "them_cons": ["Only part of the rail market posts there", "No rail filtering beyond codes", "No fleet data"],
        "verdict": "Register on BidNet Direct for free if agencies you serve post there; you need an account to bid anyway. {site} is "
                   "the layer on top: it watches BidNet and the other portals rail agencies use, filters to rail work and adds the fleet "
                   "and award context.",
        "sources": [("Civic IQ: BidNet Direct pricing (Aug 2026)", "https://civiciq.com/blog/civic-iq-bidnet-direct-pricing"),
                    ("Capterra: BidNet Direct", "https://www.capterra.ca/software/1013345/bidnet-direct")],
    },
    "sci-verkehr": {
        "name": "SCI Verkehr",
        "category": "Global rail market database and consulting",
        "one_liner": "A rail consultancy whose SCI Database covers rolling stock projects, fleets and market forecasts worldwide.",
        "blurb": "SCI Verkehr's database covers the world's rail markets for strategists. {site} covers US and Canadian rail fleets "
                 "car by car, with live bids and freight rail market data.",
        "pricing": "Data products and compilations by quote",
        "free": "No free plan",
        "summary": "SCI Verkehr is a respected rail market research firm. Its database covers some 46,700 vehicle projects in 171 "
                   "countries with fleet stocks and market forecasts, sold as reports, compilations and custom data deliveries. It "
                   "is aimed at strategy and market sizing rather than day-to-day bid capture.",
        "rows": [
            ("Geography", "US and Canada: transit, passenger and freight rail", "Worldwide, 171 countries", "them"),
            ("Freight rail", "Class I, regional and short line railroads: R-1 financials, EP 724 service, locomotives, freight and tank cars",
             "Freight rolling stock and market forecasts worldwide", "tie"),
            ("Fleet detail", "Each fleet with active cars, build year, duty cycle, cost per car-mile, subsystem suppliers; vehicle rosters",
             "Fleet stocks and vehicle projects by country and type", "tie"),
            ("Market forecasts", "Overhaul and replacement pipeline by year from fleet age and utilization; FAF freight flows to 2050",
             "Market volume forecasts by region and segment", "them"),
            ("Live bids", "Daily rail bid feed with alerts", "Procurement news (SCI Raildata)", "us"),
            ("Operating costs", "NTD-based cost per car-mile and trends since 2015", "Not a focus", "us"),
            ("Access", "Self-serve web app, CSV export", "Reports and data deliveries", "us"),
            ("Pricing", "Published: {price_line}", "By quote", "us"),
        ],
        "us_pros": ["Self-serve and current: data refreshes monthly, bids daily", "Cost and utilization per fleet", "Live bids and alerts",
                    "Freight railroad filings and service data in the same account"],
        "us_cons": ["US and Canada only", "No global market forecasts", "No rolling stock order forecasts by region"],
        "them_pros": ["Global coverage", "Long-running market forecasts and consulting", "Infrastructure market studies"],
        "them_cons": ["Built for strategy studies, not bid capture", "Not self-serve", "Pricing by quote"],
        "verdict": "For global market sizing or entering new regions, SCI Verkehr is the specialist. For winning US and Canadian "
                   "rail work this year, {site} gives you the fleets, the costs, the bids and the freight railroads in one place you can open every morning.",
        "sources": [("SCI Verkehr database presentation", "https://www.sci.de/fileadmin/user_upload/Datenbank/Datenbankpraesentation.pdf"),
                    ("SCI Database", "https://www.sci.de/en/data-trends/sci-database")],
    },
    "railmarket": {
        "name": "RAILMARKET",
        "category": "Rail industry supplier directory and news",
        "one_liner": "A B2B marketing platform, rail industry news site and company database, part of the RAILVIS family.",
        "blurb": "RAILMARKET helps rail suppliers get found, worldwide. {site} tells US and Canadian rail suppliers which fleets and "
                 "agencies need their work next, and sends the bids when they post.",
        "pricing": "Paid company profiles and advertising packages (see its advertising page)",
        "free": "Free to read news and the directory; supplier visibility is paid",
        "summary": "RAILMARKET is a marketing and visibility platform: rail companies list themselves in its industry database, and it "
                   "publishes rail news and advertising. It is the right tool for being found by buyers across many countries. It is "
                   "not built to tell you which US or Canadian operator will buy what, or when.",
        "rows": [
            ("What it is", "Market intelligence: fleets, overhaul timing, bids and awards", "Supplier directory, news and advertising", "tie"),
            ("Geography", "US and Canada, in depth", "Worldwide, with regional editions", "them"),
            ("Fleet data", "Every passenger rail fleet: builder, age, cars, duty cycle, cost per car-mile, overhaul timing",
             "Not offered", "us"),
            ("Live bids", "Daily rail and transit bids from {agencies} US and Canadian agencies, scored for relevance", "Not a focus", "us"),
            ("Getting found by buyers", "Not offered: a tool for sellers, not a directory", "Company profiles in its rail database", "them"),
        ],
        "us_pros": ["Tells you which fleets and agencies will buy, and when", "Live bids with alerts", "Published prices and a free plan"],
        "us_cons": ["US and Canada only", "No supplier directory or advertising"],
        "them_pros": ["Global reach and rail industry news", "Supplier profiles buyers can find"],
        "them_cons": ["No fleet or bid intelligence for North America", "Visibility is paid"],
        "verdict": "They do different jobs. Use RAILMARKET to be found by buyers worldwide. Use {site} to find the US and Canadian "
                   "rail work worth chasing: which fleets come due, which agencies are buying and the bids as they post.",
        "sources": [("UIRR partner listing: RAILMARKET", "https://www.uirr.com/partners/railmarket"),
                    ("RAILMARKET advertising page", "https://railmarket.com/advertise")],
    },
    "rail-market-research": {
        "name": "Rail Market Research",
        "category": "Rail market report store",
        "one_liner": "An online store of rail market reports and custom research, run by ASTRAN Business Consulting GmbH in Germany.",
        "blurb": "Rail Market Research sells one-off market reports. {site} is a live subscription: every US and Canadian fleet, "
                 "refreshed monthly, and the bids that come out of them, daily.",
        "pricing": "Per report, about $900 to $3,900 (for example US Rolling Stock Market 2024-2030 at $3,500)",
        "free": "No free plan; reports are bought individually",
        "summary": "Rail Market Research publishes and resells market reports on rolling stock, signaling, components and rail "
                   "technology, mostly global or European, and offers custom analysis. A report gives a market-size view at one "
                   "point in time. It does not name which fleets need work next or track the bids.",
        "rows": [
            ("Format", "Live web app, refreshed monthly (bids daily)", "One-off PDF-style reports", "us"),
            ("US rolling stock market", "Fleet by fleet: age, cars, cost per car-mile, overhaul and replacement years", "US Rolling Stock Market 2024-2030 report ($3,500)", "us"),
            ("Global coverage", "US and Canada only", "Global and European reports", "them"),
            ("Live bids", "Daily rail and transit bids with alerts", "Not offered", "us"),
            ("Custom research", "AI analyst over the data (paid plans)", "Custom data analysis and consulting", "them"),
        ],
        "us_pros": ["Current, fleet-level data instead of a static report", "Bids and awards included", "Free plan to try it"],
        "us_cons": ["No global or European market reports", "No bespoke consulting"],
        "them_pros": ["Reports on markets outside North America", "Custom research on request"],
        "them_cons": ["Each report is a one-time purchase that ages", "No fleet-level or bid data"],
        "verdict": "For a market-size number on Europe or the world, buy a report. For the US and Canadian market, {site} costs less "
                   "than one report a year and stays current every month.",
        "sources": [("Rail Market Research home page", "https://www.railmarketresearch.com/")],
    },
    "global-mass-transit": {
        "name": "Global Mass Transit",
        "category": "Transit industry news and reports",
        "one_liner": "A transit industry publisher with a news subscription, reports, a projects database, conferences and a newsletter.",
        "blurb": "Global Mass Transit covers transit projects and news worldwide. {site} goes deep on US and Canadian rail: every "
                 "fleet, its condition and the bids that follow.",
        "pricing": "Website subscription and reports; prices not published on its home page",
        "free": "Free newsletter and some Knowledge Centre items",
        "summary": "Global Mass Transit reports on buses, metro, light rail, commuter and high-speed rail across five world regions, with "
                   "news, tenders, project updates, reports and events. It is broad and news-led. It does not hold fleet-level "
                   "condition data or score bids for rail suppliers.",
        "rows": [
            ("Coverage", "US and Canadian rail: transit, passenger and freight", "Transit of all modes, five world regions", "them"),
            ("Fleet data", "Every passenger fleet with age, use, cost and overhaul timing", "Projects database and reports", "us"),
            ("Tenders and bids", "Daily, scored for rail relevance, tied to fleets, with alerts", "Tenders within the news subscription", "us"),
            ("News and events", "Not a news site", "News, newsletter and conferences", "them"),
        ],
        "us_pros": ["Fleet-level data and overhaul forecasts", "Rail bids scored and tied to fleets", "Published prices and a free plan"],
        "us_cons": ["No news or conferences", "US and Canada only"],
        "them_pros": ["Worldwide transit news and projects", "Events and a free newsletter"],
        "them_cons": ["No fleet condition or cost data", "Not specific to rail suppliers"],
        "verdict": "Read Global Mass Transit for worldwide transit news. Use {site} to find and win US and Canadian rail work.",
        "sources": [("Global Mass Transit home page", "https://globalmasstransit.net/")],
    },
    "ftr": {
        "name": "FTR Rail Equipment Monthly",
        "category": "Freight railcar market intelligence",
        "one_liner": "FTR's freight rail equipment service: an Excel database with market intelligence on 40 freight car types, webinars and analyst access.",
        "blurb": "FTR covers the freight railcar market for builders, lessors and investors. {site} covers the railroads themselves, "
                 "from their own filings, alongside every passenger fleet.",
        "pricing": "$20,000 a year (Rail Equipment Monthly); $35,000 bundled with the Rail Equipment Outlook",
        "free": "No free plan listed",
        "summary": "FTR is a respected freight transportation forecaster. Rail Equipment Monthly gives railcar builders, lessors and "
                   "investors an Excel database covering 40 car types, monthly and quarterly webinars and direct access to its "
                   "analysts; forecasts come in the separate Rail Equipment Outlook.",
        "rows": [
            ("Freight railcar market", "Freight and tank car fleets from public filings", "Market intelligence on 40 car types, with analyst support", "them"),
            ("Railroad financials and service", "STB R-1, 10-K, EP 724 service metrics, short lines and safety", "Not the focus", "us"),
            ("Forecasts", "Freight flows to 2050; locomotive rebuild timing", "Rail Equipment Outlook (in the $35,000 bundle)", "them"),
            ("Passenger and transit", "Every passenger fleet, bids and awards", "Not covered", "us"),
            ("Format", "Web app with definitions on every number, CSV export", "Excel database and webinars", "tie"),
        ],
        "us_pros": ["Railroad filings, service and safety data in one place", "Passenger rail included", "A fraction of the price"],
        "us_cons": ["No railcar order forecasts", "No analyst webinars"],
        "them_pros": ["Deep freight railcar market expertise", "Analyst access and webinars"],
        "them_cons": ["Freight cars only", "$20,000 a year to start"],
        "verdict": "If you build or lease freight cars and need order forecasts with analyst support, FTR is the specialist. For railroad "
                   "filings, service metrics, locomotives and the passenger market at a much lower price, use {site}.",
        "sources": [("FTR rail equipment pricing", "https://freight.ftrintel.com/rem-challenges/pricing?hsLang=en")],
    },
}
for _k in ("railmarket", "rail-market-research", "global-mass-transit", "ftr"):
    COMPETITORS[_k]["checked"] = "November 2026"


def faqs(c, site):
    n = c["name"]
    return [
        (f"Is {site} a good {n} alternative?",
         f"For rail suppliers, fleet consultants and maintenance contractors, yes. {site} focuses only on rail in the US and "
         f"Canada: public rail and transit bids with fleet data on every bid, plus freight rail market data. If you sell outside rail, {n} covers more ground."),
        (f"{n} vs {site}: which is better?", c["verdict"].replace("{site}", site)),
        (f"How much does {n} cost compared with {site}?",
         f"{n}: {c['pricing']}. {site}: " + claims.fill("{prices}") + ", with yearly billing at 20% off."),
        (f"Does {site} have a free plan?",
         claims.fill("Yes, with no card. It samples every part of the site: {free_includes}. Saving, alerts and the AI analyst need a paid plan.")),
        (f"Can I use {site} and {n} together?",
         f"Yes. Many teams keep a general tool for broad coverage and use {site} for rail-specific bids, fleet facts and award analysis."),
    ]


def hub_faqs(site):
    return [
        ("What is the best rail procurement intelligence tool?",
         f"It depends on scope. General bid services such as BidPrime and BidNet Direct cover every public sector category. GovSpend "
         f"adds purchase order history for state and local government. {site} is built only for rail fleets and rail "
         f"work in the US and Canada and is the only one of these that ties each bid to fleet age, utilization and overhaul timing."),
        ("Where can I find rail car overhaul bids?",
         f"Rail agencies post them on their own portals and on platforms such as Bonfire, OpenGov, PlanetBids, BidNet Direct and Bid "
         f"Express. {site} watches " + claims.fill("{agencies}") + f" rail agencies across those platforms and Canadian open data and sends the relevant ones to you."),
        ("Is there a database of US transit rail fleets?",
         f"The FTA National Transit Database publishes vehicle inventories each year. {site} builds on it with researched fleets, "
         f"subsystem suppliers, estimated duty cycles, costs per car-mile and overhaul forecasts for " + claims.fill("{fleets}") + " active fleets."),
        ("Where can I find Class I and short line railroad data?",
         f"The STB publishes Class I annual R-1 reports and weekly EP 724 service data; the FRA publishes operations, safety and crossing "
         f"data for every railroad. The {site} Freight Rail Analytics Portal puts them together with 10-K financials, freight and tank car "
         f"fleets, freight flows to 2050 and rail cost indexes, with a definition on every number."),
    ]


# ---------- admin edits ----------
# Admins can edit any comparison, add new ones or hide one (Admin > Comparisons). Edits are stored as JSON in the setting
# "compare:<slug>" and laid over the defaults above; "Restore default" deletes the setting.
FIELDS = ["name", "category", "one_liner", "blurb", "pricing", "free", "summary", "verdict"]
LISTS = ["us_pros", "us_cons", "them_pros", "them_cons"]


def _overrides():
    from . import db
    out = {}
    for r in db.q("SELECT key, value FROM setting WHERE key LIKE 'compare:%'"):
        try:
            out[r["key"][8:]] = json.loads(r["value"])
        except ValueError:
            pass
    return out


def _merge(base, o):
    c = dict(base or {})
    c.update({k: v for k, v in o.items() if k in FIELDS + LISTS + ["hidden", "checked"]})
    if "rows" in o:
        c["rows"] = [tuple(r) for r in o["rows"]]
    if "sources" in o:
        c["sources"] = [tuple(s) for s in o["sources"]]
    for k in FIELDS:
        c.setdefault(k, "")
    for k in LISTS + ["rows", "sources"]:
        c.setdefault(k, [])
    c.setdefault("checked", CHECKED)
    return c


def all_items(include_hidden=False):
    ov = _overrides()
    items = {slug: _merge(base, ov.get(slug, {})) for slug, base in COMPETITORS.items()}
    for slug, o in ov.items():
        if slug not in items:
            items[slug] = _merge({}, o)
    for slug, c in items.items():
        c["edited"] = slug in ov
        c["custom"] = slug not in COMPETITORS
    from . import claims
    return {k: claims.fill_all(v) for k, v in items.items() if include_hidden or not v.get("hidden")}


def get(slug, include_hidden=False):
    return all_items(include_hidden).get(slug)


def save(slug, values):
    from . import db
    db.set_setting("compare:" + slug, json.dumps(values))


def reset(slug):
    from . import db
    db.x("DELETE FROM setting WHERE key = ?", ("compare:" + slug,))
