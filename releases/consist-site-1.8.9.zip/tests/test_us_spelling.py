"""US English check: fails when user-visible text in app/ or seed/ uses a UK spelling.
Run: python tests/test_us_spelling.py  (exit 1 lists file:line). Add proper nouns to ALLOW."""
import pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
UK = re.compile(r"\b(colou?r(?<=colour)\w*|Colour\w*|signalling|Signalling|licence|programme|catalogue|centre|analyse[ds]?|favour\w*|behaviour\w*|labour\w*|honour\w*|neighbour\w*|grey(ed)?|modelled|modelling|travell\w+|enrolment|"
                r"\w*(organis|recognis|summaris|categoris|utilis|realis|minimis|maximis|prioritis|optimis|standardis|authoris|customis|visualis|finalis|capitalis|moderni[s])(e|ed|es|ing|ation|ations)\b|organis\w+|whilst|amongst|defence|aluminium|cheque|tyre)\b")
ALLOW = ["Knowledge Centre", "Open Government Licence", '"signalling"', "Programme\"", "Rail Market Research"]
SKIP_LINE = re.compile(r"\b(def|import)\b|request\.session|_pending")
def scan():
    bad = []
    for p in list((ROOT / "app").rglob("*")) + list((ROOT / "seed").rglob("*.json")):
        if p.suffix not in (".py", ".html", ".json", ".js", ".md") or "__pycache__" in p.parts: continue
        for i, line in enumerate(p.read_text(errors="ignore").splitlines(), 1):
            if SKIP_LINE.search(line): continue
            t = line
            for a in ALLOW: t = t.replace(a, "")
            for m in UK.finditer(t):
                bad.append(f"{p.relative_to(ROOT)}:{i}: {m.group(0)}")
    return bad
def test_us_spelling():
    bad = scan(); assert not bad, "UK spellings:\n" + "\n".join(bad)
if __name__ == "__main__":
    b = scan(); print("\n".join(b) or "OK: US spelling"); sys.exit(1 if b else 0)
