"""Early-stage notices (push50: rail ones only; the rest are stage 'early_offtopic', see rail_ok): RFIs, sources sought, letters / expressions of interest, market soundings, industry days,
pre-solicitations, special notices and planned procurements. Sets notice.stage = 'early' (NULL otherwise), so the site's
Early signals page does not have to guess from titles. Keyword rules only, no Claude.

  bidmon early              notices first seen in the last 3 days (the daily scan does this too)
  bidmon early --backfill   every notice
"""
import re

import bidcore as bc

EARLY_RX = re.compile(
    r"request for information|\brfi\b|sources? sought|industry (?:day|forum|outreach)|market (?:sounding|survey|research)|"
    r"expressions? of interest|\beoi\b|letters? of interest|\bloi\b|pre-?solicitation|special notice|request for (?:comments?|feedback)|"
    r"draft (?:rfp|solicitation|specification)|advance (?:notice|procurement notice)|procurement forecast|upcoming (?:procurement|solicitation)|"
    r"demande d'information|appel d'intérêt|avis d'intention|sondage de marché|lettre d'intérêt|"
    r"solicitud de información|manifestación de interés", re.I)


def ensure(c):
    if "stage" not in {r[1] for r in c.execute("PRAGMA table_info(notice)")}:
        c.execute("ALTER TABLE notice ADD COLUMN stage TEXT")
        c.execute("CREATE INDEX IF NOT EXISTS notice_stage ON notice(stage)")
        c.commit()


def is_early(title, description="", notice_type=""):
    return (notice_type or "") == "planned" or bool(EARLY_RX.search(f"{title or ''} {(description or '')[:3000]}"))


RAIL_NAICS = re.compile(r"NAICS (336510|488210|482111|482112|485112)\b")  # rolling stock, rail support, railroads, commuter rail


def rail_ok(r):
    """push50 (Justin 11-20: "a lot of things in there that have nothing to do with rail industry (medical equipment?)"): an
    early-stage notice only counts as an Early signal when it is about rail. Returns (keep, why). Federal SAM.gov special
    notices and sources-sought under broad repair NAICS codes (811210 medical / lab equipment, 811310, 333415, 334290) were
    the bulk of the noise, and the site showed every RFI whatever its score."""
    import classify
    rel, rail, rv = r["relevance"] or 0, r["rail"], r["reviewed"] or ""
    ag = (r["agency_id"] or "").upper()
    if rail == 1:
        return True, "rail"
    if rv == "claude":  # the review's own call
        return (rel >= 30 and rail != 0), f"review: rail {rail}, relevance {rel}"
    d = classify.decide(r["title"], r["description"], r["agency_id"], r["notice_type"])
    if d and d[0] == 1:
        return True, d[3]
    if d and d[0] == 0:
        return False, d[3]
    if RAIL_NAICS.search(r["description"] or ""):
        return True, "rail NAICS"
    if ag in classify.RAIL_ONLY or ag in classify.RAIL_CAPABLE:
        return True, f"rail agency {ag}"
    return (rel >= 50), f"no rail evidence (relevance {rel})"


def refilter(c):
    """Re-checks every early-stage notice: rail ones keep stage 'early', the rest become 'early_offtopic' (kept, never deleted;
    `bidmon early --unfilter` puts them all back). Returns (kept, offtopic)."""
    rows = c.execute("SELECT notice_id, agency_id, title, description, notice_type, reviewed, relevance, rail, stage FROM notice "
                     "WHERE stage IN ('early', 'early_offtopic')").fetchall()
    k = o = 0
    for r in rows:
        ok, why = rail_ok(r)
        st = "early" if ok else "early_offtopic"
        k += ok
        o += not ok
        if st != r["stage"]:
            c.execute("UPDATE notice SET stage=? WHERE notice_id=?", (st, r["notice_id"]))
    c.commit()
    return k, o


def unfilter(c):
    n = c.execute("UPDATE notice SET stage='early' WHERE stage='early_offtopic'").rowcount
    c.commit()
    return n


def counts(c):
    q = lambda w: c.execute(f"SELECT count(*) FROM notice WHERE {w}").fetchone()[0]
    return {"early": q("stage='early'"), "early_offtopic": q("stage='early_offtopic'"),
            "early, last 365 days": q("stage='early' AND coalesce(published, first_seen) >= date('now','-365 days')"),
            "offtopic, last 365 days": q("stage='early_offtopic' AND coalesce(published, first_seen) >= date('now','-365 days')")}


def run(c, backfill=False, tag_all=False):
    """tag_all (push50): tag every notice, without the backfill's re-scoring step."""
    ensure(c)
    q = "SELECT notice_id, title, description, notice_type FROM notice WHERE stage IS NULL AND coalesce(notice_type, '') NOT IN ('award', 'cancelled')"
    if not (backfill or tag_all):
        q += " AND first_seen >= datetime('now', '-3 days')"
    n = 0
    for r in c.execute(q).fetchall():
        if is_early(r["title"], r["description"], r["notice_type"]):
            c.execute("UPDATE notice SET stage='early' WHERE notice_id=?", (r["notice_id"],))
            n += 1
    refilter(c)  # push50: rail ones stay 'early', the rest 'early_offtopic'
    if backfill:  # early notices the keywords buried: re-score (the floor in relevance.review applies), never alert them again
        rows = c.execute("SELECT notice_id FROM notice WHERE stage='early' AND coalesce(relevance, kw_score, 0) < 30 AND reviewed='keywords' "
                         "AND (source='sam_gov' OR agency_id IS NOT NULL) "
                         "AND (closing >= date('now') OR (closing IS NULL AND first_seen >= date('now', '-120 days')))").fetchall()
        for r in rows:
            c.execute("UPDATE notice SET kw_score=NULL, reviewed=NULL, notified=coalesce(notified, ?) WHERE notice_id=?", (bc.now(), r["notice_id"]))
        bc.log(f"early: {len(rows)} open early-stage notices queued for re-scoring")
    c.commit()
    return n
