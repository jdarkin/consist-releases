"""Admin portal under /admin: dashboard, users, plans and Stripe, content, settings, data status, bid sources, leads, audit."""
import datetime
import json
import logging
import re

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse

from .routes_public import safe_next

from . import analyst, auth, backups, bidcatcher, billing, claims, compare, config, data, db, guide, lens, mailer, maint, signupguard, twofa
from .main import flash, redirect, render

log = logging.getLogger("consist")

router = APIRouter(prefix="/admin")
A = Depends(auth.require_admin)


def since(days):
    return (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)).isoformat()


# Overview counts real customers only: admins and @example.com test accounts are left out, and after "Reset statistics"
# (setting stats_since) only what happened since then counts. Nothing is deleted, so "Undo reset" brings everything back.
REAL = "role != 'admin' AND email NOT LIKE '%@example.com'"


@router.get("")
def dash(request: Request, u=A):
    s0 = db.settings().get("stats_since") or ""
    cut = lambda days: max(since(days), s0)  # noqa: E731
    uw = f"{REAL} AND coalesce(created, '') >= ?"
    mrr, by_plan = billing.mrr(f"u.{REAL.replace(' AND ', ' AND u.')} AND coalesce(u.created, '') >= ?", (s0,))
    counts = {r["plan_id"]: r["n"] for r in db.q(f"SELECT plan_id, count(*) n FROM user WHERE team_owner_id IS NULL AND {uw} GROUP BY 1", (s0,))}
    signups = db.q(f"SELECT substr(created,1,10) d, count(*) n FROM user WHERE {REAL} AND created >= ? GROUP BY 1 ORDER BY 1", (cut(30),))
    mine = f"user_id IN (SELECT id FROM user WHERE {REAL})"
    stats = db.q(f"SELECT (SELECT count(*) FROM user WHERE {uw}) users, (SELECT count(*) FROM user WHERE {REAL} AND created >= ?) new30, "
                 f"(SELECT count(*) FROM user WHERE {uw} AND last_login >= ?) active7, "
                 f"(SELECT count(*) FROM saved_search WHERE {mine} AND coalesce(created, '') >= ?) searches, "
                 f"(SELECT count(*) FROM analyst_job WHERE {mine} AND created >= ?) ai30, "
                 "(SELECT round(sum(cost_usd),2) FROM analyst_job WHERE created >= ?) ai_cost30, "
                 "(SELECT count(*) FROM lead WHERE status = 'new' AND email NOT LIKE '%@example.com' AND coalesce(ts, '') >= ?) leads, "
                 "(SELECT count(*) FROM source_request WHERE status = 'new' AND coalesce(ts, '') >= ?) requests",
                 (s0, cut(30), s0, cut(7), s0, cut(30), cut(30), s0, s0), one=True)
    return render(request, "admin/dash.html", user=u, mrr=mrr, by_plan=by_plan, counts=counts, signups=signups, st=stats, stats_since=s0,
                  plans={p["id"]: p for p in db.plans(False)}, events=db.q("SELECT * FROM billing_event WHERE coalesce(ts, '') >= ? ORDER BY id DESC LIMIT 8", (s0,)),
                  recent=db.q(f"SELECT * FROM user WHERE {uw} ORDER BY id DESC LIMIT 8", (s0,)), ds=data.data_status(), stripe_on=config.STRIPE_ENABLED,
                  ai_on=analyst.available(), mail_on=mailer.configured(), demo=billing.demo_mode())


@router.post("/stats-reset")
def stats_reset(request: Request, csrf: str = Form(""), undo: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if undo:
        db.x("DELETE FROM setting WHERE key = 'stats_since'")
        db.audit("admin_stats", "overview statistics reset undone", None, u.email)
        flash(request, "Overview statistics count everything again.")
    else:
        db.set_setting("stats_since", db.now())
        db.audit("admin_stats", "overview statistics reset", None, u.email)
        flash(request, "Statistics reset. Overview now counts from this moment; nothing was deleted.")
    return redirect("/admin")


# ---------- users ----------

@router.get("/users")
def users(request: Request, u=A):
    q = request.query_params.get("q", "").strip()
    plan = request.query_params.get("plan", "")
    where, args = ["1=1"], []
    if q:
        where.append("(email LIKE ? OR name LIKE ? OR company LIKE ?)")
        args += [f"%{q}%"] * 3
    if plan:
        where.append("plan_id = ?")
        args.append(plan)
    rows = db.q(f"SELECT * FROM user WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT 500", args)
    return render(request, "admin/users.html", user=u, rows=rows, q=q, plan=plan, plans=db.plans(False))


@router.post("/users/new")
def user_new(request: Request, csrf: str = Form(""), email: str = Form(""), name: str = Form(""), company: str = Form(""),
             plan_id: str = Form("free"), role: str = Form("user"), u=A):
    auth.check_csrf(request, csrf)
    email = email.strip().lower()
    if "@" not in email or db.q("SELECT 1 FROM user WHERE email = ?", (email,), one=True):
        flash(request, "Enter a new, valid email.", "bad")
        return redirect("/admin/users")
    uid = auth.create_user(email, None, name, company, role=role, plan_id=plan_id)
    if plan_id != "free":
        db.x("UPDATE user SET sub_status = 'manual' WHERE id = ?", (uid,))
    tok = auth.make_token("reset", uid, hours=24 * 7)
    link = f"{config.SITE_URL}/reset/{tok}"
    sent = False
    try:
        sent = mailer.send(email, f"Your {db.settings().get('site_name')} account", f"An account was created for you. Set your password here (valid 7 days):\n{link}")
    except Exception:
        pass
    db.audit("admin_create_user", email, uid, u.email)
    flash(request, "User created and emailed a set-password link." if sent else f"User created. Send them this set-password link: {link}")
    return redirect(f"/admin/users/{uid}")


@router.get("/usage")
def usage_page(request: Request, days: int = 30, tab: str = "overview", u=A):
    from . import usage as US
    days = days if days in (1, 7, 30, 90, 365) else 30
    tab = tab if tab in ("overview", "now", "members", "pages", "sources") else "overview"
    ctx = dict(days=days, tab=tab, live=US.live())
    if tab == "overview":
        ctx.update(sm=US.summary(days), daily=US.daily(min(days, 90) if days > 1 else 7), areas=US.top_areas(days), sources=US.sources(days))
    elif tab == "members":
        ctx.update(members=US.members(days))
    elif tab == "pages":
        ctx.update(pages=US.top_pages(days, 100), mpages=US.top_pages(days, 50, members_only=True))
    elif tab == "sources":
        ctx.update(channels=US.channels(days))
    plans = {p["id"]: p["name"] for p in db.plans(active_only=False)}
    return render(request, "admin/usage.html", user=u, plans=plans, **ctx)


@router.get("/usage/user/{uid}")
def usage_user(request: Request, uid: int, u=A):
    from . import usage as US
    m = db.q("SELECT * FROM user WHERE id = ?", (uid,), one=True)
    if not m:
        raise HTTPException(404)
    plans = {p["id"]: p["name"] for p in db.plans(active_only=False)}
    return render(request, "admin/usage_user.html", user=u, m=dict(m), st=US.user_stats(uid), days=US.timeline(uid), plans=plans)


@router.get("/users/{uid}")
def user_detail(request: Request, uid: int, u=A):
    r = db.q("SELECT * FROM user WHERE id = ?", (uid,), one=True)
    if not r:
        raise HTTPException(404)
    return render(request, "admin/user.html", user=u, r=r, plans=db.plans(False),
                  searches=db.q("SELECT * FROM saved_search WHERE user_id = ?", (uid,)),
                  jobs=db.q("SELECT * FROM analyst_job WHERE user_id = ? ORDER BY created DESC LIMIT 10", (uid,)),
                  team=db.q("SELECT id, email FROM user WHERE team_owner_id = ?", (uid,)),
                  log=db.q("SELECT * FROM audit WHERE user_id = ? ORDER BY id DESC LIMIT 20", (uid,)),
                  events=db.q("SELECT * FROM billing_event WHERE user_id = ? ORDER BY id DESC LIMIT 20", (uid,)),
                  prof=intel.profile(r), profile_fields=intel.PROFILE_FIELDS,
                  personas=[lens.PERSONAS[k]["label"] for k in intel.personas_for(r) if k in lens.PERSONAS])


@router.post("/users/{uid}")
def user_save(request: Request, uid: int, csrf: str = Form(""), name: str = Form(""), company: str = Form(""), role: str = Form("user"),
              plan_id: str = Form("free"), status: str = Form("active"), sub_status: str = Form(""), notes: str = Form(""),
              ai_used: int = Form(0), u=A):
    auth.check_csrf(request, csrf)
    if uid == u["id"] and (role != "admin" or status != "active"):
        flash(request, "You can't remove your own admin access or disable yourself.", "bad")
        return redirect(f"/admin/users/{uid}")
    db.x("UPDATE user SET name=?, company=?, role=?, plan_id=?, status=?, sub_status=?, notes=?, ai_used=? WHERE id=?",
         (name, company, role, plan_id, status, sub_status or None, notes, ai_used, uid))
    db.audit("admin_edit_user", json.dumps(dict(role=role, plan=plan_id, status=status, sub=sub_status)), uid, u.email)
    flash(request, "Saved. Note: plan changes here don't change Stripe; use 'manual' for comped accounts.")
    return redirect(f"/admin/users/{uid}")


@router.post("/users/{uid}/reset")
def user_reset(request: Request, uid: int, csrf: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    r = db.q("SELECT email FROM user WHERE id = ?", (uid,), one=True)
    tok = auth.make_token("reset", uid, hours=48)
    link = f"{config.SITE_URL}/reset/{tok}"
    sent = False
    try:
        sent = mailer.send(r["email"], "Reset your password", f"Set a new password here (valid 48 hours):\n{link}")
    except Exception:
        pass
    db.audit("admin_reset_link", r["email"], uid, u.email)
    flash(request, "Reset link emailed." if sent else f"Reset link (email not configured): {link}")
    return redirect(f"/admin/users/{uid}")


@router.post("/users/{uid}/2fa-reset")
def user_2fa_reset(request: Request, uid: int, csrf: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    twofa.disable(uid)
    db.audit("2fa_reset", "admin", uid, u.email)
    flash(request, "Two-factor sign-in is off for this account. If it's required for them, they set it up again at their next sign-in.")
    return redirect(f"/admin/users/{uid}")


@router.post("/users/{uid}/delete")
def user_delete(request: Request, uid: int, csrf: str = Form(""), confirm: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    r = db.q("SELECT email FROM user WHERE id = ?", (uid,), one=True)
    if not r or uid == u["id"] or confirm.strip().lower() != r["email"]:
        flash(request, "Type the user's email to confirm. You can't delete yourself.", "bad")
        return redirect(f"/admin/users/{uid}")
    st = auth.delete_account(uid)
    db.audit("admin_delete_user", f"{r['email']} stripe={st}", None, u.email)
    flash(request, f"Deleted {r['email']}." + (" Their Stripe subscription was cancelled." if st == "cancelled" else
                                               " Cancel their Stripe subscription in the Stripe dashboard." if st == "failed" else ""))
    return redirect("/admin/users")


# ---------- plans and billing ----------

@router.get("/plans")
def plans(request: Request, u=A):
    return render(request, "admin/plans.html", user=u, plans=db.plans(False), stripe_on=config.STRIPE_ENABLED, demo=billing.demo_mode(),
                  webhook=f"{config.SITE_URL}/stripe/webhook", hook_on=bool(config.STRIPE_WEBHOOK_SECRET),
                  events=db.q("SELECT * FROM billing_event ORDER BY id DESC LIMIT 30"))


@router.post("/plans/{pid}")
async def plan_save(request: Request, pid: str, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))

    def num(k, cast=float):
        try:
            return cast(form.get(k) or 0)
        except ValueError:
            return cast(0)
    feats = [k for k in db.FEATURE_LABELS if form.get(f"f_{k}")]
    from . import pages as PG
    prev = db.get_plan(pid)
    if not any(k.startswith("pa_") for k in form.keys()):  # a form without the page grid (scripts, the smoke test): keep page access as is
        feats += [x for x in prev.get("features", []) if str(x).startswith(("pg:", "pv:"))]
    else:
        row = {path: form.get(f"pa_{path}") or "full" for _, path, _ in PG.PAGES}
        if PG.gated(prev) or any(v != "full" for v in row.values()):  # page tokens only once a plan uses page access
            feats += PG.tokens(row)
    vals = (form.get("name", pid), form.get("blurb", ""), int(round(num("price_month") * 100)), int(round(num("price_year") * 100)),
            (form.get("stripe_price_month") or "").strip() or None, (form.get("stripe_price_year") or "").strip() or None,
            num("seats", int), num("ai_quota", int), num("search_limit", int), json.dumps(feats),
            json.dumps([b.strip() for b in (form.get("bullets") or "").splitlines() if b.strip()]), num("sort", int),
            1 if form.get("active") else 0, 1 if form.get("highlight") else 0, 1 if form.get("contact_only") else 0)
    db.x("UPDATE plan SET name=?, blurb=?, price_month=?, price_year=?, stripe_price_month=?, stripe_price_year=?, seats=?, ai_quota=?, "
         "search_limit=?, features=?, bullets=?, sort=?, active=?, highlight=?, contact_only=? WHERE id=?", vals + (pid,))
    db.audit("admin_plan", pid, None, u.email)
    claims.reset()
    flash(request, f"Plan {vals[0]} saved.")
    return redirect("/admin/plans")


# ---------- Ambassadors: free full-access subscriptions by invitation, no Stripe (app/ambassadors.py) ----------

@router.get("/ambassadors")
def ambassadors_page(request: Request, u=A):
    from . import ambassadors as AM
    return render(request, "admin/ambassadors.html", user=u, rows=AM.rows(), plans=db.plans(active_only=False),
                  default_plan=AM.default_plan(), mail_on=mailer.configured(), ai_on=bool(config.ANTHROPIC_API_KEY))


@router.post("/ambassadors/preview")
async def ambassadors_preview(request: Request, u=A):
    """The exact email an invite would send, built from the unsaved form (the link is a placeholder)."""
    from fastapi.responses import JSONResponse
    from . import ambassadors as AM, richtext
    form = await request.form()
    auth.check_csrf(request, str(form.get("csrf", "")))
    note_html = richtext.clean(str(form.get("note_html", "")))
    a = {"name": str(form.get("name", "")).strip(), "plan_id": str(form.get("plan_id", "")), "until": str(form.get("until", "")).strip(),
         "note_html": note_html, "note": "", "subject": str(form.get("subject", "")).strip(),
         "note_full": bool(form.get("note_full")) or (bool(note_html) and richtext.is_letter(note_html))}
    subj, text, html = AM.compose(a, f"{config.SITE_URL}/ambassador/preview")
    if form.get("test"):  # "Send a test to me": the same email to the admin's own address, no invite created
        try:
            ok = mailer.send(u.email, "[Test] " + subj, text, html)
        except Exception:
            ok = False
        return JSONResponse({"sent": bool(ok), "to": u.email})
    return JSONResponse({"subject": subj, "html": html, "whole_letter": a["note_full"]})


@router.post("/ambassadors/draft")
async def ambassadors_draft(request: Request, u=A):
    """Drafts an invite with AI from pasted LinkedIn profile text or LinkedIn's PDF export (the site never fetches LinkedIn)."""
    from fastapi.responses import JSONResponse
    from . import invitedraft
    form = await request.form()
    auth.check_csrf(request, str(form.get("csrf", "")))
    if not invitedraft.available():
        return JSONResponse({"error": "Add the AI key in Admin > Settings to draft invites."}, status_code=400)
    f = form.get("pdf")
    pdf = await f.read() if f is not None and hasattr(f, "read") else b""
    plan = db.get_plan(str(form.get("plan_id", ""))) or {}
    try:
        out = invitedraft.draft(str(form.get("profile", "")), pdf, str(form.get("linkedin", "")).strip(), str(form.get("context", "")),
                                plan.get("name", ""), str(form.get("until", "")), u.name or "")
    except invitedraft.DraftError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    db.audit("ambassador_ai_draft", f"{out.get('full_name', '')} (${out['cost']})", None, u.email)
    return JSONResponse(out)


@router.post("/ambassadors")
def ambassadors_invite(request: Request, csrf: str = Form(""), email: str = Form(""), name: str = Form(""), plan_id: str = Form(""),
                       until: str = Form(""), note: str = Form(""), note_html: str = Form(""), send: str = Form(""),
                       subject: str = Form(""), note_full: str = Form(""), linkedin: str = Form(""), u=A):
    from . import ambassadors as AM
    auth.check_csrf(request, csrf)
    email = email.strip().lower()
    if "@" not in email or not db.q("SELECT 1 FROM plan WHERE id = ?", (plan_id,), one=True):
        flash(request, "Enter a valid email and pick a plan.", "bad")
        return redirect("/admin/ambassadors")
    if until and until < db.now()[:10]:
        flash(request, "The end date is in the past.", "bad")
        return redirect("/admin/ambassadors")
    _, sent = AM.invite(email, name.strip(), plan_id, until.strip(), note.strip(), u.email, send=bool(send), note_html=note_html,
                         subject=subject, note_full=bool(note_full), linkedin=linkedin)
    flash(request, f"Invitation for {email} created" + (" and emailed." if sent else ". Copy the link from the list below and send it yourself."))
    return redirect("/admin/ambassadors")


@router.post("/ambassadors/{aid}/{act}")
def ambassadors_act(request: Request, aid: int, act: str, csrf: str = Form(""), until: str = Form(""), u=A):
    from . import ambassadors as AM
    auth.check_csrf(request, csrf)
    if act == "resend":
        flash(request, "A new link was emailed." if AM.renew(aid) else "A new link was made, but email isn't working: copy it from the list.")
    elif act == "until":
        AM.set_until(aid, until.strip())
        flash(request, "End date saved." if until.strip() else "No end date: free access until you revoke it.")
    elif act == "revoke":
        AM.revoke(aid, u.email)
        flash(request, "Revoked. If they had accepted, they're now on Free.")
    return redirect("/admin/ambassadors")


@router.post("/view-as")
def view_as(request: Request, csrf: str = Form(""), plan: str = Form(""), go: str = Form("/app"), u=A):
    """'View as plan': this admin's session only (auth.view_as). An empty plan switches back."""
    auth.check_csrf(request, csrf)
    go = go if go.startswith("/") and not go.startswith("//") else "/app"
    if plan and db.q("SELECT 1 FROM plan WHERE id = ?", (plan,), one=True):
        request.session["view_plan"] = plan
        db.audit("admin_view_as", plan, None, u.email)
        return redirect(go)
    request.session.pop("view_plan", None)
    flash(request, "Back to the admin view.")
    return redirect("/admin" if go.startswith("/admin") or not plan else go)


@router.post("/plans-new")
def plan_new(request: Request, csrf: str = Form(""), pid: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    pid = data.slug(pid).replace("-", "_")
    if not pid or db.q("SELECT 1 FROM plan WHERE id = ?", (pid,), one=True):
        flash(request, "Choose a new, unique plan id.", "bad")
    else:
        db.x("INSERT INTO plan (id, name, active, sort) VALUES (?, ?, 0, 9)", (pid, pid.title()))
        flash(request, "Plan created (inactive). Fill it in and tick Active.")
    return redirect("/admin/plans")


@router.post("/stripe/create-prices")
def stripe_prices(request: Request, csrf: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if not config.STRIPE_ENABLED:
        flash(request, "Add STRIPE_SECRET_KEY to the server's .env first.", "bad")
        return redirect("/admin/plans")
    try:
        done = billing.create_prices()
        flash(request, ("Created: " + "; ".join(done)) if done else "Every paid plan already has Stripe prices.")
        db.audit("stripe_create_prices", "; ".join(done), None, u.email)
    except Exception as e:
        flash(request, f"Stripe error: {e}", "bad")
    return redirect("/admin/plans")


# ---------- content and settings ----------

@router.get("/content")
def content(request: Request, u=A):
    return render(request, "admin/content.html", user=u, pages=db.q("SELECT * FROM page ORDER BY kind, slug"),
                  anns=db.q("SELECT * FROM announcement ORDER BY id DESC"))


@router.get("/content/edit")
def content_edit(request: Request, u=A):
    slug = request.query_params.get("slug", "")
    p = db.q("SELECT * FROM page WHERE slug = ?", (slug,), one=True) if slug else None
    return render(request, "admin/page_edit.html", user=u, p=p)


@router.post("/content/edit")
def content_save(request: Request, csrf: str = Form(""), slug: str = Form(""), orig: str = Form(""), title: str = Form(""),
                 description: str = Form(""), body: str = Form(""), kind: str = Form("page"), published: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    slug = data.slug(slug)
    if not slug or not title.strip():
        flash(request, "A page needs a slug and a title.", "bad")
        return redirect(f"/admin/content/edit?slug={orig}")
    if orig and orig != slug:
        db.x("DELETE FROM page WHERE slug = ?", (orig,))
    db.x("INSERT INTO page (slug, title, description, body, kind, published, updated) VALUES (?,?,?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET "
         "title=excluded.title, description=excluded.description, body=excluded.body, kind=excluded.kind, published=excluded.published, updated=excluded.updated",
         (slug, title.strip(), description.strip(), body, kind, 1 if published else 0, db.now()))
    db.audit("admin_page", slug, None, u.email)
    flash(request, "Page saved.")
    return redirect(f"/admin/content/edit?slug={slug}")


@router.post("/content/delete")
def content_delete(request: Request, csrf: str = Form(""), slug: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    db.x("DELETE FROM page WHERE slug = ?", (slug,))
    flash(request, "Page deleted.")
    return redirect("/admin/content")


@router.post("/announcements")
def announcement(request: Request, csrf: str = Form(""), text: str = Form(""), link: str = Form(""), audience: str = Form("all"),
                 aid: int = Form(0), action: str = Form("add"), u=A):
    auth.check_csrf(request, csrf)
    if action == "add" and text.strip():
        db.x("INSERT INTO announcement (text, link, audience, active, created) VALUES (?,?,?,1,?)", (text.strip(), link.strip(), audience, db.now()))
    elif action == "toggle":
        db.x("UPDATE announcement SET active = 1 - active WHERE id = ?", (aid,))
    elif action == "delete":
        db.x("DELETE FROM announcement WHERE id = ?", (aid,))
    return redirect("/admin/content#banner")


# ---------- data and sources ----------

@router.get("/data")
def data_page(request: Request, u=A):
    jobs = db.q("SELECT j.*, u.email FROM analyst_job j LEFT JOIN user u ON u.id = j.user_id ORDER BY j.created DESC LIMIT 40")
    return render(request, "admin/data.html", user=u, ds=data.data_status(), jobs=jobs, ai_on=analyst.available(), cfg=config, bk=backups.status())


@router.post("/backup/now")
def backup_now(request: Request, csrf: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    backups.request_now()
    db.audit("backup_requested", "", None, u.email)
    flash(request, "Backup requested. The server starts it within five minutes; refresh this page to see it.")
    return redirect("/admin/data#backups")


@router.post("/backup/nas-key")
def backup_nas_key(request: Request, csrf: str = Form(""), key: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if backups.set_nas_key(key):
        db.audit("backup_nas_key", key.strip()[:40], None, u.email)
        flash(request, "Key saved. The server installs it within five minutes; then run the task on the Synology again.")
    else:
        flash(request, "That doesn't look like an SSH public key. Paste the single line from nas_public_key.txt (it starts with ssh-ed25519).", "bad")
    return redirect("/admin/data#backups")


def _scan_label(err):
    """One short label for a page-watch error."""
    e = (err or "").lower()
    if "robots" in e:
        return "blocked by site"
    if "404" in e:
        return "page gone"
    if "403" in e:
        return "refused"
    return "error"


def source_rows(rows):
    """Adds how Bid Catcher actually hears from each agency (channel) and the page-scan health from page_watch."""
    try:
        scans = {r["agency_id"]: dict(r) for r in db.bq(
            "SELECT agency_id, count(*) urls, sum(last_error IS NOT NULL AND last_error != '') errs, max(last_checked) checked, "
            "group_concat(CASE WHEN last_error != '' THEN last_error END, ' | ') errors FROM page_watch GROUP BY agency_id")}
    except Exception:
        scans = {}
    freight = db.freight_ids()[1]
    out = []
    for r in rows:
        a = dict(r)
        ch, plat = (a.get("alert_channel") or "").lower(), (a.get("platform") or "").lower()
        sc = scans.get(a["agency_id"])
        if "page watch" in ch or sc:
            a["channel"] = "Page scan"
        elif "seao" in ch or "canadabuys" in ch or "seao" in plat or "canadabuys" in plat:
            a["channel"] = "Open data"
        elif a["agency_id"] in freight:
            a["channel"] = "Invite only"
        else:
            a["channel"] = "Portal email"
        a["scan"] = sc
        if sc:
            labels = sorted({_scan_label(e) for e in (sc["errors"] or "").split(" | ") if e})
            a["scan_status"] = "ok" if not sc["errs"] else f"{sc['errs']} of {sc['urls']} failing: " + ", ".join(labels)
        out.append(a)
    return out


@router.get("/coverage")
def coverage_admin(request: Request, u=A):
    """1.7.48: Bid Catcher coverage health, every agency_coverage column plus the sources behind it."""
    from . import coverage
    f = {k: request.query_params.get(k, "") for k in ("status", "quiet", "blocked") if request.query_params.get(k)}
    v = coverage.admin_view(f)
    pts, nomap = coverage.map_points(v["rows"], admin=True)
    return render(request, "admin/coverage.html", user=u, v=v, f=f, STATUS=coverage.STATUS, pts=pts, nomap=nomap,
                  MAP_COLORS=coverage.MAP_COLORS, QUIET_COLOR=coverage.QUIET_COLOR, show_map=request.query_params.get("map") == "1")


@router.get("/sources")
def sources(request: Request, u=A):
    rows = db.bq("SELECT g.*, (SELECT count(*) FROM notice n WHERE n.agency_id = g.agency_id AND coalesce(n.relevance,0) >= 50) notices, "
                 "(SELECT count(*) FROM notice n WHERE n.agency_id = g.agency_id) notices_all, "
                 "(SELECT max(published) FROM notice n WHERE n.agency_id = g.agency_id) latest FROM agency g ORDER BY g.country DESC, g.agency")
    regs = db.bq("SELECT * FROM registration ORDER BY status, platform")
    return render(request, "admin/sources.html", user=u, rows=source_rows(rows), regs=regs, writable=config.BIDS_DB_WRITABLE,
                  requests=db.q("SELECT r.*, u.email FROM source_request r LEFT JOIN user u ON u.id = r.user_id ORDER BY r.id DESC"))


@router.post("/sources/{agency_id}")
def source_save(request: Request, agency_id: str, csrf: str = Form(""), portal_url: str = Form(""), watch: str = Form(""),
                notes: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if not config.BIDS_DB_WRITABLE:
        flash(request, "Bid sources are read-only here. Set BIDS_DB_WRITABLE=1 to edit them from the site.", "bad")
        return redirect("/admin/sources")
    c = db.bids_rw()
    try:
        c.execute("UPDATE agency SET portal_url = ?, watch = ?, notes = ? WHERE agency_id = ?", (portal_url.strip(), 1 if watch else 0, notes, agency_id))
        c.commit()
    finally:
        c.close()
    db.audit("admin_source", f"{agency_id} watch={1 if watch else 0}", None, u.email)
    flash(request, f"{agency_id} saved. Bid Catcher picks it up on its next scan.")
    return redirect("/admin/sources")


@router.post("/sources-add")
def source_add(request: Request, csrf: str = Form(""), agency_id: str = Form(""), agency: str = Form(""), country: str = Form("US"),
               state_prov: str = Form(""), platform: str = Form(""), portal_url: str = Form(""), fleet_operator_ids: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if not config.BIDS_DB_WRITABLE:
        flash(request, "Bid sources are read-only here. Set BIDS_DB_WRITABLE=1 to add them from the site.", "bad")
        return redirect("/admin/sources")
    aid = data.slug(agency_id).upper().replace("-", "_")
    if not aid or not agency.strip():
        flash(request, "An agency needs an id and a name.", "bad")
        return redirect("/admin/sources")
    c = db.bids_rw()
    try:
        c.execute("INSERT INTO agency (agency_id, agency, country, state_prov, platform, portal_url, fleet_operator_ids, listing_public, watch, verified) "
                  "VALUES (?,?,?,?,?,?,?,'yes',1,?)", (aid, agency.strip(), country, state_prov, platform, portal_url, fleet_operator_ids, f"admin {db.now()[:10]}"))
        c.commit()
    except Exception as e:
        flash(request, f"Could not add: {e}", "bad")
        return redirect("/admin/sources")
    finally:
        c.close()
    db.audit("admin_source_add", aid, None, u.email)
    flash(request, f"Added {aid}. Bid Catcher will start watching it on its next scan.")
    return redirect("/admin/sources")


@router.post("/requests/{rid}")
def request_status(request: Request, rid: int, csrf: str = Form(""), status: str = Form("done"), u=A):
    auth.check_csrf(request, csrf)
    db.x("UPDATE source_request SET status = ? WHERE id = ?", (status, rid))
    return redirect("/admin/sources#requests")


@router.get("/leads")
def leads(request: Request, u=A):
    return render(request, "admin/leads.html", user=u, rows=db.q("SELECT * FROM lead ORDER BY id DESC LIMIT 300"),
                  audit=db.q("SELECT * FROM audit ORDER BY id DESC LIMIT 200"))


@router.post("/leads/{lid}")
def lead_status(request: Request, lid: int, csrf: str = Form(""), status: str = Form("done"), u=A):
    auth.check_csrf(request, csrf)
    db.x("UPDATE lead SET status = ? WHERE id = ?", (status, lid))
    return redirect("/admin/leads")


# ---------- feature requests ----------

REQ_STATUSES = ["new", "reviewing", "planned", "building", "shipped", "declined"]


@router.get("/feature-requests")
def feature_requests(request: Request, u=A):
    st = request.query_params.get("status") or ""
    st = st if st in REQ_STATUSES else ""
    if request.query_params.get("export"):
        from .routes_app import csv_response
        cols = ["id", "ts", "email", "name", "plan_id", "page", "request", "status", "implemented", "credited", "credit_note", "admin_note"]
        return csv_response("consist-feature-requests", cols, [dict(r) for r in db.q("SELECT * FROM feature_request ORDER BY id DESC")])
    rows = db.q("SELECT * FROM feature_request" + (" WHERE status = ?" if st else "") + " ORDER BY id DESC LIMIT 500", (st,) if st else ())
    counts = {r["status"]: r["n"] for r in db.q("SELECT status, count(*) n FROM feature_request GROUP BY status")}
    return render(request, "admin/requests.html", user=u, rows=rows, st=st, counts=counts, STATUSES=REQ_STATUSES)


@router.post("/feature-requests/{rid}")
async def feature_request_save(request: Request, rid: int, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    r = db.q("SELECT * FROM feature_request WHERE id = ?", (rid,), one=True)
    if not r:
        raise HTTPException(404)
    st = form.get("status") if form.get("status") in REQ_STATUSES else r["status"]
    impl = (r["implemented"] or db.now()) if form.get("implemented") else None
    cred = r["credited"] if r["credit_txn"] else (r["credited"] or db.now()) if form.get("credited") and r["user_id"] else None
    db.x("UPDATE feature_request SET status = ?, implemented = ?, credited = ?, credit_note = ?, admin_note = ? WHERE id = ?",
         (st, impl, cred, r["credit_note"] if r["credit_txn"] else str(form.get("credit_note") or "")[:300], str(form.get("admin_note") or "")[:1000], rid))
    db.audit("feature_request", f"#{rid} {st}" + (" implemented" if impl else "") + (" credited" if cred else ""), r["user_id"], u.email)
    flash(request, f"Request #{rid} saved.")
    back = form.get("back") if form.get("back") in REQ_STATUSES else ""
    return redirect("/admin/feature-requests" + (f"?status={back}" if back else ""))


@router.post("/feature-requests/{rid}/credit")
def feature_request_credit(request: Request, rid: int, csrf: str = Form(""), notify: str = Form(""), back: str = Form(""), u=A):
    """Credits the sender one month of their plan price on their Stripe balance, once per request."""
    auth.check_csrf(request, csrf)
    r = db.q("SELECT * FROM feature_request WHERE id = ?", (rid,), one=True)
    if not r:
        raise HTTPException(404)
    to = "/admin/feature-requests" + (f"?status={back}" if back in REQ_STATUSES else "")
    sender = db.q("SELECT * FROM user WHERE id = ?", (r["user_id"],), one=True) if r["user_id"] else None
    if r["credit_txn"]:
        flash(request, f"Request #{rid} was already credited.")
        return redirect(to)
    if not sender:
        flash(request, "This sender has no account, so there is no Stripe balance to credit.")
        return redirect(to)
    if not config.STRIPE_ENABLED:
        flash(request, "Stripe isn't connected (Admin > Settings > Billing), so no credit was given.")
        return redirect(to)
    sender = dict(sender)
    cents = billing.credit_month_cents(sender)
    if not cents:
        flash(request, "No paid plan price to base the credit on. Set prices in Admin > Plans.")
        return redirect(to)
    try:
        txn = billing.credit_balance(sender, cents, f"Thanks for your Consist suggestion #{rid}: one month credit")
    except Exception as e:  # noqa: BLE001  (Stripe errors are shown, not raised)
        flash(request, f"Stripe refused the credit: {getattr(e, 'user_message', None) or e}")
        return redirect(to)
    note = f"${cents / 100:,.2f} Stripe credit (1 month)"
    db.x("UPDATE feature_request SET credited = ?, credit_cents = ?, credit_txn = ?, credit_note = ?, implemented = coalesce(implemented, ?), "
         "status = 'shipped' WHERE id = ?", (db.now(), cents, txn, note, db.now(), rid))
    db.audit("feature_request_credit", f"#{rid} {note} {txn}", sender["id"], u.email)
    mailed = False
    if notify and mailer.configured():
        s = db.settings()
        try:
            mailer.send(sender["email"], "We built your suggestion, and your next month is on us",
                        f"You asked us for:\n\n{(r['request'] or '').strip()[:1500]}\n\nIt's live now. As a thank-you we've put a ${cents / 100:,.2f} credit "
                        f"(one month of your plan) on your account. It comes off your next invoice automatically.\n\nKeep them coming: {config.SITE_URL}/request\n\n{s.get('site_name') or 'Consist'}")
            mailed = True
        except Exception:  # noqa: BLE001
            log.exception("credit email failed")
    flash(request, f"Credited {note} to {sender['email']}" + (" and emailed them." if mailed else "."))
    return redirect(to)


@router.post("/test-email")
def test_email(request: Request, csrf: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    back = "/admin/settings?tab=email" if "/admin/settings" in request.headers.get("referer", "") else "/admin/data"
    try:
        ok = mailer.send(u.email, "Test email", "Email from your site works.")
        flash(request, "Test email sent." if ok else "Email isn't set up yet. Add SMTP details in Settings → Email.", "ok" if ok else "bad")
    except Exception as e:
        flash(request, f"Email failed: {e}", "bad")
    return redirect(back)


# ---------- admin sign-in and own account ----------

@router.get("/login")
@router.post("/login")
def admin_login(request: Request):
    """No separate admin sign-in page: admins use /login and the Admin link appears after sign-in."""
    raise HTTPException(404, "Not Found")


@router.get("/account")
def admin_account(request: Request, u=A):
    return render(request, "admin/account.html", user=u,
                  admins=db.q("SELECT id, email, name, last_login FROM user WHERE role = 'admin' ORDER BY id"),
                  logins=db.q("SELECT * FROM audit WHERE action = 'admin_login' AND actor = ? ORDER BY id DESC LIMIT 8", (u.email,)))


@router.post("/account")
def admin_account_save(request: Request, csrf: str = Form(""), name: str = Form(""), email: str = Form(""), current: str = Form(""),
                       new: str = Form(""), confirm: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    email = email.strip().lower()
    if not auth.check_pw(current, u["pw_hash"]):
        flash(request, "Enter your current password to save changes.", "bad")
        return redirect("/admin/account")
    if "@" not in email or db.q("SELECT 1 FROM user WHERE email = ? AND id != ?", (email, u["id"]), one=True):
        flash(request, "That email is not valid or belongs to another account.", "bad")
        return redirect("/admin/account")
    if new and (len(new) < 12 or new != confirm):
        flash(request, "The new password needs at least 12 characters, typed the same twice.", "bad")
        return redirect("/admin/account")
    db.x("UPDATE user SET name = ?, email = ? WHERE id = ?", (name.strip(), email, u["id"]))
    if new:
        db.x("UPDATE user SET pw_hash = ? WHERE id = ?", (auth.hash_pw(new), u["id"]))
        auth.login(request, u)  # keeps this session; every other session is signed out
    db.audit("admin_account", "password changed" if new else "profile", u["id"], email)
    flash(request, "Account saved." + (" Your new password is in effect." if new else ""))
    return redirect("/admin/account")


# ---------- settings center ----------

TABS = [("general", "General"), ("home", "Home page"), ("coverage", "Coverage page"), ("billing", "Billing and Stripe"), ("email", "Email"), ("ai", "AI analyst"), ("seo", "SEO automation"), ("guide", "Getting started")]
SITE_KEYS = {
    "general": ["site_name", "tagline", "support_email", "security_email", "legal_entity", "footer_note", "signup_open", "signup_verify", "signup_min_secs", "signup_daily_ip", "signup_block_disposable", "turnstile_on", "turnstile_site_key", "maintenance_on", "maintenance_title", "maintenance_message", "analytics_id", "linkedin_tag_on", "linkedin_partner_id", "linkedin_url", "x_url", "bluesky_url", "youtube_url", "indexnow_on", "rail_open", "railcars_on", "twofa_mode"],
    "home": ["hero_title", "hero_highlight", "hero_sub", "hero_cta", "features_title", "features_intro", "cta_title", "cta_sub", "meta_description",
             "freight_on", "freight_kicker", "freight_title", "freight_text", "freight_cta", "freight_cards"],
    "coverage": ["coverage_title", "coverage_intro", "coverage_meta"],
    "billing": ["billing_demo"],
    "email": [], "ai": [], "seo": [],
    "guide": guide.keys(),
}
INTEG_KEYS = {
    "general": ["TURNSTILE_SECRET", "GA_API_SECRET"],
    "billing": ["STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET"],
    "email": ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM", "ALERT_SMTP_USER", "ALERT_SMTP_PASSWORD", "ALERT_SMTP_FROM"],
    "ai": ["ANTHROPIC_API_KEY", "ANALYST_MODEL", "ANALYST_EFFORT", "ANALYST_MAX_USD", "UPLOAD_CLASSIFY_MODEL", "BIDS_INGEST_KEY"],
    "seo": ["SEO_REPORT_KEY"],
}
CHECKBOXES = {"signup_verify", "signup_block_disposable", "turnstile_on", "linkedin_tag_on", "signup_open", "billing_demo", "maintenance_on", "rail_open", "freight_on", "indexnow_on", "railcars_on"}


@router.get("/settings")
def settings_page(request: Request, u=A):
    tab = request.query_params.get("tab", "general")
    if tab not in dict(TABS):
        tab = "general"
    integ = {k: {"value": "" if k in config.SECRET_FIELDS else getattr(config, k), "masked": config.masked(k), "source": config.source(k)}
             for k in config.INTEGRATION_FIELDS}
    return render(request, "admin/settings.html", user=u, tab=tab, tabs=TABS, integ=integ, webhook=f"{config.SITE_URL}/stripe/webhook",
                  stripe_on=config.STRIPE_ENABLED, demo=billing.demo_mode(), mail_on=mailer.configured(), ai_on=analyst.available(),
                  guard=signupguard.recent(30) if tab == "general" else ([], {}), unconfirmed=signupguard.unconfirmed_count() if tab == "general" else 0,
                  turnstile_ready=signupguard.turnstile_ready())


@router.post("/settings")
async def settings_save(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    tab = form.get("tab", "general")
    if tab not in dict(TABS):
        tab = "general"
    for k in SITE_KEYS[tab]:
        if k in CHECKBOXES:
            db.set_setting(k, "1" if form.get(k) else "0")
        elif k in form:
            db.set_setting(k, str(form.get(k)).strip())
    changes, changed = {}, []
    for k in INTEG_KEYS.get(tab, []):
        v = str(form.get(k, "")).strip()
        if form.get("clear_" + k):
            changes[k] = None
            changed.append(k + " cleared")
        elif k in config.SECRET_FIELDS:
            if v:  # blank keeps the saved secret
                changes[k] = v
                changed.append(k)
        elif k in form and v != str(getattr(config, k)):
            changes[k] = v
            changed.append(k)
    if tab == "ai" and "ANALYST_EFFORT" in changes and changes["ANALYST_EFFORT"] not in ("low", "medium", "high", "xhigh", "max"):
        changes.pop("ANALYST_EFFORT")
    if changes:
        config.save_stored(changes)
    if tab == "general":
        maint.reset()
        changed.append("maintenance " + ("ON" if form.get("maintenance_on") else "off"))
    db.audit("admin_settings", f"{tab}: " + ", ".join(changed), None, u.email)
    flash(request, "Settings saved." + (" Integration changes are live now." if changes else ""))
    return redirect(f"/admin/settings?tab={tab}")


@router.post("/settings/indexnow")
def indexnow_now(request: Request, csrf: str = Form(""), u=A):
    """Send every public URL to IndexNow now (Bing, Yandex and the engines that share their index)."""
    auth.check_csrf(request, csrf)
    from . import seo
    status = seo.indexnow_run(force=True)
    db.audit("indexnow_ping", status, None, u.email)
    flash(request, status, "ok" if "sent" in status else "bad")
    return redirect("/admin/settings?tab=general#indexnow")


@router.get("/social")
def social_page(request: Request, u=A):
    from . import promo
    rows = promo.drafts()
    months = {}
    for r in rows:
        months.setdefault(r["month"], []).append(r)
    reports = db.q("SELECT slug, title, updated FROM page WHERE slug LIKE 'rail-fleet-report-%' ORDER BY slug DESC")
    from . import linkedin
    return render(request, "admin/social.html", user=u, months=months, reports=reports, promo_on=db.settings().get("promo_on", "1") == "1",
                  this_month=datetime.date.today().strftime("%Y-%m"), label=promo._label, li=linkedin.status(),
                  autopost=promo.autopost_on(), et=promo.et_label, **_awareness_ctx(promo))


def _awareness_ctx(promo):
    """Admin > Social posts: member email, press pitch, ambassador kits and chart posts (awareness plan Phase 1)."""
    from . import awareness, socialimg
    m = datetime.date.today().strftime("%Y-%m")
    if not db.q("SELECT 1 FROM page WHERE slug = ?", (promo.slug_for(m),), one=True):
        last = db.q("SELECT slug FROM page WHERE slug LIKE 'rail-fleet-report-%' ORDER BY slug DESC LIMIT 1", one=True)
        m = last["slug"][-7:] if last else m
    try:
        ambs = [(a, *awareness.ambassador_kit(uid, m)) for uid, a in awareness.active_ambassadors().items()]
    except Exception:
        ambs = []
    return {"nl": awareness.status(m), "nl_month": m, "edition": awareness.newsletter_edition(m), "pitch": awareness.pitch(m), "outlets": awareness.OUTLETS, "kits": ambs,
            "charts": {k: (c, socialimg.url(k)) for k, c in socialimg.CHARTS.items()},
            "charts_on": db.settings().get("promo_charts", "1") == "1", **_cadence_ctx()}


def _cadence_ctx():
    from . import cadence
    try:
        eng = cadence.engagement()
    except Exception:
        eng = {"by_kind": [], "reshare": None, "due": False}
    return {"cadence_on": cadence.on(), "bsky_only": cadence.bsky_only_on(), "eng": eng, "max_week": cadence.MAX_LI_WEEK}


@router.post("/social")
def social_action(request: Request, csrf: str = Form(""), action: str = Form(""), did: int = Form(0), month: str = Form(""),
                  li_client_id: str = Form(""), li_client_secret: str = Form(""), li_org_id: str = Form(""), li_webhook: str = Form(""),
                  body: str = Form(""), when: str = Form(""), u=A):
    """Mark a draft posted or not, post it to LinkedIn, delete it, regenerate a month's report and drafts, switch the monthly job,
    or save / disconnect the LinkedIn app."""
    auth.check_csrf(request, csrf)
    from . import linkedin, promo
    if action == "li_post":
        r = promo.get(did)
        if r and not r["posted"]:
            try:
                from . import cadence
                link = linkedin.post(r["body"], r["url"], r["month"], image_url=promo.image_url(r), platforms=r["platforms"] or "linkedin,bluesky",
                                     bsky_url=cadence.bsky_url(r))
                promo.mark(did, True, link)
                db.audit("linkedin_post", link or f"draft {did} via webhook", None, u.email)
                flash(request, "Sent to LinkedIn." if not link else "Posted to LinkedIn.", "ok")
            except Exception as e:
                log.warning("LinkedIn post failed: %s", e)
                flash(request, str(e), "bad")
    elif action == "autopost":
        on = promo.autopost_on()
        db.set_setting("promo_autopost", "0" if on else "1")
        if not on:
            promo.schedule_unscheduled()
        db.audit("linkedin_autopost_switch", "off" if on else "on", None, u.email)
        flash(request, "Auto-posting turned " + ("off. Drafts stay here until you post them." if on else "on."), "ok")
    elif action == "edit":
        if body.strip():
            try:
                promo.edit(did, body, when if re.fullmatch(r"20\d\d-\d\d-\d\d", when or "") else None)
                flash(request, "Draft updated.", "ok")
            except ValueError:
                flash(request, "That date isn't valid.", "bad")
    elif action == "li_webhook":
        w = li_webhook.strip()
        if w and not re.match(r"https://[\w.-]+\.(make\.com|zapier\.com|integromat\.com|n8n\.cloud)/", w):
            flash(request, "That doesn't look like a Make or Zapier webhook address (it should start with https://hook. …make.com/ or https://hooks.zapier.com/).", "bad")
        else:
            config.save_stored({"LINKEDIN_WEBHOOK_URL": w or None})
            db.audit("linkedin_webhook", "set" if w else "cleared", None, u.email)
            flash(request, "Posting webhook saved." if w else "Posting webhook removed.", "ok")
    elif action == "li_setup":
        changes = {}
        if li_client_id.strip():
            changes["LINKEDIN_CLIENT_ID"] = li_client_id.strip()
        if li_client_secret.strip():
            changes["LINKEDIN_CLIENT_SECRET"] = li_client_secret.strip()
        m = re.search(r"(\d{4,})", li_org_id or "")  # accepts the number or the page admin URL; blank = post as yourself
        org = m.group(1) if m else ""
        if org != (config.LINKEDIN_ORG_ID or ""):
            changes["LINKEDIN_ORG_ID"] = org or None
            linkedin.disconnect()  # page and profile posting need different sign-in permissions
        if changes:
            config.save_stored(changes)
            db.audit("linkedin_setup", ", ".join(k for k in changes if k != "LINKEDIN_CLIENT_SECRET") + (" + secret" if "LINKEDIN_CLIENT_SECRET" in changes else ""), None, u.email)
        flash(request, "LinkedIn app saved." + (" Now click Connect LinkedIn." if linkedin.configured() else " Add the remaining fields."), "ok")
    elif action == "li_disconnect":
        linkedin.disconnect()
        db.audit("linkedin_disconnect", "", None, u.email)
        flash(request, "LinkedIn disconnected.", "ok")
    elif action in ("posted", "unposted"):
        promo.mark(did, action == "posted")
    elif action == "delete":
        promo.delete(did)
    elif action == "generate":
        month = month if re.fullmatch(r"20\d\d-(0[1-9]|1[0-2])", month or "") else datetime.date.today().strftime("%Y-%m")
        msg = promo.generate(month, force=True)
        db.audit("monthly_report_now", month, None, u.email)
        flash(request, msg, "ok")
    elif action in ("cadence", "bsky_only", "fill"):
        from . import cadence
        if action == "fill":
            n = len(cadence.fill())
            flash(request, f"Added {n} post{'s' if n != 1 else ''} to the queue." if n else "Nothing new to add: the week is full or there's no fresh news.", "ok")
        else:
            key = "promo_cadence" if action == "cadence" else "promo_bsky_only"
            on = db.settings().get(key, "1" if action == "cadence" else "0") == "1"
            db.set_setting(key, "0" if on else "1")
            flash(request, ("Posting mix" if action == "cadence" else "Bluesky-only posts") + (" turned off." if on else " turned on."), "ok")
        return redirect("/admin/social#cadence")
    elif action in ("nl_test", "nl_send", "nl_auto", "charts", "chart_now"):
        from . import awareness
        if action == "nl_test":
            ok = awareness.send_test(month, {"id": u.id, "email": u.email, "name": u.name})
            flash(request, f"Test sent to {u.email}." if ok else "Email isn't set up, or your address opted out of optional mail.", "ok" if ok else "bad")
        elif action == "nl_send":
            db.audit("newsletter_send", month, None, u.email)
            flash(request, awareness.send_all(month), "ok")
        elif action == "nl_auto":
            on = awareness.auto_on()
            db.set_setting("newsletter_auto", "0" if on else "1")
            flash(request, "Monthly member email: " + ("send by hand." if on else "sends automatically when each report publishes."), "ok")
        elif action == "charts":
            on = db.settings().get("promo_charts", "1") == "1"
            db.set_setting("promo_charts", "0" if on else "1")
            flash(request, "Weekly chart posts turned " + ("off." if on else "on."), "ok")
        else:
            promo._init()
            did = promo.ensure_chart(datetime.datetime.now(datetime.timezone.utc), force=True)
            flash(request, "Added a chart post to the queue." if did else
                  "No chart has data right now, or Pillow isn't installed.", "ok" if did else "bad")
        return redirect("/admin/social#awareness")
    elif action == "toggle":
        on = db.settings().get("promo_on", "1") == "1"
        db.set_setting("promo_on", "0" if on else "1")
        flash(request, "Monthly report turned " + ("off." if on else "on."), "ok")
    return redirect("/admin/social")


@router.get("/social/linkedin/connect")
def social_li_connect(request: Request, u=A):
    from . import linkedin
    import secrets
    if not linkedin.configured():
        flash(request, "Add the LinkedIn app ID, secret and page ID first.", "bad")
        return redirect("/admin/social#linkedin")
    st = secrets.token_urlsafe(24)
    request.session["li_state"] = st
    return redirect(linkedin.auth_url(st))


@router.get("/social/linkedin/callback")
def social_li_callback(request: Request, code: str = "", state: str = "", error: str = "", error_description: str = "", u=A):
    from . import linkedin
    want = request.session.pop("li_state", None)
    if error:
        flash(request, f"LinkedIn said: {error_description or error}", "bad")
    elif not want or state != want or not code:
        flash(request, "That LinkedIn sign-in link expired. Click Connect LinkedIn again.", "bad")
    else:
        try:
            linkedin.exchange(code)
            db.audit("linkedin_connect", "", None, u.email)
            flash(request, "LinkedIn connected.", "ok")
        except Exception as e:
            log.warning("LinkedIn token exchange failed: %s", e)
            flash(request, "LinkedIn sign-in failed. Check the client secret and the redirect URL in the LinkedIn app.", "bad")
    return redirect("/admin/social#linkedin")


@router.post("/settings/stripe-test")
def stripe_test(request: Request, csrf: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    if not config.STRIPE_ENABLED:
        flash(request, "Add a Stripe secret key first.", "bad")
    else:
        try:
            acct = billing.client().v1.accounts.retrieve_current()
            mode = "test" if config.STRIPE_SECRET_KEY.startswith(("sk_test", "rk_test")) else "live"
            flash(request, f"Stripe connected ({mode} mode): {getattr(acct, 'business_profile', None) and acct.business_profile.name or acct.id}.")
        except Exception as e:
            flash(request, f"Stripe said: {str(e)[:200]}", "bad")
    return redirect("/admin/settings?tab=billing")


# ---------- comparison pages ----------

def _lines(text):
    return [ln.strip() for ln in (text or "").splitlines() if ln.strip()]


@router.get("/compare")
def compare_list(request: Request, u=A):
    return render(request, "admin/compare.html", user=u, items=compare.all_items(include_hidden=True))


@router.get("/compare/edit")
def compare_edit(request: Request, u=A):
    slug = request.query_params.get("slug", "")
    c = compare.get(slug, include_hidden=True) if slug else None
    rows = "\n".join(" | ".join(r) for r in (c or {}).get("rows", []))
    sources = "\n".join(" | ".join(r) for r in (c or {}).get("sources", []))
    return render(request, "admin/compare_edit.html", user=u, c=c, slug=slug, rows=rows, sources=sources, lists=compare.LISTS,
                  default_checked=compare.CHECKED)


@router.post("/compare/edit")
async def compare_save(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    orig = str(form.get("orig", ""))
    slug = data.slug(str(form.get("slug", "")))
    if form.get("action") == "reset" and orig:
        compare.reset(orig)
        db.audit("admin_compare_reset", orig, None, u.email)
        flash(request, "Restored the original comparison." if orig in compare.COMPETITORS else "Comparison deleted.")
        return redirect("/admin/compare")
    name = str(form.get("name", "")).strip()
    if not slug or not name:
        flash(request, "A comparison needs a URL slug and the competitor's name.", "bad")
        return redirect(f"/admin/compare/edit?slug={orig}")
    if slug != orig and compare.get(slug, include_hidden=True):
        flash(request, f"/compare/{slug} already exists.", "bad")
        return redirect(f"/admin/compare/edit?slug={orig}")
    vals = {k: str(form.get(k, "")).strip() for k in compare.FIELDS}
    vals["checked"] = str(form.get("checked", "")).strip() or compare.CHECKED
    vals["hidden"] = bool(form.get("hidden"))
    for k in compare.LISTS:
        vals[k] = _lines(form.get(k))
    rows, bad = [], []
    for ln in _lines(form.get("rows")):
        parts = [p.strip() for p in ln.split("|")]
        if len(parts) == 3:
            parts.append("tie")
        if len(parts) != 4:
            bad.append(ln)
            continue
        parts[3] = parts[3].lower() if parts[3].lower() in ("us", "them", "tie") else "tie"
        rows.append(parts)
    vals["rows"] = rows
    vals["sources"] = [[p.strip() for p in ln.split("|", 1)] for ln in _lines(form.get("sources")) if "|" in ln]
    if orig and orig != slug:
        compare.reset(orig)
        if orig in compare.COMPETITORS:  # renaming a built-in one: hide the old URL
            compare.save(orig, {"hidden": True})
    compare.save(slug, vals)
    db.audit("admin_compare", slug, None, u.email)
    flash(request, "Comparison saved." + (f" Skipped {len(bad)} table line(s) without 3 or 4 parts." if bad else ""), "bad" if bad else "ok")
    return redirect(f"/admin/compare/edit?slug={slug}")


# ---------- audit ----------

@router.get("/audit")
def audit_log(request: Request, u=A):
    return render(request, "admin/audit.html", user=u, rows=db.q("SELECT a.*, u.id live_uid FROM audit a LEFT JOIN user u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 500"))


# ---------- market intel (unit costs, programs, funding, contracts, manual costs) ----------

from . import intel  # noqa: E402

GRADES = ("A", "B", "C", "D")
INTEL_TABLES = {
    "unit_cost": ("Unit costs", "Planning cost per car for each event and vehicle type. Drives opportunity sizing.", [
        ("event", "Event", sorted(intel.DEFAULT_COSTS)), ("vehicle_class", "Vehicle type (* = any)", "text"),
        ("usd_per_car", "US$ per car", "num"), ("basis", "Basis", "text"), ("source_url", "Source URL", "text")]),
    "plan_event": ("Programs and plans", "Announced replacements, orders, options, overhaul programs and retirements.", [
        ("operator_id", "Operator id", "text"), ("fleet_id", "Fleet id (optional)", "int"), ("event_type", "Type", list(intel.PLAN_TYPES)),
        ("title", "Title", "text"), ("qty", "Cars", "int"), ("year_planned", "Year", "int"), ("funded", "Funding status", "text"),
        ("value_usd", "Value US$", "num"), ("confidence", "Grade", GRADES), ("source_url", "Source URL", "text"), ("notes", "Notes", "text")]),
    "funding_award": ("Funding awards", "FTA, FRA and other grants that pay for fleet work.", [
        ("operator_id", "Operator id", "text"), ("program", "Program", "text"), ("grantor", "Grantor", "text"), ("amount_usd", "Amount US$", "num"),
        ("award_date", "Award date", "text"), ("purpose", "Purpose", "text"), ("fleet_id", "Fleet id (optional)", "int"),
        ("confidence", "Grade", GRADES), ("source_url", "Source URL", "text"), ("notes", "Notes", "text")]),
    "fleet_contract": ("Contracts and warranties", "Warranty, maintenance, TSA and overhaul contracts, with end dates.", [
        ("operator_id", "Operator id", "text"), ("fleet_id", "Fleet id (optional)", "int"), ("kind", "Kind", list(intel.CONTRACT_KINDS)),
        ("vendor", "Vendor", "text"), ("start_date", "Start", "text"), ("end_date", "End", "text"), ("value_usd", "Value US$", "num"),
        ("confidence", "Grade", GRADES), ("source_url", "Source URL", "text"), ("notes", "Notes", "text")]),
    "operator_cost_manual": ("Reported costs", "Costs from annual reports for systems outside NTD (Canada). Converted to US$ per car-mile.", [
        ("operator_id", "Operator id", "text"), ("mode", "Mode (blank = all)", "text"), ("report_year", "Year", "int"), ("currency", "Currency", "text"),
        ("opex_total", "Operating cost", "num"), ("vehicle_maint", "Vehicle maintenance", "num"), ("car_km", "Car-km", "num"),
        ("active_cars", "Active cars", "int"), ("usd_per_unit", "US$ per unit of currency", "num"), ("confidence", "Grade", GRADES),
        ("source_url", "Source URL", "text"), ("notes", "Notes", "text")]),
}


def _intel_vals(spec, form):
    vals = {}
    for name, label, kind in spec:
        v = str(form.get(name) or "").strip()
        if kind in ("int", "num"):
            try:
                v = (int(float(v.replace(",", ""))) if kind == "int" else float(v.replace(",", ""))) if v else None
            except ValueError:
                raise ValueError(f"{label} must be a number")
        elif isinstance(kind, (list, tuple)) and v and v not in kind:
            raise ValueError(f"{label} must be one of {', '.join(kind)}")
        vals[name] = v if v != "" else None
    return vals


@router.get("/intel")
def intel_page(request: Request, u=A):
    t = request.query_params.get("t") or "plan_event"
    if t not in INTEL_TABLES:
        raise HTTPException(404)
    label, blurb, spec = INTEL_TABLES[t]
    order = "event, vehicle_class" if t == "unit_cost" else "rowid DESC"
    rows = [dict(r) for r in db.q(f"SELECT rowid AS _rid, * FROM {t} ORDER BY {order} LIMIT 1000")]
    counts = {k: db.q(f"SELECT count(*) n FROM {k}", one=True)["n"] for k in INTEL_TABLES}
    return render(request, "admin/intel.html", user=u, t=t, label=label, blurb=blurb, spec=spec, rows=rows, tables=INTEL_TABLES, counts=counts)


@router.post("/intel")
async def intel_save(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    t = form.get("t")
    if t not in INTEL_TABLES:
        raise HTTPException(400)
    spec = INTEL_TABLES[t][2]
    rid = str(form.get("rid") or "")
    action = form.get("action") or "save"
    try:
        if action == "delete" and rid.isdigit():
            db.x(f"DELETE FROM {t} WHERE rowid = ?", (int(rid),))
            msg = "Deleted."
        elif action == "import":
            import csv
            import io
            n = 0
            names = [s[0] for s in spec]
            for i, rec in enumerate(csv.DictReader(io.StringIO(str(form.get("csv") or "").strip()))):
                try:
                    vals = _intel_vals(spec, rec)
                except ValueError as e:
                    raise ValueError(f"Row {i + 2}: {e}")
                cols = [c for c in names if c in rec]
                if t != "unit_cost":
                    cols.append("created")
                    vals["created"] = db.now()
                db.x(f"INSERT OR REPLACE INTO {t} ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})", [vals[c] for c in cols])
                n += 1
            msg = f"Imported {n} row{'s' if n != 1 else ''}."
        else:
            vals = _intel_vals(spec, form)
            if t == "unit_cost":
                vals["vehicle_class"] = vals["vehicle_class"] or "*"
                if not vals["event"] or vals["usd_per_car"] is None:
                    raise ValueError("Event and US$ per car are required")
                vals["updated"] = db.now()
            else:
                req = [s[0] for s in spec][:1] + (["report_year"] if t == "operator_cost_manual" else [])
                if any(not vals[c] for c in req):
                    raise ValueError("Operator id is required" + (" and year" if t == "operator_cost_manual" else ""))
                if not data.operator(vals["operator_id"]):
                    raise ValueError(f"No operator with id {vals['operator_id']}")
            cols = list(vals)
            if rid.isdigit():
                db.x(f"UPDATE {t} SET {', '.join(c + ' = ?' for c in cols)} WHERE rowid = ?", [vals[c] for c in cols] + [int(rid)])
                msg = "Saved."
            else:
                if t != "unit_cost":
                    cols.append("created")
                    vals["created"] = db.now()
                db.x(f"INSERT OR REPLACE INTO {t} ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})", [vals[c] for c in cols])
                msg = "Added."
    except ValueError as e:
        flash(request, str(e), "bad")
        return redirect(f"/admin/intel?t={t}")
    intel.invalidate()
    db.audit("admin_intel", f"{t} {action} {rid}", None, u.email)
    flash(request, msg)
    return redirect(f"/admin/intel?t={t}")


# ---------- Bid Catcher (its config.json and registrations) ----------

BC_TABS = [("alerts", "Alert recipients"), ("settings", "Settings and schedules"), ("permissions", "Permissions"), ("checks", "Hand checks"),
           ("actions", "Actions"), ("feeds", "Feeds"), ("signups", "Sign-ups"), ("activity", "Mailbox")]


@router.get("/bidcatcher")
def bidcatcher_page(request: Request, u=A):
    tab = request.query_params.get("tab", "alerts")
    tab = "signups" if tab == "registrations" else tab
    if tab not in dict(BC_TABS):
        tab = "alerts"
    ok, why = bidcatcher.available()
    extra = {}
    if tab == "permissions":
        extra = {"perms": bidcatcher.permission_rows(), "fd": bidcatcher.feeds()}
    elif tab == "checks":
        extra = {"checks": bidcatcher.hand_checks()}
    elif tab == "actions":
        acts = bidcatcher.action_rows()
        extra = {"acts": acts, "busy": any(a["status"] in ("queued", "running") for a in acts or [])}
    elif tab == "feeds":
        extra = {"fd": bidcatcher.feeds()}
    elif tab == "signups":
        extra = {"groups": bidcatcher.signup_groups(), "business": bidcatcher.BUSINESS, "naics": bidcatcher.NAICS, "keywords": bidcatcher.KEYWORDS}
    return render(request, "admin/bidcatcher.html", user=u, tab=tab, tabs=BC_TABS, bc=bidcatcher.load(), ok=ok, why=why,
                  modes=bidcatcher.MODES, countries=bidcatcher.COUNTRIES, categories=bidcatcher.CATEGORIES, statuses=bidcatcher.STATUSES,
                  sched=bidcatcher.SCHEDULE, agencies=bidcatcher.agencies() if tab == "alerts" else [],
                  regs=bidcatcher.registrations() if tab == "registrations" else [], writable=config.BIDS_DB_WRITABLE,
                  runs=bidcatcher.runs() if tab == "activity" else [], spent=bidcatcher.spent_today(), **extra)


@router.post("/bidcatcher")
async def bidcatcher_save(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    tab = form.get("tab", "alerts")
    back = f"/admin/bidcatcher?tab={tab if tab in dict(BC_TABS) else 'alerts'}"
    ok, why = bidcatcher.available()
    if not ok:
        flash(request, why, "bad")
        return redirect(back)
    try:
        if tab == "alerts":
            subs, errors = bidcatcher.parse_alerts(form)
            if not errors:
                bidcatcher.save_alerts(subs)
                detail = ", ".join(f"{s['email']} ({s['mode']}{'' if s['active'] else ', paused'})" for s in subs)
        elif tab == "settings":
            vals, errors = bidcatcher.parse_general(form)
            sched, e2 = bidcatcher.parse_schedule(form)
            errors += e2
            if not errors:
                bidcatcher.save_general(vals)
                bidcatcher.save_schedule(sched)
                detail = json.dumps({**vals, **{k: v for k, v in sched.items() if v}})
        else:
            raise HTTPException(400)
    except (OSError, ValueError) as e:
        flash(request, f"Couldn't write Bid Catcher's settings: {e}", "bad")
        return redirect(back)
    if errors:
        flash(request, " ".join(errors) + " Nothing was saved.", "bad")
        return redirect(back)
    db.audit("admin_bidcatcher", f"{tab}: {detail}"[:900], None, u.email)
    flash(request, "Saved. Bid Catcher uses this from its next cycle (within a minute), no restart needed.")
    return redirect(back)


@router.post("/bidcatcher/registration")
def bidcatcher_registration(request: Request, csrf: str = Form(""), account_key: str = Form(""), status: str = Form(""),
                            notes: str = Form(None), u=A):
    auth.check_csrf(request, csrf)
    if not config.BIDS_DB_WRITABLE:
        flash(request, "Registrations are read-only here. Set BIDS_DB_WRITABLE=1 in the site's .env to edit them from the site.", "bad")
        return redirect("/admin/bidcatcher?tab=signups")
    try:
        bidcatcher.set_registration(account_key, status, notes)
    except ValueError as e:
        flash(request, str(e), "bad")
        return redirect("/admin/bidcatcher?tab=signups")
    db.audit("admin_bidcatcher", f"registration {account_key} -> {status}", None, u.email)
    flash(request, f"{account_key} set to {status}.")
    return redirect("/admin/bidcatcher?tab=signups")


def _bc_writable(request, back):
    if not config.BIDS_DB_WRITABLE:
        flash(request, "Bid Catcher's database is read-only here. Set BIDS_DB_WRITABLE=1 in the site's .env to run this from the site.", "bad")
        return False
    return True


@router.post("/bidcatcher/perm")
async def bidcatcher_perm(request: Request, u=A):
    """Permission requests: edit drafts, approve ticked drafts for sending, enable a source, decline or close, and queue the seed and
    reply-check jobs. Bid Catcher does the sending and the mailbox checks."""
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    back = "/admin/bidcatcher?tab=permissions"
    op = form.get("op", "")
    if op == "reply_to":
        v = (form.get("reply_to") or "").strip()
        if v and not bidcatcher.EMAIL.match(v):
            flash(request, f"'{v}' isn't a valid email address.", "bad")
            return redirect(back)
        bidcatcher.save_feeds(permission_reply_to=v or None)
        db.audit("admin_bidcatcher", f"permission reply-to {v or '(none)'}", None, u.email)
        flash(request, "Reply-To saved." if v else "Reply-To cleared: replies go to Bid Catcher's mailbox only.")
        return redirect(back)
    if not _bc_writable(request, back):
        return redirect(back)
    try:
        pid = int(form.get("id") or 0)
        if op == "save":
            n = bidcatcher.save_draft(pid, form.get("to_addr") or "", form.get("subject") or "", form.get("body") or "")
            msg = "Draft saved." if n else "Only drafts can be edited."
        elif op == "send":
            ids = [int(i) for i in form.getlist("pick") if i.isdigit()]
            n = bidcatcher.approve(ids, u.email)
            msg = f"{n} request{'s' if n != 1 else ''} approved. Bid Catcher sends one every 3 minutes." if n else "Tick drafts that have an address first."
        elif op == "enable":
            if form.get("confirm") != "yes":
                raise ValueError("Tick the box to confirm they said yes in writing.")
            bidcatcher.queue("permission_enable", {"id": pid}, u.email)
            msg = "Queued: Bid Catcher adds the site to its permitted list within about 30 seconds."
        elif op in ("declined", "closed"):
            bidcatcher.set_perm_status(pid, op, u.email)
            msg = f"Marked {op}."
        elif op == "seed":
            bidcatcher.queue("permission_seed", {}, u.email)
            msg = "Queued: Bid Catcher creates drafts for any blocked site that doesn't have one."
        elif op == "replies":
            bidcatcher.queue("permission_replies", {}, u.email)
            msg = "Queued: Bid Catcher checks its mailbox for replies now."
        else:
            raise ValueError("Unknown action.")
    except Exception as e:
        flash(request, f"{e}" if isinstance(e, ValueError) else f"That didn't work ({type(e).__name__}). Is Bid Catcher updated?", "bad")
        return redirect(back)
    db.audit("admin_bidcatcher", f"permission {op} {pid or ''}".strip(), None, u.email)
    flash(request, msg)
    return redirect(back + (f"#p{pid}" if op == "save" and pid else ""))


@router.post("/bidcatcher/check")
def bidcatcher_check(request: Request, csrf: str = Form(""), url: str = Form(""), agency_id: str = Form(""), note: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    back = "/admin/bidcatcher?tab=checks"
    if not _bc_writable(request, back):
        return redirect(back)
    try:
        bidcatcher.record_check(url, agency_id, note.strip() or "nothing new")
    except Exception as e:
        flash(request, f"Couldn't record it ({type(e).__name__}). Is Bid Catcher updated?", "bad")
        return redirect(back)
    db.audit("admin_bidcatcher", f"hand check {url[:200]}: {note[:200]}", None, u.email)
    flash(request, "Checked. Noted for today.")
    return redirect(back)


@router.post("/bidcatcher/action")
async def bidcatcher_action(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    back = "/admin/bidcatcher?tab=actions"
    if not _bc_writable(request, back):
        return redirect(back)
    a = form.get("action", "")
    args = {}
    if a == "rescore":
        try:
            args["max_usd"] = max(0.0, min(10.0, float(form.get("max_usd") or 2)))
        except ValueError:
            args["max_usd"] = 2.0
    elif a == "scan":
        only = [s for s in ("mail", "pages", "feeds") if form.get(s)]
        args = {"only": ",".join(only), "notify": bool(form.get("notify"))}
    elif a == "test_email":
        to = (form.get("to") or "").strip()
        if to and not bidcatcher.EMAIL.match(to):
            flash(request, f"'{to}' isn't a valid email address.", "bad")
            return redirect(back)
        args = {"to": to} if to else {}
    elif a == "federal_history":
        try:
            args["years"] = max(1, min(20, int(form.get("years") or 10)))
        except ValueError:
            args["years"] = 10
    elif a not in ("coverage", "checklist"):
        flash(request, "Unknown action.", "bad")
        return redirect(back)
    try:
        aid = bidcatcher.queue(a, args, u.email)
    except Exception as e:
        flash(request, f"Couldn't queue it ({type(e).__name__}). Is Bid Catcher updated?", "bad")
        return redirect(back)
    db.audit("admin_bidcatcher", f"action {a} {json.dumps(args)} #{aid}", None, u.email)
    flash(request, f"Queued. Bid Catcher picks it up within about 30 seconds.")
    return redirect(back)


@router.post("/bidcatcher/feeds")
async def bidcatcher_feeds(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf"))
    back = "/admin/bidcatcher?tab=feeds"
    ok, why = bidcatcher.available()
    if not ok:
        flash(request, why, "bad")
        return redirect(back)
    op = form.get("op", "")
    try:
        if op == "bonfire_on":
            note = (form.get("note") or "").strip()
            if not note:
                raise ValueError("Say who gave permission and when.")
            bidcatcher.save_feeds(bonfire_rss_permission=note[:300])
            msg, detail = "Bonfire RSS is on.", f"bonfire rss on: {note[:200]}"
        elif op == "bonfire_off":
            bidcatcher.save_feeds(bonfire_rss_permission=None)
            msg, detail = "Bonfire RSS is off.", "bonfire rss off"
        elif op == "rss":
            rows, errors = bidcatcher.parse_rss(form)
            if errors:
                raise ValueError(" ".join(errors) + " Nothing was saved.")
            bidcatcher.save_feeds(rss=rows)
            msg, detail = f"{len(rows)} official feed{'s' if len(rows) != 1 else ''} saved.", f"rss feeds: {len(rows)}"
        elif op == "perm_remove":
            host = form.get("host", "")
            bidcatcher.remove_permission(host)
            msg, detail = f"{host} removed from the permitted list.", f"permission removed {host}"
        elif op == "sam_key":
            key = (form.get("sam_key") or "").strip()
            if not re.fullmatch(r"[A-Za-z0-9_-]{20,80}", key):
                raise ValueError("That doesn't look like a SAM.gov API key.")
            bidcatcher.save_sam_key(key)
            msg, detail = "SAM.gov key saved on the server.", "sam key saved"
        elif op == "sam_remove":
            bidcatcher.remove_sam_key()
            msg, detail = "SAM.gov key removed.", "sam key removed"
        elif op == "naics":
            codes = [c for c in re.split(r"[\s,;]+", form.get("naics") or "") if c]
            if not codes or any(not re.fullmatch(r"\d{6}", c) for c in codes):
                raise ValueError("NAICS codes are six digits, separated by commas.")
            bidcatcher.save_feeds(sam_naics=codes)
            msg, detail = "NAICS codes saved.", f"sam naics {','.join(codes)}"
        else:
            raise ValueError("Unknown action.")
    except (OSError, ValueError) as e:
        flash(request, str(e), "bad")
        return redirect(back)
    db.audit("admin_bidcatcher", detail[:900], None, u.email)
    flash(request, msg + " Bid Catcher uses it from its next cycle.")
    return redirect(back)


@router.post("/bidcatcher/sender")
async def bidcatcher_sender(request: Request, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    ok, why = bidcatcher.available()
    if not ok:
        flash(request, why, "bad")
        return redirect("/admin/bidcatcher?tab=activity")
    vals, errors = bidcatcher.parse_sender(form)
    if errors:
        flash(request, " ".join(errors), "bad")
    else:
        password = str(form.get("password") or "").strip()
        bidcatcher.save_sender(vals, password)
        db.audit("admin_bidcatcher", f"alert sender {vals['address']}" + (" (password replaced)" if password else ""), None, u.email)
        flash(request, f"Alerts will be sent from {vals['address']}." if password or bidcatcher.load()["sender"]["password_set"]
              else f"Saved. Add the password for {vals['address']} to start sending from it; until then alerts use the bids mailbox.")
    return redirect("/admin/bidcatcher?tab=activity")


@router.post("/bidcatcher/test-email")
def bidcatcher_test(request: Request, csrf: str = Form(""), to: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    to = to.strip() or next((s["email"] for s in bidcatcher.load()["subscribers"] if s.get("email")), "") or u.email
    if not bidcatcher.EMAIL.match(to):
        flash(request, f"'{to}' isn't a valid email address.", "bad")
    else:
        try:
            sender = bidcatcher.test_email(to)
            db.audit("admin_bidcatcher", f"test email to {to} from {sender}", None, u.email)
            flash(request, f"Test sent to {to} from {sender}.")
        except Exception as e:
            flash(request, f"The test didn't send: {e}", "bad")
    return redirect("/admin/bidcatcher?tab=activity")


# ---------- diagnostics (system log, payments, health checks) ----------

DIAG_TABS = [("overview", "Health"), ("log", "System log"), ("payments", "Payments"), ("tools", "All diagnostic tools")]


def _check(name, state, text, href=None, area=None):
    return {"name": name, "state": state, "text": text, "href": href, "area": area}


def diag_health():
    """Green / amber / red checks for Admin > Diagnostics, built from what the site already knows. Each check is independent."""
    import os
    import shutil
    from . import syslog as L
    out = []

    def safe(fn):
        try:
            fn()
        except Exception as ex:
            out.append(_check(fn.__name__.strip("_").replace("_", " ").capitalize(), "warn", f"Couldn't check: {type(ex).__name__}"))

    def _site_errors():
        h = L.http_summary(1)
        out.append(_check("Site errors", "ok" if not h["e5"] else "warn" if h["e5"] < 5 else "bad",
                          f"{h['e5']} server error(s), {h['e4']} client error(s) and {h['slow']} slow page(s) in the last 24 hours",
                          "/admin/diagnostics?tab=log&category=http&days=1", "http"))

    def _payments():
        n = db.q("SELECT coalesce(sum(count),0) n FROM sys_event WHERE category = 'stripe' AND level = 'error' AND last_ts > ?",
                 (L.since_ack('stripe', 7),), one=True)["n"]
        key = config.STRIPE_SECRET_KEY or ""
        mode = "live" if key.startswith(("sk_live", "rk_live")) else "test (sandbox)" if key else "off"
        last = db.q("SELECT max(ts) t FROM billing_event", one=True)["t"]
        txt = f"Stripe {mode}. {n} payment problem(s) in 7 days. " + (f"Last webhook {last[:16].replace('T', ' ')} UTC." if last else "No webhook received yet.")
        state = "bad" if config.STRIPE_ENABLED and not config.STRIPE_WEBHOOK_SECRET else "warn" if n or not key else "ok"
        if config.STRIPE_ENABLED and not config.STRIPE_WEBHOOK_SECRET:
            txt += " The webhook secret is missing, so payments won't update accounts."
        out.append(_check("Payments", state, txt, "/admin/diagnostics?tab=payments", "stripe"))

    def _email():
        n = db.q("SELECT coalesce(sum(count),0) n FROM sys_event WHERE category = 'mail' AND level = 'error' AND last_ts > ?", (L.since_ack('mail', 7),), one=True)["n"]
        on = mailer.configured()
        out.append(_check("Email", "bad" if not on else "warn" if n else "ok",
                          ("Sending is set up. " if on else "Outgoing email isn't set up. ") + f"{n} failed send(s) in 7 days.",
                          "/admin/settings?tab=email", "mail"))

    def _news():
        n = db.q("SELECT coalesce(sum(count),0) n FROM sys_event WHERE category = 'news' AND level = 'error' AND last_ts > ?", (L.since_ack('news', 1),), one=True)["n"]
        out.append(_check("News search (GDELT)", "ok" if not n else "warn", f"{n} search(es) failed after retries in the last 24 hours",
                          "/admin/diagnostics?tab=log&category=news", "news"))

    def _backups():
        bk = backups.status()
        out.append(_check("Backups", "bad" if bk["problems"] and not bk["snap"] else "warn" if bk["problems"] else "ok",
                          " ".join(bk["problems"]) or "Nightly snapshot and Synology pull are current.", "/admin/data#backups"))

    def _bid_catcher():
        rs = list(bidcatcher.runs(10))
        if not rs:
            out.append(_check("Bid Catcher", "warn", "No runs recorded yet.", "/admin/bidcatcher?tab=activity"))
            return
        last = rs[0]
        fails = [r for r in rs if (r["status"] or "").lower() not in ("ok", "done", "success", "completed")]
        age = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat((last["started"] or "").replace("Z", "+00:00"))
               .replace(tzinfo=datetime.timezone.utc)).total_seconds() / 3600 if last["started"] else 999
        out.append(_check("Bid Catcher", "bad" if age > 48 else "warn" if fails else "ok",
                          f"Last run {int(age)} hour(s) ago ({last['task']}, {last['status']}). {len(fails)} of the last {len(rs)} runs had problems.",
                          "/admin/bidcatcher?tab=activity"))

    def _disk():
        du = shutil.disk_usage(config.DATA_DIR)
        free = du.free / du.total * 100
        sizes = []
        for lab, path in (("app", config.APP_DB), ("fleet", config.FLEET_DB), ("bids", config.BIDS_DB)):
            if os.path.exists(path):
                sizes.append(f"{lab} {os.path.getsize(path) / 1e6:,.0f} MB")
        out.append(_check("Disk space", "bad" if free < 10 else "warn" if free < 20 else "ok",
                          f"{free:.0f}% free ({du.free / 1e9:,.1f} GB). Databases: {', '.join(sizes)}."))

    def _security():
        admins = db.q("SELECT count(*) n, sum(CASE WHEN coalesce(totp_on,0) = 1 THEN 1 ELSE 0 END) on2 FROM user WHERE role = 'admin'", one=True)
        fails = db.q("SELECT count(*) n FROM audit WHERE action = '2fa_failed' AND ts >= ?", (L.since(7),), one=True)["n"]
        mode = db.settings().get("twofa_mode", "optional")
        no2 = (admins["n"] or 0) - (admins["on2"] or 0)
        out.append(_check("Security", "warn" if no2 or fails > 10 else "ok",
                          f"{no2} admin(s) without two-factor sign-in (mode: {mode}). {fails} failed two-factor code(s) in 7 days.",
                          "/admin/audit"))

    def _freight_service():
        from . import ep724
        e = ep724.status()
        age = (datetime.date.today() - datetime.date.fromisoformat(e["through"])).days if e["through"] else 999
        txt = (f"STB EP 724 weekly data through {e['through'] or 'none'} ({e['file']}). "
               + (f"Last checked {e['checked'][:16].replace('T', ' ')} UTC. " if e["checked"] else "Not checked yet. ")
               + (f"Last error: {e['error']}" if e["error"] else ""))
        out.append(_check("Freight service data", "ok" if age <= 16 and not e["error"] else "warn" if age <= 30 else "bad", txt.strip(),
                          "/admin/diagnostics/ep724"))

    def _ai():
        out.append(_check("AI analyst", "ok" if analyst.available() else "warn",
                          "Connected." if analyst.available() else "No API key, so the AI analyst is off.", "/admin/data"))

    for fn in (_site_errors, _payments, _email, _news, _backups, _bid_catcher, _disk, _security, _freight_service, _ai):
        safe(fn)
    if db.settings().get("maintenance_on") == "1":
        out.insert(0, _check("Maintenance mode", "warn", "The site is in maintenance mode: visitors see the maintenance page.", "/admin/settings"))
    return out


@router.get("/deploys")
def deploys_page(request: Request, u=A):
    """Builds and deploys: what is on production and staging, and when it was put there (from the deploy scripts' log)."""
    from . import deploys
    return render(request, "admin/deploys.html", user=u, et=deploys.et, **deploys.view(request.query_params.get("all") == "1"))


@router.post("/deploys/promote")
def deploys_promote(request: Request, csrf: str = Form(""), name: str = Form(""), confirm: str = Form(""), u=A):
    """Ask the server to promote a staged release to production (consist-deploy runs it within a minute)."""
    from . import deploys
    auth.check_csrf(request, csrf)
    if confirm.strip() != name:
        flash(request, "Type the release name exactly to confirm the promote.", "bad")
        return redirect("/admin/deploys")
    err = deploys.request_promote(name, u.email)
    if err:
        flash(request, err, "bad")
    else:
        db.audit("admin_deploy", f"promote requested: {name}", None, u.email)
        flash(request, f"Promote of {name} requested. The server runs it within a minute; refresh this page to see the result.")
    return redirect("/admin/deploys")


@router.get("/diagnostics")
def diagnostics(request: Request, tab: str = "overview", level: str = "", category: str = "", q: str = "", days: int = 7, page: int = 1,
                export: str = "", u=A):
    from . import syslog as L
    tab = tab if tab in dict(DIAG_TABS) else "overview"
    days = days if days in (1, 7, 30, 90) else 7
    level = level if level in L.LEVELS else ""
    category = category if category in L.CATEGORIES else ""
    ctx = dict(tab=tab, tabs=DIAG_TABS, level=level, category=category, q=q, days=days, L=L, settings=db.settings())
    if tab == "overview":
        up = int(datetime.datetime.now().timestamp() - L.STARTED)
        ctx.update(checks=diag_health(), counts=L.counts(1), counts7=L.counts(7), daily=L.daily(14), top=L.top_paths(7, 10),
                   uptime=f"{up // 86400} d {up % 86400 // 3600} h" if up >= 86400 else f"{up // 3600} h {up % 3600 // 60} min")
    elif tab == "log":
        if export:
            from .routes_app import csv_response
            rows, _ = L.events(level, category, q, days, limit=5000)
            return csv_response("consist-system-log", ["ts", "last_ts", "level", "category", "code", "method", "path", "message", "count", "ms",
                                                       "user_id", "ip", "detail"], [dict(r) for r in rows])
        page = max(1, page)
        rows, total = L.events(level, category, q, days, limit=100, offset=(page - 1) * 100)
        ctx.update(rows=rows, total=total, page=page, pages=(total + 99) // 100)
    elif tab == "payments":
        show_all = request.query_params.get("all") == "1"
        rows, total = L.events("", "stripe", "", 90, limit=100, unseen=not show_all)
        _, total_all = L.events("", "stripe", "", 90, limit=1)
        ctx.update(rows=rows, total=total, total_all=total_all, show_all=show_all, ack=L.ack_ts("stripe"), billing=db.q("SELECT b.*, u.email FROM billing_event b LEFT JOIN user u ON u.id = b.user_id ORDER BY b.id DESC LIMIT 40"),
                   key_mode=("live" if (config.STRIPE_SECRET_KEY or "").startswith(("sk_live", "rk_live")) else "test (sandbox)" if config.STRIPE_SECRET_KEY else "off"),
                   hook_on=bool(config.STRIPE_WEBHOOK_SECRET), webhook=f"{config.SITE_URL}/stripe/webhook")
    return render(request, "admin/diagnostics.html", user=u, **ctx)


@router.get("/diagnostics/event/{eid}")
def diagnostics_event(request: Request, eid: int, u=A):
    from . import syslog as L
    e = L.event(eid)
    if not e:
        raise HTTPException(404)
    try:
        det = json.loads(e["detail"]) if e["detail"] else {}
    except ValueError:
        det = {"text": e["detail"]}
    who = db.q("SELECT id, email, name FROM user WHERE id = ?", (e["user_id"],), one=True) if e["user_id"] else None
    return render(request, "admin/diagnostics_event.html", user=u, e=e, det=det, who=who, L=L)


@router.post("/diagnostics/settings")
def diagnostics_settings(request: Request, csrf: str = Form(""), diag_alerts: str = Form(""), diag_alert_to: str = Form(""), u=A):
    auth.check_csrf(request, csrf)
    db.set_setting("diag_alerts", "1" if diag_alerts else "0")
    db.set_setting("diag_alert_to", diag_alert_to.strip()[:200])
    db.audit("admin_settings", f"diagnostics email alerts {'on' if diag_alerts else 'off'}", None, u.email)
    flash(request, "Saved.")
    return redirect("/admin/diagnostics")


@router.post("/diagnostics/test")
def diagnostics_test(request: Request, csrf: str = Form(""), u=A):
    """Writes one test row so the admin can see the log working end to end."""
    from . import syslog as L
    auth.check_csrf(request, csrf)
    L.record("info", "app", f"Test entry added by {u.email}", "test", "/admin/diagnostics", "POST", None, u["id"])
    flash(request, "Test entry written to the system log.")
    return redirect("/admin/diagnostics?tab=log")


@router.get("/diagnostics/ep724")
def diagnostics_ep724(request: Request, u=A):
    """1.7.63: check STB for a newer EP 724 weekly file now (runs in the background; the Freight service data check shows the result)."""
    import threading
    from . import ep724
    threading.Thread(target=ep724.refresh, kwargs={"now_check": True}, daemon=True).start()
    db.audit("admin_settings", "freight service data: check STB now", None, u.email)
    flash(request, "Checking STB for new weekly freight service data. Reload Diagnostics in a minute to see the result.")
    return redirect("/admin/diagnostics")


@router.post("/diagnostics/ack")
def diagnostics_ack(request: Request, csrf: str = Form(""), area: str = Form(""), undo: str = Form(""), back: str = Form(""), u=A):
    """Mark an area's problems as seen (1.7.10): the health check and counts only count newer events. Nothing is deleted, the
    entries stay in the log, and Undo puts them back in the counts."""
    from . import syslog as L
    auth.check_csrf(request, csrf)
    areas = list(L.CATEGORIES) if area == "all" else [area] if area in L.CATEGORIES else []
    for a in areas:
        db.set_setting("diag_ack_" + a, "" if undo else L.since(0))
    if areas:
        what = "everything" if area == "all" else L.CATEGORIES[area]
        db.audit("admin_settings", f"diagnostics {'acknowledgement undone' if undo else 'marked as seen'}: {what}", None, u.email)
        flash(request, (f"{what.capitalize()} counts again from the full history." if undo else
                        f"Marked {what.lower()} as seen. Only new problems will show. Entries stay in the log."))
    return redirect(back if back.startswith("/admin/diagnostics") else "/admin/diagnostics")


@router.post("/diagnostics/clear")
def diagnostics_clear(request: Request, csrf: str = Form(""), older: int = Form(30), u=A):
    from . import syslog as L
    auth.check_csrf(request, csrf)
    older = older if older in (0, 7, 30) else 30
    db.x("DELETE FROM sys_event WHERE last_ts < ?", (L.since(older) if older else "9999",))
    db.audit("admin_settings", f"system log cleared ({'all' if not older else f'older than {older} days'})", None, u.email)
    flash(request, "System log cleared." if not older else f"Entries older than {older} days deleted.")
    return redirect("/admin/diagnostics?tab=log")


# ---------- SEO suggestions queue (1.7) ----------

from . import seosuggest  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402


@router.get("/seo")
def seo_queue(request: Request, status: str = "pending", u=A):
    if status not in ("pending", "approved", "rejected", "reverted", "superseded", "replaced", "all"):
        status = "pending"
    rows = seosuggest.listing(status)
    live = {(o["url_path"], o["field"]): o["value"] for o in seosuggest.live_overrides()}
    return render(request, "admin/seo.html", user=u, rows=rows, st=status, counts=seosuggest.counts(), FIELDS=seosuggest.FIELDS,
                  live=live, overrides=seosuggest.live_overrides(), key_set=bool(config.SEO_REPORT_KEY), site_url=config.SITE_URL)


@router.post("/seo/import")
async def seo_import(request: Request):
    """1.7.57 (Justin 11-16: SEO suggestions with no command-line step). Queues suggestions as pending, like `app.cli seo-import`.
    Two ways in: a JSON body (a list, or {"items": [...]}) with the X-SEO-Key header matching Admin > Settings > SEO automation, for
    the weekly routine; or the Upload suggestions form on Admin > SEO suggestions (admin session + CSRF). 404 for everyone else.
    Nothing goes live until an admin approves it."""
    import hmac
    key = request.headers.get("x-seo-key") or ""
    if key and config.SEO_REPORT_KEY and hmac.compare_digest(key.encode(), str(config.SEO_REPORT_KEY).encode()):
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Send the suggestions as a JSON list (or {\"items\": [...]})."}, status_code=400)
        items = body.get("items") if isinstance(body, dict) else body
        added, skipped, errors = seosuggest.import_items(items if isinstance(items, list) else [], source="weekly-api")
        return JSONResponse({"added": added, "skipped": skipped, "rejected": len(errors), "errors": errors[:20]},
                            headers={"Cache-Control": "no-store", "X-Robots-Tag": "noindex"})
    u = auth.current_user(request)
    if not (u and u.is_admin):
        raise HTTPException(404, "Not Found")
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    raw = ""
    f = form.get("file")
    if f is not None and hasattr(f, "read"):
        raw = (await f.read())[:2_000_000].decode("utf-8", "replace")
    raw = raw or (form.get("json") or "")
    try:
        body = json.loads(raw or "[]")
    except ValueError as e:
        flash(request, f"That isn't valid JSON ({e}).", "bad")
        return redirect("/admin/seo")
    items = body.get("items") if isinstance(body, dict) else body
    added, skipped, errors = seosuggest.import_items(items if isinstance(items, list) else [], source="upload")
    flash(request, f"Suggestions: {added} added, {skipped} skipped as duplicates, {len(errors)} rejected." + (" " + "; ".join(errors[:3]) if errors else ""))
    return redirect("/admin/seo")


@router.post("/seo/{sid}")
async def seo_decide(request: Request, sid: int, u=A):
    form = await request.form()
    auth.check_csrf(request, form.get("csrf", ""))
    act = form.get("action", "")
    s = seosuggest.get(sid)
    if not s:
        raise HTTPException(404, "Not Found")
    if act == "approve":
        v = seosuggest.approve(sid, u.email, form.get("text"))
        if v:
            db.audit("seo_approve", f"{s['url_path']} {s['field']}: {v}"[:300], None, u.email)
            flash(request, f"Live now on {s['url_path']}: {seosuggest.FIELDS[s['field']].lower()} changed.")
        else:
            flash(request, "That suggestion was already decided.", "bad")
    elif act == "reject":
        if seosuggest.reject(sid, u.email):
            db.audit("seo_reject", f"{s['url_path']} {s['field']}", None, u.email)
            flash(request, "Rejected.")
    elif act == "revert":
        if seosuggest.revert(sid, u.email):
            db.audit("seo_revert", f"{s['url_path']} {s['field']}", None, u.email)
            flash(request, f"Reverted: {s['url_path']} shows its earlier {seosuggest.FIELDS[s['field']].lower()} again.")
    return redirect("/admin/seo" + (f"?status={form.get('back')}" if form.get("back") else ""))


@router.get("/seo/report.json")
def seo_report(request: Request):
    """The latest weekly SEO report and suggestions, read-only. An admin session, or the X-SEO-Key header matching
    Admin > Settings > SEO automation; 404 for everyone else, like the rest of /admin."""
    import hmac
    key = request.headers.get("x-seo-key") or ""
    ok = bool(config.SEO_REPORT_KEY) and bool(key) and hmac.compare_digest(key.encode(), str(config.SEO_REPORT_KEY).encode())
    if not ok:
        u = auth.current_user(request)
        ok = bool(u and u.is_admin)
    if not ok:
        raise HTTPException(404, "Not Found")
    out = seosuggest.latest_report()
    out["queue"] = seosuggest.counts()
    return JSONResponse(out, headers={"Cache-Control": "no-store", "X-Robots-Tag": "noindex"})


# ---- 1.7.25: member uploads for the AI analyst, and public-record notices for Bid Catcher ----

@router.get("/uploads")
def uploads_page(request: Request, u=A):
    from . import uploads, uploadrec
    return render(request, "admin/uploads.html", user=u, rows=uploads.all_rows(), st=uploadrec.status_map(), key_set=bool(config.BIDS_INGEST_KEY))


@router.post("/uploads/{uid}/recheck")
def uploads_recheck(request: Request, uid: str, csrf: str = Form(""), u=A):
    from . import uploadrec
    auth.check_csrf(request, csrf)
    s = uploadrec.check(uid)
    flash(request, f"Checked again: {s or 'not classified (no API key or no text)'}.")
    return redirect("/admin/uploads")


def _bids_key_ok(request):
    import hmac
    key = request.headers.get("x-bids-key") or ""
    if config.BIDS_INGEST_KEY and key and hmac.compare_digest(key.encode(), str(config.BIDS_INGEST_KEY).encode()):
        return True
    cu = auth.current_user(request)
    return bool(cu and cu.is_admin)


@router.get("/uploads/notices.json")
def upload_notices(request: Request):
    """Public agency solicitations found in member uploads that bids.db doesn't have yet, for Bid Catcher to add (no member details).
    An admin session or the X-Bids-Key header; 404 for everyone else. ?all=1 includes ones already taken."""
    from . import uploadrec
    if not _bids_key_ok(request):
        raise HTTPException(404, "Not Found")
    return JSONResponse({"notices": uploadrec.candidates(include_sent=bool(request.query_params.get("all")))},
                        headers={"Cache-Control": "no-store", "X-Robots-Tag": "noindex"})


@router.post("/uploads/notices/ack")
async def upload_notices_ack(request: Request):
    """Bid Catcher marks candidates taken: JSON {"source_keys": ["upl-...", ...]}."""
    from . import uploadrec
    import hmac
    key = request.headers.get("x-bids-key") or ""  # key only (no session), so a cross-site form can't mark notices taken
    if not (config.BIDS_INGEST_KEY and key and hmac.compare_digest(key.encode(), str(config.BIDS_INGEST_KEY).encode())):
        raise HTTPException(404, "Not Found")
    try:
        body = await request.json()
    except Exception:
        body = {}
    return JSONResponse({"acked": uploadrec.ack(body.get("source_keys") or [])})
