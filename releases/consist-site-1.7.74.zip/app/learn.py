"""Training portal at /app/learn (Justin, 2026-11-11): a 'Start here' module for new members, then one module per feature.

Each module has a short 'why', 3 to 5 steps, and each step an animation of the screen: a small scripted SVG mock of the app
(sidebar, header search, page body) with a cursor that moves, clicks and types. The SVGs are drawn here from a tiny spec so they
stay in step with the UI and weigh a few KB; they loop and hold still for visitors who ask for reduced motion. A step may also
name a short recorded clip (static/learn/<file>.mp4); when the file exists it plays instead of the SVG (recorded later on staging).
Progress (which modules a member has finished) is kept per user in user_pref 'learn_done'."""
import html
import os

from . import db

STATIC = os.path.join(os.path.dirname(__file__), "static", "learn")

SIDE = ["My dashboard", "Bids and RFPs", "Past RFPs", "Operators", "Fleets", "Subsystems", "Market share", "AI analyst",
        "Alerts", "Account"]

# Each step: (title, text, scene, try-it link). A scene: side = highlighted sidebar item; body = page mock kind;
# act = list of actions: ("move", x, y), ("click",), ("type", where, text), ("show", what); cap = caption under the mock.
MODULES = [
    {"slug": "start", "title": "Start here", "icon": "target", "min": 5,
     "why": "What the site covers, how the menu is organized, and the first ten minutes that pay off most.",
     "steps": [
         ("Set your market and region", "The bar at the top of every page picks All rail, Transit or Passenger rail and the "
          "regions you cover. Every list, chart and count follows it.",
          {"side": 0, "body": "dash", "act": [("move", 470, 52), ("click",), ("show", "lens")]}, "/app"),
         ("Read the menu by job", "The sidebar is grouped by what you are trying to do: Find work (bids, upcoming work, "
          "awards), Installed base (operators, fleets, subsystems), Market, Suppliers and your Workspace.",
          {"side": 1, "body": "dash", "act": [("move", 70, 120), ("move", 70, 200), ("move", 70, 290)]}, "/app"),
         ("Tune your dashboard", "Tell us what you sell under Account and your dashboard shows the bids, fleets and signals "
          "for that trade. Click any number to open the list behind it.",
          {"side": 9, "body": "dash", "act": [("move", 70, 334), ("click",), ("move", 330, 150), ("click",)]}, "/app/account#market"),
         ("Save a search, get alerts", "On a paid plan, any filtered list of bids can be saved and emailed to you daily or "
          "instantly. Alerts lists everything you follow. In New saved search, each box (categories, subsystems, agencies, "
          "countries) takes as many picks as you like: a bid matches when it fits one pick in every box you set.",
          {"side": 8, "body": "table", "act": [("move", 560, 110), ("click",), ("show", "toast")]}, "/app/alerts"),
         ("Set up fleet updates", "Alerts > Fleet updates emails changes to fleets: new fleets, car counts, overhaul and end-of-life years, "
          "cost jumps and announced programs. Open Fleet update settings to choose the fleets you follow or every fleet, then narrow it "
          "by kind of change, mode, vehicle type, operator, country or your territory, and pick daily, weekly or no email.",
          {"side": 8, "body": "table", "act": [("move", 300, 120), ("click",), ("show", "toast")]}, "/app/alerts?tab=fleet"),
     ]},
    {"slug": "how", "title": "How every page works", "icon": "target", "min": 3,
     "why": "Every list, table and chart on the site behaves the same way. Learn these moves once and use them everywhere.",
     "steps": [
         ("Click a row to open it", "Click anywhere on a table row to open the fleet, operator, bid, award, order, builder or "
          "supplier it lists. A row that names a company opens that company (its profile, or its awards). A row that sums up a "
          "group (a year, a mode, a lessor) opens the list behind it. A record kept on another site, such as a federal grant, "
          "opens there in a new tab. Ctrl-click (Cmd-click on a Mac) opens any row in a new tab. Tables of yearly figures "
          "or calculations have nothing further to open.",
          {"side": 4, "body": "table", "act": [("move", 420, 190), ("click",), ("show", "page")]}, "/app/fleets"),
         ("Click a number tile", "The number tiles at the top of a page (fleets, cars, bids, orders, awards, bidders, winner) "
          "open the list they count, or jump to it further down the page. A tile with a › after its number is clickable.",
          {"side": 4, "body": "dash", "act": [("move", 200, 120), ("click",), ("show", "page")]}, "/app/supplier-intel"),
         ("Click a pill to filter", "A pill that names a value (a builder, a status, a kind of work) filters the list to it. "
          "The filter shows as a chip under 'Filtered by'. Click the pill again, or the chip's ✕, to clear it.",
          {"side": 4, "body": "table", "act": [("move", 400, 160), ("click",), ("show", "chip")]}, "/app/fleets"),
         ("Click a chart bar to drill in", "Bars in charts open the records behind them: a year, a builder, a subsystem or an owner. "
          "On Orders and backlog a builder's bar opens its orders that year; on the capital planner a bar narrows the table "
          "to that year. Click the same bar again, or Show all, to see everything. Trend lines are for reading, not clicking.",
          {"side": 6, "body": "bars", "act": [("move", 330, 180), ("click",), ("show", "filter")]}, "/app/market"),
         ("Hover for what it means", "Hover a column heading or a label to see its definition. Hover a pill or badge to "
          "see what it means or what clicking it does.",
          {"side": 4, "body": "table", "act": [("move", 300, 112), ("show", "hl")]}, "/app/fleets"),
         ("Sort, search and export", "Click a column heading to sort. Type in the header search to narrow the page you're "
          "on, or press Enter to search the whole site. Export CSV and Export Excel sit at the top right of a list on "
          "plans with export.",
          {"side": 4, "body": "table", "act": [("move", 300, 52), ("click",), ("type", "search", "Siemens"), ("show", "filter")]}, "/app/fleets"),
     ]},
    {"slug": "search", "title": "Finding anything", "icon": "search", "min": 3,
     "why": "One search box covers the whole site, and every pill you see is a filter.",
     "steps": [
         ("Filter the page you're on", "Start typing in the header search and the lists on the current page narrow as you type.",
          {"side": 4, "body": "table", "act": [("move", 300, 52), ("click",), ("type", "search", "Siemens"), ("show", "filter")]}, "/app/fleets"),
         ("Search the whole site", "Press Enter to search everything: pages, operators, fleets, builders and models, "
          "subsystem suppliers, bids, vehicle orders, awards and the supplier directory, grouped by type. Hyphens, "
          "spaces and dots don't matter: M9A finds M-9A, and SC44 finds SC-44.",
          {"side": -1, "body": "results", "act": [("move", 300, 52), ("click",), ("type", "search", "Charger"), ("show", "results")]}, "/app/search"),
         ("Click a pill to filter", "Any pill that names a value (a builder, a status, a trade) filters its list. Click it "
          "again, or the ✕ on the 'Filtered by' chip, to clear it.",
          {"side": 4, "body": "table", "act": [("move", 400, 160), ("click",), ("show", "chip")]}, "/app/fleets"),
     ]},
    {"slug": "fleets", "title": "Fleet Explorer", "icon": "fleet", "min": 4,
     "why": "Every passenger and transit fleet in the US and Canada: who built it, when, how many cars, and when it is due "
            "for overhaul or replacement.",
     "steps": [
         ("Filter the fleet list", "Use the filters and pills to narrow by operator, builder, mode or age. Sort any column.",
          {"side": 4, "body": "table", "act": [("move", 260, 110), ("click",), ("move", 420, 160), ("click",), ("show", "chip")]}, "/app/fleets"),
         ("Open an operator from a fleet", "Click an operator's name to open their page at the Fleets card. Use the small "
          "'only these' link to keep the list filtered to that operator instead.",
          {"side": 4, "body": "table", "act": [("move", 240, 190), ("click",), ("show", "page")]}, "/app/fleets"),
         ("Open a fleet record", "A fleet page shows the build, rebuilds, subsystems and suppliers, and the replacement window.",
          {"side": 4, "body": "detail", "act": [("move", 450, 150), ("show", "hl")]}, "/app/fleets"),
         ("Reported or estimated cost", "Most US transit costs come from NTD. Where a fleet reports nothing (Canada, Mexico, "
          "Amtrak, airports, freight), we estimate from the closest comparable fleets, or from STB R-1 for freight locomotives. "
          "Estimates carry a badge, a range and the fleets they came from.",
          {"side": 4, "body": "detail", "act": [("move", 450, 230), ("show", "hl2")]}, "/app/fleets"),
         ("Export (Investor plan and up)", "Plans with export can download the filtered list as CSV or Excel.",
          {"side": 4, "body": "table", "act": [("move", 590, 110), ("click",), ("show", "toast")]}, "/app/fleets"),
     ]},
    {"slug": "operators", "title": "Operator pages", "icon": "ops", "min": 4,
     "why": "Everything about one agency on one page: its fleets, subsystems, bids, awards, board meetings and news.",
     "steps": [
         ("Find an operator", "Use the Operators list (with category chips) or just type the name in the header search.",
          {"side": 3, "body": "table", "act": [("move", 300, 52), ("click",), ("type", "search", "SEPTA"), ("move", 260, 130), ("click",)]}, "/app/operators"),
         ("Follow operators and filter to them", "Click the ★ next to any operator (or Follow on its page) to follow it. The "
          "★ Following pill at the top of the Operators list then shows only the operators you follow, with the count; click it "
          "again to see everyone. Followed operators also feed your dashboard and alerts.",
          {"side": 3, "body": "table", "act": [("move", 60, 130), ("click",), ("move", 120, 52), ("click",), ("show", "hl")]}, "/app/operators?following=1"),
         ("Find an agency's bid and award pages", "The Procurement and award portals card on an operator page links to each of its "
          "buying agencies' own pages: the bidding portal, plus where the agency posts awards, closed solicitations and bid tabulations "
          "(a PDF tag marks a document). Bid Catcher reads these pages, so the bids and awards on them reach the bid feed and Recent awards. "
          "The same links show under each agency on Agency coverage.",
          {"side": 1, "body": "detail", "act": [("move", 300, 220), ("show", "hl")]}, "/app/operators"),
         ("Read the fleet and subsystem cards", "See every fleet, its age and status, and who supplies brakes, HVAC, doors, "
          "propulsion and train control.",
          {"side": 3, "body": "detail", "act": [("move", 330, 160), ("show", "hl")]}, "/app/operators"),
         ("Board meetings and documents", "Upcoming board meetings, the rail items on their agendas, and recent documents: "
          "often the first sign of a procurement.",
          {"side": 3, "body": "detail", "act": [("move", 330, 270), ("show", "hl2")]}, "/app/operators"),
         ("Build an account brief", "Click Account brief at the top of an operator page and tick what to include: any card on "
          "the page (key figures, why now, fleets, cost charts, reliability, train control, bids, board meetings, orders, "
          "awards, contacts and notes) plus the agency's federal grants, budget and board funding items, capital projects out "
          "to bid and on-call contracts. Press Generate brief, then Print or save as PDF. The brief ends with a Key to terms for "
          "its grade pills, mode codes and abbreviations. Your picks are remembered, and "
          "Change what is included on the brief reopens the menu.",
          {"side": 3, "body": "detail", "act": [("move", 520, 60), ("click",), ("move", 520, 140), ("show", "hl")]}, "/app/operators"),
     ]},
    {"slug": "bids", "title": "Bid Catcher: bids and RFPs", "icon": "bids", "min": 5,
     "why": "Every public rail and transit procurement in the US and Canada, checked daily and scored for relevance.",
     "steps": [
         ("Filter by relevance", "Each bid is scored 0 to 100 for rail vehicle relevance. The Relevance filter defaults to "
          "50+; pick 75+ for only the closest matches or All to see everything.",
          {"side": 1, "body": "table", "act": [("move", 520, 110), ("click",), ("show", "chip")]}, "/app/bids"),
         ("Open a bid", "A bid page has the summary, dates, documents, the fleet it relates to, and an AI fit brief. "
          "A bid we found in an agency document rather than on a bid portal shows How to get the documents instead: the contact the solicitation names and the agency website.",
          {"side": 1, "body": "detail", "act": [("move", 300, 150), ("show", "hl")]}, "/app/bids"),
         ("French and Spanish notices", "French and Spanish notices (Québec's SEAO, federal Canada, Spanish-language agencies) "
          "show an English machine translation with the original, on the site and in alert emails. The original is the official text; check it before bidding.",
          {"side": 1, "body": "detail", "act": [("move", 300, 170), ("show", "hl2")]}, "/app/bids"),
         ("Save it as an alert", "Save your filtered search and choose daily or instant email.",
          {"side": 1, "body": "table", "act": [("move", 560, 110), ("click",), ("show", "toast")]}, "/app/bids"),
         ("Learn from past RFPs", "Past RFPs show who bid, at what price, and who won. Click the bidders count to see them all.",
          {"side": 2, "body": "table", "act": [("move", 470, 190), ("click",), ("show", "page")]}, "/app/past-rfps"),
         ("On-call expiry", "On-call contracts shows every on-call, IDIQ and standing-offer bench we know of, one row per bench "
          "with all the firms on it. Ends is the base term. With options is the latest the agency can extend it. Rebid due is a "
          "year before that. A green Next round posted pill means the agency has already put out the next solicitation, so click "
          "it to see the RFQ. Values are the bench's shared ceiling, not money spent, unless a Spent figure is shown.",
          {"side": 2, "body": "table", "act": [("move", 300, 200), ("show", "hl2"), ("move", 330, 230), ("click",), ("show", "page")]}, "/app/capital-pipeline#oncall"),
         ("Early signals", "Find work > Early signals collects everything that comes before an RFP: RFIs, sources-sought "
          "notices and industry days (all of them, since these short notices score low on relevance), agency procurement "
          "forecasts, board votes that authorize a solicitation or budget a buy, on-call contracts due for rebid within a "
          "year, and vehicle orders still being planned. Respond to RFIs and attend industry days to get on the shortlist.",
          {"side": 3, "body": "table", "act": [("move", 330, 180), ("show", "hl")]}, "/app/early-signals"),
         ("Agency coverage", "The Coverage page shows every agency Bid Catcher follows and how: reading its procurement page, "
          "board meetings and documents, alert emails from its bidding portal, or public open-data feeds. Live means it is read "
          "automatically and postings or awards have turned up there in the last 180 days. Read, nothing found means we read its "
          "pages fine but nothing has turned up in 180 days, usually because the page is a landing or login page; we're finding "
          "the right one. Email alerts means notices arrive through the agency's portal. Limited means the "
          "agency's site blocks automated readers and we're arranging alerts or permission. A quiet note means an agency that "
          "usually posts often hasn't posted lately. That's usually a lull, and we check the feed. Your territory applies here too.",
          {"side": 3, "body": "table", "act": [("move", 330, 180), ("show", "hl")]}, "/app/coverage"),
         ("Coverage map", "Click the Coverage map pill at the top of Agency coverage to see every agency on a map. Dots are coloured "
          "by how we follow its bids: green Live, blue Email alerts, orange Limited, purple Pending, sand Read, nothing found "
          "(we read its pages but nothing has turned up in 180 days), grey Not yet covered; a dashed "
          "red ring marks a quiet agency. Click a dot for its bidding portal, how we follow it, last posting and open bids, with "
          "links to its bids and agency page. The map follows your territory and the status pills, and the same pill hides it again.",
          {"side": 3, "body": "dash", "act": [("move", 470, 52), ("click",), ("show", "page")]}, "/app/coverage?map=1"),
     ]},
    {"slug": "analyst", "title": "AI analyst and briefs", "icon": "ai", "min": 5,
     "why": "Ask questions in plain English and get answers grounded in the site's data, with sources. Turn any bid into a "
            "fit brief you can share.",
     "steps": [
         ("Ask a question", "Type a question about fleets, bids, suppliers or markets. Answers cite the records they use.",
          {"side": 7, "body": "chat", "act": [("move", 330, 330), ("click",), ("type", "chat", "Which fleets need HVAC overhaul by 2028?"), ("show", "answer")]}, "/app/analyst"),
         ("Ask about one fleet", "On a fleet page, 'Ask about this fleet' sends that fleet's record along with your question.",
          {"side": 4, "body": "detail", "act": [("move", 560, 90), ("click",), ("show", "page")]}, "/app/fleets"),
         ("Brief a bid, then update it", "On a bid page, the AI brief gives a fit verdict and key figures. 'Update the brief' "
          "re-runs it with the latest information (one question).",
          {"side": 1, "body": "detail", "act": [("move", 450, 240), ("click",), ("show", "hl2")]}, "/app/bids"),
         ("Download PDF, RTF or TXT", "Every brief and answer downloads as a branded PDF, an RTF for Word, or plain text. Each one ends with a Key to terms "
          "that explains its verdict and confidence pills and any abbreviations it uses (NTD, IDIQ, CBTC and so on), so a colleague "
          "who has never used the site can read it.",
          {"side": 7, "body": "chat", "act": [("move", 540, 200), ("click",), ("show", "toast")]}, "/app/analyst"),
     ]},
    {"slug": "uploads", "title": "Uploading your documents", "icon": "doc", "min": 3,
     "why": "Give the analyst a document (an RFP, a spec, a report) and ask about it alongside the site's data.",
     "steps": [
         ("Attach a file", "PDF, Word, text or CSV up to 10 MB. Tick the consent box, then ask your question.",
          {"side": 7, "body": "chat", "act": [("move", 120, 330), ("click",), ("show", "file"), ("type", "chat", "Summarize the car spec")]}, "/app/analyst"),
         ("Reuse or delete it", "Your uploads stay private to you. Reuse one with a new question or delete it any time.",
          {"side": 7, "body": "chat", "act": [("move", 540, 120), ("show", "hl")]}, "/app/analyst"),
         ("What we keep", "Uploads are never shared. If one is a public agency solicitation, the bid itself may be added to "
          "Bid Catcher, with nothing about you. See the Privacy page for details.",
          {"side": 7, "body": "chat", "act": [("show", "lock")]}, "/privacy"),
     ]},
    {"slug": "market", "title": "Market intelligence", "icon": "pie", "min": 4,
     "why": "Who supplies what across the installed base, and where share is changing.",
     "steps": [
         ("Market share", "See builder and supplier share by cars and fleets for your market and region.",
          {"side": 6, "body": "bars", "act": [("move", 330, 180), ("show", "hl")]}, "/app/market"),
         ("Zoom into a subsystem", "Click a subsystem to see every supplier in it, their share, and which car builders they supply.",
          {"side": 6, "body": "bars", "act": [("move", 250, 120), ("click",), ("show", "chip")]}, "/app/market"),
         ("Subsystems and suppliers", "Subsystems lists the supplier on each fleet; the supplier directory and supplier "
          "intelligence pages profile each company.",
          {"side": 5, "body": "table", "act": [("move", 330, 190), ("click",), ("show", "page")]}, "/app/subsystems"),
         ("Vehicle orders", "Upcoming work > Vehicle orders lists recent and active rolling stock orders and the cars still to "
          "come by year. Click any order to open its details: quantities, options, value, delivery, the operator's fleets "
          "and the builder's other orders.",
          {"side": 2, "body": "table", "act": [("move", 330, 180), ("click",), ("show", "page")]}, "/app/work?view=orders"),
         ("Replacement ordered", "When an agency has already ordered a fleet's replacement (for example LIRR's Alstom M9A "
          "replacing the M3), that fleet is left out of the buy ranking and shows a Replacement ordered pill that opens the "
          "order. Use Show already ordered to bring those fleets back. A Replacement RFP out pill means the replacement "
          "is out to bid or planned, so the buy is still open.",
          {"side": 2, "body": "table", "act": [("move", 330, 180), ("show", "hl")]}, "/app/work?view=ranked"),
         ("Option exercises", "An Option exercise row in Upcoming work means an agency can still buy more cars on an order it "
          "already signed, e.g. \"CTDOT can still buy 313 more on the 2023 Alstom order (60 ordered)\". If those cars aren't in "
          "service yet, the row shows the order itself, marked \"on order, not in service yet\", with a New cars on order pill "
          "instead of fleet signals (older orders we can't tie to a fleet say No fleet match). Its year and value are estimates: hover the value to see how it was worked out. Click the "
          "row to open the order.",
          {"side": 2, "body": "table", "act": [("move", 330, 180), ("show", "hl"), ("click",), ("show", "page")]}, "/app/work?type=option"),
         ("Weekly freight service", "Freight > Weekly service metrics shows how each Class I network is running: train speed, "
          "terminal dwell, cars online, stalled cars and carloads, as 4-week averages against a year earlier. It updates "
          "itself: the site checks the STB every day and loads each new week as soon as the railroads' reports are posted, "
          "usually about a week after the week ends. Latest week at the top tells you how current it is.",
          {"side": 5, "body": "bars", "act": [("move", 330, 180), ("show", "hl")]}, "/rail/service"),
     ]},
    {"slug": "explorer", "title": "Market Explorer: your market on one map", "icon": "pie", "min": 3,
     "why": "See every operator in your market on one map with its fleets, overhauls due, open bids, recent awards and "
            "estimated consumables spend, and narrow it down to a target list in a few clicks.",
     "steps": [
         ("One map, one table", "Market Explorer (Market in the menu) plots every operator in your lens and territory at its head "
          "office or main city. The table under the map and the In view tiles above it count only what is on the map, so pan "
          "and zoom to a region and the totals follow. Untick Table and totals follow the map to see everything.",
          {"side": 6, "body": "dash", "act": [("move", 330, 180), ("show", "hl")]}, "/app/explorer"),
         ("Filters and what the dots mean", "Use the filter rail for country, state or province, mode, average fleet age, an "
          "overhaul due in the next five years, open bids or awards in the last two years. Dot size can show cars, "
          "consumables spend or award dollars; dot colour can show fleet age, overhauls due or open bids. A blue ring marks "
          "an operator with open bids. The legend under the filters explains the colours.",
          {"side": 6, "body": "dash", "act": [("move", 120, 160), ("click",), ("show", "chip")]}, "/app/explorer"),
         ("Linking rows and dots", "Click a table row to fly the map to that operator and open its card; click a dot to "
          "highlight its row. The card links to the operator page, its fleets and its bids. Click a column heading to sort. "
          "Plans with exports can download what is in view with Export CSV.",
          {"side": 6, "body": "table", "act": [("move", 330, 200), ("click",), ("show", "page")]}, "/app/explorer"),
     ]},
    {"slug": "account", "title": "Account, plans and alerts", "icon": "user", "min": 3,
     "why": "What your plan includes, how to change it, and how to manage email alerts.",
     "steps": [
         ("Confirm your email", "New accounts open when you click the link we email after sign-up (it works for 48 hours). "
          "Nothing there? Check spam or promotions, or sign in and press Send a new link. Colleagues you invite to your team skip this step.",
          {"side": 9, "body": "dash", "act": [("move", 330, 150), ("click",), ("show", "toast")]}, "/app/account"),
         ("See what your plan includes", "Pages your plan doesn't include show a preview or a lock with the plan that adds them.",
          {"side": 9, "body": "dash", "act": [("move", 70, 334), ("click",), ("show", "lock")]}, "/app/account"),
         ("Manage alerts", "Change how often each saved search emails you, or turn it off. With a sales territory saved, one "
          "click limits an alert to bids from the agencies you cover.",
          {"side": 8, "body": "table", "act": [("move", 520, 160), ("click",), ("show", "chip")]}, "/app/alerts"),
         ("Your sales territory", "Cover a region or a set of accounts? In Account > Your territory, tick the states and provinces "
          "you cover (region buttons tick a group at once; Select all ticks every state and province), add agencies by name, and choose whether national buyers such as Amtrak "
          "count. Save, and the Territory switch at the top of every page turns it on or off. While it is on, bids, early signals, "
          "awards, board items, vehicle orders, fleets, operators, upcoming work, opportunities, dashboards and search show only "
          "your territory. A link to one named agency still opens it, and cost benchmarks and price comparisons stay national. "
          "In Alerts, tick Only bids in my territory on any saved search and its emails follow your territory too.",
          {"side": 9, "body": "dash", "act": [("move", 470, 52), ("click",), ("show", "lens")]}, "/app/account#territory"),
         ("Times in your time zone", "Every time on the site, such as when a bid was found, a note was written or data was last checked, "
          "shows in your own time zone with its abbreviation (EST, PST and so on). It follows your browser; to fix one zone, "
          "choose it in Account > Time zone. Bid closing dates are the agency's own dates and don't shift.",
          {"side": 9, "body": "dash", "act": [("move", 330, 150), ("show", "hl")]}, "/app/account#timezone"),
         ("Upgrade or change plan", "Upgrade from Account; annual billing saves 20%.",
          {"side": 9, "body": "dash", "act": [("move", 330, 150), ("click",), ("show", "toast")]}, "/app/upgrade"),
         ("Follow us anywhere", "Our LinkedIn page and Bluesky post notable new rail bids, contract awards, fleet facts, charts "
          "and a Friday roundup of the week's procurement, a few times a week and only when there's news. The links are in the footer "
          "of every page.",
          {"side": 9, "body": "dash", "act": [("move", 330, 380), ("click",), ("show", "toast")]}, "/"),
         ("Monthly report and free charts", "Each month we email members the rail fleet report's headline numbers; the unsubscribe "
          "link in that email stops it. The public data pages have an Embed this chart box: paste the code into your own site, "
          "report or slides and the chart stays current, with a credit link back to us.",
          {"side": 9, "body": "bars", "act": [("move", 330, 180), ("click",), ("show", "toast")]}, "/data/midlife-overhauls-due#embed"),
         ("Public builder and model pages", "Anyone can look up a rail car builder or model at /builders without signing in: "
          "who runs the Kawasaki M8 or the Alstom Citadis, how many are in service and when they were built, with links to each "
          "operator's public fleet roster. Handy to share with a colleague; the member pages add costs, overhaul timing and suppliers.",
          {"side": 9, "body": "bars", "act": [("move", 330, 180), ("click",), ("show", "toast")]}, "/builders"),
         ("Cookie choices", "Our public pages may ask once whether you accept LinkedIn advertising cookies, which help us measure our "
          "LinkedIn ads. They are off unless you click Accept, never run inside the app, and you can change your mind with Cookie "
          "choices in the site footer. The Privacy page explains what LinkedIn receives.",
          {"side": 9, "body": "dash", "act": [("show", "lock")]}, "/privacy"),
     ]},
]
BY_SLUG = {m["slug"]: m for m in MODULES}


def done_set(u):
    try:
        r = db.q("SELECT value FROM user_pref WHERE user_id = ? AND key = 'learn_done'", (u["id"],), one=True)
    except Exception:
        return set()
    return set(filter(None, ((r[0] if r else "") or "").split(",")))


def mark_done(u, slug, on=True):
    if slug not in BY_SLUG:
        return
    s = done_set(u)
    (s.add if on else s.discard)(slug)
    v = ",".join(m["slug"] for m in MODULES if m["slug"] in s)
    db.x("INSERT INTO user_pref (user_id, key, value) VALUES (?, 'learn_done', ?) "
         "ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value", (u["id"], v))


def clip_for(slug, i):
    f = f"{slug}-{i + 1}.mp4"
    return f"/static/learn/{f}" if os.path.exists(os.path.join(STATIC, f)) else None


# ---------- SVG scene ----------
W, H = 640, 380
BODY_X, BODY_Y = 150, 80


def _e(s):
    return html.escape(str(s), quote=True)


def _body(kind):
    o = []
    x0, y0 = BODY_X + 16, BODY_Y + 16
    if kind in ("table", "results"):
        o.append(f'<rect x="{x0}" y="{y0}" width="200" height="14" rx="3" class="l-ink"/>')
        o.append(f'<rect x="{W-140}" y="{y0-4}" width="64" height="22" rx="11" class="l-pill"/>'
                 f'<rect x="{W-68}" y="{y0-4}" width="52" height="22" rx="6" class="l-btn"/>')
        for i in range(7):
            y = y0 + 40 + i * 30
            cls = "l-row l-hit" if kind == "results" and i in (0, 3) else "l-row"
            o.append(f'<g class="{cls}"><rect x="{x0}" y="{y}" width="{W-x0-16}" height="24" rx="4" class="l-rowbg"/>'
                     f'<rect x="{x0+8}" y="{y+8}" width="{90+(i*23)%60}" height="8" rx="2" class="l-ln"/>'
                     f'<rect x="{x0+180}" y="{y+6}" width="46" height="12" rx="6" class="l-pill"/>'
                     f'<rect x="{x0+260}" y="{y+8}" width="{40+(i*17)%50}" height="8" rx="2" class="l-ln"/></g>')
    elif kind == "detail":
        o.append(f'<rect x="{x0}" y="{y0}" width="240" height="16" rx="3" class="l-ink"/>'
                 f'<rect x="{W-110}" y="{y0-4}" width="94" height="22" rx="6" class="l-btn"/>')
        for j, (yy, hh) in enumerate([(50, 90), (155, 70), (240, 60)]):
            o.append(f'<rect x="{x0}" y="{y0+yy}" width="{W-x0-16}" height="{hh}" rx="8" class="l-card"/>')
            for k in range(hh // 22):
                o.append(f'<rect x="{x0+14}" y="{y0+yy+14+k*20}" width="{160+(k*41)%140}" height="8" rx="2" class="l-ln"/>')
    elif kind == "chat":
        o.append(f'<rect x="{x0}" y="{y0}" width="160" height="14" rx="3" class="l-ink"/>')
        o.append(f'<rect x="{x0+180}" y="{y0+30}" width="{W-x0-196}" height="34" rx="10" class="l-bubble l-me"/>')
        o.append(f'<g class="l-answer"><rect x="{x0}" y="{y0+80}" width="{W-x0-60}" height="120" rx="10" class="l-card"/>'
                 + "".join(f'<rect x="{x0+14}" y="{y0+96+k*20}" width="{220+(k*53)%160}" height="8" rx="2" class="l-ln"/>' for k in range(5))
                 + f'<rect x="{W-110}" y="{y0+110}" width="60" height="20" rx="6" class="l-btn"/></g>')
        o.append(f'<rect x="{x0}" y="{H-58}" width="{W-x0-16}" height="36" rx="8" class="l-input"/>'
                 f'<rect x="{x0+8}" y="{H-50}" width="20" height="20" rx="4" class="l-pill"/>')
    elif kind == "bars":
        o.append(f'<rect x="{x0}" y="{y0}" width="180" height="14" rx="3" class="l-ink"/>')
        for i, w in enumerate([300, 230, 170, 120, 80, 50]):
            y = y0 + 40 + i * 36
            o.append(f'<rect x="{x0}" y="{y}" width="70" height="8" rx="2" class="l-ln"/>'
                     f'<rect x="{x0+90}" y="{y-6}" width="{w}" height="20" rx="4" class="l-bar l-b{i%3}"/>')
    else:  # dash
        for i in range(3):
            o.append(f'<rect x="{x0+i*150}" y="{y0}" width="136" height="64" rx="8" class="l-card"/>'
                     f'<rect x="{x0+i*150+12}" y="{y0+14}" width="50" height="16" rx="3" class="l-ink"/>'
                     f'<rect x="{x0+i*150+12}" y="{y0+40}" width="90" height="8" rx="2" class="l-ln"/>')
        o.append(f'<rect x="{x0}" y="{y0+80}" width="{W-x0-16}" height="170" rx="8" class="l-card"/>')
        for k in range(6):
            o.append(f'<rect x="{x0+14}" y="{y0+98+k*24}" width="{200+(k*61)%180}" height="8" rx="2" class="l-ln"/>')
    return "".join(o)


def scene(spec, uid, label):
    """Return an inline SVG for one step. The cursor walks through the 'move' points; 'click' pulses; 'type' types text into
    the header search or the chat box; 'show' reveals an overlay (filter chip, toast, highlight, answer). Loops every 7s."""
    acts = spec.get("act", [])
    pts = [(560, 340)] + [(a[1], a[2]) for a in acts if a[0] == "move"]
    n = max(1, len(acts))
    T = 7.0
    # cursor keyframes: one segment per action, then hold, then fade back
    kf, t, cur, clicks, typed, shows = [], 0.0, pts[0], [], [], []
    step = 0.7 / n
    kf.append((0, cur))
    mi = 1
    for i, a in enumerate(acts):
        t = round(0.08 + i * step, 3)
        if a[0] == "move":
            cur = pts[mi]; mi += 1
            kf.append((t + step * 0.8, cur))
        elif a[0] == "click":
            clicks.append((t, cur))
        elif a[0] == "type":
            typed.append((t, a[1], a[2]))
        elif a[0] == "show":
            shows.append((t, a[1]))
    kf.append((0.92, cur))
    kf.append((1.0, cur))
    css_kf = " ".join(f"{p*100:.1f}%{{transform:translate({x}px,{y}px)}}" for p, (x, y) in kf)
    s = [f'<svg class="lscene" viewBox="0 0 {W} {H}" role="img" aria-label="{_e(label)}" id="{uid}" xmlns="http://www.w3.org/2000/svg">',
         f'<style>#{uid} .cur{{animation:{uid}m {T}s infinite ease-in-out}} @keyframes {uid}m{{{css_kf}}}']
    for j, (p, (x, y)) in enumerate(clicks):
        a, b = p * 100, min(100, p * 100 + 6)
        s.append(f'#{uid} .ck{j}{{transform-origin:{x}px {y}px;animation:{uid}c{j} {T}s infinite}}'
                 f'@keyframes {uid}c{j}{{0%,{a:.1f}%{{opacity:0;transform:scale(.3)}}{a+1:.1f}%{{opacity:.9}}{b:.1f}%,100%{{opacity:0;transform:scale(1.6)}}}}')
    for j, (p, _w, txt) in enumerate(typed):
        a, b = p * 100, min(95, p * 100 + 14)
        s.append(f'#{uid} .ty{j}{{animation:{uid}t{j} {T}s infinite steps({max(1, len(txt))})}}'
                 f'@keyframes {uid}t{j}{{0%,{a:.1f}%{{width:0}}{b:.1f}%,96%{{width:{len(txt)*7.2+4:.0f}px}}100%{{width:0}}}}')
    for j, (p, _w) in enumerate(shows):
        a = p * 100 + 6
        s.append(f'#{uid} .sh{j}{{animation:{uid}s{j} {T}s infinite}}'
                 f'@keyframes {uid}s{j}{{0%,{a:.1f}%{{opacity:0}}{a+3:.1f}%,94%{{opacity:1}}100%{{opacity:0}}}}')
    s.append(f'@media (prefers-reduced-motion:reduce){{#{uid} *{{animation:none!important}} #{uid} .cur{{transform:translate({cur[0]}px,{cur[1]}px)}} '
             f'#{uid} [class^=sh]{{opacity:1}}}}</style>')
    # frame
    s.append(f'<rect width="{W}" height="{H}" rx="12" class="l-frame"/><rect width="{W}" height="26" rx="12" class="l-chrome"/>'
             f'<rect y="14" width="{W}" height="12" class="l-chrome"/>'
             + "".join(f'<circle cx="{16+i*14}" cy="13" r="4" class="l-dot"/>' for i in range(3)))
    # sidebar
    s.append(f'<rect x="0" y="26" width="{BODY_X-10}" height="{H-26}" class="l-side"/>'
             f'<text x="16" y="52" class="l-logo">Consist</text>')
    for i, lab in enumerate(SIDE):
        y = 76 + i * 29
        on = i == spec.get("side")
        s.append(f'<g class="l-nav{" l-on" if on else ""}"><rect x="6" y="{y-14}" width="{BODY_X-22}" height="22" rx="5" class="l-navbg"/>'
                 f'<text x="16" y="{y+1}">{_e(lab)}</text></g>')
    # header: search + lens
    s.append(f'<rect x="{BODY_X}" y="38" width="250" height="28" rx="14" class="l-input l-search"/>'
             f'<circle cx="{BODY_X+18}" cy="51" r="5" class="l-ic"/><text x="{BODY_X+30}" y="56" class="l-ph">Search fleets, operators…</text>'
             f'<g class="l-lens"><rect x="{W-200}" y="38" width="184" height="28" rx="8" class="l-seg"/>'
             f'<rect x="{W-198}" y="40" width="60" height="24" rx="6" class="l-segon"/>'
             f'<text x="{W-188}" y="56">All rail</text><text x="{W-128}" y="56">Transit</text><text x="{W-72}" y="56">Passenger</text></g>')
    s.append(_body(spec.get("body", "dash")))
    # overlays
    for j, (p, what) in enumerate(shows):
        g = f'<g class="sh{j}">'
        if what == "chip":
            g += f'<rect x="{BODY_X+16}" y="{BODY_Y+38}" width="150" height="22" rx="11" class="l-chip"/><text x="{BODY_X+28}" y="{BODY_Y+53}" class="l-chipt">Filtered by ✕</text>'
        elif what == "toast":
            g += f'<rect x="{W-230}" y="{H-60}" width="210" height="40" rx="8" class="l-toast"/><text x="{W-216}" y="{H-35}" class="l-toastt">Done ✓</text>'
        elif what in ("hl", "hl2"):
            y = BODY_Y + (66 if what == "hl" else 250)
            g += f'<rect x="{BODY_X+10}" y="{y}" width="{W-BODY_X-20}" height="{100 if what == "hl" else 74}" rx="10" class="l-ring"/>'
        elif what == "lens":
            g += f'<rect x="{W-204}" y="34" width="192" height="36" rx="10" class="l-ring"/>'
        elif what in ("filter", "results"):
            g += f'<rect x="{BODY_X+16}" y="{BODY_Y+56}" width="{W-BODY_X-32}" height="24" rx="4" class="l-ring"/>'
            if what == "results":
                g += f'<rect x="{BODY_X+16}" y="{BODY_Y+146}" width="{W-BODY_X-32}" height="24" rx="4" class="l-ring"/>'
        elif what == "page":
            g += f'<rect x="{BODY_X}" y="{BODY_Y}" width="{W-BODY_X}" height="{H-BODY_Y}" class="l-veil"/>' \
                 f'<rect x="{BODY_X+40}" y="{BODY_Y+40}" width="{W-BODY_X-80}" height="200" rx="10" class="l-card l-pop"/>' \
                 + "".join(f'<rect x="{BODY_X+56}" y="{BODY_Y+60+k*22}" width="{180+(k*37)%140}" height="8" rx="2" class="l-ln"/>' for k in range(7))
        elif what == "answer":
            g += f'<rect x="{BODY_X+12}" y="{BODY_Y+92}" width="{W-BODY_X-80}" height="128" rx="12" class="l-ring"/>'
        elif what == "file":
            g += f'<rect x="{BODY_X+16}" y="{H-96}" width="170" height="28" rx="6" class="l-chip"/><text x="{BODY_X+28}" y="{H-77}" class="l-chipt">spec.pdf  ☑ consent</text>'
        elif what == "lock":
            g += f'<rect x="{W/2-20}" y="{H/2-30}" width="190" height="56" rx="10" class="l-toast"/><text x="{W/2-6}" y="{H/2+3}" class="l-toastt">🔒 Private to you</text>'
        s.append(g + "</g>")
    for j, (p, where, txt) in enumerate(typed):
        x, y = (BODY_X + 30, 56) if where == "search" else (BODY_X + 50, H - 35)
        s.append(f'<rect x="{x-2}" y="{y-14}" width="{"200" if where == "search" else "400"}" height="20" class="l-inbg"/>'
                 f'<svg x="{x}" y="{y-14}" height="20" class="ty{j}" style="overflow:hidden"><text x="0" y="14" class="l-typed">{_e(txt)}</text></svg>')
    for j, (p, (x, y)) in enumerate(clicks):
        s.append(f'<circle cx="{x}" cy="{y}" r="14" class="l-click ck{j}"/>')
    s.append('<g class="cur"><path d="M0 0 L0 17 L5 13 L8 20 L11 19 L8 12 L14 12 Z" class="l-arrow"/></g></svg>')
    return "".join(s)


def modules_for(u):
    done = done_set(u)
    return [dict(m, done=m["slug"] in done) for m in MODULES], done
