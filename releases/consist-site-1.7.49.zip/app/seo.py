"""Search promotion that runs by itself: the sitemap's URL list, IndexNow pings, the RSS feed and the public data pages
(/data/...), which are rebuilt from fleet.db and bids.db each time they are requested and cached for an hour.

IndexNow (https://www.indexnow.org) tells Bing and the engines that share its index when pages change. The site serves its key at
/<key>.txt; a background thread submits the URLs whose lastmod changed since the last ping, once a day. It only runs on the
production domain (never staging or localhost) and can be turned off in Admin > Settings > General."""
import datetime
import hashlib
import json
import logging
import os
import secrets
import threading
import time
import urllib.request
from urllib.parse import urlparse

from . import compare, config, content, data, db

log = logging.getLogger("seo")

# ---------- public data pages ----------

PUBLIC_SCOPE = ("coalesce(o.category, '') NOT LIKE 'freight%' AND o.country IN ('US', 'CA') AND coalesce(p.qty_active, 0) > 0 "
                # heritage cable cars, inclines and vintage streetcars would fill the "oldest" list without being anyone's next order
                "AND coalesce(p.vehicle_class, '') NOT IN ('heritage_streetcar', 'cable_car', 'incline_car') AND coalesce(p.ntd_mode, '') NOT IN ('CC', 'IP')")

DATA_PAGES = {
    "oldest-rail-fleets": {
        "title": "Oldest passenger rail fleets in the US and Canada",
        "h1": "The oldest passenger rail fleets in the US and Canada",
        "description": "The 50 oldest passenger rail car fleets (5 or more cars in service) in the US and Canada by build year, with builder, operator and cars in service. Updated monthly.",
        "lead": "These are the 50 oldest passenger rail car fleets still in active service in the US and Canada, ranked by the year the cars were built. "
                "Groups of fewer than 5 cars, heritage streetcars, cable cars and inclines are left out. "
                "Old fleets are where rebuilds, component replacement and new car orders come next.",
    },
    "midlife-overhauls-due": {
        "title": "Rail car midlife overhauls coming due",
        "h1": "Passenger rail fleets coming due for a midlife overhaul",
        "description": "US and Canadian passenger rail fleets whose midlife overhaul falls due in the next five years, with builder, cars and due year. Updated monthly.",
        "lead": "These passenger rail fleets reach their estimated midlife overhaul in the next five years. The due year comes from each fleet's "
                "build or last rebuild year and the overhaul interval for its type of car, adjusted for how hard the fleet works.",
    },
    "rail-bids-this-month": {
        "title": "Rail and transit bids this month",
        "h1": "Rail and transit bids posted in the last 30 days",
        "description": "How many rail and transit procurement notices US and Canadian agencies posted in the last 30 days, by category and state, with recent examples.",
        "lead": "Public rail and transit procurement notices posted by US and Canadian agencies in the last 30 days, counted by category and "
                "state or province. Only notices scored as rail-relevant are counted.",
    },
}

_cache = {}


def _cached(key, fn, ttl=3600):
    hit = _cache.get(key)
    if hit and hit[0] > time.time() - ttl:
        return hit[1]
    val = fn()
    _cache[key] = (time.time(), val)
    return val


def _fleet_rows(order, where="", limit=50):
    sql = ("SELECT p.fleet_id, p.operator_id, o.operator_name, o.service_name, o.country, p.ntd_mode, p.manufacturer, p.model_name, "
           "p.vehicle_class, p.build_year, p.last_rebuild_year, p.qty_active, p.midlife_due_year "
           f"FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE {PUBLIC_SCOPE} {where} ORDER BY {order} LIMIT {int(limit)}")
    return [dict(r) for r in db.fq(sql)]


def oldest_fleets():
    return _cached("oldest", lambda: _fleet_rows("p.build_year ASC, p.qty_active DESC", "AND p.build_year IS NOT NULL AND p.qty_active >= 5"))


def midlife_due():
    y = datetime.date.today().year
    return _cached("midlife", lambda: _fleet_rows("p.midlife_due_year ASC, p.qty_active DESC",
                                                  f"AND p.midlife_due_year BETWEEN {y} AND {y + 5}", limit=100))


def bids_month():
    def build():
        since = (datetime.date.today() - datetime.timedelta(days=30)).isoformat()
        base = (f"FROM notice n LEFT JOIN agency g USING (agency_id) WHERE coalesce(n.published, date(n.first_seen)) >= '{since}' "
                "AND coalesce(n.relevance, 0) >= 50 AND coalesce(n.notice_type, '') != 'award' AND coalesce(n.country, g.country, 'US') IN ('US', 'CA')")
        try:
            total = (db.bq(f"SELECT count(*) n {base}", one=True) or {"n": 0})["n"]
            cats = [dict(r) for r in db.bq(f"SELECT n.category, count(*) n {base} GROUP BY n.category ORDER BY n DESC")]
            states = [dict(r) for r in db.bq(f"SELECT g.state_prov, count(*) n {base} AND g.state_prov IS NOT NULL GROUP BY g.state_prov ORDER BY n DESC LIMIT 15")]
            recent = [dict(r) for r in db.bq(f"SELECT n.title, coalesce(g.agency, n.buyer) agency, g.state_prov, n.category, "
                                             f"coalesce(n.published, date(n.first_seen)) published, n.closing {base} ORDER BY published DESC LIMIT 20")]
        except Exception as e:
            log.warning("bid roundup failed: %s", e)
            total, cats, states, recent = 0, [], [], []
        return {"since": since, "total": total, "cats": cats, "states": states, "recent": recent}
    return _cached("bids", build)


def data_day():
    try:
        return time.strftime("%Y-%m-%d", time.gmtime(os.path.getmtime(config.FLEET_DB)))
    except OSError:
        return ""


def bids_day():
    try:
        return time.strftime("%Y-%m-%d", time.gmtime(os.path.getmtime(config.BIDS_DB)))
    except OSError:
        return ""


def code_day():
    """When the public page templates or copy last changed (the deploy), for pages without a data date of their own."""
    here = os.path.dirname(os.path.abspath(__file__))
    paths = [os.path.join(here, f) for f in ("content.py", "compare.py", "claims.py")]
    tdir = os.path.join(here, "templates", "public")
    paths += [os.path.join(tdir, f) for f in os.listdir(tdir)] if os.path.isdir(tdir) else []
    ts = [os.path.getmtime(p) for p in paths if os.path.exists(p)]
    return time.strftime("%Y-%m-%d", time.gmtime(max(ts))) if ts else ""


# ---------- sitemap ----------

def sitemap_urls():
    """[(path, priority, lastmod)] for every public page; the sitemap, IndexNow and the feed all read this."""
    code, fleet, bids = code_day(), data_day(), bids_day()
    pages = db.q("SELECT slug, kind, updated FROM page WHERE published = 1")
    blog = max([(p["updated"] or "")[:10] for p in pages if p["kind"] == "post"] or [code])
    urls = [("/", "1.0", max(code, bids)), ("/pricing", "0.9", code), ("/compare", "0.9", code), ("/coverage", "0.8", fleet),
            ("/solutions", "0.8", code), ("/rail", "0.8", code), ("/data", "0.8", max(fleet, bids)), ("/blog", "0.6", blog),
            ("/contact", "0.4", code), ("/signup", "0.6", code)]
    urls += [(f"/data/{k}", "0.8", bids if k == "rail-bids-this-month" else fleet) for k in DATA_PAGES]
    urls += [(f"/compare/{k}", "0.8", code) for k in compare.all_items()]
    urls += [(f"/solutions/{k}", "0.8", code) for k in content.solutions()]
    urls += [(f"/p/{p['slug']}", "0.6", (p["updated"] or "")[:10]) for p in pages]
    urls += [(f"/operators/{k}", "0.7", fleet) for k in data.operator_slugs()]
    return urls


# ---------- IndexNow ----------

def indexnow_key():
    s = db.settings()
    key = s.get("indexnow_key", "")
    if not key:
        key = secrets.token_hex(16)
        db.set_setting("indexnow_key", key)
    return key


def indexnow_allowed():
    """Only the production site pings: never staging, localhost or plain http."""
    host = urlparse(config.SITE_URL).hostname or ""
    return (config.SITE_URL.startswith("https://") and "." in host and not host.startswith(("staging.", "localhost"))
            and db.settings().get("indexnow_on", "1") == "1")


def indexnow_run(force=False):
    """Submit the URLs whose lastmod changed since the last ping (all of them on the first run). Returns a status line."""
    if not indexnow_allowed():
        return "IndexNow is off for this site."
    s = db.settings()
    try:
        seen = json.loads(s.get("indexnow_seen") or "{}")
    except ValueError:
        seen = {}
    urls = sitemap_urls()
    changed = [u for u, _, mod in urls if force or seen.get(u) != (mod or "-")]
    if not changed:
        status = f"{_now()}: nothing changed since the last ping"
        db.set_setting("indexnow_status", status)
        return status
    host = urlparse(config.SITE_URL).hostname
    key = indexnow_key()
    sent = 0
    for i in range(0, len(changed), 10000):
        batch = changed[i:i + 10000]
        body = json.dumps({"host": host, "key": key, "keyLocation": f"{config.SITE_URL}/{key}.txt",
                           "urlList": [config.SITE_URL + u for u in batch]}).encode()
        req = urllib.request.Request("https://api.indexnow.org/indexnow", data=body, method="POST",
                                     headers={"Content-Type": "application/json; charset=utf-8"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                code = r.status
        except urllib.error.HTTPError as e:
            code = e.code
        except Exception as e:
            status = f"{_now()}: ping failed ({type(e).__name__})"
            db.set_setting("indexnow_status", status)
            return status
        if code not in (200, 202):
            status = f"{_now()}: IndexNow answered {code}"
            db.set_setting("indexnow_status", status)
            return status
        sent += len(batch)
    seen.update({u: (mod or "-") for u, _, mod in urls})
    db.set_setting("indexnow_seen", json.dumps(seen))
    status = f"{_now()}: sent {sent} changed URL{'s' if sent != 1 else ''}"
    db.set_setting("indexnow_status", status)
    log.info("IndexNow %s", status)
    return status


def _now():
    return datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")


def start():
    """Ping 10 minutes after start-up (so a deploy's changes go out), then once a day."""
    def loop():
        time.sleep(600)
        while True:
            try:
                indexnow_run()
            except Exception as e:
                log.error("IndexNow run failed: %s", e)
            try:
                from . import promo
                if promo.due():
                    log.info(promo.generate())
            except Exception as e:
                log.error("Monthly report failed: %s", e)
            time.sleep(86400)
    threading.Thread(target=loop, daemon=True).start()


# ---------- RSS ----------

def feed_items():
    """Guides and data pages, newest first: (title, path, date, description)."""
    items = [(p["title"], f"/p/{p['slug']}", (p["updated"] or "")[:10], p["description"] or "")
             for p in db.q("SELECT slug, title, description, updated FROM page WHERE published = 1 AND kind = 'post'")]
    for k, v in DATA_PAGES.items():
        items.append((v["title"], f"/data/{k}", bids_day() if k == "rail-bids-this-month" else data_day(), v["description"]))
    return sorted(items, key=lambda i: i[2], reverse=True)


def feed_xml(site):
    from email.utils import format_datetime
    from xml.sax.saxutils import escape

    def rfc(d):
        try:
            return format_datetime(datetime.datetime.fromisoformat(d).replace(tzinfo=datetime.timezone.utc))
        except ValueError:
            return ""
    body = "".join(f"<item><title>{escape(t)}</title><link>{config.SITE_URL}{p}</link><guid>{config.SITE_URL}{p}#{hashlib.md5(d.encode()).hexdigest()[:8]}</guid>"
                   + (f"<pubDate>{rfc(d)}</pubDate>" if d else "") + f"<description>{escape(desc)}</description></item>"
                   for t, p, d, desc in feed_items())
    return (f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel>'
            f"<title>{escape(site)}: rail fleet data and guides</title><link>{config.SITE_URL}/</link>"
            f'<atom:link href="{config.SITE_URL}/feed.xml" rel="self" type="application/rss+xml"/>'
            f"<description>Guides and monthly data on US and Canadian passenger rail fleets and rail procurement.</description>"
            f"<language>en-us</language>{body}</channel></rss>")
