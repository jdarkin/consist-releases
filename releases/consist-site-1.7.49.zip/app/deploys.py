"""Builds and deploys (Admin > Builds and deploys, Justin 11-12): what is running on production and staging and when it went in.

consist-stage.sh, consist-promote.sh, bids-stage.sh and bids-promote.sh append one JSON line per run to deploys.jsonl next to
fleet.db on the server (/opt/fleet-db-docker/data, seen here as /fleetdata). Each line:
  {"t": "2026-11-12T14:30:00Z", "kind": "site" | "bids", "env": "staging" | "production" | "check", "name": "consist-site-1.7.37.zip",
   "version": "1.7.37", "sha": "<sha256 of the zip>", "image": "sha256:...", "image_created": "...", "ok": true, "note": "..."}
The page reads that file. 1.7.49: it also reads deploy-state.json (written by consist-deploy on the server: zips that came
from the consist-releases GitHub repo and whether each is staged) and can ask for a promote by writing a signed request
to deploy-requests/; consist-deploy on the server checks the HMAC (DEPLOY_REQUEST_KEY, production .env only) and runs it."""
import datetime
import hashlib
import hmac
import json
import os
import re
import time
import uuid

from . import config

LOG = os.environ.get("DEPLOY_LOG") or os.path.join(os.path.dirname(config.FLEET_DB), "deploys.jsonl")
KINDS = {"site": "Website (consist-site)", "bids": "Bid Catcher"}
ENVS = {"production": "Production", "staging": "Staging", "check": "Checked (bids-stage)", "download": "Downloaded from GitHub", "request": "Promote request"}


def read(limit=500):
    """Deploy records, newest first. Bad lines are skipped."""
    out = []
    try:
        with open(LOG, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if isinstance(r, dict) and r.get("kind") and r.get("t"):
                    out.append(r)
    except OSError:
        return []
    out.sort(key=lambda r: str(r.get("t")), reverse=True)
    return out[:limit]


def current(rows):
    """(kind, env) -> the latest successful record, i.e. what is in place there now."""
    cur = {}
    for r in rows:
        if r.get("ok") is False:
            continue
        cur.setdefault((r.get("kind"), r.get("env")), r)
    return cur


def last_try(rows):
    """(kind, env) -> the latest record whatever its result (to flag a failed promote after a good one)."""
    out = {}
    for r in rows:
        out.setdefault((r.get("kind"), r.get("env")), r)
    return out


def _mtime(path):
    try:
        return datetime.datetime.fromtimestamp(os.path.getmtime(path), datetime.timezone.utc).isoformat(timespec="seconds")
    except OSError:
        return None


def running():
    """Facts about the copy serving this page."""
    from . import syslog
    started = datetime.datetime.fromtimestamp(syslog.STARTED, datetime.timezone.utc).isoformat(timespec="seconds")
    return {"version": config.VERSION, "env": "staging" if os.environ.get("STAGING") == "1" else "production", "started": started,
            "fleet_db": _mtime(config.FLEET_DB), "bids_db": _mtime(config.BIDS_DB), "log": LOG, "log_found": os.path.exists(LOG)}


FLEETDATA = os.path.dirname(LOG)
STATE = os.path.join(FLEETDATA, "deploy-state.json")
REQ_DIR = os.path.join(FLEETDATA, "deploy-requests")


def releases():
    """Zips the server downloaded from GitHub, newest first: name, kind, staged, status, downloaded (epoch)."""
    try:
        with open(STATE, encoding="utf-8") as fh:
            rows = json.load(fh).get("releases") or []
        out = [r for r in rows if isinstance(r, dict) and r.get("name")]
        for r in out:
            try:
                r["downloaded_iso"] = datetime.datetime.fromtimestamp(int(r.get("downloaded")), datetime.timezone.utc).isoformat(timespec="seconds")
            except (TypeError, ValueError, OSError):
                r["downloaded_iso"] = None
        return out
    except (OSError, ValueError):
        return []


def pending():
    """Names with a promote request still waiting for the server to pick it up."""
    out = set()
    try:
        for f in os.listdir(REQ_DIR):
            try:
                with open(os.path.join(REQ_DIR, f), encoding="utf-8") as fh:
                    out.add(json.load(fh).get("name"))
            except (OSError, ValueError):
                pass
    except OSError:
        pass
    return out


def can_request():
    """Only production holds DEPLOY_REQUEST_KEY; staging shows the list without buttons."""
    return bool(os.environ.get("DEPLOY_REQUEST_KEY")) and os.environ.get("STAGING") != "1"


def request_promote(name, user_email):
    """Write a signed promote request. Returns an error message, or '' when queued."""
    key = os.environ.get("DEPLOY_REQUEST_KEY") or ""
    if not can_request():
        return "Promote requests can only be made from production."
    if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", name or ""):
        return "That isn't a release name."
    rel = {r["name"]: r for r in releases()}.get(name)
    if not rel or not rel.get("staged"):
        return "That release hasn't been staged on the server."
    t = int(time.time())
    user = re.sub(r"[|\s]", "", user_email or "admin")
    sig = hmac.new(key.encode(), f"promote|{name}|{t}|{user}".encode(), hashlib.sha256).hexdigest()
    try:
        os.makedirs(REQ_DIR, exist_ok=True)
        tmp = os.path.join(REQ_DIR, f".{uuid.uuid4().hex}.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"action": "promote", "name": name, "t": t, "user": user, "sig": sig}, fh)
        os.replace(tmp, os.path.join(REQ_DIR, f"{t}-{uuid.uuid4().hex[:8]}.json"))
    except OSError as e:
        return f"Couldn't write the request ({e.strerror})."
    return ""


def view():
    rows = read()
    return {"rows": rows, "cur": current(rows), "last": last_try(rows), "run": running(), "KINDS": KINDS, "ENVS": ENVS,
            "releases": releases(), "pending": pending(), "can_request": can_request()}


def _et_offset(d):
    """US Eastern offset for a UTC time (EDT from 2 AM on the 2nd Sunday of March to 2 AM on the 1st Sunday of November);
    worked out here because the slim image has no time zone database."""
    y = d.year
    mar = datetime.datetime(y, 3, 8 + (6 - datetime.date(y, 3, 8).weekday()) % 7, 7, tzinfo=datetime.timezone.utc)
    nov = datetime.datetime(y, 11, 1 + (6 - datetime.date(y, 11, 1).weekday()) % 7, 6, tzinfo=datetime.timezone.utc)
    return -4 if mar <= d < nov else -5


def et(t):
    """'Nov 12, 2026 9:30 AM ET' from an ISO UTC time."""
    if not t:
        return "—"
    try:
        d = datetime.datetime.fromisoformat(str(t).replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=datetime.timezone.utc)
        d = d.astimezone(datetime.timezone.utc)
        return (d + datetime.timedelta(hours=_et_offset(d))).strftime("%b %-d, %Y %-I:%M %p ET")
    except Exception:
        return str(t)
