"""Agency coverage (1.7.48, Bids thread contract fleet-db/bids/coverage-data-contract.md): which agencies Bid Catcher follows
and how, from bids.db agency_coverage (bids-push27, rebuilt daily). The member page (/app/coverage, gated like Bids, filtered by
the sales territory) shows status, channels in plain words, last posting, open bids and 90-day notices, with no scraper
internals (no URLs, errors, account status, last_email or pages_blocked). The admin view (/admin/coverage) shows everything plus
page_watch, meeting_source, news_source, registration and run_log. A missing table reads as empty."""
import datetime

from . import data, lens

STATUS = {"live": ("Live", "ok", "Read automatically and working"),
          "email": ("Email alerts", "brand", "Notices arrive through the agency's bidding portal alert emails"),
          "limited": ("Limited", "warn", "The agency's site blocks automated readers and no alerts arrive yet; we're arranging alerts or permission"),
          "pending": ("Pending", "accent", "A bidding portal account is waiting for the agency's approval"),
          "none": ("Not yet covered", "", "No working channel yet")}
STATUS_ORDER = ["live", "email", "limited", "pending", "none"]
CHANNEL_WORDS = {"agency page": "its procurement page", "board meetings": "board meetings", "documents": "board and budget documents",
                 "portal alerts": "bidding portal alerts", "SAM.gov": "SAM.gov"}


def _rows():
    return data._bq_safe("SELECT * FROM agency_coverage ORDER BY agency")


def _days_ago(ts):
    if not ts:
        return None
    try:
        d = datetime.date.fromisoformat(str(ts)[:10])
    except ValueError:
        return None
    return (datetime.date.today() - d).days


def ago(ts):
    n = _days_ago(ts)
    if n is None:
        return "—"
    return "today" if n <= 0 else "yesterday" if n == 1 else f"{n} days ago"


def channels(v):
    """'agency page;open data (SEAO)' -> 'its procurement page and open data (SEAO)'."""
    words = [CHANNEL_WORDS.get(c.strip(), c.strip()) for c in (v or "").split(";") if c.strip()]
    if not words:
        return ""
    return words[0] if len(words) == 1 else ", ".join(words[:-1]) + " and " + words[-1]


def _ops(r):
    return [x for x in (r.get("fleet_operator_ids") or "").split(";") if x]


def member_view(f):
    """Rows for members (territory and filters applied) and the summary tiles."""
    sc = lens.current()
    rows = []
    for r in _rows():
        if sc.territory and not sc.in_territory(_ops(r), r.get("agency_id")):
            continue
        if sc.regions and (r.get("country") or "") not in sc.regions:
            continue
        rows.append(r)
    allrows = rows
    st = f.get("status")
    if st in STATUS:
        rows = [r for r in rows if (r.get("status") or "none") == st]
    if f.get("q"):
        rows = [r for r in rows if data.qhit([w for w in f["q"].lower().split() if w], r.get("agency"), r.get("state_prov"), r.get("agency_id"))]
    out = []
    for r in rows:
        s = r.get("status") or "none"
        ops = _ops(r)
        out.append({"agency_id": r["agency_id"], "agency": r.get("agency") or r["agency_id"], "where": (r.get("state_prov") or "").replace(";", ", ").replace("/", ", "),
                    "country": r.get("country"), "modes": (r.get("rail_modes") or "").replace(";", ", "), "status": s,
                    "status_label": STATUS.get(s, (s,))[0], "status_cls": STATUS.get(s, ("", ""))[1], "status_tip": STATUS.get(s, ("", "", ""))[2],
                    "how": channels(r.get("channels")), "last_posting": r.get("last_posting"), "posting_ago": ago(r.get("last_posting")),
                    "open_bids": r.get("open_bids") or 0, "notices_90d": r.get("notices_90d") or 0, "checked_ago": ago(r.get("last_checked")),
                    "quiet": bool(r.get("quiet")), "days_since": r.get("days_since_posting"),
                    "gap": round(r["usual_gap_days"]) if r.get("usual_gap_days") else None,
                    "href": f"/app/operators/{ops[0]}" if ops else f"/app/bids?agency={r['agency_id']}&status=all"})
    order = {k: i for i, k in enumerate(STATUS_ORDER)}
    out.sort(key=lambda r: (order.get(r["status"], 9), r["agency"].lower()))
    tiles = {"covered": sum(1 for r in allrows if r.get("status") in ("live", "email")),
             "limited": sum(1 for r in allrows if r.get("status") in ("limited", "pending")),
             "open_bids": sum(r.get("open_bids") or 0 for r in allrows),
             "new_30d": sum(r.get("notices_30d") or 0 for r in allrows),
             "total": len(allrows)}
    counts = {k: sum(1 for r in allrows if (r.get("status") or "none") == k) for k in STATUS_ORDER}
    updated = max((r.get("updated") or "" for r in allrows), default="")
    return out, tiles, counts, updated


def admin_view(f):
    rows = _rows()
    counts = {k: sum(1 for r in rows if (r.get("status") or "none") == k) for k in STATUS_ORDER}
    n_quiet = sum(1 for r in rows if r.get("quiet"))
    n_blocked = sum(1 for r in rows if (r.get("pages_blocked") or 0) > 0)
    if f.get("status") in STATUS:
        rows = [r for r in rows if (r.get("status") or "none") == f["status"]]
    if f.get("quiet") == "1":
        rows = [r for r in rows if r.get("quiet")]
    if f.get("blocked") == "1":
        rows = [r for r in rows if (r.get("pages_blocked") or 0) > 0]
    pages = {}
    for p in data._bq_safe("SELECT url, agency_id, kind, last_checked, last_changed, last_error FROM page_watch ORDER BY url"):
        pages.setdefault(p["agency_id"], []).append(p)
    meets = {}
    for m in data._bq_safe("SELECT url, agency_id, platform, active, last_checked, last_error, meetings FROM meeting_source ORDER BY url"):
        meets.setdefault(m["agency_id"], []).append(m)
    for r in rows:
        r["status_label"], r["status_cls"] = STATUS.get(r.get("status") or "none", (r.get("status"), ""))[:2]
        r["page_list"] = pages.get(r["agency_id"], [])
        r["meet_list"] = meets.get(r["agency_id"], [])
    news = data._bq_safe("SELECT name, url, kind, active, last_checked, last_error, items FROM news_source ORDER BY (last_error IS NULL), name")
    regs = data._bq_safe("SELECT account_key, platform, agencies, status, updated, notes FROM registration ORDER BY status, platform")
    runs = data._bq_safe("SELECT r.* FROM run_log r JOIN (SELECT task, max(id) id FROM run_log GROUP BY task) m ON m.id = r.id ORDER BY r.task")
    updated = max((r.get("updated") or "" for r in rows), default="")
    return {"rows": rows, "counts": counts, "n_quiet": n_quiet, "n_blocked": n_blocked, "news": news, "regs": regs, "runs": runs,
            "updated": updated, "have": bool(rows) or any(counts.values())}
