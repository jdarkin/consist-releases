"""Consist web app: public site, member app (/app), admin portal (/admin). Run: uvicorn app.main:app"""
import datetime
import html
import json
import logging
import os
import re

import markdown as md
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.gzip import GZipMiddleware

from . import award_analyst, alerts, auth, charts, claims, compare, config, content, data, db, glossary, guide, intel, lens, maint, twofa

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

HERE = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
from . import pages as _pages  # noqa: E402
app.add_middleware(_pages.PageGateMiddleware)  # innermost (before gzip): page access per plan, previews trimmed (app/pages.py)
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(lens.ScopeMiddleware)  # inside the session middleware below, so it can read the session
app.add_middleware(maint.MaintenanceMiddleware)  # also inside the session middleware: admins pass, visitors get the maintenance page
from . import usage  # noqa: E402
app.add_middleware(usage.UsageMiddleware)
from . import trial as _trial
app.add_middleware(_trial.TrialGuardMiddleware)  # inside the session middleware: free-trial download block + daily page cap
from . import syslog  # noqa: E402
app.add_middleware(syslog.SyslogMiddleware)  # Admin > Diagnostics: 5xx, 4xx and slow requests; inside the session middleware to know the member  # inside the session middleware too, so it can tell members apart (Admin > Usage)
app.add_middleware(SessionMiddleware, secret_key=config.SECRET_KEY, session_cookie="consist_session", max_age=60 * 60 * 24 * 30,
                   same_site="lax", https_only=config.COOKIE_SECURE)
# Content-Security-Policy (security review 2026-11-02): scripts, styles, fonts and connections only from this site and the services it
# uses (Google Analytics/Tag Manager, Google Fonts, map tiles, Stripe Checkout as a form target). Inline scripts are still allowed
# because templates use them. CSP_MODE=report sends it as Report-Only, CSP_MODE=off drops it (both via .env, for a quick rollback).
CSP = ("default-src 'self'; "
       "script-src 'self' 'unsafe-inline' https://www.googletagmanager.com https://*.googletagmanager.com https://snap.licdn.com https://challenges.cloudflare.com; "
       "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src 'self' data: https://fonts.gstatic.com; "
       "img-src 'self' data: blob: https:; "
       "connect-src 'self' https://*.google-analytics.com https://*.analytics.google.com https://*.googletagmanager.com https://www.google.com https://*.doubleclick.net https://*.linkedin.com https://*.ads.linkedin.com; "
       "frame-src 'self' https://www.googletagmanager.com https://challenges.cloudflare.com; "
       "form-action 'self' https://checkout.stripe.com https://billing.stripe.com; "
       "frame-ancestors 'none'; base-uri 'self'; object-src 'none'")


class SecurityHeaders:
    def __init__(self, app):
        self.app = app
        mode = os.environ.get("CSP_MODE", "enforce").lower()
        self.header = None if mode == "off" else (b"content-security-policy-report-only" if mode == "report" else b"content-security-policy")

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not self.header:
            return await self.app(scope, receive, send)

        async def add(msg):
            if msg["type"] == "http.response.start":
                msg = {**msg, "headers": list(msg.get("headers", [])) + [(self.header, CSP.encode())]}
            await send(msg)
        return await self.app(scope, receive, add)


app.add_middleware(SecurityHeaders)


class ChartRequest:
    """Gives charts.py this request's query string, for the per-chart period pickers (?rcN=YYYY-YYYY)."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            from urllib.parse import parse_qsl
            charts.begin(parse_qsl(scope.get("query_string", b"").decode("latin-1")))
        await self.app(scope, receive, send)


app.add_middleware(ChartRequest)


class HeadAsGet:
    """Answer HEAD like GET without the body (FastAPI routes are GET-only; crawlers and link checkers send HEAD)."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] != "HEAD":
            return await self.app(scope, receive, send)

        async def no_body(msg):
            if msg["type"] == "http.response.body":
                msg = {**msg, "body": b""}
            await send(msg)
        await self.app({**scope, "method": "GET"}, receive, no_body)


app.add_middleware(HeadAsGet)
app.mount("/static", StaticFiles(directory=os.path.join(HERE, "static")), name="static")


def _asset_v():
    """Cache-busting version for app.js and site.css: a hash of both files, so every deploy that changes them is fetched fresh."""
    import hashlib
    h = hashlib.sha256()
    for f in ("js/app.js", "css/site.css"):
        try:
            h.update(open(os.path.join(HERE, "static", f), "rb").read())
        except OSError:
            pass
    return h.hexdigest()[:10]
templates = Jinja2Templates(directory=os.path.join(HERE, "templates"))
templates.env.globals["page_access"] = lambda plan, path: _pages.access(plan, path)
templates.env.globals["PAGE_LIST"] = _pages.PAGES
templates.env.globals["page_gated"] = _pages.gated
templates.env.globals["referral_info"] = lambda u: __import__("app.referrals", fromlist=["info"]).info(u)
templates.env.globals["feature_access"] = _pages.feature_access
templates.env.globals["plus"] = __import__("app.claims", fromlist=["plus"]).plus
T = templates.env


# ---------- template helpers ----------

def money(v, digits=0, cur="$"):
    if v is None or v == "":
        return "—"
    v = float(v)
    if abs(v) >= 1e9:
        return f"{cur}{v / 1e9:.1f}B"
    if abs(v) >= 1e6:
        return f"{cur}{v / 1e6:.1f}M"
    if abs(v) >= 1e4:
        return f"{cur}{v / 1e3:.0f}k"
    return f"{cur}{v:,.{digits}f}"


def big(v):
    """138,392,897 -> 138.4M (headline tiles)."""
    if v is None:
        return "—"
    v = float(v)
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(v) >= div:
            return f"{v / div:.1f}".rstrip("0").rstrip(".") + suf
    return f"{v:,.0f}"


def num(v, digits=0):
    if v is None or v == "":
        return "—"
    return f"{float(v):,.{digits}f}"


def pct(v):
    if v is None:
        return "—"
    return f"{'+' if v > 0 else ''}{v:.0f}%"


def nicetime(s):
    """'Oct 27, 2026 10:30 UTC' from an ISO UTC timestamp."""
    if not s:
        return "—"
    try:
        d = datetime.datetime.fromisoformat(str(s)[:19])
    except ValueError:
        return s
    return d.strftime("%b %-d, %Y %H:%M") + " UTC"


def nicedate(s):
    if not s:
        return "—"
    try:
        return datetime.date.fromisoformat(str(s)[:10]).strftime("%b %-d, %Y")
    except ValueError:
        return s


def days_until(s):
    if not s:
        return None
    try:
        return (datetime.date.fromisoformat(str(s)[:10]) - datetime.date.today()).days
    except ValueError:
        return None


def markdown(text):
    return md.markdown(html.escape(text or "").replace("&gt;", ">"), extensions=["tables", "sane_lists"])


def clip(text, n=155):
    """Meta description text cut to n characters at a sentence or word boundary (search results show about 155)."""
    text = text.striptags() if hasattr(text, "striptags") else " ".join(str(text or "").split())  # block output is Markup: unescape once
    if len(text) <= n:
        return text
    cut = text[:n]
    end = cut.rfind(". ")
    if end > n * 0.6:
        return cut[:end + 1]
    return cut[:cut.rfind(" ")].rstrip(",;:") + "…"


def cents(v):
    return f"${v / 100:,.0f}" if v else "$0"


def weburl(u):
    """Only http(s) links from scraped or researched data reach an href; anything else (javascript:, data:) becomes '#'."""
    u = (str(u) if u else "").strip()
    return u if re.match(r"(?i)^https?://", u) else ("#" if u else "")


T.filters.update(weburl=weburl, big=big, claims=claims.fill, money=money, num=num, pct=pct, nicedate=nicedate, nicetime=nicetime, days_until=days_until, markdown=markdown, cents=cents, clip=clip,
                 mode=lambda m: data.MODES.get(m, m or "—"), cls=data.cls_label,
                 cat=lambda c: data.CATEGORIES.get(c, (c or "—").replace("_", " ")),
                 subsys=lambda s: data.SUBSYSTEMS.get(s, (s or "").replace("_", " ")),
                 overhaul=lambda s: data.OVERHAULS.get(s, (s or "").replace("_", " ")),
                 fromjson=lambda s: json.loads(s) if s else None, slug=data.slug)
def ld(obj):
    """JSON-LD script tag (escaped so text can't close the script)."""
    from markupsafe import Markup
    return Markup('<script type="application/ld+json">' + json.dumps(obj).replace("</", "<\\/") + "</script>")


def ld_faq(faqs):
    return ld({"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in faqs]})


def ld_crumbs(items):
    return ld({"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, "item": config.SITE_URL + u} for i, (n, u) in enumerate(items)]})


def admin_counts():
    r = dict(db.q("SELECT (SELECT count(*) FROM lead WHERE status = 'new') leads, (SELECT count(*) FROM source_request WHERE status = 'new') requests, "
                  "(SELECT count(*) FROM feature_request WHERE status = 'new') ideas", one=True) or {})
    try:
        from . import seosuggest
        r["seo"] = seosuggest.counts().get("pending", 0)
    except Exception:
        r["seo"] = 0
    return r


def plans_with(feature):
    """Names of the active plans that include a feature, cheapest first: what a lock tag shows. 'ai' means plans with analyst
    questions; 'lens:<feature>' means the feature for every market (a plan with lens_all as well)."""
    out = []
    for p in sorted(db.plans(), key=lambda p: (p.get("contact_only") or 0, p.get("price_month") or 0, p.get("sort") or 0)):
        f = set(p.get("features") or [])
        if feature == "ai":
            ok = (p.get("ai_quota") or 0) > 0 and p["id"] != "free"
        elif feature.startswith("lens:"):
            ok = feature[5:] in f and "lens_all" in f
        elif feature.startswith("page:"):  # a page in full (app/pages.py)
            ok = _pages.access(p, feature[5:]) == "full" and p["id"] != "free"
        else:
            ok = feature in f
        if ok:
            out.append((p.get("name") or p["id"]).replace("_", " "))
    return out


ANALYTICS_RE = re.compile(r"^(G|GTM)-[A-Z0-9]{4,12}$")
TRACKED = ("/pricing", "/data", "/coverage", "/operators/", "/solutions", "/compare", "/p/", "/blog", "/contact", "/signup")


def analytics_id(path, user, s):
    """The GA4 measurement ID (G-...) or Tag Manager container (GTM-...) for this page, or None: public marketing pages only,
    never the app, admin, account, token links or admins."""
    aid = (s or {}).get("analytics_id", "").strip().upper()
    if not ANALYTICS_RE.match(aid) or (user and user.is_admin):
        return None
    return aid if path in ("/", "/rail") or path.startswith(TRACKED) else None  # /rail exactly: /rail/... is the member portal


LI_PARTNER_RE = re.compile(r"^[0-9]{3,12}$")


def linkedin_tag(path, user, s):
    """1.7.41 LinkedIn Insight Tag partner ID for this page, or None. Same pages as analytics_id (public marketing pages only, never
    the app, admin, account or admins), and only when Admin > Settings > Analytics has it switched on with a numeric Partner ID.
    The page loads it only after the visitor clicks Accept on the cookie banner (and never with Global Privacy Control on)."""
    s = s or {}
    pid = (s.get("linkedin_partner_id") or "").strip()
    if s.get("linkedin_tag_on") != "1" or not LI_PARTNER_RE.match(pid) or (user and user.is_admin):
        return None
    return pid if path in ("/", "/rail") or path.startswith(TRACKED) else None


T.globals.update(dual_role=lambda oid=None, mode=None: data.dual_role(oid, mode), spec_link=lambda mf, md: __import__('app.specs', fromlist=['link']).link(mf, md), si_link=lambda n: __import__('app.supplierintel', fromlist=['link']).link(n), vlink=data.vendor_href, blink=data.builder_href, ohlink=data.overhaul_href, analytics_id=analytics_id, linkedin_tag=linkedin_tag, plans_with=plans_with, admin_counts=admin_counts, compare_items=compare.all_items, ld=ld, ld_faq=ld_faq, ld_crumbs=ld_crumbs, charts=charts, nx2=lambda name, *a: getattr(__import__('app.nexgen2', fromlist=[name]), name)(*a), nx_tag_list=__import__('app.nexgen', fromlist=['TAG_RX']).TAG_RX if config.NX_FEATURES else [], nx_tags=lambda n: __import__('app.nexgen', fromlist=['bid_tags']).bid_tags(n), nx_stage=lambda fid, full=False: __import__('app.nexgen', fromlist=['stage_pill']).stage_pill(fid, full), MODES=data.MODES, CLASSES=data.CLASSES, CATEGORIES=data.CATEGORIES, SUBSYSTEMS=data.SUBSYSTEMS,
                 OVERHAULS=data.OVERHAULS, FEATURE_LABELS=db.FEATURE_LABELS, EVENT_LABELS=intel.EVENT_LABELS, SIGNALS=intel.SIGNALS, sig_href=intel.sig_href, poll_status=data.poll_status, STAGES=award_analyst.STAGES, OFFERINGS=intel.OFFERINGS, PLAN_TYPES=intel.PLAN_TYPES, CONTRACT_KINDS=intel.CONTRACT_KINDS, COMPONENTS=intel.COMPONENTS, FIELD_LABELS=intel.FIELD_LABELS, SITE_URL=config.SITE_URL, now=datetime.date.today,
                 LENSES=lens.LENSES, REGIONS=lens.REGIONS, FREIGHT_PUBLIC=config.FREIGHT_PUBLIC, PERSONAS=lens.PERSONAS, CATEGORY_LABELS=lens.CATEGORY_LABELS, LENS_BLURBS=lens.LENS_BLURBS, SOLUTIONS=content.SOLUTIONS, PLAN_QUIPS=content.PLAN_QUIPS, FREIGHT_HOME=content.FREIGHT_HOME, freight_cards=content.freight_cards, TWOFA_MODES=twofa.MODES, twofa_on_site=twofa.available, plan_line=db.plan_line, guide_sections=guide.sections, guide_tour=guide.tour_steps, guide_admin=guide.admin_rows, plans_all=lambda: db.plans(active_only=False), ASSET_V=_asset_v(), scope=lens.current, NEXGEN=config.NEXGEN, NX_FEATURES=config.NX_FEATURES, VERSION=config.VERSION, TECH=__import__('app.trainctl', fromlist=['TECH']).TECH, CONF=__import__('app.trainctl', fromlist=['CONF']).CONF)


def render(request: Request, name, status=200, **ctx):
    s = db.settings()
    u = ctx.pop("user", None) or auth.current_user(request)
    aud = "members" if u else "public"
    ann = db.q("SELECT * FROM announcement WHERE active = 1 AND audience IN ('all', ?) ORDER BY id DESC LIMIT 1", (aud,), one=True)
    base = dict(request=request, user=u, s=s, site=s.get("site_name", "Consist"), csrf=auth.csrf_token(request),
                path=request.url.path, announcement=ann, canonical=config.SITE_URL + request.url.path, flash=request.session.pop("flash", None))
    base.update(LENSES=lens.lenses(), PERSONAS=lens.personas(), SOLUTIONS=content.solutions(),  # without freight while it is parked
                MODES=data.MODES if lens.current().freight else {k: v for k, v in data.MODES.items() if k != "FR"})
    rail = lens.in_rail()  # the R-1 and locomotive pages are shared by /admin, /app and the /rail portal
    base.update(rail=rail, r1b="/rail/r1" if rail else "/admin/freight", frb="/rail/locomotives" if rail else "/app/freight",
                rail_open=s.get("rail_open") == "1")
    if u and getattr(u, "get", None):
        from . import nexgen
        try:
            base.update(user_personas=intel.personas_for(u), user_is_agency=nexgen.is_agency(u))
        except Exception:  # never let the nav helpers break a page
            pass
    base.update(ctx)
    resp = templates.TemplateResponse(request, name, base, status_code=status)
    if status == 200 and request.method == "GET" and not request.url.path.startswith(("/admin", "/app")):
        try:  # approved SEO suggestions (Admin > SEO suggestions) replace the page's title, description and H1
            from . import seosuggest
            ov = seosuggest.overrides_for(request.url.path)
            if ov:
                body = seosuggest.apply(resp.body.decode("utf-8"), ov).encode("utf-8")
                resp.body = body
                resp.headers["content-length"] = str(len(body))
        except Exception:
            pass
    return resp


def flash(request: Request, msg, kind="ok"):
    request.session["flash"] = {"msg": msg, "kind": kind}


def redirect(url):
    return RedirectResponse(url, status_code=303)


# ---------- errors ----------

@app.exception_handler(StarletteHTTPException)
async def http_error(request: Request, exc: StarletteHTTPException):
    if exc.status_code in (301, 302, 303) and exc.headers and "Location" in exc.headers:
        return RedirectResponse(exc.headers["Location"], status_code=303)
    if request.url.path.startswith(("/api/", "/app/analyst/job")):
        from fastapi.responses import JSONResponse
        return JSONResponse({"error": exc.detail}, status_code=exc.status_code)
    msg = exc.detail if exc.status_code != 404 else "We couldn't find that page."
    return render(request, "public/error.html", status=exc.status_code, code=exc.status_code, message=msg)


@app.on_event("startup")
def startup():
    db.init()
    usage.ensure()
    syslog.ensure()
    syslog.install_logging()
    from . import referrals
    referrals.ensure()
    referrals.start()  # daily: referral rewards after the hold (app/referrals.py)
    from . import nexgen
    nexgen.ensure()
    from . import nexgen2
    nexgen2.ensure()
    from . import intel
    intel.init()
    if config.ADMIN_EMAIL and config.ADMIN_PASSWORD and not db.q("SELECT 1 FROM user WHERE email = ?", (config.ADMIN_EMAIL.lower(),), one=True):
        auth.create_user(config.ADMIN_EMAIL, config.ADMIN_PASSWORD, name="Admin", role="admin", plan_id="team")
        db.x("UPDATE user SET sub_status = 'manual' WHERE email = ?", (config.ADMIN_EMAIL.lower(),))
        db.audit("bootstrap_admin", config.ADMIN_EMAIL)
    from . import content
    content.seed_pages()
    alerts.start()
    from . import seo
    seo.start()  # IndexNow pings (production domain only)
    from . import promo
    promo.start()  # LinkedIn auto-poster (production domain only, Admin > Social posts)
    __import__('app.supplier_news', fromlist=['start']).start()  # keep viewed news pages fresh (production only)
    import threading
    from . import freightai
    threading.Thread(target=freightai.warm, daemon=True).start()  # build the AI analyst's freight database ahead of the first question


@app.get("/glossary.json")
def glossary_json():
    """Definitions for column headings and report-card labels (static/js/app.js turns them into hover cards)."""
    from fastapi.responses import Response
    return Response(glossary.as_json(), media_type="application/json", headers={"Cache-Control": "public, max-age=3600"})


@app.get("/healthz")
def healthz():
    """Public liveness check. It no longer names the databases (security review 2026-11-02); a missing fleet or bids database is a 503."""
    from fastapi.responses import JSONResponse
    ok = all(os.path.exists(p) for p in (config.FLEET_DB, config.BIDS_DB))
    return JSONResponse({"ok": ok}, status_code=200 if ok else 503)


@app.get("/.well-known/security.txt")
def security_txt():
    """RFC 9116 contact for security reports, from Admin > Settings (security email, else the support email)."""
    from fastapi.responses import PlainTextResponse
    s = db.settings()
    em = (s.get("security_email") or s.get("support_email") or "").strip()
    if not em:
        raise HTTPException(404)
    exp = (datetime.datetime.utcnow() + datetime.timedelta(days=180)).strftime("%Y-%m-%dT00:00:00Z")
    return PlainTextResponse(f"Contact: mailto:{em}\nExpires: {exp}\nPreferred-Languages: en\nCanonical: {config.SITE_URL}/.well-known/security.txt\n")


from . import routes_public, routes_twofa, routes_app, routes_admin, routes_intel, routes_market, routes_freight, routes_r1, routes_rail, routes_shortline, routes_escalation, routes_rd, routes_supplierintel, routes_fundprog, routes_nexgen, routes_nexgen2  # noqa: E402  (routes import render/flash from here)

app.include_router(routes_public.router)
app.include_router(routes_twofa.router)
app.include_router(routes_market.router)
app.include_router(routes_shortline.router)
app.include_router(routes_escalation.rail)
app.include_router(routes_rd.router)
app.include_router(routes_supplierintel.app)
app.include_router(routes_supplierintel.rail)
app.include_router(routes_supplierintel.admin)
app.include_router(routes_escalation.app)
app.include_router(routes_fundprog.app)
app.include_router(routes_fundprog.rail)
app.include_router(routes_rail.router)
app.include_router(routes_rail.moved)  # also redirects the old /app/freight and /admin/freight URLs into /rail
app.include_router(routes_nexgen.app)
app.include_router(routes_nexgen.admin)
app.include_router(routes_nexgen2.app)
app.include_router(routes_nexgen2.api)
app.include_router(routes_intel.router)
app.include_router(routes_app.router)
app.include_router(routes_admin.router)
from . import referrals as _referrals  # noqa: E402
app.include_router(_referrals.public)
app.include_router(_referrals.member)
app.include_router(_referrals.admin)
