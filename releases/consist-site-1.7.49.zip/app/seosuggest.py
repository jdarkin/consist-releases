"""SEO suggestions queue (1.7): rule-based title / meta description / H1 suggestions from the weekly Search Console report,
approved in Admin > SEO suggestions, and a page override store the site applies to live pages without a deploy.

Tables (app.db, created here on first use; nothing else is touched):
  seo_suggestion  one row per suggestion: pending -> approved / rejected; an approved row can be reverted.
  seo_override    the live value per (path, field); render() swaps it into <title>, the meta description (and the og: copies)
                  and the first <h1> of that page.

Import (weekly job on the VPS):  docker exec -i -w /srv consist-site python -m app.cli seo-import -   < suggestions.json
  JSON: [{"url_path": "/operators/mbta", "field": "title" | "meta_description" | "h1", "proposed": "...", "reason": "...",
          "current": "..." (optional)}]
Duplicates of a pending row (same path, field and proposed text) are skipped; a newer suggestion for the same path and field
replaces the older pending one."""
import glob
import html
import json
import os
import re
import time

from . import db

FIELDS = {"title": "Title tag", "meta_description": "Meta description", "h1": "Page heading (H1)"}
MAXLEN = {"title": 120, "meta_description": 320, "h1": 160}
REPORTS_DIR = os.environ.get("SEO_REPORTS_DIR", "/seo-reports")

_ready = False


def ensure():
    global _ready
    if _ready:
        return
    c = db.connect()
    try:
        c.executescript("""
CREATE TABLE IF NOT EXISTS seo_suggestion (id INTEGER PRIMARY KEY, created TEXT, url_path TEXT NOT NULL, field TEXT NOT NULL,
  current TEXT, proposed TEXT NOT NULL, reason TEXT, status TEXT DEFAULT 'pending', applied_at TEXT, previous_value TEXT,
  decided_by TEXT, decided_at TEXT, source TEXT);
CREATE INDEX IF NOT EXISTS seo_suggestion_status ON seo_suggestion (status, created);
CREATE TABLE IF NOT EXISTS seo_override (url_path TEXT NOT NULL, field TEXT NOT NULL, value TEXT NOT NULL, updated TEXT,
  suggestion_id INTEGER, PRIMARY KEY (url_path, field));
""")
        c.commit()
    finally:
        c.close()
    _ready = True
    _seed()


SEEDS = [("seo_seed_20261107", "seo_suggestions_2026-11-07.json")]


def _seed():
    """One-time batches shipped with a package: each adds pending rows once (flag in settings) and never changes anything live."""
    here = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed")
    for flag, fn in SEEDS:
        try:
            if db.q("SELECT 1 FROM setting WHERE key = ?", (flag,), one=True):
                continue
            with open(os.path.join(here, fn), encoding="utf-8") as fh:
                items = json.load(fh)
            added, skipped, _err = import_items(items, source="seed")
            db.set_setting(flag, f"{added} added, {skipped} skipped")
        except Exception:
            pass


def norm_path(p):
    p = (p or "").strip()
    p = re.sub(r"^https?://[^/]+", "", p).split("?")[0].split("#")[0]
    if not p.startswith("/"):
        p = "/" + p
    return p.rstrip("/") or "/"


def _clean(v, field):
    v = re.sub(r"\s+", " ", str(v or "")).strip()
    return v[:MAXLEN.get(field, 300)]


# ---------- overrides (read on every public page view; cached) ----------

_cache = {"at": 0.0, "map": {}}
TTL = 60


def overrides_for(path):
    if time.time() - _cache["at"] > TTL:
        try:
            ensure()
            m = {}
            for r in db.q("SELECT url_path, field, value FROM seo_override"):
                m.setdefault(r["url_path"], {})[r["field"]] = r["value"]
            _cache.update(at=time.time(), map=m)
        except Exception:
            _cache["at"] = time.time()
    return _cache["map"].get(norm_path(path))


def _invalidate():
    _cache["at"] = 0.0


_TITLE = re.compile(r"(<title>)(.*?)(</title>)", re.S)
_H1 = re.compile(r"(<h1\b[^>]*>)(.*?)(</h1>)", re.S)


def _meta(name_attr, name):
    return re.compile(r'(<meta ' + name_attr + r'="' + re.escape(name) + r'" content=")([^"]*)(")')


def apply(body, ov):
    """Swap the override values into a rendered page."""
    if not ov:
        return body
    if ov.get("title"):
        t = html.escape(ov["title"], quote=True)
        body = _TITLE.sub(lambda m: m.group(1) + t + m.group(3), body, count=1)
        body = _meta("property", "og:title").sub(lambda m: m.group(1) + t + m.group(3), body, count=1)
    if ov.get("meta_description"):
        d = html.escape(ov["meta_description"], quote=True)
        for rx in (_meta("name", "description"), _meta("property", "og:description")):
            body = rx.sub(lambda m: m.group(1) + d + m.group(3), body, count=1)
    if ov.get("h1"):
        h = html.escape(ov["h1"], quote=False)
        body = _H1.sub(lambda m: m.group(1) + h + m.group(3), body, count=1)
    return body


def current_values(body):
    """The live title, meta description and H1 of a rendered page, as plain text."""
    def first(rx):
        m = rx.search(body or "")
        return html.unescape(re.sub(r"<[^>]+>", "", m.group(2))).strip() if m else None
    return {"title": first(_TITLE), "meta_description": first(_meta("name", "description")), "h1": first(_H1)}


# ---------- queue ----------

def import_items(items, source="weekly"):
    """Load suggestions. Returns (added, skipped, errors)."""
    ensure()
    added = skipped = 0
    errors = []
    for i, it in enumerate(items if isinstance(items, list) else []):
        if not isinstance(it, dict):
            errors.append(f"item {i}: not an object")
            continue
        field = (it.get("field") or "").strip()
        path = norm_path(it.get("url_path"))
        proposed = _clean(it.get("proposed"), field)
        if field not in FIELDS or not proposed or not it.get("url_path"):
            errors.append(f"item {i}: needs url_path, field ({', '.join(FIELDS)}) and proposed")
            continue
        if db.q("SELECT 1 FROM seo_suggestion WHERE status = 'pending' AND url_path = ? AND field = ? AND proposed = ?",
                (path, field, proposed), one=True):
            skipped += 1
            continue
        live = db.q("SELECT value FROM seo_override WHERE url_path = ? AND field = ?", (path, field), one=True)
        if live and live["value"] == proposed:
            skipped += 1
            continue
        db.x("UPDATE seo_suggestion SET status = 'superseded', decided_at = ?, decided_by = 'import' "
             "WHERE status = 'pending' AND url_path = ? AND field = ?", (db.now(), path, field))
        db.x("INSERT INTO seo_suggestion (created, url_path, field, current, proposed, reason, status, source) VALUES (?,?,?,?,?,?, 'pending', ?)",
             (db.now(), path, field, _clean(it.get("current"), field) or None, proposed, str(it.get("reason") or "")[:2000], source))
        added += 1
    return added, skipped, errors


def listing(status="pending", limit=300):
    ensure()
    if status == "all":
        rows = db.q("SELECT * FROM seo_suggestion ORDER BY id DESC LIMIT ?", (limit,))
    else:
        rows = db.q("SELECT * FROM seo_suggestion WHERE status = ? ORDER BY id DESC LIMIT ?", (status, limit))
    return [dict(r) for r in rows]


def counts():
    ensure()
    out = {r["status"]: r["n"] for r in db.q("SELECT status, count(*) n FROM seo_suggestion GROUP BY 1")}
    out["live"] = (db.q("SELECT count(*) n FROM seo_override", one=True) or {"n": 0})["n"]
    return out


def get(sid):
    ensure()
    r = db.q("SELECT * FROM seo_suggestion WHERE id = ?", (sid,), one=True)
    return dict(r) if r else None


def approve(sid, who, text=None):
    s = get(sid)
    if not s or s["status"] != "pending":
        return None
    value = _clean(text, s["field"]) if text is not None and text.strip() else s["proposed"]
    prev = db.q("SELECT value FROM seo_override WHERE url_path = ? AND field = ?", (s["url_path"], s["field"]), one=True)
    now = db.now()
    db.x("INSERT INTO seo_override (url_path, field, value, updated, suggestion_id) VALUES (?,?,?,?,?) "
         "ON CONFLICT (url_path, field) DO UPDATE SET value = excluded.value, updated = excluded.updated, suggestion_id = excluded.suggestion_id",
         (s["url_path"], s["field"], value, now, sid))
    # an earlier approved row for the same page and field is no longer the live one
    db.x("UPDATE seo_suggestion SET status = 'replaced' WHERE status = 'approved' AND url_path = ? AND field = ? AND id != ?",
         (s["url_path"], s["field"], sid))
    db.x("UPDATE seo_suggestion SET status = 'approved', proposed = ?, applied_at = ?, previous_value = ?, decided_by = ?, decided_at = ? WHERE id = ?",
         (value, now, prev["value"] if prev else None, who, now, sid))
    _invalidate()
    return value


def reject(sid, who):
    s = get(sid)
    if not s or s["status"] != "pending":
        return False
    db.x("UPDATE seo_suggestion SET status = 'rejected', decided_by = ?, decided_at = ? WHERE id = ?", (who, db.now(), sid))
    return True


def revert(sid, who):
    """Put back what the page showed before this suggestion: the earlier override, or the page's own default."""
    s = get(sid)
    if not s or s["status"] != "approved":
        return False
    if s["previous_value"]:
        db.x("UPDATE seo_override SET value = ?, updated = ?, suggestion_id = NULL WHERE url_path = ? AND field = ?",
             (s["previous_value"], db.now(), s["url_path"], s["field"]))
    else:
        db.x("DELETE FROM seo_override WHERE url_path = ? AND field = ?", (s["url_path"], s["field"]))
    db.x("UPDATE seo_suggestion SET status = 'reverted', decided_by = ?, decided_at = ? WHERE id = ?", (who, db.now(), sid))
    _invalidate()
    return True


def live_overrides():
    ensure()
    return [dict(r) for r in db.q("SELECT * FROM seo_override ORDER BY url_path, field")]


# ---------- weekly report (read-only mount) ----------

def latest_report():
    """The newest seo-YYYY-MM-DD.md and seo-YYYY-MM-DD.suggestions.json in the mounted reports folder."""
    out = {"dir": REPORTS_DIR, "report_name": None, "report_md": None, "suggestions_name": None, "suggestions": None}
    if not os.path.isdir(REPORTS_DIR):
        out["error"] = "reports folder not mounted"
        return out
    mds = sorted(p for p in glob.glob(os.path.join(REPORTS_DIR, "seo-*.md")))
    sj = sorted(glob.glob(os.path.join(REPORTS_DIR, "seo-*.suggestions.json")))
    if mds:
        out["report_name"] = os.path.basename(mds[-1])
        with open(mds[-1], encoding="utf-8", errors="replace") as fh:
            out["report_md"] = fh.read(2_000_000)
    if sj:
        out["suggestions_name"] = os.path.basename(sj[-1])
        try:
            with open(sj[-1], encoding="utf-8") as fh:
                out["suggestions"] = json.load(fh)
        except (OSError, ValueError) as e:
            out["suggestions_error"] = str(e)[:200]
    return out
