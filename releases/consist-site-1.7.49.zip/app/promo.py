"""Automatic monthly promotion: a data-driven guide ("Rail fleet report, <Month YYYY>") published to /p/ and the RSS feed, plus
ready-to-post LinkedIn drafts that link back with ?ref=linkedin (Admin > Site usage counts those visits).

Runs from the seo background loop once a day; it does nothing until the 2nd of the month (so the monthly data refresh on the 1st
lands first) and only once per month. Admin > Social posts shows the drafts, regenerates a month and turns the job off."""
import datetime
import logging

from . import config, db, seo

log = logging.getLogger("promo")

SCHEMA = """CREATE TABLE IF NOT EXISTS social_draft (id INTEGER PRIMARY KEY, month TEXT, channel TEXT, body TEXT, url TEXT,
  created TEXT, posted TEXT)"""


def _init():
    db.x(SCHEMA)
    for col in ("post_url TEXT",   # link to the live LinkedIn post when LinkedIn gives one
                "kind TEXT",       # 'monthly' (from the report) or 'spotlight' (weekly operator post)
                "ref TEXT",        # spotlight: the operator_id, so an operator isn't featured twice in a year
                "scheduled TEXT",  # UTC time the auto-poster sends it
                "attempts INTEGER DEFAULT 0", "error TEXT",
                "image TEXT"):     # chart posts: socialimg chart key; the webhook gets its PNG address as image_url
        try:
            db.x(f"ALTER TABLE social_draft ADD COLUMN {col}")
        except Exception:
            pass


def slug_for(month):
    return f"rail-fleet-report-{month}"


def _label(month):
    return datetime.date.fromisoformat(month + "-01").strftime("%B %Y")


def _stats():
    """The numbers the report and posts quote, all from the same public queries as the /data pages."""
    y = datetime.date.today().year
    due = seo.midlife_due()
    nxt = [f for f in due if f["midlife_due_year"] == y + 1]
    cars_next = sum(f["qty_active"] or 0 for f in nxt)
    oldest = seo.oldest_fleets()
    bids = seo.bids_month()
    return {"year": y, "due": due, "due_next": nxt, "cars_next": cars_next, "oldest": oldest[:5], "bids": bids}


def _name(f):
    return (f.get("service_name") or f.get("operator_name") or "").split(" / ")[0]


def _fleet(f):
    mfr, model = f.get("manufacturer") or "", f.get("model_name") or "fleet"
    return f"{_name(f)}'s {mfr + ' ' if mfr and not model.lower().startswith(mfr.lower()) else ''}{model}"


def _grouped(fleets):
    """One row per operator and model: an order delivered in several lots shows once with its total cars."""
    out = {}
    for f in fleets:
        k = (f["operator_id"], f.get("manufacturer"), f.get("model_name"))
        if k in out:
            out[k]["qty_active"] = (out[k]["qty_active"] or 0) + (f["qty_active"] or 0)
        else:
            out[k] = dict(f)
    return sorted(out.values(), key=lambda f: -(f["qty_active"] or 0))


def build_report(month):
    """(title, description, markdown body) for a month's report."""
    from . import data as d
    st, label = _stats(), _label(month)
    y = st["year"]
    title = f"Rail fleet report, {label}: overhauls coming due and rail bids"
    lines = [f"Every month {{site}} updates its passenger rail fleet data and counts the rail bids US and Canadian agencies posted. "
             f"Here is what the {label} numbers show."]
    if st["due_next"]:
        lines += ["", f"## {len(st['due_next'])} fleets come due for a midlife overhaul in {y + 1}", "",
                  f"Our estimates put {len(st['due_next'])} passenger rail fleets, {st['cars_next']:,} cars in all, at their midlife overhaul "
                  f"in {y + 1}. The largest:", ""]
        for f in _grouped(st["due_next"])[:5]:
            lines.append(f"- **{_fleet(f)}**, {f['qty_active']:,} cars built {f['build_year'] or 'n/a'}: "
                         f"[{_name(f)}](/operators/{d.slug(f['operator_id'])})")
        lines += ["", f"The full five-year list is on [Rail car midlife overhauls coming due](/data/midlife-overhauls-due)."]
    if st["oldest"]:
        o = st["oldest"][0]
        lines += ["", "## The oldest fleets still in service", "",
                  f"The oldest passenger rail fleet of five or more cars still running is {_fleet(o)}, built in {o['build_year']}. "
                  "The next oldest:", ""]
        for f in st["oldest"][1:5]:
            lines.append(f"- {_fleet(f)}, built {f['build_year']}, {f['qty_active']:,} cars")
        lines += ["", "See the top 50 on [Oldest passenger rail fleets in the US and Canada](/data/oldest-rail-fleets)."]
    b = st["bids"]
    if b["total"]:
        cats = ", ".join(f"{d.CATEGORIES.get(c['category'], c['category'] or 'other').lower()} ({c['n']})" for c in b["cats"][:3])
        states = ", ".join(f"{s['state_prov']} ({s['n']})" for s in b["states"][:3])
        lines += ["", "## Rail bids in the last 30 days", "",
                  f"Agencies posted {b['total']:,} rail-relevant procurement notices in the 30 days to {datetime.date.today():%B %-d}. "
                  f"The busiest categories were {cats}" + (f", and the busiest states and provinces were {states}." if states else ".")]
        lines += ["", "Category and state counts, with recent examples, are on [Rail and transit bids this month](/data/rail-bids-this-month)."]
    lines += ["", "## About these numbers", "",
              "Fleet data start from the FTA National Transit Database and are extended with agency documents and {site} research; "
              "overhaul years are estimates from build or rebuild year, car type and how hard each fleet works. "
              "See [Data and methodology](/p/methodology). You may quote these figures with a link to this page."]
    tail = f"the oldest fleets still in service, and {b['total']:,} rail bids in the last 30 days." if b["total"] else "and the oldest fleets still in service."
    desc = f"{label}: {len(st['due_next'])} US and Canadian passenger rail fleets come due for midlife overhaul in {y + 1}, {tail}"
    return title, desc, "\n".join(lines)


def build_drafts(month, slug):
    """Three LinkedIn posts, each pointing at a different page with ?ref=linkedin."""
    st, label = _stats(), _label(month)
    site = db.settings().get("site_name", "Consist")
    u = lambda path: f"{config.SITE_URL}{path}?ref=linkedin"  # noqa: E731
    out = []
    if st["due_next"]:
        big = _grouped(st["due_next"])[0]
        out.append((f"{len(st['due_next'])} passenger rail fleets in the US and Canada reach their midlife overhaul in {st['year'] + 1}: "
                    f"{st['cars_next']:,} cars that need trucks, HVAC, doors and propulsion work. The biggest is {_fleet(big)} "
                    f"({big['qty_active']:,} cars).\n\nIf you rebuild rail cars or supply the parts, this is next year's pipeline. "
                    f"The full five-year list, free:\n{u('/data/midlife-overhauls-due')}\n\n#rail #transit #procurement", u("/data/midlife-overhauls-due")))
    b = st["bids"]
    if b["total"]:
        top = b["cats"][0] if b["cats"] else None
        from . import data as d
        out.append((f"US and Canadian agencies posted {b['total']:,} rail-relevant bids in the last 30 days"
                    + (f", led by {d.CATEGORIES.get(top['category'], 'other').lower()} ({top['n']})" if top else "") + ".\n\n"
                    f"We count them by category and state every month. See where the work is:\n{u('/data/rail-bids-this-month')}\n\n#rail #transit #RFP",
                    u("/data/rail-bids-this-month")))
    if st["oldest"]:
        o = st["oldest"][0]
        out.append((f"The oldest passenger rail fleet still in regular service in the US and Canada: {_fleet(o)}, built in {o['build_year']}.\n\n"
                    f"Our {label} rail fleet report has the oldest fleets, next year's overhauls and this month's rail bids:\n"
                    f"{u('/p/' + slug)}\n\n#rail #transit #{site.lower()}", u("/p/" + slug)))
    return out


def generate(month=None, force=False):
    """Publish the month's report and its drafts. Returns a status line."""
    _init()
    month = month or datetime.date.today().strftime("%Y-%m")
    slug = slug_for(month)
    exists = db.q("SELECT 1 FROM page WHERE slug = ?", (slug,), one=True)
    if exists and not force:
        return f"The {_label(month)} report already exists."
    site = db.settings().get("site_name", "Consist")
    title, desc, body = build_report(month)
    body = body.replace("{site}", site)
    if exists:
        db.x("UPDATE page SET title = ?, description = ?, body = ?, updated = ? WHERE slug = ?", (title, desc, body, db.now(), slug))
    else:
        db.x("INSERT INTO page (slug, kind, title, description, body, published, updated) VALUES (?, 'post', ?, ?, ?, 1, ?)",
             (slug, title, desc, body, db.now()))
    db.x("DELETE FROM social_draft WHERE month = ? AND posted IS NULL AND coalesce(kind, 'monthly') = 'monthly'", (month,))
    drafts_ = build_drafts(month, slug)
    for text, url in drafts_:
        db.x("INSERT INTO social_draft (month, channel, body, url, created, kind) VALUES (?, 'linkedin', ?, ?, ?, 'monthly')",
             (month, text, url, db.now()))
    schedule_unscheduled()
    db.audit("monthly_report", slug, None, "system")
    try:
        from . import awareness
        awareness.after_report(month)  # monthly member email, when Admin > Social posts has it on
    except Exception as e:
        log.warning("Member email after report failed: %s", e)
    try:
        seo.indexnow_run()
    except Exception as e:
        log.warning("IndexNow after report failed: %s", e)
    return f"Published {title} and {len(drafts_)} LinkedIn drafts."


def due():
    """True on or after the 2nd when this month's report doesn't exist yet and the job is on."""
    if db.settings().get("promo_on", "1") != "1" or datetime.date.today().day < 2:
        return False
    return not db.q("SELECT 1 FROM page WHERE slug = ?", (slug_for(datetime.date.today().strftime("%Y-%m")),), one=True)


def drafts():
    _init()
    return db.q("SELECT * FROM social_draft ORDER BY month DESC, id")


def mark(did, posted, post_url=None):
    _init()
    db.x("UPDATE social_draft SET posted = ?, post_url = ?, error = NULL, attempts = 0 WHERE id = ?", (db.now() if posted else None, post_url, did))


def edit(did, body, when=None):
    """Change a draft's text and, optionally, its date (YYYY-MM-DD; posts at the usual morning time that day)."""
    _init()
    db.x("UPDATE social_draft SET body = ? WHERE id = ? AND posted IS NULL", (body.strip(), did))
    if when:
        d = datetime.date.fromisoformat(when)
        db.x("UPDATE social_draft SET scheduled = ?, attempts = 0, error = NULL WHERE id = ? AND posted IS NULL", (_slot_utc(d, did), did))


def get(did):
    _init()
    return db.q("SELECT * FROM social_draft WHERE id = ?", (did,), one=True)


def delete(did):
    _init()
    db.x("DELETE FROM social_draft WHERE id = ?", (did,))


# ---------- auto-posting ----------
# What LinkedIn's feed rewards for a company page: steady cadence (about one post a week or more, never several a day),
# weekday mornings in the audience's time zone (US rail buyers and suppliers: Tue-Thu, 8-10am Eastern), a first line that
# hooks before "see more" (~140 characters), no more than 3 hashtags, and posts that stand on their own with a number
# people can repeat. So: the monthly drafts are spread out, one per slot, at least two days apart, and when nothing is
# queued for the coming week a weekly operator spotlight fills the gap.

POST_DAYS = (1, 2, 3)        # Tue, Wed, Thu
POST_HOUR_ET = 9             # 9am Eastern, a few minutes past so it isn't on the hour
MIN_GAP_DAYS = 2
TICK_SECONDS = 600


def autopost_on():
    return db.settings().get("promo_autopost", "1") == "1"


def _et_offset(d):
    """Hours from Eastern time to UTC on date d: 4 in daylight time (2nd Sunday of March to 1st Sunday of November), else 5."""
    def nth_sunday(y, m, n):
        first = datetime.date(y, m, 1)
        return first + datetime.timedelta(days=(6 - first.weekday()) % 7 + 7 * (n - 1))
    return 4 if nth_sunday(d.year, 3, 2) <= d < nth_sunday(d.year, 11, 1) else 5


def _slot_utc(d, salt=0):
    minute = 3 + (int(salt or 0) * 7) % 25  # 9:03 to 9:27 Eastern
    t = datetime.datetime(d.year, d.month, d.day, POST_HOUR_ET + _et_offset(d), minute, tzinfo=datetime.timezone.utc)
    return t.isoformat(timespec="seconds")


def _parse(ts):
    t = datetime.datetime.fromisoformat(ts)
    return t if t.tzinfo else t.replace(tzinfo=datetime.timezone.utc)


def _last_taken():
    """The latest day already used by a posted or scheduled LinkedIn draft."""
    r = db.q("SELECT max(x) m FROM (SELECT max(posted) x FROM social_draft WHERE posted IS NOT NULL "
             "UNION ALL SELECT max(scheduled) FROM social_draft WHERE posted IS NULL AND scheduled IS NOT NULL)", one=True)
    return _parse(r["m"]).date() if r and r["m"] else None


def next_slot(salt=0):
    """The next Tue/Wed/Thu morning that is at least MIN_GAP_DAYS after the last used day and still ahead of now."""
    now = datetime.datetime.now(datetime.timezone.utc)
    d = now.date()
    last = _last_taken()
    if last and last + datetime.timedelta(days=MIN_GAP_DAYS) > d:
        d = last + datetime.timedelta(days=MIN_GAP_DAYS)
    for _ in range(30):
        if d.weekday() in POST_DAYS and _parse(_slot_utc(d, salt)) > now + datetime.timedelta(minutes=5):
            return _slot_utc(d, salt)
        d += datetime.timedelta(days=1)
    return _slot_utc(d, salt)


def schedule_unscheduled():
    _init()
    for r in db.q("SELECT id FROM social_draft WHERE posted IS NULL AND scheduled IS NULL ORDER BY id"):
        db.x("UPDATE social_draft SET scheduled = ? WHERE id = ?", (next_slot(r["id"]), r["id"]))


def _spotlight_pick():
    from . import data
    recent = {r["ref"] for r in db.q("SELECT ref FROM social_draft WHERE kind = 'spotlight' AND created > ?",
                                     ((datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=365)).isoformat(timespec="seconds"),))}
    ops = [o for o in data.operator_slugs().values() if (o["cars"] or 0) >= 20 and o["operator_id"] not in recent
           and not (o["category"] or "").startswith("freight")]
    return max(ops, key=lambda o: o["cars"] or 0) if ops else None


def build_spotlight(o):
    """(text, url) for one operator: its fleet in numbers, one forward-looking fact, and a link to its public page."""
    from . import data
    d = data.operator(o["operator_id"])
    fleets = [f for f in d["fleets"] if (f["qty_active"] or 0) > 0]
    name = _name(o)
    builders = []
    for f in sorted(fleets, key=lambda f: -(f["qty_active"] or 0)):
        if f["manufacturer"] and f["manufacturer"] not in builders:
            builders.append(f["manufacturer"])
    by = (f", built by {', '.join(builders[:2])} and {builders[2]}" if len(builders) >= 3 else
          f", built by {' and '.join(builders)}" if builders else "")
    hook = f"{name} runs {o['cars']:,} rail cars in {len(fleets)} fleet{'s' if len(fleets) != 1 else ''}."  # the line before "see more"
    lines = [f"They were built by {by[len(', built by '):]}." if by else ""]
    if o.get("oldest") and o.get("avg_build"):
        lines.append(f"The oldest still in service dates from {o['oldest']}; the average car was built in {int(o['avg_build'])}.")
    lines = [x for x in lines if x]
    y = datetime.date.today().year
    due = sorted([f for f in fleets if f.get("midlife_due_year") and y <= f["midlife_due_year"] <= y + 3],
                 key=lambda f: (f["midlife_due_year"], -(f["qty_active"] or 0)))
    orders = [p for p in (d.get("procurements") or []) if (p["status"] or "").lower() not in ("delivered", "complete", "completed", "cancelled")]
    extra = ""
    if due:
        f = due[0]
        extra = (f"Next up: the {f['manufacturer'] + ' ' if f['manufacturer'] else ''}{f['model_name'] or 'fleet'} cars "
                 f"({f['qty_active']:,}, built {f['build_year']}) reach their midlife overhaul window around {f['midlife_due_year']}.")
    elif orders:
        p = orders[0]
        extra = f"On order: {p['qty_base'] or 'new'} {p['model']} cars{' from ' + p['manufacturer'] if p['manufacturer'] else ''}."
    url = f"{config.SITE_URL}/operators/{data.slug(o['operator_id'])}?ref=linkedin"
    text = "\n\n".join([hook] + ([" ".join(lines)] if lines else []) + ([extra] if extra else []) +
                        [f"Full roster, car orders and recent bids for {name}:\n{url}", "#rail #transit #procurement"])
    return text, url


CHART_ORDER = ("midlife", "bids", "oldest")


def build_chart_post(chart):
    """(text, url) for a weekly chart image post. Image posts reach more people on LinkedIn than link-only posts; the
    number people can repeat goes first, the link to the free /data page last."""
    from . import socialimg
    sub, rows = socialimg.series(chart)
    if not rows:
        return None
    meta = socialimg.CHARTS[chart]
    url = f"{config.SITE_URL}{meta['page']}?ref=linkedin"
    if chart == "midlife":
        peak = max(rows, key=lambda r: r[1])
        hook = f"{peak[2]} passenger rail cars in the US and Canada hit their midlife overhaul window in {peak[0]}."
        body = (f"That's the peak year in our six-year view: {sub}. Midlife work means trucks, HVAC, doors, propulsion "
                "and controls, so this is the pipeline for rebuilders and their suppliers.")
    elif chart == "bids":
        hook = f"{rows[0][0]} led US and Canadian rail bids over the last 30 days, with {rows[0][2]} notices."
        body = f"{sub[0].upper() + sub[1:]}. The categories after it: " + ", ".join(f"{r[0].lower()} ({r[2]})" for r in rows[1:4]) + "."
    else:
        hook = f"The oldest passenger rail fleet still running in the US and Canada is {rows[0][1]} years old."
        body = f"{rows[0][0]} ({rows[0][2].split('(')[-1].rstrip(')')}) leads a list where every fleet is past {rows[-1][1]} years. Built to last, but every year in service adds overhaul and parts risk."
    text = "\n\n".join([hook, body, f"Full list, free, updated monthly:\n{url}", "#rail #transit #procurement"])
    return text, url


def _next_chart():
    last = db.q("SELECT image FROM social_draft WHERE kind = 'chart' ORDER BY id DESC LIMIT 1", one=True)
    i = CHART_ORDER.index(last["image"]) + 1 if last and last["image"] in CHART_ORDER else 0
    return CHART_ORDER[i % len(CHART_ORDER)]


def ensure_chart(now, force=False):
    """Add this week's chart post when none was made in the last 6 days (image rendering needs Pillow; skipped without it)."""
    try:
        import PIL  # noqa: F401
    except ImportError:
        return None
    if not force and db.q("SELECT 1 FROM social_draft WHERE kind = 'chart' AND created >= ?", ((now - datetime.timedelta(days=6)).isoformat(timespec="seconds"),), one=True):
        return None
    start = CHART_ORDER.index(_next_chart())
    for k in range(len(CHART_ORDER)):
        chart = CHART_ORDER[(start + k) % len(CHART_ORDER)]
        built = build_chart_post(chart)
        if built:
            did = db.x("INSERT INTO social_draft (month, channel, body, url, created, kind, image) VALUES (?, 'linkedin', ?, ?, ?, 'chart', ?)",
                       (now.strftime("%Y-%m"), built[0], built[1], db.now(), chart))
            db.x("UPDATE social_draft SET scheduled = ? WHERE id = ?", (next_slot(did), did))
            return did
    return None


def ensure_spotlight():
    """Keep the page active: when nothing is queued for the next 7 days and nothing went out in the last 4, add a post.
    Weekly chart image posts come first (setting promo_charts, default on); operator spotlights fill the other weeks."""
    now = datetime.datetime.now(datetime.timezone.utc)
    soon = db.q("SELECT 1 FROM social_draft WHERE posted IS NULL AND scheduled <= ?", ((now + datetime.timedelta(days=7)).isoformat(timespec="seconds"),), one=True)
    recent = db.q("SELECT 1 FROM social_draft WHERE posted >= ?", ((now - datetime.timedelta(days=4)).isoformat(timespec="seconds"),), one=True)
    if soon or recent:
        return None
    if db.settings().get("promo_charts", "1") == "1":
        did = ensure_chart(now)
        if did:
            return did
    o = _spotlight_pick()
    if not o:
        return None
    text, url = build_spotlight(o)
    did = db.x("INSERT INTO social_draft (month, channel, body, url, created, kind, ref) VALUES (?, 'linkedin', ?, ?, ?, 'spotlight', ?)",
               (now.strftime("%Y-%m"), text, url, db.now(), o["operator_id"]))
    db.x("UPDATE social_draft SET scheduled = ? WHERE id = ?", (next_slot(did), did))
    return did


def tick():
    """One pass of the auto-poster: fill the queue, then send at most one due draft (never two within 20 hours)."""
    from . import linkedin
    if not (autopost_on() and _production()):  # staging and local copies never post
        return
    if not linkedin.status()["connected"]:
        return
    _init()
    schedule_unscheduled()
    ensure_spotlight()
    now = datetime.datetime.now(datetime.timezone.utc)
    if db.q("SELECT 1 FROM social_draft WHERE posted >= ?", ((now - datetime.timedelta(hours=20)).isoformat(timespec="seconds"),), one=True):
        return
    r = db.q("SELECT * FROM social_draft WHERE posted IS NULL AND scheduled <= ? AND coalesce(attempts, 0) < 3 ORDER BY scheduled LIMIT 1",
             (now.isoformat(timespec="seconds"),), one=True)
    if not r:
        return
    try:
        link = linkedin.post(r["body"], r["url"], r["month"], image_url=image_url(r))
        mark(r["id"], True, link or None)
        db.audit("linkedin_autopost", link or f"draft {r['id']}", None, "system")
    except Exception as e:
        db.x("UPDATE social_draft SET attempts = coalesce(attempts, 0) + 1, error = ? WHERE id = ?", (str(e)[:300], r["id"]))
        log.warning("LinkedIn auto-post failed: %s", e)


def image_url(r):
    """Public PNG address for a chart draft ('' for text posts)."""
    from . import socialimg
    return socialimg.url(r["image"], "linkedin") if r and r["image"] in socialimg.CHARTS else ""


def _production():
    from urllib.parse import urlparse
    host = urlparse(config.SITE_URL).hostname or ""
    return config.SITE_URL.startswith("https://") and "." in host and not host.startswith(("staging.", "localhost"))


def start():
    import threading
    import time

    def loop():
        time.sleep(120)
        while True:
            try:
                tick()
            except Exception as e:
                log.error("Auto-post tick failed: %s", e)
            time.sleep(TICK_SECONDS)
    threading.Thread(target=loop, daemon=True).start()


def et_label(ts):
    """'Thu Nov 5, 9:10am ET' for the admin list."""
    if not ts:
        return ""
    t = _parse(ts)
    local = t - datetime.timedelta(hours=_et_offset(t.date()))
    return local.strftime("%a %b %-d, %-I:%M%p").replace("AM", "am").replace("PM", "pm") + " ET"
