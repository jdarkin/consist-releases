"""bid-monitor: watches rail procurement for rail market bids (vehicles first), emails alerts, and keeps an awards inventory.

Usage:
  bidmon daemon                       run on the schedule below (the bid-monitor container's command)
  bidmon scan [--only mail,canadabuys,seao,pages] [--no-notify]
  bidmon awards [--since YYYY-MM-DD] [--dry-run]
  bidmon notify [--digest daily|weekly]
  bidmon test-email [ADDRESS]
  bidmon status
  bidmon coverage                     are the login-gated portals' alert emails arriving?
  bidmon checklist [--email] [--checked URL [--note TEXT]]   pages that refuse automated reading, to check by hand
  bidmon history [--check]            3-year backfill from open data (no Claude calls, no alerts)
  bidmon retag                        add subsystem tags (taxonomy.py) to every notice and award; the site's filters follow
  bidmon federal [--years N]          federal rail contract history (USAspending), into awards
  bidmon meetings [--load FILE] [--agency ID] [--no-docs]   board meetings, agendas and their rail items (no Claude)
  bidmon permissions [--seed] [--send-now] [--replies]          permission requests (normally run from Consist Admin)
  bidmon init                         create/refresh bids.db from portals.csv
  bidmon award-portals [--agency ID] [--all] [--backfill] [--report]   award / closed-solicitation pages per agency
  bidmon rescore [--max-usd N] [--notify]   re-score every notice with the current rules (old notices are not emailed unless --notify)

Schedule (container time zone): mailbox every BIDS_MAIL_MINUTES (15); open data and agency pages daily at
BIDS_SCAN_TIME (06:15); digests at config digest_time (daily) and Mondays (weekly); award research on
BIDS_AWARDS_SCHEDULE ("1st Tue 08:00", monthly). Claude spending is capped by config max_usd_per_day.
A "schedule" block in config.json (saved from Consist Admin > Bid Catcher) overrides these env values; see specs() and caps().
"""
import argparse, datetime, os, sys, time, traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bidcore as bc  # noqa: E402
import notify, relevance, sources  # noqa: E402


def scan(only=None, send=True):
    c = bc.init_db()
    s = bc.settings()
    budget = max(0.0, float(s.get("max_usd_per_day", 2)) - bc.spent_today(c))
    steps = only or ["mail", "canadabuys", "seao", "pages", "feeds"]
    started, found, new, cost, msgs = bc.now(), 0, 0, 0.0, []
    for step in steps:
        try:
            if step == "mail":
                import inbox
                f, n, k = inbox.check(c, budget - cost)
                try:  # agency documents the site queued (off until feeds.upload_feed_key is set)
                    import uploads
                    uf, un = uploads.pull(c)
                    f, n = f + uf, n + un
                except Exception as e:
                    msgs.append(f"uploads: {e}")
            elif step in ("canadabuys", "seao") and not s.get("open_data", True):
                continue
            elif step == "canadabuys":
                (f, n), k = sources.canadabuys(c), 0.0
            elif step == "seao":
                (f, n), k = sources.seao(c), 0.0
            elif step == "pages":
                if not s.get("page_watch", True):
                    continue
                f, n, k = sources.page_watch(c, budget - cost)
            elif step == "feeds":  # official feeds and feeds used with the owner's permission (each off until set in config.json)
                import coverage
                f, n, k = coverage.feeds(c)
            else:
                raise ValueError(f"unknown step {step}")
            found, new, cost = found + f, new + n, cost + k
            msgs.append(f"{step}: {f} seen, {n} new")
        except Exception as e:
            msgs.append(f"{step}: FAILED {e}")
            bc.log(f"scan {step} failed: {e}\n{traceback.format_exc()}")
    cost += relevance.review(c, budget=max(0.0, budget - cost))
    sent = notify.immediate(c) if send else 0
    stuck = c.execute("SELECT account_key, platform FROM registration WHERE status='verify_pending' AND updated >= ?", (started,)).fetchall()
    if stuck and send:
        notify.system(c, "verification needs you", "These accounts sent a verification email the agent could not complete:\n" +
                      "\n".join(f"- {r['platform']} ({r['account_key']})" for r in stuck) + "\nOpen the email in the bids mailbox and click the link.")
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (started, bc.now(), "scan:" + ",".join(steps), "done", found, new, round(cost, 4), "; ".join(msgs) + f"; alerts sent: {sent}"))
    c.commit()
    bc.log(f"scan {','.join(steps)}: " + "; ".join(msgs) + f"; ${cost:.3f}; alerts sent {sent}")
    return new


def rescore(max_usd=5.0, send=False):
    """Re-runs keyword scoring and the Claude review on every notice, e.g. after the relevance rules change."""
    c = bc.init_db()
    started = bc.now()
    if not send:  # the backlog is for the site and digests, not a burst of alert emails
        c.execute("UPDATE notice SET notified=? WHERE notified IS NULL", (started,))
    c.execute("UPDATE notice SET kw_score=NULL, reviewed=NULL")
    c.commit()
    cost = relevance.review(c, budget=max_usd)
    n, rel = c.execute("SELECT count(*), sum(relevance >= 60) FROM notice").fetchone()
    c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
              (started, bc.now(), "rescore", "done", n, 0, round(cost, 4), f"{rel} of {n} notices now at 60+"))
    c.commit()
    print(f"rescored {n} notices, {rel} at 60+, ${cost:.2f}")
    if send:
        print("alerts sent:", notify.immediate(c))


ORD = {"1st": 1, "2nd": 2, "3rd": 3, "4th": 4}


DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def monthly_past(spec, d):
    """True on or after this month's scheduled day and time, so a run missed while the container was down catches up."""
    p = spec.split()
    if len(p) != 3:
        return False
    first = d.replace(day=1)
    day = 1 + (DAYS.index(p[1]) - first.weekday()) % 7 + 7 * (ORD[p[0]] - 1)
    return (d.day, d.strftime("%H:%M")) >= (day, p[2])


def weekly_past(spec, d):
    """True on or after this week's scheduled day and time ("Wed 08:00"); catches up a missed day within the week."""
    p = spec.split()
    return len(p) == 2 and (d.weekday(), d.strftime("%H:%M")) >= (DAYS.index(p[0]), p[1])


def monthly_due(spec, d):
    p = spec.split()
    return len(p) == 3 and d.strftime("%a") == p[1] and (d.day - 1) // 7 + 1 == ORD[p[0]] and d.strftime("%H:%M") >= p[2]


def specs():
    """Schedules, reread every loop so changes saved from the Consist admin apply without a restart."""
    return (bc.opt("mail_minutes", "BIDS_MAIL_MINUTES", "15", int), bc.opt("scan_time", "BIDS_SCAN_TIME", "06:15"),
            bc.opt("awards_schedule", "BIDS_AWARDS_SCHEDULE", "1st Tue 08:00"),
            bc.opt("budgets_schedule", "BIDS_BUDGETS_SCHEDULE", "Sat 08:00"))  # weekly: board documents, capital plans, FTA grants; "" turns it off


def caps():
    """Applies the awards and budgets caps (config.json "schedule", then env) to those modules before a run."""
    import awards, budgets
    awards.MAX_USD = bc.opt("awards_max_usd", "BIDS_AWARDS_MAX_USD", "4", float)
    awards.BATCH = max(1, bc.opt("awards_batch", "BIDS_AWARDS_BATCH", "10", int))
    awards.BATCH_USD = bc.opt("awards_batch_usd", "BIDS_AWARDS_BATCH_USD", "1.0", float)
    budgets.MAX_USD = bc.opt("budgets_max_usd", "BIDS_BUDGETS_MAX_USD", "3", float)
    budgets.DISCOVER_USD = bc.opt("budgets_discover_usd", "BIDS_BUDGETS_DISCOVER_USD", "0.8", float)
    budgets.PER_PAGE = max(1, bc.opt("budgets_docs_per_page", "BIDS_BUDGETS_DOCS_PER_PAGE", "3", int))
    return awards, budgets


ACTIONS = ("retag", "closing_backfill", "federal_history", "coverage", "checklist", "checklist_checked", "rescore", "test_email", "scan", "permission_seed", "permission_enable",
           "permission_replies")


def run_actions(c):
    """Runs the jobs queued from Consist Admin > Bid Catcher (table admin_action), one at a time, keeping their printed output.
    The site can't run bidmon itself (separate container, read-mostly access), so it queues and the daemon executes."""
    import contextlib, io, json
    import coverage, permissions
    permissions.ensure(c)
    for r in c.execute("SELECT * FROM admin_action WHERE status='queued' ORDER BY id").fetchall():
        a, args = r["action"], json.loads(r["args"] or "{}")
        c.execute("UPDATE admin_action SET status='running', started=? WHERE id=?", (bc.now(), r["id"]))
        c.commit()
        out, status = io.StringIO(), "done"
        try:
            with contextlib.redirect_stdout(out):
                if a not in ACTIONS:
                    raise ValueError(f"unknown action {a}")
                if a == "closing_backfill":
                    print("closing dates filled from notice text: %d" % sources.closing_backfill(c))
                elif a == "retag":
                    import taxonomy
                    print("subsystems added to %d notices and %d awards" % taxonomy.retag(c))
                elif a == "federal_history":
                    import federal
                    print("federal contracts: %d seen, %d new" % federal.contracts(c, int(args.get("years", 10))))
                elif a == "coverage":
                    coverage.print_report(c)
                elif a == "checklist":
                    print(coverage.checklist_text(c))
                elif a == "checklist_checked":
                    coverage.mark_checked(c, args["url"], args.get("note") or "nothing new")
                    print("recorded")
                elif a == "rescore":
                    rescore(min(float(args.get("max_usd", 2)), 10.0), False)
                elif a == "test_email":
                    print(notify.test(c, args.get("to") or None))
                elif a == "scan":
                    only = [s for s in (args.get("only") or "").split(",") if s] or None
                    print("new notices:", scan(only, bool(args.get("notify", True))))
                elif a == "permission_seed":
                    print("drafts added:", permissions.seed(c))
                elif a == "permission_enable":
                    permissions.enable(c, int(args["id"]), r["requested_by"] or "admin")
                    print("enabled")
                elif a == "permission_replies":
                    print("replies matched: %d ($%.3f)" % permissions.check_replies(c))
        except Exception as e:
            status = "failed"
            print(f"FAILED: {e}", file=out)
            bc.log(f"admin action {r['id']} {a} failed: {e}\n{traceback.format_exc()}")
        c.execute("UPDATE admin_action SET status=?, finished=?, output=? WHERE id=?", (status, bc.now(), out.getvalue()[-20000:], r["id"]))
        c.commit()


def daemon():
    import taxonomy
    taxonomy.sync(bc.init_db())
    mail_every, scan_time, awards_spec, budgets_spec = specs()
    stamp = os.path.join(bc.DIR, ".stamps")
    os.makedirs(stamp, exist_ok=True)
    def once(name, key):
        p = os.path.join(stamp, name)
        if os.path.exists(p) and open(p).read() == key:
            return False
        open(p, "w").write(key)
        return True
    if not os.path.exists(os.path.join(stamp, "daily")):
        once("daily", datetime.date.today().isoformat())  # first start: mailbox only; the full scan waits for BIDS_SCAN_TIME tomorrow
    bc.log(f"bid-monitor: mailbox every {mail_every} min; daily scan {scan_time}; awards {awards_spec or 'off'}")
    last_mail = 0.0
    while True:
        now = datetime.datetime.now()
        try:
            mail_every, scan_time, awards_spec, budgets_spec = specs()
            mail_cycle = False
            if now.strftime("%H:%M") >= scan_time and once("daily", now.date().isoformat()):
                scan()
                last_mail = time.time()
                mail_cycle = True
                try:  # award and closed-solicitation pages: next batch of agencies, then the backfill allowance
                    import award_portals
                    award_portals.tick(bc.connect(), limit=bc.opt("award_discover_batch", "BIDS_AWARD_DISCOVER_BATCH", "40", int))
                except Exception as e:
                    bc.log(f"award portals failed: {e}\n{traceback.format_exc()}")
            elif time.time() - last_mail >= mail_every * 60:
                last_mail = time.time()
                scan(["mail"])
                mail_cycle = True
            import permissions
            c = bc.connect()
            run_actions(c)
            permissions.tick(c, check_mail=mail_cycle)
            digest_time = bc.settings().get("digest_time", "07:00")
            if now.strftime("%H:%M") >= digest_time and once("digest", now.date().isoformat()):
                c = bc.connect()
                notify.digest(c, "daily")
                if now.strftime("%a") == "Mon":
                    notify.digest(c, "weekly")
                    import coverage
                    notify.system(c, "this week's hand checks", coverage.checklist_text(c))
            if awards_spec and monthly_past(awards_spec, now) and once("awards", now.strftime("%Y-%m")):
                awards, _ = caps()
                c = bc.connect()
                added, cost, summary = awards.run(c)
                notify.system(c, f"monthly awards research: {added} awards added (${cost:.2f})", summary)
            if budgets_spec and weekly_past(budgets_spec, now) and once("budgets", now.strftime("%G-W%V")):
                _, budgets = caps()
                budgets.run(bc.connect(), budgets.MAX_USD, budgets.DISCOVER_USD)
        except Exception as e:
            bc.log(f"daemon error: {e}\n{traceback.format_exc()}")
        time.sleep(30)


def status():
    c = bc.init_db()
    q = lambda sql: c.execute(sql).fetchall()  # noqa: E731
    print("notices:", q("SELECT count(*), sum(relevance>=60) FROM notice")[0][:])
    print("open relevant bids:", q("SELECT count(*) FROM v_open_bids")[0][0])
    print("awards:", q("SELECT count(*), count(DISTINCT vendor_norm) FROM award")[0][:])
    print("registrations:", ", ".join(f"{r[0]} {r[1]}" for r in q("SELECT status, count(*) FROM registration GROUP BY status")))
    for r in q("SELECT started, task, status, new, cost_usd, message FROM run_log ORDER BY id DESC LIMIT 8"):
        print(" ", r["started"], r["task"], r["status"], f"new={r['new']}", f"${r['cost_usd'] or 0:.3f}", (r["message"] or "")[:160])
    print("Claude spend today: $%.3f" % bc.spent_today(c))


def cap_memory():
    """Keep a runaway scan from starving the NAS (2 GB): past BIDS_MAX_MEM_MB the step fails with MemoryError instead."""
    import resource
    mb = int(os.environ.get("BIDS_MAX_MEM_MB", "400"))
    if mb > 0:
        resource.setrlimit(resource.RLIMIT_DATA, (mb << 20, mb << 20))


def main():
    cap_memory()
    ap = argparse.ArgumentParser(prog="bidmon")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("daemon")
    sub.add_parser("status")
    sub.add_parser("init")
    s = sub.add_parser("scan")
    s.add_argument("--only")
    s.add_argument("--no-notify", action="store_true")
    a = sub.add_parser("awards")
    a.add_argument("--since")
    a.add_argument("--dry-run", action="store_true")
    g = sub.add_parser("budgets")
    g.add_argument("--max-usd", type=float)
    g.add_argument("--only", choices=["discover", "watch", "usaspending", "link"])
    g.add_argument("--discover-usd", type=float, help="share of --max-usd for finding agency pages (default BIDS_BUDGETS_DISCOVER_USD)")
    g.add_argument("--per-page", type=int, help="documents read per listing page this run (a backfill uses ~24 for two years of monthly minutes)")
    g.add_argument("--years", type=int, default=3, help="years of FTA grants to pull")
    n = sub.add_parser("notify")
    n.add_argument("--digest", choices=["daily", "weekly"])
    r = sub.add_parser("rescore")
    r.add_argument("--max-usd", type=float, default=5.0)
    r.add_argument("--notify", action="store_true")
    sub.add_parser("coverage", help="alert emails per portal account: are the login-gated portals actually reporting?")
    k = sub.add_parser("checklist", help="pages that refuse automated reading, for a weekly look by hand")
    k.add_argument("--email", action="store_true", help="also email the list to the admin subscribers")
    k.add_argument("--checked", metavar="URL", help="record that URL as checked by hand today")
    k.add_argument("--note", default="nothing new")
    h = sub.add_parser("history", help="3-year backfill from open data (SEAO, CanadaBuys, NY authorities); no Claude calls, no alerts")
    h.add_argument("--years", type=int, default=3)
    h.add_argument("--check", action="store_true", help="count only, write nothing")
    h.add_argument("--only", help="comma list of seao,canadabuys,ny")
    cp = sub.add_parser("contract-pages", help="agency contract/award pages: --load FILE, or check them (no Claude)")
    cp.add_argument("--load")
    cp.add_argument("--prune-dead", action="store_true", help="drop single-document rows that return 404/410 (listing pages are kept)")
    mt = sub.add_parser("meetings", help="board meetings and agenda items (keyword rules, no Claude)")
    mt.add_argument("--load", help="add meeting sources from a CSV (agency_id,platform,url,client,body_hint,notes)")
    mt.add_argument("--agency")
    mt.add_argument("--no-docs", action="store_true", help="calendar only, read no documents")
    mt.add_argument("--max-docs", type=int)
    mt.add_argument("--past-days", type=int, help="read documents of meetings held up to N days ago (default BIDS_MEETINGS_PAST_DAYS, 45)")
    rr = sub.add_parser("robots-retry", help="forget documents once refused by robots.txt so the next runs read them again")
    rr.add_argument("--report", action="store_true", help="counts only, change nothing")
    lp = sub.add_parser("load-past-rfps", help="add researched past solicitations with their awards and bidders (CSV); no alerts, no Claude")
    lp.add_argument("file")
    lr = sub.add_parser("load-research", help="add researched awards from a CSV (skips ones already present)")
    lr.add_argument("file")
    lr.add_argument("--tag", default="research")
    sub.add_parser("closing-backfill", help="fill blank closing dates from the notice text or review summary")
    sub.add_parser("retag", help="tag every notice and award with subsystems from taxonomy.py (adds, never removes)")
    fe = sub.add_parser("federal", help="federal rail contract history from USAspending (no key, no Claude cost)")
    fe.add_argument("--years", type=int, default=10)
    pr = sub.add_parser("permissions", help="permission requests to sites that refuse automated readers")
    pr.add_argument("--seed", action="store_true", help="queue drafts for sites that have none")
    pr.add_argument("--send-now", action="store_true", help="send the next approved request (still paced)")
    pr.add_argument("--replies", action="store_true", help="read the mailbox for replies now")
    oc = sub.add_parser("oncall", help="on-call / IDIQ / task-order contracts: classify, terms, benches, task-order and rebid links (no Claude)")
    oc.add_argument("--backfill", action="store_true", help="re-read every award, notice and agenda item already stored")
    oc.add_argument("--report", action="store_true", help="counts only")
    pf = sub.add_parser("portal-fix", help="change agencies' watched page (portal_url) in data/bids/portals.csv from a CSV of agency_id,portal_url[,note]")
    pf.add_argument("file")
    sub.add_parser("coverage-status", help="rebuild agency_coverage (per-agency status, last posting, quiet flags) and print a summary")
    fu = sub.add_parser("fix-urls", help="repair stored notice/award links that cannot be opened (no https://, bare paths); --report counts only")
    fu.add_argument("--report", action="store_true")
    awp = sub.add_parser("award-portals", help="where each agency posts awards and closed solicitations (no Claude); --backfill reads older award pages as history")
    awp.add_argument("--agency", action="append")
    awp.add_argument("--limit", type=int, default=40)
    awp.add_argument("--all", action="store_true", help="every agency, even ones checked recently")
    awp.add_argument("--backfill", action="store_true")
    awp.add_argument("--max-usd", type=float)
    awp.add_argument("--report", action="store_true")
    awp.add_argument("--reset", action="store_true", help="clear the first award history load (rules/pi rows, review queue, Pi jobs) and read every award link again")
    awd = sub.add_parser("award-docs", help="award documents read free: queue counts, or --load a reviewed CSV (load-past-rfps columns + doc_url)")
    awd.add_argument("--load")
    prt = sub.add_parser("page-retire", help="stop watching pages that refuse automated reading when alerts/RSS already cover the agency (CSV url,agency_id,reason; url ending * = prefix)")
    prt.add_argument("file")
    sub.add_parser("history-audit", help="read-only: past-RFP and award history depth by source, year and agency")
    ca = sub.add_parser("coverage-audit", help="read-only: why 'live' agencies show no notices (channel, page text, notices by source)")
    ca.add_argument("--deep", action="store_true", help="notices by source, recent page-step results, and a test extraction of 4 pages (~$0.10)")
    ea = sub.add_parser("early", help="tag early-stage notices (RFI, sources sought, EOI/LOI, planned) as stage='early'")
    ea.add_argument("--backfill", action="store_true")
    nw = sub.add_parser("news", help="OEM newsrooms and trade press: queue order / contract announcements for the award research")
    nw.add_argument("--check", action="store_true", help="per-source status only")
    nw.add_argument("--load", help="add or update sources from a CSV (name,kind,url,active)")
    fa = sub.add_parser("fix-award", help="set a blank award date on one award, guarded by a word its title must contain")
    fa.add_argument("award_id", type=int)
    fa.add_argument("--date", required=True)
    fa.add_argument("--if-title", required=True)
    tl = sub.add_parser("translate", help="English titles and descriptions for French / Spanish notices (offline models, no API cost)")
    tl.add_argument("--backfill", action="store_true", help="every French / Spanish notice not yet translated (long: run with docker exec -d)")
    tl.add_argument("--limit", type=int)
    tl.add_argument("--test", help="translate this French or Spanish text and print it")
    sub.add_parser("uploads", help="agency solicitation documents queued by the site (off until feeds.upload_feed_key is set)")
    t = sub.add_parser("test-email")
    t.add_argument("address", nargs="?")
    args = ap.parse_args()
    if args.cmd == "daemon":
        daemon()
    elif args.cmd == "status":
        status()
    elif args.cmd == "init":
        import taxonomy
        c = bc.init_db()
        taxonomy.sync(c)
        try:
            import award_portals
            award_portals.seed(c)
        except Exception as e:
            print(f"award portals seed failed: {e}")
        print(f"bids.db ready at {bc.DB}")
    elif args.cmd == "scan":
        scan(args.only.split(",") if args.only else None, not args.no_notify)
    elif args.cmd == "awards":
        awards, _ = caps()
        added, cost, summary = awards.run(bc.init_db(), args.since, args.dry_run)
        print(summary)
    elif args.cmd == "budgets":
        _, budgets = caps()
        c = bc.init_db()
        budgets.ensure(c)
        usd = args.max_usd if args.max_usd is not None else budgets.MAX_USD
        if args.only == "discover":
            print(budgets.discover(c, usd))
        elif args.only == "watch":
            print(budgets.watch(c, usd, args.per_page))
        elif args.only == "usaspending":
            print(budgets.usaspending(c, years=args.years))
        elif args.only == "link":
            budgets.link(c)
        else:
            print(budgets.run(c, usd, args.discover_usd if args.discover_usd is not None else budgets.DISCOVER_USD, args.per_page))
    elif args.cmd == "notify":
        c = bc.init_db()
        print("sent:", notify.digest(c, args.digest) if args.digest else notify.immediate(c))
    elif args.cmd == "rescore":
        rescore(args.max_usd, args.notify)
    elif args.cmd == "coverage":
        import coverage
        coverage.print_report(bc.init_db())
    elif args.cmd == "history":
        import history
        history.run(bc.init_db(), years=args.years, check=args.check, only=args.only.split(",") if args.only else None)
    elif args.cmd == "contract-pages":
        import contract_pages
        c = bc.init_db()
        if args.load:
            print("contract pages added: %d" % contract_pages.load_pages(c, args.load))
        elif args.prune_dead:
            print("dead single-document contract pages removed: %d" % contract_pages.prune_dead(c))
        else:
            print("checked %d, changed %d, unreadable %d" % contract_pages.watch(c))
            print(contract_pages.changed_text(c) or "no changes in the last 7 days")
    elif args.cmd == "oncall":
        import oncall
        c = bc.init_db()
        if not args.report:
            print(oncall.run(c, all_rows=args.backfill))
        print(oncall.report(c))
    elif args.cmd == "portal-fix":
        import csv as _csv, shutil
        live = os.path.join(bc.DIR, "portals.csv")
        if not os.path.exists(live):
            shutil.copy(os.path.join(bc.HERE, "portals.csv"), live)
        fixes = {r["agency_id"].strip(): r for r in _csv.DictReader(open(args.file, newline="", encoding="utf-8-sig")) if (r.get("agency_id") or "").strip()}
        rows = list(_csv.DictReader(open(live, newline="", encoding="utf-8")))
        cols = list(rows[0].keys())
        shutil.copy(live, live + ".bak-" + time.strftime("%Y%m%d%H%M"))
        done = []
        for r in rows:
            f = fixes.get(r["agency_id"])
            if f and f.get("portal_url", "").startswith("http") and r["portal_url"] != f["portal_url"]:
                done.append(f"{r['agency_id']}: {r['portal_url']} -> {f['portal_url']}")
                r["portal_url"] = f["portal_url"]
                if f.get("note"):
                    r["notes"] = ((r.get("notes") or "") + f" | {f['note']}").strip(" |")
        with open(live, "w", newline="", encoding="utf-8") as fh:
            w = _csv.DictWriter(fh, fieldnames=cols)
            w.writeheader()
            w.writerows(rows)
        bc.init_db()
        print(f"portal pages changed: {len(done)}" + "".join("\n  " + d for d in done))
        missing = sorted(set(fixes) - {r["agency_id"] for r in rows})
        if missing:
            print("not in portals.csv: " + ", ".join(missing))
    elif args.cmd == "fix-urls":
        c = bc.init_db()
        portal = {r[0]: r[1] for r in c.execute("SELECT agency_id, portal_url FROM agency WHERE portal_url LIKE 'http%'")}
        for table, idcol, col in (("notice", "notice_id", "url"), ("award", "award_id", "source_url")):
            bad = c.execute(f"SELECT {idcol}, agency_id, source, {col} FROM {table} WHERE {col} IS NOT NULL AND {col} != '' "
                            f"AND lower({col}) NOT LIKE 'http://%' AND lower({col}) NOT LIKE 'https://%'").fetchall()
            fixed = portal_used = cleared = 0
            by_src = {}
            for r in bad:
                by_src[r["source"]] = by_src.get(r["source"], 0) + 1
                new = sources.fix_url(r[col])
                how = "fixed"
                if not new:
                    new, how = portal.get(r["agency_id"]), "portal"
                if args.report:
                    continue
                c.execute(f"UPDATE {table} SET {col}=? WHERE {idcol}=?", (new, r[idcol]))
                if new is None:
                    cleared += 1
                elif how == "portal":
                    portal_used += 1
                else:
                    fixed += 1
            print(f"{table}: {len(bad)} links could not be opened (by source: {by_src})" +
                  ("" if args.report else f"; fixed {fixed}, pointed to the agency portal {portal_used}, cleared {cleared}"))
            for r in bad[:8]:
                print(f"    {r[idcol]} {r['agency_id']} {r['source']}: {str(r[col])[:90]}")
        c.commit()
    elif args.cmd == "award-portals":
        import award_portals
        c = bc.init_db()
        award_portals.ensure(c)
        award_portals.seed(c)
        started = bc.now()
        if args.reset:
            print("award history reset:", award_portals.reset(c))
        if args.report:
            award_portals.report(c)
        else:
            n, f = award_portals.discover(c, agencies=args.agency, limit=999 if args.all else args.limit,
                                          days=0 if (args.all or args.agency) else 60, verbose=True)
            p = fi = nw = 0
            k = 0.0
            if args.backfill:
                p, fi, nw, k = award_portals.backfill(c, args.max_usd, verbose=True)
            msg = f"discover: {n} agencies checked, {f} award links" + (f"; backfill: {p} pages, {fi} award rows, {nw} new, {award_portals.LINKED} awards tied to an RFP" if args.backfill else "")
            c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
                      (started, bc.now(), "award portals", "done", f + fi, nw, k, msg))
            c.commit()
            print(msg + (f" (${k:.2f})" if k else ""))
    elif args.cmd == "award-docs":
        import award_portals
        c = bc.init_db()
        award_portals.ensure_queue(c)
        if args.load:
            print("rows %d, notices added %d, awards added %d" % award_portals.load_review(c, args.load))
        for r in c.execute("SELECT status, count(*), sum(parsed), sum(stored) FROM award_doc GROUP BY status"):
            print(f"{r[0]}: {r[1]} documents, {r[2] or 0} rows by rules, {r[3] or 0} stored")
        print("pi reader:", "linked" if award_portals.pi_on() else "not linked")
    elif args.cmd == "page-retire":
        import contract_pages
        c = bc.init_db()
        print("pages retired:", contract_pages.retire(c, args.file))
    elif args.cmd == "history-audit":
        import coverage_status, meetings
        c = bc.init_db()
        meetings.ensure(c)
        print(coverage_status.history_audit(c))
    elif args.cmd == "coverage-audit":
        import coverage_status
        c = bc.init_db()
        if args.deep:
            print(coverage_status.deep(c))
        else:
            coverage_status.refresh(c)
            print(coverage_status.audit(c))
    elif args.cmd == "coverage-status":
        import coverage_status
        c = bc.init_db()
        coverage_status.refresh(c)
        print(coverage_status.summary(c))
    elif args.cmd == "early":
        import early
        print("early-stage notices tagged: %d" % early.run(bc.init_db(), backfill=args.backfill))
    elif args.cmd == "news":
        import news
        c = bc.init_db()
        if args.load:
            print("news sources added or updated: %d" % news.load_sources(c, args.load))
        elif not args.check:
            print("%d sources read, %d items seen, %d queued" % news.run(c))
        print(news.report(c))
    elif args.cmd == "fix-award":
        c = bc.init_db()
        n = c.execute("UPDATE award SET award_date=? WHERE award_id=? AND award_date IS NULL AND title LIKE ?",
                      (args.date, args.award_id, f"%{args.if_title}%")).rowcount
        c.commit()
        print(f"award {args.award_id}: " + ("date set to " + args.date if n else "unchanged (has a date already, or the title does not match)"))
    elif args.cmd == "translate":
        import translate
        if args.test:
            lang = translate.detect(args.test) or "fr"
            print(f"[{lang}] " + (translate.translate_text(args.test, lang) or ""))
        else:
            print(translate.run(bc.init_db(), backfill=args.backfill, limit=args.limit))
    elif args.cmd == "uploads":
        import uploads
        print("uploads read %d, added %d" % uploads.pull(bc.init_db()) if uploads._key() else "upload feed is off: set feeds.upload_feed_key")
    elif args.cmd == "meetings":
        import meetings
        c = bc.init_db()
        meetings.ensure(c)
        if args.past_days:
            meetings.PAST_DAYS = args.past_days
        if args.load:
            print("meeting sources added: %d" % meetings.load_sources(c, args.load))
        else:
            started = bc.now()
            res = meetings.run(c, agency=args.agency, docs=not args.no_docs, max_docs=args.max_docs)
            msg = "meetings seen %d, documents read %d, rail items %d" % res
            # a hand-started run shows in the run log (Admin) when it finishes
            c.execute("INSERT INTO run_log (started, finished, task, status, found, new, cost_usd, message) VALUES (?,?,?,?,?,?,?,?)",
                      (started, bc.now(), "meetings" + (f" --past-days {args.past_days}" if args.past_days else "") + (f" --agency {args.agency}" if args.agency else ""),
                       "done", res[1], res[2], 0.0, msg))
            c.commit()
            print(msg)
            print(meetings.week_text(c) or "no rail items on agendas this week")
    elif args.cmd == "load-past-rfps":
        import contract_pages
        print("past RFPs: %d rows, %d solicitations added, %d awards added" % contract_pages.load_past_rfps(bc.init_db(), args.file))
    elif args.cmd == "load-research":
        import contract_pages
        print("research awards: %d rows, %d added, %d already present or incomplete" % contract_pages.load_research(bc.init_db(), args.file, args.tag))
    elif args.cmd == "closing-backfill":
        print("closing dates filled from notice text: %d" % sources.closing_backfill(bc.init_db()))
    elif args.cmd == "retag":
        import taxonomy
        print("subsystems added to %d notices and %d awards" % taxonomy.retag(bc.init_db()))
    elif args.cmd == "federal":
        import federal
        print("federal contracts: %d seen, %d new" % federal.contracts(bc.init_db(), args.years))
    elif args.cmd == "robots-retry":
        import meetings, budgets, urllib.parse
        c = bc.init_db()
        meetings.ensure(c)
        budgets.ensure(c)
        for table in ("meeting_doc", "doc_seen"):
            rows = c.execute(f"SELECT url, coalesce(agency_id,'?') a FROM {table} WHERE error LIKE '%robots.txt%'").fetchall()
            hosts = {}
            for r in rows:
                h = urllib.parse.urlparse(r["url"]).netloc
                hosts[h] = hosts.get(h, 0) + 1
            print(f"{table}: {len(rows)} documents refused by robots.txt" + ("" if args.report else ", cleared"))
            for h, n in sorted(hosts.items(), key=lambda x: -x[1])[:25]:
                print(f"  {n:5d}  {h}")
            if not args.report:
                c.execute(f"DELETE FROM {table} WHERE error LIKE '%robots.txt%'")
        if not args.report:
            for table in ("meeting_source", "page_watch", "news_source", "doc_source"):
                try:
                    n = c.execute(f"UPDATE {table} SET last_error=NULL WHERE last_error LIKE '%robots.txt%'").rowcount
                    print(f"{table}: {n} robots errors cleared (re-checked on the next run)")
                except Exception:
                    pass
        c.commit()
    elif args.cmd == "permissions":
        import permissions
        c = bc.init_db()
        permissions.ensure(c)
        if args.seed:
            print("drafts added:", permissions.seed(c))
        if args.send_now:
            print("sent:", permissions.send_approved(c))
        if args.replies:
            print("replies matched: %d ($%.3f)" % permissions.check_replies(c))
        for r in c.execute("SELECT id, status, kind, label, to_addr, sent_at, reply_summary FROM permission_request ORDER BY id"):
            print(f"{r['id']:>3} {r['status']:12} {r['kind']:8} {r['label'][:44]:44} {r['to_addr'] or '(no address)':36} "
                  f"{(r['sent_at'] or '')[:10]} {(r['reply_summary'] or '')[:60]}")
    elif args.cmd == "checklist":
        import coverage
        c = bc.init_db()
        if args.checked:
            coverage.mark_checked(c, args.checked, args.note)
        text = coverage.checklist_text(c)
        print(text)
        if args.email:
            notify.system(c, "this week's hand checks", text)
    elif args.cmd == "test-email":
        print("sent to", notify.test(bc.init_db(), args.address))


if __name__ == "__main__":
    main()
