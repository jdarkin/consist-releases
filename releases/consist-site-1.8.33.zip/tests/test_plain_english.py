"""Simplified Technical English check (1.8.33, Justin 11-28: ASD-STE100 style for app pages, help, lessons, glossary and
emails; not legal or public marketing pages). Run: python tests/test_plain_english.py [--all]

STE rules checked here, in a simple form:
  - a sentence in a lesson step, Help text or first-day task has no more than 25 words (STE: 20 for steps, 25 for
    descriptions; we use 25 for both);
  - no words from the STE "not approved" list below, where a simpler approved word exists.
Lessons (app/learn.py), Help (app/pagehelp.py), the first-day list (app/firstday.py) and the glossary (app/glossary.py)
must pass. Legal pages (terms, privacy) and public marketing pages are out of scope (Justin 11-28)."""
import pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
MAX = 25
# not approved -> approved (ASD-STE100 style)
AVOID = {"utilize": "use", "utilise": "use", "leverage": "use", "facilitate": "help", "commence": "start",
         "prior to": "before", "in order to": "to", "subsequently": "then", "approximately": "about",
         "additional": "more", "numerous": "many", "obtain": "get", "require": "need", "requires": "needs",
         "assist": "help", "ensure": "make sure", "terminate": "stop", "initiate": "start", "via": "through",
         "e.g.": "for example", "i.e.": "that is", "etc.": "and more", "whilst": "while", "in the event that": "if",
         "a number of": "some", "at this point in time": "now", "is able to": "can", "are able to": "can"}
RX = re.compile(r"\b(" + "|".join(re.escape(k) for k in sorted(AVOID, key=len, reverse=True)) + r")(?=\W|$)")  # lower case only: "VIA Rail" is a name

def sentences(t):
    t = re.sub(r"\b(e\.g|i\.e|etc|vs|St|No)\.", lambda m: m.group(0).replace(".", ""), t)
    return [s.strip() for s in re.split(r"(?<=[.!?:;])\s+", t) if s.strip()]

def check(label, text):
    bad = []
    for s in sentences(text):
        n = len(re.findall(r"[A-Za-z0-9][\w'’/-]*", s))
        if n > MAX: bad.append(f"{label}: {n} words: {s[:90]}…")
    for m in RX.finditer(text):
        bad.append(f"{label}: use '{AVOID[m.group(1)]}' not '{m.group(1)}'")
    return bad

def texts(all_=False):
    from app import learn, pagehelp, firstday
    for m in learn.MODULES:
        yield f"lesson {m['slug']} why", m["why"]
        for i, st in enumerate(m["steps"], 1):
            yield f"lesson {m['slug']} step {i} title", st[0]
            yield f"lesson {m['slug']} step {i}", st[1]
    for h, row in pagehelp.PAGES.items():
        yield f"help {h}", row[2]
    for k, v in pagehelp.PLAIN.items():
        yield f"plain term {k}", v
    for k, t, x, h in firstday.TASKS:
        yield f"first day {k}", t + ". " + x
    if True:  # glossary passes since 1.8.33
        from app import glossary
        for k, v in glossary.TERMS.items():
            yield f"glossary {k}", v

def problems(all_=False):
    out = []
    for label, t in texts(all_):
        out += check(label, t)
    return out

def test_plain_english():
    b = problems(); assert not b, "\n".join(b)

if __name__ == "__main__":
    b = problems("--all" in sys.argv); print("\n".join(b) or "OK: plain English"); print(len(b), "items"); sys.exit(1 if b else 0)
