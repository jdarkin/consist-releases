"""Admin > Scheduled jobs (1.8.37): every timed job with its last run and a late flag (app/jobs.py)."""
from fastapi import APIRouter, Depends, Request

from . import auth, jobs

admin = APIRouter(prefix="/admin")
A = Depends(auth.require_admin)


@admin.get("/jobs")
def page(request: Request, u=A):
    from .main import render
    rows = jobs.all_jobs()
    return render(request, "admin/jobs.html", user=u, rows=rows, up=jobs.uptime(),
                  late=sum(1 for r in rows if r["state"] == "late"), failed=sum(1 for r in rows if r["state"] == "failed"),
                  never=sum(1 for r in rows if r["state"] == "never"))
