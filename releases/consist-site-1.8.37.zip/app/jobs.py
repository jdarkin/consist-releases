"""Admin > Scheduled jobs (1.8.37, Megawatch gap audit lesson a4: the Megawatch nightly news job was never in cron and nobody
saw it for weeks). One list of every job that runs on a timer, with its last run and a late flag.

Three kinds of source:
- In-app loops (alerts, DMARC reader, monthly report, auto-post, referrals, news warm) call beat(key) after each pass. The
  time and result go in table job_beat in app.db.
- Host and Pi jobs (nightly backup, off-site pull, Pi reader, uptime check) write files that the site reads: backups.py,
  pistatus.py and uptime.json in the pi-jobs folder.
- The Bid Catcher daemon writes run_log in bids.db: one row per task, newest run per task.

A job is late when its last run is older than its interval plus a grace period. Times are stored in UTC and shown in the
viewer's zone (app/tz.py)."""
import datetime
import json
import os

from . import db

SCHEMA = """CREATE TABLE IF NOT EXISTS job_beat (key TEXT PRIMARY KEY, last_run TEXT, ok INTEGER, note TEXT, runs INTEGER DEFAULT 0,
  fails INTEGER DEFAULT 0, last_ok TEXT);"""

# key: (name, where it runs, expected seconds between runs, what it does)
APP_JOBS = {
    "alerts": ("Alerts and daily checks", "Website", 600,
               "Sends bid and fleet alert emails, territory digests, data QA repairs, the EP 724 check and the monthly RSSI check."),
    "dmarc": ("DMARC report reader", "Website", 6 * 3600, "Reads DMARC reports from admin@ for Admin > Email health."),
    "seo": ("IndexNow and monthly report", "Website", 86400, "Tells search engines about changed pages and makes the monthly report."),
    "promo": ("Social auto-post", "Website", 600, "Posts approved social drafts at their time."),
    "referrals": ("Referral rewards", "Website", 6 * 3600, "Gives referral rewards when a referred member pays."),
    "news": ("Supplier news refresh", "Website", 1800, "Refreshes the supplier news searches."),
}
GRACE = 0.5  # late after interval * 1.5, and at least 15 minutes past the interval
_ready = {"ok": False}


def _init():
    if _ready["ok"]:
        return
    c = db.connect()
    try:
        c.executescript(SCHEMA)
        c.commit()
    finally:
        c.close()
    _ready["ok"] = True


def beat(key, ok=True, note=""):
    """Record one pass of an in-app job. Never raises: a broken log must not stop the job."""
    try:
        _init()
        t = db.now()
        db.x("INSERT INTO job_beat (key, last_run, ok, note, runs, fails, last_ok) VALUES (?, ?, ?, ?, 1, ?, ?) "
             "ON CONFLICT(key) DO UPDATE SET last_run = excluded.last_run, ok = excluded.ok, note = excluded.note, "
             "runs = runs + 1, fails = fails + excluded.fails, last_ok = coalesce(excluded.last_ok, last_ok)",
             (key, t, 1 if ok else 0, (note or "")[:300], 0 if ok else 1, t if ok else None))
    except Exception:
        pass


def _ts(v):
    try:
        t = datetime.datetime.fromisoformat(str(v).strip().replace("Z", "+00:00").replace(" ", "T"))
        return t if t.tzinfo else t.replace(tzinfo=datetime.timezone.utc)
    except (TypeError, ValueError):
        return None


def _every(secs):
    if secs % 86400 == 0:
        d = secs // 86400
        return "every day" if d == 1 else f"every {d} days"
    if secs % 3600 == 0:
        h = secs // 3600
        return "every hour" if h == 1 else f"every {h} hours"
    return f"every {secs // 60} minutes"


def _row(name, where, every, what, last, ok=True, note="", now=None):
    now = now or datetime.datetime.now(datetime.timezone.utc)
    t = _ts(last)
    age = (now - t).total_seconds() if t else None
    limit = every + max(900, every * GRACE)
    if t is None:
        state = "never"
    elif age > limit:
        state = "late"
    elif not ok:
        state = "failed"
    else:
        state = "ok"
    due = (t + datetime.timedelta(seconds=limit)).isoformat() if t else None
    return {"name": name, "where": where, "every": _every(every), "secs": every, "what": what, "last": t.isoformat() if t else None,
            "age": age, "state": state, "note": note or "", "late_after": due}


def _app_rows(now):
    _init()
    got = {r["key"]: r for r in db.q("SELECT * FROM job_beat")}
    out = []
    for k, (name, where, every, what) in APP_JOBS.items():
        r = got.get(k)
        out.append(_row(name, where, every, what, r["last_run"] if r else None, bool(r["ok"]) if r else True,
                        (r["note"] if r and not r["ok"] else ""), now))
    return out


def _host_rows(now):
    out = []
    try:
        from . import backups
        st = backups.status()
        snap = st.get("snap") or {}
        out.append(_row("Nightly backup snapshot", "VPS cron", 86400, "Copies the databases to a dated snapshot on the server.",
                        snap.get("ts"), bool(snap.get("ok", True)), snap.get("error") or "", now))
        lo = st.get("last_ok") or {}
        out.append(_row("Off-site backup pull", "Pi cron", 86400, "The Pi pulls the newest snapshot to its own disk.",
                        lo.get("ts"), True, "", now))
    except Exception as e:
        out.append(_row("Nightly backup snapshot", "VPS cron", 86400, "Backup status could not be read.", None, False, str(e)[:120], now))
    try:
        from . import pistatus
        p = pistatus.status()
        out.append(_row("Pi reader", "Pi cron", 900, "The Pi reads bid documents with its local model.",
                        p.get("seen"), not p.get("failed_today"), p.get("last_error") or "", now))
        u = uptime()
        out.append(_row("Uptime check", "Pi cron", 300, "The Pi opens consist-na.com and megawatch.net and emails admin@ if one is down.",
                        u.get("t"), u.get("ok", True), u.get("problem") or "", now))
    except Exception:
        pass
    return out


def _bid_rows(now):
    try:
        rows = db.bq("SELECT task, max(started) last, (SELECT status FROM run_log r2 WHERE r2.task = r.task ORDER BY id DESC LIMIT 1) status "
                     "FROM run_log r WHERE started >= ? GROUP BY task ORDER BY task",
                     ((now - datetime.timedelta(days=30)).isoformat()[:19],)) or []
    except Exception:
        return []
    out = []
    for r in rows:
        st = str(r["status"] or "").lower()
        out.append(_row(f"Bid Catcher: {r['task']}", "Bid Catcher daemon", 86400, "A Bid Catcher task. It shows late when it did not run for a day.",
                        r["last"], st not in ("error", "failed", "fail"), "" if st not in ("error", "failed", "fail") else "Last run failed. See Admin > Bid Catcher.", now))
    return out


def uptime():
    """The Pi uptime check writes uptime.json into the pi-jobs folder: {"t", "ok", "sites": [{"url", "ok", "code", "ms", "error"}],
    "down_since": {url: t}}. Empty dict when the file is not there yet."""
    try:
        from . import pistatus
        with open(os.path.join(pistatus.folder(), "uptime.json")) as fh:
            d = json.load(fh)
    except (OSError, ValueError, ImportError):
        return {}
    if not isinstance(d, dict):
        return {}
    bad = [s for s in d.get("sites") or [] if isinstance(s, dict) and not s.get("ok")]
    d["ok"] = not bad
    d["problem"] = "; ".join(f"{s.get('url')} is down ({s.get('error') or s.get('code')})" for s in bad)
    return d


def all_jobs():
    now = datetime.datetime.now(datetime.timezone.utc)
    rows = _app_rows(now) + _host_rows(now) + _bid_rows(now)
    order = {"late": 0, "failed": 1, "never": 2, "ok": 3}
    return sorted(rows, key=lambda r: (order[r["state"]], r["where"], r["name"]))


_cache = {"t": 0.0, "n": 0}


def problems():
    """Count for the admin menu badge: late or failed jobs. Cached for a minute (the menu asks on every admin page)."""
    import time
    if time.monotonic() - _cache["t"] < 60:
        return _cache["n"]
    try:
        n = sum(1 for r in all_jobs() if r["state"] in ("late", "failed"))
    except Exception:
        n = 0
    _cache.update(t=time.monotonic(), n=n)
    return n
