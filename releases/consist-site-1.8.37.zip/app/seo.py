"""Search promotion that runs by itself: the sitemap's URL list, IndexNow pings, the RSS feed and the public data pages
(/data/...), which are rebuilt from fleet.db and bids.db each time they are requested and cached for an hour.

IndexNow (https://www.indexnow.org) tells Bing and the engines that share its index when pages change. The site serves its key at
/<key>.txt; a background thread submits the URLs whose lastmod changed since the last ping, once a day. It only runs on the
production domain (never staging or localhost) and can be turned off in Admin > Settings > General."""
import datetime
import hashlib
import json
import logging
import os
import secrets
import threading
import time
import urllib.request
from urllib.parse import urlparse

from . import compare, config, content, data, db

log = logging.getLogger("seo")

# ---------- public data pages ----------

PUBLIC_SCOPE = ("coalesce(o.category, '') NOT LIKE 'freight%' AND o.country IN ('US', 'CA') AND coalesce(p.qty_active, 0) > 0 "
                # heritage cable cars, inclines and vintage streetcars would fill the "oldest" list without being anyone's next order
                "AND coalesce(p.vehicle_class, '') NOT IN ('heritage_streetcar', 'cable_car', 'incline_car') AND coalesce(p.ntd_mode, '') NOT IN ('CC', 'IP')")

DATA_PAGES = {
    "oldest-rail-fleets": {
        "title": "Oldest passenger rail fleets in the US and Canada",
        "h1": "The oldest passenger rail fleets in the US and Canada",
        "description": "The 50 oldest passenger rail car fleets (5 or more units in service) in the US and Canada by build year, with builder, operator and units in service. Updated monthly.",
        "lead": "These are the 50 oldest passenger rail car fleets still in active service in the US and Canada, ranked by the year the cars were built. "
                "Groups of fewer than 5 units, heritage streetcars, cable cars and inclines are left out. "
                "Old fleets are where rebuilds, component replacement and new car orders come next.",
    },
    "midlife-overhauls-due": {
        "title": "Rail car midlife overhauls coming due",
        "h1": "Passenger rail fleets coming due for a midlife overhaul",
        "description": "US and Canadian passenger rail fleets whose midlife overhaul falls due in the next five years, with builder, cars and due year. Updated monthly.",
        "lead": "These passenger rail fleets reach their estimated midlife overhaul in the next five years. The due year comes from each fleet's "
                "build or last rebuild year and the overhaul interval for its type of car, adjusted for how hard the fleet works.",
    },
    "rail-bids-this-month": {
        "title": "Rail and transit bids this month",
        "h1": "Rail and transit bids posted in the last 30 days",
        "description": "How many rail and transit procurement notices US and Canadian agencies posted in the last 30 days, by category and state, with recent examples.",
        "lead": "Public rail and transit procurement notices posted by US and Canadian agencies in the last 30 days, counted by category and "
                "state or province. Only notices scored as rail-relevant are counted.",
    },
}

_cache = {}


def _cached(key, fn, ttl=3600):
    hit = _cache.get(key)
    if hit and hit[0] > time.time() - ttl:
        return hit[1]
    val = fn()
    _cache[key] = (time.time(), val)
    return val


def _fleet_rows(order, where="", limit=50):
    sql = ("SELECT p.fleet_id, p.operator_id, o.operator_name, o.service_name, o.country, p.ntd_mode, p.manufacturer, p.model_name, "
           "p.vehicle_class, p.build_year, p.last_rebuild_year, p.qty_active, p.midlife_due_year "
           f"FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE {PUBLIC_SCOPE} {where} ORDER BY {order} LIMIT {int(limit)}")
    return [dict(r) for r in db.fq(sql)]


def oldest_fleets():
    return _cached("oldest", lambda: _fleet_rows("p.build_year ASC, p.qty_active DESC", "AND p.build_year IS NOT NULL AND p.qty_active >= 5"))


def midlife_due():
    y = datetime.date.today().year
    return _cached("midlife", lambda: _fleet_rows("p.midlife_due_year ASC, p.qty_active DESC",
                                                  f"AND p.midlife_due_year BETWEEN {y} AND {y + 5}", limit=100))


def bids_month():
    def build():
        since = (datetime.date.today() - datetime.timedelta(days=30)).isoformat()
        base = (f"FROM notice n LEFT JOIN agency g USING (agency_id) WHERE coalesce(n.published, date(n.first_seen)) >= '{since}' "
                "AND coalesce(n.relevance, 0) >= 50 AND coalesce(n.notice_type, '') != 'award' AND coalesce(n.country, g.country, 'US') IN ('US', 'CA')")
        try:
            total = (db.bq(f"SELECT count(*) n {base}", one=True) or {"n": 0})["n"]
            cats = [dict(r) for r in db.bq(f"SELECT n.category, count(*) n {base} GROUP BY n.category ORDER BY n DESC")]
            states = [dict(r) for r in db.bq(f"SELECT g.state_prov, count(*) n {base} AND g.state_prov IS NOT NULL GROUP BY g.state_prov ORDER BY n DESC LIMIT 15")]
            recent = [dict(r) for r in db.bq(f"SELECT n.title, coalesce(g.agency, n.buyer) agency, g.state_prov, n.category, "
                                             f"coalesce(n.published, date(n.first_seen)) published, n.closing {base} ORDER BY published DESC LIMIT 20")]
        except Exception as e:
            log.warning("bid roundup failed: %s", e)
            total, cats, states, recent = 0, [], [], []
        return {"since": since, "total": total, "cats": cats, "states": states, "recent": recent}
    return _cached("bids", build)


def data_day():
    try:
        return time.strftime("%Y-%m-%d", time.gmtime(os.path.getmtime(config.FLEET_DB)))
    except OSError:
        return ""


def bids_day():
    try:
        return time.strftime("%Y-%m-%d", time.gmtime(os.path.getmtime(config.BIDS_DB)))
    except OSError:
        return ""


def code_day():
    """When the public page templates or copy last changed (the deploy), for pages without a data date of their own."""
    here = os.path.dirname(os.path.abspath(__file__))
    paths = [os.path.join(here, f) for f in ("content.py", "compare.py", "claims.py")]
    tdir = os.path.join(here, "templates", "public")
    paths += [os.path.join(tdir, f) for f in os.listdir(tdir)] if os.path.isdir(tdir) else []
    ts = [os.path.getmtime(p) for p in paths if os.path.exists(p)]
    return time.strftime("%Y-%m-%d", time.gmtime(max(ts))) if ts else ""


# ---------- sitemap ----------

# ---------- public builder and car-model pages (1.7.58) ----------
# People search builder and model names ("Kawasaki M8", "Siemens Venture coaches", "Alstom Citadis"). These pages answer with
# who runs that car in the US and Canada, how many and when they were built, from the same public scope as the /data pages.
# Duty cycle, costs, overhaul timing and suppliers stay in the app.

def _public_fleets():
    def load():
        sql = ("SELECT p.fleet_id, p.operator_id, o.operator_name, o.service_name, o.country, o.states, p.ntd_mode, p.manufacturer, "
               "p.model_name, p.vehicle_class, p.build_year, p.last_rebuild_year, p.qty_active "
               f"FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE {PUBLIC_SCOPE} AND coalesce(p.manufacturer, '') != ''")
        return [dict(r) for r in db.fq(sql)]
    return _cached("public_fleets", load)


def _bname(m):
    return (m or "").strip()


def builders_index():
    """{builder slug: {name, slug, cars, fleets, operators (set), models {model slug: {...}}, first, last}} for builders with
    passenger fleets in service; model slugs are unique within a builder."""
    def build():
        out = {}
        for f in _public_fleets():
            name = _bname(f["manufacturer"])
            bs = data.slug(name)
            if not bs:
                continue
            b = out.setdefault(bs, {"name": name, "slug": bs, "cars": 0, "fleets": 0, "operators": set(), "models": {},
                                    "first": None, "last": None, "classes": {}})
            b["cars"] += f["qty_active"] or 0
            b["fleets"] += 1
            b["operators"].add(f["operator_id"])
            y = f["build_year"]
            if y:
                b["first"] = min(b["first"] or y, y)
                b["last"] = max(b["last"] or y, y)
            cls = f["vehicle_class"] or ""
            b["classes"][cls] = b["classes"].get(cls, 0) + (f["qty_active"] or 0)
            model = (f["model_name"] or "").strip()
            ms = data.slug(model)
            if not ms:
                continue
            m = b["models"].setdefault(ms, {"name": model, "slug": ms, "cars": 0, "fleets": [], "operators": set(),
                                            "first": None, "last": None, "classes": {}})
            m["cars"] += f["qty_active"] or 0
            m["fleets"].append(f)
            m["operators"].add(f["operator_id"])
            if y:
                m["first"] = min(m["first"] or y, y)
                m["last"] = max(m["last"] or y, y)
            m["classes"][cls] = m["classes"].get(cls, 0) + (f["qty_active"] or 0)
        _remember_slugs(out)
        return out
    return _cached("builders_index", build)


# 1.8.28 renamed builder and model pages keep working (Justin 11-28). When a builder or model is renamed in the data, its page
# address changes (/builders/alstom/comet-ii became /builders/bombardier/comet-ii). Every address the index has ever produced is
# remembered with the fleets on it (slug_history in app.db), so an old address answers with a permanent redirect to wherever
# those fleets live now. Addresses retired before this was added are matched by model name instead (see slug_redirect).
_SLUG_DDL = ("CREATE TABLE IF NOT EXISTS slug_history (bslug TEXT, mslug TEXT, fleet_id TEXT, last_seen TEXT, "
             "PRIMARY KEY (bslug, mslug, fleet_id))")


def _remember_slugs(index):
    try:
        rows = [(bs, ms, str(f["fleet_id"]), db.now()) for bs, b in index.items() for ms, m in b["models"].items() for f in m["fleets"]]
        with db._lock:
            c = db.connect()
            try:
                c.execute(_SLUG_DDL)
                c.executemany("INSERT OR REPLACE INTO slug_history VALUES (?, ?, ?, ?)", rows)
                c.commit()
            finally:
                c.close()
    except Exception:
        log.exception("slug_history")


def _history(bslug, mslug=None):
    try:
        db.x(_SLUG_DDL)
        if mslug is None:
            return [r[0] for r in db.q("SELECT DISTINCT fleet_id FROM slug_history WHERE bslug = ?", (bslug,))]
        return [r[0] for r in db.q("SELECT fleet_id FROM slug_history WHERE bslug = ? AND mslug = ?", (bslug, mslug))]
    except Exception:
        log.exception("slug_history read")
        return []


def slug_redirect(bslug, mslug=None):
    """The current address for an old /builders/<bslug>[/<mslug>] that no longer exists, or None (a real 404)."""
    to = _slug_redirect(bslug, mslug)
    return None if to == f"/builders/{bslug}" + (f"/{mslug}" if mslug else "") else to


def _slug_redirect(bslug, mslug):
    bi = builders_index()
    where = {}
    for bs, b in bi.items():
        for ms, m in b["models"].items():
            for f in m["fleets"]:
                where[str(f["fleet_id"])] = (bs, ms)
    votes = {}
    for fid in _history(bslug, mslug):
        if fid in where:
            k = where[fid] if mslug is not None else (where[fid][0], None)
            votes[k] = votes.get(k, 0) + 1
    votes.pop((bslug, mslug), None)
    if votes:
        bs, ms = max(votes, key=votes.get)
        return f"/builders/{bs}" + (f"/{ms}" if ms else "")
    tokens = set(bslug.split("-"))
    if mslug:
        # older renames: the same model name under another builder; prefer one that shares a word with the old builder name
        hits = [bs for bs, b in bi.items() if mslug in b["models"]]
        if hits:
            near = [bs for bs in hits if tokens & set(bs.split("-"))]
            pick = max(near or hits, key=lambda bs: bi[bs]["models"][mslug]["cars"])
            return f"/builders/{pick}/{mslug}"
        return None
    # an old builder name joined from two (wabtec-ge): redirect only when exactly one current builder is one of its words
    hits = [bs for bs in bi if bs in tokens]
    return f"/builders/{hits[0]}" if len(hits) == 1 else None


def builder_links(fleets):
    """{manufacturer: /builders/x, (manufacturer, model): /builders/x/y} for the rows that have a public page."""
    try:
        bi = builders_index()
    except Exception:
        return {}
    out = {}
    for f in fleets:
        bs = data.slug(f["manufacturer"])
        if bs in bi:
            out[f["manufacturer"]] = f"/builders/{bs}"
            ms = data.slug(f["model_name"])
            if ms in bi[bs]["models"]:
                out[(f["manufacturer"], f["model_name"])] = f"/builders/{bs}/{ms}"
    return out


def op_name(f):
    return (f.get("service_name") or f.get("operator_name") or "").split(" / ")[0]


def years(a, b):
    return "" if not a else (str(a) if a == b or not b else f"{a} to {b}")


def main_class(classes):
    """The vehicle type with the most cars, as a lower-case plural label ("metro cars")."""
    if not classes:
        return "rail cars"
    k = max(classes, key=classes.get)
    return plural_class(k)


def plural_class(k):
    label = data.CLASSES.get(k, "Rail car")
    words = [w if w.isupper() else w.lower() for w in label.split(" ")]  # keep EMU, DMU, AGT / APM as written
    last = words[-1]
    words[-1] = last + ("es" if last.endswith(("ch", "sh", "s", "x")) else "s")
    return " ".join(words)


def sitemap_urls():
    """[(path, priority, lastmod)] for every public page; the sitemap, IndexNow and the feed all read this."""
    code, fleet, bids = code_day(), data_day(), bids_day()
    pages = db.q("SELECT slug, kind, updated FROM page WHERE published = 1")
    blog = max([(p["updated"] or "")[:10] for p in pages if p["kind"] == "post"] or [code])
    urls = [("/", "1.0", max(code, bids)), ("/pricing", "0.9", code), ("/compare", "0.9", code), ("/coverage", "0.8", fleet),
            ("/solutions", "0.8", code), ("/rail", "0.8", code), ("/data", "0.8", max(fleet, bids)), ("/blog", "0.6", blog),
            ("/contact", "0.4", code), ("/signup", "0.6", code)]
    urls += [(f"/data/{k}", "0.8", bids if k == "rail-bids-this-month" else fleet) for k in DATA_PAGES]
    urls += [(f"/compare/{k}", "0.8", code) for k in compare.all_items()]
    urls += [(f"/solutions/{k}", "0.8", code) for k in content.solutions()]
    urls += [(f"/p/{p['slug']}", "0.6", (p["updated"] or "")[:10]) for p in pages]
    urls += [(f"/operators/{k}", "0.7", fleet) for k in data.operator_slugs()]
    try:
        bi = builders_index()
        urls.append(("/builders", "0.7", fleet))
        for bs, b in bi.items():
            urls.append((f"/builders/{bs}", "0.7", fleet))
            urls += [(f"/builders/{bs}/{ms}", "0.6", fleet) for ms in b["models"]]
    except Exception as e:  # never let the sitemap fail on the fleet data
        log.warning("builder pages left out of the sitemap: %s", e)
    return urls


# ---------- IndexNow ----------

def indexnow_key():
    s = db.settings()
    key = s.get("indexnow_key", "")
    if not key:
        key = secrets.token_hex(16)
        db.set_setting("indexnow_key", key)
    return key


def indexnow_allowed():
    """Only the production site pings: never staging, localhost or plain http."""
    host = urlparse(config.SITE_URL).hostname or ""
    return (config.SITE_URL.startswith("https://") and "." in host and not host.startswith(("staging.", "localhost"))
            and db.settings().get("indexnow_on", "1") == "1")


def indexnow_run(force=False):
    """Submit the URLs whose lastmod changed since the last ping (all of them on the first run). Returns a status line."""
    if not indexnow_allowed():
        return "IndexNow is off for this site."
    s = db.settings()
    try:
        seen = json.loads(s.get("indexnow_seen") or "{}")
    except ValueError:
        seen = {}
    urls = sitemap_urls()
    changed = [u for u, _, mod in urls if force or seen.get(u) != (mod or "-")]
    if not changed:
        status = f"{_now()}: nothing changed since the last ping"
        db.set_setting("indexnow_status", status)
        return status
    host = urlparse(config.SITE_URL).hostname
    key = indexnow_key()
    sent = 0
    for i in range(0, len(changed), 10000):
        batch = changed[i:i + 10000]
        body = json.dumps({"host": host, "key": key, "keyLocation": f"{config.SITE_URL}/{key}.txt",
                           "urlList": [config.SITE_URL + u for u in batch]}).encode()
        req = urllib.request.Request("https://api.indexnow.org/indexnow", data=body, method="POST",
                                     headers={"Content-Type": "application/json; charset=utf-8"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                code = r.status
        except urllib.error.HTTPError as e:
            code = e.code
        except Exception as e:
            status = f"{_now()}: ping failed ({type(e).__name__})"
            db.set_setting("indexnow_status", status)
            return status
        if code not in (200, 202):
            status = f"{_now()}: IndexNow answered {code}"
            db.set_setting("indexnow_status", status)
            return status
        sent += len(batch)
    seen.update({u: (mod or "-") for u, _, mod in urls})
    db.set_setting("indexnow_seen", json.dumps(seen))
    status = f"{_now()}: sent {sent} changed URL{'s' if sent != 1 else ''}"
    db.set_setting("indexnow_status", status)
    log.info("IndexNow %s", status)
    return status


def _now():
    from . import tz
    return tz.lt(datetime.datetime.now(datetime.timezone.utc))


def start():
    """Ping 10 minutes after start-up (so a deploy's changes go out), then once a day."""
    def loop():
        time.sleep(600)
        while True:
            try:
                indexnow_run()
            except Exception as e:
                log.error("IndexNow run failed: %s", e)
            try:
                from . import promo
                promo.refresh_wording()
                if promo.due():
                    log.info(promo.generate())
            except Exception as e:
                log.error("Monthly report failed: %s", e)
            from . import jobs
            jobs.beat("seo")
            time.sleep(86400)
    threading.Thread(target=loop, daemon=True).start()


# ---------- RSS ----------

def feed_items():
    """Guides and data pages, newest first: (title, path, date, description)."""
    items = [(p["title"], f"/p/{p['slug']}", (p["updated"] or "")[:10], p["description"] or "")
             for p in db.q("SELECT slug, title, description, updated FROM page WHERE published = 1 AND kind = 'post'")]
    for k, v in DATA_PAGES.items():
        items.append((v["title"], f"/data/{k}", bids_day() if k == "rail-bids-this-month" else data_day(), v["description"]))
    return sorted(items, key=lambda i: i[2], reverse=True)


def feed_xml(site):
    from email.utils import format_datetime
    from xml.sax.saxutils import escape

    def rfc(d):
        try:
            return format_datetime(datetime.datetime.fromisoformat(d).replace(tzinfo=datetime.timezone.utc))
        except ValueError:
            return ""
    body = "".join(f"<item><title>{escape(t)}</title><link>{config.SITE_URL}{p}</link><guid>{config.SITE_URL}{p}#{hashlib.md5(d.encode()).hexdigest()[:8]}</guid>"
                   + (f"<pubDate>{rfc(d)}</pubDate>" if d else "") + f"<description>{escape(desc)}</description></item>"
                   for t, p, d, desc in feed_items())
    return (f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel>'
            f"<title>{escape(site)}: rail fleet data and guides</title><link>{config.SITE_URL}/</link>"
            f'<atom:link href="{config.SITE_URL}/feed.xml" rel="self" type="application/rss+xml"/>'
            f"<description>Guides and monthly data on US and Canadian passenger rail fleets and rail procurement.</description>"
            f"<language>en-us</language>{body}</channel></rss>")
