"""1.8.24 (Justin 11-26): Admin > Email health. DMARC aggregate reports for consist-na.com arrive daily at admin@
(DNS rua=mailto:admin@consist-na.com). The site reads that mailbox over IMAP on its own, unpacks each report
(.xml, .xml.gz or .zip), stores one row per sending server, works out who sent the mail, and turns the results
into a short list of actions an admin can approve, mark done or dismiss.

Settings (server .env): DMARC_IMAP_HOST (default imap.ionos.com), DMARC_IMAP_PORT (993), DMARC_IMAP_USER,
DMARC_IMAP_PASSWORD, DMARC_IMAP_FOLDER (INBOX). Without a password the page says so and a report file can still be
uploaded by hand. Mail is only read, never deleted or moved; read message UIDs are remembered so nothing is counted
twice. No paid service is used. DNS is never changed from here: the page shows the exact record to paste at IONOS."""
import datetime
import gzip
import imaplib
import io
import logging
import socket
import threading
import time
import xml.etree.ElementTree as ET
import zipfile
from email import message_from_bytes

from . import config, db

log = logging.getLogger("dmarc")
DOMAIN = "consist-na.com"

SCHEMA = """
CREATE TABLE IF NOT EXISTS dmarc_report (
  id INTEGER PRIMARY KEY, org TEXT, report_id TEXT, begin_ts TEXT, end_ts TEXT, domain TEXT,
  p TEXT, sp TEXT, pct INTEGER, adkim TEXT, aspf TEXT, source TEXT, received TEXT,
  UNIQUE (org, report_id));
CREATE TABLE IF NOT EXISTS dmarc_row (
  id INTEGER PRIMARY KEY, report INTEGER NOT NULL, ip TEXT, n INTEGER DEFAULT 0, disposition TEXT,
  dkim TEXT, spf TEXT, header_from TEXT, envelope_from TEXT, dkim_domain TEXT, dkim_result TEXT,
  spf_domain TEXT, spf_result TEXT, sender TEXT, host TEXT);
CREATE INDEX IF NOT EXISTS dmarc_row_report ON dmarc_row (report);
CREATE TABLE IF NOT EXISTS dmarc_action (
  key TEXT PRIMARY KEY, title TEXT, detail TEXT, fix TEXT, severity TEXT, status TEXT DEFAULT 'open',
  note TEXT, first_seen TEXT, last_seen TEXT, decided TEXT, decided_by TEXT);
CREATE TABLE IF NOT EXISTS dmarc_fetch (
  id INTEGER PRIMARY KEY, at TEXT, ok INTEGER, found INTEGER DEFAULT 0, added INTEGER DEFAULT 0, message TEXT);
"""

STATUS = {"open": "Needs a decision", "approved": "Approved, waiting on the change", "done": "Done",
          "dismissed": "Dismissed (expected, no change needed)"}


def ensure():
    c = db.connect()
    try:
        c.executescript(SCHEMA)
        c.commit()
    finally:
        c.close()


# ---------------- settings ----------------

def imap_conf():
    return dict(host=config.env("DMARC_IMAP_HOST", "imap.ionos.com"), port=int(config.env("DMARC_IMAP_PORT", "993") or 993),
                user=config.env("DMARC_IMAP_USER", "admin@" + DOMAIN), password=config.env("DMARC_IMAP_PASSWORD", ""),
                folder=config.env("DMARC_IMAP_FOLDER", "INBOX"))


def configured():
    return bool(imap_conf()["password"])


# ---------------- who sent it ----------------

_host_cache = {}


def rdns(ip):
    if ip in _host_cache:
        return _host_cache[ip]
    try:
        socket.setdefaulttimeout(3)
        h = socket.gethostbyaddr(ip)[0].lower()
    except Exception:
        h = ""
    _host_cache[ip] = h
    return h


# (label, what it is, matched on host name, IP prefix or DKIM domain). Our own mail all leaves through IONOS.
SENDERS = [
    ("IONOS mail servers", "Consist's own mail: the site mailer, opportunity@ bid alerts, build.team@ invites and the mailboxes",
     ("kundenserver.de", "ionos.", "1and1.", "perfora.net", "oneandone.net", "schlund.de"), ("212.227.", "217.72.", "82.165.", "74.208."), ()),
    ("Consist server", "The VPS sending directly", (), ("74.208.37.200",), ()),
    ("Make", "Social posting automations", ("make.com", "integromat"), (), ("make.com", "integromat.com")),
    ("Google (forwarding)", "A recipient's Gmail or Google Workspace forwarding our mail on", ("google.com", "1e100.net"), ("209.85.",), ()),
    ("Microsoft (forwarding)", "A recipient's Outlook or Microsoft 365 forwarding our mail on", ("outlook.com", "protection.outlook"), ("40.92.", "40.107.", "52.100.", "52.101.", "52.102.", "52.103."), ()),
    ("Mailing list or security gateway", "A list or mail filter passing our mail on", ("mimecast", "pphosted", "barracuda", "messagelabs", "iphmx", "listserv"), (), ()),
]
OURS = {"IONOS mail servers", "Consist server", "Make"}
FORWARDERS = {"Google (forwarding)", "Microsoft (forwarding)", "Mailing list or security gateway"}


def classify(ip, host, dkim_domain=""):
    dd = (dkim_domain or "").lower()
    for label, _, hosts, prefixes, dkims in SENDERS:
        if ip == "74.208.37.200" and label != "Consist server":
            continue
        if any(h in host for h in hosts) or any(ip.startswith(p) for p in prefixes) or any(dd.endswith(d) for d in dkims):
            return label
    return "Unknown sender"


# ---------------- parsing ----------------

def _t(el, path, default=""):
    x = el.find(path)
    return (x.text or "").strip() if x is not None and x.text else default


def _ts(epoch):
    try:
        return datetime.datetime.fromtimestamp(int(epoch), datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""


def unpack(name, data):
    """Report XML documents from an attachment (.xml, .gz, .zip)."""
    name = (name or "").lower()
    out = []
    try:
        if name.endswith(".zip") or data[:2] == b"PK":
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for n in z.namelist():
                    if n.lower().endswith(".xml") and z.getinfo(n).file_size < 20_000_000:
                        out.append(z.read(n))
        elif name.endswith(".gz") or data[:2] == b"\x1f\x8b":
            out.append(gzip.decompress(data)[:20_000_000])
        elif name.endswith(".xml") or data.lstrip()[:5] in (b"<?xml", b"<feed"):
            out.append(data)
    except Exception:
        log.exception("dmarc unpack %s", name)
    return out


def store(xml, source="mailbox"):
    """Save one aggregate report. Returns True if it was new."""
    if b"<!DOCTYPE" in xml[:2000] or b"<!ENTITY" in xml[:4000]:
        return False  # never expand entities from mail we did not write
    root = ET.fromstring(xml)
    org, rid = _t(root, "report_metadata/org_name"), _t(root, "report_metadata/report_id")
    if not rid or db.q("SELECT 1 FROM dmarc_report WHERE org = ? AND report_id = ?", (org, rid), one=True):
        return False
    pp = root.find("policy_published")
    pp = pp if pp is not None else ET.Element("x")
    rep = db.x("INSERT INTO dmarc_report (org, report_id, begin_ts, end_ts, domain, p, sp, pct, adkim, aspf, source, received)"
               " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
               (org, rid, _ts(_t(root, "report_metadata/date_range/begin")), _ts(_t(root, "report_metadata/date_range/end")),
                _t(pp, "domain"), _t(pp, "p"), _t(pp, "sp"), int(_t(pp, "pct", "100") or 100), _t(pp, "adkim", "r"),
                _t(pp, "aspf", "r"), source, db.now()))
    if not isinstance(rep, int):
        rep = db.q("SELECT id FROM dmarc_report WHERE org = ? AND report_id = ?", (org, rid), one=True)["id"]
    for rec in root.findall("record"):
        ip = _t(rec, "row/source_ip")
        dk = rec.find("auth_results/dkim")
        dk_dom, dk_res = (_t(dk, "domain"), _t(dk, "result")) if dk is not None else ("", "none")
        # prefer a DKIM signature from our own domain when there are several
        for d in rec.findall("auth_results/dkim"):
            if _t(d, "domain").lower().endswith(DOMAIN):
                dk_dom, dk_res = _t(d, "domain"), _t(d, "result")
        sp = rec.find("auth_results/spf")
        host = rdns(ip) if ip else ""
        db.x("INSERT INTO dmarc_row (report, ip, n, disposition, dkim, spf, header_from, envelope_from, dkim_domain,"
             " dkim_result, spf_domain, spf_result, sender, host) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
             (rep, ip, int(_t(rec, "row/count", "0") or 0), _t(rec, "row/policy_evaluated/disposition"),
              _t(rec, "row/policy_evaluated/dkim"), _t(rec, "row/policy_evaluated/spf"),
              _t(rec, "identifiers/header_from").lower(), _t(rec, "identifiers/envelope_from").lower(),
              dk_dom.lower(), dk_res, _t(sp, "domain").lower() if sp is not None else "",
              _t(sp, "result") if sp is not None else "none", classify(ip, host, dk_dom), host))
    return True


def ingest_file(name, data, source="upload"):
    added = 0
    for xml in unpack(name, data):
        try:
            added += 1 if store(xml, source) else 0
        except ET.ParseError:
            log.warning("dmarc: not a report %s", name)
    return added


# ---------------- mailbox ----------------

def fetch(limit=300):
    """Read new report mail from the admin@ inbox. Returns (found, added, message)."""
    ensure()
    c = imap_conf()
    if not c["password"]:
        return _log_fetch(False, 0, 0, "Mailbox password not set (DMARC_IMAP_PASSWORD in the server's .env file).")
    found = added = 0
    try:
        m = imaplib.IMAP4_SSL(c["host"], c["port"], timeout=60)
        m.login(c["user"], c["password"])
        typ, _ = m.select(c["folder"], readonly=True)  # read only: flags, folders and messages are left as they are
        if typ != "OK":
            raise RuntimeError(f"folder {c['folder']} not found")
        uidv = (m.response("UIDVALIDITY")[1] or [b"0"])[0].decode()
        s = db.settings()
        last = int(s.get("dmarc_last_uid", "0") or 0) if s.get("dmarc_uidvalidity") == uidv else 0
        typ, data = m.uid("search", None, f"UID {last + 1}:*")
        uids = [int(u) for u in (data[0] or b"").split() if int(u) > last][:limit]
        for uid in uids:
            typ, msg = m.uid("fetch", str(uid), "(RFC822)")
            raw = next((p[1] for p in msg if isinstance(p, tuple)), b"")
            em = message_from_bytes(raw)
            subj = str(em.get("Subject", "")).lower()
            got = 0
            for part in em.walk():
                fn = part.get_filename() or ""
                ct = part.get_content_type()
                if fn.lower().endswith((".zip", ".gz", ".xml")) or ct in ("application/zip", "application/gzip", "application/x-gzip", "text/xml", "application/xml"):
                    payload = part.get_payload(decode=True) or b""
                    if payload:
                        got += 1
                        added += ingest_file(fn or ct, payload, "mailbox")
            if got and ("report" in subj or "dmarc" in subj or DOMAIN in subj):
                found += 1
            db.set_setting("dmarc_last_uid", str(uid))
        db.set_setting("dmarc_uidvalidity", uidv)
        m.logout()
    except Exception as e:
        log.warning("dmarc fetch failed: %s", e)
        return _log_fetch(False, found, added, f"Could not read the mailbox: {e}")
    refresh_actions()
    return _log_fetch(True, found, added, f"Read {found} report email{'s' if found != 1 else ''}, {added} new report{'s' if added != 1 else ''}.")


def _log_fetch(ok, found, added, msg):
    db.x("INSERT INTO dmarc_fetch (at, ok, found, added, message) VALUES (?,?,?,?,?)", (db.now(), int(ok), found, added, msg[:500]))
    db.x("DELETE FROM dmarc_fetch WHERE id NOT IN (SELECT id FROM dmarc_fetch ORDER BY id DESC LIMIT 200)")
    return found, added, msg


def start():
    """Check the mailbox 10 minutes after start, then every 6 hours. Off when no password is set."""
    def loop():
        time.sleep(600)
        while True:
            try:
                if configured():
                    fetch()
                from . import jobs
                jobs.beat("dmarc", note="" if configured() else "IMAP not set up")
            except Exception as e:
                log.exception("dmarc tick")
                from . import jobs
                jobs.beat("dmarc", ok=False, note=str(e))
            time.sleep(6 * 3600)
    threading.Thread(target=loop, daemon=True).start()


# ---------------- analysis ----------------

def _since(days):
    return (datetime.datetime.utcnow() - datetime.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")


def summary(days=30):
    ensure()
    since = _since(days)
    rows = db.q("SELECT r.*, p.org, p.p, p.pct, p.end_ts FROM dmarc_row r JOIN dmarc_report p ON p.id = r.report WHERE p.end_ts >= ?", (since,))
    senders = {}
    tot = dict(n=0, pass_=0, fail=0)
    for r in rows:
        s = senders.setdefault(r["sender"], dict(sender=r["sender"], n=0, pass_=0, dkim=0, spf=0, ips=set(), hosts=set(),
                                                   reporters=set(), fail_reasons={}))
        ok = r["dkim"] == "pass" or r["spf"] == "pass"
        s["n"] += r["n"]; s["pass_"] += r["n"] if ok else 0
        s["dkim"] += r["n"] if r["dkim"] == "pass" else 0
        s["spf"] += r["n"] if r["spf"] == "pass" else 0
        s["ips"].add(r["ip"]); s["reporters"].add(r["org"])
        if r["host"]:
            s["hosts"].add(r["host"])
        if not ok:
            why = []
            if r["dkim_result"] != "pass":
                why.append("no valid DKIM signature" if r["dkim_result"] in ("", "none") else f"DKIM {r['dkim_result']}")
            elif not r["dkim_domain"].endswith(DOMAIN):
                why.append(f"DKIM signed by {r['dkim_domain']}, not {DOMAIN}")
            if r["spf_result"] != "pass":
                why.append(f"SPF {r['spf_result'] or 'none'}")
            elif not r["spf_domain"].endswith(DOMAIN):
                why.append(f"SPF passed for {r['spf_domain']}, not {DOMAIN}")
            k = "; ".join(why) or "not aligned"
            s["fail_reasons"][k] = s["fail_reasons"].get(k, 0) + r["n"]
        tot["n"] += r["n"]; tot["pass_"] += r["n"] if ok else 0
    tot["fail"] = tot["n"] - tot["pass_"]
    out = []
    for s in senders.values():
        s["fail"] = s["n"] - s["pass_"]
        s["rate"] = round(100 * s["pass_"] / s["n"], 1) if s["n"] else 0
        s["ours"] = s["sender"] in OURS
        s["forwarder"] = s["sender"] in FORWARDERS
        s["ips"] = sorted(s["ips"])[:12]; s["hosts"] = sorted(s["hosts"])[:6]; s["reporters"] = sorted(s["reporters"])
        s["fail_reasons"] = sorted(s["fail_reasons"].items(), key=lambda kv: -kv[1])[:5]
        out.append(s)
    out.sort(key=lambda s: (not s["ours"], -s["n"]))
    ours_n = sum(s["n"] for s in out if s["ours"])
    ours_pass = sum(s["pass_"] for s in out if s["ours"])
    reps = db.q("SELECT count(*) n, min(begin_ts) a, max(end_ts) b FROM dmarc_report WHERE end_ts >= ?", (since,), one=True)
    latest = db.q("SELECT p, pct FROM dmarc_report ORDER BY end_ts DESC LIMIT 1", one=True)
    span = 0
    if reps and reps["a"] and reps["b"]:
        span = (datetime.datetime.fromisoformat(reps["b"]) - datetime.datetime.fromisoformat(reps["a"])).days
    return dict(senders=out, total=tot, reports=reps["n"] if reps else 0, span_days=span, days=days,
                ours_n=ours_n, ours_rate=round(100 * ours_pass / ours_n, 1) if ours_n else 0,
                policy=(latest["p"] if latest else ""), pct=(latest["pct"] if latest else 100))


def readiness(sm):
    """Is it safe to tighten the policy? Returns (verdict key, sentence, next record)."""
    p = sm["policy"] or "none"
    nxt = {"none": "quarantine", "quarantine": "reject"}.get(p)
    if not sm["reports"]:
        return "nodata", "No reports have been read yet, so there's nothing to judge.", ""
    if sm["span_days"] < 14:
        return "wait", f"Only {sm['span_days']} day{'s' if sm['span_days'] != 1 else ''} of reports so far. Wait for two weeks of reports before tightening the policy.", ""
    unknown_ours = [s for s in sm["senders"] if s["ours"] and s["rate"] < 98 and s["n"] >= 5]
    if unknown_ours:
        names = ", ".join(s["sender"] for s in unknown_ours)
        return "fix", f"Not yet. Some of Consist's own mail is failing ({names}). Fix those first, or that mail would land in spam.", ""
    if not nxt:
        return "done", "The policy is already reject, the strongest setting.", ""
    if p in ("quarantine", "reject") and (sm["pct"] or 100) < 100:
        rec = f"v=DMARC1; p={p}; pct=100; rua=mailto:admin@{DOMAIN}; adkim=r; aspf=r"
        return "ready", f"Yes. {sm['ours_rate']}% of Consist's own mail passed over {sm['span_days']} days. Raise pct to 100.", rec
    rec = f"v=DMARC1; p={nxt}; pct=25; rua=mailto:admin@{DOMAIN}; adkim=r; aspf=r"
    return "ready", (f"Yes. {sm['ours_rate']}% of Consist's own mail passed over {sm['span_days']} days. Move to p={nxt}, "
                     "starting with 25% of mail, then raise pct to 100 after two clean weeks."), rec


def refresh_actions():
    """Rebuild the open action list from the last 30 days. Decisions already made are kept."""
    ensure()
    sm = summary(30)
    now = db.now()
    want = {}
    for s in sm["senders"]:
        if s["ours"] and s["fail"] >= 5 and s["rate"] < 98:
            reasons = "; ".join(f"{k} ({v})" for k, v in s["fail_reasons"])
            fix = ("Turn on DKIM signing for consist-na.com in IONOS (Domains & SSL > consist-na.com > DNS > DKIM) and make sure "
                   "the SPF record includes IONOS: v=spf1 include:_spf-us.ionos.com ~all") if s["sender"] != "Make" else \
                  ("In Make, send from the IONOS mailbox (SMTP module with smtp.ionos.com). Do not use the mail service of Make. "
                   "Then the mail is signed for consist-na.com.")
            want[f"fail:{s['sender']}"] = ("fix", f"{s['sender']}: {s['fail']} of {s['n']} messages failed DMARC",
                                           f"Reasons: {reasons}. Sending servers: {', '.join(s['hosts'] or s['ips'])}.", fix)
        elif s["sender"] == "Unknown sender" and s["fail"] >= 1:
            want["unknown"] = ("watch", f"{s['fail']} messages claiming to be from {DOMAIN} came from servers we don't recognize",
                               f"Servers: {', '.join(s['hosts'] or s['ips'])}. Reported by {', '.join(s['reporters'])}.",
                               "If one of these is a service you use, ask Claude to add it as a known sender. If not, it is "
                               "someone using the name, and a quarantine policy will send their mail to spam.")
        elif s["forwarder"] and s["fail"] >= 1:
            want[f"fwd:{s['sender']}"] = ("info", f"{s['sender']}: {s['fail']} forwarded messages failed",
                                          "Forwarding breaks SPF, and some forwarders change the message so DKIM breaks too.",
                                          "Usually no change needed. Dismiss if this matches people forwarding our emails.")
    verdict, text, rec = readiness(sm)
    if verdict == "ready":
        want[f"policy:{sm['policy'] or 'none'}:{sm['pct']}"] = ("policy", "Tighten the DMARC policy: " + rec.split(";")[1].strip() + ", " + rec.split(";")[2].strip(), text,
                                                     f"At IONOS, edit the TXT record _dmarc.{DOMAIN} to: {rec}")
    for key, (sev, title, detail, fix) in want.items():
        old = db.q("SELECT * FROM dmarc_action WHERE key = ?", (key,), one=True)
        if old:
            reopen = old["status"] == "done"  # it came back after being marked done
            db.x("UPDATE dmarc_action SET title = ?, detail = ?, fix = ?, severity = ?, last_seen = ?" +
                 (", status = 'open', note = 'Came back after being marked done.'" if reopen else "") + " WHERE key = ?",
                 (title, detail, fix, sev, now, key))
        else:
            db.x("INSERT INTO dmarc_action (key, title, detail, fix, severity, first_seen, last_seen) VALUES (?,?,?,?,?,?,?)",
                 (key, title, detail, fix, sev, now, now))
    # problems that cleared up on their own close themselves
    for a in db.q("SELECT key FROM dmarc_action WHERE status IN ('open', 'approved')"):
        if a["key"] not in want:
            db.x("UPDATE dmarc_action SET status = 'done', note = 'Cleared: no longer seen in the last 30 days of reports.', decided = ? WHERE key = ?",
                 (now, a["key"]))


def decide(key, status, note, who):
    if status not in STATUS:
        return
    db.x("UPDATE dmarc_action SET status = ?, note = ?, decided = ?, decided_by = ? WHERE key = ?",
         (status, (note or "")[:1000], db.now(), who, key))


# ---------------- admin pages ----------------

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile  # noqa: E402

from . import auth  # noqa: E402

admin = APIRouter(prefix="/admin")
A = Depends(auth.require_admin)


@admin.get("/email-health")
def page(request: Request, days: int = 30, u=A):
    from .main import render
    ensure()
    days = days if days in (7, 30, 90) else 30
    sm = summary(days)
    verdict, text, rec = readiness(summary(30))
    acts = db.q("SELECT * FROM dmarc_action ORDER BY CASE status WHEN 'open' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END,"
                " CASE severity WHEN 'fix' THEN 0 WHEN 'policy' THEN 1 WHEN 'watch' THEN 2 ELSE 3 END, last_seen DESC")
    return render(request, "admin/email_health.html", user=u, sm=sm, verdict=verdict, verdict_text=text, record=rec,
                  actions=acts, STATUS=STATUS, conf=imap_conf(), configured=configured(),
                  fetches=db.q("SELECT * FROM dmarc_fetch ORDER BY id DESC LIMIT 8"),
                  reports=db.q("SELECT p.*, (SELECT sum(n) FROM dmarc_row WHERE report = p.id) msgs FROM dmarc_report p ORDER BY end_ts DESC LIMIT 15"))


@admin.post("/email-health/fetch")
def fetch_now(request: Request, csrf: str = Form(""), u=A):
    from .main import flash, redirect
    auth.check_csrf(request, csrf)
    found, added, msg = fetch()
    flash(request, msg, "ok" if configured() and not msg.startswith("Could not") else "error")
    return redirect("/admin/email-health")


@admin.post("/email-health/upload")
async def upload(request: Request, csrf: str = Form(""), file: UploadFile = File(...), u=A):
    from .main import flash, redirect
    auth.check_csrf(request, csrf)
    ensure()
    data = await file.read(25_000_000)
    n = ingest_file(file.filename or "", data, "upload")
    refresh_actions()
    flash(request, f"Added {n} new report{'s' if n != 1 else ''} from {file.filename}." if n else "No new reports in that file.")
    return redirect("/admin/email-health")


@admin.post("/email-health/action")
def action(request: Request, csrf: str = Form(""), key: str = Form(""), status: str = Form(""), note: str = Form(""), u=A):
    from .main import flash, redirect
    auth.check_csrf(request, csrf)
    decide(key, status, note, u.email)
    db.audit("admin_dmarc", f"{key}: {status} {note[:200]}", None, u.email)
    flash(request, "Saved.")
    return redirect("/admin/email-health#actions")
