"""1.8.37: Admin > Scheduled jobs. Every in-app timer loop calls jobs.beat(), and the late flag works.
Run: python tests/test_jobs.py"""
import datetime, os, pathlib, re, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def problems():
    bad = []
    from app import jobs
    src = {p.name: p.read_text() for p in (ROOT / "app").glob("*.py")}
    for name, s in src.items():
        if "threading.Thread(target=loop" in s and "jobs.beat(" not in s:
            bad.append(f"app/{name} has a timer loop that does not call jobs.beat()")
    beats = set(re.findall(r'jobs\.beat\("(\w+)"', "".join(src.values())))
    for k in beats - set(jobs.APP_JOBS):
        bad.append(f"jobs.beat('{k}') has no row in jobs.APP_JOBS")
    for k in set(jobs.APP_JOBS) - beats:
        bad.append(f"jobs.APP_JOBS '{k}' is never beaten")
    now = datetime.datetime(2026, 11, 28, 12, tzinfo=datetime.timezone.utc)
    ago = lambda s: (now - datetime.timedelta(seconds=s)).isoformat()
    if jobs._row("x", "w", 600, "", ago(300), now=now)["state"] != "ok": bad.append("fresh job is not ok")
    if jobs._row("x", "w", 600, "", ago(3600), now=now)["state"] != "late": bad.append("old job is not late")
    if jobs._row("x", "w", 86400, "", ago(100000), now=now)["state"] != "ok": bad.append("daily job late too soon")
    if jobs._row("x", "w", 600, "", None, now=now)["state"] != "never": bad.append("missing job is not 'never'")
    if jobs._row("x", "w", 600, "", ago(60), ok=False, now=now)["state"] != "failed": bad.append("failed job not flagged")
    return bad


def test_jobs():
    b = problems(); assert not b, "\n".join(b)


if __name__ == "__main__":
    b = problems(); print("\n".join(b) or "OK: scheduled jobs"); sys.exit(1 if b else 0)
