"""1.7.76 market map (Justin 11-18): a Marimekko chart on Market share. Each column is a segment, as wide as its total; the stack
shows each supplier's share of it; a click on a block opens its details. Two views: installed base (active cars: car builders and
each mapped subsystem, from intel.market) and rail awards (USD, last five years, by award category, from bids.db)."""
import json
from urllib.parse import quote

from . import data, lens

TOP = 6  # suppliers named per column; the rest are pooled as Other


def _cols(items, top=TOP):
    out = []
    for key, label, total, sups, link in items:
        if not total:
            continue
        sups = sorted([s for s in sups if s[1] > 0], key=lambda s: -s[1])
        blocks = [{"n": n, "v": round(v), "x": x} for n, v, x in sups[:top]]
        rest = sum(v for _, v, _ in sups[top:])
        if rest > 0:
            blocks.append({"n": "Other", "v": round(rest), "x": {"count": len(sups) - top}, "o": 1})
        out.append({"k": key, "l": label, "t": round(total), "b": blocks, "link": link})
    return sorted(out, key=lambda c: -c["t"])


def builders(cls=None, mode=None):
    """Car builders by vehicle type: one column per vehicle class, stacks = builders' active cars."""
    from . import intel
    cols = {}
    for fl in intel.snapshot().values():
        if (cls and fl["vehicle_class"] != cls) or (mode and data.MODE_ALIASES.get(fl["ntd_mode"], fl["ntd_mode"]) != mode):
            continue
        c = cols.setdefault(fl["vehicle_class"] or "other", {})
        b = c.setdefault(fl["manufacturer"] or "Unknown", [0, 0, set()])
        b[0] += fl["qty_active"] or 0
        b[1] += 1
        b[2].add(fl["operator_id"])
    return _cols([(k, data.cls_label(k), sum(v[0] for v in c.values()),
                   [(n, v[0], {"fleets": v[1], "ops": len(v[2]), "href": f"/app/market/drill?by=builder&name={quote(str(n))}&cls={quote(k)}"})
                    for n, v in c.items()], f"/app/market?cls={quote(k)}") for k, c in cols.items()])


def installed(m, components, fq=""):
    items = []
    for k, sub in m["subs"].items():
        items.append((k, components.get(k, k), sub["cars"], [(n, v, {"href": f"/app/market/drill?by=supplier&comp={k}&name={quote(str(n))}{fq}"})
                      for n, v in sub["suppliers"]], f"/app/market?sub={k}"))
    return _cols(items)


def awards(years=5):
    sc = lens.current()
    w, a = "1=1", []
    if sc.territory:
        w, a = sc.ter_sql("operator_id", "agency_id")
    rows = data._bq_safe("SELECT coalesce(category, 'other') cat, vendor, vendor_norm, count(*) n, sum(amount_usd) usd FROM award "
                         f"WHERE relevance >= 50 AND coalesce(vendor, '') != '' AND amount_usd > 0 AND award_date >= date('now', ?) AND {w} "
                         "GROUP BY 1, 3", [f"-{int(years)} years"] + a)
    cats = {}
    for r in rows:
        cats.setdefault(r["cat"], []).append((r["vendor"], r["usd"] or 0, {"count": r["n"],
                                              "href": f"/app/awards?category={quote(r['cat'])}&vendor={quote(r['vendor_norm'] or '')}"}))
    return _cols([(c, data.CATEGORIES.get(c, c.replace("_", " ").capitalize()), sum(v for _, v, _ in s), s, f"/app/awards?category={quote(c)}")
                  for c, s in cats.items()])


def blob(m, components, fq, with_awards, cls=None, mode=None):
    d = {"installed": installed(m, components, fq), "builders": builders(cls, mode)}
    if with_awards:
        d["awards"] = awards()
    return json.dumps(d).replace("</", "<\\/")
