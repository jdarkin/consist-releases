"""R&D data pages in the Freight portal: STB EP 724 weekly service (/rail/service), Canada rail traffic (/rail/canada),
freight flows and forecasts (/rail/flows), network (/rail/network). Access follows /rail (routes_rail.gate)."""
from fastapi import APIRouter, Request

from . import charts
from .main import render
from .routes_app import csv_response
from .routes_rail import gate

router = APIRouter(prefix="/rail")


@router.get("/service")
def service(request: Request, rr: str = "", m: int = 0, view: str = "ts", p: str = "", d0: str = "", d1: str = "",
            ymin: str = "", ymax: str = ""):
    from . import ep724 as E
    u, r = gate(request, "Weekly service metrics")
    if r:
        return r
    ids = [x for x, _ in E.rail_ids()]
    rr = rr if rr in ids else (ids[0] if ids else "")
    if request.query_params.get("export"):
        import csv as _c, gzip
        with gzip.open(E.SEED, "rt", newline="") as f:
            rows = [x for x in _c.DictReader(f) if x["rr"] == rr]
        return csv_response("consist-ep724-" + rr.lower(), ["rr", "measure", "variable", "sub", "week", "value"], rows)
    board = E.scoreboard()
    cur = [b for b in board if b["last"] == E.latest_week()]
    view = view if view in ("ts", "yoy") else "ts"
    m = m if 0 <= m < len(E.MEASURES) else 0
    d0, d1, p = E.date_range(p, d0, d1)
    fnum = lambda v: float(v) if v.replace(".", "", 1).replace("-", "", 1).isdigit() else None
    ya, yb = fnum(ymin), fnum(ymax)

    def since(s):
        pts = [(E.x(w), v) for w, v in s if d0 <= w <= d1]
        return pts[::max(1, len(pts) // 120)]  # every 4th week keeps the SVG small
    ch = {}
    if rr:
        vs, picked, ex = E.explorer(rr, m, request.query_params.getlist("s"), view, d0, d1)
        ch["ex"] = charts.line(ex, w=1000, h=320, title=E.MEASURES[m][2], ymin=ya, ymax=yb, pick=False,
                               xtip=(lambda x: "week %d" % x) if view == "yoy" else (lambda x: "%d week %d" % (int(x), (x - int(x)) * 52 + 1)))
        ch["dwell"] = charts.line([("System dwell", since(E.system(rr, "dwell")))], title="System terminal dwell, hours", pick=False)
        ch["online"] = charts.line([("Cars online", since(E.system(rr, "cars_online")))], title="Cars online", pick=False)
        ch["stalled"] = charts.line([(sb, since(_sum([E.series(rr, "stalled", v, sb) for v in E.variables(rr, "stalled", sb)])))
                                     for sb in ("Loaded", "Empty")], title="Cars not moved 48h+", pick=False)
        ch["carloads"] = charts.line([("Carloads originated", since(_sum([E.series(rr, "carloads", v, "Originated")
                                                                          for v in E.variables(rr, "carloads", "Originated")])))], title="Weekly carloads", pick=False)  # the page has its own period picker
    cl = E.carloads(rr) if rr else []
    if not rr:
        vs, picked = [], []
    return render(request, "rail/service.html", user=u, E=E, rr=rr, ids=E.rail_ids(), board=board, ch=ch, cl=cl,
                  m=m, view=view, p=p, d0=d0, d1=d1, ymin=ymin if ya is not None else "", ymax=ymax if yb is not None else "",
                  vs=vs, picked=picked)


@router.get("/canada")
def canada(request: Request, y: str = ""):
    from . import statcan as S
    u, r = gate(request, "Canadian rail traffic")
    if r:
        return r
    ys = S.years()
    y = y if y in ys else (ys[-1] if ys else "")
    mo = [(p, v) for p, v in S.monthly() if p >= "2015"]
    tx = lambda p: int(p[:4]) + (int(p[5:7]) - 1) / 12
    ch = charts.line([("Tonnes carried (millions)", [(tx(p), v / 1e6) for p, v in mo])], title="Canadian rail tonnage by month")
    com, last = S.commodities()
    if request.query_params.get("export"):
        return csv_response("consist-canada-rail", ["label"] + [m[0] for m in S.METRICS] + ["or"], S.industry_table(30))
    odys = S.years("od")
    oy = odys[-1] if odys else ""
    regs, m = S.od(oy) if oy else ([], [])
    tr = {k: charts.line([(t, S.trend("Total companies" if k in ("cpt", "rtk") else S.MAIN, k))], title=t) for k, t in
          [("cpt", "Cars per freight train"), ("rtk", "Revenue tonne-km (billions)")]}
    return render(request, "rail/canada.html", user=u, S=S, y=y, ys=ys, rows=S.industry_table(), ch=ch, com=com[:25], last=last,
                  regs=regs, m=m, oy=oy, tr=tr)


@router.get("/flows")
def flows(request: Request):
    from . import rdata as D
    u, r = gate(request, "Freight flows and forecasts")
    if r:
        return r
    com = D.faf_commodities()
    if request.query_params.get("export"):
        return csv_response("consist-faf-rail", ["name", "t2024", "t2050", "lo", "hi", "growth", "tmiles", "value", "share"], com)
    tot = D.faf_total()
    ch = charts.line([("Base", [(y, v[0] / 1e6) for y, v in tot]), ("Low", [(y, v[1] / 1e6) for y, v in tot if y >= 2030]),
                      ("High", [(y, v[2] / 1e6) for y, v in tot if y >= 2030])], title="US rail freight, billion tons")
    o, d, lanes = D.faf_states()
    return render(request, "rail/flows.html", user=u, D=D, com=com, ch=ch, tot=dict(tot), o=o, d=d, lanes=lanes)


@router.get("/network")
def network(request: Request, rr: str = "UP"):
    from . import rdata as D
    u, r = gate(request, "Network density and structures")
    if r:
        return r
    own = D.owners()
    if request.query_params.get("export"):
        return csv_response("consist-network-owners", list(own[0].keys()) if own else [], own)
    ids = [o["owner"] for o in own]
    rr = rr if rr in ids else "UP"
    return render(request, "rail/network.html", user=u, D=D, own=own, rr=rr, subs=D.subdivs(rr), tofc=D.tofc(rr), yards=D.yards(rr))


@router.get("/border")
def border(request: Request, m: str = "Trains"):
    from . import rdata as D
    u, r = gate(request, "Cross-border rail")
    if r:
        return r
    ms = ["Trains", "Rail Containers Loaded", "Rail Containers Empty", "Train Passengers"]
    m = m if m in ms else "Trains"
    ports, year = D.border_ports(m)
    mo = [(p, v) for p, v in D.border_monthly(m) if p >= "2015"]
    tx = lambda p: int(p[:4]) + (int(p[5:7]) - 1) / 12
    ch = charts.line([("From Canada", [(tx(p), v[0]) for p, v in mo]), ("From Mexico", [(tx(p), v[1]) for p, v in mo])], title=m + " entering the US by month")
    return render(request, "rail/border.html", user=u, D=D, m=m, ms=ms, ports=ports, year=year, ch=ch)


@router.get("/tankcars")
def tankcars(request: Request):
    from . import rdata as D
    u, r = gate(request, "Flammable liquid tank cars")
    if r:
        return r
    tank = D.tank_series()
    tys = sorted({y for v in tank.values() for y in v})
    tot = {y: sum(v.get(y, 0) for v in tank.values()) for y in tys}
    order = sorted(tank, key=lambda c: -tank[c].get(tys[-1], 0)) if tys else []
    ch = charts.line([(c, [(y, tank[c].get(y)) for y in tys]) for c in order[:6]], title="Tank cars in flammable liquid service by specification")
    late = {y: v for y, v in D.tank_latest().items() if not tys or y > tys[-1]}
    d117 = lambda y: sum(tank[c].get(y, 0) for c in tank if c.startswith("DOT-117"))
    ch2 = charts.line([("All flammable liquid tank cars", [(y, tot[y]) for y in tys] + [(y, v["total"]) for y, v in late.items()]),
                       ("DOT-117 (new and retrofit)", [(y, d117(y)) for y in tys] + [(y, v["dot117"]) for y, v in late.items() if v["dot117"]])],
                      title="Fleet and DOT-117s, survey years and latest BTS report")
    return render(request, "rail/tankcars.html", user=u, D=D, tank=tank, tys=tys, tot=tot, order=order, ch=ch, late=late, ch2=ch2)


def _sum(ss):
    t = {}
    for s in ss:
        for w, v in s:
            t[w] = t.get(w, 0) + v
    return sorted(t.items())
