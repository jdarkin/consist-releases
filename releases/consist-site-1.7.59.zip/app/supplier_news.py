"""Recent news for a supplier (Supplier intelligence > Recent in the news), from the GDELT DOC 2.0 API: free, no key, public API
built for this use (https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/). GDELT asks for at most one request every 5 seconds, so
calls are serialized and results cached for 6 hours per supplier. Cost: $0 per search."""
import hashlib, json, logging, os, threading, time, urllib.parse, urllib.request

API = "https://api.gdeltproject.org/api/v2/doc/doc"
UA = "Consist (Sand and Style LLC) supplier news"
TTL = 6 * 3600
EMPTY_TTL = 3600
_cache, _lock, _last = {}, threading.Lock(), [0.0]
WINDOWS = {"7d": "Last 7 days", "30d": "Last 30 days", "90d": "Last 90 days"}


# Rail context ANDed with the names. 1.7.29: light rail coverage often says only "LRT" (Edmonton, Calgary, Ottawa), so it is included.
CONTEXT = '(rail OR railway OR railroad OR train OR transit OR locomotive OR metro OR LRT OR "light rail" OR streetcar OR tram OR subway OR SkyTrain)'

# 1.7.29: names the press actually uses for operators whose legal or NTD name rarely appears in news (Justin 2026-11-11: TransEd showed nothing).
NEWS_ALIASES = {
    "TRANSED": ["Valley Line LRT", "Valley Line Southeast", "Valley Line West", "Edmonton LRT"],
    "ETS": ["Edmonton Transit Service", "Edmonton LRT", "Capital Line", "Metro Line LRT"],
    "CALGARY_TRANSIT": ["Calgary Transit", "CTrain", "Green Line LRT"],
    "OC_TRANSPO": ["OC Transpo", "O-Train", "Confederation Line", "Trillium Line"],
    "ION": ["ION light rail", "ION LRT", "Grand River Transit"],
    "METROLINX_HURONTARIO": ["Hurontario LRT", "Hazel McCallion Line"],
    "REM": ["Réseau express métropolitain", "REM light rail"],
    "EXO": ["exo commuter", "exo train"],
    "SKYTRAIN": ["SkyTrain", "Expo Line", "Millennium Line"],
    "CANADA_LINE": ["Canada Line SkyTrain"],
    "GO_TRANSIT": ["GO Transit", "GO train"],
    "UP_EXPRESS": ["UP Express"],
    "TTC": ["TTC subway", "TTC streetcar"],
    "WCE": ["West Coast Express"],
    "YYZ_TERMINAL_LINK": ["Pearson Terminal Link"],
}


def query(e):
    """Supplier name and distinctive aliases, quoted, plus a rail context so 'Siemens' does not return every Siemens story."""
    first = e[1].split()[0].lower().strip("(),")
    names = [e[1].split(" (")[0]] + [a for a in e[6] if len(a) > 4 and a.lower().startswith(first) and a.lower() not in e[1].lower()][:3]
    names = list(dict.fromkeys(n.replace('"', "") for n in names))
    who = "(" + " OR ".join(f'"{n}"' for n in names) + ")" if len(names) > 1 else f'"{names[0]}"'
    return f"{who} " + CONTEXT


def operator_query(name, alts=(), oid=None):
    """A railroad or transit agency: its full name plus its short names (SEPTA, Metra, BNSF), with the same rail context."""
    import re
    paren = re.findall(r"\(([^)]+)\)", name or "")  # "TransLink (West Coast Express)": also search "West Coast Express"
    alts = list(paren) + [a for a in alts if a]
    base = name.split(" (")[0]
    names = [base] + list(NEWS_ALIASES.get(oid or "", [])) + \
        [a for a in alts if len(a) >= 4 and a.lower() != base.lower() and a.lower() not in base.lower() and min(map(len, a.split())) >= 3][:3]
    names = names[:6]
    names = list(dict.fromkeys(n.replace('"', "").strip() for n in names if n and n.strip()))
    who = "(" + " OR ".join(f'"{n}"' for n in names) + ")" if len(names) > 1 else f'"{names[0]}"'
    return f"{who} " + CONTEXT


def search(e, window="30d", lang="english", meta=None):
    return fetch(e[0], query(e), window, lang, meta)


class NewsUnavailable(RuntimeError):
    """Every attempt failed and there is no earlier copy to show."""


ATTEMPTS = 2          # GDELT drops connections or answers "please limit requests" when busy
TIMEOUT = 18          # seconds per attempt (GDELT is often slow rather than down)
GAP = 5.5             # GDELT: one request every 5 seconds
RSS_TIMEOUT = 10      # the fallback feed
MAX_WAIT = ATTEMPTS * TIMEOUT + GAP + RSS_TIMEOUT  # about 50 seconds worst case
STALE_OK = 30 * 86400  # if every source is down, an earlier copy up to 30 days old is better than nothing
# Fallback (1.4, 2026-11-07): Google News RSS search feed, a public feed for exactly this. Used only when GDELT fails, and only
# while news.google.com's robots.txt allows the /rss/search path (checked once a day).
RSS = "https://news.google.com/rss/search"
_robots = {"ts": 0.0, "ok": False}
_log = logging.getLogger("consist.news")


def _key(key_id, query_text, window):
    """Cache key: the page id, the window and a short hash of the query (1.7.29), so changing a query never serves the old copy."""
    return (f"{key_id}#{hashlib.sha1((query_text or '').encode()).hexdigest()[:8]}", window)


def _disk(key):
    from . import config
    d = os.path.join(config.DATA_DIR, "news_cache")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, hashlib.sha1(repr(key).encode()).hexdigest() + ".json")


def _remember(key, out):
    _cache[key] = (time.time(), out)
    try:
        with open(_disk(key), "w") as fh:
            json.dump({"ts": time.time(), "items": out}, fh)
    except OSError:
        pass


def _earlier(key):
    """The last good result for this search (memory, then disk, so it survives restarts): (timestamp, items) or None."""
    hit = _cache.get(key)
    if hit:
        return hit
    try:
        with open(_disk(key)) as fh:
            d = json.load(fh)
        _cache[key] = (d["ts"], d["items"])
        return _cache[key]
    except (OSError, ValueError, KeyError):
        return None


def _get(url):
    """One GDELT call, retried; returns the parsed articles or raises. Holds the lock so calls stay 5+ seconds apart."""
    last = None
    with _lock:
        for attempt in range(ATTEMPTS):
            wait = GAP - (time.time() - _last[0])
            if wait > 0:
                time.sleep(wait)
            try:
                raw = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=TIMEOUT).read().decode("utf-8", "ignore")
                return json.loads(raw).get("articles", [])  # a rate-limit or error notice is plain text: ValueError, retried
            except Exception as ex:
                last = ex
                _log.warning("GDELT attempt %d/%d failed: %s", attempt + 1, ATTEMPTS, (str(ex) or type(ex).__name__)[:200])
            finally:
                _last[0] = time.time()
    raise last


def _rss_allowed():
    if time.time() - _robots["ts"] < 86400:
        return _robots["ok"]
    import urllib.robotparser
    ok = False
    try:
        rp = urllib.robotparser.RobotFileParser()
        raw = urllib.request.urlopen(urllib.request.Request("https://news.google.com/robots.txt", headers={"User-Agent": UA}), timeout=8).read().decode("utf-8", "ignore")
        rp.parse(raw.splitlines())
        ok = rp.can_fetch(UA, RSS + "?q=rail")
    except Exception as ex:
        _log.warning("news fallback robots check failed: %s", (str(ex) or type(ex).__name__)[:200])
    _robots.update(ts=time.time(), ok=ok)
    return ok


def _rss(query_text, window):
    """Google News RSS search: same query, limited to the window with when:Nd. Returns items in our shape."""
    import email.utils, xml.etree.ElementTree as ET
    days = {"7d": 7, "30d": 30, "90d": 90}[window]
    url = RSS + "?" + urllib.parse.urlencode({"q": f"{query_text} when:{days}d", "hl": "en-US", "gl": "US", "ceid": "US:en"})
    raw = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=RSS_TIMEOUT).read()
    root = ET.fromstring(raw)
    out = []
    for it in root.iter("item"):
        title = " ".join((it.findtext("title") or "").split())
        src = it.find("source")
        pub = src.text if src is not None and src.text else ""
        if pub and title.endswith(" - " + pub):
            title = title[: -len(pub) - 3]
        dom = urllib.parse.urlparse(src.get("url")).netloc.replace("www.", "") if src is not None and src.get("url") else pub
        try:
            d = email.utils.parsedate_to_datetime(it.findtext("pubDate") or "").date().isoformat()
        except (TypeError, ValueError):
            d = ""
        out.append(dict(title=title, url=it.findtext("link"), domain=dom or pub, country="", date=d, image=None, via="Google News"))
    out.sort(key=lambda a: a["date"], reverse=True)
    return out


def fetch(key_id, query_text, window="30d", lang="english", meta=None):
    """Shared by supplier, operator, short line and consultant news pages, cached 6 hours per (id, window).
    Order: fresh cache; GDELT (2 tries); Google News RSS (if robots.txt allows); the last good copy up to 30 days old
    (meta["stale"] = its age in hours); otherwise NewsUnavailable. meta["source"] says which source answered."""
    window = window if window in WINDOWS else "30d"
    key = _key(key_id, query_text, window)
    meta = meta if meta is not None else {}
    if not meta.get("warm"):
        _note_view(key_id, query_text, window)
    hit = _earlier(key)
    if hit and time.time() - hit[0] < (TTL if hit[1] else EMPTY_TTL):  # an empty answer is rechecked after an hour
        meta["source"] = "cache"
        return hit[1]
    if hit and not hit[1]:
        hit = None  # 1.7.29: an empty earlier copy is not "results"; when the services are busy, say so instead
    q = query_text + (f" sourcelang:{lang}" if lang else "")
    url = API + "?" + urllib.parse.urlencode({"query": q, "mode": "artlist", "format": "json", "maxrecords": 75, "timespan": window, "sort": "datedesc"})
    try:
        arts = _get(url)
    except Exception:
        _log.warning("GDELT failed for %s %s; trying the fallback feed", key_id, window)
        arts = None
    if arts is None:
        out = None
        if _rss_allowed():
            try:
                out = _rss(query_text, window)
                meta["source"] = "Google News"
            except Exception as ex:
                _log.error("news fallback failed for %s %s: %s", key_id, window, (str(ex) or type(ex).__name__)[:200])
        if out is not None:
            _remember(key, out)
            return out
        if not hit:  # a wider window's copy, trimmed, beats nothing
            for w2 in ("90d", "30d", "7d"):
                h2 = _earlier(_key(key_id, query_text, w2)) if w2 != window else None
                if h2 and time.time() - h2[0] < STALE_OK:
                    cut = time.strftime("%Y-%m-%d", time.gmtime(time.time() - {"7d": 7, "30d": 30, "90d": 90}[window] * 86400))
                    hit = (h2[0], [a for a in h2[1] if (a.get("date") or "") >= cut])
                    break
        if hit and hit[1] and time.time() - hit[0] < STALE_OK:
            meta["stale"] = max(1, round((time.time() - hit[0]) / 3600))
            return hit[1]
        raise NewsUnavailable("The news service is busy right now.")
    meta["source"] = "GDELT"
    if not arts and _rss_allowed():  # 1.7.29: GDELT answered with nothing; Google News often has the local press it misses
        try:
            out = _rss(query_text, window)
            if out:
                meta["source"] = "Google News"
                _remember(key, out)
                return out
        except Exception as ex:
            _log.warning("news fallback (after empty GDELT) failed for %s %s: %s", key_id, window, (str(ex) or type(ex).__name__)[:200])
    out, seen = [], set()
    for a in arts:
        t = " ".join((a.get("title") or "").split())
        k = t.lower()[:80]
        if not t or k in seen:
            continue
        seen.add(k)
        d = a.get("seendate") or ""
        out.append(dict(title=t, url=a.get("url"), domain=a.get("domain"), country=a.get("sourcecountry"),
                        date=f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) >= 8 else "", image=a.get("socialimage")))
    _remember(key, out)
    return out


# ---------------- background refresh (1.4) ----------------
# Pages people actually open are refreshed in the background, so most visits read a fresh cache instead of waiting on GDELT.
# Each fetch records (key, query, window); the warm loop refreshes those viewed in the last 14 days whose copy is over 5 hours old,
# at most 20 per half hour, through the same 5-second gap. Production only (staging shares the server's IP with GDELT's limit).

def _recent_path():
    from . import config
    d = os.path.join(config.DATA_DIR, "news_cache")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "_recent.json")


def _note_view(key_id, query_text, window):
    try:
        p = _recent_path()
        try:
            with open(p) as fh:
                rec = json.load(fh)
        except (OSError, ValueError):
            rec = {}
        rec[f"{key_id}|{window}"] = {"key": key_id, "q": query_text, "w": window, "seen": time.time()}
        if len(rec) > 2000:
            rec = dict(sorted(rec.items(), key=lambda kv: -kv[1]["seen"])[:1500])
        with open(p, "w") as fh:
            json.dump(rec, fh)
    except OSError:
        pass


def warm_once(limit=20):
    try:
        with open(_recent_path()) as fh:
            rec = json.load(fh)
    except (OSError, ValueError):
        return 0
    now, done = time.time(), 0
    for r in sorted(rec.values(), key=lambda r: -r["seen"]):
        if now - r["seen"] > 14 * 86400 or done >= limit:
            break
        hit = _earlier(_key(r["key"], r["q"], r["w"]))
        if hit and now - hit[0] < TTL - 3600:
            continue
        try:
            _cache.pop(_key(r["key"], r["q"], r["w"]), None)
            fetch(r["key"], r["q"], r["w"], meta={"warm": True})
        except Exception:
            pass
        done += 1
    return done


def start():
    from . import config
    from urllib.parse import urlparse
    host = urlparse(config.SITE_URL).hostname or ""
    if not config.SITE_URL.startswith("https://") or "sandbox" in host or host.startswith(("staging.", "localhost", "nexgen.")) \
            or os.environ.get("STAGING") == "1" or getattr(config, "NEXGEN", False):
        return  # production only

    def loop():
        time.sleep(300)
        while True:
            try:
                n = warm_once()
                if n:
                    _log.info("news warm refreshed %d searches", n)
            except Exception as e:
                _log.error("news warm failed: %s", e)
            time.sleep(1800)
    threading.Thread(target=loop, daemon=True).start()
