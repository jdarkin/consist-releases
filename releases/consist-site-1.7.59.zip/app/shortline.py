"""Short line and regional railroads (FRA Class II and III) for the Freight Rail Analytics Portal. Class II and III railroads don't file
STB R-1, so this uses FRA data: Form 55 monthly operations (fra.db fra_ops_year), train accidents and crossing collisions
(fra_accident_year, fra_crossing_inc_year), grade crossings and route miles (fra_crossing_rr, fra_network_owner), plus
seed/fra_shortline.csv.gz for each railroad's FRA class, holding company and reporting state."""
import csv
import functools
import gzip
import os

from . import fra

SEED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "seed", "fra_shortline.csv.gz")
CLASSES = {"1": "Class I", "2": "Class II (regional)", "3": "Class III (short line)"}
# FRA codes the Class I railroads report operations under (FRA Form 55); the seed leaves some of them unclassed.
CLASS1_CODES = {"BNSF", "UP", "NS", "CSX", "CPKC", "KCS", "SOO", "CNRW", "GTW", "IC", "WC", "DMIR", "BLE", "CCP"}
CLASS1_PARENT = {"KCS": "CPKC", "SOO": "CPKC", "CNRW": "CN", "GTW": "CN", "IC": "CN", "WC": "CN", "DMIR": "CN", "BLE": "CN", "CCP": "CN"}
# Field definitions: used for table hover-overs and the definitions page
DEF = {
    "railroad": ("Railroad", "Railroad name and FRA reporting code."),
    "fra_class": ("FRA class", "Class the railroad reports to FRA on Form 55 (most frequent value since 2020). Class II = regional, Class III = short line, by STB revenue thresholds."),
    "holding_company": ("Holding company", "Owner group from the FRA Railroad Master (e.g. Genesee & Wyoming, Watco). Blank = independent or not assigned."),
    "state": ("State", "State where the railroad reports most of its train-miles (Form 55 reporting state)."),
    "train_miles": ("Train-miles", "Freight, passenger and other train-miles plus yard switching miles reported on FRA Form 55 for the year."),
    "road_train_miles": ("Road train-miles", "Freight, passenger and other train-miles, excluding yard switching (Form 55)."),
    "yard_miles": ("Yard switching miles", "Yard switching train-miles (Form 55)."),
    "yard_share": ("Yard share", "Yard switching miles / total train-miles. High values mean a switching or terminal railroad."),
    "employee_hours": ("Employee hours", "Hours worked by all employees, reported on Form 55."),
    "fte": ("Employees (FTE)", "Employee hours / 2,080 hours, a full-time-equivalent headcount estimate."),
    "miles_per_hour": ("Train-miles per employee-hour", "Total train-miles / employee hours. A labor productivity measure."),
    "accidents": ("Train accidents", "FRA-reportable train accidents (collisions, derailments, other) above the damage threshold (Form 54)."),
    "acc_rate": ("Train accidents per M train-miles", "Train accidents / train-miles x 1,000,000. Shown only with 100,000+ train-miles in the year, since small denominators swing widely."),
    "collisions": ("Crossing collisions", "Highway-rail grade crossing collisions (Form 57)."),
    "damage": ("Accident damage", "Reported damage to track, equipment and structures from train accidents, dollars."),
    "crossings": ("Grade crossings", "Open at-grade crossings (public and private) on track the railroad operates, from the FRA crossing inventory (Form 71). Click a count to see those crossings on the map."),
    "route_miles": ("Route miles", "Miles of line the railroad owns, from the national rail network (NTAD North American Rail Network)."),
    "railroads": ("Railroads", "Number of reporting railroads in the group."),
}


@functools.lru_cache(maxsize=1)
def _seed():
    if not os.path.exists(SEED):
        return {}
    with gzip.open(SEED, "rt", newline="") as f:
        out = {r["fra_code"]: r for r in csv.DictReader(f)}
    for c in CLASS1_CODES:
        if c in out:
            out[c] = dict(out[c], fra_class="1")
    return out


def available():
    return fra.available() and bool(_seed())


def _passenger():
    """FRA codes mapped to a passenger operator in fleet.db (commuter agencies FRA files as Class III)."""
    try:
        return {r["fra_code"] for r in fra.q("SELECT fra_code FROM fra_railroad_map WHERE coalesce(operator_id, '') <> ''")}
    except Exception:
        return set()


def _codes():
    px = _passenger() - CLASS1_CODES  # Class Is are mapped to fleet.db too (locomotive data); they are freight
    return [c for c, r in _seed().items() if r["fra_class"] in CLASSES and c not in px]


def years():
    return fra.cached("sl_years", lambda: [r["year"] for r in fra.q("SELECT DISTINCT year FROM fra_ops_year WHERE year >= 2020 ORDER BY year")])


def _data():
    def load():
        codes = _codes()
        if not codes:
            return {}
        ph = ",".join("?" * len(codes))
        out = {}
        for r in fra.q(f"SELECT fra_code, year, total_train_miles, yard_switching_miles, employee_hours FROM fra_ops_year WHERE year >= 2020 AND fra_code IN ({ph})", codes):
            out.setdefault(r["fra_code"], {})[r["year"]] = dict(train_miles=r["total_train_miles"] or 0, yard_miles=r["yard_switching_miles"] or 0,
                                                              employee_hours=r["employee_hours"] or 0, accidents=0, collisions=0, damage=0)
        for r in fra.q(f"SELECT fra_code, year, sum(accidents) a, sum(damage_usd) d FROM fra_accident_year WHERE kind = 'train' AND year >= 2020 AND fra_code IN ({ph}) GROUP BY 1, 2", codes):
            out.setdefault(r["fra_code"], {}).setdefault(r["year"], dict(train_miles=0, yard_miles=0, employee_hours=0, collisions=0)).update(accidents=r["a"] or 0, damage=r["d"] or 0)
        for r in fra.q(f"SELECT fra_code, year, sum(collisions) c FROM fra_crossing_inc_year WHERE year >= 2020 AND fra_code IN ({ph}) GROUP BY 1, 2", codes):
            out.setdefault(r["fra_code"], {}).setdefault(r["year"], dict(train_miles=0, yard_miles=0, employee_hours=0, accidents=0, damage=0))["collisions"] = r["c"] or 0
        # at-grade crossings on track each railroad operates: the same rule the crossings explorer uses for ?rr=, so counts match the map
        static = {r["fra_code"]: r for r in fra.q(f"SELECT fra_code, count(*) crossings FROM fra_crossing WHERE position = 'At Grade' AND fra_code IN ({ph}) GROUP BY fra_code", codes)}
        routes = {r["owner_code"]: r["route_miles"] for r in fra.q(f"SELECT owner_code, route_miles FROM fra_network_owner WHERE owner_code IN ({ph})", codes)}
        return dict(ys=out, crossings={k: v["crossings"] for k, v in static.items()}, routes=routes)
    return fra.cached("sl_data", load)


def _derive(d):
    d = dict(d)
    tm, h = d.get("train_miles") or 0, d.get("employee_hours") or 0
    d["road_train_miles"] = tm - (d.get("yard_miles") or 0)
    d["yard_share"] = 100 * d["yard_miles"] / tm if tm else None
    d["fte"] = h / 2080 if h else None
    d["miles_per_hour"] = tm / h if h else None
    d["acc_rate"] = d.get("accidents", 0) * 1e6 / tm if tm >= 100000 else None
    return d


def railroads(y, cls="", hc=""):
    data, seed = _data(), _seed()
    rows = []
    for code, ys in (data.get("ys") or {}).items():
        s = seed.get(code, {})
        if cls and s.get("fra_class") != cls or hc and s.get("holding_company") != hc:
            continue
        cur = ys.get(y)
        if not cur or not cur.get("train_miles"):
            continue
        r = _derive(cur)
        r.update(fra_code=code, name=s.get("name") or code, fra_class=s.get("fra_class"), holding_company=s.get("holding_company", ""),
                 state=s.get("state", ""), crossings=data["crossings"].get(code), route_miles=data["routes"].get(code))
        rows.append(r)
    return sorted(rows, key=lambda r: -r["train_miles"])


def holding(y, cls=""):
    g = {}
    for r in railroads(y, cls):
        k = r["holding_company"] or "Independent / not assigned"
        a = g.setdefault(k, dict(name=k, railroads=0, train_miles=0, yard_miles=0, employee_hours=0, accidents=0, collisions=0, damage=0, crossings=0, route_miles=0))
        a["railroads"] += 1
        for f in ("train_miles", "yard_miles", "employee_hours", "accidents", "collisions", "damage", "crossings", "route_miles"):
            a[f] += r.get(f) or 0
    return sorted((_derive(a) | {"name": a["name"], "railroads": a["railroads"]} for a in g.values()), key=lambda r: -r["train_miles"])


def totals():
    """Totals by FRA class and year."""
    out = []
    seed = _seed()
    for y in years():
        row = {"year": y}
        for c in CLASSES:
            a = dict(train_miles=0, yard_miles=0, employee_hours=0, accidents=0, collisions=0, damage=0, railroads=0)
            for code, ys in (_data().get("ys") or {}).items():
                if seed.get(code, {}).get("fra_class") == c and ys.get(y, {}).get("train_miles"):
                    a["railroads"] += 1
                    for f in ("train_miles", "yard_miles", "employee_hours", "accidents", "collisions", "damage"):
                        a[f] += ys[y].get(f) or 0
            row[c] = _derive(a)
        out.append(row)
    return out


def railroad(code):
    s = _seed().get(code)
    ys = (_data().get("ys") or {}).get(code)
    if not s or not ys:
        return None
    return dict(code=code, name=s["name"] or code, fra_class=s["fra_class"], holding_company=s["holding_company"], state=s["state"],
                crossings=_data()["crossings"].get(code), route_miles=_data()["routes"].get(code),
                years=[dict(year=y, **_derive(ys[y])) for y in sorted(ys)])


def holding_companies():
    return sorted({r["holding_company"] for r in _seed().values() if r["holding_company"] and r["fra_class"] in CLASSES})


def class_of(op_id):
    """FRA class ('1', '2', '3' or '') for an FRA code or a fleet.db operator id used on the safety pages."""
    from . import fra as F
    code = {v: k for k, v in getattr(F, "LOCO", {}).items()}.get(op_id, op_id)
    r = _seed().get(code)
    return (r or {}).get("fra_class") or ""


def overview(seg="all"):
    """Summary cards for the portal overview, for one operator segment (all, '1', '2', '3'). Each card drills into its data set."""
    from . import fra as F, freight, r1assets, railcars
    cls = seg if seg in CLASSES else ""
    q = f"?cls={cls}" if cls else ""
    lab = CLASSES.get(cls, "freight")
    import datetime
    tot = [t for t in totals() if t["year"] < datetime.date.today().year] or totals()  # latest full year
    last = tot[-1] if tot else None
    y = last["year"] if last else None
    agg = dict(railroads=0, train_miles=0, employee_hours=0, accidents=0, collisions=0)
    for c in ([cls] if cls else list(CLASSES)):
        for k in agg:
            agg[k] += (last or {}).get(c, {}).get(k) or 0
    d = _derive(dict(agg, yard_miles=0))
    seed = _seed()
    cr = (_data().get("crossings") or {})
    crossings = sum(v or 0 for k, v in cr.items() if seed.get(k, {}).get("fra_class") in ([cls] if cls else CLASSES))
    # railroads in the segment with FRA operations and accident reporting on file since 2020 (Form 55 / 54)
    safety_n = sum(1 for code, ys in (_data().get("ys") or {}).items()
                   if (seed.get(code, {}).get("fra_class") in ([cls] if cls else CLASSES)) and any((v.get("train_miles") or 0) > 0 for v in ys.values()))
    # count railroad companies: CN and CPKC report to FRA under several codes
    n_rr = 0
    if last:
        rep = {code for code, ys in (_data().get("ys") or {}).items()
               if seed.get(code, {}).get("fra_class") in ([cls] if cls else CLASSES) and (ys.get(y) or {}).get("train_miles")}
        n_rr = len({CLASS1_PARENT.get(c, c) for c in rep})
    cards = [
        dict(v=f"{n_rr:,}", label=f"{lab if cls else 'FRA-regulated freight'} railroads reporting, {y}", href="/rail/shortlines" + q,
             tip="Railroads\nFreight railroads that filed FRA operations reports (Form 55) for the year. Commuter and passenger operators are excluded. Click for every railroad, filterable by class and holding company."),
        dict(v=f"{agg['train_miles'] / 1e6:,.1f}M", label=f"train-miles, {y}", href="/rail/shortlines" + q, tip="Train-miles\n" + DEF["train_miles"][1]),
        dict(v=f"{d['acc_rate']:.2f}" if d.get("acc_rate") is not None else "–", label=f"train accidents per million train-miles, {y}", href="/rail/safety" if cls in ("", "1") else "/rail/shortlines" + q,
             tip="Accident rate\n" + DEF["acc_rate"][1]),
        dict(v=f"{safety_n:,}" if safety_n is not None else "–", label="railroads reporting FRA safety data since 2020", href="/rail/safety" if cls in ("", "1") else "/rail/shortlines" + q,
             tip="Railroads reporting FRA safety data\nFreight railroads that have filed FRA operations (Form 55) and accident (Form 54) reports in any year since 2020. Click for safety rates by railroad."),
        dict(v=f"{crossings:,.0f}", label="at-grade crossings on their track", href="/rail/crossings" + q,
             tip="Grade crossings\nOpen at-grade crossings on track these railroads operate (FRA crossing inventory). Click for the crossings explorer and map."),
    ]
    if cls in ("", "1"):
        try:
            ct = freight.class1_totals(freight.Cube())
            u = ct[-1] if ct else None
            cards.append(dict(v=f"{u['units']:,.0f}" if u else "–", label=f"Class I locomotives in service, {u['y'] if u else ''}", href="/rail/locomotives",
                              tip="Locomotives\nClass I road and switching locomotives in service at year end (STB R-1 Sched. 710). Click for fleets, duty cycle, costs, retirements and rebuilds."))
        except Exception:
            pass
        ry = r1assets.years()
        cars = r1assets.class1("car_units", ry[-1]) if ry and "car_units" in r1assets.M else None
        les = {}
        try:
            for x in railcars.lessors():
                les[x["company"]] = x["railcars"]
        except Exception:
            pass
        from . import db as _db
        if _db.settings().get("railcars_on") == "1": cards.append(dict(v=f"{(cars or 0) + sum(v or 0 for v in les.values()):,.0f}", label="freight cars reported (Class I fleets + lessor 10-Ks)", href="/rail/railcars",
                          tip="Rolling stock reported\nClass I railroad freight cars in service (R-1 Sched. 710, latest year) plus the railcar fleets GATX, Trinity and Greenbrier report in their latest 10-Ks. Shippers' own cars are not in public filings. Click for freight equipment analysis by owner, car type and reporting mark."))
    else:
        cards.append(dict(v=f"{d['fte']:,.0f}" if d.get("fte") else "–", label=f"employee FTE, {y}", href="/rail/shortlines" + q, tip="Employees (FTE)\n" + DEF["fte"][1]))
        cards.append(dict(v=f"{d['miles_per_hour']:.2f}" if d.get("miles_per_hour") else "–", label="train-miles per employee-hour", href="/rail/shortlines" + q,
                          tip="Labor productivity\n" + DEF["miles_per_hour"][1]))
    return cards
