"""Starter CMS pages. They are inserted once (never overwritten) and are edited in Admin > Content."""
import re

from . import db

# About and methodology text, rewritten 2026-11-02 for the four plans and the freight portal (applied to stored pages by
# the pages_v4 step in seed_pages, which first keeps the old text as unpublished pages about-before-1101n and methodology-before-1101n).
ABOUT_DESC = 'Who we are and what {site} covers: public rail procurement, passenger and transit fleets, and freight rail market data for the US and Canada.'
ABOUT = """
{site} is a rail market intelligence service for the companies that build, maintain, supply and advise rail operators in the
United States and Canada.

Rail work is won years before the RFP. A commuter railroad's coaches come due for a midlife overhaul; an agency's HVAC failures
climb; a freight railroad's locomotive fleet ages past its rebuild cycle. General bid services see the RFP when it lands. We start
from the fleet and the market, and follow the work through to the bid and the award.

## Two platforms, one account

**Passenger and transit, with Bid Catcher.** Every public rail and transit procurement we can find, and the fleets behind it:

- **Bids and awards.** Bid Catcher checks {{agencies}} US and Canadian rail and transit agencies and their procurement platforms
  every day, across vehicles, components, signals, track, power, stations and operations. Each notice is scored for relevance and
  tied to the fleet it concerns. Contract awards record the winner, the price and the bidders where published, and grants show
  the funding behind the next round.
- **Every passenger rail fleet:** commuter and intercity rail, metro, light rail, streetcar, people movers and airport APMs.
  Builder, model, build and rebuild years, active cars and subsystem suppliers such as HVAC, doors, trucks and propulsion.
- **How hard each fleet works and what it costs:** estimated miles per car, maintenance cost per car-mile against peers, price
  paid per car on past orders, and when midlife and engine overhauls come due, with a replacement forecast year by year.

**The Freight Rail Analytics Portal.** Class I, regional and short line railroads:

- STB R-1 financials and operating statistics, the R-1 compared with each parent's 10-K, and weekly EP 724 service metrics
  (train speed, terminal dwell, cars online).
- Locomotive fleets and rebuild timing, freight cars and private (X-mark) car fleets, and the tank car fleet by specification.
- About 620 FRA Class II and III short line and regional railroads, FRA safety records and every grade crossing.
- Freight flows by commodity and lane with forecasts to 2050, Canadian rail traffic, cross-border trains and network density.
- Rail cost indexes: the RCAF, the AAR fuel price index, fuel surcharge analysis and cost escalation forecasts.

Every field and chart in the portal has a plain-English definition on hover.

## Plans

Plans today: {{price_line}}. Paid plans are 20% off when billed yearly. The free plan samples everything on a limited basis,
with no card; saving, alerts and the AI analyst come with a paid plan. See [Pricing](/pricing).

New members can open **Getting started** from the menu for a short guided tour of each part of the site.

## Where the data comes from

Passenger fleet and cost data start from the FTA National Transit Database (public domain), refreshed monthly, and are extended
with researched records from agency documents, railroad filings and trade press, each graded for confidence. Freight data come from
the Surface Transportation Board, the Federal Railroad Administration, the Bureau of Transportation Statistics, Statistics Canada,
the Association of American Railroads and SEC filings. Bids come from agency portals, procurement platforms and Canadian open data
(CanadaBuys, Quebec SEAO). See [Data and methodology](/p/methodology).
"""

METH_DESC = 'How {site} builds its fleet, cost, bid and freight rail data, where each part comes from, and how reliable it is.'
METH = """
## Fleet roster

The base is the National Transit Database Revenue Vehicle Inventory for every rail mode (commuter, hybrid, heavy, light, streetcar,
monorail/AGT, cable car, inclined plane). We map raw model strings to builders and model families, add Amtrak, Brightline,
state-supported services, airport people movers and Canadian systems from agency sources, and grade every record:

| Grade | Meaning |
|---|---|
| A | Agency-reported (NTD or agency document) |
| B | Trade press or manufacturer release |
| C | Secondary source |
| D | Inferred |

Orders and price paid per car draw on agency board documents, manufacturer releases and the APTA Public Transportation Vehicle
Database. From APTA we use derived values only (such as price per car); its tables are not reproduced.

## Duty cycle

Annual miles and hours per car come from the agency's NTD service data, allocated across its fleets by class. Where an agency reports
average lifetime miles, cumulative mileage is reported directly. These are estimates for planning, not odometer readings.

## Costs and escalation

Vehicle maintenance and operating costs are NTD operator/mode totals allocated to each fleet by class-weighted car-miles, in constant
dollars. The benchmark is the median across peer operators of the same class. Treat per-fleet costs as allocations. Escalation
forecasts use US Bureau of Labor Statistics price and wage indexes (PPI, ECI, CPI); the forecasts are {site} estimates.

## Overhaul pipeline and replacement forecast

Midlife overhaul timing uses build year, last rebuild and industry norms (around 20 years for most passenger cars, adjusted for
utilization); end of useful life uses FTA useful life benchmarks; engine overhauls use cited OEM or agency intervals.

## Bids and awards

Bid Catcher reads agency portals, procurement platforms and open data every day. Each notice is scored by keyword rules, then
reviewed by an AI model for relevance to rail work (0-100), category and subsystems, and matched to the agency's fleets. Some
portals block automated reading; for those we use their public feeds and alert emails, ask for permission, or check by hand, and we
never get around a site's robots rules. Awards record the winner, amount and bidders where published. Always confirm bid details on
the issuing agency's portal before you bid.

## Freight rail

The Freight Rail Analytics Portal uses public filings and statistics:

| Module | Source |
|---|---|
| Financials and operating statistics | STB Form R-1 (Class I), parent company 10-K via SEC XBRL |
| Weekly service metrics | STB EP 724 Rail Service Data |
| Short line and regional railroads | FRA Form 55 operations, accidents and crossings for Class II and III railroads |
| Safety and grade crossings | FRA Forms 54, 55a, 57 and the Form 71 crossing inventory |
| Freight and tank cars | STB Public Use Waybill Sample, BTS tank car data, lessor and builder 10-K filings |
| Flows and 2050 outlook | Freight Analysis Framework 5.7.1 (BTS and FHWA) |
| Canada | Statistics Canada rail tables (Open Government Licence - Canada) |
| Border and network | BTS Border Crossing Entry Data and National Transportation Atlas Database |
| Costs and fuel | STB RCAF (computed by AAR), AAR fuel price index, STB EP 661 fuel surcharge reports |

Members see module-by-module detail and limits under About the data in the portal.

## Suppliers and funding

| Module | Source |
|---|---|
| Supplier directory | RSSI (Railway Systems Suppliers, Inc.) public member directory, membership and website only, checked monthly; builder counts derived from the APTA Public Transportation Vehicle Database (APTA's tables are not shown) |
| Supplier financials | SEC 10-K filings (XBRL) for US filers; company annual reports and results releases for Alstom, Siemens Mobility, Knorr-Bremse, CAF, Stadler, Hitachi Rail, Hyundai Rotem, CRRC, Talgo, Nippon Sharyo and Kinki Sharyo, converted to US dollars and marked reported, converted or estimated |
| Funding programs | USAspending.gov awards by Assistance Listing (FRA, FTA, DOT, EPA) and Grants.gov funding notices |
| Reported costs outside the NTD | Agency annual reports and audited statements (VIA Rail, Metrolinx, TTC, TransLink), graded by how closely they match NTD measures |

## Persona tools (version 1.1 and later)

The tools for engineering consultants, tier-1 suppliers, investors, agency planners and lessors add these sources:

| Module | Source |
|---|---|
| Signal and train control | November 2026 sweep of on-board PTC, CBTC, ATC and ETCS for US and Canadian passenger and transit fleets: agency board documents and PTC reports, FRA positive train control pages and Federal Register notices, supplier releases (Hitachi Rail, Wabtec, Siemens Mobility, Alstom, Stadler), trade press (Railway Age, Progressive Railroading, Railway Technology, Railway Track and Structures) and, graded C, Wikipedia. Records read as inferred are graded D and name who to confirm with |
| Subsystem suppliers and platform map | November 2026 subsystem sweep (propulsion, brakes, HVAC, doors, trucks, couplers, passenger information, auxiliary power): agency board and procurement documents, supplier releases and trade press, each row graded with a source link |
| Engineering consultants | Award notices, board minutes and procurement portals read by Bid Catcher; kinds of work are read from the award title; firm websites are the firm's own site, and Wikipedia links go to the firm's article where one exists |
| On-call expiry and capital pipeline | Award dates and terms from Bid Catcher awards; open design, construction, power, station and signal notices from Bid Catcher with the agency's estimated value |
| Replacement procurement stage | Agency capital plans, board documents, RFI and RFP notices and supplier releases, each fleet with a source link and the date checked |
| Orders, backlog, delivery record and option map | Recorded vehicle orders from agency board documents and manufacturer releases; option quantities as published |
| Demand range and cost estimates | Fleet replacement timing from build year and FTA useful life benchmarks; prices escalated with the BLS rolling stock producer price index |
| Funding and rule drivers | FRA (PTC; passenger equipment safety standards, 49 CFR 238), FTA (Transit Asset Management, Buy America, ADA guidance) and EPA locomotive emission standards |
| Reliability, agency finance and lessors | FTA National Transit Database: mechanical failures, peak vehicles, contracted maintenance, operating cost, farebox recovery and vehicle ownership |
| Past RFPs | Closed notices recorded by Bid Catcher |

## Company news

Supplier, operator, short line and engineering consultant pages have a **Recent [name] in the news** button. It lists recent news stories that mention that company.

| | How it works |
|---|---|
| Source | The GDELT Project's public news index (DOC 2.0), which monitors news sites worldwide; free and open. When GDELT is busy, the Google News RSS search feed (used only while its robots.txt allows it), then the last results we saved, up to 30 days old |
| Search | The company's name plus its common short names, combined with rail words (rail, railway, railroad, train, transit, locomotive, metro) so unrelated companies with the same name are filtered out |
| Language | English-language sources |
| Time window | Last 7, 30 or 90 days; 30 days by default |
| Freshness | Results are cached and refreshed every 6 hours; pages people open are refreshed in the background |
| Links | Each headline links to the original publisher's article. {site} does not copy or store article text |

A story may mention the company only in passing, and some local or paywalled outlets are not indexed. Treat the list as a starting point, not a complete record.

## Specification links

Where a public reference exists, fleet and model pages link to a specification page for the vehicle model, usually its Wikipedia article (or the section of a family article that covers the model). These links are references only. {site}'s own fleet counts, dates and estimates come from the sources listed above, and where they differ from the linked page, {site}'s figures are the ones we stand behind. Links were checked on November 6, 2026; models without a reliable page show no link.

## Refresh

NTD-based fleet and cost data and FRA data rebuild monthly; bids are checked daily; R-1 and 10-K data update once a year when the
filings post; the other freight sources are refreshed as each agency publishes.

*For research and planning purposes only. Not financial, legal or engineering advice.*
"""

PAGES = [
    ("about", "page", "About {site}", ABOUT_DESC, ABOUT),
    ("methodology", "page", "Data and methodology", METH_DESC, METH),
    ("terms", "page", "Terms of service", "The terms that apply when you use {site}.", """
*Template: have your counsel review before launch.*

By creating an account you agree to these terms. {site} is provided by Sand & Style, LLC, doing business as {site} ("we"), on a subscription basis.

1. **Accounts.** You are responsible for your login and for activity under your account. Team plans are for the named seats only.
2. **Subscriptions.** Paid plans renew automatically each month or year until cancelled. You can cancel at any time in Account >
   Billing; access continues to the end of the paid period. Fees are non-refundable except where required by law.
3. **Data use.** You may use the data for your own business. You may not resell, republish or bulk-redistribute it, or use automated
   scraping of the service.
4. **Accuracy.** Data is compiled from public and third-party sources and estimates. It is provided as-is, for research and planning,
   without warranty. Always confirm bid details on the issuing agency's portal before bidding.
5. **Liability.** To the extent the law allows, our liability is limited to the fees you paid in the twelve months before the claim.
6. **Changes.** We may update these terms and will notify subscribers by email of material changes.
"""),
    ("privacy", "page", "Privacy policy", "How {site} handles your personal information.", """
*Template: have your counsel review before launch.*

We collect the information you give us (name, email, company, saved searches) and usage data needed to run the service. Payments are
processed by Stripe; we never see or store your full card number. We use your email to send the alerts you set up and account notices.
We do not sell personal information. You can delete your account at any time by contacting support. Questions:
{support_email}.
"""),
    ("find-rail-car-overhaul-bids", "post", "How to find rail car overhaul bids in the US and Canada",
     "Where rail agencies post rolling stock overhaul, parts and maintenance bids, and how to make sure you see them in time.", """
Rail agencies do not publish their bids in one place. A single commuter railroad may post a truck overhaul on Bonfire, a parts contract
on its own website and a vehicle procurement in a state contract register. Here is how the market actually works.

## The platforms rail agencies use

- **Bonfire**: Metra, CTA, NFTA, DART, Houston METRO, Caltrain and others.
- **OpenGov Procurement**: RTD Denver, VTA, Valley Metro and many airports.
- **PlanetBids**, **BidNet Direct**, **Bid Express** (NJ Transit) and agency-run systems such as SEPTA ePS and MBTA's Business Center.
- **Open data in Canada**: CanadaBuys (federal) and SEAO (Quebec).

Most require a free supplier registration with commodity codes before they email you. For rolling stock work, pick NAICS 336510 (railroad rolling stock
manufacturing) and 488210 (support activities for rail transportation), and every NIGP or UNSPSC code for rail car parts, repair and
maintenance that the platform's picker offers.

## What to watch for

Midlife overhauls, truck and wheelset programs, HVAC and door operator rebuilds, traction motor repair, onboard systems retrofits
(PIS, CCTV, PTC), and shop equipment such as wheel truing machines.

## Do it faster

{site} watches {{agencies}} rail agencies across all these platforms, scores every notice for rail relevance, and emails you the ones that match
your saved searches, with the fleet each bid concerns. [Start free](/signup).
"""),
    ("midlife-overhaul-timing", "post", "When do rail cars need a midlife overhaul?",
     "Midlife overhaul timing for commuter coaches, metro cars and light rail vehicles, and how utilization moves it.", """
Most passenger rail cars get a heavy overhaul around the middle of their service life: roughly 15 to 20 years for commuter coaches and
metro cars, and 12 to 18 years for light rail vehicles. Locomotive prime movers follow their own cycle, often 8 to 10 years or about
500,000 miles.

## What drives the timing

- **Utilization.** A car running 90,000 miles a year wears trucks, doors and HVAC far faster than one running 30,000.
- **Environment.** Heat, salt and tunnel dust shorten component life.
- **Obsolescence.** Electronics (TCMS, propulsion control, PIS) often force the program before the mechanical systems do.
- **Funding.** Many agencies time overhauls to capital grant cycles.

## See it for every fleet

{site}'s overhaul pipeline combines build year, last rebuild and estimated miles per car to project when each fleet comes
due, by year and by type. [See upcoming work](/app/work).
"""),
]


# Passages rewritten for the 2026-10 market lenses. Applied once to stored pages, and only where the old wording is still there.
USAGE_PRIVACY = """## Usage logs

To run and improve the service, we keep a log of the pages you view and the features you use (for example searches, exports, alerts
and AI questions) on our own servers. For signed-in members the log is tied to your account. For visitors who are not signed in it
is not: we group visits by a daily code made from a shortened IP address and browser type, without cookies, so a visitor can't be
followed from one day to the next. We store only a shortened IP address, never the full one. We keep these logs for about 13 months
and don't share or sell them."""


PAGE_REVISIONS = [
    ('{site} is a rail fleet and procurement intelligence service for the companies that build, maintain and supply passenger rail vehicles in\nthe United States and Canada.',
     '{site} is a rail fleet and procurement intelligence service for the companies that build, maintain and supply rail fleets in\nthe United States, Canada and Mexico: transit, passenger rail and freight.'),
    ('- **Every passenger rail fleet** in the US and Canada: commuter and intercity rail, metro, light rail, streetcar, people movers and\n  airport APMs. Builder, model, build and rebuild years, active cars, subsystem suppliers, power supply.',
     '- **Every rail fleet** in the US, Canada and Mexico: commuter and intercity rail, metro, light rail, streetcar, people movers,\n  airport APMs and freight locomotives from Class I to short line. Builder, model, build and rebuild years, active units, subsystem\n  suppliers, power supply.'),
    ('- **Every relevant bid** from 128 rail agencies and their procurement platforms, scored for relevance to rail vehicles, plus contract\n  awards with winners and prices.',
     '- **Every relevant bid** from 128 rail agencies and their procurement platforms across vehicles, signals, track, power, stations and\n  operations, scored for relevance, plus contract awards with winners and prices.'),
    ('Fleet and cost data start from the FTA National Transit Database (public domain), refreshed monthly, and are extended with researched\nrecords from agency documents and trade press, each graded for confidence.',
     'Fleet and cost data start from the FTA National Transit Database (public domain), refreshed monthly, and STB Form R-1 reports for\nfreight railroads, and are extended with researched records from agency documents, railroad filings and trade press, each graded for\nconfidence.'),
    ('to project when each US and Canadian fleet comes\ndue, by year and by type. [See the pipeline](/app/pipeline).',
     'to project when each fleet comes\ndue, by year and by type. [See upcoming work](/app/work).'),
]


# Freight parked (2026-10-28): the about page goes back to passenger rail. Applied once, only where the wording is unchanged.
PAGE_REVISIONS_V3 = [
    ('the United States, Canada and Mexico: transit, passenger rail and freight.',
     'the United States, Canada and Mexico: transit and passenger rail.'),
    ('- **Every rail fleet** in the US, Canada and Mexico: commuter and intercity rail, metro, light rail, streetcar, people movers,\n  airport APMs and freight locomotives from Class I to short line. Builder, model, build and rebuild years, active units, subsystem\n  suppliers, power supply.',
     '- **Every passenger rail fleet** in the US, Canada and Mexico: commuter and intercity rail, metro, light rail, streetcar, people\n  movers and airport APMs. Builder, model, build and rebuild years, active units, subsystem suppliers, power supply.'),
    ('Fleet and cost data start from the FTA National Transit Database (public domain), refreshed monthly, and STB Form R-1 reports for\nfreight railroads, and are extended with researched records from agency documents, railroad filings and trade press, each graded for\nconfidence.',
     'Fleet and cost data start from the FTA National Transit Database (public domain), refreshed monthly, and are extended with\nresearched records from agency documents, railroad filings and trade press, each graded for confidence.'),
]


def seed_pages():
    s = db.settings()
    fmt = dict(site=s.get("site_name", "Consist"), support_email=s.get("support_email", ""))
    for slug, kind, title, desc, body in PAGES:
        db.x("INSERT OR IGNORE INTO page (slug, kind, title, description, body, published, updated) VALUES (?,?,?,?,?,1,?)",
             (slug, kind, title.format(**fmt), desc.format(**fmt), body.strip().format(**fmt), db.now()))
    if not s.get("pages_v2"):
        for r in db.q("SELECT slug, body FROM page"):
            body = r["body"] or ""
            new = body
            for old, rep in PAGE_REVISIONS:
                new = new.replace(old.format(**fmt), rep.format(**fmt))
            if new != body:
                db.x("UPDATE page SET body = ?, updated = ? WHERE slug = ?", (new, db.now(), r["slug"]))
        db.set_setting("pages_v2", "1")
    if not db.settings().get("pages_v3"):
        for r in db.q("SELECT slug, body FROM page"):
            body = r["body"] or ""
            new = body
            for old, rep in PAGE_REVISIONS_V3:
                new = new.replace(old, rep)
            if new != body:
                db.x("UPDATE page SET body = ?, updated = ? WHERE slug = ?", (new, db.now(), r["slug"]))
        db.set_setting("pages_v3", "1")
    if not db.settings().get("pages_claims_v1"):  # hard agency counts in stored pages follow the live count from now on
        from . import claims
        for r in db.q("SELECT slug, body, description FROM page"):
            body, desc = claims.tokenize_agencies(r["body"]), claims.tokenize_agencies(r["description"])
            if (body, desc) != (r["body"] or "", r["description"] or ""):
                db.x("UPDATE page SET body = ?, description = ?, updated = ? WHERE slug = ?", (body, desc, db.now(), r["slug"]))
        db.set_setting("pages_claims_v1", "1")
    if not db.settings().get("no_mexico_pages_v1"):  # Mexico parked 2026-10-30; runs after the older revisions above
        for r in db.q("SELECT slug, title, description, body FROM page"):
            t, d, b = db.drop_mexico(r["title"]), db.drop_mexico(r["description"]), db.drop_mexico(r["body"])
            if (t, d, b) != (r["title"] or "", r["description"] or "", r["body"] or ""):
                db.x("UPDATE page SET title = ?, description = ?, body = ?, updated = ? WHERE slug = ?", (t, d, b, db.now(), r["slug"]))
        db.set_setting("no_mexico_pages_v1", "1")
    if not db.settings().get("pages_v4"):  # 2026-11-02: about and methodology rewritten; the old text is kept, unpublished
        new = {"about": (ABOUT_DESC, ABOUT), "methodology": (METH_DESC, METH)}
        for slug, (desc, body) in new.items():
            r = db.q("SELECT * FROM page WHERE slug = ?", (slug,), one=True)
            if not r or (r["body"] or "") == body.strip().format(**fmt):
                continue
            db.x("INSERT OR IGNORE INTO page (slug, kind, title, description, body, published, updated) VALUES (?,?,?,?,?,0,?)",
                 (slug + "-before-1101n", r["kind"], (r["title"] or "") + " (before 2026-11-02)", r["description"], r["body"], db.now()))
            db.x("UPDATE page SET description = ?, body = ?, updated = ? WHERE slug = ?",
                 (desc.format(**fmt), body.strip().format(**fmt), db.now(), slug))
        db.set_setting("pages_v4", "1")
    if not db.settings().get("pages_v5_suppliers"):  # 2026-11-03: add the supplier and funding sources to the stored methodology page
        r = db.q("SELECT body FROM page WHERE slug = 'methodology'", one=True)
        add = METH[METH.index("## Suppliers and funding"):METH.index("## Refresh")]
        if r and "## Suppliers and funding" not in (r["body"] or ""):
            b = r["body"] or ""
            b = b.replace("## Refresh", add + "## Refresh", 1) if "## Refresh" in b else b.rstrip() + "\n\n" + add
            db.x("UPDATE page SET body = ?, updated = ? WHERE slug = 'methodology'", (b, db.now()))
        db.set_setting("pages_v5_suppliers", "1")
    if not db.settings().get("pages_v6_dba"):  # 2026-11-04: Consist registered as a fictitious name of Sand & Style, LLC
        # Exact-phrase swaps only, so the admin's own wording in the stored Terms and Privacy pages is otherwise left alone.
        swaps = [('Sand & Style, LLC ("we")', 'Sand & Style, LLC, doing business as {site} ("we")'),
                 ('Sand & Style, LLC, a Florida limited liability company ("we"',
                  'Sand & Style, LLC, a Florida limited liability company doing business as {site} ("we"')]
        site = db.settings().get("site_name", "Consist")
        for r in db.q("SELECT slug, body FROM page WHERE slug IN ('terms', 'privacy')"):
            body = r["body"] or ""
            new = body
            for old, rep in swaps:
                if "doing business as" not in new:
                    new = new.replace(old, rep.format(site=site), 1)
            if new != body:
                db.x("UPDATE page SET body = ?, updated = ? WHERE slug = ?", (new, db.now(), r["slug"]))
        db.set_setting("pages_v6_dba", "1")
    if not db.settings().get("pages_v7_usage"):  # 2026-11-04: Admin > Usage logs page views and actions on our own server
        r = db.q("SELECT body FROM page WHERE slug = 'privacy'", one=True)
        if r and "usage log" not in (r["body"] or "").lower():
            b = r["body"] or ""
            para = "**Usage logs.** " + USAGE_PRIVACY.split("\n\n", 1)[1]
            m = re.search(r"^## *3\.", b, re.M)  # the full policy: add it to section 2, "Information collected automatically"
            b = (b[:m.start()] + para + "\n\n" + b[m.start():]) if m else (b.rstrip() + "\n\n" + USAGE_PRIVACY)
            db.x("UPDATE page SET body = ?, updated = ? WHERE slug = 'privacy'", (b, db.now()))
        db.set_setting("pages_v7_usage", "1")
    if not db.settings().get("pages_v8_news"):  # 2026-11-05: explain the "Recent ... in the news" buttons on the stored methodology page
        r = db.q("SELECT body FROM page WHERE slug = 'methodology'", one=True)
        add = METH[METH.index("## Company news"):METH.index("## Refresh")].replace("{site}", db.settings().get("site_name", "Consist"))
        if r and "## Company news" not in (r["body"] or ""):
            b = r["body"] or ""
            b = b.replace("## Refresh", add + "## Refresh", 1) if "## Refresh" in b else b.rstrip() + "\n\n" + add
            db.x("UPDATE page SET body = ?, updated = ? WHERE slug = 'methodology'", (b, db.now()))
        db.set_setting("pages_v8_news", "1")
    if not db.settings().get("pages_v9_specs"):  # 2026-11-06: specification links on fleet and model pages
        r = db.q("SELECT body FROM page WHERE slug = 'methodology'", one=True)
        add = METH[METH.index("## Specification links"):METH.index("## Refresh")].replace("{site}", db.settings().get("site_name", "Consist"))
        if r and "## Specification links" not in (r["body"] or ""):
            b = r["body"] or ""
            b = b.replace("## Refresh", add + "## Refresh", 1) if "## Refresh" in b else b.rstrip() + "\n\n" + add
            db.x("UPDATE page SET body = ?, updated = ? WHERE slug = 'methodology'", (b, db.now()))
        db.set_setting("pages_v9_specs", "1")
    if not db.settings().get("pages_v10_persona"):  # 2026-11-07 (1.2): sources behind the persona tools and consultant news
        r = db.q("SELECT body FROM page WHERE slug = 'methodology'", one=True)
        add = METH[METH.index("## Persona tools"):METH.index("## Company news")].replace("{site}", db.settings().get("site_name", "Consist"))
        if r and "## Persona tools" not in (r["body"] or ""):
            b = r["body"] or ""
            for at in ("## Company news", "## Specification links", "## Refresh"):
                if at in b:
                    b = b.replace(at, add + at, 1)
                    break
            else:
                b = b.rstrip() + "\n\n" + add
            b = b.replace("Supplier, operator and short line pages have a **Recent [name] in the news** button.",
                          "Supplier, operator, short line and engineering consultant pages have a **Recent [name] in the news** button.")
            db.x("UPDATE page SET body = ?, updated = ? WHERE slug = 'methodology'", (b, db.now()))
        db.set_setting("pages_v10_persona", "1")
    if not db.settings().get("pages_v11_newsfallback"):  # 2026-11-07 (1.4): news fallback source and background refresh
        r = db.q("SELECT body FROM page WHERE slug = 'methodology'", one=True)
        if r and r["body"] and "Google News" not in r["body"]:
            b = r["body"].replace("| Source | The GDELT Project's public news index (DOC 2.0), which monitors news sites worldwide; free and open |", "| Source | The GDELT Project's public news index (DOC 2.0), which monitors news sites worldwide; free and open. When GDELT is busy, the Google News RSS search feed (used only while its robots.txt allows it), then the last results we saved, up to 30 days old |")
            b = b.replace("| Freshness | Results are cached and refreshed every 6 hours |",
                          "| Freshness | Results are cached and refreshed every 6 hours; pages people open are refreshed in the background |")
            db.x("UPDATE page SET body = ?, updated = ? WHERE slug = 'methodology'", (b, db.now()))
        db.set_setting("pages_v11_newsfallback", "1")


# Solutions pages, one per persona (/solutions/<slug>). Each shows that seller's live home dashboard as a preview.
SOLUTIONS = {
    "rolling-stock": {
        "hook": 'You found the RFP. So did everyone else. Three weeks late.', "punch": 'Railcars wear out. We know which ones are wearing out first, so you hear about the order before your competitor does.',
        "persona": "oem", "title": "Rail car and locomotive procurement intelligence", "nav": "Rolling stock builders",
        "h1": "Know which agencies and railroads will buy cars and locomotives, before the RFP",
        "lead": "Replacement timing for every rail fleet in the US and Canada, options left on existing orders, funding as it is awarded, and what your competitors are winning.",
        "who": "Business development, bid and proposal, and market intelligence teams at car builders and locomotive makers.",
        "questions": [
            ("Which fleets reach the end of their useful life in the next five years?",
             "Upcoming work ranks every fleet by build year, useful-life benchmark, duty cycle and the agency's own capital plan, with car counts and an estimated contract value."),
            ("How many options are left on orders my competitors hold?",
             "Each recorded order shows base cars and the options still open, so you can see which contracts are about to run dry and which agencies will need a new procurement."),
            ("Who just got funding to buy vehicles?",
             "Federal and state grant awards are tied to the operator and its fleets, so a funding announcement shows you which fleet it is for."),
        ],
    },
    "components": {
        "hook": "Your competitor's doors are on somebody's fleet. Find out whose.", "punch": "Every fleet, every supplier, every subsystem. Then go be nicer to the agencies running the other guy's parts.",
        "persona": "component", "title": "Rail HVAC, door and brake supplier fleet data", "nav": "Component and subsystem suppliers",
        "h1": "See every fleet your doors, HVAC, brakes or propulsion are on, and when they come up for overhaul",
        "lead": "Subsystem supplier mapping by fleet, installed-base share by supplier, the new car orders still choosing suppliers, and the overhaul and repair bids that follow. One view across agencies, car builders and overhaul shops.",
        "who": "Sales and aftermarket teams at tier-1 subsystem suppliers: brakes, doors, HVAC, couplers, propulsion, TCMS, passenger information and CCTV.",
        "questions": [
            ("Which fleets carry my product, and which carry my competitor's?",
             "Subsystems maps suppliers to fleets with the car count, install year and source, and shows each supplier's share of the installed base."),
            ("When do those fleets come due for midlife or component overhaul?",
             "Each mapped fleet carries a projected next overhaul from its age, duty cycle and the industry interval for that subsystem."),
            ("Where are the repair and parts bids for my trade right now?",
             "The bid feed filters to your trades, such as component repair, parts supply and onboard systems, and alerts you as new notices appear."),
        ],
    },
    "overhaul-mro": {
        "hook": "Midlife overhauls don't sneak up on you. They just feel that way.", "punch": "See which fleets are due, what the work should cost and who is overdue. Hint: it's a lot of them.",
        "persona": "mro", "title": "Rail car midlife overhaul bids and timing", "nav": "Overhaul and MRO shops",
        "h1": "Find the fleets entering their overhaul window, and the agencies paying the most to maintain them",
        "lead": "Duty cycle and maintenance cost per car-mile for every fleet, overhaul due dates, and the overhaul and maintenance bids as they post.",
        "who": "Rebuild shops, truck and component overhaul houses and contract maintenance firms.",
        "questions": [
            ("Which fleets are in or near their midlife overhaul window?",
             "Upcoming work lists overhauls and rebuilds by year, with cars, age, miles per car and the signals behind each estimate."),
            ("Which agencies spend the most per car-mile on maintenance?",
             "Cost benchmarks compares maintenance cost per car revenue-mile with peers of the same mode, in constant dollars."),
            ("What overhaul and maintenance work is out for bid?",
             "The bid feed shows overhaul programs, component repair and maintenance services, scored for rail relevance."),
        ],
    },
    "freight-equipment": {
        "hook": 'Every Class I files how many locomotives it bought, rebuilt and retired. Nobody reads it. We did.', "punch": 'See whose fleet is getting old, who is rebuilding instead of buying, and the year the math flips.',
        "persona": "freight", "title": "Freight locomotive fleet data for suppliers", "nav": "Freight locomotive suppliers",
        "h1": "Every Class I, regional and short line locomotive fleet, with cost and use from the railroads' own filings",
        "lead": "Locomotive rosters by model and build year, STB R-1 cost, miles and rebuild history for each Class I, and the modernization programs under way.",
        "who": "Locomotive builders and modernizers, aftermarket parts suppliers, lessors and engine and traction suppliers.",
        "questions": [
            ("How old is each railroad's roster, and which models are due for modernization?",
             "Each railroad page breaks the roster down by model and build year, with the share of the fleet each model holds."),
            ("How hard are those locomotives worked, and what do they cost to run?",
             "STB R-1 data gives miles per unit, repairs per unit-mile and all-in cost per unit-mile for every Class I since 2013, in 2025 dollars."),
            ("How many units are railroads rebuilding each year, and at what cost?",
             "Rebuilt and new unit counts and costs from R-1 Schedule 710S show the pace of each railroad's modernization program."),
        ],
    },
    "signals-track-power": {
        "hook": "You don't sell trains. You sell everything trains can't run without.", "punch": 'Bids for signals, track, traction power and stations, sorted by the trades you actually do. No more digging through janitorial contracts.',
        "persona": "systems", "title": "Rail signals, track and traction power bids", "nav": "Signals, track and power",
        "h1": "Rail bids for train control, track, traction power and stations, from every agency that issues them",
        "lead": "Open bids in your trades across transit and passenger rail agencies, with funding and awards for the operators behind them.",
        "who": "Signalling and train control suppliers, track and civil contractors, traction power and station contractors, and O&M operators.",
        "questions": [
            ("What signals, track and power work is out for bid now?",
             "Pick your trades once and the bid feed shows those notices first, from agency portals and procurement platforms across the US and Canada."),
            ("Which operators just got funding for capital work?",
             "Funding and awards ties each grant to its operator, so you can see who has money to spend."),
            ("Who has been winning this work, and at what price?",
             "Award history shows winners, amounts and bidder counts by category and agency on paid plans."),
        ],
    },
    "engineering-consultants": {
        "hook": "By the time the RFQ posts, the shortlist is already in somebody's head.", "punch": "See the RFQs, on-calls and awards for signals, systems and design work, who holds them now, and which agencies just got the money.",
        "persona": "consult", "title": "Rail engineering and signal consulting opportunities", "nav": "Engineering consultants",
        "h1": "Find the signals, systems and design work before your competitors do, and see who holds it now",
        "lead": "Open RFQs and on-call solicitations for engineering, signals and systems work, recent awards and their winners, and the grants that fund the next round.",
        "who": "Business development leads at engineering firms that design, manage and inspect signals, train control, systems and civil work for transit and commuter agencies.",
        "questions": [
            ("Which engineering and signal RFQs are out now, and when are questions due?",
             "The bid feed filters to engineering, signals and systems work, with closing dates and the agency behind each notice."),
            ("Who won the last round of this work, and for how much?",
             "Award history shows winners, amounts and bidder counts by agency and category, so you know the incumbent before you pursue."),
            ("Which agencies just got funding for signal and capital work?",
             "Funding and awards ties federal grants to each agency, so you can see who has money to spend in the next 12 to 36 months."),
        ],
    },
    "investors": {
        "hook": "The companies report backlog once a quarter. The orders happen every week.", "punch": "North American passenger rail orders, backlog and share by builder, with a source on every row and a download button.",
        "persona": "investor", "title": "Rail rolling stock orders, backlog and market share data", "nav": "Investors and analysts",
        "h1": "Track North American passenger rail orders, backlog and market share by builder",
        "lead": "Every recorded vehicle order with quantities, value and price per car, backlog still to deliver, share of new orders over time, and replacement demand for the next decade.",
        "who": "Equity and credit analysts, private equity and M&A teams, and market intelligence groups covering rail equipment makers and suppliers.",
        "questions": [
            ("Who is winning North American passenger orders, and is share shifting?",
             "Orders and backlog charts cars ordered by builder and year, and share of new orders over the last five years."),
            ("How much is still to deliver, and for whom?",
             "Backlog by builder counts cars and value on orders not yet delivered, with the order list behind it."),
            ("How big is the replacement market over the next ten years?",
             "Replacement demand counts cars reaching end of useful life or planned replacement each year, with values at recorded unit costs."),
        ],
    },
    "agencies": {
        "hook": "Your board asks how you compare. Your peers are busy too.", "punch": "Fleet age, cost per car-mile, reliability and replacement exposure against a peer group you choose, ready for the board deck.",
        "persona": "agency", "title": "Rail fleet peer benchmarking for transit agencies", "nav": "Transit agencies",
        "h1": "Benchmark your rail fleets and costs against your peers, and plan the next buy",
        "lead": "A peer scorecard built from NTD and fleet records, what peers paid for new cars and overhauls, and when every fleet reaches midlife and end of life.",
        "who": "Fleet, mechanical, capital planning, asset management and grants staff at public transit and commuter rail agencies, and the consultants who support them.",
        "questions": [
            ("How do our fleet age, costs and reliability compare with our peers?",
             "The peer scorecard ranks your agency against a suggested or hand-picked peer group, with exports for board reports."),
            ("What did peers pay for new cars and overhauls?",
             "Vehicle orders and award history show quantities, values and price per car by vehicle type and year."),
            ("When will each of our fleets need an overhaul or replacement?",
             "Every fleet carries a projected midlife and end-of-life year from its age, duty cycle and useful-life benchmark."),
        ],
    },
}


# One-line pitches under each plan on the pricing page (copy only; the plans themselves are edited in Admin > Plans).
PLAN_QUIPS = {
    "free": "Free. As in, stop complaining.",
    "fleet_explorer": "Forecasts, market share and fleet lists for every market. No bids. You're here for the trains.",
    "pro": "Every transit fleet and every rail bid. One seat, zero excuses.",
    "team": "Five seats and a CRM export, so your sales manager can stop asking you for \"a quick list.\"",
    "freight_analyst": "Six Class Is, one seat, no more PDFs from the STB.",
    "freight_team": "Five seats, so the whole desk can stop rebuilding the same comp table.",
    "enterprise": "Passenger and freight, the whole continent. For people who get asked about all of it.",
}


def solutions():
    """The Solutions pages this viewer can see: the freight one only while freight is visible (see lens.py)."""
    from . import lens
    ok = lens.personas()
    return {k: v for k, v in SOLUTIONS.items() if v["persona"] in ok}


FREIGHT_HOME = {
    "freight_kicker": "Freight Rail Analytics Portal",
    "freight_title": "Is your business in freight railroading? We have that too.",
    "freight_text": "Six Class I railroads file what they spend, buy, rebuild and retire with the STB every year. Almost nobody reads it. "
                    "We read all of it, {years}, and put it next to their 10-K financials, locomotive fleets, who owns the freight cars, "
                    "fuel surcharges, the STB rail cost index, 600+ regional and short line railroads, FRA safety records and every grade crossing in the country. Every number has a definition one hover away. "
                    "Separate portal, same login.",
    "freight_cta": "See the Freight Rail Analytics Portal",
}


def freight_cards(raw):
    """Admin text ("Title | text", one card per line) -> [(title, text)]; blank or unreadable -> the built-in cards."""
    cards = [tuple(x.strip() for x in ln.split("|", 1)) for ln in (raw or "").splitlines() if "|" in ln]
    out = [c for c in cards if c[0] and c[1]] or FREIGHT_FEATURES
    if db.settings().get("railcars_on") != "1":  # module switched off in Admin > Settings > General
        out = [c for c in out if c[0] != "Freight cars by owner"]
    return out


# What the Freight Rail Analytics Portal includes, for the home page band and the freight block on /pricing.
FREIGHT_FEATURES = [
    ("Class I R-1 scoreboard", "Costs, capex and operating stats by line item for every Class I, straight from the STB R-1 filings."),
    ("Locomotive fleets", "Units by model, builder and age, rebuilds vs new buys, retirements and cost per unit-mile."),
    ("Freight cars by owner", "Private (X-mark), railroad and TTX shares of traffic by car type and commodity, accidents by reporting mark, lessor fleets and the tank car transition."),
    ("Fuel, surcharges and cost escalation", "Each Class I's fuel bill against its fuel surcharge revenue every quarter, the AAR fuel index, and the STB Rail Cost Adjustment Factor, with costs restated in rail-cost dollars."),
    ("Financials and investor reporting", "Income statement, balance sheet, cash flow and operating ratio, all Class Is side by side, plus parent 10-K figures and investor-site links."),
    ("Short lines and regionals", "Every FRA Class II and III freight railroad: train-miles, crew hours, accidents and crossings, by holding company."),
    ("FRA safety rates", "Train accidents and crossing collisions per million train-miles, and what caused them."),
    ("Grade crossings", "Every US grade crossing on a map with warning devices, train counts and collision history since 2010."),
    ("Definitions on every number", "Hover any column, tile or chart for what it means and where it comes from, plus a full definitions page."),
    ("Exports", "Download the R-1, freight car, fuel, short line, safety and crossing tables as CSV."),
]

# 1.7.25 (Justin approved 2026-11-11): uploads wording, appended once to the live Privacy and Terms pages by db.init (flag legal_uploads_1111)
PRIVACY_UPLOADS = """
## Documents you upload

On plans that include the AI analyst, you can attach a document (such as a PDF or Word file) to a question.

- **We keep a copy.** We store the file and the text we read from it in our data repository, linked to your account, so you can use it again with later questions. You can delete an upload at any time from the AI analyst page, which removes the file and its text from the Service. Copies may remain in our encrypted backups for up to 12 months.
- **It stays private to you.** Other members cannot see your uploads, and the AI analyst never uses them to answer anyone else's questions. Our administrators can see uploads only to run, support and secure the Service.
- **We don't sell or share it.** We do not sell your uploads or any of your data, and we do not share them with other members or third parties, except service providers that process data for us under contract. For example, the text of your document is sent to our AI provider, Anthropic, to answer your question; under its commercial terms it does not use that data to train its models.
- **We use it to improve the Service.** We may use your uploads, questions and usage to improve how the Service works for everyone, for example to check the accuracy of our data, find gaps in our coverage and improve the analyst's answers. Nothing that identifies you or your company is shown to other members.
- **Public records.** If a document you upload is a public procurement record issued by a public agency (for example an agency's RFP, RFQ or tender), we may add its public details (agency, title, reference number, dates and description) to our bid records, the same way as notices we collect ourselves. The record never says who uploaded it.
- **Please upload only what you may share.** Don't upload documents that are confidential to someone else, or that contain personal information we don't need.
"""
TERMS_UPLOADS = """
**Uploaded documents.** You keep ownership of documents you upload. You confirm you have the right to share them with us, and you give us a license to store, process and analyze them to provide and improve the Service, as described in our Privacy policy. Where a document is a public procurement record of a public agency, you agree we may add its public details to the Service's bid records without naming you. You can delete your uploads at any time.
"""

# 1.7.41 (Justin asked 2026-11-12): LinkedIn Insight Tag wording. Exact-phrase swaps into the stored Privacy page, applied once by db.init
# (flag legal_linkedin_1112); the old body is kept as the unpublished page privacy-before-1112. The same swaps were made to
# project-files/fleet-db/legal/consist-privacy-policy.txt. If the "No advertising cookies" paragraph is not there, PRIVACY_LINKEDIN is
# appended as its own section instead.
PRIVACY_LINKEDIN = """**Cookie choices and LinkedIn advertising.** On our public pages (not inside the signed-in app, account or admin pages), and only if you click Accept on our cookie banner, we use the LinkedIn Insight Tag, a small script from LinkedIn Corporation (LinkedIn Ireland Unlimited Company for visitors in the EU, EEA and Switzerland). If you decline, or your browser sends a Global Privacy Control signal, the tag does not load. You can change your choice at any time with the "Cookie choices" link in the site footer. When it runs, LinkedIn sets or reads cookies (such as "bcookie", "li_sugr", "lidc", "UserMatchHistory" and "AnalyticsSyncHistory") and receives your IP address, browser details, the page you are on and the page that referred you. We use it for three things:
- **Aggregated visitor demographics.** LinkedIn shows us reports about visitors in aggregate, such as industry, job function, seniority and company size. We never see who you are or your LinkedIn profile.
- **Retargeting.** LinkedIn may show our ads on LinkedIn to people who visited our site.
- **Conversion tracking.** We count how many people who saw or clicked our LinkedIn ads went on to visit key pages or sign up, so we can measure our advertising.

LinkedIn processes this data under its own privacy policy (https://www.linkedin.com/legal/privacy-policy) and cookie policy (https://www.linkedin.com/legal/cookie-policy). LinkedIn members can also turn off ads based on other websites in their LinkedIn ad settings (https://www.linkedin.com/psettings/advertising), and anyone can opt out of LinkedIn retargeting at https://www.linkedin.com/psettings/guest-controls/retargeting-opt-out. We do not use any other advertising cookies or tracking pixels, and we do not sell your information."""

PRIVACY_LINKEDIN_SWAPS = [
    ("**No advertising cookies.** We do not use advertising cookies or tracking pixels, and we do not sell your information or share it for cross-context behavioral advertising.",
     PRIVACY_LINKEDIN),
    ("Google (analytics and web fonts, as described above).",
     "Google (analytics and web fonts, as described above) and LinkedIn (advertising measurement and retargeting, as described in section 2, only if you accept advertising cookies)."),
    ("- **Google Analytics cookies:** up to 2 years, set by Google; you can delete them at any time in your browser.",
     "- **Google Analytics cookies:** up to 2 years, set by Google; you can delete them at any time in your browser.\n- **LinkedIn cookies (only if you accept):** from 1 day up to 1 year depending on the cookie, set by LinkedIn; you can delete them in your browser or change your choice with Cookie choices in the footer. Your cookie choice itself is stored in your browser (\"consist_ads_consent\") until you clear it."),
    ("We do not sell or share personal information as those terms are defined in California law.",
     "We do not sell personal information. If you accept LinkedIn advertising cookies, the data the LinkedIn Insight Tag collects may count as \"sharing\" for cross-context behavioral advertising under California law; you can opt out at any time by choosing Decline in Cookie choices in the footer, and we treat a Global Privacy Control signal from your browser as an opt-out."),
    ("You can unsubscribe from alert emails by changing your alert settings.",
     "You can unsubscribe from alert emails by changing your alert settings. You can accept or decline LinkedIn advertising cookies at any time with the Cookie choices link in the site footer, and opt out of LinkedIn retargeting at https://www.linkedin.com/psettings/guest-controls/retargeting-opt-out."),
]


def privacy_with_linkedin(body):
    """The Privacy page body with the 1.7.41 LinkedIn wording; the LinkedIn paragraph is appended as a section when there's no place for it."""
    b = body or ""
    if "LinkedIn Insight Tag" in b:
        return b
    for old, new in PRIVACY_LINKEDIN_SWAPS:
        b = b.replace(old, new, 1)
    if "LinkedIn Insight Tag" not in b:
        b = b.rstrip() + "\n\n## Cookie choices and LinkedIn advertising\n\n" + PRIVACY_LINKEDIN.split("** ", 1)[1] + "\n"
    return b
