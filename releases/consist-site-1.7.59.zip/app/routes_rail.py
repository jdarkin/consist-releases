"""The rail portal at /rail: freight and safety analytics with its own shell and menu (templates/rail/), on the same accounts.

What it holds: the STB R-1 portal (routes_r1.py, also at /admin/freight), the Class I locomotive pages (routes_freight.py, parked
at /app/freight) and the FRA safety and grade crossing data (fra.py). The shared pages read lens.in_rail() to link within /rail
and to use the rail shell.

Access: admins always; members on a plan with the 'rail' feature (an add-on plan set up in Admin > Plans). Until the portal is
opened in Admin > Settings > General (rail_open), everyone but admins gets a 404 and nothing links here.
"""
import json
import math
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from . import auth, charts, db, fra, freight, lens, r1assets
from . import routes_freight as RF
from . import routes_r1 as R1
from .main import T, render
from .routes_app import csv_response

router = APIRouter(prefix="/rail")
moved = APIRouter()  # the old homes of these pages, before they were consolidated here (2026-10-31)
T.globals.update(R1_MODULES=r1assets.MODULES, FRA_CREDIT=fra.CREDIT, rail_ok=lens.rail_ok, rail_team_ok=lens.rail_team_ok)


def _open():
    return db.settings().get("rail_open") == "1"


def viewer(request, need=True):
    """The signed-in user with rail access. Visitors are sent to sign in; members without it get the add-on page; while the
    portal is closed everyone but admins gets a 404."""
    u = auth.current_user(request)
    if not (u and u.is_admin) and not _open():
        raise HTTPException(404)
    if not u:
        if not need:
            return None
        raise HTTPException(303, headers={"Location": f"/login?next={request.url.path}"})
    return u


# Freight Team tools: these pages, and CSV export from any portal page, need the 'rail_team' feature (lens.rail_team_ok).
TEAM_PATHS = ("/rail/fuel", "/rail/escalation")


def team_only(request):
    p = request.url.path
    return bool(request.query_params.get("export")) or any(p == t or p.startswith(t + "/") for t in TEAM_PATHS)


def gate(request, title):
    """(user, None) when the viewer can use the portal page, else (user, response to return): the free preview for members
    without a freight plan, the Freight Team page for Freight Analyst members on a Team tool."""
    u = viewer(request)
    if not lens.rail_ok(u):
        from . import teasers
        return u, render(request, "rail/locked.html", user=u, title=title, plans=_rail_plans(), teasers=teasers.cards(request.url.path))
    if request.query_params.get("export") and not (u and (u.is_admin or u.can("export"))):
        raise HTTPException(403, "CSV and Excel export is part of the Analyst and Investor plans.")
    if team_only(request) and not lens.rail_team_ok(u):
        return u, render(request, "rail/locked.html", user=u, title=title, team=True,
                         plans=[p for p in _rail_plans() if "rail_team" in (p.get("features") or [])])
    return u, None


def _rail_plans():
    return [p for p in db.plans() if "rail" in (p.get("features") or []) and p.get("active", 1)]


def _int(v, d, lo=None, hi=None):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return d
    if lo is not None and v < lo:
        return lo
    if hi is not None and v > hi:
        return hi
    return v


# ---------- home ----------

@router.get("")
def home(request: Request):
    u = auth.current_user(request)
    hl = fra.headline()
    soon = not _open()
    if not lens.rail_ok(u) or (soon and not u.is_admin):
        # The public landing (indexed, linked from the footer and Solutions): what Consist Rail is and how to get it.
        # While the portal is closed it says "opening soon" and offers the waitlist; the portal pages under /rail/ stay 404.
        from . import teasers
        prev = teasers.cards() if u and not soon else []  # signed-in members without a freight plan get the free preview
        return render(request, "rail/landing.html", user=u, hl=hl, plans=[] if soon else _rail_plans(), r1_years=r1assets.years(), F=fra, soon=soon,
                      teasers=prev)
    ops = fra.operators()
    top = sorted([o for o in ops if o["train_miles"] and o["train_miles"] > 2e6], key=lambda o: -(o["crossing_collisions_per_m_train_miles"] or 0))[:8]
    from . import shortline
    seg = request.cookies.get("rseg", "all")
    if seg in ("1", "2", "3"):
        top = [o for o in top if shortline.class_of(o["operator_id"]) == seg]
    return render(request, "rail/home.html", user=u, hl=hl, F=fra, R=r1assets, r1_years=r1assets.years(), ops=ops, top=top,
                  fra_on=fra.available(), class1=[o for o in ops if o["operator_id"] in fra.CLASS1],
                  cards=shortline.overview(seg) if fra.available() else [])


# ---------- R-1 portal and locomotives: the shared pages, served inside the rail shell ----------

@router.get("/r1")
def r1_home(request: Request):
    u, r = gate(request, "R-1 portal")
    return r or R1.module(request, "overview", u)


@router.get("/r1/m/{mod}")
def r1_module(request: Request, mod: str):
    u, r = gate(request, "R-1 portal")
    return r or R1.module(request, mod, u)


@router.get("/r1/metric/{key}")
def r1_metric(request: Request, key: str):
    u, r = gate(request, "R-1 portal")
    return r or R1.metric(request, key, u)


@router.get("/r1/about")
def r1_about(request: Request):
    u, r = gate(request, "R-1 portal")
    return r or R1.about(request, u)


@router.get("/locomotives")
def loco_home(request: Request):
    u, r = gate(request, "Locomotive analytics")
    return r or RF.home(request, u)


@router.get("/locomotives/rr/{op}")
def loco_rr(request: Request, op: str):
    u, r = gate(request, "Locomotive analytics")
    return r or RF.railroad(request, op, u)


@router.get("/locomotives/metric/{key}")
def loco_metric(request: Request, key: str):
    u, r = gate(request, "Locomotive analytics")
    return r or RF.metric(request, key, u)


@router.get("/locomotives/renewal")
def loco_renewal(request: Request):
    u, r = gate(request, "Locomotive analytics")
    return r or RF.renewal_page(request, u)


@router.get("/locomotives/rebuild")
def loco_rebuild(request: Request):
    u, r = gate(request, "Locomotive analytics")
    return r or RF.rebuild(request, u)


@router.get("/locomotives/about")
def loco_about(request: Request):
    u, r = gate(request, "Locomotive analytics")
    return r or RF.about(request, u)


# ---------- FRA safety ----------

SAFETY_COLS = ["operator_id", "name", "segment", "year_from", "year_to", "train_miles", "passenger_miles", "train_accidents", "equipment_accidents",
               "track_accidents", "human_factor_accidents", "crossing_collisions", "crossing_fatalities", "damage_usd",
               "train_accidents_per_m_train_miles", "crossing_collisions_per_m_train_miles", "fatal_per_m", "crossings", "pax", "pax_ungated"]


def _nofra(request, u, title):
    return render(request, "rail/nofra.html", user=u, title=title)


@router.get("/safety")
def safety(request: Request):
    u, r = gate(request, "Safety rates")
    if r:
        return r
    return safety_page(request, u, True)


def safety_page(request, u, rail):
    """Operator safety rates with lens buttons; the freight portal and the passenger app (/app/safety) share it (2026-11-03)."""
    if not fra.available():
        return _nofra(request, u, "Safety rates")
    keys = [k for k, _l, _t in fra.SAFETY_LENSES]
    lens = request.query_params.get("lens") or ""
    if lens not in keys:  # old ?seg= links, then the portal's own default
        lens = {"Freight": "freight", "Passenger": "pax"}.get(request.query_params.get("seg") or "", "")
    if lens not in keys:
        cls = request.cookies.get("rseg", "") if rail else ""
        lens = {"1": "c1", "2": "c2", "3": "c3"}.get(cls, "freight" if rail else "pax")
    root = "/rail/safety" if rail else "/app/safety"
    rows = fra.by_lens(fra.operators(""), lens)
    if request.query_params.get("export"):
        return csv_response("consist-fra-operator-safety", SAFETY_COLS, rows)
    med = fra.medians(rows, ["train_accidents_per_m_train_miles", "crossing_collisions_per_m_train_miles", "fatal_per_m", "damage_per_m"])
    big = [o for o in rows if (o["train_miles"] or 0) >= 2e6] or rows
    sel = request.query_params.get("op") or ""
    pick = lambda o: f"{root}?lens={lens}" + ("" if o["operator_id"] == sel else f"&op={o['operator_id']}") + "#list"  # click again to clear
    bars_acc = charts.bars([(o["name"], o["train_accidents_per_m_train_miles"], o["segment"], pick(o))
                            for o in sorted(big, key=lambda o: -(o["train_accidents_per_m_train_miles"] or 0))], max_items=15)
    bars_x = charts.bars([(o["name"], o["crossing_collisions_per_m_train_miles"], o["segment"], pick(o))
                          for o in sorted(big, key=lambda o: -(o["crossing_collisions_per_m_train_miles"] or 0))], max_items=15)
    shown = [o for o in rows if o["operator_id"] == sel] if sel else rows
    selname = shown[0]["name"] if sel and shown else ""
    if sel and not shown:
        shown, sel = rows, ""
    return render(request, "rail/safety.html", user=u, F=fra, rows=shown, all_n=len(rows), sel=sel, selname=selname, lens=lens, med=med, bars_acc=bars_acc, bars_x=bars_x,
                  rail=rail, root=root, big_cut=any((o["train_miles"] or 0) >= 2e6 for o in rows),
                  period=(rows[0]["year_from"], rows[0]["year_to"]) if rows else None)


@router.get("/safety/{op}")
def safety_operator(request: Request, op: str):
    u, r = gate(request, "Safety rates")
    if r:
        return r
    return safety_operator_page(request, u, op, True)


def safety_operator_page(request, u, op, rail):
    if not fra.available():
        return _nofra(request, u, "Safety rates")
    d = fra.operator(op)
    if not d or (not rail and d["segment"] != "Passenger"):  # the passenger app shows passenger agencies only
        raise HTTPException(404)
    ys = [y for y in d["years"] if y["year"] <= (d["y1"] or 9999) + 1]
    if request.query_params.get("export"):
        cols = ["year", "tm", "pm", "train", "rate", "crossing", "xrate", "killed", "injured", "dmg"] + fra.CAUSE_GROUPS
        return csv_response(f"consist-fra-{op.lower()}", cols, ys)
    rate_chart = charts.line([("Train accidents per M train-miles", [(y["year"], y["rate"]) for y in ys if y["rate"] is not None]),
                              ("Crossing collisions per M train-miles", [(y["year"], y["xrate"]) for y in ys if y["xrate"] is not None])],
                             title="Accident rates by year")
    cause_chart = charts.stacked({y["year"]: {g: y[g] for g in fra.CAUSE_GROUPS} for y in ys}, fra.CAUSE_GROUPS[:5], {g: g for g in fra.CAUSE_GROUPS})
    return render(request, "rail/safety_operator.html", user=u, F=fra, d=d, ys=ys, rate_chart=rate_chart, cause_chart=cause_chart,
                  rail=rail, root="/rail/safety" if rail else "/app/safety",
                  loco=fra.LOCO.get(op, op) if rail and fra.LOCO.get(op, op) in freight.RAILROADS else None, peers=fra.medians(fra.operators(d["segment"]), [
                      "train_accidents_per_m_train_miles", "crossing_collisions_per_m_train_miles", "fatal_per_m"]))


@router.get("/causes")
def causes(request: Request):
    u, r = gate(request, "Accidents by cause")
    if r:
        return r
    if not fra.available():
        return _nofra(request, u, "Accidents by cause")
    p = request.query_params
    a, b = fra.accident_years()
    op = p.get("op") or ""
    ops = fra.operators()
    if op not in {o["operator_id"] for o in ops}:
        op = ""
    seg = p.get("seg") if p.get("seg") in ("Freight", "Passenger") else ""
    last = (ops[0]["year_to"] if ops else b) or b
    y1 = _int(p.get("y1"), last, a, b)
    y0 = _int(p.get("y0"), max(a or 0, y1 - 4), a, y1)
    group = p.get("group") if p.get("group") in fra.CAUSE_GROUPS else ""
    years, grid, dmg = fra.cause_years(op or None, seg)
    top = fra.top_causes(y0, y1, op or None, seg, group)
    if p.get("export"):
        return csv_response("consist-fra-accident-causes", ["cause_code", "cause", "cause_group", "n", "dmg", "ops"], top)
    code = p.get("code") or ""
    who = fra.cause_operators(code, y0, y1) if code else []
    tot = {g: sum(grid[y][g] for y in years if y0 <= y <= y1) for g in fra.CAUSE_GROUPS}
    chart = charts.line([(g, [(y, grid[y][g]) for y in years]) for g in fra.CAUSE_GROUPS[:5]], title="Train accidents by cause group")
    return render(request, "rail/causes.html", user=u, F=fra, ops=ops, op=op, seg=seg, y0=y0, y1=y1, a=a, b=b, group=group, years=years,
                  grid=grid, dmg=dmg, top=top, code=code, who=who, tot=tot, chart=chart,
                  bars=charts.bars([(g, tot[g], "", None) for g in fra.CAUSE_GROUPS if tot[g]]))


# ---------- grade crossings ----------

def _crossings(request, preset=None):
    u, r = gate(request, "Grade crossings")
    if r:
        return r
    if not fra.available():
        return _nofra(request, u, "Grade crossings")
    p = request.query_params
    f = fra.crossing_filters(p, preset)
    if p.get("export"):
        return csv_response("consist-fra-crossings" + ("-ungated-passenger" if preset else ""), fra.CROSSING_COLS, fra.crossings_export(f))
    page = _int(p.get("page"), 1, 1)
    rows, stats = fra.crossings(f, page)
    pages = max(1, math.ceil((stats.get("n") or 0) / fra.PER_PAGE))
    pts = fra.crossing_points(f) if p.get("map", "1") != "0" else []
    keep = {k: v for k, v in f.items() if v and not (k == "position" and v == "At Grade") and not (k == "sort" and v == "collisions")}
    if preset:  # the preset's own defaults stay implied, except that "all, not just those with collisions" must be explicit
        for k, v in (("type", "Public"), ("warning", "ungated"), ("pax", "1")):
            if keep.get(k) == v:
                keep.pop(k)
    nohit = {k: v for k, v in keep.items() if k != "hit"}
    if preset and not f["hit"]:
        keep["hit"] = ""
    qs, qs_nohit = urlencode(keep), urlencode(nohit)
    return render(request, "rail/crossings.html", user=u, F=fra, f=f, rows=rows, stats=stats, page=page, pages=pages, preset=preset,
                  facets=fra.facets(), points=json.dumps(pts), npts=len(pts), qs=qs, qs_nohit=qs_nohit, hl=fra.headline(),
                  states=fra.state_rows() if preset else [])


@router.get("/crossings")
def crossings(request: Request):
    return _crossings(request)


@router.get("/crossings/ungated")
def ungated(request: Request):
    return _crossings(request, "ungated")


@router.get("/crossings/{cid}")
def crossing(request: Request, cid: str):
    u, r = gate(request, "Grade crossings")
    if r:
        return r
    if not fra.available():
        return _nofra(request, u, "Grade crossings")
    c = fra.crossing(cid.upper())
    if not c:
        raise HTTPException(404)
    return render(request, "rail/crossing.html", user=u, F=fra, c=c)


@router.get("/about")
def about(request: Request):
    u, r = gate(request, "About the Freight Rail Analytics Portal")
    if r:
        return r
    return render(request, "rail/about.html", user=u, F=fra, hl=fra.headline(), R=r1assets, fra_on=fra.available())


# ---------- old URLs ----------
# The locomotive pages lived at /app/freight and the R-1 portal at /admin/freight. Both moved here; their old links redirect for
# anyone who can use the portal and stay a 404 for everyone else, as before.

def _moved(request, new):
    u = auth.current_user(request)
    if not lens.rail_ok(u):
        raise HTTPException(404)
    q = request.url.query
    return RedirectResponse(new + ("?" + q if q else ""), status_code=301)


@moved.get("/app/freight{rest:path}")
def old_freight(request: Request, rest: str):
    return _moved(request, "/rail/locomotives" + rest)


@moved.get("/admin/freight{rest:path}")
def old_r1(request: Request, rest: str):
    return _moved(request, "/rail/r1" + (rest if rest not in ("", "/") else "/m/overview"))
