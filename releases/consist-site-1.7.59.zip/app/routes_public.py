"""Public pages: landing, pricing, coverage, comparisons, CMS pages, auth, sitemap, Stripe webhook."""
from urllib.parse import quote
import os
import logging
import re

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import PlainTextResponse, RedirectResponse, Response

import time

from . import auth, billing, claims, compare, config, content, data, db, fra, intel, lens, mailer, personas, r1assets, twofa
from .main import flash, redirect, render

router = APIRouter()
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def safe_next(n):
    return n if n and n.startswith("/") and not n.startswith("//") else "/app"


def _freight_now():
    """Live freight numbers for the home page's platform cards and freight band, from the free-preview cards (app/teasers.py):
    {card key: {label: value}}. Empty while the freight portal is closed."""
    if db.settings().get("rail_open") != "1":
        return {}
    from . import teasers
    try:
        return {c["key"]: dict(c["stats"]) for c in teasers.cards()}
    except Exception:
        return {}


@router.get("/")
def home(request: Request):
    fs, bs = data.fleet_stats(), data.bid_stats()
    latest, _ = data.notices({"status": "all", "sort": "new"}, per=6)
    by_year, _ = data.pipeline(years=6)
    years = {}
    for r in by_year:
        years.setdefault(r["yr"], {})[r["subsystem"]] = r["cars"]
    fc_years, fc_tot, _ = intel.forecast(10, "vehicle_class", {})
    fc_keys = [k for k, _ in sorted(fc_tot.items(), key=lambda kv: -kv[1]["cars"])][:4]
    for d in fc_years.values():
        d["other"] = sum(d.pop(k, 0) for k in list(d) if k not in fc_keys)
    fc_keys.append("other")
    fc = {"years": fc_years, "series": fc_keys, "labels": {**{k: data.CLASSES.get(k, k or "Other") for k in fc_keys}, "other": "Other"},
          "cars": sum(t["cars"] for t in fc_tot.values()), "value": sum(t["value"] for t in fc_tot.values())}
    return render(request, "public/home.html", fs=fs, bs=bs, latest=latest, plans=[p for p in db.plans() if db.settings().get("rail_open") == "1" or not db.is_freight_plan(p)], pipeline_years=years,
                  rail_hl=fra.headline(), r1_years=r1assets.years(), fc=fc, fnow=_freight_now(), freight_rr=claims.freight_railroads(),
                  competitors=compare.all_items(), faqs=compare.hub_faqs(db.settings().get("site_name", "Consist")))


def passenger_plans():
    return [p for p in db.plans() if not db.is_freight_plan(p)]


def freight_plans():
    return [p for p in db.plans() if "rail" in (p.get("features") or [])]


@router.get("/pricing")
def pricing(request: Request):
    site = db.settings().get("site_name", "Consist")
    faqs = [
        ("Can I try it before I pay?", "Yes. The Free plan is free forever, with no card. Paid plans are billed when you subscribe, and you can cancel any time."),
        ("Can I cancel any time?", "Yes. Cancel in Account > Billing. You keep access until the end of the period you paid for."),
        ("Do you offer yearly billing?", "Yes. Paying yearly saves 20%."),
        ("What counts as an analyst question?", "Each question you ask the AI analyst, and each AI bid brief, uses one. Browsing never does."),
        ("Do you cover freight railroads?", f"Yes, in the {site} - Freight Rail Analytics Portal: Class I STB R-1 costs and financials, locomotive fleets, "
         "FRA safety rates and every grade crossing. Freight Markets Analyst includes all of it; Rail Expert adds the passenger and transit tools."),
    ]
    faqs += [
        ("What does the free plan include?", "A sample of everything: recent bids, the first 10 fleets of the roster, previews of past RFPs and capital "
         "projects, and this week's headline numbers from every freight page. Saving and the AI analyst are on paid plans."),
        ("Which plan do I need?", "Passenger & Transit Analyst if you sell to transit agencies and passenger railroads. Freight Markets Analyst "
         "if you work with freight railroads. Rail Expert covers both, for less than the two together."),
    ]
    rail_open = db.settings().get("rail_open") == "1"
    allp = [p for p in db.plans() if rail_open or not db.is_freight_plan(p)]
    return render(request, "public/pricing.html", allplans=allp, faqs=faqs, canceled=request.query_params.get("canceled"))


def _scoped(sc, fn):
    """Run fn with a lens scope set (public pages have none of their own)."""
    tok = lens.set_current(sc)
    try:
        return fn()
    finally:
        lens.reset(tok)


@router.get("/coverage")
def coverage(request: Request):
    cur = request.query_params.get("lens", "all")
    if cur == "freight" and "freight" not in lens.lenses():  # freight is parked; the tab was public for a day
        return RedirectResponse("/coverage", status_code=301)
    cur = cur if cur in lens.lenses() else "all"
    tabs = {k: _scoped(lens.Scope(k), data.fleet_stats) for k in lens.lenses()}
    split = {c: _scoped(lens.Scope(cur, (c,)), data.fleet_stats) for c in lens.REGIONS}
    bs = data.bid_stats()
    s, a = db.settings(), tabs["all"]
    tok = {"operators": a["operators"], "fleets": f"{a['fleets']:,}", "cars": f"{a['cars']:,}", "agencies": bs["agencies"],
           "site": s.get("site_name", "Consist")}

    def fill(key):  # copy edited in Admin > Settings > Coverage page; an unknown {token} is left as typed
        text = s.get(key) or db.DEFAULT_SETTINGS[key]
        for k, v in tok.items():
            text = text.replace("{" + k + "}", str(v))
        return text
    cov = {k: fill("coverage_" + k) for k in ("title", "intro", "meta")}
    return _scoped(lens.Scope(cur), lambda: render(
        request, "public/coverage.html", ops=data.operators(), fs=tabs[cur], tabs=tabs, split=split, cur=cur, bs=bs,
        agencies=data.agencies(), cov=cov))


_panels = {}


def persona_preview(key):
    """A persona's home dashboard in its default lens, cached for an hour (public Solutions pages)."""
    hit = _panels.get(key)
    if hit and time.time() - hit[0] < 3600:
        return hit[1]
    p = _scoped(lens.Scope(lens.persona_lens(key)), lambda: personas.home(key))
    _panels[key] = (time.time(), p)
    return p


class _Visitor:
    """Stands in for a member in the persona panel: nothing unlocked, so tables show a short preview."""
    def can(self, feature):
        return False


@router.get("/solutions")
def solutions(request: Request):
    return render(request, "public/solutions.html", sols=content.solutions(), fs=data.fleet_stats(), bs=data.bid_stats())


@router.get("/solutions/{slug}")
def solution(request: Request, slug: str):
    if slug == "consulting-finance":  # split 2026-11 into engineering consultants and investors
        return RedirectResponse("/solutions/engineering-consultants", status_code=301)
    sol = content.solutions().get(slug)
    if not sol:
        if slug in content.SOLUTIONS:  # a parked segment (freight): send its old links to the hub
            return RedirectResponse("/solutions", status_code=301)
        raise HTTPException(404)
    try:
        panel = persona_preview(sol["persona"])
    except Exception:
        panel = None
    sc = lens.Scope(lens.persona_lens(sol["persona"]))
    return _scoped(sc, lambda: render(request, "public/solution.html", sol=sol, slug=slug, panel=panel, persona=lens.PERSONAS[sol["persona"]],
                                      visitor=_Visitor(), sols=content.solutions()))


@router.get("/operators")
def operators_hub():
    return redirect("/coverage")


@router.get("/operators/{slug}")
def operator_page(request: Request, slug: str):
    """Public operator page (SEO): the fleet roster, car orders and recent rail bids. Duty cycle, costs, overhaul timing and suppliers stay in the app."""
    row = data.operator_slugs().get(slug)
    if not row:
        if slug in {data.slug(o) for o in db.freight_ids()[0]}:  # a railroad page while freight is parked: keep the link value
            return RedirectResponse("/coverage", status_code=301)
        raise HTTPException(404)
    d = data.operator(row["operator_id"])
    try:
        bids, awards = data.notices_for_operator(row["operator_id"], 6), len(data.awards_for_operator(row["operator_id"], 50))
    except Exception:
        bids, awards = [], 0
    peers = [o for o in data.operators(scoped=False, category=(row["category"] or "").split("_")[0] or None)
             if o["operator_id"] != row["operator_id"]][:8]
    name = (row["service_name"] or row["operator_name"]).split(" / ")[0]
    bare = re.sub(r"\s*\(.*?\)", "", name)
    name = bare if len(bare) >= 20 else name  # drop "(CTrail Hartford Line + Shore Line East)" but keep "Connector (Cincinnati Bell Connector)"
    first = name.split()[0]
    if len((row["modes"] or "").split(";")) > 1 and first.isupper() and len(first) > 2:
        name = first  # "SEPTA Regional Rail" also runs the subway and trolleys: call it SEPTA
    # 1.7.58 SEO: "<agency> fleet roster" searches rank 7-10, so the title names the car types and the page leads with a type breakdown
    from . import seo
    by_type = {}
    for f in d["fleets"]:
        if not (f["qty_active"] or 0):
            continue
        t = by_type.setdefault(f["vehicle_class"] or "", {"cls": f["vehicle_class"] or "", "fleets": 0, "cars": 0, "first": None, "last": None})
        t["fleets"] += 1
        t["cars"] += f["qty_active"] or 0
        if f["build_year"]:
            t["first"] = min(t["first"] or f["build_year"], f["build_year"])
            t["last"] = max(t["last"] or f["build_year"], f["build_year"])
    by_type = sorted(by_type.values(), key=lambda t: -t["cars"])
    labels = [seo.plural_class(t["cls"]) for t in by_type if t["cls"]][:3]
    types = (", ".join(labels[:-1]) + " and " + labels[-1]) if len(labels) > 1 else (labels[0] if labels else "")
    blinks = seo.builder_links(d["fleets"])
    return render(request, "public/operator.html", o=row, d=d, oname=name, bids=bids, n_awards=awards, peers=peers,
                  by_type=by_type, types=types, blinks=blinks, years=seo.years,
                  builders=sorted({f["manufacturer"] for f in d["fleets"] if f["manufacturer"]}))


@router.get("/favicon.ico")
def favicon():
    return RedirectResponse("/static/img/favicon.svg", status_code=301)


@router.get("/compare")
def compare_hub(request: Request):
    site = db.settings().get("site_name", "Consist")
    return render(request, "public/compare_hub.html", competitors=compare.all_items(), faqs=compare.hub_faqs(site), checked=compare.CHECKED)


@router.get("/compare/{slug}")
def compare_page(request: Request, slug: str):
    c = compare.get(slug)
    if not c:
        raise HTTPException(404)
    site = db.settings().get("site_name", "Consist")
    others = {k: v for k, v in compare.all_items().items() if k != slug}
    return render(request, "public/compare.html", c=c, slug=slug, faqs=compare.faqs(c, site), others=others, checked=c["checked"])


@router.get("/p/{slug}")
def page(request: Request, slug: str):
    p = db.q("SELECT * FROM page WHERE slug = ? AND published = 1", (slug,), one=True)
    if not p:
        raise HTTPException(404)
    p = dict(p)
    p["body"], p["description"] = claims.fill(p["body"]), claims.fill(p["description"])
    return render(request, "public/page.html", p=p)


@router.get("/blog")
def blog(request: Request):
    posts = db.q("SELECT * FROM page WHERE kind = 'post' AND published = 1 ORDER BY updated DESC")
    return render(request, "public/blog.html", posts=posts)


@router.get("/contact")
def contact(request: Request):
    return render(request, "public/contact.html", sent=request.query_params.get("sent"), topic=request.query_params.get("topic", ""))


@router.post("/contact")
def contact_post(request: Request, csrf: str = Form(""), name: str = Form(""), email: str = Form(""), company: str = Form(""),
                 message: str = Form(""), website: str = Form("")):
    auth.check_csrf(request, csrf)
    if website or auth.spend(request, "contact", 5):  # honeypot, or more than 5 messages in 10 minutes
        return redirect("/contact?sent=1")
    if not EMAIL_RE.match(email.strip()) or not message.strip():
        flash(request, "Please give your email and a message.", "bad")
        return redirect("/contact")
    db.x("INSERT INTO lead (ts, name, email, company, message) VALUES (?,?,?,?,?)", (db.now(), name[:200], email[:200], company[:200], message[:4000]))
    s = db.settings()
    try:
        mailer.send(s.get("support_email"), f"New contact: {name} ({company})", f"{name} <{email}>\n{company}\n\n{message}")
    except Exception:
        pass
    return redirect("/contact?sent=1")


# ---------- feature requests ("Did we miss something?" under every data page; tracked in Admin > Feature requests) ----------

def _req_page(v):
    v = (v or "").strip()
    return v[:300] if v.startswith("/") and not v.startswith("//") else ""


@router.get("/request")
def request_form(request: Request):
    return render(request, "public/request.html", page=_req_page(request.query_params.get("page")), sent=request.query_params.get("sent"))


@router.post("/request")
def request_post(request: Request, csrf: str = Form(""), page: str = Form(""), text: str = Form(""), email: str = Form(""),
                 name: str = Form(""), website: str = Form("")):
    auth.check_csrf(request, csrf)
    u = auth.current_user(request)
    page = _req_page(page)
    back = "/request?sent=1" + (f"&page={quote(page)}" if page else "")
    if website or auth.spend(request, "feature_request", 5):  # honeypot, or more than 5 in 10 minutes
        return redirect(back)
    email = (u.email if u else email).strip()
    if not text.strip() or not EMAIL_RE.match(email):
        flash(request, "Tell us what you'd like built, and an email so we can follow up.", "bad")
        return redirect("/request" + (f"?page={quote(page)}" if page else ""))
    db.x("INSERT INTO feature_request (ts, user_id, email, name, plan_id, page, request) VALUES (?,?,?,?,?,?,?)",
         (db.now(), u.id if u else None, email[:200], ((u.name if u else name) or "")[:200], (u.plan or {}).get("id") if u else None, page, text.strip()[:4000]))
    try:
        mailer.send(db.settings().get("support_email"), "New feature request", f"{email} on {page or '(no page)'}:\n\n{text.strip()[:4000]}")
    except Exception:
        pass
    return redirect(back)


# ---------- auth ----------

@router.get("/signup")
def signup(request: Request):
    if auth.current_user(request):
        return redirect("/app")
    return render(request, "public/signup.html", plan=request.query_params.get("plan", ""), interval=request.query_params.get("interval", "month"),
                  personas=[request.query_params.get("persona", "")], regions=[], **_guard_ctx())


def _guard_ctx():
    """1.7.47: the signed form stamp and, when switched on, the Turnstile site key for the sign-up form."""
    from . import signupguard
    s = db.settings()
    return {"fs": signupguard.stamp(), "turnstile_key": signupguard.setting(s, "turnstile_site_key") if signupguard.turnstile_ready(s) else "",
            "verify_on": signupguard.setting(s, "signup_verify") == "1"}


@router.post("/signup")
def signup_post(request: Request, csrf: str = Form(""), email: str = Form(""), password: str = Form(""), name: str = Form(""),
                company: str = Form(""), plan: str = Form(""), interval: str = Form("month"), website: str = Form(""),
                persona: list[str] = Form([]), region: list[str] = Form([]), fs: str = Form(""),
                cf_token: str = Form("", alias="cf-turnstile-response")):
    from . import signupguard
    auth.check_csrf(request, csrf)
    s = db.settings()
    email = email.strip().lower()
    err = None
    why = None if s.get("signup_open") != "1" else signupguard.check(request, fs, website, email, cf_token)
    if s.get("signup_open") != "1":
        err = "Sign-ups are paused right now. Contact us for access."
    elif why:  # 1.7.47 bot protection: logged for Admin > Settings, with a plain message for a person who tripped it
        signupguard.log(request, email, why)
        err = {"fast": "That was quick. Check the form and press Create account again.",
               "stamp": "This form expired. Check the details and press Create account again.",
               "daily": "Too many sign-ups from your network today. Try again tomorrow or contact us.",
               "disposable": "Please use your work email. Throwaway inbox services can't open an account.",
               "turnstile": "Please complete the check above the button and try again."}.get(why, "Something went wrong.")
    elif auth.spend(request, "signup", 5):
        signupguard.log(request, email, "burst")
        err = "Too many sign-ups from your network. Wait ten minutes and try again."
    elif not EMAIL_RE.match(email):
        err = "Enter a valid work email."
    elif len(password) < 10:
        err = "Use a password of at least 10 characters."
    elif db.q("SELECT 1 FROM user WHERE email = ?", (email,), one=True):
        err = "There's already an account for that email. Sign in instead."
    if err:
        return render(request, "public/signup.html", error=err, email=email, full_name=name, company=company, plan=plan, interval=interval,
                      personas=persona, regions=region, **_guard_ctx())
    uid = auth.create_user(email, password, name, company)
    db.audit("signup", email, uid, actor=f"ip:{auth.client_ip(request)}")
    from . import ga
    ga.remember(request, uid)  # GA4 key events from the server (app/ga.py); sign_up fires when the account opens (after the email is confirmed)
    from . import referrals
    referrals.capture(request, uid)  # signed up through a member's /r/<code> link
    u = auth.load_user(uid)
    intel.apply_signup_choices(u, persona, [r for r in region if r in lens.REGIONS])
    nxt = f"/app/upgrade?plan={plan}&interval={interval}" if plan and plan != "free" else "/app"
    if signupguard.setting(s, "signup_verify") == "1":  # 1.7.47: the account opens when the emailed link is clicked
        db.x("UPDATE user SET status = 'unconfirmed' WHERE id = ?", (uid,))
        try:
            signupguard.send_confirm(u, nxt)
        except Exception:
            logging.getLogger("consist").exception("confirmation email for user %s", uid)
        return render(request, "public/confirm.html", email=email, sent=True)
    ga.event(uid, "sign_up", method="email", plan=plan or "free")
    return _open_account(request, u, nxt)


def _open_account(request, u, nxt):
    """Sign the new member in (or start 2FA set-up), send the welcome email and go to their first page."""
    s = db.settings()
    email = u["email"]
    need_2fa = twofa.available() and twofa.required(u)  # 'Required for everyone': set it up before the first page
    if not need_2fa:
        auth.login(request, u)
    try:
        mailer.send(email, f"Welcome to {s.get('site_name')}", f"Your account is ready: {config.SITE_URL}/app\n\nSet up a saved search to get rail bids by email: {config.SITE_URL}/app/alerts")
    except Exception:
        pass
    if need_2fa:
        from .routes_twofa import begin
        return begin(request, u, nxt)
    if nxt != "/app":
        return redirect(nxt)
    flash(request, "Welcome aboard. Start with the bid feed, or set up an alert.")
    return redirect("/app")


@router.get("/confirm/{tok}")
def confirm_email(request: Request, tok: str):
    """1.7.47: the link in the confirmation email opens the account and signs the member in."""
    t = auth.use_token(tok, "confirm")
    r = db.q("SELECT * FROM user WHERE id = ?", (t["user_id"],), one=True) if t else None
    if not r:
        return render(request, "public/confirm.html", error="That link has expired or was already used. Sign in to get a new one.")
    if r["status"] == "unconfirmed":
        db.x("UPDATE user SET status = 'active' WHERE id = ?", (r["id"],))
        db.audit("signup_confirmed", r["email"], r["id"])
        from . import ga
        ga.event(r["id"], "sign_up", method="email", plan="free" if "plan=" not in (t.get("email") or "") else (t.get("email") or "").split("plan=")[1].split("&")[0])
    elif r["status"] != "active":
        return render(request, "public/confirm.html", error="This account is disabled. Contact support.")
    return _open_account(request, auth.load_user(r["id"]), t.get("email") or "/app")


@router.post("/confirm/resend")
def confirm_resend(request: Request, csrf: str = Form(""), email: str = Form("")):
    from . import signupguard
    auth.check_csrf(request, csrf)
    if not auth.spend(request, "confirm", 3):
        r = db.q("SELECT * FROM user WHERE email = ? AND status = 'unconfirmed'", (email.strip().lower(),), one=True)
        if r:
            try:
                signupguard.send_confirm(dict(r))
            except Exception:
                pass
    return render(request, "public/confirm.html", email=email, sent=True)


@router.get("/login")
def login(request: Request):
    if auth.current_user(request):
        return redirect(safe_next(request.query_params.get("next")))
    return render(request, "public/login.html", next=request.query_params.get("next", ""))


@router.post("/login")
def login_post(request: Request, csrf: str = Form(""), email: str = Form(""), password: str = Form(""), next: str = Form("")):
    auth.check_csrf(request, csrf)
    ip = auth.client_ip(request)
    if auth.throttled(ip):
        return render(request, "public/login.html", error="Too many attempts. Wait ten minutes and try again.", email=email, next=next)
    r = db.q("SELECT * FROM user WHERE email = ?", (email.strip().lower(),), one=True)
    if not r or not auth.check_pw(password, r["pw_hash"]):
        auth.note_failure(ip)
        return render(request, "public/login.html", error="That email and password don't match.", email=email, next=next)
    if r["status"] == "unconfirmed":  # 1.7.47
        return render(request, "public/confirm.html", email=r["email"], unconfirmed=True)
    if r["status"] != "active":
        return render(request, "public/login.html", error="This account is disabled. Contact support.", email=email, next=next)
    from .routes_twofa import begin
    return begin(request, dict(r), safe_next(next))


@router.post("/logout")
def logout(request: Request, csrf: str = Form("")):
    auth.check_csrf(request, csrf)
    request.session.clear()
    return redirect("/")


@router.get("/forgot")
def forgot(request: Request):
    return render(request, "public/forgot.html", sent=request.query_params.get("sent"))


@router.post("/forgot")
def forgot_post(request: Request, csrf: str = Form(""), email: str = Form("")):
    auth.check_csrf(request, csrf)
    if auth.spend(request, "forgot", 5):
        return redirect("/forgot?sent=1")
    r = db.q("SELECT * FROM user WHERE email = ? AND status = 'active'", (email.strip().lower(),), one=True)
    if r:
        tok = auth.make_token("reset", r["id"], hours=2)
        link = f"{config.SITE_URL}/reset/{tok}"
        try:
            mailer.send(r["email"], "Reset your password", f"Use this link within 2 hours to set a new password:\n{link}\n\nIf you didn't ask, ignore this email.")
        except Exception:
            pass
        db.audit("password_reset_requested", r["email"], r["id"])
    return redirect("/forgot?sent=1")


@router.get("/reset/{tok}")
def reset(request: Request, tok: str):
    if not auth.use_token(tok, "reset", consume=False):
        return render(request, "public/forgot.html", error="That link has expired. Request a new one.")
    return render(request, "public/reset.html", tok=tok)


@router.post("/reset/{tok}")
def reset_post(request: Request, tok: str, csrf: str = Form(""), password: str = Form("")):
    auth.check_csrf(request, csrf)
    if len(password) < 10:
        return render(request, "public/reset.html", tok=tok, error="Use at least 10 characters.")
    t = auth.use_token(tok, "reset")
    if not t:
        return render(request, "public/forgot.html", error="That link has expired. Request a new one.")
    db.x("UPDATE user SET pw_hash = ? WHERE id = ?", (auth.hash_pw(password), t["user_id"]))
    db.audit("password_reset", "", t["user_id"])
    from .routes_twofa import begin
    resp = begin(request, {"id": t["user_id"]}, "/app")  # a reset link never skips the code step
    flash(request, "Password updated.")
    return resp


@router.get("/invite/{tok}")
def invite(request: Request, tok: str):
    t = auth.use_token(tok, "invite", consume=False)
    if not t:
        raise HTTPException(404, "This invitation has expired or was already used.")
    owner = db.q("SELECT name, company, email FROM user WHERE id = ?", (t["user_id"],), one=True)
    return render(request, "public/invite.html", tok=tok, email=t["email"], owner=owner)


@router.post("/invite/{tok}")
def invite_post(request: Request, tok: str, csrf: str = Form(""), name: str = Form(""), password: str = Form("")):
    auth.check_csrf(request, csrf)
    t = auth.use_token(tok, "invite", consume=False)
    if not t:
        raise HTTPException(404, "This invitation has expired or was already used.")
    if len(password) < 10:
        return render(request, "public/invite.html", tok=tok, email=t["email"], error="Use at least 10 characters.")
    existing = db.q("SELECT id FROM user WHERE email = ?", (t["email"],), one=True)
    if existing:
        db.x("UPDATE user SET team_owner_id = ? WHERE id = ?", (t["user_id"], existing["id"]))
        uid = existing["id"]
    else:
        owner = db.q("SELECT company FROM user WHERE id = ?", (t["user_id"],), one=True)
        uid = auth.create_user(t["email"], password, name, owner["company"] if owner else "", team_owner_id=t["user_id"])
    auth.use_token(tok, "invite")
    db.audit("invite_accepted", t["email"], uid)
    from .routes_twofa import begin
    return begin(request, {"id": uid}, "/app")


@router.get("/ambassador/{tok}")
def ambassador(request: Request, tok: str):
    from . import ambassadors as AM
    a = AM.pending(tok)
    if not a:
        raise HTTPException(404, "This invitation has expired, was revoked or was already used.")
    has = db.q("SELECT 1 FROM user WHERE email = ?", (a["email"],), one=True)
    return render(request, "public/ambassador.html", tok=tok, a=a, plan=db.get_plan(a["plan_id"]), existing=bool(has))


@router.post("/ambassador/{tok}")
def ambassador_post(request: Request, tok: str, csrf: str = Form(""), name: str = Form(""), password: str = Form("")):
    from . import ambassadors as AM
    auth.check_csrf(request, csrf)
    a = AM.pending(tok)
    if not a:
        raise HTTPException(404, "This invitation has expired, was revoked or was already used.")
    has = db.q("SELECT 1 FROM user WHERE email = ?", (a["email"],), one=True)
    if not has and len(password) < 10:
        return render(request, "public/ambassador.html", tok=tok, a=a, plan=db.get_plan(a["plan_id"]), existing=False,
                      error="Use at least 10 characters.")
    uid = AM.accept(tok, name, password)
    if has:  # an existing account signs in as usual, so the invite link alone never signs anyone in
        flash(request, "You're an Ambassador now. Sign in to start.")
        return redirect("/login?next=/app")
    from .routes_twofa import begin
    return begin(request, {"id": uid}, "/app")


# ---------- machine endpoints ----------

@router.post("/stripe/webhook")
async def stripe_webhook(request: Request):
    from . import syslog
    if not config.STRIPE_WEBHOOK_SECRET:
        syslog.record("error", "stripe", "Stripe sent a webhook but no webhook secret is set (Admin > Settings > Integrations)", "no_secret", "/stripe/webhook", "POST")
        raise HTTPException(400, "Webhook secret not configured")
    payload = await request.body()
    try:
        kind = billing.handle_webhook(payload, request.headers.get("stripe-signature"))
    except Exception as e:
        bad_sig = "Signature" in type(e).__name__
        syslog.record("error", "stripe", ("Webhook signature check failed (wrong webhook secret?)" if bad_sig else f"Webhook could not be processed: {type(e).__name__}: {e}")[:400],
                      "webhook_signature" if bad_sig else "webhook_error", "/stripe/webhook", "POST",
                      {"error": type(e).__name__, "message": str(e)[:500]})
        raise HTTPException(400, f"Invalid webhook: {type(e).__name__}")
    return {"received": kind}


@router.get("/robots.txt", response_class=PlainTextResponse)
def robots():
    return f"User-agent: *\nDisallow: /app\nDisallow: /admin\nDisallow: /rail/\nDisallow: /invite\nDisallow: /ambassador\nDisallow: /reset\nAllow: /\n\nSitemap: {config.SITE_URL}/sitemap.xml\n"


@router.get("/sitemap.xml")
def sitemap():
    from . import seo

    def entry(u, pr, mod=""):
        return f"<url><loc>{config.SITE_URL}{u}</loc>" + (f"<lastmod>{mod}</lastmod>" if mod else "") + f"<priority>{pr}</priority></url>"
    body = "".join(entry(*u) for u in seo.sitemap_urls())
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{body}</urlset>',
                    media_type="application/xml")


@router.get("/feed.xml")
def feed():
    from . import seo
    return Response(seo.feed_xml(db.settings().get("site_name", "Consist")), media_type="application/rss+xml")


@router.get("/data")
def data_hub(request: Request):
    from . import seo
    return render(request, "public/data_hub.html", pages=seo.DATA_PAGES, fleet_day=seo.data_day(), bids_day=seo.bids_day())


# ---------- public builder and car-model pages (1.7.58, SEO) ----------

def _op_link_slug(oid):
    return data.slug(oid) if data.slug(oid) in data.operator_slugs() else None


@router.get("/builders")
def builders_hub(request: Request):
    from . import seo
    rows = sorted(seo.builders_index().values(), key=lambda b: -b["cars"])
    return render(request, "public/builders.html", rows=rows, updated=seo.data_day(), main_class=seo.main_class)


@router.get("/builders/{bslug}")
def builder_public(request: Request, bslug: str):
    from . import seo
    b = seo.builders_index().get(bslug)
    if not b:
        raise HTTPException(404)
    models = sorted(b["models"].values(), key=lambda m: -m["cars"])
    ops = {}
    for m in models:
        for f in m["fleets"]:
            o = ops.setdefault(f["operator_id"], {"name": seo.op_name(f), "slug": _op_link_slug(f["operator_id"]), "cars": 0, "models": []})
            o["cars"] += f["qty_active"] or 0
            if m["name"] not in o["models"]:
                o["models"].append(m["name"])
    others = [x for x in sorted(seo.builders_index().values(), key=lambda x: -x["cars"]) if x["slug"] != bslug][:8]
    return render(request, "public/builder.html", b=b, models=models, ops=sorted(ops.values(), key=lambda o: -o["cars"]),
                  others=others, updated=seo.data_day(), main_class=seo.main_class, years=seo.years)


@router.get("/builders/{bslug}/{mslug}")
def model_public(request: Request, bslug: str, mslug: str):
    from . import seo
    b = seo.builders_index().get(bslug)
    m = b["models"].get(mslug) if b else None
    if not m:
        raise HTTPException(404)
    fleets = sorted(m["fleets"], key=lambda f: (-(f["qty_active"] or 0), f["build_year"] or 0))
    for f in fleets:
        f["op"], f["op_slug"] = seo.op_name(f), _op_link_slug(f["operator_id"])
    siblings = [x for x in sorted(b["models"].values(), key=lambda x: -x["cars"]) if x["slug"] != mslug][:8]
    return render(request, "public/model.html", b=b, m=m, fleets=fleets, siblings=siblings, updated=seo.data_day(),
                  main_class=seo.main_class, years=seo.years)


@router.get("/data/{slug}")
def data_page(request: Request, slug: str):
    from . import seo
    page = seo.DATA_PAGES.get(slug)
    if not page:
        raise HTTPException(404)
    rows = {"oldest-rail-fleets": seo.oldest_fleets, "midlife-overhauls-due": seo.midlife_due}.get(slug)
    from . import socialimg
    chart = next((k for k, c in socialimg.CHARTS.items() if c["page"] == "/data/" + slug), None)
    rows = rows() if rows else None
    return render(request, "public/data_page.html", slug=slug, page=page, rows=rows, blinks=seo.builder_links(rows or []),
                  chart=chart, chart_img=socialimg.url(chart) if chart else "", embed=socialimg.embed_code(chart) if chart else "",
                  bids=seo.bids_month() if slug == "rail-bids-this-month" else None,
                  updated=seo.bids_day() if slug == "rail-bids-this-month" else seo.data_day(), pages=seo.DATA_PAGES)


@router.get("/img/chart/{chart}.png")
def chart_png(chart: str):
    """Chart images for LinkedIn posts and 'Embed this chart' (socialimg.py). Public data only; cached a day."""
    from . import socialimg
    if chart not in socialimg.CHARTS:
        raise HTTPException(404)
    try:
        body = socialimg.png(chart)
    except ImportError:
        raise HTTPException(404)
    return Response(body, media_type="image/png", headers={"Cache-Control": "public, max-age=21600",
                                                           "Access-Control-Allow-Origin": "*", "Cross-Origin-Resource-Policy": "cross-origin"})


@router.get("/{key}.txt", response_class=PlainTextResponse)
def indexnow_key_file(key: str):
    """IndexNow ownership check: the key file must sit at the site root and contain the key."""
    from . import seo
    if key != db.settings().get("indexnow_key"):
        raise HTTPException(404)
    return seo.indexnow_key()


@router.get("/unsubscribe/{tok}")
def unsubscribe(request: Request, tok: str):
    from . import unsub
    e = unsub.email_for(tok)
    if not e:
        raise HTTPException(404, "This unsubscribe link isn't valid.")
    return render(request, "public/unsubscribe.html", email=e, out=unsub.is_out(e), done="")


@router.post("/unsubscribe/{tok}")
async def unsubscribe_post(request: Request, tok: str):
    """Mail clients send RFC 8058 one-click POSTs (body List-Unsubscribe=One-Click) with no cookie or CSRF token;
    that is safe here because the signed token names the address and the only effect is stopping optional email."""
    from . import unsub
    e = unsub.email_for(tok)
    if not e:
        raise HTTPException(404, "This unsubscribe link isn't valid.")
    form = await request.form()
    if form.get("List-Unsubscribe") == "One-Click":
        unsub.opt_out(e, "one-click")
        return PlainTextResponse("Unsubscribed.")
    auth.check_csrf(request, str(form.get("csrf", "")))
    if form.get("action") == "in":
        unsub.opt_in(e)
        done = "in"
    else:
        unsub.opt_out(e, "page")
        done = "out"
    return render(request, "public/unsubscribe.html", email=e, out=unsub.is_out(e), done=done)
