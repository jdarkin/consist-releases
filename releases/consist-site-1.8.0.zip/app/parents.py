"""1.7.92 (BD review 11-19): one parent company per supplier.

Subsystem records, awards and the supplier directory spell the same company many ways (five Hitachi Rail variants for onboard
signalling, Alstom Transportation Inc. and Alstom Transport Canada in awards, Faiveley beside Wabtec). Shares, market maps and
top-vendor charts roll up to the parent below; the legal entity or brand stays in the detail rows. Only well-documented ownership
is listed here. Add a line when a new spelling turns up (match is case-insensitive on the start of the name)."""
import re

# (prefix of the name as recorded, parent today)
PARENTS = (
    ("hitachi", "Hitachi Rail"), ("thales", "Hitachi Rail"), ("ansaldo", "Hitachi Rail"), ("ansaldobreda", "Hitachi Rail"),
    ("alstom", "Alstom"), ("bombardier", "Alstom"), ("adtranz", "Alstom"), ("abb daimler", "Alstom"),
    ("wabtec", "Wabtec"), ("faiveley", "Wabtec"), ("ge transportation", "Wabtec"), ("motivepower", "Wabtec"),
    ("motive power", "Wabtec"), ("westinghouse air brake", "Wabtec"),
    ("knorr", "Knorr-Bremse"), ("new york air brake", "Knorr-Bremse"), ("merak", "Knorr-Bremse"),
    ("siemens", "Siemens Mobility"), ("kawasaki", "Kawasaki"), ("progress rail", "Progress Rail"), ("emd", "Progress Rail"),
    ("electro-motive", "Progress Rail"), ("dellner", "Dellner"), ("stadler", "Stadler"), ("hyundai rotem", "Hyundai Rotem"),
    ("caf", "CAF"), ("mitsubishi electric", "Mitsubishi Electric"), ("toshiba", "Toshiba"),
    ("crrc", "CRRC"), ("kinki sharyo", "Kinki Sharyo"), ("nippon sharyo", "Nippon Sharyo"), ("talgo", "Talgo"),
)
_SUFFIX = re.compile(r"[,.]?\s+(inc|llc|ltd|ltée|ltee|corp|corporation|co|company|sa|ag|gmbh|usa|us|canada|na)\.?$", re.I)


def parent(name):
    """'Hitachi Rail (Thales GTS)' -> 'Hitachi Rail'; 'Alstom Transport Canada Inc.' -> 'Alstom'; unknown names come back tidied."""
    n = (name or "").strip()
    low = n.lower()
    for pre, par in PARENTS:
        if low.startswith(pre) and (len(low) == len(pre) or not low[len(pre)].isalnum()):
            return par
    for _ in range(3):
        n2 = _SUFFIX.sub("", n).strip()
        if n2 == n:
            break
        n = n2
    return n or name
