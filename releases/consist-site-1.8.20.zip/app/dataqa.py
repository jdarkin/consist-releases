"""Data QA repairs (1.8.14, Justin 11-23).

Admin > Data QA flags lists patterns that usually mean a data error. This module tries to fix each one:
- Safe repairs run automatically (once a day from the alerts loop, and on Run safe repairs now).
- Anything that needs a judgment call shows why it wasn't fixed, a suggested repair, and Approve / Deny (the data is correct,
  stop flagging it) / Suggest an alternative in plain language (read by rules, shown back for confirmation before it is used).

Repairs never write to fleet.db or bids.db (both are read-only to the site) and never touch user tables in app.db. Each
repair is a row in qa_fix (app.db) that is laid over the fleet and bid data when pages are built, so every change is logged
and any of them can be undone from the same page.
"""
import datetime
import re
import threading

from . import data, db, intel

_lock = threading.Lock()

SCHEMA = """CREATE TABLE IF NOT EXISTS qa_fix (id INTEGER PRIMARY KEY, ts TEXT, flag_key TEXT, kind TEXT, ref TEXT, field TEXT,
  old TEXT, new TEXT, status TEXT, how TEXT, note TEXT, actor TEXT, undone_ts TEXT, undone_by TEXT);
CREATE INDEX IF NOT EXISTS qa_fix_key ON qa_fix (flag_key, status);"""
# status: applied (laid over the data) | correct (flag denied: the data is right) | undone
# how: auto | approved | alternative

JUNK = re.compile("[▁​\u0000-\u0008\u000b\u000c\u000e-\u001f]")
MODERN = {"metro_car", "lrv", "emu", "dmu", "agt_vehicle", "monorail_car"}
ON_ORDER = re.compile(r"order|plan|deliver|build|construct|procure|future", re.I)
FLEET_FIELDS = {"build_year", "ulb_year", "useful_life_benchmark", "cost_basis"}
NOTICE_FIELDS = {"title", "hidden"}
_ready = {"v": False}
_ov = {"key": None, "fleet": {}, "op": {}, "notice": {}}


def _now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def ensure():
    if _ready["v"]:
        return
    with db._lock:
        c = db.connect()
        try:
            c.executescript(SCHEMA)
            c.commit()
        finally:
            c.close()
    _ready["v"] = True


# ---------------- overlays: what the repairs change on the way out ----------------

def _version():
    ensure()
    r = db.q("SELECT count(*) || '/' || coalesce(max(id), 0) || '/' || coalesce(max(undone_ts), '') v FROM qa_fix", one=True)
    return r["v"] if r else ""


def overlays():
    v = _version()
    if _ov["key"] == v:
        return _ov
    fleet, op, notice = {}, {}, {}
    for r in db.q("SELECT ref, field, new FROM qa_fix WHERE status = 'applied' ORDER BY id"):
        kind, _, ref = r["ref"].partition(":")
        val = _cast(r["new"])
        {"fleet": fleet, "op": op, "notice": notice}.get(kind, {}).setdefault(ref, {})[r["field"]] = val
    _ov.update(key=v, fleet=fleet, op=op, notice=notice)
    return _ov


def _cast(v):
    if v is None or v == "":
        return None
    return int(v) if re.fullmatch(r"-?\d+", str(v)) else v


def apply_fleet(rows):
    """Lays applied fleet repairs over fleet dicts (data.attach_estimates and intel._build call it)."""
    try:
        ov = overlays()
    except Exception:
        return rows
    if not ov["fleet"] and not ov["op"]:
        return rows
    for r in rows:
        if not r:
            continue
        for src in (ov["op"].get(str(r.get("operator_id"))), ov["fleet"].get(str(r.get("fleet_id")))):
            for k, v in (src or {}).items():
                r[k] = v
                r.setdefault("qa_fixed", []).append(k)
    return rows


def apply_notice(r):
    try:
        o = overlays()["notice"].get(str(r.get("notice_id")))
    except Exception:
        return r
    if o:
        if o.get("title"):
            r["title"] = o["title"]
        if o.get("hidden"):
            r["qa_hidden"] = True
    elif r.get("title") and JUNK.search(r["title"]):
        r["title"] = clean(r["title"])  # same cleanup as the automatic repair, before the daily run has logged it
    return r


def hidden_notices():
    try:
        return [k for k, v in overlays()["notice"].items() if v.get("hidden")]
    except Exception:
        return []


def clean(t):
    return re.sub(r"\s{2,}", " ", JUNK.sub(" ", t or "")).strip()


# ---------------- the checks ----------------

def _fname(fl):
    return f"{fl['operator_name']} {fl.get('manufacturer') or ''} {fl.get('model_name') or ''}".replace("  ", " ").strip()


def _suppressed():
    return {r["flag_key"] for r in db.q("SELECT flag_key FROM qa_fix WHERE status IN ('correct', 'applied')")}


def raw_flags():
    """Every flag on the data as the site shows it now (repairs already laid over). Each is a dict: key, kind, ref, record,
    why, href, and either auto (a safe repair: field/new) or suggest (field/new/label) plus reason (why it wasn't fixed)."""
    out = []
    yr = intel.this_year()
    snap = intel.snapshot_all()
    by_model, by_op = {}, {}
    for fl in snap.values():
        fid = fl["fleet_id"]
        href = f"/app/fleets/{fid}"
        by_model.setdefault((fl["operator_id"], fl.get("model_name"), fl.get("manufacturer")), []).append(fl)
        by_op.setdefault(fl["operator_id"], []).append(fl)
        by_, last = fl.get("build_year"), fl.get("build_year_last")
        if fl.get("vehicle_class") in MODERN and by_ and by_ < 1960:
            f = dict(key=f"build_old:{fid}", kind="Build year", ref=f"fleet:{fid}", record=_fname(fl), href=href,
                     why=f"{fl['vehicle_class']} built {by_}: before 1960 is unlikely for this vehicle type", field="build_year", old=by_)
            if last and 1960 <= last <= yr + 1:
                f.update(auto=True, new=last, label=f"Use the last build year on record ({last})")
            else:
                f.update(new=None, label="Clear the build year (show it as unknown)",
                         reason="No other build year on record to fall back on, so the right year needs a person.")
            out.append(f)
        if by_ and by_ > yr + 1:
            f = dict(key=f"build_future:{fid}", kind="Build year", ref=f"fleet:{fid}", record=_fname(fl), href=href,
                     why=f"built {by_}, in the future", field="build_year", old=by_)
            if ON_ORDER.search(fl.get("fleet_status") or ""):
                f.update(auto=True, correct=True, label=f"Fleet status is \"{fl['fleet_status']}\", so a future build year is right")
            else:
                f.update(new=None, label="Clear the build year (show it as unknown)",
                         reason="The fleet isn't marked as on order, so this may be a typo or a fleet that hasn't been delivered yet.")
            out.append(f)
        ulb, life = fl.get("ulb_year"), fl.get("useful_life_benchmark")
        if ulb and by_ and ulb < by_:
            f = dict(key=f"ulb:{fid}", kind="Useful life", ref=f"fleet:{fid}", record=_fname(fl), href=href,
                     why=f"useful life ends {ulb}, before the build year {by_}", field="ulb_year", old=ulb)
            if life and 5 <= life <= 60:
                f.update(auto=True, new=by_ + life, label=f"Build year + {life}-year useful life = {by_ + life}")
            else:
                f.update(new=by_ + 31, label=f"Build year + 31 years (FTA default for rail cars) = {by_ + 31}",
                         reason="No useful life benchmark on record for this fleet, so the 31-year default is a guess.")
            out.append(f)
    for (oid, model, mfr), fls in by_model.items():
        if len(fls) >= 4:
            yrs = [x.get("build_year") for x in fls]
            real = all(yrs) and len(set(yrs)) == len(yrs)  # one row per build year: how NTD reports a fleet bought over years
            out.append({**dict(key=f"split:{oid}:{mfr}:{model}", kind="Fleet split", ref=f"op:{oid}", record=f"{fls[0]['operator_name']} {mfr or ''} {model}",
                            href=f"/app/operators/{oid}", why=f"{len(fls)} fleet rows for one model, so lists show it several times",
                            field=None, old=None, new=None, label="Keep as is: separate rows by build year or order are real",
                            reason="Two or more rows share a build year, so they may be duplicates. Merging rows changes counts, ages and useful-life dates, so it needs a person to check."),
                            **({"auto": True, "correct": True, "label": "Each row is a different build year, which is how NTD reports a fleet bought over several years"} if real else {})})
    for oid, fls in by_op.items():
        cpm = {round(f["maint_cost_per_car_mile"], 2) for f in fls if f.get("maint_cost_per_car_mile")}
        if len(fls) >= 5 and len(cpm) == 1 and not any(f.get("cost_basis") for f in fls):
            v = cpm.pop()
            out.append(dict(key=f"cost:{oid}", kind="Cost", ref=f"op:{oid}", record=fls[0]["operator_name"], href=f"/app/operators/{oid}",
                            why=f"every fleet shows the same maintenance cost per car-mile (${v}): a mode average, not per fleet",
                            field="cost_basis", old=None, auto=True, new="operator average",
                            label="Label these costs as an operator average on fleet pages"))
    for r in data._bq_safe("SELECT notice_id, title FROM notice WHERE title GLOB '*[" + "▁​" + "]*' LIMIT 200"):
        out.append(dict(key=f"bid_text:{r['notice_id']}", kind="Bid text", ref=f"notice:{r['notice_id']}", record=clean(r["title"])[:80],
                        href=f"/app/bids/{r['notice_id']}", why="junk characters in the title", field="title", old=r["title"],
                        auto=True, new=clean(r["title"]), label="Remove the junk characters"))
    for r in data._bq_safe("SELECT notice_id, title, closing, first_seen, hygiene_note FROM notice WHERE closing IS NOT NULL "
                           "AND closing < date(first_seen) AND first_seen >= date('now', '-30 days') LIMIT 200"):
        f = dict(key=f"bid_dates:{r['notice_id']}", kind="Bid dates", ref=f"notice:{r['notice_id']}", record=(r["title"] or "")[:80],
                 href=f"/app/bids/{r['notice_id']}", why=f"closed {r['closing']} but first seen {str(r['first_seen'])[:10]}",
                 field="hidden", old=None, new="1", label="Hide it from bid lists and alerts")
        if (r["hygiene_note"] or "") == "closed_on_arrival":
            f.update(auto=True, correct=True, label="Bid Catcher already keeps it out of new bids (closed on arrival)")
        else:
            f["reason"] = "The closing date may be a typo (wrong year), in which case the bid is still open."
        out.append(f)
    return out


def flags():
    """The report: open flags (not fixed and not marked correct)."""
    ensure()
    sup = _suppressed()
    return [f for f in raw_flags() if f["key"] not in sup]


# ---------------- making changes ----------------

SUGGESTED = object()


def record(f, how, actor, new=SUGGESTED, note=""):
    """Logs one repair. correct=True flags (and Deny) are stored with status 'correct' so the flag stops showing."""
    ensure()
    status = "correct" if (f.get("correct") or how == "deny" or f.get("field") is None) else "applied"
    val = f.get("new") if new is SUGGESTED else new
    if status == "applied" and f["field"] not in (FLEET_FIELDS | NOTICE_FIELDS):
        raise ValueError("That field can't be repaired here.")
    db.x("INSERT INTO qa_fix (ts, flag_key, kind, ref, field, old, new, status, how, note, actor) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
         (_now(), f["key"], f["kind"], f["ref"], f.get("field"), None if f.get("old") is None else str(f.get("old")),
          None if val is None else str(val), status, how, note or f.get("label") or "", actor))
    intel.invalidate()


def run_auto(actor="automatic"):
    """Applies every safe repair. Returns how many were made. Runs once a day from the alerts loop and from the button."""
    with _lock:
        n = 0
        for f in flags():
            if f.get("auto"):
                try:
                    record(f, "auto", actor)
                    n += 1
                except Exception:
                    pass
        db.x("INSERT OR REPLACE INTO setting (key, value) VALUES ('qa_auto_last', ?)", (_now(),))
        return n


def daily():
    r = db.q("SELECT value FROM setting WHERE key = 'qa_auto_last'", one=True)
    if r and r["value"] and r["value"][:10] == _now()[:10]:
        return 0
    return run_auto()


def find(key):
    for f in raw_flags():
        if f["key"] == key:
            return f
    return None


def undo(fix_id, actor):
    db.x("UPDATE qa_fix SET status = 'undone', undone_ts = ?, undone_by = ? WHERE id = ? AND status != 'undone'", (_now(), actor, fix_id))
    intel.invalidate()


def log(limit=300):
    ensure()
    return [dict(r) for r in db.q("SELECT * FROM qa_fix ORDER BY id DESC LIMIT ?", (limit,))]


# ---------------- plain-language alternatives ----------------

_FIELD_WORDS = [("ulb_year", r"useful life|ulb|retire(?:ment)?|end of life"), ("build_year", r"build year|built|build|year built|delivered"),
                ("useful_life_benchmark", r"life (?:benchmark|span|length)|lasts?")]


def interpret(text, f):
    """Reads a plain-language fix with rules (no paid AI). Returns {"ok", "action", "field", "new", "say"} for the admin to
    confirm, or {"ok": False, "say": why}."""
    t = (text or "").strip().lower()
    if not t:
        return {"ok": False, "say": "Type what the right value is, for example \"build year is 1998\"."}
    if re.search(r"\b(correct|right|fine|ok|leave|keep|real|accurate|as is)\b", t) and not re.search(r"\d{4}", t):
        return {"ok": True, "action": "deny", "field": None, "new": None, "say": "Mark this data as correct and stop flagging it."}
    if f["ref"].startswith("notice:"):
        if re.search(r"\b(hide|remove|drop|exclude|spam|not a bid)\b", t):
            return {"ok": True, "action": "set", "field": "hidden", "new": "1", "say": "Hide this bid from bid lists and alerts."}
        m = re.search(r"title\s*(?:is|should be|to|=|:)\s*[\"']?(.+?)[\"']?$", text.strip(), re.I)
        if m:
            return {"ok": True, "action": "set", "field": "title", "new": m.group(1).strip(), "say": f"Change the title to \"{m.group(1).strip()}\"."}
        return {"ok": False, "say": "I can hide a bid, fix its title (title is ...) or mark it correct. Bid dates come from the agency "
                                    "posting, so a wrong closing date has to be fixed in Bid Catcher."}
    if f["ref"].startswith("op:") and f["kind"] == "Fleet split":
        return {"ok": False, "say": "Merging fleet rows has to be done in the fleet data (Data thread). Here you can keep the rows as they are."}
    if f["ref"].startswith("op:") and f["kind"] == "Cost":
        if re.search(r"average|label", t):
            return {"ok": True, "action": "set", "field": "cost_basis", "new": "operator average", "say": "Label these costs as an operator average."}
        return {"ok": False, "say": "For costs I can label them as an operator average, or mark them correct."}
    field = None
    for fld, pat in _FIELD_WORDS:
        if re.search(pat, t):
            field = fld
            break
    field = field or f.get("field")
    if re.search(r"\b(clear|blank|unknown|remove|delete|none|empty)\b", t):
        return {"ok": True, "action": "set", "field": field, "new": None, "say": f"Clear the {_label(field)} (show it as unknown)."}
    m = re.search(r"\b(1[89]\d\d|20\d\d)\b", t)
    plus = re.search(r"\+\s*(\d{1,2})|(\d{1,2})\s*years?", t)
    yr = intel.this_year()
    if m:
        v = int(m.group(1))
        if field == "build_year" and not 1880 <= v <= yr + 8:
            return {"ok": False, "say": f"{v} isn't a believable build year."}
        return {"ok": True, "action": "set", "field": field, "new": v, "say": f"Set the {_label(field)} to {v}."}
    if plus and field in ("ulb_year", "useful_life_benchmark"):
        n = int(plus.group(1) or plus.group(2))
        if field == "ulb_year":
            snap = intel.snapshot_all().get(int(f["ref"].split(":")[1])) or {}
            if snap.get("build_year"):
                return {"ok": True, "action": "set", "field": "ulb_year", "new": snap["build_year"] + n,
                        "say": f"Set the useful life end to {snap['build_year'] + n} (build year + {n})."}
        return {"ok": True, "action": "set", "field": "useful_life_benchmark", "new": n, "say": f"Set the useful life to {n} years."}
    return {"ok": False, "say": "I couldn't read a change from that. Try \"build year is 1998\", \"useful life ends 2045\", "
                                "\"clear the build year\" or \"this is correct\"."}


def _label(field):
    return {"build_year": "build year", "ulb_year": "useful life end", "useful_life_benchmark": "useful life (years)",
            "title": "title", "hidden": "visibility", "cost_basis": "cost label"}.get(field, field or "value")

