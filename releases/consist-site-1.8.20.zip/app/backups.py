"""Nightly off-site backups, as the site sees them. The work happens on the VPS host (consist-backup bundle in /opt/consist-backup):
it writes backup_status.json and backup_pulls.log into the site's data folder, and picks up the two request files written here
("Back up now" and the off-site puller's public key; since 11-23 the Pi, the Synology being offline) every five minutes."""
import datetime
import json
import os
import re

from . import config, db

STALE_HOURS = 36
KEY_RE = re.compile(r"^(ssh-ed25519|ecdsa-sha2-nistp256|ecdsa-sha2-nistp384|ssh-rsa) [A-Za-z0-9+/=]{60,}( [A-Za-z0-9@._-]{0,80})?$")


def _p(name):
    return os.path.join(config.DATA_DIR, name)


def _age_h(ts):
    try:
        t = datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=datetime.timezone.utc)
    except (TypeError, ValueError):
        return None
    return (datetime.datetime.now(datetime.timezone.utc) - t).total_seconds() / 3600


def pulls(n=10):
    """Most recent NAS pulls, newest first: [{ts, ok, rc, ip}]."""
    try:
        lines = open(_p("backup_pulls.log")).read().splitlines()[-n:]
    except OSError:
        return []
    out = []
    for ln in reversed(lines):
        m = re.match(r"(\S+) rc=(\d+) from=(\S*)", ln)
        if m:
            out.append({"ts": m.group(1), "rc": int(m.group(2)), "ok": m.group(2) == "0", "ip": m.group(3)})
    return out


def status():
    try:
        snap = json.load(open(_p("backup_status.json")))
    except (OSError, ValueError):
        snap = None
    pl = pulls()
    last_ok = next((p for p in pl if p["ok"]), None)
    try:
        key = open(_p("backup_key_status")).read().strip()
    except OSError:
        key = ""
    snap_age = _age_h(snap["ts"]) if snap else None
    pull_age = _age_h(last_ok["ts"]) if last_ok else None
    problems = []
    if not snap:
        problems.append("No snapshot yet: the backup scripts aren't installed on the server, or haven't run.")
    elif not snap.get("ok"):
        problems.append(f"The last snapshot failed: {snap.get('error') or 'see /var/log/consist-backup.log'}.")
    elif snap_age is not None and snap_age > STALE_HOURS:
        problems.append(f"The last snapshot is {int(snap_age)} hours old.")
    if snap and not last_ok:
        problems.append("The off-site copy (Pi) hasn't pulled a backup yet.")
    elif pull_age is not None and pull_age > STALE_HOURS:
        problems.append(f"The off-site copy (Pi) last pulled {int(pull_age)} hours ago.")
    return {"snap": snap, "pulls": pl, "last_ok": last_ok, "key": key, "problems": problems,
            "requested": os.path.exists(_p("backup_request"))}


def request_now():
    open(_p("backup_request"), "w").write(db.now())


def set_nas_key(text):
    line = (text or "").strip().splitlines()[0].strip() if (text or "").strip() else ""
    if not KEY_RE.match(line):
        return False
    open(_p("backup_nas_key.pub"), "w").write(line + "\n")
    return True


def check_and_alert():
    """For the daily cron on the host: emails the support address when backups have problems, at most once a day."""
    from . import mailer
    st = status()
    if not st["problems"]:
        return "ok"
    s = db.settings()
    last = s.get("backup_alert_ts") or ""
    if last and (_age_h(last) or 99) < 20:
        return "problem (already emailed today): " + " ".join(st["problems"])
    to = s.get("support_email")
    if to and mailer.configured():
        mailer.send(to, "Consist backups need attention",
                    "\n".join(st["problems"]) + f"\n\nDetails: {config.SITE_URL}/admin/data#backups")
        db.set_setting("backup_alert_ts", db.now())
        return "problem, emailed: " + " ".join(st["problems"])
    return "problem, no email configured: " + " ".join(st["problems"])
