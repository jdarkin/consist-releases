"""Queries against the live fleet.db (Fleet Explorer) and bids.db (Bid Catcher). Both are opened read-only."""
import datetime
import json
import re

from . import db, lens

MODES = {"CR": "Commuter rail", "HR": "Heavy rail / metro", "LR": "Light rail", "SR": "Streetcar", "MG": "Monorail / AGT",
         "CC": "Cable car", "IP": "Inclined plane", "YR": "Hybrid rail", "AR": "Alaska Railroad", "ICR": "Intercity rail",
         "APM": "Airport people mover", "IC": "Intercity rail", "FR": "Freight rail"}
# Operators that run freight as well as the passenger service they report to NTD. Their passenger fleets are real and belong in the
# passenger and transit lens; the note tells members why a freight railroad shows up there.
DUAL_ROLE = {
    "ARRC": "Alaska Railroad is a freight and passenger railroad. It reports its passenger service to the National Transit Database "
            "(as \"Alaska Railroad\" mode), so its passenger cars and locomotives are counted in passenger and transit views. Its freight "
            "fleet is covered separately in freight views.",
}


# 1.7.39: punctuation-tolerant search (Justin 11-12: "M9A" must find "M-9A"). Each query word matches the raw text or, with
# hyphens, spaces, dots and slashes dropped on both sides, the squeezed text.
def norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def qhit(q, *fields):
    """True when every word of q is in the fields (raw or squeezed)."""
    words = q.lower().split() if isinstance(q, str) else [w.lower() for w in (q or [])]
    hay = " ".join(str(f or "") for f in fields).lower()
    nh = norm(hay)
    return all(w in hay or (norm(w) and norm(w) in nh) for w in words)


def sqln(col):
    """SQL for a column squeezed like norm() (lower case, no - space . / _ ,)."""
    return ("replace(replace(replace(replace(replace(replace(lower(coalesce(" + col + ", '')), '-', ''), ' ', ''), '.', ''), '/', ''), '_', ''), ',', '')")


def dual_role(oid=None, mode=None):
    """The 'also runs freight' note for an operator, or None."""
    if oid in DUAL_ROLE:
        return DUAL_ROLE[oid]
    if mode == "AR":
        return DUAL_ROLE["ARRC"]
    return None


CLASSES = {"coach": "Coach", "cab_car": "Cab car", "locomotive": "Locomotive", "emu": "EMU", "dmu": "DMU", "metro_car": "Metro car",
           "lrv": "Light rail vehicle", "streetcar": "Streetcar", "heritage_streetcar": "Heritage streetcar", "agt_vehicle": "AGT / APM vehicle",
           "monorail_car": "Monorail car", "cable_car": "Cable car", "incline_car": "Incline car", "switcher": "Switcher locomotive", "slug": "Slug unit"}
# Vehicle types arrive from several sources with different spellings ("Locomotive", "diesel locomotive", "locomotive ").
# cls_key() folds them to one key, so filters list each type once and a filter matches every spelling.
CLASS_ALIASES = {"locomotives": "locomotive", "loco": "locomotive", "diesel_locomotive": "locomotive", "electric_locomotive": "locomotive",
                 "dual_mode_locomotive": "locomotive", "passenger_locomotive": "locomotive", "freight_locomotive": "locomotive",
                 "road_locomotive": "locomotive", "diesel_electric_locomotive": "locomotive", "light_rail_vehicle": "lrv", "light_rail": "lrv",
                 "light_rail_car": "lrv", "heavy_rail_car": "metro_car", "heavy_rail": "metro_car", "subway_car": "metro_car", "rapid_transit_car": "metro_car",
                 "passenger_coach": "coach", "commuter_coach": "coach", "trailer": "coach", "cab": "cab_car", "control_car": "cab_car",
                 "cab_control_car": "cab_car", "switcher_locomotive": "locomotive", "switcher": "locomotive", "agt": "agt_vehicle", "apm_vehicle": "agt_vehicle", "people_mover": "agt_vehicle"}


def cls_key(c):
    k = re.sub(r"[^a-z0-9]+", "_", (c or "").strip().lower()).strip("_")
    return CLASS_ALIASES.get(k, k)


def cls_label(c):
    k = cls_key(c)
    return CLASSES.get(k, k.replace("_", " ").capitalize() if k else "—")


CATEGORIES = {
    "overhaul_program": "Overhaul and rebuild", "component_repair": "Component repair", "parts_supply": "Parts supply",
    "maintenance_services": "Maintenance services", "onboard_systems": "Onboard systems", "shop_equipment": "Shop equipment",
    "cleaning_interior": "Cleaning and interiors", "vehicle_procurement": "Vehicle procurement",
    "engineering_support": "Engineering support", "track_infrastructure": "Track and right of way",
    "signals_communications": "Signals, train control and communications", "traction_power": "Traction power and catenary",
    "stations_facilities": "Stations, yards and facilities", "rail_operations": "Rail operations and O&M",
    "rail_engineering": "Rail engineering and consulting", "other": "Other rail-related"}
SUBSYSTEMS = {"vehicle_control": "Vehicle control / TCMS", "propulsion_traction": "Propulsion and traction", "prime_mover": "Prime mover",
              "brakes": "Brakes", "trucks": "Trucks", "doors": "Doors", "hvac": "HVAC", "pis_passenger_info": "Passenger information",
              "cctv": "CCTV", "signal_onboard": "Onboard signaling", "coupler": "Couplers", "hep": "Head-end power", "tilt": "Tilt",
              "passenger_experience": "Passenger experience", "auxiliary_power": "Auxiliary power"}
MODE_ALIASES = {"ICR": "IC"}  # two NTD-era codes for intercity rail; shown and filtered as one


def mode_codes(m):
    """The stored mode codes a mode filter value stands for."""
    return [m] + [k for k, v in MODE_ALIASES.items() if v == m]


def scope_sql(mode_col="p.ntd_mode", country_col="o.country"):
    return lens.current().sql(mode_col, country_col)


OVERHAULS = {"vehicle_midlife": "Midlife overhaul", "vehicle_ulb": "End of useful life", "prime_mover_overhaul": "Engine overhaul"}


def today():
    return datetime.date.today().isoformat()


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")


# ---------------- fleet ----------------

FLEET_COLS = """p.fleet_id, p.operator_id, o.operator_name, o.service_name, o.country, p.ntd_mode, p.manufacturer, p.model_name,
  p.vehicle_class, p.propulsion, p.build_year, p.last_rebuild_year, p.qty_total_current, p.qty_active, p.useful_life_benchmark,
  p.est_annual_miles_per_car, p.est_cumulative_miles, p.duty_confidence, p.midlife_due_year, p.ulb_year, p.engine_overhaul_due_year,
  p.maint_cost_per_car_mile, p.benchmark_maint_per_car_mile, p.delta_vs_benchmark_pct, p.opex_per_car_mile,
  p.opex_per_passenger_mile, p.maint_cost_per_car_year"""

# 1.7.30: operating costs for fleets with no reported (NTD) cost are estimated by the R&D build (build_opex_peer.py):
# allocation_method peer_estimate (closest comparable NTD fleets) or r1_freight (STB R-1 locomotive rates), with a low-high range,
# a grade (B/C/D) and the peer fleets used. They show with an Estimate badge and stay out of benchmarks and reported totals.
ESTIMATE_METHODS = ("peer_estimate", "r1_freight")
EST_SQL = "SELECT fleet_id FROM fleet_opex_estimate WHERE allocation_method IN ('peer_estimate', 'r1_freight')"
_EST_COLS = ("est_low_total_usd", "est_high_total_usd", "estimate_grade", "peer_fleet_ids")


def _est_cols():
    try:
        have = {r[1] for r in db.fq("PRAGMA table_info(fleet_opex_estimate)")}
    except Exception:
        return []
    return [c for c in _EST_COLS if c in have]


def attach_estimates(rows, peers=False):
    """Sets r["cost_est"] on fleets whose cost is an estimate: method, grade, per-car-year value and range, peer ids
    (and with peers=True the peer fleet names). Rows with a reported cost get None. Works before the R&D columns exist."""
    rows = [r for r in rows if r]
    try:  # 1.8.14: data QA repairs (Admin > Data QA flags)
        from . import dataqa
        dataqa.apply_fleet(rows)
    except Exception:
        pass
    for r in rows:
        r["cost_est"] = None
    ids = sorted({int(r["fleet_id"]) for r in rows if r.get("fleet_id") is not None})
    if not ids:
        return rows
    extra = _est_cols()
    sel = ", ".join(["fleet_id", "report_year", "allocation_method", "est_total_opex_usd", "notes"] + extra)
    got = {}
    for x in db.fq(f"SELECT {sel} FROM fleet_opex_estimate WHERE allocation_method IN ('peer_estimate', 'r1_freight') "
                   f"AND fleet_id IN ({','.join(str(i) for i in ids)}) ORDER BY report_year", ()):
        got[x["fleet_id"]] = dict(x)  # latest year wins
    for r in rows:
        e = got.get(r.get("fleet_id"))
        if not e:
            continue
        n = r.get("qty_active") or r.get("qty_total_current") or 0
        per = lambda v: (v / n) if (v and n) else None
        pids = [int(t) for t in (e.get("peer_fleet_ids") or "").replace(",", ";").split(";") if t.strip().isdigit()]
        r["cost_est"] = dict(method=e["allocation_method"], grade=e.get("estimate_grade") or "D",
                             label="STB R-1 rates" if e["allocation_method"] == "r1_freight" else "comparable fleets",
                             per_car=per(e.get("est_total_opex_usd")), low=per(e.get("est_low_total_usd")),
                             high=per(e.get("est_high_total_usd")), peer_ids=pids, notes=e.get("notes") or "", peers=[])
    if peers:
        want = sorted({i for r in rows if r["cost_est"] for i in r["cost_est"]["peer_ids"]})
        if want:
            names = {x["fleet_id"]: dict(x) for x in db.fq(
                "SELECT p.fleet_id, p.manufacturer, p.model_name, o.operator_name FROM v_fleet_profile p JOIN operator o USING (operator_id) "
                f"WHERE p.fleet_id IN ({','.join(str(i) for i in want)})", ())}
            for r in rows:
                if r["cost_est"]:
                    r["cost_est"]["peers"] = [names[i] for i in r["cost_est"]["peer_ids"] if i in names]
    return rows


# Sortable columns: key -> (SQL expression, direction on first click). Blanks always sort last.
FLEET_SORTS = {"fleet": ("coalesce(p.manufacturer, '') || ' ' || p.model_name", "asc"), "operator": ("o.operator_name", "asc"),
               "type": ("p.vehicle_class", "asc"), "built": ("p.build_year", "asc"), "cars": ("p.qty_active", "desc"),
               "miles": ("p.est_annual_miles_per_car", "desc"), "cost": ("p.maint_cost_per_car_mile", "desc"),
               "delta": ("p.delta_vs_benchmark_pct", "desc"), "midlife": ("p.midlife_due_year", "asc")}
FLEET_SORT_ALIASES = {"age": ("built", "asc"), "newest": ("built", "desc")}  # older links and the Sort menu


def fleet_sort(f):
    """The (column key, 'asc'|'desc') a fleet list is sorted by, from its sort and dir parameters."""
    key, d = f.get("sort") or "cars", None
    if key in FLEET_SORT_ALIASES:
        key, d = FLEET_SORT_ALIASES[key]
    if key not in FLEET_SORTS:
        key = "cars"
    return key, (f.get("dir") if f.get("dir") in ("asc", "desc") else d or FLEET_SORTS[key][1])


def fleet_filters(f):
    where, args = ["coalesce(p.qty_active, p.qty_total_current, 0) > 0" if f.get("active", "1") == "1" else "1=1"], []
    if f.get("q"):
        where.append(f"(p.model_name LIKE ? OR p.manufacturer LIKE ? OR o.operator_name LIKE ? OR o.service_name LIKE ? OR p.operator_id LIKE ?"
                     f" OR (? != '' AND ({sqln('p.model_name')} LIKE ? OR {sqln('p.manufacturer')} LIKE ?)))")
        args += [f"%{f['q']}%"] * 5 + [norm(f["q"]), f"%{norm(f['q'])}%", f"%{norm(f['q'])}%"]
    if not f.get("_noscope"):
        w, a = scope_sql()
        where.append(w)
        args += a
    if f.get("mode"):
        codes = mode_codes(f["mode"])
        where.append(f"p.ntd_mode IN ({','.join('?' * len(codes))})")
        args += codes
    if f.get("cls"):  # every stored spelling of this vehicle type
        raws = [r[0] for r in db.fq("SELECT DISTINCT vehicle_class FROM v_fleet_profile WHERE vehicle_class IS NOT NULL") if cls_key(r[0]) == cls_key(f["cls"])]
        where.append(f"p.vehicle_class IN ({','.join('?' * len(raws))})" if raws else "0")
        args += raws
    if f.get("oem") and "|" in str(f["oem"]):  # 1.8.3: a supplier's every builder spelling, joined by '|'
        vs = [v for v in str(f["oem"]).split("|") if v][:40]
        where.append(f"p.manufacturer IN ({','.join('?' * len(vs))})")
        args += vs
    for key, col in (("oem", "p.manufacturer"), ("country", "o.country"),
                     ("operator", "p.operator_id"), ("propulsion", "p.propulsion")):
        if f.get(key) and not (key == "oem" and "|" in str(f[key])):
            where.append(f"{col} = ?")
            args.append(f[key])
    if f.get("own"):  # 1.7.35: NTD ownership, as Leasing and ownership groups it ("not reported" when blank)
        where.append("p.fleet_id IN (SELECT fleet_id FROM fleet WHERE lower(replace(coalesce(nullif(ownership, ''), 'not reported'), '_', ' ')) = lower(?))")
        args.append(f["own"])
    if f.get("built_from"):
        where.append("p.build_year >= ?")
        args.append(int(f["built_from"]))
    if f.get("built_to"):
        where.append("p.build_year <= ?")
        args.append(int(f["built_to"]))
    if f.get("_ids") is not None:
        where.append(f"p.fleet_id IN ({','.join(str(int(i)) for i in f['_ids']) or 'NULL'})")
    if f.get("midlife_by"):
        where.append("p.midlife_due_year <= ?")
        args.append(int(f["midlife_by"]))
    return " AND ".join(where), args


def fleets(f, page=1, per=50):
    where, args = fleet_filters(f)
    key, d = fleet_sort(f)
    expr = FLEET_SORTS[key][0]
    order = f"({expr}) IS NULL, {expr} {d.upper()}, o.operator_name, p.build_year"
    base = f"FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE {where}"
    tot = db.fq(f"SELECT count(*) n, sum(p.qty_active) cars FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE {where}", args, one=True)
    lim = "" if per is None else f" LIMIT {int(per)} OFFSET {int((page - 1) * per)}"
    rows = db.fq(f"SELECT {FLEET_COLS} {base} ORDER BY {order}{lim}", args)
    return attach_estimates([dict(r) for r in rows]), (tot["n"] if tot else 0), (tot["cars"] if tot else 0)


def fleet_facets():
    w, a = scope_sql()
    base = f"FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE {w}"

    def col(sql):
        return [r[0] for r in db.fq(sql, a) if r[0]]
    modes = col(f"SELECT DISTINCT p.ntd_mode {base} ORDER BY 1")
    return {
        "modes": sorted({MODE_ALIASES.get(m, m) for m in modes}),
        "classes": sorted({cls_key(c) for c in col(f"SELECT DISTINCT p.vehicle_class {base}")} - {""}, key=cls_label),
        "oems": col(f"SELECT p.manufacturer {base} AND p.manufacturer IS NOT NULL GROUP BY 1 ORDER BY sum(p.qty_active) DESC"),
        "propulsions": col(f"SELECT DISTINCT p.propulsion {base} ORDER BY 1"),
        "operators": [dict(r) for r in db.fq(f"SELECT DISTINCT o.operator_id, o.operator_name {base} ORDER BY o.operator_name", a)],
    }


def fleet(fid):
    r = db.fq(f"SELECT {FLEET_COLS}, p.est_annual_hours_per_car, p.duty_method, p.opex_per_seat_mile "
              "FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE p.fleet_id = ?", (fid,), one=True)
    if not r:
        return None
    d = attach_estimates([dict(r)], peers=True)[0]
    nat = db.fq("SELECT * FROM v_fleet_national WHERE fleet_id = ?", (fid,), one=True)
    d["national"] = dict(nat) if nat else {}
    d["duty"] = dict(db.fq("SELECT * FROM fleet_duty_cycle WHERE fleet_id = ? ORDER BY report_year DESC", (fid,), one=True) or {})
    d["opex"] = dict(db.fq("SELECT * FROM fleet_opex_estimate WHERE fleet_id = ? ORDER BY report_year DESC", (fid,), one=True) or {})
    d["overhauls"] = [dict(x) for x in db.fq("SELECT * FROM overhaul_projection WHERE fleet_id = ? ORDER BY projected_due_year", (fid,))]
    d["subsystems"] = [dict(x) for x in db.fq(
        "SELECT s.subsystem, s.supplier, s.product, s.detail, s.confidence, s.source_url FROM fleet_subsystem fs "
        "JOIN seed_subsystem s ON s.rowid = fs.subsystem_rowid WHERE fs.fleet_id = ? ORDER BY s.subsystem", (fid,))]
    d["power"] = dict(db.fq("SELECT * FROM v_fleet_electrification WHERE fleet_id = ?", (fid,), one=True) or {})
    d["lcc"] = dict(db.fq("SELECT * FROM fleet_lcc WHERE fleet_id = ?", (fid,), one=True) or {})
    d["vehicles"] = db.fq("SELECT count(*) n, count(unit_number) numbered FROM vehicle WHERE fleet_id = ?", (fid,), one=True)
    d["siblings"] = [dict(x) for x in db.fq(
        f"SELECT {FLEET_COLS} FROM v_fleet_profile p JOIN operator o USING (operator_id) WHERE p.operator_id = ? AND p.fleet_id != ? "
        "AND coalesce(p.qty_active,0) > 0 ORDER BY p.qty_active DESC LIMIT 12", (d["operator_id"], fid))]
    attach_estimates(d["siblings"])
    return d


def operators(country=None, scoped=True, category=None):
    w, a = scope_sql() if scoped else ("1=1", [])
    sql = ("SELECT o.operator_id, o.operator_name, o.service_name, o.country, o.states, o.modes, o.category, count(p.fleet_id) fleets, "
           "sum(p.qty_active) cars, min(p.build_year) oldest, "
           # 1.8.0 (BD review): car-weighted, and heritage, cable and incline cars left out (VTA showed 1965 from one 1928 trolley)
           "coalesce(round(sum(CASE WHEN p.vehicle_class NOT IN ('heritage_streetcar', 'cable_car', 'incline_car') THEN p.build_year * p.qty_active END) "
           "/ nullif(sum(CASE WHEN p.vehicle_class NOT IN ('heritage_streetcar', 'cable_car', 'incline_car') AND p.build_year IS NOT NULL THEN p.qty_active END), 0)), "
           "round(avg(p.build_year))) avg_build, group_concat(DISTINCT p.ntd_mode) fleet_modes, "
           f"round(sum(CASE WHEN p.fleet_id NOT IN ({EST_SQL}) THEN p.qty_active * p.maint_cost_per_car_mile END) / nullif(sum(CASE WHEN p.maint_cost_per_car_mile IS NOT NULL AND p.fleet_id NOT IN ({EST_SQL}) THEN p.qty_active END), 0), 2) maint_cpm "
           f"FROM operator o JOIN v_fleet_profile p USING (operator_id) WHERE coalesce(p.qty_active,0) > 0 AND {w} "
           + ("AND o.country = ? " if country else "") + ("AND o.category LIKE ? " if category else "")
           + "GROUP BY o.operator_id ORDER BY cars DESC")
    out = [dict(r) for r in db.fq(sql, a + ([country] if country else []) + ([category + "%"] if category else []))]
    for o in out:  # 1.8.0: show the modes the operator actually runs fleets in (VTA listed heavy rail it does not run)
        fm = [m for m in (o.pop("fleet_modes") or "").split(",") if m]
        if fm:
            o["modes"] = ";".join(sorted(set(fm)))
    return out


_op_slugs = {}


def operator_slugs():
    """Public operator page slugs (from operator_id, e.g. SOUND_TRANSIT -> sound-transit) -> operator row, for operators with active fleets.
    Cached for an hour; the fleet data changes monthly."""
    import time
    c = _op_slugs.setdefault(lens.current().freight, {})
    if c.get("t", 0) > time.time() - 3600:
        return c["m"]
    m = {}
    for o in operators(scoped=False):
        m.setdefault(slug(o["operator_id"]), o)
    c.update(t=time.time(), m=m)
    return m


def operator(oid):
    r = db.fq("SELECT * FROM operator WHERE operator_id = ?", (oid,), one=True)
    if not r:
        return None
    d = dict(r)
    d["fleets"], d["n_fleets"], d["cars"] = fleets({"operator": oid, "sort": "cars", "_noscope": 1}, per=None)
    d["trend"] = [dict(x) for x in db.fq("SELECT * FROM operator_cost_trend WHERE operator_id = ? ORDER BY ntd_mode, report_year", (oid,))]
    d["procurements"] = [dict(x) for x in db.fq("SELECT rowid AS order_id, * FROM seed_procurement WHERE ';' || operator_id || ';' LIKE ? ORDER BY award_date DESC",
                                               (f"%;{oid};%",))]
    d["power"] = [dict(x) for x in db.fq("SELECT * FROM seed_electrification WHERE operator_id = ?", (oid,))]
    return d


def operator_stats(oid):
    """Operator page: published NTD ridership and service for the latest report year, rail modes summed, with the year before
    for change. None when the operator doesn't report to the NTD (Canadian systems, most freight)."""
    rows = [dict(r) for r in db.fq("SELECT report_year y, ntd_mode, unlinked_trips upt, passenger_miles pmt, vehicle_revenue_miles vrm, "
                                   "vehicle_revenue_hours vrh, vehicles_max_service voms, opex_total opex, fare_revenue fares "
                                   "FROM operator_mode_year WHERE operator_id = ? AND coalesce(ntd_mode, '') != 'FR'", (oid,))]
    years = sorted({r["y"] for r in rows if r["upt"]}, reverse=True)
    if not years:
        return None

    def tot(y, k):
        v = [r[k] for r in rows if r["y"] == y and r[k] is not None]
        return sum(float(x) for x in v) if v else None
    y, p = years[0], (years[1] if len(years) > 1 and years[1] == years[0] - 1 else None)
    out = {"year": y, "prev": p, "modes": sorted({MODES.get(r["ntd_mode"], r["ntd_mode"]) for r in rows if r["y"] == y and r["upt"]})}
    for k in ("upt", "pmt", "vrm", "vrh", "voms", "opex", "fares"):
        out[k], out[k + "_prev"] = tot(y, k), (tot(p, k) if p else None)
        a, b = out[k], out[k + "_prev"]
        out[k + "_chg"] = (a / b - 1) * 100 if a and b else None
    out["trip_len"] = out["pmt"] / out["upt"] if out["pmt"] and out["upt"] else None
    out["recovery"] = out["fares"] / out["opex"] * 100 if out["fares"] and out["opex"] else None
    out["per_trip"] = out["opex"] / out["upt"] if out["opex"] and out["upt"] else None
    return out


PIPELINE_SORTS = {"due": (lambda r: r["projected_due_year"], "asc"), "event": (lambda r: r["subsystem"], "asc"),
                  "fleet": (lambda r: f"{r['manufacturer'] or ''} {r['model_name'] or ''}".strip().lower(), "asc"),
                  "operator": (lambda r: (r["operator_name"] or "").lower(), "asc"), "built": (lambda r: r["build_year"], "asc"),
                  "cars": (lambda r: r["qty_active"], "desc"), "used": (lambda r: r["pct_of_interval_used"], "desc")}


def sort_rows(rows, sorts, key, d):
    """Sort dict rows in Python by a PIPELINE_SORTS-style column; blanks go last in both directions."""
    get = sorts[key][0]
    have = [r for r in rows if get(r) not in (None, "")]
    return sorted(have, key=get, reverse=d == "desc") + [r for r in rows if get(r) in (None, "")]


def pipeline(start=None, years=10, kind=None):
    start = start or datetime.date.today().year
    sw, sa = scope_sql()
    where, args = ["op.projected_due_year BETWEEN ? AND ?", "coalesce(p.qty_active,0) > 0", sw], [start, start + years - 1] + sa
    if kind:
        where.append("op.subsystem = ?")
        args.append(kind)
    w = " AND ".join(where)
    by_year = [dict(r) for r in db.fq(
        f"SELECT op.projected_due_year yr, op.subsystem, count(*) fleets, sum(p.qty_active) cars, sum(op.est_cost_usd) cost "
        f"FROM overhaul_projection op JOIN v_fleet_profile p USING (fleet_id) JOIN operator o USING (operator_id) WHERE {w} GROUP BY 1, 2 ORDER BY 1", args)]
    rows = [dict(r) for r in db.fq(
        f"SELECT op.*, p.operator_id, o.operator_name, p.model_name, p.manufacturer, p.vehicle_class, p.build_year, p.qty_active, p.ntd_mode "
        f"FROM overhaul_projection op JOIN v_fleet_profile p USING (fleet_id) JOIN operator o USING (operator_id) "
        f"WHERE {w} ORDER BY op.projected_due_year, p.qty_active DESC", args)]
    return by_year, rows


def procurements():
    """Vehicle orders, limited to operators with a fleet in the current lens and region."""
    w, a = scope_sql()
    nul = "" if lens.current().territory else "s.operator_id IS NULL OR "  # 1.7.45: an order with no agency is outside any territory
    return [dict(r) for r in db.fq(
        f"SELECT s.rowid AS order_id, s.* FROM seed_procurement s WHERE {nul}EXISTS (SELECT 1 FROM v_fleet_profile p JOIN operator o USING (operator_id) "
        f"WHERE (';' || s.operator_id || ';') LIKE ('%;' || p.operator_id || ';%') AND {w}) ORDER BY s.award_date DESC", a)]


def procurement(oid):
    """1.7.33: one vehicle order with its operators, the fleets those operators run (this builder first), and the builder's other orders."""
    r = db.fq("SELECT rowid AS order_id, * FROM seed_procurement WHERE rowid = ?", (oid,), one=True)
    if not r:
        return None
    d = dict(r)
    ops = [x for x in (d.get("operator_id") or "").split(";") if x]
    d["operators"] = [operator_name(x) or {"operator_id": x, "operator_name": x} for x in ops]
    d["fleets"] = []
    if ops:
        man = (d.get("manufacturer") or "").split()[0].lower() if d.get("manufacturer") else ""
        rows = [dict(x) for x in db.fq(f"SELECT {FLEET_COLS} FROM v_fleet_profile p JOIN operator o USING (operator_id) "
                                       f"WHERE p.operator_id IN ({','.join('?' * len(ops))}) ORDER BY p.qty_active DESC", ops)]
        model = (d.get("model") or "").lower()
        for x in rows:
            x["match"] = bool(model and model in (x.get("model_name") or "").lower())
            x["same_builder"] = bool(man and man in (x.get("manufacturer") or "").lower())
        rows.sort(key=lambda x: (not x["match"], not x["same_builder"], -(x.get("qty_active") or 0)))
        d["fleets"] = rows[:8]
    def _usd(m):  # 2300000000 -> $2.3B (values are stored as published text)
        v = int(m.group(0))
        return f"${v / 1e9:.2f}".rstrip("0").rstrip(".") + "B" if v >= 1e9 else f"${v / 1e6:.1f}".rstrip("0").rstrip(".") + "M"
    d["value_fmt"] = re.sub(r"(?<![\d.])\d{7,}(?![\d.])", _usd, d.get("value_usd") or "") or None
    d["others"] = [dict(x) for x in db.fq("SELECT rowid AS order_id, operator_id, model, award_date, qty_base, status FROM seed_procurement "
                                          "WHERE manufacturer = ? AND rowid != ? ORDER BY award_date DESC LIMIT 8", (d.get("manufacturer"), oid))] if (d.get("manufacturer") or "").strip().lower() not in ("", "tbd", "unknown", "n/a") else []
    return d


def first_int(v):
    """The first whole number in a free-text quantity like '242' or 'up to 144 across MTA/CTDOT'."""
    m = re.search(r"\d[\d,]*", str(v or ""))
    return int(m.group(0).replace(",", "")) if m else 0


def fleet_stats(scoped=True):
    w, a = scope_sql() if scoped else ("1=1", [])
    r = db.fq("SELECT count(*) fleets, sum(p.qty_active) cars, count(DISTINCT p.operator_id) operators FROM v_fleet_profile p "
              f"JOIN operator o USING (operator_id) WHERE coalesce(p.qty_active,0) > 0 AND {w}", a, one=True)
    s = dict(r) if r else {"fleets": 0, "cars": 0, "operators": 0}
    # 1.7.78: fleets that actually carry both a cost figure (reported or estimated) and a duty cycle (annual miles per car).
    try:
        c = db.fq("SELECT count(*) n FROM v_fleet_profile p JOIN operator o USING (operator_id) "
                  "WHERE coalesce(p.qty_active,0) > 0 AND p.est_annual_miles_per_car IS NOT NULL "
                  "AND (p.maint_cost_per_car_mile IS NOT NULL OR p.opex_per_car_mile IS NOT NULL "
                  "OR p.fleet_id IN (SELECT fleet_id FROM fleet_opex_estimate)) "
                  f"AND {w}", a, one=True)
        s["fleets_cost_duty"] = c["n"] if c else 0
    except Exception:
        s["fleets_cost_duty"] = None
    s["subsystems"] = (db.fq("SELECT count(*) n FROM seed_subsystem", one=True) or {"n": 0})["n"]
    s["oems"] = (db.fq("SELECT count(DISTINCT manufacturer) n FROM v_fleet_profile", one=True) or {"n": 0})["n"]
    s["data_year"] = (db.fq("SELECT max(report_year) y FROM fleet_opex_estimate", one=True) or {"y": None})["y"]
    return s


# ---------------- bids ----------------

_BCOLS = {}


def bcols(table):
    """Columns of a bids.db table (cached 10 minutes). Bid Catcher adds columns with ALTER TABLE, so the site checks before reading them."""
    import time
    hit = _BCOLS.get(table)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    try:
        cols = {r[1] for r in db.bq(f"PRAGMA table_info({table})")}
    except Exception:
        cols = set()
    _BCOLS[table] = (time.time(), cols)
    return cols


def bcol(table, col, alias, expr=None):
    """'expr AS col' when bids.db has the column (bids-push21 on-call fields), else 'NULL AS col'."""
    return f"{expr or alias + '.' + col} AS {col}" if col in bcols(table) else f"NULL AS {col}"


def _notice_cols():
    # 1.7.32: bids-push22 machine translations of French and Spanish notices (originals unchanged)
    return NOTICE_COLS + ", " + ", ".join(bcol("notice", c, "n") for c in ("contract_type", "lang", "title_en", "description_en", "translated_by"))


NOTICE_COLS = """n.notice_id, n.source, n.agency_id, coalesce(g.agency, n.buyer) agency, n.country, n.ref_no, n.title, n.notice_type,
  coalesce(n.published, date(n.first_seen)) AS published, n.closing, n.url, n.value_est, n.currency, n.relevance, n.category, n.subsystems, n.rail, n.operator_id, n.summary,
  g.state_prov, g.platform"""


def open_clause():
    return f"(n.closing >= '{today()}' OR (n.closing IS NULL AND coalesce(n.published, date(n.first_seen)) >= date('now', '-45 days')))"


def notice_filters(f, full_history=True):
    where, args = ["coalesce(n.relevance, n.kw_score, 0) >= ?", "coalesce(n.notice_type,'') NOT IN ('award')"], [_min_rel(f.get("min_rel"))]
    if not full_history:
        where.append("coalesce(n.published, date(n.first_seen)) >= date('now', '-30 days')")
    if f.get("q"):
        nr = ",".join("'" + x.replace("'", "") + "'" for x in sorted(NO_REDISTRIBUTE)) or "''"
        tr = "title_en" in bcols("notice") and "description_en" in bcols("notice")  # 1.7.32: English translations match too
        where.append(f"(n.title LIKE ? OR ((n.description LIKE ? OR n.summary LIKE ?) AND upper(coalesce(n.agency_id, '')) NOT IN ({nr})) "
                     "OR n.buyer LIKE ? OR g.agency LIKE ?" + (" OR n.title_en LIKE ? OR n.description_en LIKE ?" if tr else "")
                     + f" OR (? != '' AND {sqln('n.title')} LIKE ?))")
        args += [f"%{f['q']}%"] * (7 if tr else 5) + [norm(f["q"]), f"%{norm(f['q'])}%"]
    if f.get("ntype"):  # 1.7.44: one notice type (e.g. 'planned' agency forecasts)
        where.append("n.notice_type = ?")
        args.append(f["ntype"])
    if f.get("stage"):  # 1.7.44: Bid Catcher's notice.stage (e.g. 'early'), only when bids.db has the column
        if "stage" in bcols("notice"):
            where.append("n.stage = ?")
            args.append(f["stage"])
        else:
            where.append("0")
    for key, col in (("category", "n.category"), ("country", "n.country"), ("agency", "n.agency_id"), ("operator", "n.operator_id")):
        vals = [v for v in str(f.get(key) or "").split(",") if v.strip()]  # 1.7.74: several values, comma-separated (alerts)
        if len(vals) == 1:
            where.append(f"{col} = ?")
            args.append(vals[0])
        elif vals:
            where.append(f"{col} IN ({','.join('?' * len(vals))})")
            args += vals
    sc = lens.current()
    if sc.territory and not f.get("_noscope") and not f.get("agency") and not f.get("operator"):  # 1.7.45 sales territory
        w, a = sc.ter_sql("n.operator_id", "n.agency_id")
        where.append(w)
        args += a
    regions = sc.regions
    if regions and not f.get("country") and not f.get("_noscope"):
        where.append(f"(n.country IS NULL OR n.country IN ({','.join('?' * len(regions))}))")
        args += list(regions)
    trades = [t for t in (f.get("trades") or "").split(",") if t in CATEGORIES]
    if trades and not f.get("category"):
        where.append(f"n.category IN ({','.join('?' * len(trades))})")
        args += trades
    subs = [v for v in str(f.get("subsystem") or "").split(",") if v.strip()]
    if subs:  # any of the picked subsystems
        where.append("(" + " OR ".join(["(';' || n.subsystems || ';') LIKE ?"] * len(subs)) + ")")
        args += [f"%;{v};%" for v in subs]
    st = f.get("status", "open")
    if st == "open":
        where.append(open_clause())
    elif st == "closed":
        where.append("NOT " + open_clause())
    if f.get("days"):
        where.append("coalesce(n.published, date(n.first_seen)) >= date('now', ?)")
        args.append(f"-{int(f['days'])} days")
    if f.get("new_since"):  # first collected after this UTC time ("new since my last sign-in / the last update")
        where.append("substr(n.first_seen, 1, 19) >= ?")
        args.append(f["new_since"][:19])
    if f.get("after_id"):
        where.append("n.notice_id > ?")
        args.append(int(f["after_id"]))
    try:  # 1.8.14: bids hidden by a data QA repair (lists, counts and alerts)
        from . import dataqa
        hid = dataqa.hidden_notices()
    except Exception:
        hid = []
    if hid:
        where.append(f"n.notice_id NOT IN ({','.join('?' * len(hid))})")
        args += hid
    return " AND ".join(where), args


NOTICE_SORTS = {"new": "coalesce(n.published, date(n.first_seen)) DESC, n.notice_id DESC", "closing": "n.closing IS NULL, n.closing ASC", "relevance": "n.relevance DESC, coalesce(n.published, date(n.first_seen)) DESC"}


_MON = {m: i for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}
_CLOSE_RX = re.compile(r"\b(?:clos(?:es|ing|e date|ing date)|due|deadline|submissions? due)\b[^.;]{0,25}?\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(?:(\d{1,2}),?\s+)?(20\d\d)", re.I)


def closing_hint(text):
    """A closing date stated in a notice's summary or title ("closing Feb 2027", "due March 3, 2026") when the source
    gave none: (iso date, 'Feb 2027' or 'Mar 3, 2026'). Month-only dates use the last day of the month."""
    m = _CLOSE_RX.search(text or "")
    if not m:
        return None
    mon, day, yr = _MON[m.group(1).lower()[:3]], m.group(2), int(m.group(3))
    try:
        if day:
            d = datetime.date(yr, mon, int(day))
            return d.isoformat(), d.strftime("%b ") + str(d.day) + d.strftime(", %Y")
        nxt = datetime.date(yr + (mon == 12), mon % 12 + 1, 1)
        return (nxt - datetime.timedelta(days=1)).isoformat(), datetime.date(yr, mon, 1).strftime("%b %Y")
    except ValueError:
        return None


# Agencies whose notice text may not be reissued or redistributed (Justin, 2026-11-09: Amtrak's postings say so). The site shows
# only the title, reference, dates, category and subsystem pills and a link to the agency's portal; Bid Catcher keeps the text for
# its own scoring. Add an agency_id here to restrict another agency.
NO_REDISTRIBUTE = {"AMTRAK"}
RESTRICTED_NOTE = "Details on Amtrak's procurement portal (Amtrak does not permit redistribution)."
RESTRICTED_FIELDS = ("description", "description_en", "summary", "value_est", "raw_json", "excerpt")


def restricted(r):
    return str((r or {}).get("agency_id") or "").upper() in NO_REDISTRIBUTE


def restrict(r):
    """Strip a no-redistribution agency's notice down to what the site may show. Returns the (copied) row."""
    r = dict(r)
    if restricted(r):
        for k in RESTRICTED_FIELDS:
            if k in r:
                r[k] = None
        r["restricted"] = True
        r["restricted_note"] = RESTRICTED_NOTE if str(r.get("agency_id")).upper() == "AMTRAK" else \
            "Details on the agency's procurement portal (the agency does not permit redistribution)."
    return r


# Public labels for notice sources that need one (1.7.25: Bid Catcher adds public agency solicitations found in member uploads as
# source 'agency_document'; never shown as a member upload).
NOTICE_SOURCES = {"agency_document": "Agency solicitation document"}


# 1.7.64 (Justin 11-17, bid 10019): a notice found in an agency document has no public posting, so its page says how to get the
# documents: the contact the document names, the agency site, and (admins and the member who uploaded it only) the uploaded copy.
_CONTACT_RX = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_CONTACT_CUE = re.compile(r"submi|inquir|enquir|question|contact|clarif|procurement|purchasing|buyer|addend|request", re.I)


def doc_contacts(text, limit=2):
    """Emails the solicitation text gives for submissions or inquiries (a nearby cue word), in order, at most limit."""
    out = []
    t = text or ""
    for m in _CONTACT_RX.finditer(t):
        e = m.group(0).rstrip(".").lower()
        near = re.split(r"[.!?\n]\s", t[max(0, m.start() - 200):m.start()])[-1]  # the same sentence or line only
        if e not in out and _CONTACT_CUE.search(near):
            out.append(e)
        if len(out) >= limit:
            break
    return out


def notice_upload_id(n):
    """The member upload a notice came from (Bid Catcher source_key [agency_document:]upl-<id>, or an upload reconciled to this notice), or None."""
    try:
        r = db.bq("SELECT source_key FROM notice WHERE notice_id = ?", (n["notice_id"],), one=True)
        k = ((r["source_key"] if r else "") or "").rsplit(":", 1)[-1]  # Bid Catcher stores "agency_document:upl-<id>"
        if k.startswith("upl-"):
            return k[4:]
    except Exception:
        pass
    try:
        from . import db as appdb
        r = appdb.q("SELECT upload_id FROM upload_notice WHERE notice_id = ? ORDER BY checked DESC LIMIT 1", (n["notice_id"],), one=True)
        return r["upload_id"] if r else None
    except Exception:
        return None


def _with_hint(r):
    r = restrict(r)
    try:  # 1.8.14: data QA repairs (cleaned titles)
        from . import dataqa
        dataqa.apply_notice(r)
    except Exception:
        pass
    if r.get("source") in NOTICE_SOURCES:
        r["source_label"] = NOTICE_SOURCES[r["source"]]
    if not r.get("closing"):
        h = closing_hint(r.get("summary")) or closing_hint(r.get("title"))
        if h:
            r["closing_est"], r["closing_est_label"] = h
    return r


def notices(f, page=1, per=25, full_history=True):
    where, args = notice_filters(f, full_history)
    if f.get("sort", "new") == "new" and db._hyg["on"]:  # 1.7.92: a bid first seen after it closed is not "just posted"
        where += " AND coalesce(n.hygiene_note, '') != 'closed_on_arrival'"
    order = NOTICE_SORTS.get(f.get("sort"), NOTICE_SORTS["new"])
    base = f"FROM notice n LEFT JOIN agency g USING (agency_id) WHERE {where}"
    tot = db.bq(f"SELECT count(*) n {base}", args, one=True)
    lim = "" if per is None else f" LIMIT {int(per)} OFFSET {int((page - 1) * per)}"
    rows = db.bq(f"SELECT {_notice_cols()} {base} ORDER BY {order}{lim}", args)
    return [_with_hint(r) for r in rows], (tot["n"] if tot else 0)


def notice(nid):
    r = db.bq(f"SELECT {_notice_cols()}, n.description, n.first_seen, n.kw_score, n.reviewed, g.portal_url, g.alert_channel, g.fleet_operator_ids "
              "FROM main.notice n LEFT JOIN agency g USING (agency_id) WHERE n.notice_id = ?", (nid,), one=True)  # main.: a repeat still opens
    return _with_hint(r) if r else None


def agencies():
    return [dict(r) for r in db.bq("SELECT agency_id, agency, country, state_prov FROM agency ORDER BY agency")]


def bid_stats():
    r = db.bq(f"SELECT count(*) total, sum(CASE WHEN {open_clause()} THEN 1 ELSE 0 END) open_now, "
              "sum(CASE WHEN coalesce(n.published, date(n.first_seen)) >= date('now','-7 days') THEN 1 ELSE 0 END) week FROM notice n "
              "WHERE coalesce(n.relevance, n.kw_score, 0) >= 50 AND coalesce(n.notice_type,'') != 'award'", one=True)
    s = dict(r) if r else {"total": 0, "open_now": 0, "week": 0}
    s["agencies"] = (db.bq("SELECT count(*) n FROM agency", one=True) or {"n": 0})["n"]
    s["awards"] = (db.bq("SELECT count(*) n FROM award WHERE relevance >= 50", one=True) or {"n": 0})["n"]
    s["award_usd"] = (db.bq("SELECT sum(amount_usd) v FROM award WHERE relevance >= 50", one=True) or {"v": 0})["v"]
    return s


def by_category(days=365):
    return [dict(r) for r in db.bq(
        "SELECT category, count(*) n FROM notice WHERE coalesce(relevance,0) >= 50 AND coalesce(published, date(first_seen)) >= date('now', ?) "
        "AND coalesce(notice_type,'') != 'award' GROUP BY 1 ORDER BY 2 DESC", (f"-{days} days",))]


def award_filters(f):
    where, args = ["a.relevance >= 50"], []
    sc = lens.current()
    if sc.territory and not f.get("_noscope") and not f.get("agency"):  # 1.7.45 sales territory
        w, a = sc.ter_sql("a.operator_id", "a.agency_id")
        where.append(w)
        args += a
    for key, col in (("category", "a.category"), ("agency", "a.agency_id"), ("country", "a.country")):
        if f.get(key):
            where.append(f"{col} = ?")
            args.append(f[key])
    if f.get("subsystem"):  # a subsystem pill was clicked (1.7.4)
        where.append("(';' || coalesce(a.subsystems, '') || ';') LIKE ?")
        args.append(f"%;{f['subsystem']};%")
    if f.get("vendor"):  # 1.7.92: a parent company's row carries all its entities' norms joined by '|'
        vs = [v for v in str(f["vendor"]).split("|") if v][:40]
        where.append(f"a.vendor_norm IN ({','.join('?' * len(vs))})")
        args += vs
    if f.get("q"):
        where.append(f"(a.title LIKE ? OR a.vendor LIKE ? OR a.buyer LIKE ? OR (? != '' AND ({sqln('a.title')} LIKE ? OR {sqln('a.vendor')} LIKE ?)))")
        args += [f"%{f['q']}%"] * 3 + [norm(f["q"]), f"%{norm(f['q'])}%", f"%{norm(f['q'])}%"]
    if f.get("since"):
        where.append("a.award_date >= ?")
        args.append(f["since"])
    return " AND ".join(where), args


def awards(f, limit=100):
    w, a = award_filters(f)
    rows = db.bq(f"SELECT a.*, coalesce(g.agency, a.buyer) agency FROM award a LEFT JOIN agency g USING (agency_id) WHERE {w} "
                 f"ORDER BY a.award_date DESC LIMIT {int(limit)}", a)
    return [dict(r) for r in rows]


AWARD_SOURCES = {
    "seao": ("SEAO, Quebec public tenders (open data)", "Quebec's official tender system publishes every public contract award as open data."),
    "canadabuys": ("CanadaBuys (open data)", "The Government of Canada's tender and award notices, published as open data."),
    "mail": ("Procurement portal alert", "Award notice received from the agency's procurement portal."),
    "page": ("Agency bid results page", "Read from the agency's published bid results or award page."),
    "board_docs": ("Agency board documents", "Read from board agendas, minutes, capital plans or award lists the agency publishes."),
    "research": ("Researched award", "Found by our award research in board documents, award lists or trade press; the grade says which."),
    "usaspending": ("USAspending.gov (federal contracts)", "A federal agency's rail contract award, from the US government's spending data."),
    "sam_gov": ("SAM.gov contract award", "A federal contract award notice published on SAM.gov."),
    "board_agenda": ("Board meeting agenda (recommended for approval)", "Read from a board or committee agenda: staff recommended this "
                     "award for approval. The board's vote can change or defer it; the minutes confirm it."),
    "manual": ("Added by an editor", "Entered by hand from the cited source."),
    "sample": ("Sample data", "Placeholder record for testing; not a real award."),
}
GRADES = {"A": "Agency document", "B": "Trade press", "C": "Secondary source", "D": "Inferred", "E": "Unconfirmed"}


def award(aid):
    """One award with its agency, bid tabulation, linked notice and source description."""
    r = db.bq("SELECT a.*, coalesce(g.agency, a.buyer) agency, g.portal_url, g.fleet_operator_ids FROM award a "
              "LEFT JOIN agency g USING (agency_id) WHERE a.award_id = ?", (aid,), one=True)
    if not r:
        return None
    d = dict(r)
    d["tab"] = [dict(t) for t in db.bq("SELECT bidder, bidder_norm, amount, rank, winner, source_url FROM bid_tab WHERE award_id = ? "
                                      "ORDER BY coalesce(rank, 999), amount", (aid,))]
    d["notice"] = notice(d["notice_id"]) if d.get("notice_id") else None
    d["source_label"], d["source_about"] = AWARD_SOURCES.get(d.get("source") or "", (d.get("source") or "Unknown source", ""))
    url = d.get("source_url") or ""
    d["source_is_dataset"] = url.lower().split("?")[0].endswith((".csv", ".json", ".zip", ".xml"))
    d["grade_label"] = GRADES.get(d.get("confidence") or "", "")
    if d.get("low_bid") and d.get("high_bid") and d["high_bid"] > d["low_bid"]:
        d["spread_pct"] = round(100 * (d["high_bid"] - d["low_bid"]) / d["low_bid"])
    if d.get("amount_usd") and d.get("term_months"):
        d["annual_usd"] = d["amount_usd"] * 12 / d["term_months"]
    op = d.get("operator_id") or ((d.get("fleet_operator_ids") or "").split(";")[0] or None)
    d["op"] = operator_name(op) if op else None
    # 1.7.31 on-call links (bids-push21): a task order's parent contract, an on-call's task orders and the other firms on its bench
    d["parent"], d["task_orders"], d["bench_firms"] = None, [], []
    if d.get("parent_award_id"):
        p = db.bq("SELECT award_id, title, vendor, ref_no FROM award WHERE award_id = ?", (d["parent_award_id"],), one=True)
        d["parent"] = dict(p) if p else None
    if d.get("contract_type") == "oncall" and "parent_award_id" in bcols("award"):
        d["task_orders"] = [dict(x) for x in db.bq("SELECT award_id, title, vendor, amount_usd, award_date FROM award WHERE parent_award_id = ? "
                                                   "ORDER BY award_date DESC", (aid,))]
        d["task_total"] = sum(x["amount_usd"] or 0 for x in d["task_orders"]) or None
    if d.get("bench_id"):
        d["bench_firms"] = [dict(x) for x in db.bq("SELECT award_id, vendor FROM award WHERE bench_id = ? AND award_id != ? ORDER BY vendor",
                                                   (d["bench_id"], aid))]
    return d


def operator_name(oid):
    r = db.fq("SELECT operator_id, operator_name FROM operator WHERE operator_id = ?", (oid,), one=True)
    return dict(r) if r else None


def award_vendors(f, limit=15):
    """Award winners, by value. limit=None returns every vendor (for re-ranking by units, fleets or customers)."""
    w, a = award_filters(f)
    tot = db.bq(f"SELECT sum(amount_usd) v, count(*) n FROM award a WHERE {w}", a, one=True)
    rows = db.bq(f"SELECT a.vendor_norm vendor, count(*) wins, sum(a.amount_usd) usd, count(DISTINCT a.agency_id) agencies, "
                 f"max(a.award_date) latest, max(a.vendor) label FROM award a WHERE {w} AND a.vendor_norm IS NOT NULL GROUP BY 1 ORDER BY usd DESC", a)
    total = (tot["v"] if tot else 0) or 0
    # 1.7.92 (BD review): roll legal entities up to the parent (Alstom Transportation Inc. + Alstom Transport Canada -> Alstom)
    from .parents import parent
    groups = {}
    for r in rows:
        d = dict(r)
        k = parent(d["label"] or d["vendor"])
        g = groups.get(k)
        if g is None:
            groups[k] = dict(d, label=k, vendor=d["vendor"], entities=[d["label"]], _ag=None)
            continue
        g["vendor"] += "|" + d["vendor"]
        g["wins"] += d["wins"] or 0
        g["usd"] = (g["usd"] or 0) + (d["usd"] or 0)
        g["agencies"] = max(g["agencies"] or 0, d["agencies"] or 0)  # lower bound: agencies are not de-duplicated across entities
        g["latest"] = max(g["latest"] or "", d["latest"] or "") or None
        g["entities"].append(d["label"])
    out = sorted(groups.values(), key=lambda d: -(d["usd"] or 0))
    for d in out:
        d.pop("_ag", None)
        d["share"] = round(100 * (d["usd"] or 0) / total, 1) if total else None
    return (out if limit is None else out[:int(limit)]), total, (tot["n"] if tot else 0)


def award_categories(f):
    w, a = award_filters(f)
    return [dict(r) for r in db.bq(f"SELECT a.category, count(*) n, sum(a.amount_usd) usd, avg(a.amount_usd) avg_usd, "
                                   f"avg(coalesce(a.n_bidders, 0)) bidders FROM award a WHERE {w} GROUP BY 1 ORDER BY usd DESC", a)]


def award_years(f):
    w, a = award_filters(f)
    return [dict(r) for r in db.bq(f"SELECT substr(a.award_date,1,4) yr, count(*) n, sum(a.amount_usd) usd FROM award a "
                                   f"WHERE {w} AND a.award_date IS NOT NULL GROUP BY 1 ORDER BY 1", a)]


def awards_for_operator(oid, limit=10):
    return [dict(r) for r in db.bq("SELECT a.*, coalesce(g.agency, a.buyer) agency FROM award a LEFT JOIN agency g USING (agency_id) "
                                   "WHERE (a.operator_id = ? OR (';' || g.fleet_operator_ids || ';') LIKE ?) AND a.relevance >= 50 "
                                   f"ORDER BY a.award_date DESC LIMIT {int(limit)}", (oid, f"%;{oid};%"))]


def _min_rel(v):
    """The Bids relevance floor (?min_rel=, 0-100, default 50). Bad input falls back to the default."""
    try:
        return max(0, min(100, int(str(v).strip()))) if v not in (None, "") else 50
    except (TypeError, ValueError):
        return 50


def _agencies_for_operator(oid):
    try:
        return [r["agency_id"] for r in db.bq("SELECT agency_id FROM agency WHERE (';' || coalesce(fleet_operator_ids, '') || ';') LIKE ? "
                                              "OR agency_id = ?", (f"%;{oid};%", oid))]
    except Exception:
        return []


def _tzlt(d):
    from . import tz
    return tz.lt(d)


def _bq_safe(sql, args=()):
    """A bids.db query that returns [] while a table doesn't exist yet (the meeting tables arrive with Bid Catcher push16)."""
    try:
        return [dict(r) for r in db.bq(sql, args)]
    except Exception:
        return []


# 1.7.66 (Justin 11-18): procurement and award portals per bid agency, from Bid Catcher's agency_link table (bids-push38):
# kind bids | awards | closed | tabulations; source portal | curated | discovered. The agency's own portal_url stands in as the
# bidding portal where no bids-kind link is listed. Empty (no card) before push38.
LINK_KINDS = {"bids": "Bidding portal", "awards": "Awards", "closed": "Closed solicitations", "tabulations": "Bid tabulations"}
_KIND_ORDER = {k: i for i, k in enumerate(LINK_KINDS)}


def agency_links(agency_ids):
    """{agency_id: [link dicts]} for these Bid Catcher agencies, bidding portal first, then awards, closed solicitations, tabulations."""
    ids = [a for a in dict.fromkeys(agency_ids or []) if a]
    if not ids:
        return {}
    ph = ",".join("?" * len(ids))
    ags = {r["agency_id"]: r for r in _bq_safe(f"SELECT agency_id, agency, platform, portal_url FROM agency WHERE agency_id IN ({ph})", ids)}
    rows = _bq_safe(f"SELECT agency_id, url, kind, label, source, watch, score, found, last_checked, backfilled, backfill_pages, note "
                    f"FROM agency_link WHERE agency_id IN ({ph})", ids)
    out = {}
    for r in rows:
        if r.get("kind") not in LINK_KINDS or not r.get("url"):
            continue
        out.setdefault(r["agency_id"], []).append(r)
    for aid, g in ags.items():
        have = out.setdefault(aid, [])
        pu = (g.get("portal_url") or "").strip()
        if pu and not any(x["kind"] == "bids" for x in have) and not any(x["url"] == pu for x in have):
            have.append({"agency_id": aid, "url": pu, "kind": "bids", "label": None, "source": "agency"})
    for aid, links in out.items():
        plat = (ags.get(aid) or {}).get("platform") or ""
        for x in links:
            x["kind_label"] = LINK_KINDS[x["kind"]]
            x["text"] = x.get("label") or (plat if x["kind"] == "bids" and plat else x["kind_label"])
            x["pdf"] = (x["url"].split("?")[0].lower().endswith(".pdf"))
        for x in links:
            y = re.findall(r"\b(?:19|20)\d\d\b", f"{x['text']} {x['url']}")
            x["_y"] = max(int(v) for v in y) if y else 0
        links.sort(key=lambda x: (_KIND_ORDER[x["kind"]], -x["_y"], -(x.get("score") or 0), x["text"].lower()))  # newest year lists first
        seen = {}
        for x in links:  # past three of a kind (yearly award PDFs) fold under "more"
            seen[x["kind"]] = seen.get(x["kind"], 0) + 1
            x["more"] = seen[x["kind"]] > 3
    return {k: v for k, v in out.items() if v}


def portal_cards(oid):
    """The Procurement and award portals card on an operator page: [{agency_id, agency, platform, links}] for its bid agencies."""
    from . import brief
    ids = brief.agency_ids(oid)
    links = agency_links(ids)
    if not links:
        return []
    names = {r["agency_id"]: r for r in _bq_safe(f"SELECT agency_id, agency, platform FROM agency WHERE agency_id IN ({','.join('?' * len(ids))})", ids)}
    return [{"agency_id": a, "agency": (names.get(a) or {}).get("agency") or a, "platform": (names.get(a) or {}).get("platform") or "",
             "links": links[a]} for a in ids if a in links]


def meetings_for_operator(oid, n_up=5, n_items=15, n_docs=10):
    """Board meetings and documents for an operator's agencies (1.7.16, from Bid Catcher's meeting tables; see
    fleet-db/bids/meetings-data-contract.md): upcoming meetings, recent rail agenda items and recently read documents."""
    ags = _agencies_for_operator(oid)
    out = {"upcoming": [], "agenda": [], "docs": [], "agencies": ags}
    if not ags:
        return out
    ph = ",".join("?" * len(ags))
    out["upcoming"] = _bq_safe(f"SELECT * FROM meeting WHERE agency_id IN ({ph}) AND meeting_date >= date('now') AND coalesce(status, '') != 'cancelled' "
                               f"ORDER BY meeting_date, meeting_time LIMIT {int(n_up)}", ags)
    items = _bq_safe(f"SELECT i.*, m.meeting_date, m.body FROM meeting_item i JOIN meeting m USING (meeting_id) WHERE i.agency_id IN ({ph}) "
                     f"AND coalesce(i.relevance, 0) >= 45 ORDER BY m.meeting_date DESC, i.relevance DESC LIMIT {int(n_items)}", ags)
    for it in items:
        it["subs"] = [x for x in (it.get("subsystems") or "").split(";") if x]
        try:
            it["bidder_list"] = [b for b in json.loads(it.get("bidders") or "[]") if isinstance(b, dict) and b.get("name")]
        except Exception:
            it["bidder_list"] = []
        url = it.get("doc_url") or ""
        it["href"] = url + (f"#page={it['page']}" if it.get("page") and ".pdf" in url.lower() and "#" not in url else "")
    out["agenda"] = items
    out["docs"] = _bq_safe(f"SELECT * FROM meeting_doc WHERE agency_id IN ({ph}) AND error IS NULL ORDER BY fetched DESC LIMIT {int(n_docs)}", ags)
    return out


def notices_for_operator(oid, limit=8):
    rows = db.bq(f"SELECT {_notice_cols()} FROM notice n LEFT JOIN agency g USING (agency_id) "
                 "WHERE (n.operator_id = ? OR (';' || g.fleet_operator_ids || ';') LIKE ?) AND coalesce(n.relevance,0) >= 50 "
                 f"AND coalesce(n.notice_type,'') != 'award' ORDER BY coalesce(n.published, date(n.first_seen)) DESC LIMIT {int(limit)}", (oid, f"%;{oid};%"))
    return [_with_hint(r) for r in rows]


def notice_operators(n):
    ids = [x for x in ((n.get("fleet_operator_ids") or "").split(";") + [n.get("operator_id") or ""]) if x]
    seen = []
    for i in ids:
        if i not in seen:
            seen.append(i)
    return seen


def data_status():
    import os
    from . import config
    out = {}
    for name, path in (("fleet", config.FLEET_DB), ("bids", config.BIDS_DB)):
        if os.path.exists(path):
            st = os.stat(path)
            out[name] = {"path": path, "size_mb": round(st.st_size / 1e6, 1),
                         "modified": _tzlt(datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc))}
        else:
            out[name] = {"path": path, "missing": True}
    tables = {"fleet": ["operator", "fleet", "vehicle", "seed_subsystem", "overhaul_projection", "seed_procurement"],
              "bids": ["agency", "notice", "award", "registration", "run_log"]}
    for name, tbls in tables.items():
        counts = {}
        for t in tbls:
            try:
                r = db.fq(f"SELECT count(*) n FROM {t}", one=True, db=name)
                counts[t] = r["n"] if r else None
            except Exception:
                counts[t] = None
        out[name]["counts"] = counts
    try:
        out["bids"]["runs"] = [dict(r) for r in db.bq("SELECT * FROM run_log ORDER BY id DESC LIMIT 12")]
    except Exception:
        out["bids"]["runs"] = []
    try:
        out["fleet"]["edits"] = [dict(r) for r in db.fq("SELECT * FROM agent_run ORDER BY started DESC LIMIT 5")]
    except Exception:
        out["fleet"]["edits"] = []
    out["sample"] = bool(db.bq("SELECT 1 FROM notice WHERE source = 'sample' LIMIT 1", one=True))
    return out


def last_update():
    """Start of the most recent Bid Catcher scan that added notices (UTC ISO), for the "new in the last update" filter."""
    try:
        r = db.bq("SELECT started FROM run_log WHERE task LIKE 'scan%' AND coalesce(new, 0) > 0 ORDER BY started DESC LIMIT 1", one=True)
    except Exception:
        return None
    return r["started"] if r else None


def poll_status():
    """When Bid Catcher last polled its sources (run_log) and what each step found, for the "Updated" line on bid pages."""
    try:
        scan = db.bq("SELECT started, finished, task, status, found, new, message FROM run_log WHERE task LIKE 'scan%' "
                     "AND status = 'done' ORDER BY finished DESC LIMIT 1", one=True)
        full = db.bq("SELECT finished FROM run_log WHERE task LIKE 'scan:%' AND task != 'scan:mail' AND status = 'done' "
                     "ORDER BY finished DESC LIMIT 1", one=True)
        aw = db.bq("SELECT finished FROM run_log WHERE task = 'awards' ORDER BY finished DESC LIMIT 1", one=True)
        seen = db.bq("SELECT max(last_seen) v FROM notice", one=True)
    except Exception:
        return None
    last = (scan and scan["finished"]) or (seen and seen["v"])
    if not last:
        return None
    out = {"last": last, "full": full["finished"] if full else None, "awards": aw["finished"] if aw else None,
           "new": scan["new"] if scan else None, "steps": []}
    for part in ((scan["message"] if scan else "") or "").split("; "):
        name, _, rest = part.partition(": ")
        if rest and name != "alerts sent":
            out["steps"].append((name, rest))
    out["ago"], mins = _ago(last)
    out["stale"] = mins is not None and mins > 36 * 60
    out["full_ago"] = _ago(out["full"])[0] if out["full"] else None
    return out


def _ago(ts):
    """'24 min ago' for a run_log timestamp (UTC), plus the minutes."""
    try:
        t = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return ts, None
    if t.tzinfo is None:
        t = t.replace(tzinfo=datetime.timezone.utc)
    mins = int((datetime.datetime.now(datetime.timezone.utc) - t).total_seconds() // 60)
    return ("just now" if mins < 2 else f"{mins} min ago" if mins < 90 else f"{mins // 60} h ago" if mins < 48 * 60 else f"{mins // 1440} days ago"), mins


# 1.7.40 drill helpers: every row that names a vendor, bidder or builder links to that company's details
_BSLUGS = {}


def builder_href(b):
    """The builder's page when it has fleets on file (exact slug, else the one builder whose slug starts with it), else its orders."""
    from urllib.parse import urlencode
    if not b:
        return None
    if "s" not in _BSLUGS:
        try:
            _BSLUGS["s"] = {slug(r["manufacturer"]) for r in db.fq("SELECT DISTINCT manufacturer FROM v_fleet_profile WHERE manufacturer IS NOT NULL")}
        except Exception:
            _BSLUGS["s"] = set()
    have, sl = _BSLUGS["s"], slug(b)
    if sl in have:
        return f"/app/builders/{sl}"
    near = [h for h in have if sl and h.startswith(sl + "-")]
    return f"/app/builders/{near[0]}" if len(near) == 1 else "/app/work?" + urlencode({"view": "orders", "builder": b}) + "#all"


def vendor_href(name):
    """Supplier Intelligence page for a tracked company, else that company's awards."""
    from urllib.parse import urlencode
    if not name:
        return None
    try:
        h = __import__("app.supplierintel", fromlist=["link"]).link(name)
    except Exception:
        h = None
    return h or "/app/awards?" + urlencode({"q": name})


def overhaul_href(sub, year=None):
    """An overhaul row on a fleet: the subsystem market (every fleet due for that work) when it is a tracked subsystem,
    else the Upcoming work list for that year."""
    from urllib.parse import urlencode
    s = (sub or "").replace("vehicle_", "") if sub not in SUBSYSTEMS else sub
    if s in SUBSYSTEMS:
        return "/app/subsystems?" + urlencode({"subsystem": s, **({"due": year} if year else {})})
    return "/app/work?" + urlencode({**({"y": year} if year else {})}) + "#list"
