"""Outgoing email over SMTP (IONOS or any provider). Without SMTP settings, messages are written to the log instead."""
import email.message
import email.utils
import logging
import smtplib
import ssl

from . import config

log = logging.getLogger("consist.mail")


def configured():
    return bool(config.SMTP_HOST)


def _with_name(sender):
    """Adds the site name as the display name ("Consist <noreply@consist-na.com>") when the From setting is a bare address."""
    name, addr = email.utils.parseaddr(sender or "")
    if name or not addr:
        return sender
    try:
        from . import db
        name = db.settings().get("site_name") or "Consist"
    except Exception:
        name = "Consist"
    return email.utils.formataddr((name, addr))


def _support(sender_addr):
    """Replies go to the support address when it is real and differs from the sender."""
    try:
        from . import db
        s = (db.settings().get("support_email") or "").strip()
    except Exception:
        return ""
    return s if "@" in s and not s.endswith("@example.com") and s.lower() != (sender_addr or "").lower() else ""


def send(to, subject, text, html=None, alerts=False, reply_to=None, optional=False, personal=False, ambassador=False, kind=None, headers=None):
    """optional=True marks mail the recipient can opt out of (alerts, invites, notes): it carries one-click List-Unsubscribe
    headers and is skipped when the address has opted out. Leave it False for account mail (password resets, sign-up).
    alerts=True sends from the bid alert mailbox (Admin > Settings > Email) when one is set, else the main one.
    personal=True (1.7.46, Ambassador invites): one-to-one mail. The opt-out check still applies, but no List-Unsubscribe headers:
    Gmail and Microsoft read them as bulk or marketing mail and file a first message from a new sender in Promotions, Junk or
    quarantine, which is why the "Send a test to me" copy (no headers) arrived and the real invites often did not."""
    kind = kind or purpose()
    user, password, sender = config.SMTP_USER, config.SMTP_PASSWORD, config.SMTP_FROM
    if alerts and config.ALERT_SMTP_USER and config.ALERT_SMTP_PASSWORD:
        user, password, sender = config.ALERT_SMTP_USER, config.ALERT_SMTP_PASSWORD, config.ALERT_SMTP_FROM
    if ambassador and config.AMB_SMTP_USER and config.AMB_SMTP_PASSWORD:  # 1.7.72: Ambassador invite sender
        user, password, sender = config.AMB_SMTP_USER, config.AMB_SMTP_PASSWORD, config.AMB_SMTP_FROM
        reply_to = reply_to or email.utils.parseaddr(sender)[1]  # personal mail: replies come back to the invite mailbox
    if not configured():
        log.warning("SMTP not configured; would send to %s: %s\n%s", to, subject, text)
        record(to, subject, kind, sender, "not_sent", "Email sending isn't set up on this server")
        return False
    if optional:
        from . import unsub
        if unsub.is_out(to):
            log.info("skipped optional email to %s (opted out): %s", to, subject)
            record(to, subject, kind, sender, "skipped", "Recipient unsubscribed")
            return False
    msg = email.message.EmailMessage()
    msg["From"] = _with_name(sender)
    msg["To"] = to
    msg["Subject"] = subject
    # Date and Message-ID: smtplib adds neither, and spam filters (Gmail, Outlook, SpamAssassin) mark mail without them
    msg["Date"] = email.utils.formatdate(localtime=False, usegmt=True)
    addr = email.utils.parseaddr(sender)[1]
    msg["Message-ID"] = email.utils.make_msgid(domain=addr.rsplit("@", 1)[-1] if "@" in addr else None)
    if optional and not personal:
        from . import unsub
        sup = _support(addr)  # a mailto fallback only when someone reads that inbox
        msg["List-Unsubscribe"] = f"<{unsub.url(to)}>" + (f", <mailto:{sup}?subject=unsubscribe>" if sup else "")
        msg["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"
    rt = reply_to or _support(addr)
    if rt:
        msg["Reply-To"] = rt
    for k, v in (headers or {}).items():  # 1.8.9: e.g. X-Consist-Categories on bid alerts, for mail rules and automations
        if k.startswith("X-") and v:
            msg[k] = str(v).replace("\r", " ").replace("\n", " ")[:900]
    msg.set_content(text)
    if html:
        msg.add_alternative(html, subtype="html")
    try:
        _smtp(msg, user, password)
    except Exception as ex:
        record(to, subject, kind, sender, "failed", f"{type(ex).__name__}: {ex}")
        from . import syslog
        syslog.record("error", "mail", f"Email to {to} failed: {type(ex).__name__}: {ex}"[:400], "smtp", detail={"subject": subject[:200]})
        raise
    record(to, subject, kind, sender, "sent")
    return True


# ---------- 1.7.81 (Justin 11-19): email log, Admin > Email log ----------
# What each send is for, by the function that called send(). A new caller shows as module.function until it is named here.
PURPOSES = {
    ("alerts", "run_once"): "Bid alert", ("alerts", "send_test_bid"): "Bid alert (test)", ("alerts", "send_now"): "Bid alert (update now)",
    ("alerts", "run_fleet_changes"): "Fleet update digest", ("alerts", "send_test_fleet"): "Fleet update (test)",
    ("ambassadors", "send_invite"): "Ambassador invite", ("routes_admin", "ambassadors_preview"): "Ambassador invite (test)",
    ("awareness", "_run"): "Awareness email", ("awareness", "send_test"): "Awareness email (test)",
    ("backups", "check_and_alert"): "Backup warning to admin", ("referrals", "_credit"): "Referral credit",
    ("referrals", "invite"): "Referral invite", ("routes_admin", "user_new"): "New account (admin created)",
    ("routes_admin", "user_reset"): "Password reset (admin sent)", ("routes_admin", "feature_request_credit"): "Feature request credit",
    ("routes_admin", "test_email"): "Settings test email", ("routes_app", "account_delete"): "Account deleted notice to admin",
    ("routes_app", "team_invite"): "Team invite", ("routes_public", "contact_post"): "Contact form to support",
    ("routes_public", "request_post"): "Feature request to support", ("routes_public", "_open_account"): "Welcome email",
    ("routes_public", "forgot_post"): "Password reset", ("signupguard", "send_confirm"): "Email confirmation",
    ("syslog", "go"): "Site error alert to admin", ("bd18", "send_digest"): "Weekly territory digest", ("bidcatcher", "test_email"): "Bid Catcher mailbox test",
}
STATUS = {"sent": "Sent", "failed": "Failed", "skipped": "Skipped (unsubscribed)", "not_sent": "Not sent (mail not set up)"}


def purpose():
    """The purpose label of whoever called send(), from the call stack (no caller has to pass it)."""
    import sys
    f = sys._getframe(1)
    first = None
    while f is not None:
        mod = (f.f_globals.get("__name__") or "").rsplit(".", 1)[-1]
        if mod != "mailer":
            key = (mod, f.f_code.co_name)
            if key in PURPOSES:
                return PURPOSES[key]
            first = first or f"{mod}.{f.f_code.co_name}"
        f = f.f_back
    return first or "Other"


def record(to, subject, kind, sender, status, error=""):
    """One row per send attempt in app.db email_log. Never raises: logging must not stop an email."""
    try:
        import datetime
        from . import db
        rid = db.x("INSERT INTO email_log (ts, to_addr, kind, subject, sender, status, error) VALUES (?, ?, ?, ?, ?, ?, ?)",
                   (datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), (to or "")[:300], (kind or "")[:120],
                    (subject or "")[:300], email.utils.parseaddr(sender or "")[1][:200], status, (error or "")[:500]))
        if isinstance(rid, int) and rid % 500 == 0:  # keep a year
            db.x("DELETE FROM email_log WHERE ts < ?", ((datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=365)).isoformat(),))
    except Exception as e:
        log.warning("email log write failed: %s", e)


def _smtp(msg, user, password):
    ctx = ssl.create_default_context()
    if config.SMTP_PORT == 465:
        with smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, context=ctx, timeout=30) as s:
            s.login(user, password)
            s.send_message(msg)
    else:
        with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30) as s:
            s.starttls(context=ctx)
            if user:
                s.login(user, password)
            s.send_message(msg)
    return True
