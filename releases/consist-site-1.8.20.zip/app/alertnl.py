"""1.8.10 (Justin 11-20): describe a bid alert in plain English and get a filled-in New saved search form to check and save.

No paid AI: a rule-based reader built on the site's own lists (categories, subsystems, agencies, countries, relevance levels).
parse(text, agencies) returns {"fields": {...form values...}, "understood": [(label, value)], "unknown": [words it skipped]}.
"""
import re

from . import data, lens

CAT_WORDS = {
    "overhaul_program": ["overhaul", "overhauls", "rebuild", "rebuilds", "midlife", "mid-life", "refurbishment", "refurbish", "rehab", "rehabilitation"],
    "component_repair": ["component repair", "repair", "repairs"],
    "parts_supply": ["parts", "part", "spares", "spare parts", "supply", "supplies", "consumables", "components"],
    "maintenance_services": ["maintenance services", "maintenance", "mro"],
    "onboard_systems": ["onboard systems", "onboard", "on-board"],
    "shop_equipment": ["shop equipment", "lifts", "wheel truing", "tooling"],
    "cleaning_interior": ["cleaning", "interiors", "interior", "seats", "seating"],
    "vehicle_procurement": ["vehicle procurement", "light rail vehicles", "light rail vehicle", "lrv", "lrvs", "vehicle", "cars", "coaches", "railcars", "railcar", "rail cars", "new cars", "vehicles", "locomotives", "locomotive", "trainsets", "rolling stock procurement"],
    "engineering_support": ["engineering support"],
    "track_infrastructure": ["track", "right of way", "rail grinding", "ties", "turnouts"],
    "signals_communications": ["signals", "signal", "signaling", "train control", "ptc", "cbtc", "communications", "radio"],
    "traction_power": ["traction power", "catenary", "substations", "substation", "third rail", "ocs"],
    "stations_facilities": ["stations", "station", "yards", "yard", "facilities", "facility"],
    "rail_operations": ["operations", "o&m", "operate"],
    "rail_engineering": ["consulting", "consultants", "engineering", "design services"],
}
SUB_WORDS = {
    "vehicle_control": ["tcms", "vehicle control"], "propulsion_traction": ["propulsion", "traction motors", "traction motor", "inverters"],
    "prime_mover": ["prime mover", "engines", "diesel engine"], "brakes": ["brakes", "brake", "braking"],
    "trucks": ["trucks", "truck", "bogies", "bogie", "wheelsets", "wheels"], "doors": ["doors", "door"],
    "hvac": ["hvac", "air conditioning", "heating"], "pis_passenger_info": ["passenger information", "pis", "signage", "announcements"],
    "cctv": ["cctv", "cameras", "camera", "video"], "signal_onboard": ["onboard signaling", "cab signal", "cab signals"],
    "coupler": ["couplers", "coupler"], "hep": ["head-end power", "hep"], "tilt": ["tilt"],
    "passenger_experience": ["wifi", "wi-fi", "passenger experience"], "auxiliary_power": ["auxiliary power", "apu", "batteries", "battery"],
}
COUNTRY_WORDS = {"US": ["us", "u.s.", "usa", "united states", "american"], "CA": ["canada", "canadian"]}
AGENCY_ALIASES = {"nj transit": "NJT", "njt": "NJT", "njtransit": "NJT", "lirr": "MTA", "long island rail road": "MTA", "metro-north": "MTA",
                  "metro north": "MTA", "nyct": "MTA", "new york city transit": "MTA", "la metro": "LAMETRO", "wmata": "WMATA",
                  "dc metro": "WMATA", "the t": "MBTA", "go transit": "METROLINX", "translink": "TRANSLINK"}
GENERIC = set("rail transit metro tram trams streetcar light rail commuter rail subway railway railroad airport city county state "
              "operations ops parts track signals the authority district".split()) | {"light rail", "commuter rail", "people mover"}
DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
STOP = set("a an and or the for of in on at to from with me my i want get send email emails alert alerts bids bid rfps rfp "
           "notices notice opportunities leads lead any all about please only new every each over above below than score "
           "scores relevance minimum min least at daily weekly instantly instant immediately day week am pm by is are "
           "that which who like show tell let know when there be it them those these some more matches match work works job jobs "
           "open current morning mornings evening territory area region tags tag line summary summaries contracts contract "
           "projects project packages package mentioning containing keyword keywords titled words word".split())


def _has(text, phrase):
    return re.search(r"(?<![\w-])" + re.escape(phrase) + r"(?![\w-])", text) is not None


def _agency_index(agencies):
    """[(phrase, agency_id)], longest first: the id, the full name, the name without its parentheses, and each name in them."""
    out = []
    ids = {a["agency_id"].lower(): a["agency_id"] for a in agencies}
    for a in agencies:
        aid, name = a["agency_id"], (a.get("agency") or "")
        cands = {aid.lower().replace("_", " "), name.lower(), re.sub(r"\s*\(.*?\)", "", name).strip().lower()}
        for inner in re.findall(r"\((.*?)\)", name):
            cands.update(x.strip().lower() for x in re.split(r"[;,]", inner) if len(x.strip()) >= 3 and not x.strip().lower().startswith("incl"))
        out += [(c, aid) for c in cands if len(c) >= 3 and c not in GENERIC]
    for k, v in AGENCY_ALIASES.items():
        if v.lower() in ids:
            out.append((k, ids[v.lower()]))
    return sorted(set(out), key=lambda x: -len(x[0]))


def parse(text, agencies=None):
    raw = (text or "").strip()[:600]
    t = " " + re.sub(r"\s+", " ", raw.lower()) + " "
    used = []  # (start, end) spans already understood
    f, said = {}, []

    def take(phrase):
        m = re.search(r"(?<![\w-])" + re.escape(phrase) + r"(?![\w-])", t)
        if m:
            used.append(m.span())
        return bool(m)

    # keywords: anything in quotes, or after "mentioning / containing / keyword(s) / about"
    kws = re.findall(r"[\"“']([^\"”']{2,60})[\"”']", raw)
    for m in re.finditer(r"\b(?:mentioning|containing|keywords?|with the words?|titled)\s+([a-z0-9][\w\- ]{1,40}?)(?=,| and | or | in | from | for | daily| weekly| instantly|$|\.)", t):
        kws.append(m.group(1).strip())
        used.append(m.span())
    if kws:
        f["q"] = " ".join(dict.fromkeys(k.strip() for k in kws if k.strip()))
        said.append(("Keywords", f["q"]))
        for k in kws:
            take(k.lower())

    # agencies
    picked = []
    for phrase, aid in _agency_index(agencies if agencies is not None else data.agencies()):
        if aid in picked:
            continue
        if any(s <= m.start() < e for s, e in used for m in [re.search(re.escape(phrase), t)] if m):
            continue
        if _has(t, phrase):
            picked.append(aid)
            take(phrase)
    if picked:
        f["agency"] = ",".join(picked)
        names = {a["agency_id"]: a.get("agency") for a in (agencies if agencies is not None else data.agencies())}
        said.append(("Agencies", "; ".join(names.get(a) or a for a in picked)))

    # subsystems before categories, so "brake parts" gives Brakes + Parts supply
    subs = [k for k, words in SUB_WORDS.items() if any([take(w) for w in words if _has(t, w)])]
    if subs:
        f["subsystem"] = ",".join(subs)
        said.append(("Subsystems", ", ".join(data.SUBSYSTEMS[s] for s in subs)))
    cats = [k for k, words in CAT_WORDS.items() if any([take(w) for w in words if _has(t, w)])]
    for k, label in data.CATEGORIES.items():
        if k not in cats and _has(t, label.lower()) and take(label.lower()):
            cats.append(k)
    if cats:
        f["category"] = ",".join(cats)
        said.append(("Categories", ", ".join(data.CATEGORIES[c] for c in cats)))

    countries = [k for k, words in COUNTRY_WORDS.items() if k in lens.REGIONS and any(_has(t, w) and take(w) for w in words)]
    if countries:
        f["country"] = ",".join(countries)
        said.append(("Countries", ", ".join(lens.REGIONS[c] for c in countries)))

    # relevance
    m = re.search(r"(?:relevance|score|scored|rated)\s*(?:of\s*)?(?:over|above|at least|>=?|of at least|min(?:imum)?)?\s*(\d{1,3})\+?|"
                  r"(?:over|above|at least|>=?)\s*(\d{1,3})\s*(?:relevance|score)?|(\d{1,3})\+\s*(?:relevance|score)?", t)
    rel = None
    if m:
        n = int(next(g for g in m.groups() if g))
        if 0 <= n <= 100:
            rel = max([k for k in ("0", "25", "50", "75", "90") if int(k) <= n] or ["0"], key=int)
            used.append(m.span())
    elif any(_has(t, w) for w in ("any score", "all scores", "everything", "wide net", "borderline")):
        rel = "0" if not _has(t, "wide net") else "25"
    elif any(_has(t, w) for w in ("best only", "only the best", "top matches")):
        rel = "90"
    elif any(_has(t, w) for w in ("strong", "strong matches", "high relevance")):
        rel = "75"
    if rel is not None:
        f["min_rel"] = rel
        said.append(("Minimum relevance", {"0": "All scores", "25": "25+", "50": "50+", "75": "75+", "90": "90+"}[rel]))

    # how often, when, and what each email includes
    if any(_has(t, w) for w in ("instantly", "instant", "immediately", "right away", "as soon as", "real time", "real-time")):
        f["frequency"] = "instant"
    elif any(_has(t, w) for w in ("weekly", "every week", "each week", "once a week")) or any(_has(t, d) or _has(t, d + "s") for d in DAYS):
        f["frequency"] = "weekly"
    elif any(_has(t, w) for w in ("daily", "every day", "each day", "every morning", "each morning", "once a day")):
        f["frequency"] = "daily"
    if f.get("frequency"):
        said.append(("Email me", {"instant": "Instantly", "daily": "Daily", "weekly": "Weekly"}[f["frequency"]]))
    for i, d in enumerate(DAYS):
        if _has(t, d) or _has(t, d + "s"):
            f["send_day"] = str(i)
            said.append(("Weekday for weekly emails", d.capitalize()))
            break
    m = re.search(r"\b(?:at|around|by)\s+(\d{1,2})(?::(\d\d))?\s*(am|pm|a\.m\.|p\.m\.)?|\b(\d{1,2})(?::(\d\d))?\s*(am|pm|a\.m\.|p\.m\.)|\b(noon|midday|midnight)\b", t)
    if m:
        g = m.groups()
        if g[6]:
            h = 0 if g[6] == "midnight" else 12
        else:
            h, ap = (int(g[0]), g[2]) if g[0] else (int(g[3]), g[5])
            ap = (ap or "").replace(".", "")
            h = (h % 12) + (12 if ap == "pm" else 0) if ap else h
        if 0 <= h <= 23:
            f["send_hour"] = str(h)
            said.append(("Send time", f"{(h % 12) or 12}:00 {'AM' if h < 12 else 'PM'} in your time zone"))
            used.append(m.span())
    if any(_has(t, w) for w in ("all open", "all current", "everything open", "every time", "even if sent", "repeat")):
        f["send"] = "all"
        said.append(("Each email includes", "All open matches"))
    elif any(_has(t, w) for w in ("only new", "just new", "new ones", "not repeated", "never repeat")):
        f["send"] = "new"
        said.append(("Each email includes", "Only new bids"))
    if any(_has(t, w) for w in ("my territory", "in my area", "my region", "my accounts")):
        f["territory_only"] = "1"
        said.append(("Territory", "Only my territory"))
    hide = []
    if any(_has(t, w) for w in ("no tags", "without tags", "no tag line", "no machine")):
        hide.append("tags")
    if any(_has(t, w) for w in ("no summary", "without summaries", "without summary", "no summaries")):
        hide.append("summary")
    if hide:
        f["hide"] = ",".join(hide)
        said.append(("Email contents", "Leave out " + " and ".join({"tags": "the tag line", "summary": "summaries"}[h] for h in hide)))

    # what it skipped, so the member knows what to fix by hand
    rest = list(t)
    for s, e in used:
        rest[s:e] = " " * (e - s)
    left = [w for w in re.findall(r"[a-z][a-z\-&']+", "".join(rest)) if w not in STOP and len(w) > 2 and not w.isdigit()]
    for words in list(CAT_WORDS.values()) + list(SUB_WORDS.values()) + list(COUNTRY_WORDS.values()):
        left = [w for w in left if w not in words]
    left = [w for w in left if w not in DAYS and w.rstrip("s") not in DAYS and w not in ("relevance", "minimum", "strong", "best")]

    # a short name for the alert
    bits = []
    if picked:
        bits.append(" and ".join(a.upper() for a in picked[:2]) + (" +" + str(len(picked) - 2) if len(picked) > 2 else ""))
    if subs:
        bits.append(", ".join(data.SUBSYSTEMS[s] for s in subs[:2]))
    if cats:
        bits.append(", ".join(data.CATEGORIES[c] for c in cats[:2]))
    if f.get("q") and not bits:
        bits.append(f["q"])
    f["name"] = (" · ".join(bits) or "Rail bids")[:80]
    return {"fields": f, "understood": said, "unknown": list(dict.fromkeys(left))[:12], "text": raw}
