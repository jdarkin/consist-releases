"""NexGen punch-list pages (2026-11-07): demand range and quarters, option map, delivery record, agency planner, platform supplier map,
consultants and tier-1, signal profiles, on-call expiry and capital pipeline, drivers, reliability, past RFPs, agency finance,
market note, lessors, and the read-only API with keys."""
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse
from urllib.parse import urlencode

from . import auth, data, intel, nexgen, nexgen2, trainctl
from .main import flash, redirect, render
from .routes_nexgen import _can_export, _export

app = APIRouter(prefix="/app")
api = APIRouter(prefix="/api/v1")
U = Depends(auth.require_user)


def _intel_ok(u):
    """Consultant and tier-1 pages show the same award and supplier data as Supplier intelligence, so they share its plan gate."""
    return u.is_admin or u.can("fleet_detail")


def _intel_locked(request, u, title):
    return render(request, "app/locked.html", user=u, feature="fleet_detail", title=title)


def _r(request, tpl, u, **kw):
    return render(request, tpl, user=u, GAPS=nexgen2.GAPS, stamp=nexgen.data_stamp(), can_export=_can_export(u), **kw)


@app.get("/market-note")
def market_note(request: Request, u=U):
    return _r(request, "app/nx_note.html", u, n=nexgen2.market_note(), PROC_STAGES=nexgen.PROC_STAGES)


@app.get("/option-map")
def option_map(request: Request, u=U):
    rows = nexgen2.option_map()
    kind = request.query_params.get("type") or None  # Type pill filter (1.7.4)
    if kind == "joint":
        rows = [r for r in rows if r["joint"]]
    elif kind == "options":
        rows = [r for r in rows if r.get("opts")]
    elif kind == "research":
        rows = [r for r in rows if r.get("fleet_id")]
    else:
        kind = None
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-options-and-joint-buys", ["Award year", "Operators", "Builder", "Model", "Base", "Options left", "Joint", "Status", "Notes", "Source"],
                       [(r.get("year"), ";".join(r["ops"]), r.get("builder"), r.get("model"), r.get("qty_base"), r.get("opts"), "yes" if r["joint"] else "", r.get("status"),
                         r.get("notes"), r.get("source_url")) for r in rows])
    return _r(request, "app/nx_options.html", u, rows=rows, f={"type": kind} if kind else {})


@app.get("/delivery-record")
def delivery_record(request: Request, u=U):
    rows = nexgen2.delivery_record()
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-builder-delivery-record", ["Builder", "Orders", "Cars", "Cars in backlog", "Avg years award to first delivery", "Orders with delays reported"],
                       [(b["builder"], b["orders"], b["cars"], b["backlog"], b["lead_avg"], len(b["delays"])) for b in rows])
    return _r(request, "app/nx_delivery.html", u, rows=rows)


@app.get("/my-agency/planner")
def planner(request: Request, u=U):
    me = nexgen.my_agency(u)
    oid = request.query_params.get("operator") or (me or {}).get("operator_id")
    if not oid:
        return redirect("/app/my-agency")
    ov = {}
    for k, v in request.query_params.items():
        if k.startswith("y") and k[1:].isdigit() and v.isdigit():
            ov[int(k[1:])] = int(v)
    plan, by_year = nexgen2.planner(oid, ov)
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-capital-plan", ["Fleet", "Cars", "Replacement year", "Basis", "Price per car (mid)", "Replacement cost", "Overhaul year", "Overhaul cost"],
                       [(f"{p['fleet']['manufacturer'] or ''} {p['fleet']['model_name']}", p["cars"], p["rep"], p["basis"], round(p["unit"]) if p["unit"] else None,
                         round(p["rep_cost"]), p["oh_year"], round(p["oh_cost"])) for p in plan]
                       + [("Total by year", None, None, None, None, None, None, None)] + [(str(y), None, None, None, None, round(v["replace"]), None, round(v["overhaul"])) for y, v in by_year.items()])
    name = (data.operator(oid) or {}).get("operator_name", oid)
    # 1.7.35: a chart bar narrows the table to that year (and replacement or overhaul). Other rows are hidden, not dropped,
    # so their replacement-year inputs still go with Recalculate.
    from .routes_app import bar_pick
    sel = bar_pick(request)
    keep = {k: v for k, v in request.query_params.items() if k not in ("y", "k", "export")}

    def href(y, k):
        return "/app/my-agency/planner?" + urlencode({**keep, "y": y, **({"k": k} if k else {})}) + "#list"
    for p in plan:
        p["shown"] = not sel or ((sel[1] in (None, "replace") and p["rep"] == sel[0]) or (sel[1] in (None, "overhaul") and p["oh_year"] == sel[0]))
    n = sum(1 for p in plan if p["shown"])
    return _r(request, "app/nx_planner.html", u, plan=plan, by_year=by_year, oid=oid, op_name=name, ov=ov, sel=sel, n=n, bar_href=href,
              clear_href="/app/my-agency/planner?" + urlencode(keep),
              labels={"replace": "Replacement", "overhaul": "Midlife overhaul"})


def _cov():
    rows, tf = nexgen.coverage()
    snap = [fl for fl in intel.snapshot().values() if (fl["qty_active"] or 0) > 0]
    tc = sum(fl["qty_active"] for fl in snap) or 1
    mapped = sum(fl["qty_active"] for fl in snap if fl["installed"])
    return {"pct": round(100 * mapped / tc), "rows": rows, "fleets": tf}


@app.get("/platforms")
def platforms(request: Request, u=U):
    f = {k: (request.query_params.get(k) or "").strip()[:120] for k in nexgen2.PLATFORM_FILTERS}
    f = {k: v for k, v in f.items() if v}
    recs = nexgen2.platform_records()
    rows, subs, sel = nexgen2.platform_map(f, recs)
    if request.query_params.get("export") in ("csv", "xlsx") and _can_export(u):
        return _export(request, "consist-platform-installed-base", ["Agency", "Platform", "Subsystem", "Supplier", "Product", "Fleets", "Active cars", "Source"],
                       [(r["operator_name"], r["platform"], r["subsystem"], r["supplier"], r["product"], r["fleets"], r["cars"], r["source_url"]) for r in sel])
    names = {fl["operator_id"]: fl["operator_name"] for fl in intel.snapshot_all().values()}
    return _r(request, "app/nx_platforms.html", u, rows=rows, subs=subs, allsubs=sorted({r["sub"] for r in recs}), sel=sel, f=f, names=names, cov=_cov(),
              qs=urlencode(f), base_cars=nexgen2.unique_cars(sel))


@app.get("/consultants-tier1")
def consultants_tier1(request: Request, u=U):  # split into two portals in 1.2
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/app/consultants", status_code=301)


@app.get("/consultants")
def consultants_list(request: Request, u=U):
    if not _intel_ok(u):
        return _intel_locked(request, u, "Engineering consultants")
    from . import consultants as C
    try:
        years = max(1, min(int(request.query_params.get("years") or 5), 10))
    except ValueError:
        years = 5
    f = {k: (request.query_params.get(k) or "").strip()[:80] for k in ("q", "agency", "kind")}
    rows = C.firms(years, q=f["q"] or None, agency=f["agency"] or None, kind=f["kind"] or None)
    allrows = C.firms(years) if any(f.values()) else rows
    agencies = sorted({a for b in allrows for a in b["agencies"]})
    if request.query_params.get("export") in ("csv", "xlsx") and _can_export(u):
        return _export(request, "consist-consultants", ["Firm", "Awards", "Value USD", "Agencies", "Kinds of work", "Open on-call terms", "Latest award", "Website"],
                       [(b["name"], b["n"], b["usd"] or None, "; ".join(b["agencies"]), "; ".join(b["kinds"]), b["oncall_open"], b["last"], b["profile"]["website"]) for b in rows])
    return _r(request, "app/nx_consultants.html", u, rows=rows, f={k: v for k, v in f.items() if v}, years=years, agencies=agencies,
              kinds=[lab for _, lab, _ in C.NATURE])


@app.get("/consultants/{key}")
def consultant_detail(request: Request, key: str, u=U):
    if not _intel_ok(u):
        return _intel_locked(request, u, "Engineering consultants")
    from . import consultants as C
    d = C.firm(key[:80])
    if not d:
        raise HTTPException(404)
    if request.query_params.get("export") in ("csv", "xlsx") and _can_export(u):
        return _export(request, "consist-consultant-" + key, ["Award date", "Agency", "Title", "Kind of work", "Category", "Value USD", "Term months", "Term ends",
                                                              "Bidders", "Reference", "Source"],
                       [(a["award_date"], a["agency"], a["title"], "; ".join(l for _, l in a["nature"]), a["cat_label"], a.get("amount_usd"), a.get("term_months"),
                         a["end"], a.get("n_bidders"), a.get("ref_no"), a.get("source_url")) for a in d["awards"]])
    return _r(request, "app/nx_consultant.html", u, d=d, si=__import__('app.supplierintel', fromlist=['link']).link(d["name"]))


@app.get("/consultants/{key}/news")
def consultant_news(request: Request, key: str, u=U):
    if not _intel_ok(u):
        return _intel_locked(request, u, "Engineering consultants")
    from . import consultants as C, supplier_news as N
    from .main import render as _render
    d = C.firm(key[:80])
    if not d:
        raise HTTPException(404)
    e = C.news_entity(d)
    w = request.query_params.get("w", "30d")
    meta = {}
    try:
        items, err = N.fetch(e[0], N.query(e), w, meta=meta), None
    except Exception:
        items, err = [], "busy"
    return _render(request, "supplier_news.html", user=u, e=(key, e[1]) + e[2:], items=items, err=err, stale=meta.get("stale"), src=meta.get("source"),
                   w=w if w in N.WINDOWS else "30d", N=N, rail=False, root="/app/consultants")


@app.get("/tier1")
def tier1_portal(request: Request, u=U):
    if not _intel_ok(u):
        return _intel_locked(request, u, "Tier-1 suppliers")
    rows = nexgen2.tier1()
    q = (request.query_params.get("q") or "").strip().lower()[:80]
    sub = (request.query_params.get("sub") or "").strip()[:40]
    subs = sorted({s for t in rows for s in t["subs"]})
    if q:
        rows = [t for t in rows if q in t["name"].lower()]
    if sub:
        rows = [t for t in rows if sub in t["subs"]]
    if request.query_params.get("export") in ("csv", "xlsx") and _can_export(u):
        return _export(request, "consist-tier1-suppliers", ["Supplier", "Cars mapped", "Fleets", "Agencies", "Subsystems"],
                       [(t["name"], t["cars"], t["fleets"], len(t["operators"]), "; ".join(t["subs"])) for t in rows])
    return _r(request, "app/nx_tier1.html", u, rows=rows, subs=subs, f={"q": q, "sub": sub})


@app.get("/signal-profiles")
def signal_profiles(request: Request, u=U):
    f = {k: (request.query_params.get(k) or "").strip()[:80] for k in nexgen2.SIGNAL_FILTERS}
    f = {k: v for k, v in f.items() if v}
    res = nexgen2.signal_profiles(f)
    if request.query_params.get("export") in ("csv", "xlsx") and _can_export(u):
        rows = []
        for o in res["mapped"]:
            for q in o["recs"]:
                rows.append((o["operator_id"], o["name"], q["scope"], ", ".join(trainctl.TECH.get(t, trainctl.TECH["UNK"])[0] for t in q["tech"]),
                             " + ".join(x["name"] for x in q["systems"]) or "None", q["oem_label"],
                             "; ".join(f"{x['name']} (formerly {x['formerly']})" for x in q["oems"] if x.get("formerly")),
                             q["status_label"], ", ".join(q["planned"]), q["contract_year"], q["contract_value"], q["integrator"], q["wayside"], q["automation"],
                             q["confidence"], q["conf_label"], q["confirm_with"], "; ".join(q["notes_all"]), " ".join(q["sources"])))
        return _export(request, "consist-train-control", ["Operator ID", "Operator", "Fleets", "Technology", "System", "OEM", "Earlier names", "Status", "Planned",
                                                          "Contract year", "Contract value USD", "Integrator", "Wayside", "Automation", "Grade", "Confidence",
                                                          "Confirm with", "Notes", "Sources"], rows)
    return _r(request, "app/nx_signal.html", u, res=res, f=f, TECH=trainctl.TECH, CONF=trainctl.CONF)


@app.get("/capital-pipeline")
def capital_pipeline(request: Request, u=U):
    f = {k: (request.query_params.get(k) or "").strip()[:80] for k in nexgen2.CAPITAL_KEYS}
    f = {k: v for k, v in f.items() if v}
    pipe, pipe_all = nexgen2.capital_pipeline(365, f)
    oc, oc_all = nexgen2.oncall_expiry(f)
    exp = request.query_params.get("export")
    if exp == "oncall" and _can_export(u):
        return _export(request, "consist-oncall-expiry", ["Buyer", "Title", "Contract holder(s)", "Award date", "Term (months)", "Base end", "Ends with options",
                                                          "Expect re-bid", "Value (USD)", "Value is shared ceiling", "Spent to date (USD)", "Next round notice", "Source"],
                       [(r.get("buyer"), r.get("title"), "; ".join(r["firms"]), r.get("award_date"), r.get("term_months"), r.get("base_end"), r.get("with_options") or r.get("ends"),
                         r.get("rebid"), r.get("value"), "yes" if r.get("value_is_ceiling") else "", r.get("spent"),
                         f"{request.base_url}app/bids/{r['rebid_notice_id']}" if r.get("rebid_notice_id") else "", r.get("source_url")) for r in oc])
    if exp == "pipeline" and _can_export(u):
        return _export(request, "consist-capital-projects", ["Published", "Buyer", "Project", "Type", "Tags", "Est. value", "Currency", "Closes", "Open", "Notice"],
                       [((r.get("published") or "")[:10], r.get("buyer"), r.get("title"), data.CATEGORIES.get(r.get("category"), r.get("category")),
                         "; ".join(l for _, l in r["tags"]), r.get("value_est"), r.get("currency"), (r.get("closing") or r.get("closing_est") or "")[:10],
                         "yes" if r["open"] else "", f"{request.base_url}app/bids/{r['notice_id']}") for r in pipe])
    buyers = sorted({r["buyer"] for r in pipe_all + oc_all if r.get("buyer")}, key=str.lower)
    holders = sorted({v for r in oc_all for v in r["firms"]}, key=str.lower)
    tags = {}
    for r in pipe_all:
        for _, l in r["tags"]:
            tags[l] = tags.get(l, 0) + 1
    return _r(request, "app/nx_pipeline.html", u, pipe=pipe[:300], pipe_n=len(pipe), oc=oc, f=f, buyers=buyers, holders=holders,
              tags=sorted(tags.items(), key=lambda x: -x[1]), cats=[(c, data.CATEGORIES.get(c, c)) for c in nexgen2.CAPITAL_CATS],
              qs=str(request.query_params.__class__([(k, v) for k, v in request.query_params.multi_items() if k != "export"])), lensed=nexgen2._lens_ops() is not None,
              scope_label=f"{nexgen2.lens.current().label}, {nexgen2.lens.current().region_label}")


@app.get("/drivers")
def drivers(request: Request, u=U):
    me = nexgen.my_agency(u)
    oid = request.query_params.get("operator") or (me or {}).get("operator_id")
    fd = nexgen2.funding_for(oid) if oid else {}
    work = request.query_params.get("work", "")
    shown = [r for r in fd.get("rows", []) if not work or r["work"] == work]
    return _r(request, "app/nx_drivers.html", u, rows=nexgen2.drivers(), fd=fd, shown=shown, work=work, oid=oid,
              ops=sorted(data.operators(), key=lambda o: o["operator_name"]))


@app.get("/reliability")
def reliability(request: Request, u=U):
    mode = request.query_params.get("mode") or None
    rows, meds = nexgen2.reliability(mode)
    if request.query_params.get("export") and _can_export(u):
        return _export(request, "consist-reliability", ["Operator", "Mode", "NTD year", "Miles between failures", "Mode median", "Change since first year (%)", "Spare ratio (%)"],
                       [(r["name"], r["mode"], r["year"], r["mdbf"], meds.get(r["mode"]), r["change"], r["spare"]) for r in rows])
    modes = sorted({m for (_o, m) in intel.operator_mode_stats().keys() if m})
    return _r(request, "app/nx_reliability.html", u, rows=rows, meds=meds, mode=mode, modes=modes)


@app.get("/past-rfps")
def past_rfps(request: Request, u=U):
    if not u.bids:
        return render(request, "app/locked.html", user=u, feature="bids_recent", title="Past RFPs")
    f = {k: (request.query_params.get(k) or "").strip()[:80] for k in nexgen2.PAST_KEYS}
    f = {k: v for k, v in f.items() if v}
    export = request.query_params.get("export") in ("csv", "xlsx") and _can_export(u)
    rows, stats = nexgen2.past_rfps(limit=5000 if export else 300, f=f)
    if export:
        return _export(request, "consist-past-rfps", ["Closed", "Agency", "Solicitation", "Category", "Method", "Winner", "Bidders", "Award USD", "Award date", "Matched by", "Notice"],
                       [((r.get("closing") or "")[:10], r.get("buyer") or r.get("operator_id"), r.get("title"), data.CATEGORIES.get(r.get("category"), r.get("category")),
                         "; ".join(l for g, l in r["tags"] if g in ("method", "contract")), r.get("vendor"), r.get("n_bidders"), r.get("amount_usd"), r.get("award_date"),
                         r.get("match"), r.get("url")) for r in rows])
    return _r(request, "app/nx_past.html", u, rows=rows, stats=stats, f=f, ops=sorted(data.operators(), key=lambda o: o["operator_name"]),
              tag_labels=[l for _, l, _ in nexgen.TAG_RX], qs=str(request.query_params))


@app.get("/agency-finance")
def agency_finance(request: Request, u=U):
    me = nexgen.my_agency(u)
    oid = request.query_params.get("operator") or (me or {}).get("operator_id")
    rows, latest = nexgen2.finance(oid) if oid else ([], [])
    return _r(request, "app/nx_finance.html", u, rows=rows, latest=latest, oid=oid, op_name=(data.operator(oid) or {}).get("operator_name") if oid else None,
              ops=sorted(data.operators(), key=lambda o: o["operator_name"]))


@app.get("/lessors")
def lessors(request: Request, u=U):
    return _r(request, "app/nx_lessors.html", u, v=nexgen2.lessor_view())


# ---------------- API keys (account side) ----------------

def _api_ok(u):
    return u.is_admin or u.can("api")  # enterprise only (Justin, 2026-11-08): no longer comes with CSV export


@app.get("/api-keys")
def api_keys(request: Request, u=U):
    return _r(request, "app/nx_api.html", u, keys=nexgen2.keys_for(u), allowed=_api_ok(u), new=request.session.pop("nx_new_key", None))


@app.post("/api-keys")
def api_keys_post(request: Request, csrf: str = Form(""), action: str = Form("new"), kid: int = Form(0), label: str = Form(""), u=U):
    auth.check_csrf(request, csrf)
    if not _api_ok(u):
        raise HTTPException(403, "API access is part of enterprise plans. Contact us for a quote.")
    if action == "revoke" and kid:
        nexgen2.revoke(u, kid)
        flash(request, "Key revoked.")
    else:
        request.session["nx_new_key"] = nexgen2.new_key(u, label)
    return redirect("/app/api-keys")


# ---------------- read-only API ----------------

API_PER_HOUR = 600  # per key; the API is for syncing a CRM or BI tool, not bulk scraping
_api_hits = {}


def _api_user(request: Request):
    import time
    k = (request.headers.get("authorization") or "").removeprefix("Bearer ").strip() or request.headers.get("x-api-key", "")
    u = nexgen2.user_for_key(k)
    if not u or not _api_ok(u):
        raise HTTPException(401, "Send a valid API key as 'Authorization: Bearer <key>'. Keys are made under Account > API keys.")
    hour = int(time.time() // 3600)
    slot = k[:16]
    h, n = _api_hits.get(slot, (hour, 0))
    n = n + 1 if h == hour else 1
    _api_hits[slot] = (hour, n)
    if len(_api_hits) > 5000:
        for kk in [kk for kk, (hh, _) in _api_hits.items() if hh != hour]:
            _api_hits.pop(kk, None)
    if n > API_PER_HOUR:
        raise HTTPException(429, f"Rate limit: {API_PER_HOUR} requests per hour per key. Try again next hour.")
    return u


def _page(request, rows, cap=1000):
    try:
        lim = min(cap, max(1, int(request.query_params.get("limit") or 200)))
        off = max(0, int(request.query_params.get("offset") or 0))
    except ValueError:
        lim, off = 200, 0
    return {"total": len(rows), "offset": off, "limit": lim, "data": rows[off:off + lim],
            "terms": "Internal use under your Consist subscription. No resale or redistribution. Sources: NTD, agency documents, Consist research."}


FLEET_COLS = ("fleet_id", "operator_id", "operator_name", "country", "ntd_mode", "vehicle_class", "manufacturer", "model_name", "propulsion", "build_year",
              "last_rebuild_year", "qty_active", "ulb_year", "midlife_due_year", "est_annual_miles_per_car", "maint_cost_per_car_year")


@api.get("/fleets")
def api_fleets(request: Request):
    _api_user(request)
    op = request.query_params.get("operator")
    rows = [{k: fl.get(k) for k in FLEET_COLS} for fl in intel.snapshot_all().values() if not op or fl["operator_id"] == op]
    for r in rows:
        st = nexgen.proc_stage(r["fleet_id"]) or {}
        r["procurement_stage"] = st.get("stage")
    return JSONResponse(_page(request, rows))


@api.get("/operators")
def api_operators(request: Request):
    _api_user(request)
    return JSONResponse(_page(request, [{k: o.get(k) for k in ("operator_id", "operator_name", "country", "category", "states", "modes")} for o in data.operators()]))


@api.get("/upcoming")
def api_upcoming(request: Request):
    _api_user(request)
    try:
        years = min(20, max(1, int(request.query_params.get("years") or 10)))
    except ValueError:
        years = 10
    types = [t for t in (request.query_params.get("type") or "").split(",") if t in intel.WORK_TYPES] or None
    rows = []
    for o in intel.work_timeline(types, years):
        st = nexgen.proc_stage(o["fleet"]["fleet_id"]) or {}
        rows.append({"year": o["year"], "type": o["type"], "fleet_id": o["fleet"]["fleet_id"], "order_id": o.get("order_id"), "operator_id": o["fleet"]["operator_id"],
                     "model": o["fleet"]["model_name"], "cars": o["cars"], "value_usd": round(o["value"] or 0), "score": o["score"],
                     "procurement_stage": st.get("stage"), "expected_rfp": st.get("expected_rfp"), "awarded_to": st.get("awarded_to")})
    return JSONResponse(_page(request, rows))


@api.get("/orders")
def api_orders(request: Request):
    _api_user(request)
    return JSONResponse(_page(request, [{k: o.get(k) for k in ("year", "operator_id", "builder", "model", "cars", "qty_options", "value", "per_car", "status", "delivery", "backlog", "source_url")}
                                        for o in nexgen.orders() if o.get("cars")]))


@api.get("/bids")
def api_bids(request: Request):
    u = _api_user(request)
    if not u.bids:
        raise HTTPException(403, "Your plan does not include bids.")
    rows, _ = data.notices({"status": request.query_params.get("status") or "open"}, per=None, full_history=u.can("bids_full"))
    return JSONResponse(_page(request, [dict({k: r.get(k) for k in ("notice_id", "operator_id", "title", "category", "published", "closing", "value_est", "currency", "url", "lang", "title_en")},
                                             buyer=r.get("buyer") or r.get("agency")) for r in rows]))
