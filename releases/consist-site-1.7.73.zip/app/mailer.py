"""Outgoing email over SMTP (IONOS or any provider). Without SMTP settings, messages are written to the log instead."""
import email.message
import email.utils
import logging
import smtplib
import ssl

from . import config

log = logging.getLogger("consist.mail")


def configured():
    return bool(config.SMTP_HOST)


def _with_name(sender):
    """Adds the site name as the display name ("Consist <noreply@consist-na.com>") when the From setting is a bare address."""
    name, addr = email.utils.parseaddr(sender or "")
    if name or not addr:
        return sender
    try:
        from . import db
        name = db.settings().get("site_name") or "Consist"
    except Exception:
        name = "Consist"
    return email.utils.formataddr((name, addr))


def _support(sender_addr):
    """Replies go to the support address when it is real and differs from the sender."""
    try:
        from . import db
        s = (db.settings().get("support_email") or "").strip()
    except Exception:
        return ""
    return s if "@" in s and not s.endswith("@example.com") and s.lower() != (sender_addr or "").lower() else ""


def send(to, subject, text, html=None, alerts=False, reply_to=None, optional=False, personal=False, ambassador=False):
    """optional=True marks mail the recipient can opt out of (alerts, invites, notes): it carries one-click List-Unsubscribe
    headers and is skipped when the address has opted out. Leave it False for account mail (password resets, sign-up).
    alerts=True sends from the bid alert mailbox (Admin > Settings > Email) when one is set, else the main one.
    personal=True (1.7.46, Ambassador invites): one-to-one mail. The opt-out check still applies, but no List-Unsubscribe headers:
    Gmail and Microsoft read them as bulk or marketing mail and file a first message from a new sender in Promotions, Junk or
    quarantine, which is why the "Send a test to me" copy (no headers) arrived and the real invites often did not."""
    if not configured():
        log.warning("SMTP not configured; would send to %s: %s\n%s", to, subject, text)
        return False
    if optional:
        from . import unsub
        if unsub.is_out(to):
            log.info("skipped optional email to %s (opted out): %s", to, subject)
            return False
    user, password, sender = config.SMTP_USER, config.SMTP_PASSWORD, config.SMTP_FROM
    if alerts and config.ALERT_SMTP_USER and config.ALERT_SMTP_PASSWORD:
        user, password, sender = config.ALERT_SMTP_USER, config.ALERT_SMTP_PASSWORD, config.ALERT_SMTP_FROM
    if ambassador and config.AMB_SMTP_USER and config.AMB_SMTP_PASSWORD:  # 1.7.72: Ambassador invite sender
        user, password, sender = config.AMB_SMTP_USER, config.AMB_SMTP_PASSWORD, config.AMB_SMTP_FROM
        reply_to = reply_to or email.utils.parseaddr(sender)[1]  # personal mail: replies come back to the invite mailbox
    msg = email.message.EmailMessage()
    msg["From"] = _with_name(sender)
    msg["To"] = to
    msg["Subject"] = subject
    # Date and Message-ID: smtplib adds neither, and spam filters (Gmail, Outlook, SpamAssassin) mark mail without them
    msg["Date"] = email.utils.formatdate(localtime=False, usegmt=True)
    addr = email.utils.parseaddr(sender)[1]
    msg["Message-ID"] = email.utils.make_msgid(domain=addr.rsplit("@", 1)[-1] if "@" in addr else None)
    if optional and not personal:
        from . import unsub
        sup = _support(addr)  # a mailto fallback only when someone reads that inbox
        msg["List-Unsubscribe"] = f"<{unsub.url(to)}>" + (f", <mailto:{sup}?subject=unsubscribe>" if sup else "")
        msg["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"
    rt = reply_to or _support(addr)
    if rt:
        msg["Reply-To"] = rt
    msg.set_content(text)
    if html:
        msg.add_alternative(html, subtype="html")
    try:
        _smtp(msg, user, password)
    except Exception as ex:
        from . import syslog
        syslog.record("error", "mail", f"Email to {to} failed: {type(ex).__name__}: {ex}"[:400], "smtp", detail={"subject": subject[:200]})
        raise
    return True


def _smtp(msg, user, password):
    ctx = ssl.create_default_context()
    if config.SMTP_PORT == 465:
        with smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, context=ctx, timeout=30) as s:
            s.login(user, password)
            s.send_message(msg)
    else:
        with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30) as s:
            s.starttls(context=ctx)
            if user:
                s.login(user, password)
            s.send_message(msg)
    return True
